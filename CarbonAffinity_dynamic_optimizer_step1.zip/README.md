# CarbonAffinity main experiment

This directory implements the paper's primary experiment only: two physical
regions, exactly one NVIDIA A800 per region, Qwen3.5-27B, and tensor parallelism
1. The configuration validator rejects an 8-GPU or TP=8 setup so those results
cannot accidentally enter the main comparison.

## Dynamic optimizer development

The frozen V6.1 policy remains the experimental baseline. New optimizer work is
specified in `experiments/ONLINE_OPTIMIZER_DESIGN.md`; it starts with an exact,
finite-horizon offline oracle used to measure the optimality gap of the future
bounded-time online scheduler.

Run the included three-region oracle example:

```bash
PYTHONPATH="$PWD" python scripts/solve_offline_oracle.py \
  --input configs/offline_oracle_example.json \
  --output results/offline_oracle_example_solution.json
```

Build a bounded instance from a replay config before solving it:

```bash
PYTHONPATH="$PWD" python scripts/build_offline_oracle_problem.py \
  --config configs/real_window_00.generated.yaml \
  --max-requests 12 --epoch-ms 1000 \
  --output results/oracle_window00_slice.json
```

For the first four-hour, one-A800 workflow validation, follow
[`SINGLE_GPU_TRIAL.md`](SINGLE_GPU_TRIAL.md). That smoke path is explicitly
excluded from paper results.

## What is measured

- Forecast marginal operating emissions rate (MOER) is used only at dispatch.
- Historical MOER is used for ex-post settlement.
- Each host samples only the assigned A800 with NVML. Host and cooling energy
  are explicitly outside this measurement boundary.
- Cache reuse predicted by the state directory and cached tokens actually
  reported by vLLM are separate fields. A missing vLLM observation remains
  `null`.
- A lease uses a stable vLLM `cache_salt` while valid and rotates the salt after
  expiry. This prevents further hits to expired state; old blocks are reclaimed
  by vLLM's normal eviction policy. Physical per-session eviction remains
  `lease_enforced: null` unless a cache-control plugin confirms it, so namespace
  invalidation is never mislabeled as immediate HBM release.

## 1. Install on both A800 hosts

```bash
cd /root/CarbonAffinity
export PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/
export HF_ENDPOINT=https://hf-mirror.com
unset PIP_EXTRA_INDEX_URL
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --index-url "$PIP_INDEX_URL" -r requirements.txt
python -m pip install -e . --no-deps
```

Model weights must be downloaded from ModelScope during bootstrap and served
from a local path. Runtime launchers set Hugging Face and Transformers offline
mode, so a measured run cannot silently fetch files from the public Hub. See
[`SINGLE_GPU_TRIAL.md`](SINGLE_GPU_TRIAL.md) for the exact mirrored download
and capability-gated bootstrap.

## 2. Start identical TP=1 vLLM replicas

Run this on each physical host (change the model path only if necessary):

```bash
CUDA_VISIBLE_DEVICES=0 \
nohup vllm serve /root/models/Qwen3.5-27B \
  --served-model-name Qwen3.5-27B \
  --host 127.0.0.1 \
  --port 18000 \
  --tensor-parallel-size 1 \
  --enable-prefix-caching \
  --max-model-len 32768 \
  --gpu-memory-utilization 0.92 \
  > results/vllm.log 2>&1 &
```

On the coordinator in region A, forward region B's local API and control sidecar:

```bash
ssh -N \
  -L 28000:127.0.0.1:18000 \
  -L 29000:127.0.0.1:19000 \
  USER@REGION_B_HOST
```

## 3. Calibrate the two A800s separately

On region A:

```bash
python scripts/calibrate_region.py \
  --region-id region_a \
  --api-base http://127.0.0.1:18000/v1 \
  --model Qwen3.5-27B \
  --tokenizer /root/models/Qwen3.5-27B \
  --gpu-index 0 \
  --output profiles/region_a.json
```

Run the same command on region B with `region_b`, then copy
`region_b.json` and its `.samples.jsonl` file back to the coordinator. This is a
short hardware calibration, not model training.

On each host also capture a site manifest (use the actual grid-zone identifier):

```bash
python scripts/collect_site_manifest.py \
  --region-id region_a --grid-region GRID_ZONE_A \
  --model-dir /root/models/Qwen3.5-27B --gpu-index 0 \
  --output manifests/region_a.json
```

Copy region B's manifest to the coordinator. Preflight checks that the GPU UUIDs
are different and the model configuration hashes match.

## 4. Supply workload and carbon data

Copy and replace the examples:

```bash
cp data/normalized/main_trace.example.jsonl data/normalized/main_trace.jsonl
cp data/carbon/moer.example.csv data/carbon/moer.csv
```

The request trace must explicitly provide `shared_prefix_tokens`; session IDs
alone are never treated as proof of cache reuse. Carbon CSV timestamps must
cover the configured replay window, with both forecast and historical MOER.
Fit return-time parameters from the training split only with
`scripts/fit_return_model.py`; copy its workload-group parameters into the
`lease.return_models` configuration before the measured campaign.

Measure the HBM opportunity-cost term with `measure_cache_pressure.py` on each
site and fit it with `fit_memory_shadow.py`. Copy the fitted
`memory_shadow_g_per_gib_s` into the config and set `lease.calibrated: true`.
The fitted value is a score-equivalent opportunity cost, not direct CO2; a
scientifically valid zero slope is accepted.
Use `derive_kv_footprint.py` to derive `kv_bytes_per_token` from the exact model
configuration; hybrid/custom cache models must be checked against vLLM's
allocated cache blocks rather than accepted blindly.

## 5. Start local-only site agents and preflight

On each host, use the same long random token and its own region ID/manifest:

```bash
export CARBONAFFINITY_CONTROL_TOKEN='REPLACE_WITH_AT_LEAST_16_RANDOM_CHARACTERS'
nohup python scripts/site_agent.py \
  --region-id region_a --gpu-index 0 \
  --manifest manifests/region_a.json \
  --output-root results/site_agent \
  --host 127.0.0.1 --port 19000 \
  > results/site_agent.log 2>&1 &

python scripts/preflight.py \
  --config configs/two_region_a800.yaml \
  --output results/preflight.json
```

The sidecar binds to loopback by default and rejects requests without the token.

## 6. Run the complete randomized campaign

```bash
python scripts/run_campaign.py \
  --config configs/two_region_a800.yaml \
  --output-root results/main_campaign \
  --resume
```

The comparison includes `round_robin`, `pressure_only`, `cleanest_now`,
`sticky`, `cedar_like`, `carbon_affinity`, and the hindsight
`oracle_historical`. `run_campaign.py` randomizes their order, controls both
site samplers, downloads separate telemetry, audits every policy, and supports
resumption without deleting verified outputs. It also requires both vLLM
servers to acknowledge `/reset_prefix_cache` before each policy so cache state
cannot leak from one baseline into the next.
