from __future__ import annotations

import argparse
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

from carbonaffinity.carbon import CarbonTrace
from carbonaffinity.config import load_config, resolve_path
from carbonaffinity.models import RegionSnapshot, RequestSpec
from carbonaffinity.profile import HardwareProfile
from carbonaffinity.replay import load_trace


def timestamp(value: str | float | int) -> float:
    if isinstance(value, (int, float)):
        return float(value)
    return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()


def curve(profile: HardwareProfile, request: RequestSpec, cached: int) -> dict[str, float]:
    values = profile._batch_curve(request, cached)  # calibrated profile surface
    return {str(key): float(value) for key, value in sorted((values or {}).items())}


def option(
    profile: HardwareProfile,
    request: RequestSpec,
    region_id: str,
    rtt_ms: float,
) -> dict[str, Any]:
    snapshot = RegionSnapshot(region_id, 0, 0, rtt_ms=rtt_ms)
    cached = min(request.prompt_tokens, request.shared_prefix_tokens)
    cold = profile.estimate(request, 0, snapshot)
    warm = profile.estimate(request, cached, snapshot)
    warm_cold_tokens = request.prompt_tokens - cached
    return {
        "cold_energy_j": cold.solo_energy_j,
        "warm_energy_j": warm.solo_energy_j,
        "cold_ttft_ms": cold.ttft_ms,
        "warm_ttft_ms": warm.ttft_ms,
        "tpot_ms": cold.tpot_ms,
        "cold_batch_energy_multipliers": curve(profile, request, 0),
        "warm_batch_energy_multipliers": curve(profile, request, cached),
        "cold_ttft_ms_per_additional_request": (
            profile.active_ttft_ms_per_request
            + profile.active_ttft_base_ms_per_request
            + request.prompt_tokens
            * profile.active_ttft_ms_per_cold_token_per_request
        ) * profile.uncertainty_margin,
        "warm_ttft_ms_per_additional_request": (
            profile.active_ttft_ms_per_request
            + profile.active_ttft_base_ms_per_request
            + warm_cold_tokens
            * profile.active_ttft_ms_per_cold_token_per_request
        ) * profile.uncertainty_margin,
        "cold_tpot_ms_per_additional_request": (
            profile.tpot_ms_per_active_request
            + profile.tpot_active_base_ms_per_request
            + request.prompt_tokens
            * profile.tpot_active_ms_per_cold_token_per_request
        ) * profile.uncertainty_margin,
        "warm_tpot_ms_per_additional_request": (
            profile.tpot_ms_per_active_request
            + profile.tpot_active_base_ms_per_request
            + warm_cold_tokens
            * profile.tpot_active_ms_per_cold_token_per_request
        ) * profile.uncertainty_margin,
        "in_domain": profile.in_domain(request, snapshot),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build a bounded exact-oracle instance from a real replay config."
    )
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-requests", type=int, default=16)
    parser.add_argument("--epoch-ms", type=float, default=1000.0)
    parser.add_argument("--initial-placements", type=Path)
    parser.add_argument(
        "--migration-matrix", type=Path,
        help="JSON object keyed by source->destination with energy_j and delay_ms",
    )
    args = parser.parse_args()
    if args.max_requests < 1 or args.epoch_ms <= 0:
        raise ValueError("max-requests and epoch-ms must be positive")

    config = load_config(args.config)
    trace_path = resolve_path(config, config["experiment"]["trace"])
    rows = load_trace(trace_path, float(config.get("runtime", {}).get("arrival_scale", 1.0)))
    rows = rows[: args.max_requests]
    requests = [RequestSpec.from_dict(row) for row in rows]
    profiles = {
        row["id"]: HardwareProfile.from_json(resolve_path(config, row["profile"]))
        for row in config["regions"]
    }
    carbon = CarbonTrace.from_csv(
        resolve_path(config, config["carbon"]["trace"]),
        max_age_s=float(config["carbon"].get("max_age_s", 1800.0)),
    )
    if str(config["carbon"].get("clock_mode", "trace_relative")) != "trace_relative":
        raise ValueError("oracle builder currently requires trace_relative carbon clock")
    carbon_start = timestamp(config["carbon"]["trace_start_timestamp"])

    grouped: dict[int, list[RequestSpec]] = defaultdict(list)
    for request in requests:
        grouped[int(request.arrival_ms // args.epoch_ms)].append(request)

    region_rows = []
    for row in config["regions"]:
        profile = profiles[row["id"]]
        region_rows.append({
            "region_id": row["id"],
            "capacity": min(
                int(row.get("admission_concurrency", profile.max_concurrency)),
                profile.max_concurrency,
            ),
            # Request-specific calibrated curves are stored in each option.
            "batch_energy_multipliers": {"1": 1.0},
        })

    epochs = []
    for bucket, bucket_requests in sorted(grouped.items()):
        relative_s = bucket * args.epoch_ms / 1000.0
        intensity = {}
        for region_id in profiles:
            observation = carbon.at(region_id, carbon_start + relative_s)
            if observation.forecast_lbs_per_mwh is None:
                raise ValueError(
                    f"missing/stale carbon for {region_id} at relative second {relative_s}"
                )
            intensity[region_id] = observation.forecast_lbs_per_mwh
        request_rows = []
        for request in bucket_requests:
            request_rows.append({
                "request_id": request.request_id,
                "session_id": request.session_id,
                "ttft_slo_ms": request.ttft_slo_ms,
                "tpot_slo_ms": request.tpot_slo_ms,
                "options": {
                    region["id"]: option(
                        profiles[region["id"]], request, region["id"],
                        float(region.get("rtt_ms", 0.0)),
                    )
                    for region in config["regions"]
                },
            })
        epochs.append({
            "epoch_id": str(bucket),
            "carbon_lbs_per_mwh": intensity,
            "requests": request_rows,
        })

    initial = {}
    if args.initial_placements:
        initial = json.loads(args.initial_placements.read_text(encoding="utf-8"))
    migration = {}
    if args.migration_matrix:
        migration = json.loads(args.migration_matrix.read_text(encoding="utf-8"))
    payload = {
        "schema_version": 1,
        "source": {
            "config": str(args.config),
            "trace": str(trace_path),
            "max_requests": args.max_requests,
            "epoch_ms": args.epoch_ms,
            "warning": (
                "Epochs use trace arrival buckets. For a physical-run oracle, "
                "rebuild epochs from recorded dispatch times."
            ),
        },
        "regions": region_rows,
        "initial_placements": initial,
        "migration": migration,
        "epochs": epochs,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print("requests =", len(requests))
    print("epochs =", len(epochs))
    print("regions =", len(region_rows))
    print("ORACLE_PROBLEM_COMPLETE =", args.output.resolve())


if __name__ == "__main__":
    main()
