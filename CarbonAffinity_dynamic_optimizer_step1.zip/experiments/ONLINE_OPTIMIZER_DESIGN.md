# CarbonAffinity online optimizer design

Status: implementation design. V6.1 remains a frozen experimental baseline.

## Optimization problem

At routing epoch `t`, request `i` is assigned to one serving region `r` with
binary variable `x[i,r,t]`. The system minimizes operational carbon over a
rolling horizon:

`compute carbon + cache-rebuild carbon + network/migration carbon + terminal state value`.

The optimizer enforces one assignment per request, regional admission capacity,
model/context compatibility, and TTFT/TPOT SLOs. Energy is state dependent:
a request is warm only when its reusable prefix is resident at the chosen
region. Batch size is determined by all assignments to the same region in the
same epoch, so energy, latency, cache state, and capacity are coupled rather
than handled by independent rules.

The exact implementation in `carbonaffinity/offline_oracle.py` uses the state

`S[t] = {session -> cache-bearing region}`

and enumerates the joint assignment at each epoch. Dynamic programming keeps
the cheapest path to every reachable cache state. This yields a globally
optimal answer for a small frozen instance and explicitly accounts for:

- time-varying regional carbon intensity;
- region-specific cold and warm energy/latency;
- calibrated batch-energy curves;
- request-, shape-, and cache-specific batch-energy curves and concurrency slopes;
- regional capacity and load-dependent TTFT/TPOT;
- cache-state transitions;
- network energy and delay on migration.

The solver is exponential in the number of simultaneous requests and cache
states. It is intentionally an offline oracle, not a deployment algorithm.

`scripts/build_offline_oracle_problem.py` converts a bounded prefix of an
existing replay config into this schema. Its arrival-time buckets are suitable
for early algorithm development. A paper optimality-gap result must instead
use epochs reconstructed from recorded physical dispatch times and include a
frozen measured migration matrix (accepted by the builder through
`--migration-matrix`).

## Production algorithm

The production path will use receding-horizon control. At every epoch it will:

1. read live carbon, queue, capacity, cache, network, and model-residual state;
2. compute a per-session finite-horizon state-value table;
3. allocate requests jointly using regional dual prices for capacity;
4. execute only the first assignment;
5. update energy, latency, and forecast residual models from observed results.

Regional dual prices are updated online: overload raises a region's price and
spare capacity lowers it. This is the decomposition mechanism that preserves
cross-request coupling without enumerating the global state in production.
Health and model compatibility remain safety checks; cache, migration, batch,
network, SLO, and capacity costs belong to the unified optimizer.

## Validation order

1. Exact oracle on synthetic cases with known answers.
2. Exact oracle versus online approximation on small trace slices.
3. Shadow-mode decisions beside the serving system.
4. Multi-region same-host replay with region-to-GPU rotation.
5. A real three-or-more-geography canary with measured RTT and transfer cost.

Report optimality gap, decision latency, carbon, SLO violations, migrations,
cache reuse, and model residual coverage. A deployable optimizer must have a
strict per-epoch time budget and fall back to the best feasible incumbent, not
to an unprincipled chain of special cases.
