# CarbonAffinity: State-Aware Carbon Routing for Multi-Turn and Agentic LLM Serving

> Detailed research plan, scope freeze, and evaluation blueprint  
> Version: 0.1 (2026-08-17)  
> Intended paper type: computer systems / sustainable AI serving

## 0. Executive decision

CarbonAffinity studies a concrete production problem:

> A cloud provider already operates identical LLM replicas in several policy-eligible regions. A multi-turn conversation or agent trajectory leaves valuable serving state, especially KV cache, at the region that served the previous turn. When the next turn arrives, should the provider preserve session affinity and reuse that state, or rehome the turn to a currently cleaner grid and pay the resulting cache-miss, re-prefill, WAN, and latency costs?

The paper will not study arbitrary worldwide routing, model-quality degradation, model-size selection, power capping, or the construction of new replicas solely for carbon reduction. Its core decision is deliberately narrow:

1. route each returning turn to one of the session's already approved replicas; and
2. decide how long the current replica should retain the session's KV state while the user or tool is inactive.

The central hypothesis is that neither carbon-greedy routing nor static sticky sessions are correct:

- carbon-greedy per-turn routing can destroy reusable state and increase both energy and TTFT;
- permanent pinning preserves state but misses real carbon opportunities after long tool gaps, cache eviction, or large changes in regional marginal emissions;
- the correct policy depends jointly on session state, queue state, predicted inter-turn time, and time-varying grid state.

The intended novelty is therefore **state-aware carbon routing**, not merely adding a carbon coefficient to an existing load balancer.

## 1. Proposed title and concise pitch

### Primary title

**CarbonAffinity: State-Aware Carbon Routing for Multi-Turn and Agentic LLM Serving**

### One-sentence pitch

CarbonAffinity dynamically chooses between cache-affine execution and carbon-aware rehoming at multi-turn boundaries, minimizing settled operational emissions while preserving per-turn latency and end-to-end agent completion SLOs.

### Candidate abstract skeleton

Geo-distributed LLM services can route inference toward regions with cleaner marginal electricity, but existing carbon routers largely treat requests as independent. This assumption breaks for multi-turn conversations and agentic workflows: successive turns share an expanding prefix, leave KV cache at a particular replica, and are separated by uncertain user or tool delays. Moving a returning turn to a cleaner region may therefore force a full re-prefill, increasing energy and violating TTFT, while permanently pinning the session can forfeit carbon savings when cached state has expired or grid conditions change. We propose CarbonAffinity, a state-aware routing layer that tracks per-session cache residency, queue pressure, tool-gap uncertainty, and forecast marginal emissions. At each turn boundary it grants a bounded cache lease and rehomes a session only when predicted settled-carbon savings exceed the state-loss and SLO-risk costs. CarbonAffinity uses the same model and decoding configuration in every region, preserving output quality by construction. We plan to implement CarbonAffinity over vLLM-compatible replicas and evaluate it using real multi-turn and coding-agent traces, telemetry-calibrated energy models, historical-MOER settlement, and a live multi-region testbed.

## 2. Research background and urgency

### 2.1 AI inference is becoming a material electricity load

The motivation should not rest on a vague claim that "AI uses much energy." The production pressure is more specific:

- The IEA reports that data centres used about 415 TWh in 2024 and projects consumption to more than double to roughly 945 TWh by 2030, with AI as the main growth driver.
- AI inference is continuous rather than a one-time training event. Its placement decisions occur repeatedly and can therefore become an operational control surface.
- Data-centre capacity is geographically concentrated, while marginal emissions vary by grid and time. Two otherwise identical inference executions can consequently have different operational carbon impact.

Sources: [IEA Energy and AI](https://www.iea.org/reports/energy-and-ai/), [IEA executive summary](https://www.iea.org/reports/energy-and-ai/executive-summary).

### 2.2 Multi-turn and agentic serving is no longer a niche workload

The target workload is not invented for this paper. Modern chat, coding, browser, data-analysis, and enterprise workflow agents repeatedly alternate between LLM inference and external actions. The same trajectory may issue tens of LLM calls while its context grows.

MLCommons added an agentic inference workload to MLPerf Endpoints in 2026. Its client explicitly preserves turn dependencies, inter-turn delays, and a stable `X-Session-ID` so routers can maintain KV-cache locality. This is direct evidence that conversation-aware routing is now part of realistic inference benchmarking, rather than an optional application optimization. Source: [MLCommons Agentic Inference](https://mlcommons.org/2026/07/agentic-inference-for-mlperf-inference/).

TraceLab reports roughly 4,300 real coding-agent sessions containing about 350,000 LLM steps and 430,000 tool calls. These workloads are session-structured and temporally correlated, unlike independent prompt benchmarks. Source: [TraceLab](https://arxiv.org/abs/2606.30560).

### 2.3 Persistent serving state has measurable value

Successive turns repeat most of the conversation history. If a later turn reaches a replica that retains the corresponding prefix KV cache, the engine can avoid recomputing that prefix. If it reaches a different region or a replica without the state, it must reload or recompute it.

This is not a minor implementation detail:

- CachedAttention reports large TTFT, throughput, and cost gains from preserving multi-turn KV state.
- Continuum shows that tool calls create pauses during which naive serving systems evict state, causing repeated prefill and accumulated queueing delay when the agent returns.
- A USENIX ATC production characterization confirms that KV reuse patterns are workload dependent and predictable for request categories.
- DualMap shows that even within one cluster, cache affinity conflicts with ordinary load balancing.

Sources: [CachedAttention](https://arxiv.org/abs/2403.19708), [Continuum](https://arxiv.org/abs/2511.02230), [KVCache Cache in the Wild](https://www.usenix.org/conference/atc25/presentation/wang-jiahao), [DualMap](https://arxiv.org/abs/2602.06502).

### 2.4 The production conflict

Carbon routing and session affinity pull in opposite directions:

- a carbon router wants to follow the cleanest eligible region as grid conditions change;
- a serving router wants a returning turn to follow its existing KV state;
- a load balancer wants to avoid hot replicas;
- an SLO controller wants low network delay, low queueing delay, and predictable TTFT;
- an enterprise policy layer forbids some regions regardless of their carbon intensity.

Existing work generally optimizes only a subset of these forces. CarbonAffinity makes their interaction the primary problem.

## 3. Exact real-world application scenario

### 3.1 Operator

The intended operator is a cloud or enterprise LLM platform serving the same model from multiple regions. As is standard in online routing, we assume that an existing provisioning layer has placed warm replicas in the candidate regions; the router takes this feasible replica set as input.

Replica placement, autoscaling, and long-term capacity planning are outside the first paper's scope. A future joint placement-and-routing formulation would need to account explicitly for idle energy and embodied carbon.

### 3.2 Users and request classes

The platform serves a mixture of:

1. multi-turn chat and enterprise RAG sessions;
2. coding, data-analysis, and browser agents with tool calls;
3. single-turn traffic used as a control workload.

Each session carries:

- a stable session or trajectory ID;
- an allowed region set derived from tenancy, data residency, and policy;
- TTFT and TPOT targets;
- for agents, an optional trajectory-completion or deadline target.

### 3.3 Geographic realism

The paper will not assume that an EU enterprise request can freely move to the United States. For every session (s), routing is restricted to an eligibility set:

\[
\mathcal{R}_s = \mathcal{R}^{\mathrm{residency}}_s
\cap \mathcal{R}^{\mathrm{model}}_s
\cap \mathcal{R}^{\mathrm{latency}}_s
\cap \mathcal{R}^{\mathrm{tenant}}_s.
\]

Carbon optimization occurs only inside this set. A realistic primary deployment is several grid-diverse regions within one legal jurisdiction, such as multiple CONUS grid regions, rather than unrestricted Germany-US-Sweden routing.

### 3.4 Concrete example

A coding agent begins in region A and accumulates a 20k-token context. Region A retains its KV cache while the agent invokes a repository search tool. During the 15-second tool call:

- region A's forecast marginal emissions rise;
- cleaner region B has spare capacity;
- region A still owns a large reusable prefix;
- moving to B would force destination-side prefill of nearly the full history.

A request-independent carbon router chooses B. A permanently sticky router chooses A. CarbonAffinity estimates the actual incremental energy and latency of both choices and migrates only if the cleaner grid advantage is large enough to pay for losing state.

Later, after a five-minute tool call, region A has already evicted the KV cache. The affinity value is now near zero, so CarbonAffinity can rehome the next turn to B without paying the earlier state-loss penalty. This change of decision within one trajectory is the central behavior the paper seeks to enable.

## 4. Why current research is insufficient

### 4.1 GAR optimizes model selection, not persistent serving state

GAR minimizes estimated per-request carbon by selecting among heterogeneous models under quality and latency constraints. Its evaluation and reviews expose several weaknesses CarbonAffinity must avoid: ambiguous p95 reporting, weak baselines, missing theory, predictor opacity, use of benchmark queries rather than serving traces, and insufficiently grounded energy accounting. More fundamentally, GAR treats each query as a routing item and does not model session-local KV state. Source: [GAR](https://arxiv.org/abs/2605.11603).

CarbonAffinity instead fixes the model and decoding policy across regions. It therefore preserves quality by construction and isolates the systems effect of placement and state reuse.

### 4.2 Live clean-grid routing establishes feasibility but leaves our core gap open

The August 2026 paper *Routing LLM Inference to the Cleanest Grid in Real Time* is the strongest direct baseline. It demonstrates live two-region routing driven by WattTime MOER and performs ex-post settlement using historical MOER. It also explicitly identifies the missing problem CarbonAffinity targets:

- its live workload is synthetic;
- multi-turn sessions are represented through coarse origin pinning;
- prefix-cache locality is not modeled;
- cross-region dispatch is acknowledged to force cache misses, full prefill, extra TTFT, and extra energy;
- cross-region latency, networking, per-region energy heterogeneity, and sensitivity to session pinning are left for future work.

Source: [Routing LLM Inference to the Cleanest Grid in Real Time](https://arxiv.org/abs/2608.06188).

CarbonAffinity should present itself as answering this explicit open systems question, not as the first carbon-aware LLM router.

### 4.3 CEDAR is agent-aware at the queue level, not cache-state aware

CEDAR routes mixed-criticality agentic requests using backlog, waiting-time percentiles, SLO slack, cost, and marginal carbon. Its published evaluation is trace driven, but its public description does not expose a per-session model of KV residency, state-loss energy, or dynamic affinity. It is therefore a required baseline, but not the same problem. Source: [CEDAR](https://eprints.whiterose.ac.uk/id/eprint/239602/).

### 4.4 Cache-aware systems do not optimize carbon

Continuum, CachedAttention, DualMap, and related KV-aware serving systems optimize latency, throughput, or cost. They do not decide whether a time-varying marginal-emissions advantage is large enough to justify breaking affinity. CarbonAffinity connects these two previously separate control layers.

## 5. Research questions and falsifiable hypotheses

### Research questions

- **RQ1:** How much additional energy and TTFT does cross-region state loss cause as context length, cache tier, concurrency, and tool gap vary?
- **RQ2:** Under what carbon-intensity difference is migration genuinely lower-carbon after including re-prefill and routing overhead?
- **RQ3:** Can a dynamic affinity policy reduce settled trajectory-level carbon versus both carbon-greedy routing and static session pinning without violating TTFT, TPOT, or agent JCT SLOs?
- **RQ4:** How sensitive are decisions to tool-duration prediction, carbon forecast error, queue bursts, and cache eviction?
- **RQ5:** Do savings remain under real multi-turn traces and live multi-region execution, rather than only perfect-foresight replay?

### Hypotheses

- **H1:** Per-turn cleanest-region routing sometimes emits more operational carbon than session pinning because destination re-prefill energy exceeds the grid advantage.
- **H2:** Static session pinning is unnecessarily conservative after long tool gaps or cache eviction and therefore leaves measurable carbon savings unused.
- **H3:** A state-aware policy dominates both baselines on the carbon-SLO Pareto frontier.
- **H4:** Most useful rehoming decisions occur at state discontinuities: cache eviction, long tool gaps, large MOER changes, or severe queue pressure.
- **H5:** When carbon differences are small or uncertainty is high, the correct policy is to preserve affinity or fall back to the production pressure router. CarbonAffinity should not force migrations merely to appear active.

## 6. System state and decision variables

For session (s), turn (k), candidate region (r), and decision time (t), CarbonAffinity observes:

### Session state

- current and previous serving regions;
- input length and expected output length;
- cached prefix tokens (b_{s,k,r}) available at each candidate replica;
- cache tier and age;
- current turn number and estimated remaining turns;
- tool type and inter-turn gap distribution;
- session deadline or remaining JCT slack.

### Serving state

- queue length, active sequences, and prefix-cache pressure per replica;
- estimated TTFT and TPOT under the candidate placement;
- measured prefill/decode energy curves by context length and concurrency;
- HBM availability and the memory opportunity price of retaining state.

### Grid and network state

- forecast absolute MOER for dispatch;
- later historical MOER for settlement;
- signal age and forecast uncertainty;
- user-to-region RTT and region-to-region transfer characteristics;
- missing or stale signal indicators.

### Policy state

- data-residency and tenant allowlists;
- per-region capacity limits;
- SLOs and fallback policy.

### Primary control variables

\[
r_{s,k} \in \mathcal R_s
\]

selects the region for the next turn, and

\[
\tau_{s,k} \ge 0
\]

selects the bounded KV-cache lease retained after the current turn.

The first paper will not make active WAN KV transfer a required control. A migration is implemented as destination-side prefix recomputation, exactly the cost that naive carbon routers ignore. Cross-region KV transfer can be evaluated as an optional extension only if the serving stack exposes a reliable implementation.

## 7. Cost and optimization model

### 7.1 Incremental execution energy

For a candidate region (r), estimate:

\[
\widehat E_{s,k,r} =
\widehat E^{\mathrm{prefill}}_r(L_{s,k}-b_{s,k,r}, q_r)
+ \widehat E^{\mathrm{decode}}_r(O_{s,k}, q_r)
+ \widehat E^{\mathrm{router}}_{s,k,r}
+ \widehat E^{\mathrm{network}}_{s,k,r}.
\]

The important term is (L_{s,k}-b_{s,k,r}): the number of tokens that must actually be prefetched or recomputed after accounting for state already resident at the candidate.

Primary claims should use measured GPU-attributable energy. Network, host, PUE, and cooling terms should be reported separately or as sensitivity intervals unless whole-system metering is available.

### 7.2 Settled operational carbon

The routing decision uses forecast MOER, but reported carbon must be settled against the historical MOER for the actual execution interval:

\[
C^{\mathrm{GPU}}_{s,k,r}
= \widehat E^{\mathrm{GPU}}_{s,k,r}
\cdot \mathrm{MOER}^{\mathrm{historical}}_r(t_{\mathrm{execute}}).
\]

This is an estimate of consequential operational emissions, not direct measurement of physical CO2. The paper must state this explicitly. WattTime's methodology is appropriate for estimating the emissions change caused by changing electricity use; Electricity Maps' average, location-based signal is useful as a secondary footprint metric, not as the sole avoided-emissions metric.

Sources: [WattTime methodology](https://watttime.org/data-science/methodology-validation/), [Electricity Maps methodology](https://www.electricitymaps.com/data/methodology).

### 7.3 Cache-retention opportunity cost

Retaining KV state does not have a clean direct "joules per cached byte" interpretation. Its main cost is occupying scarce memory, increasing eviction or queueing pressure for other sessions. We therefore model it through a measured memory shadow price:

\[
C^{\mathrm{lease}}_{s,k,r}
= \pi^M_r(t) \cdot \mathrm{KVBytes}_{s,k} \cdot \tau_{s,k},
\]

where \(\pi^M_r(t)\) is learned from how marginal HBM occupation changes queueing, admission, and additional prefill work. The paper must not pretend this is directly metered carbon.

### 7.4 Primary objective

Over completed trajectories:

\[
\min_{r,\tau}
\sum_s \sum_k
\left(
C^{\mathrm{GPU}}_{s,k,r_{s,k}}
+ C^{\mathrm{network}}_{s,k,r_{s,k}}
+ C^{\mathrm{lease}}_{s,k,r_{s,k}}
\right).
\]

Subject to:

- zero residency or tenant-policy violations;
- p95 TTFT and TPOT targets per request class;
- p95 trajectory JCT or deadline target for agentic workloads;
- replica capacity and HBM constraints;
- queue stability;
- no change in model weights, quantization, prompt, output limit, or decoding configuration across routing policies.

Quality is not included as a learned constraint because the same model and decoding policy runs everywhere. This removes GAR's fragile pre-route quality predictor from the problem.

## 8. Proposed algorithm: carbon-aware affinity leases

CarbonAffinity uses a small rolling-horizon controller rather than an unproven primal-dual claim or a black-box reinforcement-learning policy.

### Step 1: Filter candidates

Remove regions that fail residency, model availability, signal freshness, hard capacity, or worst-case latency checks. If no remote candidate remains, preserve the existing route.

### Step 2: Estimate state-aware immediate cost

For each eligible region, estimate:

- effective prefix hit and re-prefill tokens;
- incremental prefill/decode energy;
- queue-aware TTFT/TPOT;
- forecast dispatch carbon;
- network and router overhead.

### Step 3: Estimate the option value of affinity

Using tool-type history and current trajectory progress, estimate the probability that the session returns within lease \(\tau\). The value of retaining cache is:

\[
V^{\mathrm{aff}}_{s,k,r}(\tau)
= P(T^{\mathrm{return}}_{s,k}\le\tau)
\cdot \left(
\text{avoided prefill carbon}
+ \lambda_L \text{avoided TTFT/JCT}
\right)
- C^{\mathrm{lease}}_{s,k,r}(\tau).
\]

Choose a bounded lease that maximizes this value. Very long or failed tool calls therefore do not pin HBM indefinitely.

### Step 4: Apply a migration break-even rule

Let (r_0) be the region holding the best reusable state and (r_1) a cleaner candidate. Rehome only when:

\[
\underbrace{\widehat C_{s,k,r_0}-\widehat C_{s,k,r_1}}_{\text{forecast carbon benefit}}
>
\underbrace{C^{\mathrm{state-loss}}_{s,k,r_1}}_{\text{re-prefill and cache miss}}
+ \underbrace{C^{\mathrm{network}}_{s,k,r_1}}_{\text{transfer}}
+ \underbrace{M^{\mathrm{risk}}_{s,k}}_{\text{forecast/SLO margin}}.
\]

This threshold gives the system interpretable hysteresis and prevents region thrashing.

### Step 5: Fail safely

If carbon data is stale, predictors are out of distribution, or the SLO guard is infeasible, disable the carbon overlay for that decision and revert to the production cache/load-aware router. Missing carbon data must never be interpreted as zero carbon.

### Algorithmic claims

The paper should initially claim:

- an interpretable state-aware objective;
- a practical online approximation with bounded cache leases and migration hysteresis;
- empirical robustness under forecast and tool-gap error.

It should not claim sublinear regret, competitive ratios, or formal probabilistic SLO guarantees unless a correct theorem with assumptions and proof is completed. This directly avoids one of GAR's central review failures.

## 9. End-to-end system flow

1. A request reaches a geo-routing gateway with `session_id`, tenant policy, prompt metadata, and SLO class.
2. The policy filter constructs the legal candidate set.
3. A session-state directory reports which replicas retain matching prefix state, how many tokens are reusable, the cache tier, and state age.
4. Regional agents report live queue, capacity, cache pressure, and telemetry-derived energy features.
5. The carbon service reports forecast absolute MOER plus timestamp and uncertainty for each eligible grid region.
6. CarbonAffinity scores stay/rehome actions and applies the SLO guard and migration threshold.
7. The gateway dispatches the turn and records the complete decision context.
8. vLLM executes the request; telemetry records power, tokens, timing, and cache behavior.
9. After the turn, CarbonAffinity grants or declines a bounded cache lease based on the predicted return distribution and memory pressure.
10. After historical MOER becomes available, a settlement process recomputes carbon for the actual place and time of execution.
11. An audit log preserves forecast-vs-settled MOER, policy eligibility, predicted-vs-realized cache hit, energy, TTFT, TPOT, and migration outcome.

## 10. System architecture and implementation scope

### Components

- **Geo Gateway:** OpenAI-compatible proxy with stable session IDs.
- **Policy Filter:** residency, tenant, and region eligibility.
- **Affinity Directory:** session-to-replica prefix residency and lease metadata.
- **Regional Sidecar:** queue, vLLM metrics, cache pressure, and NVML/DCGM telemetry.
- **Carbon Signal Service:** forecast polling, freshness checks, historical settlement, and local archival.
- **Decision Engine:** candidate scoring, lease selection, SLO guard, and hysteresis.
- **Replay Driver:** MLPerf/TraceLab-compatible closed-loop multi-turn replay.
- **Auditor:** per-trajectory carbon, latency, energy, and policy accounting.

### Serving stack

Recommended primary configuration:

- identical Qwen3.5-9B replicas;
- identical weights, tokenizer, quantization, decoding parameters, and maximum context;
- vLLM-compatible endpoints with prefix caching enabled;
- one region/replica may be represented by more than one GPU only for scale experiments, not by a different model.

Qwen3.5-9B is large enough to exercise long-context KV behavior but small enough to host on a single modern 32 GB GPU in live multi-region tests. A second model size can be added later as a generality check, but it is not required to establish the core phenomenon.

### Required instrumentation

- 50-100 ms GPU power sampling where supported;
- request start, first-token, every-token or aggregate decode timing;
- input/output tokens and actual prefix-cache hit tokens;
- queue and active-sequence state at dispatch;
- cache insert, lease, hit, eviction, and expiry events;
- region, forecast MOER, historical MOER, and signal version;
- tool start/end and inter-turn delay;
- router decision time and fallback reason.

## 11. Evaluation methodology

### 11.1 Workloads

Primary workloads:

1. **MLPerf Agentic Inference:** reproducible closed-loop agent trajectories, stable session IDs, inter-turn delays, and conversation-aware routing semantics.
2. **TraceLab coding-agent traces:** real session hierarchy, tool calls, and temporal behavior.

Secondary control:

3. **ShareGPT or another public multi-turn chat trace:** distinguishes human-paced chat from fast tool-driven agents.
4. **Single-turn trace:** demonstrates that CarbonAffinity reduces to an ordinary carbon/load-aware router when no persistent state exists.

Purely random synthetic prompts may be used for controlled microbenchmarks but not as the primary end-to-end workload.

### 11.2 Carbon data

- Dispatch with timestamped forecast absolute MOER.
- Settle with historical MOER at the execution interval.
- Preserve the exact API/model version and missing-data policy.
- Use average location-based carbon intensity only as a secondary footprint metric.
- Run year-long historical replay with block bootstrap to capture diurnal, weekly, and seasonal autocorrelation.

### 11.3 Hardware evidence

The preferred evidence stack is:

1. **Controlled state-loss microbenchmarks:** one multi-GPU server, repeatedly compare same-replica cache hits with different-replica cache misses.
2. **Scale test:** 8x A800 or equivalent, stressing cache pressure, concurrent sessions, and queue interactions.
3. **Live multi-region validation:** two or three physically distinct but policy-compatible regions, one identical GPU/model replica per region, synchronized carbon signals, actual WAN RTT, and real request execution.
4. **Historical replay:** more grid regions and a full year to estimate seasonal opportunity, clearly labeled as replay rather than live deployment.

The live test establishes mechanism feasibility; the replay estimates magnitude. The paper must not present replayed savings as directly measured emissions reduction.

### 11.4 Baselines

- **Pressure-only / production load balancer:** carbon blind, queue and capacity aware.
- **Round robin:** simple reference, not the only baseline.
- **Carbon-greedy per turn:** route every turn to the lowest forecast-MOER eligible region.
- **Carbon-at-session-start + permanent pinning:** choose a clean initial region and keep the whole session there.
- **Load-aware sticky sessions:** preserve affinity unless the home replica is overloaded.
- **Cache-affinity router:** prefix/session aware but carbon blind, following DualMap-like principles.
- **CEDAR-style queue/carbon routing:** mixed-criticality carbon baseline without explicit cache-state valuation.
- **Clean-grid live router:** reproduce the latest pressure-plus-carbon overlay and its coarse pinning variants.
- **Oracle:** knows future tool gaps, cache evictions, historical MOER, and queue evolution.

### 11.5 CarbonAffinity ablations

- no cache-residency feature;
- no tool-gap prediction;
- fixed TTL instead of adaptive lease;
- no queue state;
- no migration hysteresis;
- forecast-only reporting instead of historical settlement, shown only to quantify accounting bias;
- average CI instead of MOER, shown as a signal-choice sensitivity, not the primary result.

### 11.6 Metrics

Primary:

- settled GPU-attributable gCO2e per completed trajectory;
- total settled GPU-attributable operational emissions;
- p95/p99 TTFT;
- p95/p99 TPOT;
- p95/p99 agent job-completion time;
- SLO violation and trajectory completion rates;
- zero policy violations.

Mechanism:

- effective cached-prefix tokens and hit ratio;
- re-prefill tokens, joules, and carbon;
- migration rate and migration reversals;
- cache lease hit, early-expiry, and wasted-retention rates;
- queue time, router overhead, and fallback frequency;
- forecast-vs-settled carbon error;
- WAN bytes and latency.

Secondary:

- throughput/goodput;
- GPU energy per completed trajectory;
- memory occupancy and cache eviction pressure;
- operational cost and egress cost;
- PUE/network/host-carbon sensitivity interval;
- fairness across short and long sessions.

### 11.7 Statistical design

- Replay every policy against identical session arrivals and token traces.
- Use paired seeds and identical carbon time windows.
- For live A/B, randomize by complete session, never by individual turn, to avoid contaminating affinity state across arms.
- Isolate policy arms on distinct replicas where possible; otherwise explicitly disclose treatment interference.
- Report block-bootstrap confidence intervals over time blocks, not IID request bootstrap alone.
- Report individual workload classes and session-length buckets rather than only aggregate means.

## 12. Experimental questions mapped to figures

### Figure 1: Motivation

One trajectory showing carbon-greedy migration, cache loss, extra prefill energy, and TTFT versus a state-aware decision.

### Figure 2: Break-even surface

Required MOER difference for beneficial migration as a function of context length, cached-prefix fraction, queue state, and tool gap.

### Figure 3: Carbon-SLO Pareto frontier

Settled carbon versus p95 TTFT/JCT for all baselines and CarbonAffinity.

### Figure 4: Where savings come from

Decompose savings into initial placement, dynamic rehoming after cache expiry, avoided bad migrations, and load-aware fallback.

### Figure 5: Robustness

Carbon and SLO performance under carbon-forecast error, tool-duration error, burst load, and cache pressure.

### Figure 6: Live multi-region timeline

Forecast MOER, settled MOER, regional request share, cache-hit rate, queue depth, and migrations over the live run.

### Table 1: Workloads and systems

Models, GPUs, traces, sessions, turns, context/output lengths, tool gaps, and regions.

### Table 2: Main result

Trajectory-level carbon, energy, TTFT, TPOT, JCT, completion, and policy compliance.

### Table 3: Overhead and accounting boundary

Router CPU time, telemetry, network bytes, forecast error, GPU-only result, and end-to-end sensitivity.

## 13. Go/no-go gates before full implementation

### Gate A: Does state loss matter energetically?

Run second-turn cache-hit versus cache-miss microbenchmarks at 2k, 8k, 16k, and 32k context lengths. Measure TTFT and joules. Continue only if state loss creates a clear, repeatable penalty.

### Gate B: Is there a non-trivial routing conflict?

Combine the measured penalty with real MOER differences. Verify both regimes exist:

- some cases where migration reduces settled carbon;
- some cases where carbon-greedy migration increases settled carbon.

If one action always wins, a dynamic router is unnecessary.

### Gate C: Do real agent traces create decision opportunities?

Replay TraceLab/MLPerf timing and measure how often a session returns with valid state, expired state, or changed carbon ranking. The opportunity frequency must be material.

### Gate D: Can the policy improve a strong baseline?

CarbonAffinity must beat both permanent pinning and carbon-greedy routing while meeting predeclared SLOs. Merely beating round robin is insufficient.

These gates should be completed before building a large campaign. They prevent several days of GPU work from being spent on an unverified premise.

## 14. Scope boundaries

### Included

- identical-model geo-replica selection;
- multi-turn and agentic trajectories;
- prefix/KV cache residency and bounded retention;
- queue/load state;
- forecast-MOER dispatch and historical settlement;
- residency and latency constraints;
- real trace replay and live multi-region validation.

### Explicitly excluded from the first paper

- routing among different model sizes or quality levels;
- truncating output, changing quantization, or degrading answer quality;
- arbitrary cross-jurisdiction routing;
- provisioning new regions solely for carbon;
- joint battery, renewable, cooling, and power-cap optimization;
- claiming directly measured CO2;
- requiring cross-region KV transfer;
- broad multi-objective RL without interpretability;
- formal guarantees without complete proofs.

## 15. Expected contributions

### Conceptual contribution

Identify and quantify **carbon affinity**: the time-varying carbon value of executing a returning LLM turn where its reusable serving state already resides.

### Algorithmic contribution

Develop a state-aware online routing policy with bounded cache leases and a carbon break-even migration rule that incorporates re-prefill, queue, network, and forecast risk.

### Systems contribution

Implement an OpenAI-compatible multi-region router and vLLM-side instrumentation that tracks session state, cache reuse, queue pressure, telemetry energy, and forecast-to-historical carbon settlement.

### Empirical contribution

Provide the first planned study specifically measuring when carbon-aware cross-region routing and KV-cache affinity reinforce or contradict each other under real multi-turn and agentic traces.

The word "first" must be re-audited immediately before submission because this area is moving quickly.

## 16. Reviewer questions the paper must answer in advance

### Why would an operator have the same model in several regions?

For latency, availability, capacity, disaster recovery, and data-residency service areas. CarbonAffinity exploits existing eligible replicas; it does not justify creating idle replicas purely for carbon.

### Why not pin every session permanently?

Because grid rankings, load, and cache validity change during long user/tool gaps. Once state is evicted, permanent pinning preserves no cache benefit but still forfeits cleaner placement.

### Why not always choose the cleanest region?

Because a lower MOER can be outweighed by full-prefix recomputation, WAN delay, and queueing. CarbonAffinity measures this break-even rather than assuming migration is free.

### Is CO2 directly measured?

No. GPU energy is measured; consequential operational emissions are estimated using time- and location-matched marginal emissions. Forecast values drive dispatch and historical values settle results.

### What about PUE, cooling, CPU, and network energy?

The primary claim is GPU-attributable operational carbon unless whole-system power is available. Other terms are measured where possible and otherwise reported through transparent sensitivity bounds.

### What about data sovereignty?

The eligible region set is a hard precondition. A lower-carbon prohibited region is never considered.

### Does routing alter model quality?

No. All regions run the same model, weights, tokenizer, quantization, prompt, and decoding configuration. The paper isolates system placement.

### Are predictor overheads counted?

Yes. Router CPU time and energy are logged, and predictor training/inference cost is reported. The policy should use simple calibrated models rather than an opaque, expensive router.

### Why is this not just CEDAR or the clean-grid router plus a cache flag?

Because the control unit is a trajectory with persistent and expiring state. CarbonAffinity jointly values state retention and future rehoming, uses actual reusable-prefix size in energy prediction, and optimizes trajectory SLOs. The evaluation must prove that these features change decisions and outcomes beyond a binary sticky-session heuristic.

## 17. Initial execution plan

### Phase 1: novelty and phenomenon validation

- Reproduce the cache-hit/cache-miss energy and TTFT gap.
- Audit the full methods of the August 2026 clean-grid paper, CEDAR, Continuum, DualMap, and TraceLab.
- Finalize workload and carbon-data licenses.
- Produce the break-even figure before implementing the full router.

### Phase 2: minimum viable system

- Geo gateway and policy filter.
- Session-state directory.
- vLLM cache/queue instrumentation.
- Telemetry-calibrated prefill/decode energy estimator.
- Historical settlement pipeline.
- Sticky, carbon-greedy, and state-aware policies.

### Phase 3: single-cluster hardware-in-the-loop campaign

- Use multiple replicas as logical regions.
- Replay real session timing.
- Inject recorded regional MOER and measured WAN delay.
- Establish correctness, mechanism, and scale.

### Phase 4: live multi-region validation

- Deploy identical replicas in two or three policy-compatible physical regions.
- Run session-randomized A/B for at least 24-48 hours if budget permits.
- Use forecast MOER for decisions and historical MOER for settlement.
- Treat this as feasibility evidence, not a universal percentage claim.

### Phase 5: seasonal replay and paper

- Replay one year of MOER with the hardware-calibrated model.
- Run forecast-error and carbon-signal sensitivity.
- Generate figures automatically from immutable result manifests.
- Write the paper around the measured break-even phenomenon, not around a predetermined positive percentage.

## 18. Recommended venue positioning

Primary positioning: systems for emerging AI workloads, with sustainability as the motivating resource dimension.

Potential targets:

- EuroSys or ASPLOS if the implementation and live evaluation are strong;
- SoCC if the contribution is primarily geo-cloud routing and operations;
- ACM e-Energy if the carbon/grid methodology is stronger than the serving-system implementation;
- a workshop only as a fallback, not the initial target.

The paper should be written as a systems paper: production scenario, measured mechanism, implementable policy, strong baselines, real traces, explicit accounting boundary, and live validation.

## 19. Novelty audit as of 2026-08-17

| Work | Carbon-aware | Multi-turn/agent-aware | KV/cache state in routing | Live multi-region | Main gap left for CarbonAffinity |
|---|---:|---:|---:|---:|---|
| GAR | Yes | No | No | No | Persistent state, real traces, grounded telemetry |
| CEDAR | Yes | Yes | Not explicit in public description | Trace-driven | Per-session KV residency and state-loss carbon |
| Cleanest Grid in Real Time | Yes | Coarse session pinning | Explicitly not modeled | Yes | Prefix invalidation, re-prefill energy, latency, dynamic affinity |
| Continuum | No | Yes | Yes | No geo-carbon routing | Carbon-aware rehoming |
| DualMap | No | Limited | Yes | No geo-carbon routing | Time-varying carbon and tool-gap state |
| CarbonAffinity | Yes | Yes | Primary state variable | Planned | Joint state-carbon routing at turn boundaries |

This table is the core intellectual justification. The project should be stopped or substantially revised if a new paper already implements dynamic MOER-aware routing using per-replica KV residency, adaptive retention, and real agent traces.

## 20. Immediate next action

Do not begin with the full geo-router. Begin with a compact motivation experiment:

1. serve the first turn of a long-context conversation on replica A;
2. issue the second turn once to A with cache reuse and once to replica B with a cache miss;
3. sweep context length and inter-turn delay;
4. measure incremental joules, TTFT, and effective cached tokens;
5. combine those measurements with real MOER differences to plot the migration break-even boundary.

If this figure is strong, it becomes Figure 1 or Figure 2 of the eventual paper and justifies the entire CarbonAffinity design. If it is weak, the idea should be revised before spending substantial multi-region GPU budget.

## 21. Key references

- [IEA, Energy and AI](https://www.iea.org/reports/energy-and-ai/)
- [MLCommons, Agentic Inference for MLPerf](https://mlcommons.org/2026/07/agentic-inference-for-mlperf-inference/)
- [TraceLab: Characterizing Coding Agent Workloads for LLM Serving](https://arxiv.org/abs/2606.30560)
- [Routing LLM Inference to the Cleanest Grid in Real Time](https://arxiv.org/abs/2608.06188)
- [GAR: Carbon-Aware Routing for LLM Inference via Constrained Optimization](https://arxiv.org/abs/2605.11603)
- [CEDAR: Carbon Efficient Dynamic Allocation and Routing for Agentic LLM Inference](https://eprints.whiterose.ac.uk/id/eprint/239602/)
- [Continuum: Efficient and Robust Multi-Turn LLM Agent Scheduling with KV Cache Time-to-Live](https://arxiv.org/abs/2511.02230)
- [CachedAttention: Cost-Efficient LLM Serving for Multi-turn Conversations](https://arxiv.org/abs/2403.19708)
- [DualMap: Cache Affinity and Load Balancing for Distributed LLM Serving](https://arxiv.org/abs/2602.06502)
- [KVCache Cache in the Wild, USENIX ATC 2025](https://www.usenix.org/conference/atc25/presentation/wang-jiahao)
- [WattTime methodology and validation](https://watttime.org/data-science/methodology-validation/)
- [Electricity Maps methodology](https://www.electricitymaps.com/data/methodology)
- [Microsoft: Saving CO2 Using Location and Time Shifting in Azure](https://devblogs.microsoft.com/ise/saving-co2-using-location-and-time-shifting-in-azure/)
