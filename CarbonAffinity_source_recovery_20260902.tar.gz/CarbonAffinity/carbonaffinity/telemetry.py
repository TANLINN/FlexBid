from __future__ import annotations

import argparse
import csv
import json
import signal
import time
from datetime import datetime, timezone
from pathlib import Path

import pynvml

RUNNING = True


def _stop(_signum, _frame) -> None:
    global RUNNING
    RUNNING = False


def _safe(call):
    try:
        return call()
    except (pynvml.NVMLError, AttributeError):
        return None


def sample(output: Path, gpu_index: int, region_id: str, interval_ms: int = 100) -> None:
    if interval_ms < 20:
        raise ValueError("interval_ms must be at least 20")
    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)
    output.parent.mkdir(parents=True, exist_ok=True)
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(gpu_index)
    metadata_path = output.with_suffix(".metadata.json")
    metadata = {
        "region_id": region_id,
        "gpu_index": gpu_index,
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "measurement_boundary": "one physical GPU module; host/cooling energy excluded",
        "interval_ms": interval_ms,
    }
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    fields = ["wall_time_ns", "elapsed_ms", "sample_interval_ms", "power_w", "power_limit_w", "total_energy_mj", "util_pct", "memory_used_mib", "temperature_c"]
    start = previous = time.perf_counter_ns()
    next_sample = start
    try:
        with output.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            while RUNNING:
                now = time.perf_counter_ns()
                if now < next_sample:
                    time.sleep((next_sample - now) / 1e9)
                    continue
                power = _safe(lambda: pynvml.nvmlDeviceGetPowerUsage(handle))
                cap = _safe(lambda: pynvml.nvmlDeviceGetEnforcedPowerLimit(handle))
                energy = _safe(lambda: pynvml.nvmlDeviceGetTotalEnergyConsumption(handle))
                util = _safe(lambda: pynvml.nvmlDeviceGetUtilizationRates(handle))
                memory = _safe(lambda: pynvml.nvmlDeviceGetMemoryInfo(handle))
                temperature = _safe(lambda: pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU))
                writer.writerow({
                    "wall_time_ns": time.time_ns(),
                    "elapsed_ms": (now - start) / 1e6,
                    "sample_interval_ms": (now - previous) / 1e6,
                    "power_w": None if power is None else power / 1000.0,
                    "power_limit_w": None if cap is None else cap / 1000.0,
                    "total_energy_mj": energy,
                    "util_pct": getattr(util, "gpu", None),
                    "memory_used_mib": None if memory is None else memory.used / 2**20,
                    "temperature_c": temperature,
                })
                stream.flush()
                previous = now
                next_sample += interval_ms * 1_000_000
    finally:
        pynvml.nvmlShutdown()
        metadata["completed_utc"] = datetime.now(timezone.utc).isoformat()
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--interval-ms", type=int, default=100)
    args = parser.parse_args()
    sample(args.output, args.gpu_index, args.region_id, args.interval_ms)


if __name__ == "__main__":
    main()

