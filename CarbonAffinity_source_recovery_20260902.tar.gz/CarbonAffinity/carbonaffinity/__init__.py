"""CarbonAffinity main-experiment artifact."""

__version__ = "0.1.0"

