from __future__ import annotations

from pathlib import Path

import httpx


class SiteControlClient:
    def __init__(self, base_url: str, token: str, timeout_s: float = 60.0):
        self.base_url = base_url.rstrip("/")
        self.client = httpx.AsyncClient(
            timeout=timeout_s,
            headers={"Authorization": f"Bearer {token}"},
        )

    async def close(self) -> None:
        await self.client.aclose()

    async def status(self) -> dict:
        response = await self.client.get(self.base_url + "/status")
        response.raise_for_status()
        return response.json()

    async def start_telemetry(self, run_id: str, interval_ms: int = 100) -> dict:
        response = await self.client.post(
            self.base_url + "/telemetry/start",
            json={"run_id": run_id, "interval_ms": interval_ms},
        )
        response.raise_for_status()
        return response.json()

    async def stop_telemetry(self) -> dict:
        response = await self.client.post(self.base_url + "/telemetry/stop", json={})
        response.raise_for_status()
        return response.json()

    async def download(self, run_id: str, destination: Path, metadata: bool = False) -> None:
        suffix = ".metadata.json" if metadata else ".csv"
        response = await self.client.get(f"{self.base_url}/telemetry/{run_id}{suffix}")
        response.raise_for_status()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(response.content)

