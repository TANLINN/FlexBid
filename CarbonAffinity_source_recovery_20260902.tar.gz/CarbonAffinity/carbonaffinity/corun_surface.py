"""Recovered co-run TTFT model (four observable workload coordinates).

Initial prompt/output reservations persist until the first token/completion.
Never derive admission features from future arrivals, realized output length,
or post-hoc remaining-work estimates. Pure-phase experiments do not validate
the additive mixed-phase hypothesis: mixed loads fail closed by default.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
from pathlib import Path

from .artifacts import finite_nonnegative, quantile


ANCHORS = {
    "own": [1024, 4096, 16384],
    "prefill": [0, 8192, 16384, 32768],
    "prefill_decode": [0, 8, 16, 192, 384, 448, 896],
    # Runtime uses the SUM across decoders. Include two-decoder anchors;
    # the lost v2 summary listed only single-decoder budgets.
    "active_decode": [0, 192, 384, 448, 896],
}


def key(*values):
    return "|".join(str(int(value)) for value in values)


def features(row):
    raw = row["admission_features"]
    return tuple(finite_nonnegative(raw[name]) for name in ANCHORS)


class CorunTTFTModel:
    def __init__(self, payload: dict, model_sha256=""):
        self.payload = payload
        self.model_sha256 = model_sha256
        self.anchors = payload["anchors"]
        for name in ANCHORS:
            values = self.anchors[name]
            if not values or values != sorted(set(values)):
                raise ValueError(f"invalid anchors: {name}")
            for value in values:
                finite_nonnegative(value)
        self.margin = finite_nonnegative(payload["uncertainty_margin_ms"])
        for name in ("base_ttft_ms", "prefill_phase_ttft_ms", "active_decode_phase_ttft_ms"):
            for value in payload[name].values():
                finite_nonnegative(value)

    @classmethod
    def from_json(cls, path):
        raw = Path(path).read_bytes()
        return cls(json.loads(raw), hashlib.sha256(raw).hexdigest())

    def predict(self, own, prefill=0, prefill_decode=0, active_decode=0):
        values = tuple(finite_nonnegative(v) for v in (own, prefill, prefill_decode, active_decode))
        ood = any(v > max(self.anchors[name]) for name, v in zip(ANCHORS, values))
        # No mixed-prefill-and-decode experiment was recovered; abstain.
        mixed = (prefill > 0 or prefill_decode > 0) and active_decode > 0
        ood |= mixed and not self.payload.get("mixed_phase_validated", False)
        selected = {name: next((a for a in self.anchors[name] if a >= v), self.anchors[name][-1])
                    for name, v in zip(ANCHORS, values)}
        o, p, d, a = (selected[name] for name in ANCHORS)
        base = self.payload["base_ttft_ms"][key(o)]
        pref_key = key(o, p, d)
        decode_key = key(o, a)
        if (prefill or prefill_decode) and not self.payload.get("prefill_support", {}).get(pref_key, False):
            ood = True
        if active_decode and not self.payload.get("active_decode_support", {}).get(decode_key, False):
            ood = True
        predicted = (base
                     + max(0, self.payload["prefill_phase_ttft_ms"][pref_key] - base)
                     + max(0, self.payload["active_decode_phase_ttft_ms"][decode_key] - base)
                     + self.margin)
        return {"conservative_ttft_ms": math.inf if ood else predicted,
                "out_of_domain": bool(ood), "mixed_phase": mixed,
                "anchors": selected, "model_sha256": self.model_sha256}


def fit_tables(rows, anchors=None):
    anchors = anchors or ANCHORS
    data = [(row, features(row), finite_nonnegative(row["victim"]["ttft_ms"])) for row in rows]
    base, pref, dec, pref_support, dec_support = {}, {}, {}, {}, {}
    for o in anchors["own"]:
        samples = [ttft for row, f, ttft in data if f[0] <= o and row["phase"] == "baseline"]
        if not samples:
            raise ValueError(f"missing baseline support for own={o}")
        base[key(o)] = max(samples)
        for p, d in itertools.product(anchors["prefill"], anchors["prefill_decode"]):
            values = [ttft for row, f, ttft in data if row["phase"] == "prefill_then_decode"
                      and f[0] <= o and f[1] <= p and f[2] <= d and f[3] == 0]
            cell_key = key(o, p, d)
            pref[cell_key] = max([base[key(o)]] + values)
            pref_support[cell_key] = bool(values) or (p == 0 and d == 0)
        for a in anchors["active_decode"]:
            values = [ttft for row, f, ttft in data if row["phase"] == "active_decode"
                      and f[0] <= o and f[3] <= a and f[1] == 0 and f[2] == 0]
            dec[key(o, a)] = max([base[key(o)]] + values)
            dec_support[key(o, a)] = bool(values) or a == 0
    return {"schema_version": 3, "model_type": "corun_monotone_upper_envelope",
            "status": "CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION", "candidate_frozen": False,
            "runtime_mode": "chunked_prefill_cap_784", "runtime_cap": 784,
            "anchors": anchors, "uncertainty_margin_ms": 0,
            "base_ttft_ms": base, "prefill_phase_ttft_ms": pref, "active_decode_phase_ttft_ms": dec,
            "prefill_support": pref_support, "active_decode_support": dec_support,
            "mixed_phase_validated": False, "future_trace_access": False,
            "reconstruction_note": "reconstructed implementation; not byte-identical to lost v2 candidate"}


def evaluate(model, rows, slo_ms=16000):
    groups = {}
    for row in rows:
        prediction = model.predict(*features(row))
        actual = finite_nonnegative(row["victim"]["ttft_ms"])
        bound = prediction["conservative_ttft_ms"]
        entry = (actual, bound, prediction["out_of_domain"])
        for name in ("overall", "phase:" + row["phase"], "victim:" + row["victim_mode"], "gpu:" + str(row["gpu_index"])):
            groups.setdefault(name, []).append(entry)
    summary = {}
    for name, entries in groups.items():
        finite_ratios = [actual / bound for actual, bound, ood in entries if not ood and bound > 0]
        summary[name] = {
            "samples": len(entries),
            "coverage": sum(not ood and actual <= bound for actual, bound, ood in entries) / len(entries),
            "actual_violations": sum(actual > slo_ms for actual, _, _ in entries),
            "predicted_infeasible": sum(bound > slo_ms for _, bound, _ in entries),
            "false_negatives": sum(actual > slo_ms >= bound for actual, bound, _ in entries),
            "false_positives": sum(actual <= slo_ms < bound for actual, bound, _ in entries),
            "out_of_domain": sum(ood for _, _, ood in entries),
            "actual_over_prediction_q95": quantile(finite_ratios, .95) if finite_ratios else None,
        }
    return summary


def fit_with_loo(rows):
    if any(row.get("failures", 0) or not row["victim"]["success"] for row in rows):
        raise ValueError("failed requests cannot be silently dropped from fitting")
    gpus = sorted({int(row["gpu_index"]) for row in rows})
    if len(gpus) < 2:
        raise ValueError("leave-one-GPU-out needs at least two GPUs")
    folds = []
    for gpu in gpus:
        train = [row for row in rows if row["gpu_index"] != gpu]
        test = [row for row in rows if row["gpu_index"] == gpu]
        model = CorunTTFTModel(fit_tables(train))
        predictions = [model.predict(*features(row)) for row in test]
        if any(row["out_of_domain"] for row in predictions):
            raise ValueError("development matrix does not support every held-out case")
        residuals = [max(0, row["victim"]["ttft_ms"] - pred["conservative_ttft_ms"])
                     for row, pred in zip(test, predictions)]
        folds.append({"heldout_gpu": gpu, "samples": len(test), "positive_residual_max_ms": max(residuals)})
    payload = fit_tables(rows)
    payload["uncertainty_margin_ms"] = max(100, math.ceil(max(row["positive_residual_max_ms"] for row in folds) + 5))
    payload["loo_folds"] = folds
    payload["training_rows"] = len(rows)
    payload["development_evaluation"] = evaluate(CorunTTFTModel(payload), rows)
    return payload
