from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any


MODEL_KIND = "observable_corun_stratified_monotone_candidate_v1"
METRICS = ("ttft_ms", "tpot_ms")


def _integer(value: Any, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise ValueError("nonnegative integer reservation required")
    return value


def _key(coordinate: tuple[int, ...]) -> str:
    return "|".join(map(str, coordinate))


def _coordinates(query: dict[str, Any]) -> tuple[str, tuple[int, ...]]:
    prompt = _integer(query["prompt_tokens"], 1)
    cached = _integer(query["cached_reservation"])
    output = _integer(query["output_budget"], 1)
    if cached >= prompt or output != 64 or query.get("runtime_cap") != 784:
        raise ValueError("unsupported own context/output/runtime")

    mode = "warm" if cached else "cold"
    if not cached and query.get("cold_namespace_isolated") is not True:
        raise ValueError("cold namespace is not known to be isolated")
    coordinate = [cached, prompt - cached] if cached else [prompt]
    phases: dict[str, list[tuple[int, ...]]] = {
        "prefill": [],
        "decode": [],
    }
    for background in query.get("backgrounds", []):
        phase = background.get("phase")
        if phase not in phases:
            raise ValueError("unsupported background phase")
        bg_prompt = _integer(background["prompt_tokens"], 1)
        bg_cached = _integer(background["cached_reservation"])
        bg_output = _integer(background["output_budget"], 1)
        outstanding = _integer(background["prefill_reservation"])
        if phase == "decode":
            if (bg_prompt, bg_cached, outstanding) != (16064, 15680, 0):
                raise ValueError("decode background is outside the validated protocol")
            phases["decode"].append((bg_output,))
        else:
            if (
                bg_cached != 0
                or outstanding != bg_prompt
                or background.get("cold_namespace_isolated") is not True
            ):
                raise ValueError("prefill background is outside the validated protocol")
            phases["prefill"].append((outstanding, bg_output))

    prefill_count = len(phases["prefill"])
    decode_count = len(phases["decode"])
    if (prefill_count, decode_count) not in {
        (0, 0),
        (1, 0),
        (2, 0),
        (0, 1),
        (0, 2),
        (1, 1),
    }:
        raise ValueError("unsupported background phase counts")
    for label in ("prefill", "decode"):
        items = phases[label]
        if len(set(items)) > 1:
            raise ValueError("heterogeneous same-phase backgrounds are unsupported")
        if items:
            coordinate.extend(items[0])
    return (
        f"{mode}|prefill{prefill_count}|decode{decode_count}",
        tuple(coordinate),
    )


class ObservableCorunModel:
    """Validated-domain admission model for exact observable co-run strata."""

    def __init__(self, payload: dict[str, Any], model_sha256: str) -> None:
        if payload.get("model_kind") != MODEL_KIND:
            raise ValueError("wrong observable co-run model kind")
        surfaces = payload.get("surfaces")
        margins = payload.get("margin_ms")
        if not isinstance(surfaces, dict) or not surfaces:
            raise ValueError("observable co-run model has no surfaces")
        if not isinstance(margins, dict):
            raise ValueError("observable co-run model has no margins")
        for stratum, surface in surfaces.items():
            axes = surface.get("axes")
            cells = surface.get("cells")
            if not isinstance(axes, list) or not axes or not isinstance(cells, dict):
                raise ValueError(f"malformed observable co-run surface: {stratum}")
            if any(
                not isinstance(axis, list)
                or not axis
                or axis != sorted(set(axis))
                or any(type(value) is not int for value in axis)
                for axis in axes
            ):
                raise ValueError(f"malformed observable co-run axes: {stratum}")
            for cell in cells.values():
                upper = cell.get("upper_ms") if isinstance(cell, dict) else None
                if not isinstance(upper, dict) or any(
                    type(upper.get(metric)) not in (int, float)
                    or not math.isfinite(float(upper[metric]))
                    or float(upper[metric]) <= 0
                    for metric in METRICS
                ):
                    raise ValueError(f"malformed observable co-run cell: {stratum}")
        self.payload = payload
        self.model_sha256 = model_sha256

    @classmethod
    def from_json(cls, path: str | Path) -> "ObservableCorunModel":
        raw = Path(path).read_bytes()
        return cls(json.loads(raw), hashlib.sha256(raw).hexdigest())

    def predict_query(self, query: dict[str, Any]) -> dict[str, Any]:
        try:
            stratum, coordinate = _coordinates(query)
            surface = self.payload["surfaces"].get(stratum)
            if surface is None:
                raise ValueError("unsupported workload stratum")
            axes = surface["axes"]
            if len(coordinate) != len(axes) or any(
                value < anchors[0] or value > anchors[-1]
                for value, anchors in zip(coordinate, axes)
            ):
                raise ValueError("outside sampled coordinate range")
            chosen = tuple(
                next(anchor for anchor in anchors if anchor >= value)
                for value, anchors in zip(coordinate, axes)
            )
            upper = surface["cells"][_key(chosen)]["upper_ms"]
            mode = stratum.split("|", 1)[0]
            prediction = {
                metric: float(upper[metric])
                + float(self.payload["margin_ms"][mode][metric])
                for metric in METRICS
            }
            if any(not math.isfinite(value) or value <= 0 for value in prediction.values()):
                raise ValueError("corrupt observable co-run prediction")
            return {
                "in_domain": True,
                "stratum": stratum,
                "lookup_coordinate": list(chosen),
                "anchor_point": coordinate == chosen,
                "prediction_ms": prediction,
            }
        except (KeyError, StopIteration, TypeError, ValueError) as error:
            return {
                "in_domain": False,
                "prediction_ms": None,
                "reason": str(error),
            }


def load_corun_model(path: str | Path):
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    if payload.get("model_kind") == MODEL_KIND:
        return ObservableCorunModel.from_json(path)
    from .corun_surface import CorunTTFTModel

    return CorunTTFTModel.from_json(path)
