"""Observable-only expected remaining session work; no future trace reads."""
from __future__ import annotations

from .artifacts import finite_nonnegative


def expected_work(model: dict, workload: str, turn: int) -> dict | None:
    table = model.get("workloads", {}).get(workload)
    if table is None:
        table = model.get("workloads", {}).get("default")
    if not isinstance(table, dict) or not table or turn < 0:
        return None
    anchors = sorted(int(key) for key in table)
    if turn < anchors[0] or turn > min(anchors[-1], int(model.get("max_turn", anchors[-1]))):
        return None
    key = str(max(anchor for anchor in anchors if anchor <= turn))
    return {name: finite_nonnegative(value) for name, value in table[key].items()}


def future_energy(work: dict, profile) -> float:
    return (
        work.get("future_requests", 0) * profile.base_request_j
        + work.get("future_cold_tokens", 0) * profile.cold_prefill_j_per_token
        + work.get("future_cached_tokens", 0) * profile.cached_prefill_j_per_token
        + work.get("future_output_tokens", 0) * profile.decode_j_per_token
    ) * profile.uncertainty_margin


def annotate_problem(problem: dict, model: dict, profiles: dict) -> tuple[int, int]:
    inside = outside = 0
    for epoch in problem["epochs"]:
        for row in epoch["requests"]:
            if "turn_id" not in row or "workload" not in row:
                raise ValueError("rebuild problem with observable turn_id/workload fields")
            work = expected_work(model, row["workload"], int(row["turn_id"]))
            row["future_work_in_domain"] = work is not None
            inside += int(work is not None)
            outside += int(work is None)
            for region, option in row["options"].items():
                option["learned_future_energy_j"] = None if work is None else future_energy(work, profiles[region])
    return inside, outside
