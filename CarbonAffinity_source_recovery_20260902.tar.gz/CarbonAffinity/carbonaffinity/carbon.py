from __future__ import annotations

import csv
from bisect import bisect_right
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from .models import CarbonObservation

LB_PER_MWH_TO_G_PER_KWH = 0.45359237
JOULES_PER_KWH = 3_600_000.0


def carbon_grams(energy_j: float, moer_lbs_per_mwh: float) -> float:
    return max(0.0, energy_j) / JOULES_PER_KWH * moer_lbs_per_mwh * LB_PER_MWH_TO_G_PER_KWH


def _timestamp(value: str) -> float:
    value = value.strip()
    try:
        return float(value)
    except ValueError:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


@dataclass(frozen=True)
class _CarbonRow:
    timestamp_s: float
    forecast: float | None
    historical: float | None


class CarbonTrace:
    """Point-in-time forecast for dispatch and historical MOER for settlement."""

    def __init__(self, rows: dict[str, list[_CarbonRow]], max_age_s: float = 1800.0):
        self.rows = {region: sorted(values, key=lambda row: row.timestamp_s) for region, values in rows.items()}
        self.timestamps = {region: [row.timestamp_s for row in values] for region, values in self.rows.items()}
        self.max_age_s = max_age_s

    @classmethod
    def from_csv(cls, path: str | Path, max_age_s: float = 1800.0) -> "CarbonTrace":
        grouped: dict[str, list[_CarbonRow]] = defaultdict(list)
        with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
            for raw in csv.DictReader(handle):
                region = str(raw["region_id"])
                forecast_value = raw.get("forecast_lbs_per_mwh", "").strip()
                historical_value = raw.get("historical_lbs_per_mwh", "").strip()
                grouped[region].append(_CarbonRow(
                    timestamp_s=_timestamp(raw["timestamp"]),
                    forecast=float(forecast_value) if forecast_value else None,
                    historical=float(historical_value) if historical_value else None,
                ))
        if not grouped:
            raise ValueError(f"carbon trace is empty: {path}")
        return cls(dict(grouped), max_age_s=max_age_s)

    def at(self, region_id: str, now_s: float) -> CarbonObservation:
        values = self.rows.get(region_id, [])
        positions = self.timestamps.get(region_id, [])
        position = bisect_right(positions, now_s) - 1
        if position < 0:
            return CarbonObservation(region_id, None, None, None, True)
        row = values[position]
        stale = now_s - row.timestamp_s > self.max_age_s
        return CarbonObservation(
            region_id=region_id,
            forecast_lbs_per_mwh=None if stale else row.forecast,
            historical_lbs_per_mwh=None if stale else row.historical,
            source_timestamp_s=row.timestamp_s,
            stale=stale,
        )
