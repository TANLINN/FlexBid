from __future__ import annotations

from dataclasses import asdict, dataclass
import math
from typing import Any


_UNLIMITED_MBPS = 1.0e15


def _nonnegative(name: str, value: Any) -> float:
    number = float(value)
    if not math.isfinite(number) or number < 0.0:
        raise ValueError(f"{name} must be non-negative")
    return number


def _positive(name: str, value: Any) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0.0:
        raise ValueError(f"{name} must be positive")
    return number


@dataclass(frozen=True)
class NetworkSpec:
    """Deterministic wide-area network model for one serving region.

    Rates use decimal megabits/s and the energy coefficient uses decimal GB.
    The model is disabled by default so historical experiments are unchanged.
    """

    enabled: bool = False
    inject_delay: bool = False
    rtt_ms: float = 0.0
    uplink_mbps: float = _UNLIMITED_MBPS
    downlink_mbps: float = _UNLIMITED_MBPS
    prompt_bytes_per_token: float = 4.0
    output_bytes_per_token: float = 8.0
    request_base_bytes: float = 0.0
    response_base_bytes: float = 0.0
    first_response_bytes: float | None = None
    energy_kwh_per_gb: float = 0.0
    carbon_g_per_kwh: float = 0.0

    @classmethod
    def from_dict(cls, raw: dict[str, Any] | None) -> "NetworkSpec":
        if raw is None:
            return cls()
        if not isinstance(raw, dict):
            raise ValueError("network specification must be a mapping")
        # Reuse the region parser so validation has one implementation.
        return cls.from_region_config({"network": raw})

    @classmethod
    def from_region_config(cls, config: dict[str, Any]) -> "NetworkSpec":
        raw = config.get("network") or {}
        if not isinstance(raw, dict):
            raise ValueError("region.network must be a mapping")

        enabled = bool(raw.get("enabled", False))
        return cls(
            enabled=enabled,
            inject_delay=bool(raw.get("inject_delay", False)) and enabled,
            rtt_ms=_nonnegative(
                "network.rtt_ms",
                raw.get("rtt_ms", config.get("rtt_ms", 0.0)),
            ),
            uplink_mbps=_positive(
                "network.uplink_mbps",
                raw.get("uplink_mbps", _UNLIMITED_MBPS),
            ),
            downlink_mbps=_positive(
                "network.downlink_mbps",
                raw.get("downlink_mbps", _UNLIMITED_MBPS),
            ),
            prompt_bytes_per_token=_nonnegative(
                "network.prompt_bytes_per_token",
                raw.get("prompt_bytes_per_token", 4.0),
            ),
            output_bytes_per_token=_nonnegative(
                "network.output_bytes_per_token",
                raw.get("output_bytes_per_token", 8.0),
            ),
            request_base_bytes=_nonnegative("request_base_bytes", raw.get("request_base_bytes", 0)),
            response_base_bytes=_nonnegative("response_base_bytes", raw.get("response_base_bytes", 0)),
            first_response_bytes=(None if raw.get("first_response_bytes") is None else
                                  _nonnegative("first_response_bytes", raw["first_response_bytes"])),
            energy_kwh_per_gb=_nonnegative(
                "network.energy_kwh_per_gb",
                raw.get("energy_kwh_per_gb", 0.0),
            ),
            carbon_g_per_kwh=_nonnegative(
                "network.carbon_g_per_kwh",
                raw.get("carbon_g_per_kwh", 0.0),
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def carbon_g_per_byte(self) -> float:
        return self.energy_kwh_per_gb * self.carbon_g_per_kwh / 1.0e9


@dataclass(frozen=True)
class NetworkEstimate:
    request_bytes: int = 0
    response_bytes: int = 0
    first_response_bytes: int = 0
    request_transfer_ms: float = 0.0
    response_transfer_ms: float = 0.0
    first_response_transfer_ms: float = 0.0
    propagation_ms: float = 0.0
    ttft_ms: float = 0.0
    completion_ms: float = 0.0
    energy_j: float = 0.0
    carbon_g: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def transfer_ms(byte_count: int | float, rate_mbps: float) -> float:
    """Serialize bytes over a decimal-Mbps link and return milliseconds."""

    byte_count = max(0.0, float(byte_count))
    rate_mbps = _positive("rate_mbps", rate_mbps)
    return byte_count * 8.0 / (rate_mbps * 1000.0)


def estimate_network(
    spec: NetworkSpec,
    *,
    prompt_tokens: int = 0,
    output_tokens: int = 0,
    request_bytes: int | None = None,
    response_bytes: int | None = None,
    first_response_bytes: int | None = None,
) -> NetworkEstimate:
    """Estimate request-boundary network latency, energy, and carbon.

    No KV state is transferred.  ``request_bytes`` therefore represents the
    full prompt/API payload sent to the selected region.  If exact wire-byte
    counts are unavailable, deterministic token-to-byte factors are used.
    """

    if not spec.enabled:
        return NetworkEstimate()

    prompt_tokens = max(0, int(prompt_tokens))
    output_tokens = max(0, int(output_tokens))
    req = max(
        0,
        int(
            round(spec.request_base_bytes + prompt_tokens * spec.prompt_bytes_per_token)
            if request_bytes is None
            else request_bytes
        ),
    )
    resp = max(
        0,
        int(
            round(spec.response_base_bytes + output_tokens * spec.output_bytes_per_token)
            if response_bytes is None
            else response_bytes
        ),
    )
    first = max(
        0,
        int(
            round(spec.output_bytes_per_token if spec.first_response_bytes is None else spec.first_response_bytes)
            if first_response_bytes is None
            else first_response_bytes
        ),
    )
    first = min(first, resp) if resp else 0

    request_ms = transfer_ms(req, spec.uplink_mbps)
    response_ms = transfer_ms(resp, spec.downlink_mbps)
    first_response_ms = transfer_ms(first, spec.downlink_mbps)

    # One full RTT covers request propagation plus first-response propagation.
    ttft_ms = spec.rtt_ms + request_ms + first_response_ms
    completion_ms = spec.rtt_ms + request_ms + response_ms

    total_bytes = req + resp
    energy_kwh = total_bytes / 1.0e9 * spec.energy_kwh_per_gb
    return NetworkEstimate(
        request_bytes=req,
        response_bytes=resp,
        first_response_bytes=first,
        request_transfer_ms=request_ms,
        response_transfer_ms=response_ms,
        first_response_transfer_ms=first_response_ms,
        propagation_ms=spec.rtt_ms,
        ttft_ms=ttft_ms,
        completion_ms=completion_ms,
        energy_j=energy_kwh * 3.6e6,
        carbon_g=energy_kwh * spec.carbon_g_per_kwh,
    )
