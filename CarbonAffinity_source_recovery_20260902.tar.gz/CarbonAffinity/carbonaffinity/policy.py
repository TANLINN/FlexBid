from __future__ import annotations

import math
import json
from dataclasses import dataclass, replace
from pathlib import Path

from .carbon import CarbonTrace, carbon_grams
from .models import CandidateEstimate, RegionSnapshot, RequestSpec, RouteDecision
from .network import NetworkSpec, estimate_network
from .profile import HardwareProfile
from .state import StateDirectory


@dataclass(frozen=True)
class PolicySettings:
    name: str = "carbon_affinity"
    lease_ttl_s: float = 900.0
    carbon_weight: float = 1.0
    slo_violation_penalty: float = 1000.0
    queue_penalty: float = 0.02
    migration_hysteresis_g: float = 0.002
    uncertainty_penalty_g: float = 0.0
    carbon_error_quantile_lbs_per_mwh: float = 0.0
    carbon_common_error_quantile_lbs_per_mwh: float = 0.0
    carbon_diff_error_quantile_lbs_per_mwh: float = 0.0
    energy_error_quantile_solo_fraction: float = 0.0
    lifecycle_migration_enabled: bool = False
    lifecycle_future_work_path: str | None = None
    lifecycle_risk_mode: str = "expected_value"
    ttl_candidates_s: tuple[float, ...] = (0.0, 60.0, 300.0, 900.0)
    adaptive_lease: bool = True
    kv_bytes_per_token: float = 327680.0
    memory_shadow_g_per_gib_s: float = 0.0
    latency_value_g_per_ms: float = 0.0
    return_models: dict | None = None

    @classmethod
    def from_dict(cls, raw: dict) -> "PolicySettings":
        lease = raw.get("lease", {})
        lifecycle = raw.get("lifecycle_migration", {})
        return cls(
            name=str(raw.get("policy", "carbon_affinity")),
            lease_ttl_s=float(raw.get("lease_ttl_s", 900.0)),
            carbon_weight=float(raw.get("carbon_weight", 1.0)),
            slo_violation_penalty=float(raw.get("slo_violation_penalty", 1000.0)),
            queue_penalty=float(raw.get("queue_penalty", 0.02)),
            migration_hysteresis_g=float(raw.get("migration_hysteresis_g", 0.002)),
            uncertainty_penalty_g=float(raw.get("uncertainty_penalty_g", 0.0)),
            carbon_error_quantile_lbs_per_mwh=float(
                raw.get("carbon_error_quantile_lbs_per_mwh", 0.0)
            ),
            carbon_common_error_quantile_lbs_per_mwh=float(
                raw.get("carbon_common_error_quantile_lbs_per_mwh", 0.0)
            ),
            carbon_diff_error_quantile_lbs_per_mwh=float(
                raw.get("carbon_diff_error_quantile_lbs_per_mwh", 0.0)
            ),
            energy_error_quantile_solo_fraction=float(
                raw.get("energy_error_quantile_solo_fraction", 0.0)
            ),
            lifecycle_migration_enabled=bool(
                lifecycle.get("enabled", False)
            ),
            lifecycle_future_work_path=(
                str(lifecycle["future_work_model"])
                if lifecycle.get("future_work_model") else None
            ),
            lifecycle_risk_mode=str(
                lifecycle.get("risk_mode", "expected_value")
            ),
            ttl_candidates_s=tuple(float(value) for value in lease.get("ttl_candidates_s", [0, 60, 300, 900])),
            adaptive_lease=bool(lease.get("adaptive", True)),
            kv_bytes_per_token=float(lease.get("kv_bytes_per_token", 327680.0)),
            memory_shadow_g_per_gib_s=float(lease.get("memory_shadow_g_per_gib_s", 0.0)),
            latency_value_g_per_ms=float(lease.get("latency_value_g_per_ms", 0.0)),
            return_models=lease.get("return_models") or {"default": {"return_probability": 0.7, "mean_gap_s": 120.0}},
        )


class RouterPolicy:
    def __init__(
        self,
        settings: PolicySettings,
        carbon: CarbonTrace,
        profiles: dict[str, HardwareProfile],
        state: StateDirectory,
    ):
        self.settings = settings
        self.carbon = carbon
        self.profiles = profiles
        self.state = state
        self._round_robin_index = 0
        self._future_work: dict[str, dict] = {}
        if self.settings.lifecycle_migration_enabled:
            path = self.settings.lifecycle_future_work_path
            if not path:
                raise ValueError(
                    "lifecycle migration requires future_work_model"
                )
            payload = json.loads(Path(path).read_text())
            self._future_work = payload.get("workloads", {})

    def decide(
        self,
        request: RequestSpec,
        snapshots: dict[str, RegionSnapshot],
        now_s: float,
        carbon_time_s: float | None = None,
    ) -> RouteDecision:
        carbon_time_s = now_s if carbon_time_s is None else carbon_time_s
        previous = self.state.last_region(request.session_id, now_s)
        candidates: list[CandidateEstimate] = []
        missing_carbon = False
        for region_id, snapshot in snapshots.items():
            if not snapshot.healthy:
                continue
            cached = self.state.reusable_tokens(request.session_id, region_id, request, now_s)
            if self.settings.name == "cedar_like":
                cached = 0
            network_spec = NetworkSpec.from_dict(snapshot.network)
            network = estimate_network(
                network_spec,
                prompt_tokens=request.prompt_tokens,
                output_tokens=request.max_output_tokens,
            )
            # The latency surface consumes the live request-boundary network
            # delay.  Replace legacy RTT only when the explicit model is on,
            # preventing both omission and double counting.
            service_snapshot = (
                replace(snapshot, rtt_ms=network.ttft_ms)
                if network_spec.enabled else snapshot
            )
            service = self.profiles[region_id].estimate(
                request, cached, service_snapshot
            )
            in_domain = self.profiles[region_id].in_domain(request, snapshot)
            observation = self.carbon.at(region_id, carbon_time_s)
            signal = (
                observation.historical_lbs_per_mwh
                if self.settings.name == "oracle_historical"
                else observation.forecast_lbs_per_mwh
            )
            compute_carbon_g = (
                carbon_grams(service.energy_j, signal)
                if signal is not None else None
            )
            carbon_g = (
                compute_carbon_g + network.carbon_g
                if compute_carbon_g is not None else None
            )
            missing_carbon = missing_carbon or carbon_g is None
            feasible = in_domain and service.ttft_ms <= request.ttft_slo_ms and service.tpot_ms <= request.tpot_slo_ms
            fully_warm = self.profiles[region_id].estimate(
                request, request.prompt_tokens, service_snapshot
            )
            state_loss_j = max(0.0, service.energy_j - fully_warm.energy_j)
            score = self._score(snapshot, carbon_g, feasible)
            candidates.append(CandidateEstimate(
                region_id=region_id,
                cached_tokens=cached,
                energy_j=service.energy_j,
                ttft_ms=service.ttft_ms,
                tpot_ms=service.tpot_ms,
                forecast_lbs_per_mwh=signal,
                forecast_carbon_g=carbon_g,
                slo_feasible=feasible,
                in_domain=in_domain,
                score=score,
                state_loss_energy_j=state_loss_j,
                queue_depth=snapshot.queue_depth,
                solo_energy_j=service.solo_energy_j,
                projected_batch_size=service.projected_batch_size,
                allocated_energy_multiplier=service.allocated_energy_multiplier,
                compute_forecast_carbon_g=compute_carbon_g,
                network_forecast_carbon_g=network.carbon_g,
                network_energy_j=network.energy_j,
                network_ttft_ms=network.ttft_ms,
                network_completion_ms=network.completion_ms,
                network_request_bytes=network.request_bytes,
                network_response_bytes=network.response_bytes,
                network_carbon_g_per_byte=network_spec.carbon_g_per_byte,
                network_prompt_bytes_per_token=network_spec.prompt_bytes_per_token,
                network_request_base_bytes=network_spec.request_base_bytes,
                network_response_base_bytes=network_spec.response_base_bytes,
                network_output_bytes_per_token=network_spec.output_bytes_per_token,
            ))
        if not candidates:
            raise RuntimeError("no healthy region is available")

        fallback_reason: str | None = None
        fallback = missing_carbon and self.settings.name in {
            "carbon_affinity", "cleanest_now", "cedar_like", "oracle_historical"
        }
        if fallback:
            fallback_reason = "carbon signal unavailable; pressure-only fallback"
        policy = "pressure_only" if fallback else self.settings.name
        feasible = [candidate for candidate in candidates if candidate.slo_feasible]
        selectable = feasible or candidates
        if not feasible:
            fallback = True
            policy = "pressure_only"
            fallback_reason = "no SLO-feasible region; pressure-only fallback"
        chosen, reason = self._select(
            policy, selectable, previous, request
        )
        if fallback_reason is not None:
            reason = fallback_reason
        lease_ttl_s, lease_value, lease_reason = self._choose_lease(request, chosen, snapshots[chosen.region_id], policy)
        return RouteDecision(
            request_id=request.request_id,
            session_id=request.session_id,
            selected_region=chosen.region_id,
            policy=policy,
            previous_region=previous,
            migrated=previous is not None and previous != chosen.region_id,
            fallback=fallback,
            lease_ttl_s=lease_ttl_s,
            lease_value=lease_value,
            lease_reason=lease_reason,
            reason=reason,
            candidates=tuple(candidates),
        )

    def _choose_lease(
        self,
        request: RequestSpec,
        selected: CandidateEstimate,
        snapshot: RegionSnapshot,
        policy: str,
    ) -> tuple[float, float, str]:
        if policy not in {"carbon_affinity", "oracle_historical"} or not self.settings.adaptive_lease:
            return self.settings.lease_ttl_s, 0.0, "fixed lease for baseline or ablation"
        model = (self.settings.return_models or {}).get(
            request.workload,
            (self.settings.return_models or {}).get("default", {}),
        )
        return_probability = min(1.0, max(0.0, float(model.get("return_probability", 0.7))))
        mean_gap_s = max(1e-6, float(model.get("mean_gap_s", 120.0)))
        profile = self.profiles[selected.region_id]
        cold = profile.estimate(request, 0, snapshot)
        warm = profile.estimate(request, request.prompt_tokens, snapshot)
        avoided_energy_j = max(0.0, cold.energy_j - warm.energy_j)
        avoided_latency_ms = max(0.0, cold.ttft_ms - warm.ttft_ms)
        avoided_carbon_g = (
            carbon_grams(avoided_energy_j, selected.forecast_lbs_per_mwh)
            if selected.forecast_lbs_per_mwh is not None else 0.0
        )
        kv_gib = request.prompt_tokens * self.settings.kv_bytes_per_token / 2**30
        best = (0.0, 0.0)
        for ttl_s in self.settings.ttl_candidates_s:
            return_by_ttl = return_probability * (1.0 - math.exp(-max(0.0, ttl_s) / mean_gap_s))
            benefit = return_by_ttl * (
                avoided_carbon_g + self.settings.latency_value_g_per_ms * avoided_latency_ms
            )
            opportunity_cost = self.settings.memory_shadow_g_per_gib_s * kv_gib * max(0.0, ttl_s)
            value = benefit - opportunity_cost
            if value > best[1] or (value == best[1] and ttl_s < best[0]):
                best = (ttl_s, value)
        return best[0], best[1], (
            f"max lease value over {list(self.settings.ttl_candidates_s)}; "
            f"P(return)={return_probability:.3f}, mean_gap={mean_gap_s:.1f}s"
        )

    def _score(self, snapshot: RegionSnapshot, carbon_g: float | None, feasible: bool) -> float:
        carbon_term = carbon_g * self.settings.carbon_weight if carbon_g is not None else 0.0
        pressure = (snapshot.active_requests + snapshot.queue_depth) / max(1, snapshot.capacity)
        # CarbonAffinity already accounts for occupancy twice in physically
        # meaningful units: the profile predicts marginal batch energy and the
        # feasibility gate predicts tail latency.  Adding an uncalibrated,
        # dimensionless queue term to grams double-counts load and can route a
        # request to a dirtier region.  Keep the soft queue heuristic only for
        # the CEDAR-like ablation; the proposed and oracle policies solve the
        # constrained carbon objective directly.
        queue_cost = (
            pressure * self.settings.queue_penalty
            if self.settings.name == "cedar_like"
            else 0.0
        )
        return carbon_term + queue_cost + (
            0.0 if feasible else self.settings.slo_violation_penalty
        )

    def _select(
        self,
        policy: str,
        candidates: list[CandidateEstimate],
        previous: str | None,
        request: RequestSpec | None = None,
    ) -> tuple[CandidateEstimate, str]:
        by_region = {candidate.region_id: candidate for candidate in candidates}
        if policy == "round_robin":
            ordered = sorted(candidates, key=lambda item: item.region_id)
            winner = ordered[self._round_robin_index % len(ordered)]
            self._round_robin_index += 1
            return winner, "round-robin baseline"
        if policy == "sticky" and previous in by_region:
            return by_region[previous], "session affinity"
        if policy == "sticky":
            winner = min(candidates, key=lambda item: (item.queue_depth, item.ttft_ms, item.region_id))
            return winner, "carbon-blind initial placement for sticky baseline"
        if policy == "pressure_only":
            winner = min(candidates, key=lambda item: (item.queue_depth, item.ttft_ms, item.region_id))
            return winner, "carbon unavailable or pressure-only baseline"
        if policy == "cleanest_now":
            winner = min(candidates, key=lambda item: (float("inf") if item.forecast_lbs_per_mwh is None else item.forecast_lbs_per_mwh, item.score))
            return winner, "lowest instantaneous forecast MOER"

        if policy == "cedar_like":
            winner = min(candidates, key=lambda item: (item.score, item.ttft_ms, item.region_id))
            return winner, "stateless forecast-carbon plus queue baseline"

        if policy == "oracle_historical":
            winner = min(candidates, key=lambda item: (item.score, item.ttft_ms, item.region_id))
            return winner, "historical-MOER state-aware oracle"

        winner = min(candidates, key=lambda item: (item.score, item.ttft_ms, item.region_id))
        selection_reason = (
            "minimum state- and batch-aware allocated predicted carbon under SLO"
        )

        # Use an independently calibrated additive error interval normalized by
        # solo-request energy.  The q=.975 component quantile gives joint 95%
        # coverage for comparing two regional estimates (Bonferroni).
        cleanest = min(
            candidates,
            key=lambda item: (
                float("inf")
                if item.forecast_lbs_per_mwh is None
                else item.forecast_lbs_per_mwh,
                item.score,
                item.region_id,
            ),
        )
        energy_q = self.settings.energy_error_quantile_solo_fraction
        if winner.region_id != cleanest.region_id and energy_q > 0.0:
            winner_upper_j = (
                winner.energy_j + energy_q * winner.solo_energy_j
            )
            cleanest_lower_j = max(
                0.0,
                cleanest.energy_j - energy_q * cleanest.solo_energy_j,
            )
            if winner_upper_j >= cleanest_lower_j:
                winner = cleanest
                selection_reason = (
                    "cleanest grid because allocated-energy confidence "
                    f"intervals overlap at component q={energy_q:.4f}"
                )

        lifecycle_improvement: float | None = None
        lifecycle_winner_energy_j: float | None = None
        lifecycle_incumbent_energy_j: float | None = None
        future_work = self._expected_future_work(request)
        if (
            previous in by_region
            and cleanest.region_id != previous
            and future_work is not None
        ):
            incumbent = by_region[previous]
            incumbent_lifecycle_j = (
                incumbent.energy_j
                + self._future_work_energy_j(
                    incumbent.region_id, future_work
                )
            )
            cleanest_lifecycle_j = (
                cleanest.energy_j
                + self._future_work_energy_j(
                    cleanest.region_id, future_work
                )
            )
            incumbent_lifecycle_g = (
                float(incumbent.forecast_carbon_g or 0.0)
                + carbon_grams(
                    incumbent_lifecycle_j - incumbent.energy_j,
                    incumbent.forecast_lbs_per_mwh,
                )
                + self._future_work_network_g(incumbent, future_work)
            )
            cleanest_lifecycle_g = (
                float(cleanest.forecast_carbon_g or 0.0)
                + carbon_grams(
                    cleanest_lifecycle_j - cleanest.energy_j,
                    cleanest.forecast_lbs_per_mwh,
                )
                + self._future_work_network_g(cleanest, future_work)
            )
            improvement = self.settings.carbon_weight * (
                incumbent_lifecycle_g - cleanest_lifecycle_g
            )
            if improvement > 0.0:
                winner = cleanest
                lifecycle_improvement = improvement
                lifecycle_winner_energy_j = cleanest_lifecycle_j
                lifecycle_incumbent_energy_j = incumbent_lifecycle_j
                selection_reason = (
                    "cleanest-grid migration amortized over independently "
                    "trained expected cumulative future work"
                )
        if previous in by_region and winner.region_id != previous:
            incumbent = by_region[previous]
            improvement = (
                lifecycle_improvement
                if lifecycle_improvement is not None
                else incumbent.score - winner.score
            )
            risk_winner_energy_j = (
                lifecycle_winner_energy_j
                if lifecycle_winner_energy_j is not None
                else winner.energy_j
            )
            risk_incumbent_energy_j = (
                lifecycle_incumbent_energy_j
                if lifecycle_incumbent_energy_j is not None
                else incumbent.energy_j
            )
            # A forecast-error bound for a difference of two regional carbon
            # estimates scales with the energy of both alternatives.  This
            # converts an intensity residual (lbs/MWh) into request-level grams.
            common_q = self.settings.carbon_common_error_quantile_lbs_per_mwh
            diff_q = self.settings.carbon_diff_error_quantile_lbs_per_mwh
            expected_lifecycle = (
                lifecycle_improvement is not None
                and self.settings.lifecycle_risk_mode == "expected_value"
            )
            if expected_lifecycle:
                risk_g = 0.0
            elif common_q > 0.0 or diff_q > 0.0:
                # Let regional forecast errors be e_a=m+d/2 and e_b=m-d/2.
                # The pairwise route-regret error is then
                # (E_a-E_b)m + (E_a+E_b)d/2.  Calibrating the common and
                # differential modes avoids treating correlated regional
                # errors as two independent worst cases.
                intensity_energy = (
                    abs(
                        risk_winner_energy_j
                        - risk_incumbent_energy_j
                    ) * common_q
                    + 0.5 * (
                        risk_winner_energy_j
                        + risk_incumbent_energy_j
                    ) * diff_q
                )
                risk_g = carbon_grams(intensity_energy, 1.0)
            else:
                risk_g = carbon_grams(
                    risk_winner_energy_j
                    + risk_incumbent_energy_j,
                    self.settings.carbon_error_quantile_lbs_per_mwh,
                )
            threshold = (
                self.settings.migration_hysteresis_g
                + self.settings.uncertainty_penalty_g
                + risk_g
            )
            if improvement < threshold:
                return incumbent, (
                    f"migration benefit {improvement:.6f} below calibrated "
                    f"hysteresis+risk {threshold:.6f} (forecast-risk={risk_g:.6f})"
                )
        return winner, (
            f"{selection_reason}; "
            f"projected_batch={winner.projected_batch_size}, "
            f"allocated_energy_multiplier={winner.allocated_energy_multiplier:.4f}"
        )

    @staticmethod
    def _future_work_network_g(
        candidate: CandidateEstimate,
        future_work: dict[str, float],
    ) -> float:
        prompt_tokens = (
            float(future_work.get("future_cold_tokens", 0.0))
            + float(future_work.get("future_cached_tokens", 0.0))
        )
        output_tokens = float(
            future_work.get("future_output_tokens", 0.0)
        )
        future_bytes = (
            prompt_tokens * candidate.network_prompt_bytes_per_token
            + output_tokens * candidate.network_output_bytes_per_token
            + float(future_work.get("future_requests", 0)) * (candidate.network_request_base_bytes + candidate.network_response_base_bytes)
        )
        return max(0.0, future_bytes) * candidate.network_carbon_g_per_byte

    def _expected_future_work(
        self, request: RequestSpec | None
    ) -> dict[str, float] | None:
        if (
            request is None
            or not self.settings.lifecycle_migration_enabled
        ):
            return None
        values = self._future_work.get(
            request.workload,
            self._future_work.get("default"),
        )
        if not values:
            return None
        table = {int(turn): row for turn, row in values.items()}
        # Raw agent/workflow step identifiers are not guaranteed to be
        # contiguous across trace sources.  Never clamp an unseen large step
        # (for example, a Codex workflow_step in the thousands) to the final
        # calibrated turn bucket: that fabricates future-work evidence outside
        # the model's support.
        if request.turn_id < min(table) or request.turn_id > max(table):
            return None
        eligible = [turn for turn in table if turn <= request.turn_id]
        turn = max(eligible) if eligible else min(table)
        return {
            key: max(0.0, float(value))
            for key, value in table[turn].items()
        }

    def _future_work_energy_j(
        self, region_id: str, work: dict[str, float]
    ) -> float:
        profile = self.profiles[region_id]
        return (
            work.get("future_requests", 0.0) * profile.base_request_j
            + work.get("future_cold_tokens", 0.0)
            * profile.cold_prefill_j_per_token
            + work.get("future_cached_tokens", 0.0)
            * profile.cached_prefill_j_per_token
            + work.get("future_output_tokens", 0.0)
            * profile.decode_j_per_token
        )
