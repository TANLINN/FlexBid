from __future__ import annotations

import time
from collections import Counter
from typing import Mapping, Sequence

from .carbon import carbon_grams
from .closed_loop import (
    ClosedLoopAssignment,
    ClosedLoopCapacityError,
    ClosedLoopPlan,
    ClosedLoopPlanner,
)
from .models import RegionSnapshot
from .offline_oracle import OracleRequest


BASELINE_POLICIES = (
    "pressure_only",
    "cleanest_now",
    "sticky",
    "carbon_affinity",
)


class BaselineClosedLoopPlanner(ClosedLoopPlanner):
    """Capacity-safe sequential baselines for the closed-loop runtime.

    The adapter deliberately shares the joint planner's live-load accounting,
    atomic reservations, calibrated option surfaces, and completion handling.
    Only the assignment rule changes.  Requests already assigned in the same
    microbatch are rechecked whenever a tentative placement increases a
    region's final batch size.
    """

    def __init__(self, template, policy_name: str, **kwargs) -> None:
        if policy_name not in BASELINE_POLICIES:
            raise ValueError(f"unsupported baseline policy: {policy_name}")
        super().__init__(template, **kwargs)
        self.baseline_policy = policy_name
        self.policy_name = f"closed_loop_{policy_name}"
        self.reason = (
            "atomic capacity-safe closed-loop baseline: " + policy_name
        )
        self._regions = {
            region.region_id: region for region in template.regions
        }
        self._migration = {
            (edge.source, edge.destination): edge
            for edge in template.migration_edges
        }

    def _warm(self, request: OracleRequest, region_id: str) -> bool:
        return self._placements.get(request.session_id) == region_id

    def _edge(self, request: OracleRequest, region_id: str):
        source = self._placements.get(request.session_id)
        if source is None or source == region_id:
            return None
        return self._migration.get((source, region_id))

    def _request_feasible(
        self,
        request: OracleRequest,
        region_id: str,
        projected_load: int,
        snapshot=None,
        members=(),
    ) -> bool:
        option = request.option(region_id)
        if option is None or not option.in_domain:
            return False
        region = self._regions[region_id]
        if projected_load < 1 or projected_load > region.capacity:
            return False
        warm = self._warm(request, region_id)
        edge = self._edge(request, region_id)
        migration_delay_ms = 0.0 if edge is None else edge.delay_ms
        additional = max(0, projected_load - 1)
        ttft_ms = (
            (option.warm_ttft_ms if warm else option.cold_ttft_ms)
            + migration_delay_ms
            + additional * region.queue_ttft_ms_per_additional_request
            + additional
            * (
                option.warm_ttft_ms_per_additional_request
                if warm
                else option.cold_ttft_ms_per_additional_request
            )
        )
        tpot_ms = (
            option.tpot_ms
            + additional * region.tpot_ms_per_additional_request
            + additional
            * (
                option.warm_tpot_ms_per_additional_request
                if warm
                else option.cold_tpot_ms_per_additional_request
            )
        )
        ttft_ms, tpot_ms = option.latency(projected_load, warm, region)
        ttft_ms += migration_delay_ms
        ttft_ms, tpot_ms = self._guarded_latency_ms(
            ttft_ms, tpot_ms, request, region_id, snapshot, members,
        )
        return ttft_ms + self._queue_wait_ms.get(request.request_id, 0) <= request.ttft_slo_ms and tpot_ms <= request.tpot_slo_ms

    def _tentative_feasible(
        self,
        request: OracleRequest,
        region_id: str,
        assigned: dict[str, str],
        load: Mapping[str, int],
        snapshots: Mapping[str, RegionSnapshot],
    ) -> bool:
        snapshot = snapshots.get(region_id)
        if snapshot is not None and not snapshot.healthy:
            return False
        members = [
            self.request(request_id)
            for request_id, assigned_region in assigned.items()
            if assigned_region == region_id
        ] + [request]
        projected = load[region_id] + len(members)
        return all(
            self._request_feasible(member, region_id, projected, snapshot, members)
            for member in members
        )

    def _request_carbon(
        self,
        request: OracleRequest,
        region_id: str,
        projected_load: int,
        carbon_lbs_per_mwh: Mapping[str, float],
        include_future: bool,
    ) -> float:
        option = request.option(region_id)
        assert option is not None
        region = self._regions[region_id]
        warm = self._warm(request, region_id)
        energy_j = (
            option.warm_energy_j if warm else option.cold_energy_j
        ) * option.batch_multiplier(
            projected_load,
            warm,
            region.batch_multiplier(projected_load),
        )
        if (
            include_future
            and getattr(
                request,
                "future_work_in_domain",
                option.learned_future_energy_j is not None,
            )
            and option.learned_future_energy_j is not None
        ):
            energy_j += option.learned_future_energy_j
        result = carbon_grams(energy_j, carbon_lbs_per_mwh[region_id]) + option.network_carbon_g
        source = self._placements.get(request.session_id)
        edge = self._edge(request, region_id)
        if source is not None and source != region_id and edge is not None:
            average_intensity = 0.5 * (
                carbon_lbs_per_mwh[source]
                + carbon_lbs_per_mwh[region_id]
            )
            result += carbon_grams(edge.energy_j, average_intensity)
        return result

    def _tentative_objective(
        self,
        request: OracleRequest,
        region_id: str,
        assigned: dict[str, str],
        load: Mapping[str, int],
        carbon_lbs_per_mwh: Mapping[str, float],
        include_future: bool,
    ) -> float:
        tentative = dict(assigned)
        tentative[request.request_id] = region_id
        counts = Counter(tentative.values())
        return sum(
            self._request_carbon(
                self.request(request_id),
                destination,
                load[destination] + counts[destination],
                carbon_lbs_per_mwh,
                include_future,
            )
            for request_id, destination in tentative.items()
        )

    def _pressure_key(
        self,
        region_id: str,
        assigned: Mapping[str, str],
        load: Mapping[str, int],
    ) -> tuple[float, int, str]:
        projected = (
            load[region_id]
            + sum(value == region_id for value in assigned.values())
            + 1
        )
        return (
            projected / self._regions[region_id].capacity,
            projected,
            region_id,
        )

    def plan(
        self,
        request_ids: Sequence[str],
        snapshots: Mapping[str, RegionSnapshot],
        carbon_lbs_per_mwh: Mapping[str, float],
    ) -> ClosedLoopPlan:
        started_ns = time.perf_counter_ns()
        if not request_ids:
            raise ValueError("closed-loop batch is empty")
        if len(request_ids) != len(set(request_ids)):
            raise ValueError("closed-loop batch has duplicate requests")
        requests = tuple(self.request(item) for item in request_ids)
        if any(key in self._reservations for key in request_ids):
            raise ValueError("request already reserved")
        sessions = [request.session_id for request in requests]
        if len(sessions) != len(set(sessions)):
            raise ValueError(
                "closed-loop batch may contain at most one request per session"
            )
        region_ids = set(self._regions)
        if set(carbon_lbs_per_mwh) != region_ids:
            raise ValueError("carbon regions do not match planner regions")

        load = self._load(snapshots)
        if sum(
            max(0, region.capacity - load[region.region_id])
            for region in self.template.regions
        ) < len(requests):
            raise ClosedLoopCapacityError(
                "insufficient unreserved capacity for ready batch"
            )

        assigned: dict[str, str] = {}
        for request in requests:
            feasible = [
                region_id
                for region_id in sorted(region_ids)
                if self._tentative_feasible(
                    request,
                    region_id,
                    assigned,
                    load,
                    snapshots,
                )
            ]
            if not feasible:
                raise ClosedLoopCapacityError(
                    "baseline has no capacity- and SLO-feasible assignment "
                    f"for {request.request_id}"
                )

            if self.baseline_policy == "pressure_only":
                winner = min(
                    feasible,
                    key=lambda region_id: self._pressure_key(
                        region_id, assigned, load
                    ),
                )
            elif self.baseline_policy == "cleanest_now":
                winner = min(
                    feasible,
                    key=lambda region_id: (
                        carbon_lbs_per_mwh[region_id],
                        self._pressure_key(region_id, assigned, load),
                    ),
                )
            elif self.baseline_policy == "sticky":
                previous = self._placements.get(request.session_id)
                if previous in feasible:
                    winner = previous
                else:
                    winner = min(
                        feasible,
                        key=lambda region_id: self._pressure_key(
                            region_id, assigned, load
                        ),
                    )
            else:
                winner = min(
                    feasible,
                    key=lambda region_id: (
                        self._tentative_objective(
                            request,
                            region_id,
                            assigned,
                            load,
                            carbon_lbs_per_mwh,
                            include_future=True,
                        ),
                        self._pressure_key(region_id, assigned, load),
                    ),
                )
            assigned[request.request_id] = winner

        counts = Counter(assigned.values())
        assignments = tuple(
            ClosedLoopAssignment(
                request_id=request.request_id,
                region_id=assigned[request.request_id],
                planned_epoch_batch=counts[assigned[request.request_id]],
                background_load=load[assigned[request.request_id]],
                projected_total_load=(
                    load[assigned[request.request_id]]
                    + counts[assigned[request.request_id]]
                ),
            )
            for request in requests
        )
        self._guard_batch(tuple(assigned.items()), snapshots)

        objective = sum(
            self._request_carbon(
                request,
                assigned[request.request_id],
                load[assigned[request.request_id]]
                + counts[assigned[request.request_id]],
                carbon_lbs_per_mwh,
                include_future=False,
            )
            for request in requests
        )
        result = ClosedLoopPlan(
            batch_id=self._batch_id,
            assignments=assignments,
            planner_time_ms=(time.perf_counter_ns() - started_ns) / 1e6,
            budget_exhausted=False,
            objective_carbon_g=objective,
            load_before=tuple(sorted(load.items())),
        )
        self._commit(assignments)
        self._batch_id += 1
        return result
