from __future__ import annotations

import json
import os
import secrets
import threading
from dataclasses import asdict
from pathlib import Path

from .models import CacheEntry, RequestSpec


class StateDirectory:
    def __init__(self, path: str | Path | None = None, persist_every_updates: int = 1000):
        self.path = Path(path) if path else None
        self._entries: dict[tuple[str, str], CacheEntry] = {}
        self._last_region: dict[str, str] = {}
        self._lock = threading.RLock()
        self._dirty_updates = 0
        self._persist_every_updates = max(1, persist_every_updates)
        if self.path and self.path.exists():
            self._load()

    def _load(self) -> None:
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        for item in raw.get("entries", []):
            entry = CacheEntry(**item)
            self._entries[(entry.session_id, entry.region_id)] = entry
        self._last_region.update(raw.get("last_region", {}))

    def reusable_tokens(self, session_id: str, region_id: str, request: RequestSpec, now_s: float) -> int:
        with self._lock:
            entry = self._entries.get((session_id, region_id))
            return entry.reusable_tokens(request, now_s) if entry else 0

    def last_region(self, session_id: str, now_s: float | None = None) -> str | None:
        with self._lock:
            region = self._last_region.get(session_id)
            if region is None or now_s is None:
                return region
            entry = self._entries.get((session_id, region))
            return region if entry and now_s < entry.expires_at_s else None

    def update(
        self,
        request: RequestSpec,
        region_id: str,
        now_s: float,
        lease_ttl_s: float,
        observed_cached_tokens: int | None = None,
        cache_salt: str | None = None,
        persist: bool = True,
    ) -> None:
        prefix = max(request.shared_prefix_tokens, request.prompt_tokens)
        entry = CacheEntry(
            session_id=request.session_id,
            region_id=region_id,
            prefix_tokens=prefix,
            turn_id=request.turn_id,
            expires_at_s=now_s + max(0.0, lease_ttl_s),
            updated_at_s=now_s,
            observed_cached_tokens=observed_cached_tokens,
            cache_salt=cache_salt,
        )
        with self._lock:
            self._entries[(request.session_id, region_id)] = entry
            self._last_region[request.session_id] = region_id
            self._dirty_updates += 1
            if persist and self._dirty_updates >= self._persist_every_updates:
                self._expire_without_persist(now_s)
                self.persist()

    def salt_for_dispatch(self, session_id: str, region_id: str, now_s: float) -> str:
        """Stable within a lease; a new salt logically invalidates expired KV."""
        with self._lock:
            entry = self._entries.get((session_id, region_id))
            if entry and now_s < entry.expires_at_s and entry.cache_salt:
                return entry.cache_salt
        return secrets.token_hex(32)

    def _expire_without_persist(self, now_s: float) -> int:
        expired = [key for key, entry in self._entries.items() if now_s >= entry.expires_at_s]
        for key in expired:
            del self._entries[key]
        for session, region in list(self._last_region.items()):
            if (session, region) not in self._entries:
                del self._last_region[session]
        return len(expired)

    def expire(self, now_s: float) -> int:
        with self._lock:
            expired = self._expire_without_persist(now_s)
            if expired:
                self.persist()
            return len(expired)

    def persist(self) -> None:
        if not self.path:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "entries": [asdict(entry) for entry in self._entries.values()],
            "last_region": self._last_region,
        }
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        temporary.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        os.replace(temporary, self.path)
        self._dirty_updates = 0
