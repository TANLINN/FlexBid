from __future__ import annotations

import asyncio
import math
import time
from collections import Counter
from dataclasses import asdict, dataclass, replace
from typing import Mapping, Sequence

from .models import RegionSnapshot, RequestSpec
from .offline_oracle import OracleEpoch, OracleProblem, OracleRequest
from .online_planner import (
    OnlinePlannerSettings,
    solve_online,
)


class ClosedLoopCapacityError(RuntimeError):
    """The current live load leaves no feasible joint assignment."""


@dataclass(frozen=True)
class ClosedLoopAssignment:
    request_id: str
    region_id: str
    planned_epoch_batch: int
    background_load: int
    projected_total_load: int


@dataclass(frozen=True)
class ClosedLoopPlan:
    batch_id: int
    assignments: tuple[ClosedLoopAssignment, ...]
    planner_time_ms: float
    budget_exhausted: bool
    objective_carbon_g: float
    load_before: tuple[tuple[str, int], ...]

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class ClosedLoopRuntimeDecision:
    assignment: ClosedLoopAssignment
    batch_id: int
    planner_time_ms: float
    budget_exhausted: bool
    objective_carbon_g: float
    load_before: tuple[tuple[str, int], ...]

    @property
    def region_id(self) -> str:
        return self.assignment.region_id

    def to_dict(self) -> dict:
        return asdict(self)


class ClosedLoopPlanner:
    """Atomically plans batches against live and already-reserved load.

    The planner is intentionally independent of asyncio and HTTP.  A runtime
    coordinator may call :meth:`plan` while holding its reservation lock, then
    call :meth:`complete` when a request finishes.  This prevents concurrent
    request coroutines from all observing an empty queue and selecting the
    same region.
    """

    def __init__(
        self,
        template: OracleProblem,
        settings: OnlinePlannerSettings | None = None,
        prefill_backlog_model=None,
        corun_model=None,
    ) -> None:
        self.template = template
        self.settings = settings or OnlinePlannerSettings(
            horizon_epochs=0,
            max_price_iterations=32,
            time_budget_ms=100.0,
            continuation_mode="learned_future",
        )
        self._requests = {
            request.request_id: request
            for epoch in template.epochs
            for request in epoch.requests
        }
        self._placements = dict(template.initial_placements)
        self._reserved = Counter(
            {region.region_id: 0 for region in template.regions}
        )
        self._batch_id = 0
        self._reservations: dict[str, tuple[str, int, int]] = {}
        self._queue_wait_ms: dict[str, float] = {}
        from .prefill_backlog import PrefillBacklogTTFTModel
        self.prefill_backlog_model = PrefillBacklogTTFTModel.coerce(prefill_backlog_model)
        self.corun_model = corun_model
        self.guard_audit = Counter()

    def _commit(self, assignments) -> None:
        ids = [a.request_id for a in assignments]
        if len(ids) != len(set(ids)) or any(key in self._reservations for key in ids):
            raise RuntimeError("duplicate reservation")
        for assignment in assignments:
            request = self.request(assignment.request_id)
            warm = self._placements.get(request.session_id) == assignment.region_id
            own = max(0, request.prompt_tokens - (request.shared_prefix_tokens if warm else 0))
            self._reservations[request.request_id] = (assignment.region_id, own, request.max_output_tokens)
            self._reserved[assignment.region_id] += 1

    def _workload_entries(self, region_id, snapshot, members=()):
        entries = {key: ("prefill", own, output) for key, (region, own, output)
                   in self._reservations.items() if region == region_id}
        if snapshot is not None:
            entries.update({key: (phase, own, output) for key, phase, own, output in snapshot.workload_requests})
        for request in members:
            warm = self._placements.get(request.session_id) == region_id
            entries[request.request_id] = ("prefill", max(0, request.prompt_tokens - (request.shared_prefix_tokens if warm else 0)), request.max_output_tokens)
        return entries

    def _workload(self, region_id, snapshot, members=(), exclude=None):
        entries = self._workload_entries(region_id, snapshot, members)
        entries.pop(exclude, None)
        pref = sum(v[1] for v in entries.values() if v[0] == "prefill")
        pending = sum(v[2] for v in entries.values() if v[0] == "prefill")
        decode = sum(v[2] for v in entries.values() if v[0] == "decode")
        if snapshot is not None and not snapshot.workload_requests:
            pref = max(pref, snapshot.estimated_prefill_tokens)
            pending = max(pending, snapshot.prefill_decode_tokens)
            decode = max(decode, snapshot.active_decode_tokens)
        return pref, pending, decode

    def _observable_query(self, request, region_id, snapshot, members=()):
        entries = self._workload_entries(region_id, snapshot, members)
        entries.pop(request.request_id, None)

        previous = self._placements.get(request.session_id)
        warm = previous == region_id
        cached = request.shared_prefix_tokens if warm else 0
        backgrounds = []
        for request_id, (phase, own, output) in sorted(entries.items()):
            try:
                background = self.request(request_id)
            except KeyError as error:
                raise ValueError(
                    "active background is absent from the planner template"
                ) from error
            bg_previous = self._placements.get(background.session_id)
            bg_warm = bg_previous == region_id
            bg_cached = background.shared_prefix_tokens if bg_warm else 0
            backgrounds.append({
                "phase": phase,
                "prompt_tokens": background.prompt_tokens,
                "cached_reservation": bg_cached,
                "output_budget": output,
                "prefill_reservation": own if phase == "prefill" else 0,
                "cold_namespace_isolated": bg_previous is None,
            })
        return {
            "prompt_tokens": request.prompt_tokens,
            "cached_reservation": cached,
            "output_budget": request.max_output_tokens,
            # A first-seen session has no prior cache namespace on any region.
            # Migration is conservatively OOD because an older destination
            # cache cannot be inferred from last-placement state alone.
            "cold_namespace_isolated": previous is None,
            "runtime_cap": 784,
            "backgrounds": backgrounds,
        }

    def _guarded_latency_ms(
        self, existing_ttft, existing_tpot, request, region_id, snapshot,
        members=(),
    ):
        if self.prefill_backlog_model is None and self.corun_model is None:
            return existing_ttft, existing_tpot
        if self.corun_model is not None and hasattr(self.corun_model, "predict_query"):
            try:
                query = self._observable_query(
                    request, region_id, snapshot, members,
                )
            except (KeyError, TypeError, ValueError) as error:
                prediction = {
                    "in_domain": False,
                    "prediction_ms": None,
                    "reason": str(error),
                }
            else:
                prediction = self.corun_model.predict_query(query)
            predicted_values = prediction.get("prediction_ms") or {}
            predicted_ttft = predicted_values.get("ttft_ms")
            predicted_tpot = predicted_values.get("tpot_ms")
            self.guard_audit["observable_predictions"] += 1
        else:
            warm = self._placements.get(request.session_id) == region_id
            own = max(
                0,
                request.prompt_tokens
                - (request.shared_prefix_tokens if warm else 0),
            )
            pref, pending, decode = self._workload(
                region_id, snapshot, members, request.request_id,
            )
            if self.corun_model is not None:
                prediction = self.corun_model.predict(
                    own, pref, pending, decode,
                )
            else:
                prediction = self.prefill_backlog_model.predict(own, pref)
                if pending or decode:
                    prediction = {**prediction, "out_of_domain": True}
            predicted_ttft = prediction.get("conservative_ttft_ms")
            predicted_tpot = None

        self.guard_audit["predictions"] += 1
        out_of_domain = bool(
            prediction.get("out_of_domain", not prediction.get("in_domain", True))
        )
        if out_of_domain:
            self.guard_audit["out_of_domain_predictions"] += 1
            return math.inf, math.inf

        network = 0.0 if snapshot is None else snapshot.rtt_ms
        if snapshot is not None and snapshot.network:
            from .network import NetworkSpec, estimate_network
            spec = NetworkSpec.from_dict(snapshot.network)
            if spec.enabled:
                network = estimate_network(
                    spec,
                    prompt_tokens=request.prompt_tokens,
                    output_tokens=request.max_output_tokens,
                ).ttft_ms
        guarded_ttft = float(predicted_ttft) + network
        guarded_tpot = (
            existing_tpot
            if predicted_tpot is None
            else float(predicted_tpot)
        )
        self.guard_audit["guard_activations"] += int(
            guarded_ttft > existing_ttft or guarded_tpot > existing_tpot
        )
        self.guard_audit["tpot_guard_activations"] += int(
            guarded_tpot > existing_tpot
        )
        return max(existing_ttft, guarded_ttft), max(
            existing_tpot, guarded_tpot,
        )

    def _guarded_ttft_ms(self, existing, request, region_id, snapshot, members=()):
        return self._guarded_latency_ms(
            existing, 0.0, request, region_id, snapshot, members,
        )[0]

    def _guard_batch(self, assignments, snapshots):
        by_region = {}
        for key, region in assignments:
            by_region.setdefault(region, []).append(self.request(key))
        for region, members in by_region.items():
            for request in members:
                ttft, tpot = self._guarded_latency_ms(
                    0.0, 0.0, request, region, snapshots.get(region), members,
                )
                if (
                    ttft + self._queue_wait_ms.get(request.request_id, 0)
                    > request.ttft_slo_ms
                    or tpot > request.tpot_slo_ms
                ):
                    self.guard_audit["atomic_batch_rejections"] += 1
                    raise ClosedLoopCapacityError(
                        "joint batch violates workload-conditioned latency guard"
                    )

    @property
    def reserved(self) -> dict[str, int]:
        return dict(self._reserved)

    @property
    def placements(self) -> dict[str, str]:
        return dict(self._placements)

    def request(self, request_id: str) -> OracleRequest:
        try:
            return self._requests[request_id]
        except KeyError as error:
            raise KeyError(
                f"request {request_id!r} is absent from planner template"
            ) from error

    def _load(
        self,
        snapshots: Mapping[str, RegionSnapshot],
    ) -> dict[str, int]:
        result = {}
        for region in self.template.regions:
            snapshot = snapshots.get(region.region_id)
            observed = (
                0
                if snapshot is None
                else snapshot.active_requests
                + snapshot.queue_depth
            )
            # Reservations and RegionClient counters describe the same work
            # at different points in its lifecycle, so summing would double
            # count.  max() also incorporates controlled external activity.
            result[region.region_id] = max(
                observed,
                self._reserved[region.region_id],
            )
            if snapshot is not None and snapshot.workload_requests:
                ids = {row[0] for row in snapshot.workload_requests}
                ids.update(key for key, value in self._reservations.items() if value[0] == region.region_id)
                result[region.region_id] = max(observed, len(ids))
        return result

    def plan(
        self,
        request_ids: Sequence[str],
        snapshots: Mapping[str, RegionSnapshot],
        carbon_lbs_per_mwh: Mapping[str, float],
    ) -> ClosedLoopPlan:
        if not request_ids:
            raise ValueError("closed-loop batch is empty")
        if len(request_ids) != len(set(request_ids)):
            raise ValueError("closed-loop batch has duplicate requests")

        requests = tuple(self.request(item) for item in request_ids)
        if any(key in self._reservations for key in request_ids):
            raise ValueError("request already reserved")
        sessions = [request.session_id for request in requests]
        if len(sessions) != len(set(sessions)):
            raise ValueError(
                "closed-loop batch may contain at most one request per session"
            )

        region_ids = {
            region.region_id for region in self.template.regions
        }
        if set(carbon_lbs_per_mwh) != region_ids:
            raise ValueError("carbon regions do not match planner regions")

        load = self._load(snapshots)
        residual = {
            region.region_id: max(
                0,
                region.capacity - load[region.region_id],
            )
            for region in self.template.regions
        }
        if sum(residual.values()) < len(requests):
            raise ClosedLoopCapacityError(
                "insufficient unreserved capacity for ready batch"
            )

        original_regions = {
            region.region_id: region
            for region in self.template.regions
        }
        # Keep the frozen planner untouched.  Instead, compile current live
        # load into an equivalent temporary problem: residual capacity is the
        # new capacity; background queuing is folded into base latency; and
        # batch curves are shifted from k to background+k.
        adjusted_regions = tuple(
            replace(
                region,
                capacity=max(1, residual[region.region_id]),
                batch_energy_multipliers=((1, 1.0),),
                queue_ttft_ms_per_additional_request=0.0,
                tpot_ms_per_additional_request=0.0,
            )
            for region in self.template.regions
        )
        adjusted_requests = []
        for request in requests:
            options = []
            for region_id, option in request.options:
                region = original_regions[region_id]
                background = load[region_id]
                room = residual[region_id]
                snapshot = snapshots.get(region_id)
                if room < 1 or (snapshot is not None and not snapshot.healthy):
                    options.append((
                        region_id,
                        replace(option, in_domain=False),
                    ))
                    continue

                cold_ttft_add = (
                    region.queue_ttft_ms_per_additional_request
                    + option.cold_ttft_ms_per_additional_request
                )
                warm_ttft_add = (
                    region.queue_ttft_ms_per_additional_request
                    + option.warm_ttft_ms_per_additional_request
                )
                cold_tpot_add = (
                    region.tpot_ms_per_additional_request
                    + option.cold_tpot_ms_per_additional_request
                )
                warm_tpot_add = (
                    region.tpot_ms_per_additional_request
                    + option.warm_tpot_ms_per_additional_request
                )
                warm_now = (
                    self._placements.get(request.session_id)
                    == region_id
                )
                selected_tpot_add = (
                    warm_tpot_add if warm_now else cold_tpot_add
                )
                cold_curve = tuple(
                    (
                        batch,
                        option.batch_multiplier(
                            background + batch,
                            False,
                            region.batch_multiplier(
                                background + batch
                            ),
                        ),
                    )
                    for batch in range(1, room + 1)
                )
                warm_curve = tuple(
                    (
                        batch,
                        option.batch_multiplier(
                            background + batch,
                            True,
                            region.batch_multiplier(
                                background + batch
                            ),
                        ),
                    )
                    for batch in range(1, room + 1)
                )
                options.append((
                    region_id,
                    replace(
                        option,
                        cold_ttft_ms=self._guarded_ttft_ms((
                            option.cold_ttft_ms
                            + background * cold_ttft_add
                        ), request, region_id, snapshot),
                        warm_ttft_ms=self._guarded_ttft_ms((
                            option.warm_ttft_ms
                            + background * warm_ttft_add
                        ), request, region_id, snapshot),
                        tpot_ms=(
                            option.tpot_ms
                            + background * selected_tpot_add
                        ),
                        cold_batch_energy_multipliers=cold_curve,
                        warm_batch_energy_multipliers=warm_curve,
                        cold_ttft_ms_per_additional_request=(
                            cold_ttft_add
                        ),
                        warm_ttft_ms_per_additional_request=(
                            warm_ttft_add
                        ),
                        cold_tpot_ms_per_additional_request=(
                            selected_tpot_add
                        ),
                        warm_tpot_ms_per_additional_request=(
                            selected_tpot_add
                        ),
                        cold_latency_curve=tuple((batch,
                            self._guarded_ttft_ms(option.latency(background + batch, False, region)[0], request, region_id, snapshot),
                            option.latency(background + batch, False, region)[1]) for batch in range(1, room + 1)) if option.cold_latency_curve else (),
                        warm_latency_curve=tuple((batch,
                            self._guarded_ttft_ms(option.latency(background + batch, True, region)[0], request, region_id, snapshot),
                            option.latency(background + batch, True, region)[1]) for batch in range(1, room + 1)) if option.warm_latency_curve else (),
                    ),
                ))
            adjusted_requests.append(
                replace(request, options=tuple(options), ttft_slo_ms=max(0, request.ttft_slo_ms - self._queue_wait_ms.get(request.request_id, 0)))
            )

        epoch = OracleEpoch(
            epoch_id=f"closed-loop:{self._batch_id}",
            carbon_lbs_per_mwh=tuple(
                sorted(
                    (region, float(value))
                    for region, value in carbon_lbs_per_mwh.items()
                )
            ),
            requests=tuple(adjusted_requests),
        )
        problem = OracleProblem(
            regions=adjusted_regions,
            epochs=(epoch,),
            initial_placements=tuple(
                sorted(self._placements.items())
            ),
            migration_edges=self.template.migration_edges,
        )
        problem.validate()
        try:
            solution = solve_online(problem, self.settings)
        except RuntimeError as error:
            if "feasible" not in str(error).lower():
                raise
            raise ClosedLoopCapacityError(str(error)) from error
        if not solution.steps:
            raise ClosedLoopCapacityError(
                "online planner returned no closed-loop step"
            )
        step = solution.steps[0]
        counts = Counter(region for _, region in step.assignments)
        assignments = tuple(
            ClosedLoopAssignment(
                request_id=request_id,
                region_id=region_id,
                planned_epoch_batch=counts[region_id],
                background_load=load[region_id],
                projected_total_load=(
                    load[region_id] + counts[region_id]
                ),
            )
            for request_id, region_id in step.assignments
        )

        capacities = {
            region.region_id: region.capacity
            for region in self.template.regions
        }
        if any(
            load[region] + counts[region] > capacities[region]
            for region in capacities
        ):
            raise AssertionError(
                "planner violated live-load capacity constraint"
            )
        self._guard_batch(step.assignments, snapshots)
        self._commit(assignments)

        result = ClosedLoopPlan(
            batch_id=self._batch_id,
            assignments=assignments,
            planner_time_ms=step.planner_time_ms,
            budget_exhausted=step.budget_exhausted,
            objective_carbon_g=step.cost.objective_carbon_g,
            load_before=tuple(sorted(load.items())),
        )
        self._batch_id += 1
        return result

    def complete(
        self,
        request_id: str,
        region_id: str,
        success: bool,
    ) -> None:
        if request_id not in self._reservations or self._reservations[request_id][0] != region_id:
            raise RuntimeError(
                f"completion without reservation in {region_id}"
            )
        self._reserved[region_id] -= 1
        del self._reservations[request_id]
        self._queue_wait_ms.pop(request_id, None)
        if success:
            request = self.request(request_id)
            self._placements[request.session_id] = region_id


@dataclass
class _PendingAssignment:
    request: RequestSpec
    snapshots: Mapping[str, RegionSnapshot]
    carbon_lbs_per_mwh: Mapping[str, float]
    future: asyncio.Future
    submitted_s: float


class AsyncClosedLoopCoordinator:
    """Micro-batches ready requests and atomically reserves their routes."""

    def __init__(
        self,
        planner: ClosedLoopPlanner,
        control_interval_ms: float = 100.0,
    ) -> None:
        if control_interval_ms < 0:
            raise ValueError("control_interval_ms must be non-negative")
        self.planner = planner
        self.control_interval_s = control_interval_ms / 1000.0
        self._lock = asyncio.Lock()
        self._pending: list[_PendingAssignment] = []
        self._flush_task: asyncio.Task | None = None
        self._plans: list[ClosedLoopPlan] = []
        self.snapshot_provider = None
        self._closed = False
        self.policy_name = getattr(planner, "policy_name", "joint_closed_loop_learned_future")
        self.reason = getattr(planner, "reason", "atomic closed-loop joint assignment")

    @property
    def plans(self) -> tuple[ClosedLoopPlan, ...]:
        return tuple(self._plans)

    async def assign(
        self,
        request: RequestSpec,
        snapshots: Mapping[str, RegionSnapshot],
        carbon_lbs_per_mwh: Mapping[str, float],
    ) -> ClosedLoopRuntimeDecision:
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        async with self._lock:
            if self._closed:
                raise RuntimeError("coordinator closed")
            self._pending.append(
                _PendingAssignment(
                    request=request,
                    snapshots=dict(snapshots),
                    carbon_lbs_per_mwh=dict(carbon_lbs_per_mwh),
                    future=future,
                    submitted_s=time.perf_counter(),
                )
            )
            self._ensure_flush_locked()
        try:
            return await future
        except asyncio.CancelledError:
            async with self._lock:
                reserved = self.planner._reservations.get(request.request_id)
                if reserved is not None:
                    self.planner.complete(request.request_id, reserved[0], False)
                self._pending = [item for item in self._pending if item.future is not future]
            raise

    async def complete(
        self,
        request_id: str,
        region_id: str,
        success: bool,
    ) -> None:
        async with self._lock:
            self.planner.complete(request_id, region_id, success)
            self._ensure_flush_locked()

    async def close(self) -> None:
        async with self._lock:
            self._closed = True
            task = self._flush_task
            self._flush_task = None
            pending = list(self._pending)
            self._pending.clear()
        if task is not None and task is not asyncio.current_task():
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
        for item in pending:
            if not item.future.done():
                item.future.set_exception(
                    RuntimeError("closed-loop coordinator closed")
                )

    def _ensure_flush_locked(self) -> None:
        if not self._pending:
            return
        if self._flush_task is None or self._flush_task.done():
            self._flush_task = asyncio.create_task(self._flush_after_delay())

    async def _flush_after_delay(self) -> None:
        await asyncio.sleep(max(0.001, self.control_interval_s))
        async with self._lock:
            self._flush_task = None
            self._flush_locked()
            self._ensure_flush_locked()

    def _flush_locked(self) -> None:
        now = time.perf_counter()
        kept = []
        for item in self._pending:
            if item.future.done():
                continue
            elapsed_ms = (now - item.submitted_s) * 1000
            if elapsed_ms >= item.request.ttft_slo_ms:
                item.future.set_exception(TimeoutError("no feasible route before TTFT deadline"))
                continue
            self.planner._queue_wait_ms[item.request.request_id] = elapsed_ms
            kept.append(item)
        self._pending = kept
        if not self._pending:
            return

        # Use the freshest observation in this micro-batch.  Internal
        # reservations prevent an older RegionClient snapshot from causing
        # oversubscription.
        latest = self._pending[-1]
        snapshots = self.snapshot_provider() if self.snapshot_provider else latest.snapshots
        load = self.planner._load(snapshots)
        capacities = {
            region.region_id: region.capacity
            for region in self.planner.template.regions
        }
        available = sum(
            max(0, capacities[region] - load[region])
            for region in capacities
        )
        if available < 1:
            return

        selected: list[_PendingAssignment] = []
        selected_sessions = {self.planner.request(key).session_id for key in self.planner._reservations}
        for item in self._pending:
            if item.request.session_id in selected_sessions:
                continue
            selected.append(item)
            selected_sessions.add(item.request.session_id)
            if len(selected) >= available:
                break
        if not selected:
            return

        try:
            while selected:
                try:
                    plan = self.planner.plan(
                        [item.request.request_id for item in selected], snapshots,
                        latest.carbon_lbs_per_mwh,
                    )
                    break
                except ClosedLoopCapacityError:
                    if len(selected) == 1:
                        raise
                    selected = selected[:max(1, len(selected) // 2)]
        except ClosedLoopCapacityError:
            return
        except BaseException as error:
            selected_ids = {id(item) for item in selected}
            self._pending = [
                item for item in self._pending
                if id(item) not in selected_ids
            ]
            for item in selected:
                if not item.future.done():
                    item.future.set_exception(error)
            return

        by_request = {
            assignment.request_id: assignment
            for assignment in plan.assignments
        }
        self._plans.append(plan)
        selected_ids = {id(item) for item in selected}
        self._pending = [
            item for item in self._pending
            if id(item) not in selected_ids
        ]
        for item in selected:
            assignment = by_request[item.request.request_id]
            if not item.future.done():
                item.future.set_result(
                    ClosedLoopRuntimeDecision(
                        assignment=assignment,
                        batch_id=plan.batch_id,
                        planner_time_ms=plan.planner_time_ms,
                        budget_exhausted=plan.budget_exhausted,
                        objective_carbon_g=plan.objective_carbon_g,
                        load_before=plan.load_before,
                    )
                )
