from __future__ import annotations

import hashlib
import itertools
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .carbon import carbon_grams


@dataclass(frozen=True)
class OracleRegion:
    region_id: str
    capacity: int
    batch_energy_multipliers: tuple[tuple[int, float], ...] = ((1, 1.0),)
    queue_ttft_ms_per_additional_request: float = 0.0
    tpot_ms_per_additional_request: float = 0.0

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "OracleRegion":
        curve = raw.get("batch_energy_multipliers") or {"1": 1.0}
        anchors = tuple(sorted((int(key), float(value)) for key, value in curve.items()))
        if not anchors or anchors[0][0] != 1:
            raise ValueError(
                f"region {raw.get('region_id')} batch curve must contain batch size 1"
            )
        if any(size < 1 or multiplier < 0.0 for size, multiplier in anchors):
            raise ValueError("batch sizes must be positive and multipliers non-negative")
        return cls(
            region_id=str(raw["region_id"]),
            capacity=int(raw["capacity"]),
            batch_energy_multipliers=anchors,
            queue_ttft_ms_per_additional_request=float(
                raw.get("queue_ttft_ms_per_additional_request", 0.0)
            ),
            tpot_ms_per_additional_request=float(
                raw.get("tpot_ms_per_additional_request", 0.0)
            ),
        )

    def batch_multiplier(self, batch_size: int) -> float:
        if batch_size < 1:
            raise ValueError("batch_size must be positive")
        anchors = self.batch_energy_multipliers
        if batch_size <= anchors[0][0]:
            return anchors[0][1]
        for (left_n, left_value), (right_n, right_value) in zip(
            anchors, anchors[1:]
        ):
            if batch_size <= right_n:
                fraction = (batch_size - left_n) / (right_n - left_n)
                return left_value + fraction * (right_value - left_value)
        return anchors[-1][1]


@dataclass(frozen=True)
class OracleOption:
    cold_energy_j: float
    warm_energy_j: float
    cold_ttft_ms: float
    warm_ttft_ms: float
    tpot_ms: float
    cold_batch_energy_multipliers: tuple[tuple[int, float], ...] = ()
    warm_batch_energy_multipliers: tuple[tuple[int, float], ...] = ()
    cold_ttft_ms_per_additional_request: float = 0.0
    warm_ttft_ms_per_additional_request: float = 0.0
    cold_tpot_ms_per_additional_request: float = 0.0
    warm_tpot_ms_per_additional_request: float = 0.0
    learned_future_energy_j: float | None = None
    in_domain: bool = True
    network_carbon_g: float = 0.0
    network_energy_j: float = 0.0
    cold_latency_curve: tuple[tuple[int, float, float], ...] = ()
    warm_latency_curve: tuple[tuple[int, float, float], ...] = ()

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "OracleOption":
        option = cls(
            cold_energy_j=float(raw["cold_energy_j"]),
            warm_energy_j=float(raw["warm_energy_j"]),
            cold_ttft_ms=float(raw["cold_ttft_ms"]),
            warm_ttft_ms=float(raw["warm_ttft_ms"]),
            tpot_ms=float(raw["tpot_ms"]),
            cold_batch_energy_multipliers=cls._curve(
                raw.get("cold_batch_energy_multipliers")
            ),
            warm_batch_energy_multipliers=cls._curve(
                raw.get("warm_batch_energy_multipliers")
            ),
            cold_ttft_ms_per_additional_request=float(
                raw.get("cold_ttft_ms_per_additional_request", 0.0)
            ),
            warm_ttft_ms_per_additional_request=float(
                raw.get("warm_ttft_ms_per_additional_request", 0.0)
            ),
            cold_tpot_ms_per_additional_request=float(
                raw.get("cold_tpot_ms_per_additional_request", 0.0)
            ),
            warm_tpot_ms_per_additional_request=float(
                raw.get("warm_tpot_ms_per_additional_request", 0.0)
            ),
            learned_future_energy_j=(
                None
                if raw.get("learned_future_energy_j") is None
                else float(raw["learned_future_energy_j"])
            ),
            in_domain=bool(raw.get("in_domain", True)),
            network_carbon_g=float(raw.get("network_carbon_g", 0)),
            network_energy_j=float(raw.get("network_energy_j", 0)),
            cold_latency_curve=tuple(tuple(row) for row in raw.get("cold_latency_curve", ())),
            warm_latency_curve=tuple(tuple(row) for row in raw.get("warm_latency_curve", ())),
        )
        numeric = (
            option.cold_energy_j,
            option.warm_energy_j,
            option.cold_ttft_ms,
            option.warm_ttft_ms,
            option.tpot_ms,
            option.cold_ttft_ms_per_additional_request,
            option.warm_ttft_ms_per_additional_request,
            option.cold_tpot_ms_per_additional_request,
            option.warm_tpot_ms_per_additional_request,
            option.network_carbon_g,
            option.network_energy_j,
        )
        if any(value < 0.0 for value in numeric):
            raise ValueError("energy and latency values must be non-negative")
        if (
            option.learned_future_energy_j is not None
            and option.learned_future_energy_j < 0.0
        ):
            raise ValueError("learned future energy must be non-negative")
        return option

    def latency(self, concurrent, warm, region):
        curve = self.warm_latency_curve if warm else self.cold_latency_curve
        if curve:
            candidates = [row for row in curve if row[0] >= concurrent]
            if not candidates:
                return float("inf"), float("inf")
            row = min(candidates)
            return row[1], row[2]
        additional = max(0, concurrent - 1)
        return (
            (self.warm_ttft_ms if warm else self.cold_ttft_ms) + additional * (
                region.queue_ttft_ms_per_additional_request + (self.warm_ttft_ms_per_additional_request if warm else self.cold_ttft_ms_per_additional_request)),
            self.tpot_ms + additional * (region.tpot_ms_per_additional_request + (
                self.warm_tpot_ms_per_additional_request if warm else self.cold_tpot_ms_per_additional_request)),
        )

    @staticmethod
    def _curve(raw: dict[str, Any] | None) -> tuple[tuple[int, float], ...]:
        if not raw:
            return ()
        curve = tuple(sorted((int(key), float(value)) for key, value in raw.items()))
        if curve[0][0] != 1:
            raise ValueError("option batch curve must contain batch size 1")
        if any(size < 1 or value < 0.0 for size, value in curve):
            raise ValueError("invalid option batch curve")
        return curve

    @staticmethod
    def _interpolate(curve: tuple[tuple[int, float], ...], batch_size: int) -> float:
        if batch_size <= curve[0][0]:
            return curve[0][1]
        for (left_n, left_value), (right_n, right_value) in zip(curve, curve[1:]):
            if batch_size <= right_n:
                fraction = (batch_size - left_n) / (right_n - left_n)
                return left_value + fraction * (right_value - left_value)
        return curve[-1][1]

    def batch_multiplier(
        self, batch_size: int, warm: bool, fallback: float
    ) -> float:
        curve = (
            self.warm_batch_energy_multipliers
            if warm else self.cold_batch_energy_multipliers
        )
        return self._interpolate(curve, batch_size) if curve else fallback


@dataclass(frozen=True)
class OracleRequest:
    request_id: str
    session_id: str
    ttft_slo_ms: float
    tpot_slo_ms: float
    options: tuple[tuple[str, OracleOption], ...]
    turn_id: int = 0
    workload: str = "agentic"
    prompt_tokens: int = 0
    max_output_tokens: int = 0
    shared_prefix_tokens: int = 0
    future_work_in_domain: bool = False

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "OracleRequest":
        return cls(
            request_id=str(raw["request_id"]),
            session_id=str(raw["session_id"]),
            turn_id=int(raw.get("turn_id", 0)),
            workload=str(raw.get("workload", "agentic")),
            prompt_tokens=int(raw.get("prompt_tokens", 0)),
            max_output_tokens=int(raw.get("max_output_tokens", 0)),
            shared_prefix_tokens=int(raw.get("shared_prefix_tokens", 0)),
            future_work_in_domain=bool(raw.get("future_work_in_domain", False)),
            ttft_slo_ms=float(raw["ttft_slo_ms"]),
            tpot_slo_ms=float(raw["tpot_slo_ms"]),
            options=tuple(
                sorted(
                    (str(region_id), OracleOption.from_dict(option))
                    for region_id, option in raw["options"].items()
                )
            ),
        )

    def option(self, region_id: str) -> OracleOption | None:
        return dict(self.options).get(region_id)


@dataclass(frozen=True)
class OracleEpoch:
    epoch_id: str
    carbon_lbs_per_mwh: tuple[tuple[str, float], ...]
    requests: tuple[OracleRequest, ...]

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "OracleEpoch":
        requests = tuple(OracleRequest.from_dict(row) for row in raw["requests"])
        sessions = [request.session_id for request in requests]
        if len(sessions) != len(set(sessions)):
            raise ValueError("an epoch may contain at most one request per session")
        return cls(
            epoch_id=str(raw["epoch_id"]),
            carbon_lbs_per_mwh=tuple(
                sorted(
                    (str(region_id), float(value))
                    for region_id, value in raw["carbon_lbs_per_mwh"].items()
                )
            ),
            requests=requests,
        )


@dataclass(frozen=True)
class MigrationEdge:
    source: str
    destination: str
    energy_j: float = 0.0
    delay_ms: float = 0.0

    @classmethod
    def from_dict(cls, key: str, raw: dict[str, Any]) -> "MigrationEdge":
        try:
            source, destination = key.split("->", 1)
        except ValueError as error:
            raise ValueError(f"invalid migration edge {key!r}; expected source->destination") from error
        edge = cls(
            source=source,
            destination=destination,
            energy_j=float(raw.get("energy_j", 0.0)),
            delay_ms=float(raw.get("delay_ms", 0.0)),
        )
        if edge.energy_j < 0.0 or edge.delay_ms < 0.0:
            raise ValueError("migration energy and delay must be non-negative")
        return edge


@dataclass(frozen=True)
class OracleProblem:
    regions: tuple[OracleRegion, ...]
    epochs: tuple[OracleEpoch, ...]
    initial_placements: tuple[tuple[str, str], ...] = ()
    migration_edges: tuple[MigrationEdge, ...] = ()

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "OracleProblem":
        if int(raw.get("schema_version", 1)) != 1:
            raise ValueError("unsupported oracle schema version")
        problem = cls(
            regions=tuple(OracleRegion.from_dict(row) for row in raw["regions"]),
            epochs=tuple(OracleEpoch.from_dict(row) for row in raw["epochs"]),
            initial_placements=tuple(
                sorted(
                    (str(session), str(region))
                    for session, region in raw.get("initial_placements", {}).items()
                )
            ),
            migration_edges=tuple(
                MigrationEdge.from_dict(key, value)
                for key, value in sorted(raw.get("migration", {}).items())
            ),
        )
        problem.validate()
        return problem

    @classmethod
    def from_json(cls, path: str | Path) -> "OracleProblem":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))

    def validate(self) -> None:
        region_ids = [region.region_id for region in self.regions]
        if len(region_ids) < 2 or len(region_ids) != len(set(region_ids)):
            raise ValueError("the oracle requires at least two unique regions")
        if any(region.capacity < 1 for region in self.regions):
            raise ValueError("region capacity must be positive")
        region_set = set(region_ids)
        request_ids: list[str] = []
        for epoch in self.epochs:
            carbon_regions = {region for region, _ in epoch.carbon_lbs_per_mwh}
            if carbon_regions != region_set:
                raise ValueError(
                    f"epoch {epoch.epoch_id} carbon regions do not match problem regions"
                )
            if any(value < 0.0 for _, value in epoch.carbon_lbs_per_mwh):
                raise ValueError("carbon intensity must be non-negative")
            for request in epoch.requests:
                request_ids.append(request.request_id)
                option_regions = {region for region, _ in request.options}
                if not option_regions or not option_regions <= region_set:
                    raise ValueError(f"invalid options for request {request.request_id}")
        if len(request_ids) != len(set(request_ids)):
            raise ValueError("request IDs must be globally unique")
        for session, region in self.initial_placements:
            if region not in region_set:
                raise ValueError(f"initial placement for {session} uses unknown region {region}")
        for edge in self.migration_edges:
            if edge.source not in region_set or edge.destination not in region_set:
                raise ValueError("migration edge references an unknown region")

    def canonical_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))


@dataclass(frozen=True)
class EpochCost:
    objective_carbon_g: float
    compute_carbon_g: float
    migration_carbon_g: float
    compute_energy_j: float
    migration_energy_j: float
    migrations: int
    network_carbon_g: float = 0.0
    network_energy_j: float = 0.0

    def plus(self, other: "EpochCost") -> "EpochCost":
        return EpochCost(
            objective_carbon_g=self.objective_carbon_g + other.objective_carbon_g,
            compute_carbon_g=self.compute_carbon_g + other.compute_carbon_g,
            migration_carbon_g=self.migration_carbon_g + other.migration_carbon_g,
            compute_energy_j=self.compute_energy_j + other.compute_energy_j,
            migration_energy_j=self.migration_energy_j + other.migration_energy_j,
            migrations=self.migrations + other.migrations,
            network_carbon_g=self.network_carbon_g + other.network_carbon_g,
            network_energy_j=self.network_energy_j + other.network_energy_j,
        )


ZERO_COST = EpochCost(0.0, 0.0, 0.0, 0.0, 0.0, 0)


@dataclass(frozen=True)
class OracleStep:
    epoch_id: str
    assignments: tuple[tuple[str, str], ...]
    warm_cache_hits: tuple[str, ...]
    cost: EpochCost
    placements_after: tuple[tuple[str, str], ...]


@dataclass(frozen=True)
class _Node:
    cost: EpochCost
    steps: tuple[OracleStep, ...]


@dataclass(frozen=True)
class OracleSolution:
    status: str
    exact: bool
    problem_sha256: str
    cost: EpochCost
    steps: tuple[OracleStep, ...]
    explored_transitions: int
    frontier_sizes: tuple[int, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _all_sessions(problem: OracleProblem) -> tuple[str, ...]:
    sessions = {session for session, _ in problem.initial_placements}
    for epoch in problem.epochs:
        sessions.update(request.session_id for request in epoch.requests)
    return tuple(sorted(sessions))


def _assignments(
    epoch: OracleEpoch,
    region_order: tuple[str, ...],
) -> Iterable[tuple[str, ...]]:
    choices: list[tuple[str, ...]] = []
    for request in epoch.requests:
        valid = tuple(
            region_id
            for region_id in region_order
            if (option := request.option(region_id)) is not None and option.in_domain
        )
        if not valid:
            return
        choices.append(valid)
    yield from itertools.product(*choices)


def _evaluate_assignment(
    problem: OracleProblem,
    epoch: OracleEpoch,
    placement: dict[str, str],
    assigned_regions: tuple[str, ...],
) -> tuple[EpochCost, tuple[str, ...]] | None:
    regions = {region.region_id: region for region in problem.regions}
    carbon = dict(epoch.carbon_lbs_per_mwh)
    migration = {
        (edge.source, edge.destination): edge for edge in problem.migration_edges
    }
    counts = {
        region_id: assigned_regions.count(region_id)
        for region_id in regions
    }
    if any(
        counts[region_id] > regions[region_id].capacity
        for region_id in regions
    ):
        return None

    compute_energy_j = 0.0
    compute_carbon_g = 0.0
    migration_energy_j = 0.0
    migration_carbon_g = 0.0
    migrations = 0
    network_carbon_g = 0.0
    network_energy_j = 0.0
    warm_hits: list[str] = []
    for request, destination in zip(epoch.requests, assigned_regions):
        option = request.option(destination)
        assert option is not None
        source = placement.get(request.session_id)
        warm = source == destination
        edge = migration.get((source, destination)) if source is not None else None
        migration_delay_ms = edge.delay_ms if edge is not None else 0.0
        region = regions[destination]
        concurrent = counts[destination]
        ttft_ms = (
            (option.warm_ttft_ms if warm else option.cold_ttft_ms)
            + migration_delay_ms
            + max(0, concurrent - 1) * region.queue_ttft_ms_per_additional_request
            + max(0, concurrent - 1) * (
                option.warm_ttft_ms_per_additional_request
                if warm else option.cold_ttft_ms_per_additional_request
            )
        )
        tpot_ms = (
            option.tpot_ms
            + max(0, concurrent - 1) * region.tpot_ms_per_additional_request
            + max(0, concurrent - 1) * (
                option.warm_tpot_ms_per_additional_request
                if warm else option.cold_tpot_ms_per_additional_request
            )
        )
        ttft_ms, tpot_ms = option.latency(concurrent, warm, region)
        ttft_ms += migration_delay_ms
        if not option.in_domain or ttft_ms > request.ttft_slo_ms or tpot_ms > request.tpot_slo_ms:
            return None

        solo_energy_j = option.warm_energy_j if warm else option.cold_energy_j
        allocated_energy_j = solo_energy_j * option.batch_multiplier(
            concurrent, warm, region.batch_multiplier(concurrent)
        )
        compute_energy_j += allocated_energy_j
        compute_carbon_g += carbon_grams(allocated_energy_j, carbon[destination])
        network_carbon_g += option.network_carbon_g
        network_energy_j += option.network_energy_j
        if warm:
            warm_hits.append(request.request_id)
        if source is not None and source != destination:
            migrations += 1
            if edge is not None:
                migration_energy_j += edge.energy_j
                average_intensity = 0.5 * (carbon[source] + carbon[destination])
                migration_carbon_g += carbon_grams(edge.energy_j, average_intensity)

    objective = compute_carbon_g + migration_carbon_g + network_carbon_g
    return (
        EpochCost(
            objective_carbon_g=objective,
            compute_carbon_g=compute_carbon_g,
            migration_carbon_g=migration_carbon_g,
            compute_energy_j=compute_energy_j,
            migration_energy_j=migration_energy_j,
            migrations=migrations,
            network_carbon_g=network_carbon_g,
            network_energy_j=network_energy_j,
        ),
        tuple(warm_hits),
    )


def solve_exact(problem: OracleProblem, max_states: int = 250_000, max_transitions: int = 2_000_000) -> OracleSolution:
    """Solve the finite-horizon routing problem exactly by dynamic programming.

    This solver is deliberately bounded to small instances.  It is an offline
    oracle for validating an online approximation, not a production scheduler.
    State consists of the last cache-bearing region for every session; actions
    are joint request-to-region assignments within an epoch.
    """
    if max_states < 1:
        raise ValueError("max_states must be positive")
    sessions = _all_sessions(problem)
    region_order = tuple(sorted(region.region_id for region in problem.regions))
    initial = dict(problem.initial_placements)
    initial_key = tuple(initial.get(session, "") for session in sessions)
    frontier: dict[tuple[str, ...], _Node] = {initial_key: _Node(ZERO_COST, ())}
    frontier_sizes = [1]
    explored = 0

    for epoch in problem.epochs:
        next_frontier: dict[tuple[str, ...], _Node] = {}
        for state_key, node in frontier.items():
            placement = {
                session: region
                for session, region in zip(sessions, state_key)
                if region
            }
            for assigned_regions in _assignments(epoch, region_order):
                explored += 1
                if explored > max_transitions:
                    raise RuntimeError(f"exact transition limit exceeded: {max_transitions}")
                evaluated = _evaluate_assignment(
                    problem, epoch, placement, assigned_regions
                )
                if evaluated is None:
                    continue
                epoch_cost, warm_hits = evaluated
                after = dict(placement)
                for request, region_id in zip(epoch.requests, assigned_regions):
                    after[request.session_id] = region_id
                after_key = tuple(after.get(session, "") for session in sessions)
                total = node.cost.plus(epoch_cost)
                assignments = tuple(
                    (request.request_id, region_id)
                    for request, region_id in zip(epoch.requests, assigned_regions)
                )
                step = OracleStep(
                    epoch_id=epoch.epoch_id,
                    assignments=assignments,
                    warm_cache_hits=warm_hits,
                    cost=epoch_cost,
                    placements_after=tuple(sorted(after.items())),
                )
                candidate = _Node(total, node.steps + (step,))
                incumbent = next_frontier.get(after_key)
                candidate_key = (total.objective_carbon_g, assignments)
                incumbent_key = (
                    incumbent.cost.objective_carbon_g,
                    incumbent.steps[-1].assignments,
                ) if incumbent is not None else None
                if incumbent is None or candidate_key < incumbent_key:
                    next_frontier[after_key] = candidate
                    if len(next_frontier) > max_states:
                        raise RuntimeError(f"exact frontier state limit exceeded: {max_states}")
        if not next_frontier:
            raise RuntimeError(f"epoch {epoch.epoch_id} has no feasible joint assignment")
        if len(next_frontier) > max_states:
            raise RuntimeError(
                f"exact frontier has {len(next_frontier)} states after epoch "
                f"{epoch.epoch_id}; max_states={max_states}"
            )
        frontier = next_frontier
        frontier_sizes.append(len(frontier))

    best_state, best = min(
        frontier.items(),
        key=lambda item: (item[1].cost.objective_carbon_g, item[0]),
    )
    del best_state
    digest = hashlib.sha256(problem.canonical_json().encode("utf-8")).hexdigest()
    return OracleSolution(
        status="OPTIMAL",
        exact=True,
        problem_sha256=digest,
        cost=best.cost,
        steps=best.steps,
        explored_transitions=explored,
        frontier_sizes=tuple(frontier_sizes),
    )
