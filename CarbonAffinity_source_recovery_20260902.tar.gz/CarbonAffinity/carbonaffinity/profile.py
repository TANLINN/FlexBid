from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

from .models import RequestSpec, RegionSnapshot
from .latency_surface import estimate_latency_surface


@dataclass(frozen=True)
class ServiceEstimate:
    energy_j: float
    ttft_ms: float
    tpot_ms: float
    solo_energy_j: float = 0.0
    projected_batch_size: int = 1
    allocated_energy_multiplier: float = 1.0


@dataclass(frozen=True)
class HardwareProfile:
    region_id: str
    accelerator: str
    model: str
    base_request_j: float
    cold_prefill_j_per_token: float
    cached_prefill_j_per_token: float
    decode_j_per_token: float
    base_ttft_ms: float
    cold_prefill_ms_per_token: float
    cached_prefill_ms_per_token: float
    base_tpot_ms: float
    queue_ttft_ms_per_request: float
    active_ttft_ms_per_request: float = 0.0
    tpot_ms_per_active_request: float = 0.0
    active_ttft_base_ms_per_request: float = 0.0
    active_ttft_ms_per_cold_token_per_request: float = 0.0
    tpot_active_base_ms_per_request: float = 0.0
    tpot_active_ms_per_cold_token_per_request: float = 0.0
    uncertainty_margin: float = 1.0
    max_prompt_tokens: int = 32768
    max_output_tokens: int = 2048
    max_concurrency: int = 32
    batch_energy_model: dict | None = None
    latency_surface_model: dict | None = None

    @classmethod
    def from_json(cls, path: str | Path) -> "HardwareProfile":
        with Path(path).open("r", encoding="utf-8") as handle:
            return cls(**json.load(handle))

    @staticmethod
    def _nearest_bucket(value: int, buckets: list[int]) -> int:
        value = max(1, value)
        return min(buckets, key=lambda bucket: abs(math.log2(value / bucket)))

    def _batch_curve(
        self, request: RequestSpec, cached_tokens: int
    ) -> dict[int, float] | None:
        model = self.batch_energy_model
        if not model:
            return None
        cells = model.get("cells") or {}
        prompt_buckets = sorted({int(key.split("|")[1]) for key in cells})
        output_buckets = sorted({int(key.split("|")[2]) for key in cells})
        if not prompt_buckets or not output_buckets:
            raw = model.get("global") or {}
            return {int(key): float(value) for key, value in raw.items()} or None
        prompt = self._nearest_bucket(request.prompt_tokens, prompt_buckets)
        output = self._nearest_bucket(request.max_output_tokens, output_buckets)
        cold = cells.get(f"cold|{prompt}|{output}")
        warm = cells.get(f"warm|{prompt}|{output}")
        if not cold or not warm:
            raw = model.get("global") or {}
            return {int(key): float(value) for key, value in raw.items()} or None
        warm_fraction = max(
            0.0, min(1.0, cached_tokens / max(1, request.prompt_tokens))
        )
        keys = sorted({int(key) for key in cold} & {int(key) for key in warm})
        return {
            key: (1.0 - warm_fraction) * float(cold[str(key)])
            + warm_fraction * float(warm[str(key)])
            for key in keys
        }

    @staticmethod
    def _total_batch_energy(curve: dict[int, float], batch_size: int) -> float:
        """Normalized total energy for a batch, monotonized and interpolated."""
        anchors = sorted(curve)
        if not anchors:
            return float(batch_size)
        totals: list[tuple[int, float]] = []
        running = 0.0
        for anchor in anchors:
            running = max(running, anchor * max(0.0, curve[anchor]))
            totals.append((anchor, running))
        n = max(1, min(batch_size, totals[-1][0]))
        for (left_n, left_total), (right_n, right_total) in zip(totals, totals[1:]):
            if n <= right_n:
                fraction = (n - left_n) / max(1, right_n - left_n)
                return left_total + fraction * (right_total - left_total)
        return totals[-1][1]

    def _allocated_batch_multiplier(
        self, request: RequestSpec, cached_tokens: int, active_requests: int
    ) -> tuple[int, float]:
        """Allocate measured batch energy evenly across concurrent requests.

        Finite differences of independently measured batch totals are too noisy
        to identify per-request marginal energy.  Average-cost attribution keeps
        the measured total-energy curve while avoiding that unstable derivative.
        """
        curve = self._batch_curve(request, cached_tokens)
        if not curve:
            return 1, 1.0
        maximum = max(curve)
        projected = max(1, min(active_requests + 1, maximum))
        total = self._total_batch_energy(curve, projected)
        return projected, max(0.0, total / projected)

    @staticmethod
    def _bracket(value: float, anchors: list[int]) -> tuple[int, int, float]:
        """Return bounding anchors and a clamped linear interpolation weight."""
        if not anchors:
            raise ValueError("latency surface has no anchors")
        if value <= anchors[0]:
            return anchors[0], anchors[0], 0.0
        if value >= anchors[-1]:
            return anchors[-1], anchors[-1], 0.0
        for left, right in zip(anchors, anchors[1:]):
            if value <= right:
                weight = (value - left) / (right - left)
                return left, right, weight
        return anchors[-1], anchors[-1], 0.0

    def _latency_surface_value(
        self,
        mode: str,
        metric: str,
        prompt_tokens: int,
        concurrency: int,
    ) -> float | None:
        model = self.latency_surface_model
        if not model:
            return None
        cells = model.get("cells") or {}
        prompt_buckets = sorted(int(value) for value in model.get("prompt_buckets", []))
        concurrency_buckets = sorted(
            int(value) for value in model.get("concurrency_buckets", [])
        )
        if not cells or not prompt_buckets or not concurrency_buckets:
            return None

        # Prompt lengths are geometrically spaced in calibration, so interpolate
        # in log2-token space.  Concurrency is interpolated in request space.
        log_prompt = math.log2(max(1, prompt_tokens))
        log_buckets = [math.log2(max(1, value)) for value in prompt_buckets]
        left_log, right_log, prompt_weight = self._bracket(log_prompt, log_buckets)
        left_prompt = prompt_buckets[log_buckets.index(left_log)]
        right_prompt = prompt_buckets[log_buckets.index(right_log)]
        left_concurrency, right_concurrency, concurrency_weight = self._bracket(
            max(1, concurrency), concurrency_buckets
        )

        def cell(prompt: int, active: int) -> float:
            row = cells.get(f"{mode}|{prompt}|{active}")
            if row is None or metric not in row:
                raise KeyError(f"missing latency surface cell {mode}|{prompt}|{active}:{metric}")
            return float(row[metric])

        try:
            low = (
                (1.0 - concurrency_weight) * cell(left_prompt, left_concurrency)
                + concurrency_weight * cell(left_prompt, right_concurrency)
            )
            high = (
                (1.0 - concurrency_weight) * cell(right_prompt, left_concurrency)
                + concurrency_weight * cell(right_prompt, right_concurrency)
            )
        except (KeyError, TypeError, ValueError):
            return None
        value = (1.0 - prompt_weight) * low + prompt_weight * high
        margins = model.get("one_sided_q95_residual_ms") or {}
        margin = float((margins.get(mode) or {}).get(metric, 0.0))
        return max(0.0, value + margin)

    def _surface_latency(
        self,
        request: RequestSpec,
        cached_tokens: int,
        snapshot: RegionSnapshot,
    ) -> tuple[float, float] | None:
        concurrency = max(1, snapshot.active_requests + 1)
        cold_ttft = self._latency_surface_value(
            "cold", "ttft_ms", request.prompt_tokens, concurrency
        )
        warm_ttft = self._latency_surface_value(
            "warm", "ttft_ms", request.prompt_tokens, concurrency
        )
        cold_tpot = self._latency_surface_value(
            "cold", "tpot_ms", request.prompt_tokens, concurrency
        )
        warm_tpot = self._latency_surface_value(
            "warm", "tpot_ms", request.prompt_tokens, concurrency
        )
        if None in (cold_ttft, warm_ttft, cold_tpot, warm_tpot):
            return None
        warm_fraction = max(
            0.0, min(1.0, cached_tokens / max(1, request.prompt_tokens))
        )
        ttft = (1.0 - warm_fraction) * cold_ttft + warm_fraction * warm_ttft
        tpot = (1.0 - warm_fraction) * cold_tpot + warm_fraction * warm_tpot
        # The surface captures active-request contention.  Queue waiting and
        # network RTT remain live, region-specific terms.
        ttft += snapshot.queue_depth * self.queue_ttft_ms_per_request
        ttft += snapshot.rtt_ms
        return ttft, tpot

    def estimate(self, request: RequestSpec, cached_tokens: int, snapshot: RegionSnapshot) -> ServiceEstimate:
        cached = max(0, min(cached_tokens, request.prompt_tokens))
        cold = request.prompt_tokens - cached
        solo_energy = (
            self.base_request_j
            + cold * self.cold_prefill_j_per_token
            + cached * self.cached_prefill_j_per_token
            + request.max_output_tokens * self.decode_j_per_token
        ) * self.uncertainty_margin
        batch_size, allocated_multiplier = self._allocated_batch_multiplier(
            request, cached, snapshot.active_requests
        )
        energy = solo_energy * allocated_multiplier
        surface_latency = estimate_latency_surface(
            self.latency_surface_model, request.prompt_tokens, cached,
            snapshot.active_requests + 1,
            request.max_output_tokens,
        )
        if surface_latency is not None:
            surface_latency = (
                surface_latency[0] + snapshot.queue_depth * self.queue_ttft_ms_per_request + snapshot.rtt_ms,
                surface_latency[1],
            )
        if surface_latency is None:
            ttft = (
                self.base_ttft_ms
                + cold * self.cold_prefill_ms_per_token
                + cached * self.cached_prefill_ms_per_token
                + snapshot.active_requests * self.active_ttft_ms_per_request
                + snapshot.active_requests * (
                    self.active_ttft_base_ms_per_request
                    + cold * self.active_ttft_ms_per_cold_token_per_request
                )
                + snapshot.queue_depth * self.queue_ttft_ms_per_request
                + snapshot.rtt_ms
            ) * self.uncertainty_margin
            tpot = (
                self.base_tpot_ms
                + snapshot.active_requests * self.tpot_ms_per_active_request
                + snapshot.active_requests * (
                    self.tpot_active_base_ms_per_request
                    + cold * self.tpot_active_ms_per_cold_token_per_request
                )
            ) * self.uncertainty_margin
        else:
            ttft, tpot = (
                value * self.uncertainty_margin for value in surface_latency
            )
        return ServiceEstimate(
            energy_j=max(0.0, energy), ttft_ms=max(0.0, ttft),
            tpot_ms=max(0.0, tpot),
            solo_energy_j=max(0.0, solo_energy),
            projected_batch_size=batch_size,
            allocated_energy_multiplier=allocated_multiplier,
        )

    def in_domain(self, request: RequestSpec, snapshot: RegionSnapshot) -> bool:
        return (
            request.prompt_tokens <= self.max_prompt_tokens
            and request.max_output_tokens <= self.max_output_tokens
            and snapshot.active_requests + snapshot.queue_depth + 1 <= self.max_concurrency
        )
