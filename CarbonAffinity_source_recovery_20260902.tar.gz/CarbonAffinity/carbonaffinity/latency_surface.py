from __future__ import annotations

import math


def _bracket(value: float, anchors: list[int]) -> tuple[int, int, float]:
    if not anchors:
        raise ValueError("latency surface has no anchors")
    if value <= anchors[0]:
        return anchors[0], anchors[0], 0.0
    if value >= anchors[-1]:
        return anchors[-1], anchors[-1], 0.0
    for left, right in zip(anchors, anchors[1:]):
        if value <= right:
            return left, right, (value - left) / (right - left)
    return anchors[-1], anchors[-1], 0.0


def _surface_value(
    model: dict,
    mode: str,
    metric: str,
    prompt_tokens: int,
    concurrency: int,
) -> float:
    cells = model["cells"]
    prompt_buckets = sorted(int(value) for value in model["prompt_buckets"])
    concurrency_buckets = sorted(
        int(value) for value in model["concurrency_buckets"]
    )
    method = str(model.get("interpolation", "linear"))
    if method in {"monotone_upper_envelope", "upper_envelope"}:
        if prompt_tokens > max(prompt_buckets) or concurrency > max(concurrency_buckets):
            return math.inf
        p = next(value for value in prompt_buckets if value >= prompt_tokens)
        c = next(value for value in concurrency_buckets if value >= max(1, concurrency))
        value = float(cells[f"{mode}|{p}|{c}"][metric])
        margin = float(model.get("one_sided_q95_residual_ms", {}).get(mode, {}).get(metric, 0))
        return value + margin
    prompt_logs = [math.log2(max(1, value)) for value in prompt_buckets]
    left_log, right_log, prompt_weight = _bracket(
        math.log2(max(1, prompt_tokens)), prompt_logs
    )
    left_prompt = prompt_buckets[prompt_logs.index(left_log)]
    right_prompt = prompt_buckets[prompt_logs.index(right_log)]
    left_c, right_c, concurrency_weight = _bracket(
        max(1, concurrency), concurrency_buckets
    )

    def cell(prompt: int, active: int) -> float:
        return float(cells[f"{mode}|{prompt}|{active}"][metric])

    low = (
        (1.0 - concurrency_weight) * cell(left_prompt, left_c)
        + concurrency_weight * cell(left_prompt, right_c)
    )
    high = (
        (1.0 - concurrency_weight) * cell(right_prompt, left_c)
        + concurrency_weight * cell(right_prompt, right_c)
    )
    value = (1.0 - prompt_weight) * low + prompt_weight * high
    margin = float(
        model.get("one_sided_q95_residual_ms", {})
        .get(mode, {})
        .get(metric, 0.0)
    )
    return max(0.0, value + margin)


def estimate_latency_surface(
    model: dict | None,
    prompt_tokens: int,
    cached_tokens: int,
    concurrency: int,
    output_tokens: int | None = None,
    runtime_cap: int = 784,
) -> tuple[float, float] | None:
    """Return calibrated server TTFT/TPOT, excluding queue delay and RTT."""
    if not model:
        return None
    if model.get("model_kind") == "residual_latency_monotone_candidate_v1":
        assumptions = model.get("assumptions") or {}
        if (
            output_tokens != int(assumptions.get("output_tokens", -1))
            or runtime_cap != int(assumptions.get("runtime_cap", -1))
        ):
            return math.inf, math.inf
        mode = "warm" if cached_tokens > 0 else "cold"
        coordinate = (
            (cached_tokens, prompt_tokens - cached_tokens, max(1, concurrency))
            if mode == "warm"
            else (prompt_tokens, max(1, concurrency))
        )
        try:
            surface = model["surfaces"][mode]
            axes_by_name = surface["axes"]
            names = (
                ("cached_tokens", "uncached_tokens", "concurrency")
                if mode == "warm"
                else ("prompt_tokens", "concurrency")
            )
            axes = [axes_by_name[name] for name in names]
            if any(
                value < anchors[0] or value > anchors[-1]
                for value, anchors in zip(coordinate, axes)
            ):
                return math.inf, math.inf
            chosen = tuple(
                next(anchor for anchor in anchors if anchor >= value)
                for value, anchors in zip(coordinate, axes)
            )
            cell = surface["cells"]["|".join(map(str, chosen))]["upper_ms"]
            margin = model["margin_ms"][mode]
            values = tuple(
                float(cell[metric]) + float(margin[metric])
                for metric in ("ttft_ms", "tpot_ms")
            )
        except (KeyError, StopIteration, TypeError, ValueError, ZeroDivisionError) as error:
            raise ValueError("configured residual latency surface is malformed") from error
        if not all(math.isfinite(value) and value >= 0 for value in values):
            raise ValueError("configured residual latency surface is malformed")
        return values
    try:
        cold_ttft = _surface_value(
            model, "cold", "ttft_ms", prompt_tokens, concurrency
        )
        warm_ttft = _surface_value(
            model, "warm", "ttft_ms", prompt_tokens, concurrency
        )
        cold_tpot = _surface_value(
            model, "cold", "tpot_ms", prompt_tokens, concurrency
        )
        warm_tpot = _surface_value(
            model, "warm", "tpot_ms", prompt_tokens, concurrency
        )
    except (KeyError, TypeError, ValueError, ZeroDivisionError) as error:
        raise ValueError("configured latency surface is malformed") from error
    warm_fraction = max(
        0.0, min(1.0, cached_tokens / max(1, prompt_tokens))
    )
    if not all(math.isfinite(value) for value in (cold_ttft, warm_ttft, cold_tpot, warm_tpot)):
        return math.inf, math.inf
    return (
        (1.0 - warm_fraction) * cold_ttft + warm_fraction * warm_ttft,
        (1.0 - warm_fraction) * cold_tpot + warm_fraction * warm_tpot,
    )
