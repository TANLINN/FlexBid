"""Recovered legacy backlog model. Co-run model supersedes this incomplete input space.

Loading coefficients does not certify them. Deployment must verify an external
validation/freeze record; unsupported inputs are rejected, never clamped safe.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

from .artifacts import finite_nonnegative


class PrefillBacklogTTFTModel:
    def __init__(self, payload: dict, source_sha256: str = ""):
        self.payload = payload
        self.model_sha256 = source_sha256
        self.own = sorted(int(x) for x in payload["own_token_anchors"])
        self.backlog = sorted(int(x) for x in payload["backlog_token_anchors"])
        if not self.own or not self.backlog:
            raise ValueError("empty anchors")
        self.cells = payload["cells"]
        for own in self.own:
            for backlog in self.backlog:
                finite_nonnegative(self.cells[f"{own}|{backlog}"]["conservative_ttft_ms"])

    @classmethod
    def from_json(cls, path):
        raw = Path(path).read_bytes()
        return cls(json.loads(raw), hashlib.sha256(raw).hexdigest())

    @classmethod
    def from_dict(cls, payload):
        return cls(payload, hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest())

    @classmethod
    def coerce(cls, value):
        if value is None or isinstance(value, cls):
            return value
        return cls.from_dict(value) if isinstance(value, dict) else cls.from_json(value)

    def predict(self, own_tokens, backlog_tokens):
        own_tokens = finite_nonnegative(own_tokens)
        backlog_tokens = finite_nonnegative(backlog_tokens)
        ood = own_tokens > self.own[-1] or backlog_tokens > self.backlog[-1]
        own = next((a for a in self.own if a >= own_tokens), self.own[-1])
        backlog = next((a for a in self.backlog if a >= backlog_tokens), self.backlog[-1])
        return {
            "conservative_ttft_ms": math.inf if ood else self.cells[f"{own}|{backlog}"]["conservative_ttft_ms"],
            "out_of_domain": ood, "model_sha256": self.model_sha256,
        }
