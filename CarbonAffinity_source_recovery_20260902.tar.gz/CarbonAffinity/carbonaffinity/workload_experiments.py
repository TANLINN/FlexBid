"""Deterministic, inspectable development/held-out case matrices."""
from __future__ import annotations

import itertools


def cases(kind: str) -> list[dict]:
    heldout = kind.endswith("validation")
    victims = [("cold_small", 4096, 0), ("warm_long", 16384, 15360), ("cold_long", 16384, 0)]
    if heldout and kind != "backlog_validation":
        victims = [("cold_2048", 2048, 0), ("warm_2048", 16384, 14336), ("cold_8192", 8192, 0)]
    baseline_repeats = 2 if heldout and kind != "backlog_validation" else 3
    if kind.startswith("corun"):
        tokens = [4096, 12288] if heldout else [8192, 16384]
        outputs = [96, 320] if heldout else [8, 192, 448]
        ordering = [("background_first", 375), ("victim_first", 500)] if heldout else [
            ("background_first", 0), ("background_first", 750), ("victim_first", 250), ("victim_first", 1000)]
    elif kind.startswith("active_decode"):
        tokens = [4096, 12288] if heldout else [8192, 16384]
        outputs = [96, 320] if heldout else [192, 448]
        ordering = [("decode_first", 125)] if heldout else [("decode_first", 0), ("decode_first", 250)]
    elif kind.startswith("backlog"):
        tokens = [4096, 12288, 20480] if heldout else [8192, 16384, 24576]
        outputs = [8]
        ordering = [("background_first", value) for value in ([125, 500, 1000, 1750] if heldout else [0, 250, 750, 1500])]
    else:
        raise ValueError(f"unknown measurement kind {kind}")
    result = []
    for mode, prompt, shared in victims:
        base = {"victim_mode": mode, "victim_prompt_tokens": prompt,
                "victim_shared_tokens": shared, "victim_output_tokens": 64}
        for repeat in range(baseline_repeats):
            result.append({**base, "order": "baseline", "offset_ms": 0,
                           "background_tokens": 0, "background_count": 0, "background_output_tokens": 0, "repeat": repeat})
        for p, n, d, (order, offset) in itertools.product(tokens, [1, 2], outputs, ordering):
            result.append({**base, "order": order, "offset_ms": offset,
                           "background_tokens": p, "background_count": n, "background_output_tokens": d, "repeat": 0})
    return [{"case_id": f"{kind}_{index:04d}", **row} for index, row in enumerate(result)]


def features_at_admission(own, victim_start, backgrounds):
    prefill = pending = decode = 0
    for row in backgrounds:
        start, first, end = row["start_ns"], row.get("first_ns"), row["end_ns"]
        if start <= victim_start < end:
            if first is None or victim_start < first:
                prefill += row["prompt_tokens"]
                pending += row["requested_output_tokens"]
            else:
                decode += row["requested_output_tokens"]
    return {"own": own, "prefill": prefill, "prefill_decode": pending, "active_decode": decode}
