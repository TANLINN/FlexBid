"""Small, fail-closed artifact primitives shared by recovery workflows."""
from __future__ import annotations

import hashlib
import json
import math
import os
import tempfile
from pathlib import Path


def sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: str | Path, payload: object, *, overwrite: bool = False) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        raise FileExistsError(f"preserving existing artifact: {path}")
    content = json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def read_rows(path: str | Path) -> list[dict]:
    path = Path(path)
    paths = sorted(path.rglob("measurements.jsonl")) if path.is_dir() else [path]
    if not paths:
        raise ValueError(f"no measurements found: {path}")
    rows = []
    for item in paths:
        with item.open(encoding="utf-8-sig") as handle:
            for number, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                row = json.loads(line)
                if not isinstance(row, dict):
                    raise ValueError(f"non-object row at {item}:{number}")
                rows.append(row)
    if not rows:
        raise ValueError("empty measurement dataset")
    return rows


def finite_nonnegative(value: object) -> float:
    value = float(value)
    if not math.isfinite(value) or value < 0:
        raise ValueError("expected finite nonnegative value")
    return value


def quantile(values, q: float) -> float:
    values = sorted(float(value) for value in values)
    if not values or not all(math.isfinite(v) for v in values):
        raise ValueError("quantile requires nonempty finite observations")
    index = (len(values) - 1) * q
    left = int(index)
    return values[left] + (index - left) * (values[min(left + 1, len(values) - 1)] - values[left])
