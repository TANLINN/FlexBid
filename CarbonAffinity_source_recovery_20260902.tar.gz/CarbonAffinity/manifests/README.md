Generate one manifest on each physical A800 host with
`scripts/collect_site_manifest.py`. The coordinator preflight requires distinct
GPU UUIDs and identical model `config.json` hashes.

