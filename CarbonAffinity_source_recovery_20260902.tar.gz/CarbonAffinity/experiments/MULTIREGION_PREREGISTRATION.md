# CarbonAffinity Multi-Region Evaluation Preregistration (Draft)

Status: **DRAFT — must be checksum-frozen before any GPU evaluation.**

This experiment is a new evaluation.  The completed development and held-out
windows are not used to tune the algorithm, thresholds, region set, or network
conditions.  Reading the old held-out results is permitted only for the
diagnostic route-decomposition analysis and is not a basis for changing V6.1.

## Questions

1. When the cleanest grid is not the minimum end-to-end carbon destination,
   does CarbonAffinity select the lower-carbon destination?
2. Does the answer change as the feasible choice set grows from 2 to 4 to 8
   regions?
3. On a terminal or short-horizon turn, does CarbonAffinity avoid a cold
   migration that cleanest-now performs?
4. Do any carbon gains preserve the preregistered TTFT and TPOT constraints?

## Frozen algorithm and policies

The CarbonAffinity implementation, energy profiles, carbon-risk calibration,
future-work fitting procedure, and all routing hyperparameters are frozen before
materializing evaluation results.  The future-work model may be refit with the
same frozen fitting procedure only after excluding every development, old
held-out, and new-evaluation session.  No coefficient or threshold is selected
using new-evaluation outcomes.

Primary policies:

- `pressure_only`: carbon-blind queue/latency placement.
- `sticky`: carbon-blind session affinity.
- `cleanest_now`: lowest forecast carbon intensity among the same SLO-feasible
  candidates used by CarbonAffinity.
- `carbon_affinity`: frozen V6.1 with lifecycle OOD guard.

`round_robin` may be reported as a secondary baseline.  An unconstrained
cleanest policy, if added, is an ablation and not the primary baseline.

## New workload split

- Select eight new one-hour TraceLab source windows.
- Exclude all development and prior held-out time ranges.
- Exclude every session appearing in development or prior held-out data.
- Require at least 80 usable requests and at least 10 repeated-session rows.
- Select even chronological quantiles of all eligible windows; do not rank
  windows by policy outcome, carbon spread, or expected advantage.
- Cap each window at 120 requests using source order.
- Record and freeze raw-input, selection-manifest, materialized-trace, carbon,
  configuration, code, and fitted-model SHA-256 hashes before GPU execution.

## Candidate regions

The source NESO CSV has 14 ordered regional series.  Use nested, evenly spaced
sets selected by column index, fixed before evaluation:

- 2 regions: indices `{0, 13}`.
- 4 regions: indices `{0, 4, 9, 13}`.
- 8 regions: indices `{0, 2, 4, 6, 7, 9, 11, 13}`.

The 8-region set therefore maps to North Scotland, North West England,
Yorkshire, South Wales, West Midlands, East England, South England, and South
East England.  Region IDs and source columns must be written into the frozen
manifest.

The primary routing experiment is the 8-region condition.  The 2- and 4-region
conditions are a candidate-set scaling ablation, not substitutes for the
8-region result.

## Hardware mapping

- Eight A800 GPUs, one serving endpoint per logical region in the 8-region
  condition.
- Rotate the logical-region-to-GPU mapping across repetitions with a
  preregistered cyclic permutation so a consistently efficient GPU is not
  permanently assigned to a consistently clean region.
- Keep the same Qwen3.5-27B model, serving configuration, and calibrated
  per-GPU profiles.
- Reset prefix cache before every policy/window cell.
- Run policies sequentially within a cell and randomize their order using
  frozen seeds.
- Verify no retention workload, calibration, duplicate campaign, or unrelated
  GPU process is active before every repetition.

This remains a same-host hardware-in-the-loop experiment.  It must not be
described as a physically deployed eight-geography GPU fleet.

## Network conditions

The same-host network has near-zero RTT and would make cleanest-now unusually
strong.  The primary multi-region run therefore requires actual delay injection
in the request path, not only an RTT value in the predictor.

Before execution, freeze one region-specific RTT vector derived without looking
at policy outcomes.  If no externally measured matrix is available, use the
predeclared synthetic sensitivity vector:

`[0, 20, 40, 60, 80, 100, 120, 150] ms`

assigned by the frozen region order.  Report a zero-RTT mechanism ablation and
a doubled-RTT stress analysis.  The paper must label synthetic RTTs as emulated.

The primary system uses recomputation at the target and does not claim live KV
transfer.  A modeled KV-transfer sensitivity analysis, if included, must be
reported separately with its bandwidth and energy assumptions.

## Repetitions and statistical unit

- Five repetitions.
- Each repetition aggregates all eight new windows.
- Paired policy comparisons use the same repetition, windows, configuration,
  and logical-region mapping.
- The primary uncertainty interval resamples repetitions and windows.  Report
  both repetition-level paired bootstrap and two-way repetition/window
  bootstrap.

## Endpoints

Primary endpoint:

- Measured GPU operational carbon settled against historical regional carbon
  intensity, paired CarbonAffinity versus SLO-constrained cleanest-now.

Secondary endpoints:

- measured GPU energy;
- TTFT and TPOT violation rates and p95 values;
- migrations per session and per repetition;
- observed prefix-cache hit tokens;
- request failures and fallback decisions;
- routing computation overhead.

Mechanism endpoints:

- observed cross-policy route match rate;
- same-state route match rate, using CarbonAffinity's exact candidate snapshot;
- number of route divergences by cause;
- number of terminal-turn and one-future-turn migrations;
- predicted and settled profile-carbon advantage on divergent requests;
- decomposition into intensity, allocated energy, state-loss energy, cache,
  batch size, queue, and RTT;
- fraction of divergent decisions whose predicted sign agrees with settled
  counterfactual sign.

Per-request counterfactual settled carbon is profile-based and must not be
called physically measured telemetry.  Physical telemetry is valid at the
policy/window aggregate level.

## Hypotheses

- H1: CarbonAffinity emits less measured operational carbon than pressure-only.
- H2: CarbonAffinity preserves TTFT/TPOT violation rates within a preregistered
  non-inferiority margin of 0.5 percentage points versus cleanest-now.
- H3: In the 8-region condition, CarbonAffinity has a positive paired carbon
  advantage over cleanest-now.
- H4: On terminal or one-future-turn same-state divergences with a warm
  incumbent, CarbonAffinity selects the lower settled profile-carbon option
  more often than cleanest-now.

H3 is not declared successful merely because the point estimate is positive;
its preregistered confidence interval must exclude zero.  Otherwise the result
is reported as statistical parity.

## Stop and exclusion rules

Exclude a policy/window cell only for a preregistered integrity failure:

- request failure;
- invalid or incomplete telemetry;
- wrong request count;
- missing completion marker;
- carbon trace not covering every energy interval;
- duplicate campaign or retention process using an experimental GPU;
- frozen checksum mismatch.

Do not exclude a valid cell because its result is unfavorable.  Rerun only the
failed cell with the same seed and frozen inputs, preserving the failure log.

