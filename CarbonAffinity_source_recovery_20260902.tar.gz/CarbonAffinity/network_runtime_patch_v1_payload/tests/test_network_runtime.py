from __future__ import annotations

import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from carbonaffinity.audit import audit_results
from carbonaffinity.models import RequestSpec
from carbonaffinity.region import RegionClient
from carbonaffinity.replay import run_replay


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, *_args) -> None:
        pass

    def do_GET(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b"{}")

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        json.loads(self.rfile.read(length))
        events = [
            {"choices": [{"text": "a"}], "usage": None},
            {
                "choices": [{"text": "b"}],
                "usage": {
                    "prompt_tokens": 10,
                    "completion_tokens": 2,
                    "prompt_tokens_details": {"cached_tokens": 7},
                },
            },
        ]
        body = "".join(
            f"data: {json.dumps(item)}\n\n" for item in events
        ) + "data: [DONE]\n\n"
        encoded = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


class NetworkRuntimeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self.thread = threading.Thread(
            target=self.server.serve_forever, daemon=True
        )
        self.thread.start()

    async def asyncTearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    async def test_delay_wire_bytes_energy_and_no_kv_transfer(self) -> None:
        port = self.server.server_address[1]
        client = RegionClient({
            "id": "network_region",
            "api_base": f"http://127.0.0.1:{port}/v1",
            "model": "mock",
            "admission_concurrency": 1,
            "network": {
                "enabled": True,
                "inject_delay": True,
                "rtt_ms": 40,
                "uplink_mbps": 100,
                "downlink_mbps": 100,
                "energy_kwh_per_gb": 1,
                "carbon_g_per_kwh": 500,
            },
        })
        try:
            result = await client.complete(
                RequestSpec("network", 0, 10, 2, "network"),
                [1] * 10,
            )
        finally:
            await client.close()

        self.assertTrue(result.success)
        self.assertGreaterEqual(result.ttft_ms or 0, 35)
        self.assertGreaterEqual(result.network_injected_delay_ms, 40)
        self.assertGreater(result.network_request_bytes, 0)
        self.assertGreater(result.network_response_bytes, 0)
        self.assertGreater(result.network_energy_j, 0)
        self.assertGreater(result.network_carbon_g, 0)
        self.assertEqual(result.kv_transfer_bytes, 0)

    async def test_replay_and_audit_expose_total_operational_carbon(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            port = self.server.server_address[1]
            profile = {
                "accelerator": "A800",
                "model": "mock",
                "base_request_j": 1,
                "cold_prefill_j_per_token": 1,
                "cached_prefill_j_per_token": 0.1,
                "decode_j_per_token": 1,
                "base_ttft_ms": 1,
                "cold_prefill_ms_per_token": 0.1,
                "cached_prefill_ms_per_token": 0.01,
                "base_tpot_ms": 1,
                "queue_ttft_ms_per_request": 1,
                "uncertainty_margin": 1,
            }
            for region in ("region_a", "region_b"):
                (root / f"{region}.json").write_text(
                    json.dumps({**profile, "region_id": region}),
                    encoding="utf-8",
                )
            (root / "carbon.csv").write_text(
                "timestamp,region_id,forecast_lbs_per_mwh,historical_lbs_per_mwh\n"
                "1000,region_a,500,500\n1000,region_b,100,100\n",
                encoding="utf-8",
            )
            trace = root / "trace.jsonl"
            trace.write_text(json.dumps({
                "request_id": "r1",
                "session_id": "s1",
                "arrival_ms": 0,
                "prompt_tokens": 10,
                "max_output_tokens": 2,
                "shared_prefix_tokens": 0,
                "prompt": "hello",
            }) + "\n", encoding="utf-8")
            network = {
                "enabled": True,
                "inject_delay": False,
                "rtt_ms": 10,
                "uplink_mbps": 100,
                "downlink_mbps": 100,
                "energy_kwh_per_gb": 1,
                "carbon_g_per_kwh": 500,
            }
            config = {
                "_root": str(root),
                "_config_path": str(root / "config.yaml"),
                "experiment": {"tokenizer": "unused"},
                "regions": [
                    {
                        "id": "region_a",
                        "api_base": f"http://127.0.0.1:{port}/v1",
                        "model": "mock",
                        "profile": "region_a.json",
                        "admission_concurrency": 1,
                    },
                    {
                        "id": "region_b",
                        "api_base": f"http://127.0.0.1:{port}/v1",
                        "model": "mock",
                        "profile": "region_b.json",
                        "admission_concurrency": 1,
                        "network": network,
                    },
                ],
                "carbon": {
                    "trace": "carbon.csv",
                    "clock_mode": "trace_relative",
                    "trace_start_timestamp": 1000,
                    "max_age_s": 100,
                },
                "routing": {
                    "policy": "carbon_affinity",
                    "migration_hysteresis_g": 0,
                },
                "lease": {"adaptive": False},
                "runtime": {"max_in_flight": 2},
            }
            output = root / "requests.jsonl"
            await run_replay(config, trace, output)
            row = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(row["decision"]["selected_region"], "region_b")
            self.assertGreater(row["completion"]["network_request_bytes"], 0)
            self.assertEqual(row["completion"]["kv_transfer_bytes"], 0)
            self.assertAlmostEqual(
                row["settled_total_operational_carbon_g"],
                row["settled_profile_carbon_g"]
                + row["settled_network_carbon_g"],
            )
            audit = audit_results(output)
            self.assertGreater(audit["network_request_bytes"], 0)
            self.assertEqual(audit["kv_transfer_bytes"], 0)


if __name__ == "__main__":
    unittest.main()
