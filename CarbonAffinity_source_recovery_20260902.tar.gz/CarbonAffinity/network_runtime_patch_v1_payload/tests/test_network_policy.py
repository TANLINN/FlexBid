from __future__ import annotations

import unittest

from carbonaffinity.carbon import CarbonTrace, _CarbonRow
from carbonaffinity.models import RegionSnapshot, RequestSpec
from carbonaffinity.network import NetworkSpec
from carbonaffinity.policy import PolicySettings, RouterPolicy
from carbonaffinity.profile import HardwareProfile
from carbonaffinity.state import StateDirectory


def _profile(region: str) -> HardwareProfile:
    return HardwareProfile(
        region_id=region,
        accelerator="A800",
        model="test",
        base_request_j=0,
        cold_prefill_j_per_token=1.0,
        cached_prefill_j_per_token=0.01,
        decode_j_per_token=0,
        base_ttft_ms=10,
        cold_prefill_ms_per_token=0.1,
        cached_prefill_ms_per_token=0.001,
        base_tpot_ms=10,
        queue_ttft_ms_per_request=0,
    )


class NetworkPolicyTests(unittest.TestCase):
    def _carbon(self) -> CarbonTrace:
        return CarbonTrace(
            {
                "region_a": [_CarbonRow(1000, 100, 100)],
                "region_b": [_CarbonRow(1000, 110, 110)],
            },
            max_age_s=100,
        )

    def test_total_carbon_can_diverge_from_cleanest_grid(self) -> None:
        carbon = self._carbon()
        snapshots = {
            "region_a": RegionSnapshot(
                "region_a", 0, 0,
                network=NetworkSpec(
                    enabled=True,
                    energy_kwh_per_gb=1000,
                    carbon_g_per_kwh=1000,
                ).to_dict(),
            ),
            "region_b": RegionSnapshot(
                "region_b", 0, 0,
                network=NetworkSpec(enabled=True).to_dict(),
            ),
        }
        profiles = {
            "region_a": _profile("region_a"),
            "region_b": _profile("region_b"),
        }
        request = RequestSpec("r", 0, 1000, 1, "s")
        proposed = RouterPolicy(
            PolicySettings(name="carbon_affinity", migration_hysteresis_g=0),
            carbon, profiles, StateDirectory(),
        ).decide(request, snapshots, 1001, 1001)
        cleanest = RouterPolicy(
            PolicySettings(name="cleanest_now"),
            carbon, profiles, StateDirectory(),
        ).decide(request, snapshots, 1001, 1001)

        self.assertEqual(proposed.selected_region, "region_b")
        self.assertEqual(cleanest.selected_region, "region_a")

    def test_network_ttft_prunes_infeasible_region_for_every_policy(self) -> None:
        carbon = self._carbon()
        snapshots = {
            "region_a": RegionSnapshot(
                "region_a", 0, 0,
                network=NetworkSpec(enabled=True, rtt_ms=200).to_dict(),
            ),
            "region_b": RegionSnapshot(
                "region_b", 0, 0,
                network=NetworkSpec(enabled=True).to_dict(),
            ),
        }
        profiles = {
            "region_a": _profile("region_a"),
            "region_b": _profile("region_b"),
        }
        for name in (
            "pressure_only", "cleanest_now", "sticky", "carbon_affinity"
        ):
            decision = RouterPolicy(
                PolicySettings(name=name),
                carbon, profiles, StateDirectory(),
            ).decide(
                RequestSpec(
                    name, 0, 10, 1, name, ttft_slo_ms=100
                ),
                snapshots, 1001, 1001,
            )
            self.assertEqual(decision.selected_region, "region_b", name)


if __name__ == "__main__":
    unittest.main()
