from __future__ import annotations

import hashlib
import json
import shutil
import sys
import time
import atexit
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    "carbonaffinity/network.py": "d1ac1783058170666adbd9c195dd72f5755ce061a0a9a444e72e1c96a1f07ca2",
    "carbonaffinity/models.py": "20cf2951af864719e65a4e0b44978ea95df882962461c88f14ae1efc4b3f446d",
    "carbonaffinity/policy.py": "cdac2e269c5fc53ed4ec1f80e36e377a92684f109b2affb7aa0d28aa71a1e244",
    "carbonaffinity/region.py": "b935300ba40ef85e65e704f58ecbad16203c2c199200d55a13bccb216f8b52c5",
    "carbonaffinity/replay.py": "ac31f585b4d5f4d9c32bf0ee4e4701ca6dd00a97a2bbd27f4d72f1dc39725ddd",
    "carbonaffinity/audit.py": "652f5bfd08e13377d29e795c6c07b7c8409f3fda3c88ad1f099b223b694365ca",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one target, found {count}")
    return text.replace(old, new, 1)


def patch(relative: str, replacements: list[tuple[str, str, str]]) -> None:
    path = ROOT / relative
    text = path.read_text(encoding="utf-8")
    for old, new, label in replacements:
        text = replace_once(text, old, new, f"{relative}:{label}")
    path.write_text(text, encoding="utf-8")


def main() -> None:
    mismatches = {
        relative: {"expected": expected, "actual": digest(ROOT / relative)}
        for relative, expected in EXPECTED.items()
        if digest(ROOT / relative) != expected
    }
    if mismatches:
        print(json.dumps({"status": "HASH_MISMATCH", "files": mismatches}, indent=2))
        raise SystemExit(2)

    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    backup = ROOT / "results" / f"network_runtime_backup_{stamp}"
    for relative in EXPECTED:
        source = ROOT / relative
        destination = backup / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)

    rollback_state = {"complete": False}

    def rollback_unfinished_install() -> None:
        if rollback_state["complete"]:
            return
        for relative in EXPECTED:
            shutil.copy2(backup / relative, ROOT / relative)
        print("NETWORK_RUNTIME_PATCH_ROLLED_BACK", file=sys.stderr)

    atexit.register(rollback_unfinished_install)
    (ROOT / "results" / "network_runtime_backup_latest.txt").write_text(
        str(backup.resolve()), encoding="utf-8"
    )

    patch("carbonaffinity/network.py", [
        (
            '    @classmethod\n    def from_region_config(cls, config: dict[str, Any]) -> "NetworkSpec":\n',
            '    @classmethod\n    def from_dict(cls, raw: dict[str, Any] | None) -> "NetworkSpec":\n'
            '        if raw is None:\n            return cls()\n'
            '        if not isinstance(raw, dict):\n'
            '            raise ValueError("network specification must be a mapping")\n'
            '        # Reuse the region parser so validation has one implementation.\n'
            '        return cls.from_region_config({"network": raw})\n\n'
            '    @classmethod\n    def from_region_config(cls, config: dict[str, Any]) -> "NetworkSpec":\n',
            "from_dict",
        ),
        (
            '    def to_dict(self) -> dict[str, Any]:\n        return asdict(self)\n',
            '    def to_dict(self) -> dict[str, Any]:\n        return asdict(self)\n\n'
            '    @property\n    def carbon_g_per_byte(self) -> float:\n'
            '        return self.energy_kwh_per_gb * self.carbon_g_per_kwh / 1.0e9\n',
            "carbon_per_byte",
        ),
    ])

    patch("carbonaffinity/models.py", [
        (
            '    rtt_ms: float = 0.0\n    capacity: int = 1\n',
            '    rtt_ms: float = 0.0\n    capacity: int = 1\n'
            '    network: dict[str, Any] | None = None\n',
            "snapshot_network",
        ),
        (
            '    solo_energy_j: float = 0.0\n    reason: str = ""\n',
            '    solo_energy_j: float = 0.0\n'
            '    compute_forecast_carbon_g: float | None = None\n'
            '    network_forecast_carbon_g: float = 0.0\n'
            '    network_energy_j: float = 0.0\n'
            '    network_ttft_ms: float = 0.0\n'
            '    network_completion_ms: float = 0.0\n'
            '    network_request_bytes: int = 0\n'
            '    network_response_bytes: int = 0\n'
            '    network_carbon_g_per_byte: float = 0.0\n'
            '    network_prompt_bytes_per_token: float = 0.0\n'
            '    network_output_bytes_per_token: float = 0.0\n'
            '    reason: str = ""\n',
            "candidate_network",
        ),
        (
            '    cached_prompt_tokens_observed: int | None\n    error: str | None = None\n',
            '    cached_prompt_tokens_observed: int | None\n'
            '    network_request_bytes: int = 0\n'
            '    network_response_bytes: int = 0\n'
            '    network_first_response_bytes: int = 0\n'
            '    network_injected_delay_ms: float = 0.0\n'
            '    network_energy_j: float = 0.0\n'
            '    network_carbon_g: float = 0.0\n'
            '    kv_transfer_bytes: int = 0\n'
            '    error: str | None = None\n',
            "completion_network",
        ),
    ])

    patch("carbonaffinity/policy.py", [
        (
            'from dataclasses import dataclass\n',
            'from dataclasses import dataclass, replace\n',
            "replace_import",
        ),
        (
            'from .models import CandidateEstimate, RegionSnapshot, RequestSpec, RouteDecision\n',
            'from .models import CandidateEstimate, RegionSnapshot, RequestSpec, RouteDecision\n'
            'from .network import NetworkSpec, estimate_network\n',
            "network_import",
        ),
        (
            '            service = self.profiles[region_id].estimate(request, cached, snapshot)\n',
            '            network_spec = NetworkSpec.from_dict(snapshot.network)\n'
            '            network = estimate_network(\n'
            '                network_spec,\n'
            '                prompt_tokens=request.prompt_tokens,\n'
            '                output_tokens=request.max_output_tokens,\n'
            '            )\n'
            '            # Replace legacy RTT only when the explicit network model is on.\n'
            '            service_snapshot = (\n'
            '                replace(snapshot, rtt_ms=network.ttft_ms)\n'
            '                if network_spec.enabled else snapshot\n'
            '            )\n'
            '            service = self.profiles[region_id].estimate(\n'
            '                request, cached, service_snapshot\n'
            '            )\n',
            "network_estimate",
        ),
        (
            '            carbon_g = (\n'
            '                carbon_grams(service.energy_j, signal)\n'
            '                if signal is not None else None\n'
            '            )\n',
            '            compute_carbon_g = (\n'
            '                carbon_grams(service.energy_j, signal)\n'
            '                if signal is not None else None\n'
            '            )\n'
            '            carbon_g = (\n'
            '                compute_carbon_g + network.carbon_g\n'
            '                if compute_carbon_g is not None else None\n'
            '            )\n',
            "total_carbon",
        ),
        (
            '            fully_warm = self.profiles[region_id].estimate(request, request.prompt_tokens, snapshot)\n',
            '            fully_warm = self.profiles[region_id].estimate(\n'
            '                request, request.prompt_tokens, service_snapshot\n'
            '            )\n',
            "warm_snapshot",
        ),
        (
            '                solo_energy_j=service.solo_energy_j,\n'
            '            ))\n',
            '                solo_energy_j=service.solo_energy_j,\n'
            '                compute_forecast_carbon_g=compute_carbon_g,\n'
            '                network_forecast_carbon_g=network.carbon_g,\n'
            '                network_energy_j=network.energy_j,\n'
            '                network_ttft_ms=network.ttft_ms,\n'
            '                network_completion_ms=network.completion_ms,\n'
            '                network_request_bytes=network.request_bytes,\n'
            '                network_response_bytes=network.response_bytes,\n'
            '                network_carbon_g_per_byte=network_spec.carbon_g_per_byte,\n'
            '                network_prompt_bytes_per_token=network_spec.prompt_bytes_per_token,\n'
            '                network_output_bytes_per_token=network_spec.output_bytes_per_token,\n'
            '            ))\n',
            "candidate_values",
        ),
        (
            '            incumbent_total_g = carbon_grams(\n'
            '                incumbent_total_j,\n'
            '                incumbent.forecast_lbs_per_mwh,\n'
            '            )\n'
            '            cleanest_total_g = carbon_grams(\n'
            '                cleanest_total_j,\n'
            '                cleanest.forecast_lbs_per_mwh,\n'
            '            )\n',
            '            incumbent_total_g = (\n'
            '                float(incumbent.forecast_carbon_g or 0.0)\n'
            '                + carbon_grams(\n'
            '                    incumbent_total_j - incumbent.energy_j,\n'
            '                    incumbent.forecast_lbs_per_mwh,\n'
            '                )\n'
            '                + self._future_work_network_g(incumbent, future_work)\n'
            '            )\n'
            '            cleanest_total_g = (\n'
            '                float(cleanest.forecast_carbon_g or 0.0)\n'
            '                + carbon_grams(\n'
            '                    cleanest_total_j - cleanest.energy_j,\n'
            '                    cleanest.forecast_lbs_per_mwh,\n'
            '                )\n'
            '                + self._future_work_network_g(cleanest, future_work)\n'
            '            )\n',
            "lifecycle_network",
        ),
        (
            '    def _expected_future_work(\n',
            '    @staticmethod\n'
            '    def _future_work_network_g(\n'
            '        candidate: CandidateEstimate,\n'
            '        future_work: dict[str, float],\n'
            '    ) -> float:\n'
            '        prompt_tokens = (\n'
            '            float(future_work.get("future_cold_tokens", 0.0))\n'
            '            + float(future_work.get("future_cached_tokens", 0.0))\n'
            '        )\n'
            '        output_tokens = float(\n'
            '            future_work.get("future_output_tokens", 0.0)\n'
            '        )\n'
            '        future_bytes = (\n'
            '            prompt_tokens * candidate.network_prompt_bytes_per_token\n'
            '            + output_tokens * candidate.network_output_bytes_per_token\n'
            '        )\n'
            '        return max(0.0, future_bytes) * candidate.network_carbon_g_per_byte\n\n'
            '    def _expected_future_work(\n',
            "future_network_method",
        ),
    ])

    patch("carbonaffinity/region.py", [
        (
            'from .models import CompletionResult, RegionSnapshot, RequestSpec\n',
            'from .models import CompletionResult, RegionSnapshot, RequestSpec\n'
            'from .network import NetworkSpec, estimate_network, transfer_ms\n',
            "network_import",
        ),
        (
            '        self.rtt_ms = float(config.get("rtt_ms", 0.0))\n',
            '        self.rtt_ms = float(config.get("rtt_ms", 0.0))\n'
            '        self.network = NetworkSpec.from_region_config(config)\n',
            "network_config",
        ),
        (
            '            capacity=self.capacity,\n        )\n',
            '            capacity=self.capacity,\n'
            '            network=self.network.to_dict(),\n'
            '        )\n',
            "snapshot_network",
        ),
        (
            '        cached: int | None = None\n        status: int | None = None\n',
            '        cached: int | None = None\n'
            '        network_response_bytes = 0\n'
            '        network_first_response_bytes = 0\n'
            '        network_injected_delay_ms = 0.0\n'
            '        response_propagation_injected = False\n'
            '        status: int | None = None\n',
            "network_counters",
        ),
        (
            '        if cache_salt is not None:\n'
            '            payload["cache_salt"] = cache_salt\n'
            '        try:\n'
            '            async with self._client.stream("POST", f"{self.api_base}/completions", json=payload) as response:\n',
            '        if cache_salt is not None:\n'
            '            payload["cache_salt"] = cache_salt\n'
            '        network_request_bytes = len(\n'
            '            json.dumps(\n'
            '                payload, ensure_ascii=False, separators=(",", ":")\n'
            '            ).encode("utf-8")\n'
            '        )\n'
            '        try:\n'
            '            if self.network.enabled and self.network.inject_delay:\n'
            '                upload_delay_ms = (\n'
            '                    self.network.rtt_ms / 2.0\n'
            '                    + transfer_ms(network_request_bytes, self.network.uplink_mbps)\n'
            '                )\n'
            '                await asyncio.sleep(upload_delay_ms / 1000.0)\n'
            '                network_injected_delay_ms += upload_delay_ms\n'
            '            async with self._client.stream("POST", f"{self.api_base}/completions", json=payload) as response:\n',
            "upload_delay",
        ),
        (
            '                async for line in response.aiter_lines():\n'
            '                    if not line.startswith("data:"):\n',
            '                async for line in response.aiter_lines():\n'
            '                    wire_bytes = len((line + "\\n").encode("utf-8"))\n'
            '                    network_response_bytes += wire_bytes\n'
            '                    if self.network.enabled and self.network.inject_delay:\n'
            '                        line_delay_ms = transfer_ms(\n'
            '                            wire_bytes, self.network.downlink_mbps\n'
            '                        )\n'
            '                        if not response_propagation_injected:\n'
            '                            line_delay_ms += self.network.rtt_ms / 2.0\n'
            '                            response_propagation_injected = True\n'
            '                        await asyncio.sleep(line_delay_ms / 1000.0)\n'
            '                        network_injected_delay_ms += line_delay_ms\n'
            '                    if not line.startswith("data:"):\n',
            "download_delay",
        ),
        (
            '                        if first_perf_ns is None:\n'
            '                            first_perf_ns = now\n',
            '                        if first_perf_ns is None:\n'
            '                            first_perf_ns = now\n'
            '                            network_first_response_bytes = network_response_bytes\n',
            "first_response",
        ),
        (
            '        completed_wall_ns = dispatch_wall_ns + completed_perf_ns - dispatch_perf_ns\n'
            '        return CompletionResult(\n',
            '        completed_wall_ns = dispatch_wall_ns + completed_perf_ns - dispatch_perf_ns\n'
            '        network_actual = estimate_network(\n'
            '            self.network,\n'
            '            prompt_tokens=request.prompt_tokens,\n'
            '            output_tokens=completion_tokens,\n'
            '            request_bytes=network_request_bytes,\n'
            '            response_bytes=network_response_bytes,\n'
            '            first_response_bytes=network_first_response_bytes,\n'
            '        )\n'
            '        return CompletionResult(\n',
            "actual_network",
        ),
        (
            '            cached_prompt_tokens_observed=cached,\n'
            '            error=error,\n',
            '            cached_prompt_tokens_observed=cached,\n'
            '            network_request_bytes=network_actual.request_bytes,\n'
            '            network_response_bytes=network_actual.response_bytes,\n'
            '            network_first_response_bytes=network_actual.first_response_bytes,\n'
            '            network_injected_delay_ms=network_injected_delay_ms,\n'
            '            network_energy_j=network_actual.energy_j,\n'
            '            network_carbon_g=network_actual.carbon_g,\n'
            '            kv_transfer_bytes=0,\n'
            '            error=error,\n',
            "completion_values",
        ),
    ])

    patch("carbonaffinity/replay.py", [
        (
            '            if result.success:\n',
            '            settled_total_operational_carbon_g = (\n'
            '                settled_profile_carbon_g + result.network_carbon_g\n'
            '                if settled_profile_carbon_g is not None else None\n'
            '            )\n'
            '            if result.success:\n',
            "settled_total",
        ),
        (
            '                "forecast_profile_carbon_g": selected.forecast_carbon_g,\n'
            '                "settled_profile_carbon_g": settled_profile_carbon_g,\n',
            '                "forecast_profile_carbon_g": selected.compute_forecast_carbon_g,\n'
            '                "settled_profile_carbon_g": settled_profile_carbon_g,\n'
            '                "forecast_network_carbon_g": selected.network_forecast_carbon_g,\n'
            '                "settled_network_carbon_g": result.network_carbon_g,\n'
            '                "forecast_total_operational_carbon_g": selected.forecast_carbon_g,\n'
            '                "settled_total_operational_carbon_g": settled_total_operational_carbon_g,\n'
            '                "network_accounting_semantics": (\n'
            '                    "full prompt request bytes plus streamed response bytes; "\n'
            '                    "KV transfer bytes are always zero"\n'
            '                ),\n',
            "record_network",
        ),
    ])

    patch("carbonaffinity/audit.py", [
        (
            '        "profile_settled_carbon_g": sum(float(row.get("settled_profile_carbon_g") or 0) for row in rows),\n',
            '        "profile_settled_carbon_g": sum(float(row.get("settled_profile_carbon_g") or 0) for row in rows),\n'
            '        "network_forecast_carbon_g": sum(float(row.get("forecast_network_carbon_g") or 0) for row in rows),\n'
            '        "network_settled_carbon_g": sum(float(row.get("settled_network_carbon_g") or 0) for row in rows),\n'
            '        "network_energy_j": sum(float(row["completion"].get("network_energy_j") or 0) for row in rows),\n'
            '        "network_request_bytes": sum(int(row["completion"].get("network_request_bytes") or 0) for row in rows),\n'
            '        "network_response_bytes": sum(int(row["completion"].get("network_response_bytes") or 0) for row in rows),\n'
            '        "kv_transfer_bytes": sum(int(row["completion"].get("kv_transfer_bytes") or 0) for row in rows),\n'
            '        "total_forecast_operational_carbon_g": sum(float(row.get("forecast_total_operational_carbon_g") or row.get("forecast_profile_carbon_g") or 0) for row in rows),\n'
            '        "total_settled_operational_carbon_g": sum(float(row.get("settled_total_operational_carbon_g") or row.get("settled_profile_carbon_g") or 0) for row in rows),\n',
            "summary_network",
        ),
        (
            '        summary["measured_operational_carbon_g"] = sum(item["operational_carbon_g"] for item in per_region)\n',
            '        gpu_operational_carbon_g = sum(\n'
            '            item["operational_carbon_g"] for item in per_region\n'
            '        )\n'
            '        summary["measured_gpu_operational_carbon_g"] = gpu_operational_carbon_g\n'
            '        summary["measured_operational_carbon_g"] = (\n'
            '            gpu_operational_carbon_g\n'
            '            + summary["network_settled_carbon_g"]\n'
            '        )\n',
            "measured_total",
        ),
    ])

    installed = {
        relative: digest(ROOT / relative) for relative in EXPECTED
    }
    (backup / "INSTALL_MANIFEST.json").write_text(
        json.dumps({
            "schema_version": 1,
            "backup": str(backup.resolve()),
            "installed_hashes": installed,
        }, indent=2),
        encoding="utf-8",
    )
    rollback_state["complete"] = True
    print("NETWORK_RUNTIME_PATCH_APPLIED")
    print("BACKUP =", backup.resolve())
    print(json.dumps(installed, indent=2))


if __name__ == "__main__":
    main()
