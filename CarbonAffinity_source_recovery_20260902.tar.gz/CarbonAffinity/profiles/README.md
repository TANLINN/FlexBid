# Region profiles

`region_a.json` and `region_b.json` are intentionally not shipped with guessed
numbers. Generate one profile on each physical A800 with
`scripts/calibrate_region.py`, then copy both files to this directory. The main
experiment preflight rejects a profile whose region ID or model does not match
the experiment configuration.

