# CarbonAffinity paper review log

Date: 2026-08-28

This log records two review--revision cycles over `latex/main.tex`. The paper is
currently a research/design draft: the joint online planner and its final
evaluation are not yet complete.

## Literature patterns used in the rewrite

- Recent systems papers such as Sarathi-Serve and VTC start from a concrete
  serving-specific failure mode, define the resource/cost abstraction that
  makes generic scheduling insufficient, and derive a mechanism from that
  structure.
- Stateful systems such as CachedAttention, Mooncake, Continuum, SYMPHONY, and
  Agentix establish that KV/program state and future dependencies are real
  serving concerns.
- Cleanest-grid routing and GAR establish carbon-aware LLM routing but use a
  different state boundary. The draft therefore claims a qualified intersection
  gap, not that every component technique is new.
- The exact solver is presented as an OPT-style, model-consistent benchmark for
  small frozen instances, never as a production algorithm or physical truth.

## Cycle 1

### Primary-author review

Found that the original draft mixed routing and scheduling terminology,
over-emphasized the exact oracle, used one scalar latency for TTFT/TPOT, used a
single regional price for multiple resources, and risked presenting an
unimplemented joint planner as complete.

### Non-specialist review

Requested a numerical running example, a one-minute explanation before the
formalism, a narrower novelty claim, a concrete deployment story, and honest
implementation status.

### Energy/carbon review

Found destination-only carbon accounting, possible double counting of network
and movement cost, over-strong “actual/settled carbon” language, mixed expected
and robust objectives, and an unsupported dual-bound claim.

### LLM-serving review

Found incomplete KV transition semantics, an under-defined price-loop order,
candidate-independent SLO constraints, an oracle state too small for its claim,
and insufficient baselines to separate future state value from load pricing.

### Revisions

- Retitled the work as online state-aware carbon **routing**.
- Rebuilt the Introduction as: real need; cleanest-now failure; adjacent work
  and gap; CarbonAffinity mechanism; scoped contributions.
- Added an illustrative break-even example and a plain-language overview.
- Defined linear session scope, versioned multi-replica cache state, and
  reuse/re-prefill/KV-transfer transitions.
- Split action carbon by destination service/movement, source movement, WAN,
  site PUE, and signal location; re-prefill is counted exactly once.
- Replaced a scalar latency model with joint-assignment TTFT and TPOT guards.
- Changed regional price to a resource-indexed price.
- Restricted coordination to the current epoch and deleted the unsupported
  certified-dual-gap claim.
- Added three-layer evaluation, stronger baselines, negative controls, and
  route-difference attribution.

## Cycle 2

### Non-specialist review

Found a remaining “planner implements / planner is future work” contradiction,
an over-broad deployment premise, a coarse related-work table, and ambiguous
example arithmetic.

### Energy/carbon review

Found that common-mode forecast error does not always cancel, destination KV
write was implicit, fixed idle needed two separate estimands, and policies must
share one logical carbon timeline for causal comparison.

### LLM-serving review

Found that the optimization still selected only a region rather than a
`(region, movement mode)` action, greedy repair could miss feasible solutions,
the SLO probability source was unspecified, and future HBM contention was
still an unspoken approximation.

### Revisions

- Unified every candidate as `(region, movement mode)` from formulation through
  continuation value, pricing, repair, and complexity.
- Added a policy-independent validated seed incumbent; heuristic repair can
  never replace it with an infeasible assignment.
- Instantiated SLO guards with one-sided split-conformal residual quantiles,
  pooled fallback, OOD rejection, and post-repair revalidation.
- Defined paired migration residual calibration without assuming common-mode
  cancellation.
- Added destination KV-write energy and two pre-registered idle estimands.
- Required a common frozen logical-time carbon sequence for primary comparisons;
  sequential live runs demonstrate feasibility only.
- Made future cache competition an explicit survival-model approximation and
  added it to sensitivity/oracle-gap analysis.
- Replaced category-level novelty rows with named adjacent systems.

## Current reviewer-style verdict

The draft now states a coherent, implementable LLM-state-specific online
optimization framework, with an auditable novelty boundary and defensible
accounting plan. It is **not yet submission-ready**: EuroSys-level acceptance
still requires implementation of the joint planner, measured motivation
figures, physical or carefully bounded multi-region validation, and frozen
quantitative results. Those are experimental blockers, not writing issues.
