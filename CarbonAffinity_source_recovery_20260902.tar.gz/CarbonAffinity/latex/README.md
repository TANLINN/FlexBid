# CarbonAffinity submission draft

This folder contains the two-column systems-paper draft.

Files:

- `main.tex`: submission-oriented paper draft. The quantitative results section
  is intentionally withheld until final experiments and manifests are frozen.
- `references.bib`: references used by the draft.

Generic build:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

The current class is a portable two-column `article` draft. Replace the class
and margins with the official venue template before submission; the technical
content does not depend on a venue-specific package.
