"""Synthetic tests: no physical GPU, SSH, or real vLLM launches."""
import asyncio
import hashlib
import itertools
import json
import os
import re
import unittest
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from scripts.build_latency_shape_probe import BASE_SHA256, PROJECT, make_source
from scripts.latency_shape_probe_support import (
    CONCURRENT_PROMPT, CONCURRENT_WIDTH, GPUS, PROMPTS, audit, fixed_schedule,
    observed_o_blocks, prewarm, tuning_events,
)


def event(bt, seconds=4.25):
    key = (48, 128, 128, bt, *(["torch.bfloat16"] * 4), "torch.float32",
           "torch.bfloat16", "torch.int32", "torch.int32")
    return (f"(EngineCore) Triton autotuning for function chunk_fwd_kernel_o,\n"
            f"with key as {key},\nfinished after {seconds}s,\nbest config selected: test;\n")


class ShapeProbeTests(unittest.TestCase):
    def test_parser_dtype_family_and_incomplete_log(self):
        text = "".join(event(bt) for bt in (16, 32, 64))
        self.assertEqual(observed_o_blocks(tuning_events(text)), {16, 32, 64})
        self.assertEqual(observed_o_blocks(tuning_events(text.replace("torch.int32", "torch.int64"))), set())
        with self.assertRaises(ValueError):
            tuning_events("Triton autotuning for function missing")

    def test_launcher_generation_and_embedded_python(self):
        base = (PROJECT / "scripts/run_latency_pause_probe.sh").read_text()
        self.assertEqual(hashlib.sha256(base.encode()).hexdigest(), BASE_SHA256)
        source = make_source(base)
        blocks = re.findall(r"<<'PY'\n(.*?)\nPY(?:\n|$)", source, re.S)
        self.assertEqual(len(blocks), 2)
        for block in blocks:
            compile(block, "embedded", "exec")
        self.assertIn("OWNED_PGIDS+=(\"$PREWARM_PID\")", source)
        self.assertIn("SHAPE_PREWARM_TIMEOUT", source)
        self.assertLess(source.index("wait \"$PREWARM_PID\""), source.index("PROBE_STAGE=measurement"))
        self.assertLess(source.index("subprocess.run([sys.executable"), source.index("write_json(root / 'EXPERIMENT_COMPLETE.json'"))
        with self.assertRaises(ValueError):
            make_source(base + "# unexpected change\n")

    def setup_root(self, root):
        snapshots = {}
        for gpu in GPUS:
            data = "".join(event(bt) for bt in (16, 32, 64)).encode()
            (root / f"vllm_gpu_{gpu}.log").write_bytes(data)
            snapshots[str(gpu)] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            rows = [{"gpu_index": gpu, "mode": mode, "prompt_tokens": 12288,
                     "concurrency": 3, "repeat": repeat, "ttft_p95_ms": 550,
                     "tpot_p95_ms": 40, "cached_tokens": [11760] * 3,
                     "results": [{"success": True, "output_tokens": 64}] * 3}
                    for mode, repeat in itertools.product(("cold", "warm"), range(5))]
            path = root / "raw" / f"gpu_{gpu}" / "measurements.jsonl"
            path.parent.mkdir(parents=True)
            path.write_text("".join(json.dumps(r) + "\n" for r in rows))
        (root / "SHAPE_PREWARM.json").write_text(json.dumps({
            "logs": snapshots, "checks": {"all_shape_keys_observed": True}}))

    def test_good_audit_is_diagnostic_only(self):
        with TemporaryDirectory() as temp:
            root = Path(temp)
            self.setup_root(root)
            with patch("builtins.print"):
                audit(root)
            report = json.loads((root / "SHAPE_PREWARM_EFFECT_REPORT.json").read_text())
            self.assertEqual(report["status"], "PASS")
            self.assertTrue(report["diagnostic_only"])
            self.assertFalse(report["threshold_is_service_slo"])

    def test_new_tuning_fails_even_with_fast_requests(self):
        with TemporaryDirectory() as temp:
            root = Path(temp)
            self.setup_root(root)
            with (root / "vllm_gpu_6.log").open("a") as out:
                out.write(event(32))
            with patch("builtins.print"), self.assertRaises(RuntimeError):
                audit(root)
            report = json.loads((root / "SHAPE_PREWARM_EFFECT_REPORT.json").read_text())
            self.assertFalse(report["checks"]["no_new_autotuning_after_prewarm"])

    def test_slow_requests_preserved_and_fail_diagnostic(self):
        with TemporaryDirectory() as temp:
            root = Path(temp)
            self.setup_root(root)
            path = root / "raw/gpu_0/measurements.jsonl"
            data = path.read_text().replace('"ttft_p95_ms": 550', '"ttft_p95_ms": 4800')
            path.write_text(data)
            before = path.read_bytes()
            with patch("builtins.print"), self.assertRaises(RuntimeError):
                audit(root)
            self.assertEqual(path.read_bytes(), before)

    def test_log_rotation_rejected(self):
        with TemporaryDirectory() as temp:
            root = Path(temp)
            self.setup_root(root)
            (root / "vllm_gpu_0.log").write_text("replaced")
            with self.assertRaisesRegex(RuntimeError, "truncated"):
                audit(root)

    def test_fixed_prewarm_sends_exact_schedule_and_separate_artifacts(self):
        from carbonaffinity.models import CompletionResult

        class Materializer:
            def tokens(self, raw):
                return [1] * raw["prompt_tokens"]

        class Client:
            calls = []
            closed = []
            def __init__(self, config, timeout):
                self.gpu = config["id"]
                self.asserted_concurrency = config["admission_concurrency"]
            async def complete(self, request, prompt, **kwargs):
                self.calls.append((self.gpu, len(prompt), kwargs["cache_salt"]))
                return CompletionResult(request.request_id, self.gpu, True, 200,
                                        1, 2, 3, 1, 1, request.max_output_tokens,
                                        len(prompt), 0)
            async def reset_prefix_cache(self):
                return True
            async def close(self):
                self.closed.append(self.gpu)

        with TemporaryDirectory() as temp, patch.dict(os.environ, TRITON_PRINT_AUTOTUNING="1"):
            root = Path(temp)
            for gpu in GPUS:
                (root / f"vllm_gpu_{gpu}.log").write_text("".join(event(bt) for bt in (16, 32, 64)))
            with patch("builtins.print"):
                asyncio.run(prewarm(root, Materializer(), Client))
            expected_per_gpu = len(fixed_schedule()) + 2 * CONCURRENT_WIDTH
            self.assertEqual(len(Client.calls), len(GPUS) * expected_per_gpu)
            self.assertEqual(len({x[2] for x in Client.calls}),
                             len(GPUS) * (len(fixed_schedule()) + CONCURRENT_WIDTH))
            self.assertEqual(sorted(Client.closed), ["gpu_0", "gpu_6", "gpu_7"])
            for gpu in GPUS:
                self.assertEqual(
                    [x[1] for x in Client.calls if x[0] == f"gpu_{gpu}"],
                    list(PROMPTS) * 2 + [CONCURRENT_PROMPT] * (2 * CONCURRENT_WIDTH))
            self.assertEqual(len(list(root.rglob("measurements.jsonl"))), 0)
            self.assertEqual(len(fixed_schedule()), 8)

    def run_cache_case(self, mutation=None, observed_blocks=(16, 32, 64)):
        from carbonaffinity.models import CompletionResult

        class Materializer:
            def tokens(self, raw):
                return [1] * raw["prompt_tokens"]

        class Client:
            closed = []
            def __init__(self, config, timeout):
                self.gpu = config["id"]
            async def complete(self, request, prompt, **kwargs):
                await asyncio.sleep(0)
                result = CompletionResult(request.request_id, self.gpu, True, 200,
                                          1, 2, 3, 1, 1, request.max_output_tokens,
                                          len(prompt),
                                          None if len(prompt) in (16, 32, 64) else 0)
                return mutation(result) if mutation else result
            async def reset_prefix_cache(self):
                return True
            async def close(self):
                self.closed.append(self.gpu)

        with TemporaryDirectory() as temp, patch.dict(os.environ, TRITON_PRINT_AUTOTUNING="1"):
            root = Path(temp)
            for gpu in GPUS:
                (root / f"vllm_gpu_{gpu}.log").write_text("".join(event(bt) for bt in observed_blocks))
            failure = None
            with patch("builtins.print"):
                try:
                    asyncio.run(prewarm(root, Materializer(), Client))
                except RuntimeError as exc:
                    failure = str(exc)
            files = {p.relative_to(root).as_posix(): json.loads(p.read_text())
                     for p in root.rglob("*.json")}
            return failure, files, Client.closed

    def test_short_missing_cache_preserved_as_unknown(self):
        failure, files, closed = self.run_cache_case()
        self.assertIsNone(failure)
        self.assertEqual(len(closed), 3)
        report = files["SHAPE_PREWARM.json"]
        self.assertEqual(report["missing_cache_observations"], 18)
        self.assertTrue(report["checks"]["all_shape_keys_observed"])
        records = [v for k, v in files.items() if k.startswith("prewarm/")]
        self.assertEqual(len(records), 42)
        self.assertEqual(len({r["cache_salt"] for r in records}), 33)
        for record in records:
            if record["result"]["prompt_tokens_reported"] in (16, 32, 64):
                self.assertIsNone(record["result"]["cached_prompt_tokens_observed"])
                self.assertTrue(record["missing_cache_observation_allowed"])

    def test_all_prewarm_missing_readings_preserved_as_unknown(self):
        failure, files, closed = self.run_cache_case(
            lambda r: replace(r, cached_prompt_tokens_observed=None))
        self.assertIsNone(failure)
        self.assertEqual(len(closed), 3)
        report = files["SHAPE_PREWARM.json"]
        self.assertEqual(report["missing_cache_observations"], 42)
        self.assertEqual(report["missing_cache_observation_allowed_for_prompts"], list(PROMPTS))
        self.assertIn("null remains unknown", report["cache_observation_policy"])
        for path, record in files.items():
            if path.startswith("prewarm/"):
                self.assertIsNone(record["result"]["cached_prompt_tokens_observed"])
                self.assertTrue(all(record["checks"].values()))

    def test_cached_tuning_shapes_do_not_require_repeated_autotune_logs(self):
        failure, files, _ = self.run_cache_case(
            lambda r: replace(r, cached_prompt_tokens_observed=None), observed_blocks=(64,))
        self.assertIsNone(failure)
        self.assertTrue(files["SHAPE_PREWARM.json"]["checks"]["fixed_schedule_completed"])
        self.assertFalse(files["SHAPE_PREWARM.json"]["checks"]["all_shape_keys_observed"])
        self.assertEqual(files["SHAPE_PREWARM.json"]["requests"], 42)

    def test_observed_cache_hits_still_fail_for_every_prompt(self):
        for cached, prompt in ((1, p) for p in PROMPTS):
            with self.subTest(cached=cached, prompt=prompt):
                def mutate(result):
                    return (replace(result, cached_prompt_tokens_observed=cached)
                            if result.prompt_tokens_reported == prompt else result)
                failure, files, closed = self.run_cache_case(mutate)
                self.assertIn("cache_observation_acceptable", failure)
                self.assertNotIn("SHAPE_PREWARM.json", files)
                self.assertEqual(len(files["SHAPE_PREWARM_FAILURE.json"]["errors"]), 3)
                self.assertEqual(len(closed), 3)
                for gpu in GPUS:
                    raw = files[f"prewarm/gpu_{gpu}_0_{prompt}.json"]
                    self.assertEqual(raw["result"]["cached_prompt_tokens_observed"], cached)

    def test_request_checks_not_relaxed_and_other_gpus_finish(self):
        for field, value, check in (("output_tokens", 63, "output_tokens_exact"),
                                    ("prompt_tokens_reported", 15, "prompt_tokens_exact"),
                                    ("success", False, "request_succeeded")):
            with self.subTest(field=field):
                def mutate(result):
                    return (replace(result, **{field: value})
                            if result.region_id == "gpu_7" else result)
                failure, files, closed = self.run_cache_case(mutate)
                self.assertIn(check, failure)
                detail = json.loads(files["SHAPE_PREWARM_FAILURE.json"]["errors"]["7"].split(
                    "prewarm result mismatch: ", 1)[1])
                self.assertEqual(detail["actual"][field], value)
                self.assertEqual(len(closed), 3)
                self.assertEqual(set(files["SHAPE_PREWARM_FAILURE.json"]["errors"]), {"7"})
                for gpu in (0, 6):
                    self.assertEqual(len([k for k in files if k.startswith(f"prewarm/gpu_{gpu}_")]), 14)

    def test_formal_warm_missing_cache_still_fails(self):
        with TemporaryDirectory() as temp:
            root = Path(temp)
            self.setup_root(root)
            path = root / "raw/gpu_7/measurements.jsonl"
            path.write_text(path.read_text().replace('[11760, 11760, 11760]', '[null, null, null]'))
            with patch("builtins.print"), self.assertRaises(RuntimeError):
                audit(root)
            report = json.loads((root / "SHAPE_PREWARM_EFFECT_REPORT.json").read_text())
            self.assertFalse(report["checks"]["observed_cache_unchanged"])


class PrewarmProtocolTests(unittest.IsolatedAsyncioTestCase):
    async def test_stream_without_cache_details_keeps_unknown_not_zero(self):
        import httpx
        from carbonaffinity.models import RequestSpec
        from carbonaffinity.region import RegionClient

        for prompt_tokens in (16, 2048):
            for mode, expected in (("absent", None), ("null", None), ("zero", 0), ("hit", 7)):
                with self.subTest(prompt=prompt_tokens, mode=mode):
                    usage = {"prompt_tokens": prompt_tokens, "completion_tokens": 64,
                             "total_tokens": prompt_tokens + 64}
                    if mode == "null":
                        usage["prompt_tokens_details"] = None
                    elif mode in ("zero", "hit"):
                        usage["prompt_tokens_details"] = {"cached_tokens": expected}
                    events = [{"choices": [{"text": "x"}], "usage": None},
                              {"choices": [], "usage": usage}]
                    body = "".join("data: " + json.dumps(e) + "\n\n" for e in events)
                    body += "data: [DONE]\n\n"

                    def handle(request):
                        payload = json.loads(request.content)
                        self.assertEqual(len(payload["prompt"]), prompt_tokens)
                        self.assertEqual(payload["cache_salt"], "isolated-test-salt")
                        return httpx.Response(200, text=body,
                                              headers={"content-type": "text/event-stream"})

                    client = RegionClient({"id": "test", "api_base": "http://test.invalid/v1",
                                           "model": "mock", "admission_concurrency": 1})
                    await client.close()
                    client._client = httpx.AsyncClient(transport=httpx.MockTransport(handle))
                    try:
                        result = await client.complete(
                            RequestSpec("test", 0, prompt_tokens, 64, "test"),
                            [1] * prompt_tokens, cache_salt="isolated-test-salt")
                    finally:
                        await client.close()
                    self.assertTrue(result.success, result.error)
                    self.assertEqual(result.prompt_tokens_reported, prompt_tokens)
                    self.assertEqual(result.output_tokens, 64)
                    self.assertEqual(result.cached_prompt_tokens_observed, expected)


if __name__ == "__main__":
    unittest.main()
