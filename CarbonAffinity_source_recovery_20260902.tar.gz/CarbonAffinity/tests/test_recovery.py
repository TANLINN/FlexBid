"""Synthetic recovery regressions. None of these are physical measurements."""
from __future__ import annotations

import asyncio
import itertools
import json
import math
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, write_json
from carbonaffinity.baseline_closed_loop import BaselineClosedLoopPlanner
from carbonaffinity.closed_loop import AsyncClosedLoopCoordinator, ClosedLoopCapacityError, ClosedLoopPlanner
from carbonaffinity.corun_surface import CorunTTFTModel, fit_tables, fit_with_loo
from carbonaffinity.future_work import annotate_problem, expected_work
from carbonaffinity.latency_surface import estimate_latency_surface
from carbonaffinity.models import RegionSnapshot, RequestSpec
from carbonaffinity.network import NetworkSpec, estimate_network
from carbonaffinity.offline_oracle import OracleProblem, solve_exact
from carbonaffinity.online_planner import OnlinePlannerSettings, solve_online
from carbonaffinity.region import RegionClient
from carbonaffinity.workload_experiments import cases, features_at_admission
from scripts.freeze_validated_model import freeze


def problem():
    option = {"cold_energy_j": 10, "warm_energy_j": 5, "cold_ttft_ms": 10, "warm_ttft_ms": 5, "tpot_ms": 10}
    return OracleProblem.from_dict({"regions": [{"region_id": r, "capacity": 2} for r in ("a", "b")],
        "epochs": [{"epoch_id": "0", "carbon_lbs_per_mwh": {"a": 1, "b": 500}, "requests": [
            {"request_id": f"r{i}", "session_id": f"s{i}", "prompt_tokens": 1024, "max_output_tokens": 64,
             "ttft_slo_ms": 1000, "tpot_slo_ms": 100, "options": {"a": dict(option), "b": dict(option)}} for i in range(3)]}]})


def snapshots():
    return {r: RegionSnapshot(r, 0, 0, capacity=2) for r in ("a", "b")}


class NoOverlapGuard:
    def predict(self, own, prefill, pending, decode):
        return {"out_of_domain": False, "conservative_ttft_ms": 2000 if prefill + pending + decode > 0 else 10}


def synthetic_rows():
    rows = []
    for gpu in range(8):
        for own in (1024, 4096, 16384):
            for phase, p, d, a in [("baseline", 0, 0, 0), ("prefill_then_decode", 8192, 8, 0),
                                     ("prefill_then_decode", 16384, 192, 0), ("active_decode", 0, 0, 192),
                                     ("active_decode", 0, 0, 448)]:
                rows.append({"gpu_index": gpu, "phase": phase, "victim_mode": str(own), "failures": 0,
                             "admission_features": {"own": own, "prefill": p, "prefill_decode": d, "active_decode": a},
                             "victim": {"success": True, "ttft_ms": 100 + own / 20 + p / 4 + d * 20 + a * 20 + gpu}})
    return rows


class RecoveryModelTests(unittest.TestCase):
    def test_affine_network_includes_fixed_api_overhead(self):
        spec = NetworkSpec(enabled=True, request_base_bytes=100, response_base_bytes=200,
                           prompt_bytes_per_token=5, output_bytes_per_token=260, first_response_bytes=262)
        value = estimate_network(spec, prompt_tokens=1000, output_tokens=10)
        self.assertEqual((value.request_bytes, value.response_bytes, value.first_response_bytes), (5100, 2800, 262))

    def test_network_rejects_nonfinite(self):
        for value in (float("nan"), float("inf"), -1):
            with self.assertRaises(ValueError):
                NetworkSpec.from_dict({"request_base_bytes": value})

    def test_future_observable_turn_range(self):
        model = {"workloads": {"agentic": {"0": {"future_requests": 3}, "64": {"future_requests": 0}}}, "max_turn": 64}
        self.assertEqual(expected_work(model, "agentic", 0)["future_requests"], 3)
        self.assertIsNone(expected_work(model, "agentic", 65))
        self.assertIsNone(expected_work(model, "unknown", 0))
        self.assertIsNone(expected_work(model, "agentic", -1))

    def test_annotation_requires_observable_fields(self):
        with self.assertRaises(ValueError):
            annotate_problem({"epochs": [{"requests": [{"options": {}}]}]}, {}, {})

    def test_matrix_counts_and_unique_cases(self):
        for kind, count in {"backlog_development": 81, "backlog_validation": 81,
                            "corun_development": 153, "active_decode_development": 57,
                            "corun_validation": 54, "active_decode_validation": 30}.items():
            rows = cases(kind)
            self.assertEqual(len(rows), count, kind)
            self.assertEqual(len({r["case_id"] for r in rows}), count)

    def test_admission_features_ignore_future_arrivals(self):
        rows = [{"start_ns": 0, "first_ns": 100, "end_ns": 200, "prompt_tokens": 1000, "requested_output_tokens": 192},
                {"start_ns": 60, "first_ns": 120, "end_ns": 200, "prompt_tokens": 2000, "requested_output_tokens": 448}]
        self.assertEqual(features_at_admission(1024, 50, rows), {"own": 1024, "prefill": 1000, "prefill_decode": 192, "active_decode": 0})

    def test_phase_transition_preserves_full_output_budget(self):
        rows = [{"start_ns": 0, "first_ns": 100, "end_ns": 200, "prompt_tokens": 1000, "requested_output_tokens": 192}]
        self.assertEqual(features_at_admission(1024, 150, rows)["active_decode"], 192)
        self.assertEqual(features_at_admission(1024, 200, rows)["active_decode"], 0)

    def test_corun_fit_and_loo(self):
        payload = fit_with_loo(synthetic_rows())
        self.assertEqual(len(payload["loo_folds"]), 8)
        self.assertFalse(payload["candidate_frozen"])
        self.assertEqual(payload["development_evaluation"]["overall"]["false_negatives"], 0)

    def test_corun_out_of_range_fails_closed(self):
        model = CorunTTFTModel(fit_tables(synthetic_rows()))
        prediction = model.predict(50000, 0, 0, 0)
        self.assertTrue(prediction["out_of_domain"])
        self.assertTrue(math.isinf(prediction["conservative_ttft_ms"]))

    def test_corun_mixed_phase_is_not_claimed_validated(self):
        model = CorunTTFTModel(fit_tables(synthetic_rows()))
        self.assertTrue(model.predict(1024, 8192, 8, 192)["out_of_domain"])

    def test_corun_unsupported_empty_cell_not_safe(self):
        model = CorunTTFTModel(fit_tables(synthetic_rows()))
        self.assertTrue(model.predict(1024, 8192, 0, 0)["out_of_domain"])

    def test_empty_measurements_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                read_rows(temp)

    def test_no_artifact_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "model.json"
            write_json(path, {"x": 1})
            with self.assertRaises(FileExistsError):
                write_json(path, {"x": 2})
            self.assertEqual(json.loads(path.read_text()), {"x": 1})

    def test_freeze_preserves_candidate_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            write_json(root / "candidate.json", {"candidate_frozen": False})
            write_json(root / "validation.json", {"status": "PASS", "candidate_sha256": sha256(root / "candidate.json"), "checks": {"nonempty": True}})
            freeze(root / "candidate.json", root / "validation.json", root / "frozen.json")
            self.assertEqual(sha256(root / "candidate.json"), sha256(root / "frozen.json"))

    def test_freeze_rejects_failed_validation(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            write_json(root / "candidate.json", {})
            write_json(root / "validation.json", {"status": "FAIL"})
            with self.assertRaises(ValueError):
                freeze(root / "candidate.json", root / "validation.json", root / "frozen.json")
            self.assertFalse((root / "frozen.json").exists())

    def test_explicit_bad_latency_model_not_silent_legacy_fallback(self):
        with self.assertRaises(ValueError):
            estimate_latency_surface({"cells": {}}, 1024, 0, 1)


class RecoveryPlannerTests(unittest.TestCase):
    def test_completion_requires_matching_request_identity(self):
        planner = ClosedLoopPlanner(problem())
        plan = planner.plan(["r0"], snapshots(), {"a": 1, "b": 500})
        region = plan.assignments[0].region_id
        with self.assertRaises(RuntimeError):
            planner.complete("r1", region, True)
        self.assertEqual(sum(planner.reserved.values()), 1)
        planner.complete("r0", region, True)
        with self.assertRaises(RuntimeError):
            planner.complete("r0", region, True)

    def test_atomic_guard_failure_does_not_commit_partial_plan(self):
        planner = ClosedLoopPlanner(problem(), corun_model=NoOverlapGuard())
        with self.assertRaises(ClosedLoopCapacityError):
            planner.plan(["r0", "r1"], snapshots(), {"a": 1, "b": 500})
        self.assertEqual(sum(planner.reserved.values()), 0)

    def test_baselines_share_same_batch_guard(self):
        for policy in ("cleanest_now", "carbon_affinity", "sticky", "pressure_only"):
            planner = BaselineClosedLoopPlanner(problem(), policy, corun_model=NoOverlapGuard())
            plan = planner.plan(["r0", "r1"], snapshots(), {"a": 1, "b": 500})
            self.assertEqual(len({a.region_id for a in plan.assignments}), 2)

    def test_unhealthy_region_excluded_from_joint_plan(self):
        planner = ClosedLoopPlanner(problem())
        state = snapshots()
        state["a"] = replace(state["a"], healthy=False)
        plan = planner.plan(["r0"], state, {"a": 1, "b": 500})
        self.assertEqual(plan.assignments[0].region_id, "b")

    def test_snapshot_union_counts_external_and_not_yet_dispatched(self):
        planner = ClosedLoopPlanner(problem())
        planner.plan(["r0"], snapshots(), {"a": 1, "b": 500})
        state = snapshots()
        state["a"] = replace(state["a"], active_requests=1, workload_requests=(("external", "prefill", 500, 20),))
        self.assertEqual(planner._load(state)["a"], 2)
        self.assertEqual(planner._workload("a", state["a"]), (1524, 84, 0))

    def test_snapshot_overrides_reservation_at_first_token(self):
        planner = ClosedLoopPlanner(problem())
        planner.plan(["r0"], snapshots(), {"a": 1, "b": 500})
        state = replace(snapshots()["a"], active_requests=1, workload_requests=(("r0", "decode", 0, 64),))
        self.assertEqual(planner._workload("a", state), (0, 0, 64))

    def test_exact_transition_limit_stops_before_huge_enumeration(self):
        with self.assertRaisesRegex(RuntimeError, "transition limit"):
            solve_exact(problem(), max_transitions=1)

    def test_network_cost_is_in_exact_and_online_objective(self):
        p = problem()
        request = p.epochs[0].requests[0]
        request = replace(request, options=tuple((r, replace(o, network_carbon_g=10 if r == "a" else 0)) for r, o in request.options))
        p = replace(p, epochs=(replace(p.epochs[0], requests=(request,)),))
        exact = solve_exact(p)
        online = solve_online(p, OnlinePlannerSettings(continuation_mode="none"))
        self.assertEqual(dict(exact.steps[0].assignments)["r0"], "b")
        self.assertAlmostEqual(exact.cost.objective_carbon_g, online.cost.objective_carbon_g)


class RecoveryAsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_infeasible_joint_batch_is_split_not_dropped(self):
        planner = ClosedLoopPlanner(problem(), corun_model=NoOverlapGuard())
        coordinator = AsyncClosedLoopCoordinator(planner, control_interval_ms=1)
        try:
            requests = [RequestSpec(f"r{i}", 0, 1024, 64, f"s{i}", ttft_slo_ms=1000) for i in range(2)]
            assignments = await asyncio.wait_for(asyncio.gather(*(coordinator.assign(r, snapshots(), {"a": 1, "b": 500}) for r in requests)), 2)
            self.assertEqual(len({a.region_id for a in assignments}), 2)
            for request, assignment in zip(requests, assignments):
                await coordinator.complete(request.request_id, assignment.region_id, True)
            self.assertEqual(sum(planner.reserved.values()), 0)
        finally:
            await coordinator.close()

    async def test_cancelled_queued_client_releases_workload(self):
        client = RegionClient({"id": "a", "api_base": "http://127.0.0.1:1/v1", "model": "mock", "admission_concurrency": 1})
        await client._semaphore.acquire()
        request = RequestSpec("cancel", 0, 1024, 64, "s")
        task = asyncio.create_task(client.complete(request, "hello"))
        try:
            await asyncio.sleep(.01)
            self.assertEqual(client.snapshot().prefill_requests, 1)
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
            self.assertEqual(client.snapshot().queue_depth, 0)
            self.assertEqual(client.snapshot().prefill_requests, 0)
        finally:
            client._semaphore.release()
            await client.close()

    async def test_baseline_policy_label_preserved(self):
        coordinator = AsyncClosedLoopCoordinator(BaselineClosedLoopPlanner(problem(), "cleanest_now"))
        self.assertEqual(coordinator.policy_name, "closed_loop_cleanest_now")
        await coordinator.close()


if __name__ == "__main__":
    unittest.main()
