"""Synthetic independent-validation gate regressions, never a GPU claim."""
import asyncio
import copy
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from carbonaffinity.artifacts import sha256, write_json
from scripts import validate_observable_corun_candidate as val
from scripts import observable_corun_candidate as estimator
from scripts import corun_observable_development as dev
from scripts import corun_observable_pilot as engine
from tests.test_corun_observable_pilot import FakeClient
from tests.test_latency_residual import Materializer, event


def raw_grid():
    async def run():
        client = FakeClient()
        try:
            return [await engine.run_case(SimpleNamespace(gpu_index=0, runtime_evidence="test"),
                Materializer(), client, c, "heldout", protocol=val) for c in val.cases()]
        finally:
            await client.close()
    return asyncio.run(run())


def synthetic_candidate():
    observations = []
    for c in dev.cases():
        if c["phase_role"] == "fit_development":
            query = estimator.design_query(c)
            stratum, coord, _ = estimator.coordinates(query)
            observations.append(dict(stratum=stratum, coordinate=coord, gpu=0,
                role="fit_development", metrics=dict(ttft_ms=100, tpot_ms=35)))
    return estimator.fit_cells(observations)


class CorunValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = raw_grid()
        cls.model = synthetic_candidate()

    def fit_fixture(self, root):
        root.mkdir()
        model = copy.deepcopy(self.model)
        reference = root / "unchanged_reference.json"
        write_json(reference, {"synthetic": True})
        write_json(root / "FIT_RECORD.json", dict(validation_data_read=False, training_rows=2016,
            excluded_future_controls=192, source_sha256={str(reference): sha256(reference)},
            fit_code_sha256={str(Path(estimator.__file__).resolve()): sha256(estimator.__file__)}))
        model["provenance"] = {"fit_record_sha256": sha256(root / "FIT_RECORD.json")}
        candidate = root / "model.json"
        write_json(candidate, model)
        digest = sha256(candidate)
        audit = root / "OBSERVABLE_CORUN_CANDIDATE_AUDIT.json"
        write_json(audit, dict(status="CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION", checks=dict(synthetic=True), candidate_sha256=digest))
        write_json(root / "FIT_COMPLETE.json", dict(status="COMPLETE", audit_sha256=sha256(audit), candidate_sha256=digest))
        return candidate, digest

    def run_fixture(self, root):
        fit = root / "fit"
        candidate, digest = self.fit_fixture(fit)
        patch_path = patch.object(val, "CANDIDATE", candidate)
        patch_hash = patch.object(val, "EXPECTED_SHA256", digest)
        patch_path.start()
        patch_hash.start()
        self.addCleanup(patch_path.stop)
        self.addCleanup(patch_hash.stop)
        run = root / "run"
        run.mkdir()
        extra = val.prepare(run, None)
        write_json(run / "LAUNCH.json", dict(runtime_cap=784, effective_cap_verified=True, cache_block784_verified=True))
        write_json(run / "PREREGISTRATION.json", dict(design=val.design(), expected_rows=768,
            code_sha256={str(p): sha256(p) for p in val.code_paths()}, **extra))
        logs = {}
        for g in range(8):
            raw = "".join(event(bt) for bt in (16, 32, 64)).encode()
            (run / f"vllm_gpu_{g}.log").write_bytes(raw)
            logs[str(g)] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            path = run / "raw" / f"gpu_{g}" / "measurements.jsonl"
            path.parent.mkdir(parents=True)
            path.write_text("".join(json.dumps(dict(r, gpu_index=g, runtime_evidence_sha256=sha256(run / "LAUNCH.json"))) + "\n" for r in self.raw))
        write_json(run / "SHAPE_PREWARM.json", dict(gpu_indices=list(range(8)), requests=64,
            checks=dict(all_shape_keys_observed=True), logs=logs))
        return run, candidate

    def rewrite(self, run, gpu, mutate):
        p = run / "raw" / f"gpu_{gpu}" / "measurements.jsonl"
        rows = [json.loads(line) for line in p.read_text().splitlines()]
        mutate(rows)
        p.write_text("".join(json.dumps(r) + "\n" for r in rows))

    def test_heldout_complete_matrix_real_client_budget_flow(self):
        self.assertEqual(len(val.cases()), 96)
        self.assertEqual(sum(c["phase_role"] == "primary_validation" for c in val.cases()), 72)
        self.assertEqual([c["cell_id"] for c in val.cases()[:48]], [c["cell_id"] for c in reversed(val.cases()[48:])])
        trained = {estimator.coordinates(estimator.design_query(c))[:2] for c in dev.cases()}
        for row in self.raw:
            self.assertTrue(all(row["checks"].values()), row)
            query = estimator.admission_query(row)
            self.assertEqual(query, estimator.design_query(row))
            self.assertNotIn(estimator.coordinates(query)[:2], trained)
            self.assertTrue(estimator.predict(self.model, query)["in_domain"])
            for bg in row["backgrounds"]:
                self.assertEqual(bg["output_tokens"], 128)
                self.assertEqual(bg["prompt_tokens"], 16064 if bg["cached_target"] else 12288)
        self.assertEqual(len(dev.cases()), 276)
        self.assertEqual(len(engine.cases()), 24)

    def test_candidate_must_match_and_predictions_locked_before_rows(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            candidate, digest = self.fit_fixture(root / "fit")
            run = root / "new"
            run.mkdir()
            with patch.object(val, "CANDIDATE", candidate), patch.object(val, "EXPECTED_SHA256", "0" * 64):
                with self.assertRaisesRegex(ValueError, "HASH_MISMATCH"):
                    val.prepare(run, None)
            self.assertEqual(list(run.iterdir()), [])
            with patch.object(val, "CANDIDATE", candidate), patch.object(val, "EXPECTED_SHA256", digest):
                before = candidate.read_bytes()
                extra = val.prepare(run, None)
                self.assertEqual((run / "LOCKED_CANDIDATE.json").read_bytes(), before)
                self.assertEqual(candidate.read_bytes(), before)
                self.assertEqual(extra["prediction_plan_sha256"], sha256(run / "PREDICTIONS_BEFORE_MEASUREMENT.json"))
                self.assertFalse((run / "raw").exists())
                self.assertEqual(len(json.loads((run / "PREDICTIONS_BEFORE_MEASUREMENT.json").read_text())), 96)

    def test_pass_is_bounded_and_control_undercoverage_does_not_disappear(self):
        with tempfile.TemporaryDirectory() as temp:
            run, candidate = self.run_fixture(Path(temp))
            before = candidate.read_bytes()
            def poison(rows):
                for r in rows:
                    if r["phase_role"] == "future_arrival_control":
                        r["results"]["victim"]["tpot_ms"] = 400
            for g in range(8):
                self.rewrite(run, g, poison)
            report = val.audit(run)
            self.assertEqual(report["status"], "PASS", report["checks"])
            self.assertTrue(report["bounded_primary_validation_passed"])
            self.assertFalse(report["continuous_arrival_tpot_validated"])
            self.assertFalse(report["candidate_frozen"])
            self.assertEqual(report["primary_rows"], 576)
            self.assertEqual(report["future_control_rows"], 192)
            self.assertEqual(report["future_controls_diagnostic_only"]["cold_tpot_ms"]["coverage"], 0)
            self.assertEqual(candidate.read_bytes(), before)

    def test_pooled_pass_cannot_hide_gpu_or_stratum_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            run, _ = self.run_fixture(Path(temp))
            def fail_two(rows):
                group = [r for r in rows if r["mode"] == "cold_p8192" and r["scenario"] == "decode1"]
                self.assertEqual(len(group), 2)
                for r in group:
                    r["results"]["victim"]["ttft_ms"] = 200
            self.rewrite(run, 0, fail_two)
            report = val.audit(run)
            self.assertEqual(report["status"], "FAIL")
            self.assertTrue(report["checks"]["primary_mode_metric_coverage95"])
            self.assertFalse(report["checks"]["every_gpu_mode_metric_coverage95"])
            self.assertFalse(report["checks"]["every_phase_stratum_metric_coverage95"])

    def test_single_classification_false_negative_fails_even_with_coverage(self):
        with tempfile.TemporaryDirectory() as temp:
            run, _ = self.run_fixture(Path(temp))
            def fail_one(rows):
                rows[0]["results"]["victim"]["ttft_ms"] = 17000
            self.rewrite(run, 2, fail_one)
            report = val.audit(run)
            self.assertTrue(report["checks"]["every_gpu_mode_metric_coverage95"])
            self.assertFalse(report["checks"]["primary_ttft_classification_false_negatives_zero"])
            self.assertEqual(report["status"], "FAIL")

    def test_candidate_plan_order_and_tuning_tampering_fail_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            run, _ = self.run_fixture(Path(temp))
            plan = run / "PREDICTIONS_BEFORE_MEASUREMENT.json"
            saved = plan.read_bytes()
            plan.write_text("{}")
            self.assertFalse(val.audit(run)["checks"]["prediction_plan_hash_unchanged"])
            plan.write_bytes(saved)
            self.rewrite(run, 4, lambda rows: rows.reverse())
            report = val.audit(run)
            self.assertFalse(report["checks"]["exact_preregistered_order"])
            self.assertTrue(report["checks"]["exact_768_cases"])
            self.rewrite(run, 4, lambda rows: rows.reverse())
            with (run / "vllm_gpu_3.log").open("a") as f:
                f.write(event(32))
            (run / "LOCKED_CANDIDATE.json").write_text("{}")
            report = val.audit(run)
            self.assertFalse(report["checks"]["candidate_bytes_unchanged"])
            self.assertFalse(report["checks"]["no_post_prewarm_autotuning"])
            self.assertEqual(report["status"], "FAIL")

    def test_fit_evidence_change_prevents_launch(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            candidate, digest = self.fit_fixture(root / "fit")
            (root / "fit/unchanged_reference.json").write_text("changed")
            with patch.object(val, "CANDIDATE", candidate), patch.object(val, "EXPECTED_SHA256", digest):
                with self.assertRaisesRegex(ValueError, "evidence changed"):
                    val.verified_candidate()


if __name__ == "__main__":
    unittest.main()
