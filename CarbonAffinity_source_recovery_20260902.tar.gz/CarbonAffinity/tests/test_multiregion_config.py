from __future__ import annotations

import unittest

from carbonaffinity.config import validate_config


class MultiRegionConfigTests(unittest.TestCase):
    @staticmethod
    def _config(count: int) -> dict:
        return {
            "regions": [
                {
                    "id": f"r{index}",
                    "api_base": f"http://127.0.0.1:{18000 + index}/v1",
                    "control_base": "http://127.0.0.1:1",
                    "profile": f"profiles/r{index}.json",
                    "site_manifest": f"manifests/r{index}.json",
                    "model": "Qwen3.5-27B",
                    "gpu_count": 1,
                    "tensor_parallel_size": 1,
                }
                for index in range(count)
            ],
            "routing": {"policy": "carbon_affinity"},
        }

    def test_eight_regions_are_valid(self) -> None:
        validate_config(self._config(8))

    def test_one_or_nine_regions_are_rejected(self) -> None:
        for count in (1, 9):
            with self.subTest(count=count), self.assertRaises(ValueError):
                validate_config(self._config(count))


if __name__ == "__main__":
    unittest.main()
