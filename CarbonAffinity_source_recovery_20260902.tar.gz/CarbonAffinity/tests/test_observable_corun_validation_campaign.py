import unittest
from types import SimpleNamespace
from unittest.mock import Mock

from scripts import run_observable_corun_validation_campaign as runner


class SerializedStartupTests(unittest.TestCase):
    def test_non_vllm_process_is_not_waited_on(self):
        process = Mock()
        original = Mock(return_value=process)
        health = Mock()
        launch = runner.SerializedVllmPopen(original, health=health)

        self.assertIs(launch(["nvidia-smi", "--loop=1"]), process)
        health.assert_not_called()

    def test_vllm_process_returns_only_after_health(self):
        process = Mock()
        process.poll.return_value = None
        original = Mock(return_value=process)
        health = Mock(side_effect=[False, False, True])
        launch = runner.SerializedVllmPopen(
            original, timeout_s=10, poll_s=0, health=health
        )
        command = ["/venv/bin/vllm", "serve", "/model", "--port", "18003"]

        self.assertIs(
            launch(command, env={"CUDA_VISIBLE_DEVICES": "3"}), process
        )
        self.assertEqual(health.call_count, 3)
        self.assertEqual(health.call_args.args, (18003,))

    def test_early_vllm_exit_is_returned_to_established_supervisor(self):
        process = Mock()
        process.poll.return_value = 17
        launch = runner.SerializedVllmPopen(
            Mock(return_value=process), timeout_s=10, poll_s=0, health=Mock()
        )

        self.assertIs(
            launch(["vllm", "serve", "/model", "--port", "18000"]), process
        )

    def test_main_restores_original_popen_after_supervisor_exit(self):
        original = Mock()
        delegated = Mock(side_effect=SystemExit(0))
        module = SimpleNamespace(
            subprocess=SimpleNamespace(Popen=original), main=delegated
        )
        with self.assertRaises(SystemExit):
            runner.main(campaign="validation", runner_module=module)
        delegated.assert_called_once_with(campaign="validation")
        self.assertIs(module.subprocess.Popen, original)


if __name__ == "__main__":
    unittest.main()
