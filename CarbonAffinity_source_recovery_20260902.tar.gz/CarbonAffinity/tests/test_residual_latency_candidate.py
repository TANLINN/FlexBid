"""Synthetic fit/transfer tests; no GPU or true latency validation."""
import copy
import itertools
import json
import tempfile
import unittest
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, write_json
from scripts.audit_latency_residual import audit
from scripts.fit_residual_latency_candidate import build
from scripts.residual_latency_candidate import (AXES, AXIS_NAMES, batch_observation, evaluate,
                                               fit_candidate, fit_cells, predict)
from tests.test_latency_residual import fixture


def dataset(root):
    fixture(root)
    rows = read_rows(root / "raw")
    for row in rows:
        for item in row["results"]:
            p = row["prompt_tokens"]
            c = row["cached_context_target"]
            u = row["residual_target"]
            n = row["concurrency"]
            # Deliberately include one slow GPU, so held-out leakage is visible.
            gpu_offset = 200 if row["gpu_index"] == 4 else row["gpu_index"]
            item["ttft_ms"] = (p if row["mode"] == "cold" else c * .01 + u) + n * 100 + gpu_offset
            item["tpot_ms"] = 30 + n + p * .0001 + gpu_offset * .01
    return rows


class CandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory() as temp:
            cls.rows = dataset(Path(temp))
        cls.model, cls.diagnostics = fit_candidate(cls.rows)

    def test_no_freeze_or_validation_claim_and_54_cells(self):
        self.assertFalse(self.model["candidate_frozen"])
        self.assertFalse(self.model["independent_validation_passed"])
        self.assertEqual(sum(len(x["cells"]) for x in self.model["surfaces"].values()), 54)
        self.assertTrue(all(x["coverage"] == 1 for x in self.diagnostics["development_resubstitution"].values()))
        self.assertTrue(self.diagnostics["development_coverage_is_expected_by_construction"])

    def test_leave_one_gpu_out_excludes_slow_gpu(self):
        fold = self.diagnostics["leave_one_gpu_out_without_margin"][4]
        self.assertEqual(fold["heldout_gpu"], 4)
        self.assertNotIn(4, fold["training_gpus"])
        self.assertEqual(fold["training_batches"], 756)
        self.assertEqual(fold["heldout_batches"], 108)
        self.assertEqual(fold["without_margin"]["cold_ttft_ms"]["coverage"], 0)
        self.assertAlmostEqual(fold["without_margin"]["warm_ttft_ms"]["positive_residual_max_ms"], 193)
        self.assertGreaterEqual(self.model["margin_ms"]["warm"]["ttft_ms"], 193)

    def test_same_prompt_different_cache_residual_not_blended(self):
        a = predict(self.model, "warm", (1568, 32, 8))
        b = predict(self.model, "warm", (1568, 768, 8))
        self.assertLess(a["prediction_ms"]["ttft_ms"], b["prediction_ms"]["ttft_ms"])
        # A coordinate between anchors rounds upwards, not linearly downwards.
        p = predict(self.model, "warm", (2352, 200, 3))
        self.assertEqual(p["lookup_coordinate"], [7840, 384, 4])
        self.assertFalse(p["anchor_point"])
        self.assertFalse(p["independently_validated"])

    def test_ood_is_explicit_not_clamped(self):
        for mode, coordinate, options in [
            ("warm", (1568, 0, 1), {}), ("warm", (1568, 769, 1), {}),
            ("warm", (None, 32, 1), {}), ("warm", (31361, 32, 1), {}),
            ("cold", (1599, 1), {}), ("cold", (32129, 1), {}),
            ("cold", (1600, 9), {}), ("cold", (1600, 1), {"output_tokens": 256}),
            ("warm", (1568, 32, 1), {"runtime_cap": 1024}),
            ("warm", (1568, 32, True), {}),
        ]:
            with self.subTest(mode=mode, coordinate=coordinate, options=options):
                p = predict(self.model, mode, coordinate, **options)
                self.assertFalse(p["in_domain"])
                self.assertIsNone(p["prediction_ms"])

    def test_monotonic_and_sorted_json_roundtrip(self):
        model = json.loads(json.dumps(self.model, sort_keys=True))
        for mode, axes in AXES.items():
            coordinates = list(itertools.product(*(axes[n] for n in AXIS_NAMES[mode])))
            for a in coordinates:
                pa = predict(model, mode, a)["prediction_ms"]
                self.assertEqual(pa, predict(self.model, mode, a)["prediction_ms"])
                for b in coordinates:
                    if all(x <= y for x, y in zip(a, b)):
                        pb = predict(model, mode, b)["prediction_ms"]
                        self.assertTrue(all(pa[m] <= pb[m] for m in pa))

    def test_missing_cell_and_bad_warm_cache_rejected(self):
        observations = [batch_observation(r) for r in self.rows]
        with self.assertRaisesRegex(ValueError, "missing training cell"):
            fit_cells([r for r in observations if not (r["mode"] == "warm" and r["coordinate"] == (1568, 32, 1))])
        row = copy.deepcopy(next(r for r in self.rows if r["mode"] == "warm"))
        row["results"][0]["cached_prompt_tokens_observed"] = None
        with self.assertRaisesRegex(ValueError, "warm cache"):
            batch_observation(row)


class BuildTests(unittest.TestCase):
    def make_source(self, root):
        fixture(root)
        write_json(root / "RESIDUAL_DEVELOPMENT_AUDIT.json", audit(root))
        write_json(root / "EXPERIMENT_COMPLETE.json", {"status": "COMPLETE", "rows": 864})

    def test_build_preserves_sources_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "dev"
            self.make_source(source)
            before = {str(p): sha256(p) for p in source.rglob("*") if p.is_file()}
            output = root / "fit"
            report = build(source, output)
            self.assertEqual(report["status"], "CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION")
            self.assertEqual(before, {str(p): sha256(p) for p in source.rglob("*") if p.is_file()})
            self.assertEqual(sha256(report["candidate"]), report["candidate_sha256"])
            self.assertFalse(json.loads((output / "FIT_COMPLETE.json").read_text())["model_validated"])
            with self.assertRaises(FileExistsError):
                build(source, output)
            with self.assertRaises(ValueError):
                build(source, source / "fit")

    def test_passing_marker_does_not_bypass_raw_reaudit(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "dev"
            self.make_source(source)
            path = source / "raw/gpu_0/measurements.jsonl"
            path.write_text("\n".join(path.read_text().splitlines()[:-1]) + "\n")
            with self.assertRaisesRegex(ValueError, "source audit recheck failed"):
                build(source, root / "fit")
            self.assertFalse((root / "fit").exists())


if __name__ == "__main__":
    unittest.main()
