"""Synthetic full-grid/provenance regressions. No physical GPU validation."""
import asyncio
import copy
import hashlib
import json
import tempfile
import unittest
from collections import Counter
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from carbonaffinity.artifacts import sha256, write_json
from scripts import corun_observable_development as dev
from scripts import corun_observable_pilot as engine
from tests.test_corun_observable_pilot import FakeClient
from tests.test_latency_residual import Materializer, event


def grid_rows():
    async def run():
        client = FakeClient()
        try:
            return [await engine.run_case(SimpleNamespace(gpu_index=0, runtime_evidence="test"),
                Materializer(), client, c, "full-grid", protocol=dev) for c in dev.cases()]
        finally:
            await client.close()
    return asyncio.run(run())


class DevelopmentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = grid_rows()

    def test_exact_matrix_and_reversed_order(self):
        self.assertEqual(len(dev.workloads()), 23)
        self.assertEqual(len(dev.VICTIMS), 6)
        self.assertEqual(len(dev.cases()), 276)
        self.assertEqual(dev.design()["expected_rows"], 2208)
        self.assertEqual(len({c["case_id"] for c in dev.cases()}), 276)
        self.assertEqual([c["cell_id"] for c in dev.cases()[:138]],
                         [c["cell_id"] for c in reversed(dev.cases()[138:])])
        self.assertEqual(Counter(c["cell_id"] for c in dev.cases()).most_common()[0][1], 2)
        self.assertEqual(sum(c["phase_role"] == "future_arrival_control" for c in dev.cases()), 24)
        for c in dev.cases():
            if c["cached_target"]:
                self.assertEqual(c["prompt_tokens"] // 784 * 784, c["cached_target"])

    def test_reserved_coordinates_not_collected(self):
        for c in dev.cases():
            if c["cached_target"]:
                self.assertNotIn(c["cached_target"], dev.RESERVED["warm_cached_tokens"])
                self.assertNotIn(c["prompt_tokens"] - c["cached_target"], dev.RESERVED["warm_residual_tokens"])
            else:
                self.assertNotIn(c["prompt_tokens"], dev.RESERVED["cold_prompt_tokens"])
            for bg in c["backgrounds"]:
                self.assertNotIn(bg["output_tokens"], dev.RESERVED["background_output_tokens"])
                if not bg["cached_target"]:
                    self.assertNotIn(bg["prompt_tokens"], dev.RESERVED["background_prefill_tokens"])

    def test_entire_grid_matches_real_client_reservations(self):
        for row in self.rows:
            self.assertTrue(all(row["checks"].values()), row)
            self.assertEqual(engine.check_row(row, dev), row["checks"])
            self.assertFalse(row["snapshot_after_completion"]["workload_requests"])
        # The original V2 registry must not be mutated by running the new design.
        self.assertEqual(len(engine.cases()), 24)
        self.assertEqual(engine.VERSION, "observable-corun-development-pilot-v2")

    def test_count_and_budget_axes_are_not_conflated(self):
        rows = [r for r in self.rows if r["mode"] == "cold_p4096" and r["repeat"] == 0]
        decode = next(r for r in rows if r["case_id"].endswith("decode2_o64_r0"))
        self.assertEqual(decode["admission_snapshot"]["active_decode_tokens"], 128)
        mixed = next(r for r in rows if "mixed_p8192_po192_do64" in r["case_id"])
        snap = mixed["admission_snapshot"]
        self.assertEqual((snap["estimated_prefill_tokens"], snap["prefill_decode_tokens"], snap["active_decode_tokens"]), (8192, 192, 64))
        future = next(r for r in rows if r["scenario"] == "future2")
        self.assertEqual(future["admission_snapshot"]["workload_requests"], ())
        wrong = copy.deepcopy(decode)
        wrong["results"]["bg0"]["output_tokens"] = 63
        self.assertFalse(engine.check_row(wrong, dev)["bg0_request"])
        self.assertFalse(all(engine.check_row(decode).values()))

    def fixture(self, root):
        write_json(root / "LAUNCH.json", dict(runtime_cap=784, effective_cap_verified=True, cache_block784_verified=True))
        evidence = sha256(root / "LAUNCH.json")
        reference = root / "pilot_reference.json"
        reference.write_text('{"preserved":true}')
        write_json(root / "PRIOR_PILOT_GATE.json", dict(status="PASS", sha256={str(reference): sha256(reference)}))
        write_json(root / "PREREGISTRATION.json", dict(design=dev.design(), expected_rows=2208,
            prior_pilot_gate_sha256=sha256(root / "PRIOR_PILOT_GATE.json"),
            code_sha256={str(p): sha256(p) for p in dev.code_paths()}))
        logs = {}
        for g in range(8):
            raw = "".join(event(bt) for bt in (16, 32, 64)).encode()
            (root / f"vllm_gpu_{g}.log").write_bytes(raw)
            logs[str(g)] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
            path = root / "raw" / f"gpu_{g}" / "measurements.jsonl"
            path.parent.mkdir(parents=True)
            path.write_text("".join(json.dumps(dict(r, gpu_index=g, runtime_evidence_sha256=evidence)) + "\n" for r in self.rows))
        write_json(root / "SHAPE_PREWARM.json", dict(gpu_indices=list(range(8)), requests=64,
            checks=dict(all_shape_keys_observed=True), logs=logs))

    def test_full_audit_detects_order_prior_changes_and_tuning(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.fixture(root)
            report = dev.audit(root)
            self.assertEqual(report["status"], "PASS", report["checks"])
            self.assertEqual(report["future_control_rows"], 192)
            path = root / "raw/gpu_2/measurements.jsonl"
            lines = path.read_text().splitlines()
            path.write_text("\n".join(reversed(lines)) + "\n")
            report = dev.audit(root)
            self.assertFalse(report["checks"]["exact_preregistered_order"])
            self.assertTrue(report["checks"]["exact_2208_cases"])
            (root / "pilot_reference.json").write_text("changed")
            with (root / "vllm_gpu_7.log").open("a") as handle:
                handle.write(event(32))
            report = dev.audit(root)
            self.assertFalse(report["checks"]["prior_pilot_unchanged"])
            self.assertFalse(report["checks"]["no_post_prewarm_autotuning"])

    def test_prior_pilot_is_required_before_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            prior, run = root / "prior", root / "new"
            prior.mkdir()
            run.mkdir()
            write_json(prior / "EXPERIMENT_COMPLETE.json", dict(status="COMPLETE", rows=192))
            write_json(prior / engine.REPORT_NAME, dict(status="PASS", stage=engine.VERSION))
            for name in ("PREREGISTRATION.json", "LAUNCH.json", "SHAPE_PREWARM.json"):
                write_json(prior / name, {})
            for g in range(8):
                (prior / f"vllm_gpu_{g}.log").write_text("unchanged")
            with patch.object(dev, "PILOT_ROOT", prior), patch.object(engine, "audit", return_value={"status": "PASS"}) as audit:
                result = dev.prepare(run, None)
                self.assertFalse(result["model_fitting_in_this_run"])
                self.assertEqual(result["prior_pilot_gate_sha256"], sha256(run / "PRIOR_PILOT_GATE.json"))
                audit.assert_called_once_with(prior)
                (prior / "FATAL.json").write_text("{}")
                with self.assertRaisesRegex(ValueError, "fatal marker"):
                    dev.prepare(run, None)


if __name__ == "__main__":
    unittest.main()
