import itertools
import unittest

from scripts import fit_cache_energy_n3_candidate as fit


def synthetic_rows(gpu=0):
    rows = []
    for cached, output, concurrency, repeat, mode in itertools.product(
        fit.CACHED_TARGETS, fit.OUTPUTS, fit.CONCURRENCIES, fit.REPEATS, fit.MODES,
    ):
        prompt = cached + 384
        cold = prompt if mode == "cold" else 384
        warm = 0 if mode == "cold" else cached
        solo = 100 + .2 * cold + .03 * warm + 2 * output
        ratio = 1.0 if concurrency == 1 else (.5 if mode == "cold" else .4)
        rows.append({
            "gpu_index": gpu, "cached_context_target": cached,
            "prompt_tokens": prompt, "output_tokens": output,
            "concurrency": concurrency, "repeat": repeat, "mode": mode,
            "total_energy_j": solo * ratio * concurrency,
        })
    return rows


class CacheEnergyCandidateTests(unittest.TestCase):
    def test_per_gpu_fit_recovers_synthetic_training_data(self):
        rows = synthetic_rows()
        profile = fit.fit_gpu(rows)
        errors = [
            abs(fit.predict(row, profile) - fit.per_request_energy(row))
            for row in rows
        ]
        self.assertLess(max(errors), 1e-6)
        self.assertEqual(len(profile["batch_energy_model"]["cells"]), 12)

    def test_n2_interpolates_total_batch_energy(self):
        model = fit.fit_gpu(synthetic_rows())["batch_energy_model"]
        cold = fit.batch_multiplier(model, 1952, 64, "cold", 2)
        warm = fit.batch_multiplier(model, 1952, 64, "warm", 2)
        self.assertAlmostEqual(cold, .625)
        self.assertAlmostEqual(warm, .55)

    def test_nearest_bucket_matches_runtime_log_distance(self):
        self.assertEqual(fit.nearest_bucket(16064, list(fit.PROMPTS)), 8224)
        self.assertEqual(fit.nearest_bucket(128, list(fit.OUTPUTS)), 192)

    def test_evaluation_reports_all_groups(self):
        rows = []
        profiles = {}
        for gpu in fit.GPUS:
            group = synthetic_rows(gpu)
            rows.extend(group)
            profiles[str(gpu)] = fit.fit_gpu(group)
        result = fit.evaluate(rows, profiles)
        self.assertEqual(result["overall"]["samples"], 384)
        self.assertLess(result["overall"]["maximum"], 1e-9)
        self.assertEqual(result["gpu_7"]["samples"], 48)


if __name__ == "__main__":
    unittest.main()
