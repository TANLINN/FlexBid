import ast
import gzip
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from scripts import build_observable_corun_fit_command as builder
from scripts import build_observable_corun_development_command as development
from scripts.build_latency_residual_validation_transfer import build_payload


class CorunFitTransferTests(unittest.TestCase):
    def test_plaintext_roundtrip_python310_bash_cpu_only(self):
        text = builder.command()
        raw = text.split("<<'OBSERVABLE_CORUN_FIT_SOURCE_EOF'\n", 1)[1].split("OBSERVABLE_CORUN_FIT_SOURCE_EOF\n", 1)[0]
        self.assertEqual(raw.encode(), builder.payload())
        for name, source in zip(builder.NAMES, raw.split(builder.SEPARATOR)):
            ast.parse(source, filename=name, feature_version=(3, 10))
        ast.parse(builder.INSTALLER, feature_version=(3, 10))
        self.assertNotIn("base64", text)
        self.assertNotIn("nohup", text)
        self.assertNotIn("vllm serve", text)
        self.assertNotIn("nvidia-smi", text)
        self.assertLess(text.index("-m unittest"), text.index("-m scripts.fit_observable_corun_candidate --"))
        self.assertIn(builder.SOURCE, text)
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if bash.is_file():
            result = subprocess.run([str(bash), "-n"], input=text, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_immutable_install_core_guard_and_installed37_tests(self):
        base_payload = json.loads(gzip.decompress(build_payload()))
        digest_dev = hashlib.sha256(development.payload()).hexdigest()
        self.assertEqual(digest_dev, "1174f944b0eda2af84491c5d531f73ffbcddc9d76d19c9db85c0ecd18d75f2ca")
        files = {n: s.encode() for n, s in base_payload["files"].items()}
        files.update({n: s.encode() for n, s in zip(development.NAMES, development.payload().decode().split(development.SEPARATOR))})
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            base = root / "results/observable_corun_development_transfer_1174f944b0eda2af"
            for name, data in files.items():
                path = base / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
            for name in base_payload["required_core_lf_sha256"]:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes((builder.PROJECT / name).read_text(encoding="utf-8").encode())
            (base / "DEVELOPMENT_TRANSFER_MANIFEST.json").write_text(json.dumps(dict(source_payload_sha256=digest_dev,
                files_sha256={n: hashlib.sha256(d).hexdigest() for n, d in files.items()},
                required_core_lf_sha256=base_payload["required_core_lf_sha256"])))
            original = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file()}
            script = builder.INSTALLER.replace("project=Path('/root/CarbonAffinity')", "project=Path(" + repr(str(root)) + ")")
            raw = builder.payload()
            digest = hashlib.sha256(raw).hexdigest()
            def install(data=raw):
                return subprocess.run([sys.executable, "-c", script, digest], input=data, capture_output=True)
            self.assertNotEqual(install(raw + b"bad").returncode, 0)
            result = install()
            self.assertEqual(result.returncode, 0, result.stderr)
            destination = Path(result.stdout.decode().strip())
            self.assertEqual(install().returncode, 0)
            self.assertEqual(original, {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in original})
            env = {**os.environ, "PYTHONPATH": str(destination) + os.pathsep + str(builder.PROJECT), "PYTHONNOUSERSITE": "1"}
            tests = subprocess.run([sys.executable, "-m", "unittest", "tests.test_latency_residual",
                "tests.test_corun_observable_pilot", "tests.test_corun_observable_development",
                "tests.test_observable_corun_candidate", "-q"], cwd=destination, env=env,
                capture_output=True, text=True, timeout=180)
            self.assertEqual(tests.returncode, 0, tests.stderr)
            self.assertIn("Ran 37 tests", tests.stderr)
            target = destination / builder.NAMES[0]
            target.write_text("# preserve user changes")
            self.assertNotEqual(install().returncode, 0)
            self.assertEqual(target.read_text(), "# preserve user changes")
            core = root / "carbonaffinity/region.py"
            core.write_text("# changed core")
            rejected = install()
            self.assertNotEqual(rejected.returncode, 0)
            self.assertIn("CORE_SOURCE_CHANGED", rejected.stderr.decode())


if __name__ == "__main__":
    unittest.main()
