"""Transfer and launch gates: synthetic/local checks, never starts a GPU."""
import base64
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from scripts.build_latency_residual_transfer import DEPENDENCIES, INSTALLER, PROJECT, build_payload, command


class TransferTests(unittest.TestCase):
    def setup_project(self, root):
        for name in DEPENDENCIES:
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes((PROJECT / name).read_bytes())

    def install(self, root, payload, digest=None):
        return subprocess.run([sys.executable, "-c", INSTALLER,
            digest or hashlib.sha256(payload).hexdigest(), str(root)],
            input=base64.b64encode(payload).decode(), text=True, capture_output=True, timeout=30)

    def test_verified_bundle_idempotent_and_installed_tests_run(self):
        payload = build_payload()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.setup_project(root)
            before = {p: (root / p).read_bytes() for p in DEPENDENCIES}
            first = self.install(root, payload)
            self.assertEqual(first.returncode, 0, first.stderr)
            bundle = Path(first.stdout.strip())
            second = self.install(root, payload)
            self.assertEqual(second.returncode, 0, second.stderr)
            self.assertEqual(first.stdout, second.stdout)
            manifest = json.loads((bundle / "TRANSFER_MANIFEST.json").read_text())
            for name, digest in manifest["files_sha256"].items():
                self.assertEqual(hashlib.sha256((bundle / name).read_bytes()).hexdigest(), digest)
            env = {**os.environ, "PYTHONPATH": str(bundle) + os.pathsep + str(PROJECT), "PYTHONNOUSERSITE": "1"}
            checked = subprocess.run([sys.executable, "-m", "unittest", "tests.test_latency_residual", "-v"],
                                     cwd=bundle, env=env, capture_output=True, text=True, timeout=60)
            self.assertEqual(checked.returncode, 0, checked.stdout + checked.stderr)
            self.assertIn("Ran 8 tests", checked.stderr)
            self.assertEqual(before, {p: (root / p).read_bytes() for p in DEPENDENCIES})

    def test_corruption_and_core_mismatch_do_not_install(self):
        payload = build_payload()
        for issue in ("checksum", "core"):
            with self.subTest(issue=issue), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                self.setup_project(root)
                if issue == "core":
                    (root / DEPENDENCIES[0]).write_text("# a different server version\n")
                outcome = self.install(root, payload, "0" * 64 if issue == "checksum" else None)
                self.assertNotEqual(outcome.returncode, 0)
                self.assertFalse((root / "results").exists())

    def test_conflicting_bundle_is_not_overwritten(self):
        payload = build_payload()
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.setup_project(root)
            bundle = root / "results" / ("residual_latency_transfer_" + hashlib.sha256(payload).hexdigest()[:16])
            target = bundle / "scripts/latency_residual_protocol.py"
            target.parent.mkdir(parents=True)
            target.write_text("# user modified file\n")
            outcome = self.install(root, payload)
            self.assertNotEqual(outcome.returncode, 0)
            self.assertIn("NOT_OVERWRITTEN", outcome.stderr)
            self.assertEqual(target.read_text(), "# user modified file\n")
            self.assertFalse((bundle / "scripts/measure_latency_residual.py").exists())

    def test_command_has_gates_and_valid_bash_syntax(self):
        script = command(build_payload())
        self.assertLess(script.index("if RESIDUAL_BUNDLE="), script.index("unittest tests.test_latency_residual"))
        self.assertLess(script.index("unittest tests.test_latency_residual"), script.index("nohup env"))
        self.assertIn('cd "$RESIDUAL_BUNDLE"', script)
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if not bash.exists():
            self.skipTest("bash unavailable")
        checked = subprocess.run([str(bash), "-n"], input=script, text=True, capture_output=True, timeout=20)
        self.assertEqual(checked.returncode, 0, checked.stderr)


class SupervisorTests(unittest.TestCase):
    def test_prewarm_failure_blocks_measurement_and_records_fatal(self):
        from scripts import run_latency_residual_campaign as runner
        processes, calls = [], []

        class Process:
            def __init__(self, args, **kwargs):
                self.pid = 5000 + len(processes)
                self.returncode = 1 if "--prewarm-only" in args else None
                calls.append(args)
                processes.append(self)
                if "serve" in args:
                    kwargs["stdout"].write("max_num_batched_tokens=784\nSetting attention block size to 784 tokens\n")
                    kwargs["stdout"].flush()
            def poll(self):
                return self.returncode
            def wait(self):
                return self.returncode

        def killpg(pid, _sig):
            next(p for p in processes if p.pid == pid).returncode = 0

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            model = root / "model"
            model.mkdir()
            (model / "config.json").write_text("{}")
            output = root / "results/run"
            args = SimpleNamespace(project_root=root, model_dir=model, model="test", output_root=output, prewarm_only=False)
            # Do not change global os.name (pathlib on Windows relies on it).
            fake_os = SimpleNamespace(name="posix", environ=os.environ, pathsep=os.pathsep,
                                      getpid=os.getpid, killpg=killpg)
            http = MagicMock()
            http.__enter__.return_value.get.return_value.is_success = True
            sock = MagicMock()
            sock.__enter__.return_value.connect_ex.return_value = 1
            fake_signal = SimpleNamespace(SIGTERM=15, SIGINT=2, SIGKILL=9, signal=MagicMock())
            with patch.object(runner, "arguments", return_value=args), patch.object(runner, "os", fake_os), \
                 patch.object(runner, "signal", fake_signal), \
                 patch.object(runner.signal, "signal"), patch.object(runner.socket, "socket", return_value=sock), \
                 patch.object(runner.httpx, "Client", return_value=http), \
                 patch.object(runner.subprocess, "check_output", return_value=""), \
                 patch.object(runner.subprocess, "Popen", Process), patch("builtins.print"), \
                 self.assertRaises(SystemExit) as stopped:
                runner.main()
            self.assertEqual(stopped.exception.code, 1)
            self.assertFalse(any("scripts.measure_latency_residual" in c for c in calls))
            self.assertTrue(any("--prewarm-only" in c for c in calls))
            self.assertFalse((output / "EXPERIMENT_COMPLETE.json").exists())
            self.assertIn("worker failed", json.loads((output / "FATAL.json").read_text())["error"])
            self.assertTrue(all(p.returncode == 0 for p in processes))


if __name__ == "__main__":
    unittest.main()
