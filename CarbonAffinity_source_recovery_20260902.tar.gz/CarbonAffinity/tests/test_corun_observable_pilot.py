"""Synthetic only: no GPU, inference endpoint, or latency performance claim."""
import asyncio
import copy
import hashlib
import json
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import httpx

from carbonaffinity.artifacts import write_json, sha256
from carbonaffinity.models import CompletionResult, RequestSpec
from carbonaffinity.region import RegionClient
from scripts import corun_observable_pilot as pilot
from tests.test_latency_residual import Materializer, event


class FakeClient(RegionClient):
    def __init__(self, bad_cache=False, bad_output=False):
        super().__init__({"id": "gpu_0", "api_base": "http://127.0.0.1:1/v1", "model": "synthetic", "admission_concurrency": 8})
        self.primed = set()
        self.victim_started = asyncio.Event()
        self.bad_cache, self.bad_output = bad_cache, bad_output

    async def reset_prefix_cache(self):
        self.primed.clear()
        self.victim_started.clear()
        return True

    async def _complete_inner(self, request, tokens, salt, *args):
        cached = (len(tokens) // 784) * 784 if salt in self.primed else None
        if request.max_output_tokens == 1:
            self.primed.add(salt)
        else:
            # Hold the designed background phase until the admission snapshot
            # has been taken. Wall-clock sleeps made mixed-phase fixtures race
            # under host load. The real-parser test independently verifies the
            # production first-token state transition.
            if ":bg" in request.request_id:
                hold_prefill = not cached
                if not hold_prefill:
                    old = self._workloads[request.request_id]
                    self._workloads[request.request_id] = ("decode", 0, old[2], old[3])
                await self.victim_started.wait()
            else:
                self.victim_started.set()
            old = self._workloads[request.request_id]
            self._workloads[request.request_id] = ("decode", 0, old[2], old[3])
            await asyncio.sleep(0)
        if self.bad_cache and request.max_output_tokens > 1:
            cached = None
        output = 63 if self.bad_output else request.max_output_tokens
        return CompletionResult(request.request_id, self.region_id, True, 200,
                                1, 2, 3, 100., 35., output, len(tokens), cached)


def one_case(scenario="mixed", mode="warm"):
    return next(c for c in pilot.cases() if c["scenario"] == scenario and c["mode"] == mode)


def run_grid(grid, **kwargs):
    async def run():
        client = FakeClient(**kwargs)
        try:
            return [await pilot.run_case(SimpleNamespace(gpu_index=0, runtime_evidence="synthetic"),
                        Materializer(), client, c, "test") for c in grid]
        finally:
            await client.close()
    return asyncio.run(run())


class ObservablePilotTests(unittest.TestCase):
    def test_primed_decode_pair_uses_real_stream_parser_and_distinct_cache(self):
        async def run(budget):
            primed, calls = {}, []
            release = asyncio.Event()
            class Stream(httpx.AsyncByteStream):
                def __init__(self, payload):
                    self.payload = payload
                async def __aiter__(self):
                    p = self.payload
                    salt, tokens, output = p["cache_salt"], p["prompt"], p["max_tokens"]
                    is_background = salt.endswith(("bg0", "bg1"))
                    cached = 15680 if primed.get(salt) == tokens else None
                    if output == 1:
                        primed[salt] = tokens
                    elif not is_background:
                        release.set()
                    yield b'data: {"choices":[{"text":"a"}]}\n\n'
                    if is_background and output > 1:
                        await release.wait()
                    await asyncio.sleep(0)
                    usage = dict(prompt_tokens=len(tokens), completion_tokens=output)
                    if cached is not None:
                        usage["prompt_tokens_details"] = dict(cached_tokens=cached)
                    yield ("data: " + json.dumps(dict(choices=[dict(text="b")], usage=usage)) + "\n\ndata: [DONE]\n\n").encode()
            def handle(request):
                if request.url.path == "/reset_prefix_cache":
                    primed.clear()
                    return httpx.Response(200, json=True)
                payload = json.loads(request.content)
                calls.append(payload)
                return httpx.Response(200, stream=Stream(payload))
            client = RegionClient(dict(id="real-parser", api_base="http://test/v1", model="mock"))
            await client._client.aclose()
            client._client = httpx.AsyncClient(transport=httpx.MockTransport(handle), trust_env=False)
            try:
                case = copy.deepcopy(one_case("decode2", "cold_small"))
                for bg in case["backgrounds"]:
                    bg["output_tokens"] = budget
                protocol = SimpleNamespace(VERSION=pilot.VERSION, cases=lambda: [case])
                row = await asyncio.wait_for(pilot.run_case(SimpleNamespace(gpu_index=0, runtime_evidence="synthetic"),
                    Materializer(), client, case, "real-pair", protocol), 3)
                self.assertTrue(all(row["checks"].values()), row)
                self.assertEqual([e[1:] for e in row["admission_snapshot"]["workload_requests"]],
                                 [("decode", 0, budget), ("decode", 0, budget)])
                primes = {p["cache_salt"]: p["prompt"] for p in calls if p["max_tokens"] == 1}
                backgrounds = [p for p in calls if p["max_tokens"] > 1 and p["cache_salt"].endswith(("bg0", "bg1"))]
                self.assertEqual(len(primes), 2)
                self.assertEqual(len(backgrounds), 2)
                for p in backgrounds:
                    self.assertEqual(primes[p["cache_salt"]], p["prompt"])
                self.assertEqual(client.snapshot().workload_requests, ())
            finally:
                release.set()
                await client.close()
        for budget in (64, 192):
            with self.subTest(output_budget=budget):
                asyncio.run(run(budget))

    def test_real_stream_parser_decode_snapshot_matches_sampler_contract(self):
        # Exercise the production first-token transition, not FakeClient's
        # replacement implementation. No socket or external server is used.
        async def run():
            observed, release = asyncio.Event(), asyncio.Event()
            class Stream(httpx.AsyncByteStream):
                async def __aiter__(self):
                    yield b'data: {"choices":[{"text":"a"}]}\n\n'
                    observed.set()
                    await release.wait()
                    yield b'data: {"choices":[{"text":"b"}],"usage":{"prompt_tokens":16384,"completion_tokens":192}}\n\ndata: [DONE]\n\n'
            client = RegionClient(dict(id="real-parser", api_base="http://test/v1", model="mock"))
            await client._client.aclose()
            client._client = httpx.AsyncClient(transport=httpx.MockTransport(
                lambda request: httpx.Response(200, stream=Stream())), trust_env=False)
            job = asyncio.create_task(client.complete(RequestSpec("bg", 0, 16384, 192, "bg"), [1]*16384))
            try:
                await asyncio.wait_for(observed.wait(), 2)
                snap = client.snapshot()
                self.assertEqual(snap.workload_requests, (("bg", "decode", 0, 192),))
                self.assertEqual((snap.estimated_prefill_tokens, snap.prefill_decode_tokens, snap.active_decode_tokens), (0, 0, 192))
                release.set()
                result = await job
                self.assertTrue(result.success)
                self.assertEqual(client.snapshot().workload_requests, ())
            finally:
                release.set()
                if not job.done():
                    job.cancel()
                await asyncio.gather(job, return_exceptions=True)
                await client.close()
        asyncio.run(run())

    def test_matrix_scope_and_cache_alignment(self):
        self.assertEqual(len(pilot.cases()), 24)
        self.assertEqual(pilot.design()["expected_rows"], 192)
        self.assertFalse(pilot.design()["slo_is_pass_gate"])
        self.assertEqual(len({c["case_id"] for c in pilot.cases()}), 24)
        self.assertEqual([c["scenario"] for c in pilot.cases()[:2]], ["decode2", "mixed"])
        self.assertEqual(pilot.VERSION, "observable-corun-development-pilot-v2")
        for c in pilot.cases():
            if c["mode"] == "warm":
                self.assertEqual(c["prompt_tokens"] // 784 * 784, c["cached_target"])
            for bg in c["backgrounds"]:
                self.assertEqual(bg["output_tokens"], 192)
                primed = c["scenario"].startswith("decode") or (c["scenario"] == "mixed" and bg["role"] == "bg0")
                self.assertEqual((bg["prompt_tokens"], bg["cached_target"]), (16064, 15680) if primed else (16384, 0))

    def test_background_priming_is_not_proof_of_observed_cache(self):
        row = run_grid([one_case("decode2")])[0]
        for role in ("bg0", "bg1"):
            for bad in (None, 0, 15679):
                wrong = copy.deepcopy(row)
                wrong["results"][role]["cached_prompt_tokens_observed"] = bad
                wrong["cache_features"][role] = pilot.features(wrong["results"][role])
                self.assertFalse(pilot.check_row(wrong)[role + "_request"])
            for field in ("cache_salt", "prompt_sha256"):
                wrong = copy.deepcopy(row)
                wrong["background_primes"][role][field] = "different"
                self.assertFalse(pilot.check_row(wrong)["background_primes"])

    def test_early_background_completion_retains_phase_evidence_without_victim(self):
        class EarlyClient(FakeClient):
            async def _complete_inner(self, request, tokens, salt, *args):
                if request.request_id.endswith(":bg0") and request.max_output_tokens == 192:
                    return CompletionResult(request.request_id, self.region_id, True, 200,
                        1, 2, 3, 100., 35., 192, len(tokens), 15680)
                return await super()._complete_inner(request, tokens, salt, *args)
        async def run():
            client = EarlyClient()
            try:
                return await asyncio.wait_for(pilot.run_case(SimpleNamespace(gpu_index=0, runtime_evidence="synthetic"),
                    Materializer(), client, one_case("decode2"), "early"), 3)
            finally:
                await client.close()
        row = asyncio.run(run())
        self.assertIn("before requested phase", row["collection_error"])
        self.assertEqual(row["phase_failure"]["expected"], [0, 2])
        self.assertEqual(row["phase_failure"]["actual"], [0, 1])
        self.assertEqual(row["phase_failure"]["jobs_done"], [True, False])
        self.assertNotIn("victim", row["results"])
        self.assertNotIn("admission_snapshot", row)
        self.assertFalse(row["checks"]["no_collection_error"])
        self.assertFalse(row["snapshot_after_completion"]["workload_requests"])

    def test_all_24_cases_with_real_client_reservations(self):
        for row in run_grid(pilot.cases()):
            self.assertTrue(all(row["checks"].values()), row)
            self.assertEqual(row["checks"], pilot.check_row(row))
            self.assertFalse(row["snapshot_after_completion"]["workload_requests"])

    def test_live_mixed_features_and_future_exclusion(self):
        mixed, future = run_grid([one_case(), one_case("future2")])
        snap = mixed["admission_snapshot"]
        self.assertEqual((snap["estimated_prefill_tokens"], snap["prefill_decode_tokens"], snap["active_decode_tokens"]), (16384, 192, 192))
        self.assertEqual(mixed["cache_features"]["victim"]["observed_uncached_tokens"], 384)
        self.assertEqual(future["admission_snapshot"]["workload_requests"], ())
        tampered = copy.deepcopy(mixed)
        tampered["admission_snapshot"]["active_decode_tokens"] = 191
        self.assertFalse(all(pilot.check_row(tampered).values()))

    def test_decode_clears_prefill_but_keeps_complete_output_budget(self):
        decoded, prefilling = run_grid([one_case("decode1"), one_case("prefill1")])
        entry = decoded["admission_snapshot"]["workload_requests"][0]
        self.assertEqual(entry[1:], ("decode", 0, 192))
        self.assertTrue(all(pilot.check_row(decoded).values()))
        for column, bad in ((2, 16384), (3, 191)):
            wrong = copy.deepcopy(decoded)
            values = list(entry)
            values[column] = bad
            wrong["admission_snapshot"]["workload_requests"] = [values]
            self.assertFalse(pilot.check_row(wrong)["live_identity_and_budgets"])
        values = list(prefilling["admission_snapshot"]["workload_requests"][0])
        self.assertEqual(values[1:], ["prefill", 16384, 192])
        values[2] = 0
        prefilling["admission_snapshot"]["workload_requests"] = [values]
        self.assertFalse(pilot.check_row(prefilling)["live_identity_and_budgets"])

    def test_unknown_warm_cache_and_wrong_tokens_fail(self):
        for kwargs in ({"bad_cache": True}, {"bad_output": True}):
            row = run_grid([one_case("baseline")], **kwargs)[0]
            self.assertFalse(all(pilot.check_row(row).values()))
        cold = run_grid([one_case("baseline", "cold_small")])[0]
        self.assertIsNone(cold["cache_features"]["victim"]["observed_uncached_tokens"])
        self.assertEqual(cold["own_uncached_reservation"], 4096)

    def test_finished_background_not_relabelled_as_decode(self):
        async def run():
            client = FakeClient()
            try:
                job = asyncio.create_task(asyncio.sleep(0))
                await job
                with self.assertRaisesRegex(RuntimeError, "before requested phase"):
                    await pilot.await_phases(client, [job], (0, 1))
            finally:
                await client.close()
        asyncio.run(run())

    def test_failed_row_saved_and_no_overwrite(self):
        async def run(path):
            args = SimpleNamespace(output=path, gpu_index=0, runtime_evidence="synthetic")
            client = FakeClient(bad_cache=True)
            try:
                with self.assertRaisesRegex(RuntimeError, "raw row retained"):
                    await pilot.collect(args, Materializer(), client, [one_case("baseline")])
                row = json.loads(path.read_text())
                self.assertIsNone(row["results"]["victim"]["cached_prompt_tokens_observed"])
                with self.assertRaises(FileExistsError):
                    await pilot.collect(args, Materializer(), client, [one_case("baseline")])
            finally:
                await client.close()
        with tempfile.TemporaryDirectory() as temp, patch("builtins.print"):
            asyncio.run(run(Path(temp) / "measurements.jsonl"))

    def test_audit_exact_grid_tampering_and_new_tuning(self):
        rows = run_grid(pilot.cases())
        for row in rows:
            self.assertTrue(all(row["checks"].values()), row)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            write_json(root / "LAUNCH.json", dict(runtime_cap=784, effective_cap_verified=True, cache_block784_verified=True))
            evidence = sha256(root / "LAUNCH.json")
            write_json(root / "PREREGISTRATION.json", dict(design=pilot.design(), expected_rows=192,
                code_sha256={str(Path(pilot.__file__).resolve()): sha256(pilot.__file__)}))
            logs = {}
            for g in range(8):
                raw = "".join(event(bt) for bt in (16, 32, 64)).encode()
                (root / f"vllm_gpu_{g}.log").write_bytes(raw)
                logs[str(g)] = dict(bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
                path = root / "raw" / f"gpu_{g}" / "measurements.jsonl"
                path.parent.mkdir(parents=True)
                path.write_text("".join(json.dumps(dict(r, gpu_index=g, runtime_evidence_sha256=evidence)) + "\n" for r in rows))
            write_json(root / "SHAPE_PREWARM.json", dict(gpu_indices=list(range(8)), requests=64,
                       checks=dict(all_shape_keys_observed=True), logs=logs))
            report = pilot.audit(root)
            self.assertEqual(report["status"], "PASS", report)
            with (root / "vllm_gpu_3.log").open("a") as handle:
                handle.write(event(32))
            self.assertEqual(pilot.audit(root)["status"], "FAIL")
            (root / "raw/gpu_2/measurements.jsonl").write_text("")
            self.assertFalse(pilot.audit(root)["checks"]["exact_192_cases"])


if __name__ == "__main__":
    unittest.main()
