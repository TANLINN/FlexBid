from __future__ import annotations

import unittest
from collections import Counter

from carbonaffinity.baseline_closed_loop import BaselineClosedLoopPlanner
from carbonaffinity.closed_loop import ClosedLoopCapacityError
from carbonaffinity.models import RegionSnapshot
from carbonaffinity.offline_oracle import OracleProblem


def option(
    *,
    cold_energy: float = 10.0,
    warm_energy: float = 5.0,
    tpot_add: float = 0.0,
) -> dict:
    return {
        "cold_energy_j": cold_energy,
        "warm_energy_j": warm_energy,
        "cold_ttft_ms": 10.0,
        "warm_ttft_ms": 5.0,
        "tpot_ms": 10.0,
        "cold_tpot_ms_per_additional_request": tpot_add,
        "warm_tpot_ms_per_additional_request": tpot_add,
        "learned_future_energy_j": 2.0,
    }


def problem(*, initial=None, tpot_add=0.0) -> OracleProblem:
    rows = []
    for request_id, session_id in (("r0", "s0"), ("r1", "s1"), ("r2", "s2")):
        rows.append({
            "request_id": request_id,
            "session_id": session_id,
            "ttft_slo_ms": 100.0,
            "tpot_slo_ms": 100.0,
            "future_work_in_domain": True,
            "options": {
                "a": option(cold_energy=100.0, warm_energy=100.0, tpot_add=tpot_add),
                "b": option(cold_energy=10.0, warm_energy=1.0, tpot_add=tpot_add),
            },
        })
    return OracleProblem.from_dict({
        "regions": [
            {"region_id": "a", "capacity": 2},
            {"region_id": "b", "capacity": 2},
        ],
        "initial_placements": initial or {},
        "epochs": [{
            "epoch_id": "0",
            "carbon_lbs_per_mwh": {"a": 1.0, "b": 20.0},
            "requests": rows,
        }],
    })


def snapshots() -> dict[str, RegionSnapshot]:
    return {
        "a": RegionSnapshot("a", 0, 0, capacity=2),
        "b": RegionSnapshot("b", 0, 0, capacity=2),
    }


class BaselineClosedLoopPlannerTests(unittest.TestCase):
    def test_pressure_only_balances_projected_load(self) -> None:
        planner = BaselineClosedLoopPlanner(problem(), "pressure_only")
        plan = planner.plan(["r0", "r1"], snapshots(), {"a": 1, "b": 20})
        self.assertEqual(
            Counter(item.region_id for item in plan.assignments),
            Counter({"a": 1, "b": 1}),
        )

    def test_cleanest_now_respects_capacity(self) -> None:
        planner = BaselineClosedLoopPlanner(problem(), "cleanest_now")
        plan = planner.plan(["r0", "r1", "r2"], snapshots(), {"a": 1, "b": 20})
        self.assertEqual(
            Counter(item.region_id for item in plan.assignments),
            Counter({"a": 2, "b": 1}),
        )

    def test_sticky_keeps_feasible_session_placement(self) -> None:
        planner = BaselineClosedLoopPlanner(
            problem(initial={"s0": "b"}), "sticky"
        )
        plan = planner.plan(["r0"], snapshots(), {"a": 1, "b": 20})
        self.assertEqual(plan.assignments[0].region_id, "b")

    def test_carbon_affinity_can_prefer_warm_dirtier_region(self) -> None:
        planner = BaselineClosedLoopPlanner(
            problem(initial={"s0": "b"}), "carbon_affinity"
        )
        plan = planner.plan(["r0"], snapshots(), {"a": 1, "b": 20})
        self.assertEqual(plan.assignments[0].region_id, "b")

    def test_tentative_batch_rechecks_earlier_requests(self) -> None:
        planner = BaselineClosedLoopPlanner(
            problem(tpot_add=100.0), "cleanest_now"
        )
        plan = planner.plan(["r0", "r1"], snapshots(), {"a": 1, "b": 20})
        self.assertEqual(
            Counter(item.region_id for item in plan.assignments),
            Counter({"a": 1, "b": 1}),
        )

    def test_unhealthy_regions_are_not_selected(self) -> None:
        planner = BaselineClosedLoopPlanner(problem(), "cleanest_now")
        state = snapshots()
        state["a"] = RegionSnapshot("a", 0, 0, healthy=False, capacity=2)
        plan = planner.plan(["r0"], state, {"a": 1, "b": 20})
        self.assertEqual(plan.assignments[0].region_id, "b")

    def test_no_slo_feasible_region_raises(self) -> None:
        planner = BaselineClosedLoopPlanner(
            problem(tpot_add=100.0), "cleanest_now"
        )
        state = snapshots()
        state["a"] = RegionSnapshot("a", 1, 0, capacity=2)
        state["b"] = RegionSnapshot("b", 1, 0, capacity=2)
        with self.assertRaises(ClosedLoopCapacityError):
            planner.plan(["r0"], state, {"a": 1, "b": 20})


if __name__ == "__main__":
    unittest.main()
