import ast
import gzip
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from scripts import build_observable_corun_validation_command as builder
from scripts import build_observable_corun_fit_command as fit_builder
from scripts import build_observable_corun_development_command as dev_builder
from scripts.build_latency_residual_validation_transfer import build_payload


class ValidationTransferTests(unittest.TestCase):
    def test_plaintext_roundtrip_python310_bash_and_short_summary(self):
        text = builder.command()
        raw = text.split("<<'OBSERVABLE_CORUN_VALIDATION_SOURCE_EOF'\n", 1)[1].split("OBSERVABLE_CORUN_VALIDATION_SOURCE_EOF\n", 1)[0]
        self.assertEqual(raw.encode(), builder.payload())
        for name, source in zip(builder.NAMES, raw.split(builder.SEPARATOR)):
            ast.parse(source, filename=name, feature_version=(3, 10))
        ast.parse(builder.INSTALLER, feature_version=(3, 10))
        summary_python = builder.SUMMARY.split("<<'CORUN_VALIDATION_SUMMARY_EOF'\n", 1)[1].split("CORUN_VALIDATION_SUMMARY_EOF\n", 1)[0]
        ast.parse(summary_python, feature_version=(3, 10))
        self.assertNotIn("base64", text)
        self.assertLess(text.index("-m unittest"), text.index("nohup env"))
        self.assertIn("EXPECTED_ROWS=768", text)
        self.assertIn("dc4aef7156118107a0c3e90b409d90d4c9b468138aa69039bae2498305b4d84b", text)
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if bash.is_file():
            for command in (text, builder.SUMMARY):
                result = subprocess.run([str(bash), "-n"], input=command, text=True, capture_output=True)
                self.assertEqual(result.returncode, 0, result.stderr)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "OBSERVABLE_CORUN_INDEPENDENT_VALIDATION_REPORT.json").write_text(json.dumps(
                dict(status="FAIL", rows=768, checks=dict(raw_integrity=False), candidate_frozen=False,
                     bounded_primary_validation_passed=False, continuous_arrival_tpot_validated=False)))
            result = subprocess.run([sys.executable, "-c", summary_python, str(root)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("STATUS = FAIL", result.stdout)
            self.assertIn("raw_integrity", result.stdout)
            self.assertLess(len(result.stdout.splitlines()), 30)
            empty = subprocess.run([sys.executable, "-c", summary_python, ""], capture_output=True, text=True)
            self.assertNotEqual(empty.returncode, 0)

    def test_immutable_install_and_installed44_tests(self):
        base_payload = json.loads(gzip.decompress(build_payload()))
        digest_fit = hashlib.sha256(fit_builder.payload()).hexdigest()
        self.assertEqual(digest_fit, "90207d3fe0c9f468e1d5fdccfe103d969a90d3d6ca0de2d6535c250e28cdae7a")
        files = {n: s.encode() for n, s in base_payload["files"].items()}
        for previous in (dev_builder, fit_builder):
            files.update({n: s.encode() for n, s in zip(previous.NAMES, previous.payload().decode().split(previous.SEPARATOR))})
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            base = root / "results/observable_corun_fit_transfer_90207d3fe0c9f468"
            for name, data in files.items():
                path = base / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
            for name in base_payload["required_core_lf_sha256"]:
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes((builder.PROJECT / name).read_text(encoding="utf-8").encode())
            (base / "CORUN_FIT_TRANSFER_MANIFEST.json").write_text(json.dumps(dict(source_payload_sha256=digest_fit,
                files_sha256={n: hashlib.sha256(d).hexdigest() for n, d in files.items()},
                required_core_lf_sha256=base_payload["required_core_lf_sha256"])))
            old_hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob("*") if p.is_file()}
            script = builder.INSTALLER.replace("project=Path('/root/CarbonAffinity')", "project=Path(" + repr(str(root)) + ")")
            raw = builder.payload()
            digest = hashlib.sha256(raw).hexdigest()
            def install(data=raw):
                return subprocess.run([sys.executable, "-c", script, digest], input=data, capture_output=True)
            self.assertNotEqual(install(raw + b"corrupt").returncode, 0)
            self.assertFalse(list(root.glob("results/observable_corun_validation_transfer_*")))
            result = install()
            self.assertEqual(result.returncode, 0, result.stderr)
            destination = Path(result.stdout.decode().strip())
            self.assertEqual(install().returncode, 0)
            self.assertEqual(old_hashes, {p: hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in old_hashes})
            env = {**os.environ, "PYTHONPATH": str(destination) + os.pathsep + str(builder.PROJECT), "PYTHONNOUSERSITE": "1"}
            tests = subprocess.run([sys.executable, "-m", "unittest", "tests.test_latency_residual",
                "tests.test_corun_observable_pilot", "tests.test_corun_observable_development",
                "tests.test_observable_corun_candidate", "tests.test_observable_corun_validation", "-q"],
                cwd=destination, env=env, capture_output=True, text=True, timeout=240)
            self.assertEqual(tests.returncode, 0, tests.stderr)
            self.assertIn("Ran 44 tests", tests.stderr)
            target = destination / builder.NAMES[0]
            target.write_text("# user changes")
            self.assertNotEqual(install().returncode, 0)
            self.assertEqual(target.read_text(), "# user changes")


if __name__ == "__main__":
    unittest.main()
