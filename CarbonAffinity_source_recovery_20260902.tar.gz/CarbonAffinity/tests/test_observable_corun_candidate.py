"""Synthetic CPU regressions; no endpoint/GPU/independent-validation claim."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from carbonaffinity.artifacts import sha256, write_json
from scripts import corun_observable_development as dev
from scripts import observable_corun_candidate as model_api
from scripts.fit_observable_corun_candidate import build
from tests import test_corun_observable_development as fixtures


def training_rows(base):
    rows = []
    for gpu in range(8):
        for original in base:
            row = copy.deepcopy(original)
            row["gpu_index"] = gpu
            query = model_api.admission_query(row)
            stratum, coord, _ = model_api.coordinates(query)
            offset = 200 if gpu == 4 else gpu
            nonlinear_mixed = 5000 if "prefill1|decode1" in stratum else 0
            row["results"]["victim"]["ttft_ms"] = 100 + sum(coord) + nonlinear_mixed + offset
            row["results"]["victim"]["tpot_ms"] = 30 + sum(coord) * .001 + offset * .01
            rows.append(row)
    return rows


class CorunCandidateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = fixtures.grid_rows()
        cls.rows = training_rows(cls.base)
        cls.model, cls.report = model_api.fit_candidate(cls.rows)

    def test_exact_partition_and_no_validation_claim(self):
        self.assertEqual(self.report["training_rows"], 2016)
        self.assertEqual(self.report["excluded_future_control_rows"], 192)
        self.assertEqual(len(self.model["surfaces"]), 12)
        self.assertEqual(sum(len(s["cells"]) for s in self.model["surfaces"].values()), 126)
        self.assertTrue(all(c["samples"] == 16 for s in self.model["surfaces"].values() for c in s["cells"].values()))
        self.assertFalse(self.model["candidate_frozen"])
        self.assertFalse(self.model["independent_validation_passed"])
        self.assertTrue(all(g["coverage"] == 1 for g in self.report["development_resubstitution"].values()))

    def test_leave_slow_gpu_out_and_margin_not_independent(self):
        fold = self.report["leave_one_gpu_out_without_margin"][4]
        self.assertNotIn(4, fold["training_gpus"])
        self.assertEqual((fold["training_rows"], fold["heldout_rows"]), (1764, 252))
        for mode in ("cold", "warm"):
            ev = fold["without_margin"][mode + "_ttft_ms"]
            self.assertEqual(ev["coverage"], 0)
            self.assertAlmostEqual(ev["positive_residual_max_ms"], 193)
            self.assertGreaterEqual(self.model["margin_ms"][mode]["ttft_ms"], 193)

    def test_future_control_poison_never_changes_cells_or_margin(self):
        rows = copy.deepcopy(self.rows)
        for row in rows:
            if row["phase_role"] == "future_arrival_control":
                row["results"]["victim"]["ttft_ms"] = 1e9
                row["results"]["victim"]["tpot_ms"] = 1e8
        model, report = model_api.fit_candidate(rows)
        self.assertEqual(model, self.model)
        self.assertTrue(all(g["coverage"] == 0 for g in report["future_controls_diagnostic_only"].values()))

    def test_admission_features_never_read_outcomes_or_future_jobs(self):
        row = copy.deepcopy(next(r for r in self.rows if r["scenario"] == "future2"))
        query = model_api.admission_query(row)
        row.update(results=None, cache_features=None, backgrounds=[], scenario="unread",
                   mode="unread", admission_snapshot_wall_ns=-1)
        row["requests"] = {"victim": row["requests"]["victim"]}
        self.assertEqual(model_api.admission_query(row), query)
        row = copy.deepcopy(next(r for r in self.rows if r["scenario"] == "mixed"))
        query = model_api.admission_query(row)
        row["results"] = None
        row["cache_features"] = None
        self.assertEqual(model_api.admission_query(row), query)

    def test_phase_counts_budgets_and_mixed_not_added(self):
        queries = [model_api.design_query(c) for c in dev.cases()]
        strata = [model_api.coordinates(q)[0] for q in queries]
        self.assertIn("cold|prefill0|decode2", strata)
        mixed = next(q for q in queries if model_api.coordinates(q)[0] == "cold|prefill1|decode1")
        stratum, coord, _ = model_api.coordinates(mixed)
        pure = copy.deepcopy(mixed)
        pure["backgrounds"] = [b for b in pure["backgrounds"] if b["phase"] == "prefill"]
        self.assertNotEqual(model_api.coordinates(pure)[0], stratum)
        self.assertGreater(model_api.predict(self.model, mixed)["prediction_ms"]["ttft_ms"],
                           model_api.predict(self.model, pure)["prediction_ms"]["ttft_ms"] + 4000)

    def test_intermediate_ceiling_and_json_roundtrip(self):
        case = next(c for c in dev.cases() if c["cached_target"] and c["scenario"] == "mixed")
        query = model_api.design_query(case)
        query.update(prompt_tokens=7840 + 384, cached_reservation=7840)
        for bg in query["backgrounds"]:
            bg["output_budget"] = 128
            if bg["phase"] == "prefill":
                bg.update(prompt_tokens=12288, prefill_reservation=12288)
        pred = model_api.predict(self.model, query)
        self.assertEqual(pred["lookup_coordinate"], [31360, 768, 16384, 192, 192])
        self.assertFalse(pred["anchor_point"])
        self.assertFalse(pred["independently_validated"])
        self.assertEqual(pred, model_api.predict(json.loads(json.dumps(self.model, sort_keys=True)), query))
        for s in self.model["surfaces"].values():
            coords = [(tuple(map(int, k.split("|"))), c) for k, c in s["cells"].items()]
            for a, ca in coords:
                for b, cb in coords:
                    if all(x <= y for x, y in zip(a, b)):
                        self.assertTrue(all(ca["upper_ms"][m] <= cb["upper_ms"][m] for m in model_api.METRICS))

    def test_ood_is_rejected_not_clamped(self):
        base = model_api.design_query(next(c for c in dev.cases() if c["scenario"] == "decode2"))
        queries = []
        for change in (dict(output_budget=65), dict(prompt_tokens=32768), dict(runtime_cap=1024),
                       dict(cached_reservation=None), dict(cold_namespace_isolated=False), dict(prompt_tokens=True)):
            queries.append(dict(base, **change))
        for field, value in (("output_budget", 193), ("output_budget", 128),
                             ("prompt_tokens", 16384), ("cached_reservation", 0), ("prefill_reservation", 10)):
            q = copy.deepcopy(base)
            q["backgrounds"][0][field] = value
            queries.append(q)
        queries.append(dict(base, backgrounds=base["backgrounds"] * 2))
        for q in queries:
            p = model_api.predict(self.model, q)
            self.assertFalse(p["in_domain"], q)
            self.assertIsNone(p["prediction_ms"])

    def test_duplicate_missing_cell_cache_and_control_fit_rejected(self):
        with self.assertRaisesRegex(ValueError, "unique"):
            model_api.fit_candidate(self.rows[:-1] + [self.rows[0]])
        observations = [model_api.observation(r) for r in self.rows if r["phase_role"] == "fit_development"]
        first = observations[0]
        with self.assertRaisesRegex(ValueError, "missing"):
            model_api.fit_cells([x for x in observations if (x["stratum"], x["coordinate"]) != (first["stratum"], first["coordinate"])])
        with self.assertRaisesRegex(ValueError, "controls"):
            model_api.fit_cells([model_api.observation(next(r for r in self.rows if r["scenario"] == "future1"))])
        rows = copy.deepcopy(self.rows)
        row = next(r for r in rows if r["cached_target"])
        row["results"]["victim"]["cached_prompt_tokens_observed"] = None
        with self.assertRaisesRegex(ValueError, "raw row"):
            model_api.fit_candidate(rows)


class CorunBuildTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = fixtures.grid_rows()

    def source(self, path):
        path.mkdir()
        fixtures.DevelopmentTests.fixture(SimpleNamespace(rows=self.base), path)
        write_json(path / dev.REPORT_NAME, dev.audit(path))
        write_json(path / "EXPERIMENT_COMPLETE.json", dict(status="COMPLETE", rows=2208, stage=dev.VERSION))

    def test_build_preserves_sources_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, output = root / "dev", root / "fit"
            self.source(source)
            before = {str(p): sha256(p) for p in source.rglob("*") if p.is_file()}
            report = build(source, output)
            self.assertEqual(report["status"], "CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION")
            self.assertEqual(before, {str(p): sha256(p) for p in source.rglob("*") if p.is_file()})
            self.assertEqual(sha256(report["candidate"]), report["candidate_sha256"])
            self.assertFalse(json.loads((output / "FIT_COMPLETE.json").read_text())["independent_validation_passed"])
            with self.assertRaises(FileExistsError):
                build(source, output)
            with self.assertRaises(ValueError):
                build(source, source / "fit")

    def test_saved_pass_cannot_bypass_raw_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "dev"
            self.source(source)
            path = source / "raw/gpu_0/measurements.jsonl"
            path.write_text("\n".join(path.read_text().splitlines()[:-1]) + "\n")
            with self.assertRaisesRegex(ValueError, "re-audit"):
                build(source, root / "fit")
            self.assertFalse((root / "fit").exists())

    def test_change_during_fit_retains_fatal_no_candidate(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source, output = root / "dev", root / "fit"
            self.source(source)
            original = model_api.fit_candidate
            def changed(rows):
                result = original(rows)
                (source / "pilot_reference.json").write_text("changed during fit")
                return result
            with patch.object(model_api, "fit_candidate", side_effect=changed):
                with self.assertRaisesRegex(RuntimeError, "changed during fit"):
                    build(source, output)
            self.assertTrue((output / "FATAL.json").exists())
            self.assertFalse((output / "FIT_COMPLETE.json").exists())
            self.assertFalse((output / "observable_corun_candidate_v1.json").exists())


if __name__ == "__main__":
    unittest.main()
