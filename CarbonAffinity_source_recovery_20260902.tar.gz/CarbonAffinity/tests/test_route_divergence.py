from __future__ import annotations

import unittest

from scripts.analyze_route_divergence import analyze_pair, summarize


def candidate(
    region: str,
    intensity: float,
    carbon: float,
    cached: int,
) -> dict:
    return {
        "region_id": region,
        "cached_tokens": cached,
        "energy_j": 100.0 if region == "a" else 300.0,
        "ttft_ms": 100.0,
        "tpot_ms": 10.0,
        "forecast_lbs_per_mwh": intensity,
        "forecast_carbon_g": carbon,
        "slo_feasible": True,
        "in_domain": True,
        "score": carbon,
        "state_loss_energy_j": 0.0 if region == "a" else 200.0,
        "queue_depth": 0,
    }


def record(
    request_id: str,
    turn: int,
    selected: str,
    policy: str,
) -> dict:
    candidates = [
        candidate("a", 400.0, 0.020, 1024),
        candidate("b", 200.0, 0.030, 0),
    ]
    return {
        "request_id": request_id,
        "session_id": "session",
        "turn_id": turn,
        "arrival_ms": float(turn),
        "prompt_tokens": 1024,
        "shared_prefix_tokens": 1024,
        "max_output_tokens": 16,
        "routing_carbon_timestamp_s": 0.0,
        "settled_profile_carbon_g": 0.02 if selected == "a" else 0.03,
        "decision": {
            "selected_region": selected,
            "previous_region": "a",
            "migrated": selected != "a",
            "reason": f"{policy} reason",
            "candidates": candidates,
        },
        "completion": {
            "dispatch_wall_time_ns": 0,
            "completed_wall_time_ns": 1_000_000_000,
        },
    }


class RouteDivergenceTests(unittest.TestCase):
    def test_same_state_cleanest_is_separate_from_observed_baseline(self) -> None:
        ca_rows = [record("r0", 0, "a", "ca"), record("r1", 1, "a", "ca")]
        clean_rows = [
            record("r0", 0, "b", "clean"),
            # Deliberately emulate a path-dependent baseline state that picks a.
            record("r1", 1, "a", "clean"),
        ]
        rows = analyze_pair(ca_rows, clean_rows, "rep_00", "window_00")
        report = summarize(rows)

        self.assertEqual(report["observed_route_matches"], 1)
        self.assertEqual(report["same_state_route_matches"], 0)
        self.assertEqual(report["same_state_divergences"], 2)
        self.assertEqual(report["terminal_same_state_divergences"], 1)
        self.assertEqual(report["terminal_carbon_affinity_migrations"], 0)


if __name__ == "__main__":
    unittest.main()
