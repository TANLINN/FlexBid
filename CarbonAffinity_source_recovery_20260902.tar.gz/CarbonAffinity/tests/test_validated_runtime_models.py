from __future__ import annotations

import json
import math
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from carbonaffinity.baseline_closed_loop import BaselineClosedLoopPlanner
from carbonaffinity.latency_surface import estimate_latency_surface
from carbonaffinity.models import RegionSnapshot
from carbonaffinity.observable_corun import ObservableCorunModel, load_corun_model
from carbonaffinity.offline_oracle import OracleProblem


def observable_payload() -> dict:
    return {
        "schema_version": 1,
        "model_kind": "observable_corun_stratified_monotone_candidate_v1",
        "margin_ms": {
            "cold": {"ttft_ms": 1.0, "tpot_ms": 2.0},
            "warm": {"ttft_ms": 1.0, "tpot_ms": 2.0},
        },
        "surfaces": {
            "cold|prefill0|decode0": {
                "axes": [[1024]],
                "cells": {
                    "1024": {
                        "upper_ms": {"ttft_ms": 10.0, "tpot_ms": 10.0}
                    }
                },
            },
            "cold|prefill1|decode0": {
                "axes": [[1024], [1024], [64]],
                "cells": {
                    "1024|1024|64": {
                        "upper_ms": {"ttft_ms": 20.0, "tpot_ms": 200.0}
                    }
                },
            },
        },
    }


def residual_payload() -> dict:
    cells = {
        "cold": {
            "axes": {"prompt_tokens": [1024, 4096], "concurrency": [1, 4]},
            "cells": {
                "1024|1": {"upper_ms": {"ttft_ms": 100, "tpot_ms": 10}},
                "1024|4": {"upper_ms": {"ttft_ms": 200, "tpot_ms": 20}},
                "4096|1": {"upper_ms": {"ttft_ms": 300, "tpot_ms": 30}},
                "4096|4": {"upper_ms": {"ttft_ms": 400, "tpot_ms": 40}},
            },
        },
        "warm": {
            "axes": {
                "cached_tokens": [784, 3136],
                "uncached_tokens": [32, 384],
                "concurrency": [1, 4],
            },
            "cells": {},
        },
    }
    for cached in (784, 3136):
        for uncached in (32, 384):
            for concurrency in (1, 4):
                cells["warm"]["cells"][f"{cached}|{uncached}|{concurrency}"] = {
                    "upper_ms": {
                        "ttft_ms": cached / 10 + uncached + concurrency,
                        "tpot_ms": 10 + concurrency,
                    }
                }
    return {
        "model_kind": "residual_latency_monotone_candidate_v1",
        "assumptions": {"output_tokens": 64, "runtime_cap": 784},
        "margin_ms": {
            "cold": {"ttft_ms": 1, "tpot_ms": 2},
            "warm": {"ttft_ms": 3, "tpot_ms": 4},
        },
        "surfaces": cells,
    }


def problem() -> OracleProblem:
    option = {
        "cold_energy_j": 10,
        "warm_energy_j": 5,
        "cold_ttft_ms": 10,
        "warm_ttft_ms": 5,
        "tpot_ms": 10,
    }
    return OracleProblem.from_dict({
        "regions": [
            {"region_id": region, "capacity": 2}
            for region in ("a", "b")
        ],
        "epochs": [{
            "epoch_id": "0",
            "carbon_lbs_per_mwh": {"a": 1, "b": 500},
            "requests": [{
                "request_id": f"r{index}",
                "session_id": f"s{index}",
                "prompt_tokens": 1024,
                "max_output_tokens": 64,
                "ttft_slo_ms": 1000,
                "tpot_slo_ms": 100,
                "options": {"a": dict(option), "b": dict(option)},
            } for index in range(2)],
        }],
    })


class ObservableCorunRuntimeTests(unittest.TestCase):
    def test_exact_query_returns_both_latency_metrics(self):
        model = ObservableCorunModel(observable_payload(), "synthetic")
        result = model.predict_query({
            "prompt_tokens": 1024,
            "cached_reservation": 0,
            "output_budget": 64,
            "cold_namespace_isolated": True,
            "runtime_cap": 784,
            "backgrounds": [{
                "phase": "prefill",
                "prompt_tokens": 1024,
                "cached_reservation": 0,
                "output_budget": 64,
                "prefill_reservation": 1024,
                "cold_namespace_isolated": True,
            }],
        })
        self.assertTrue(result["in_domain"])
        self.assertEqual(result["prediction_ms"], {
            "ttft_ms": 21.0,
            "tpot_ms": 202.0,
        })

    def test_unsupported_output_fails_closed(self):
        model = ObservableCorunModel(observable_payload(), "synthetic")
        result = model.predict_query({
            "prompt_tokens": 1024,
            "cached_reservation": 0,
            "output_budget": 128,
            "cold_namespace_isolated": True,
            "runtime_cap": 784,
            "backgrounds": [],
        })
        self.assertFalse(result["in_domain"])

    def test_loader_selects_observable_model(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "model.json"
            path.write_text(json.dumps(observable_payload()), encoding="utf-8")
            self.assertIsInstance(load_corun_model(path), ObservableCorunModel)

    def test_baseline_uses_tpot_guard_to_separate_batch(self):
        planner = BaselineClosedLoopPlanner(
            problem(),
            "cleanest_now",
            corun_model=ObservableCorunModel(observable_payload(), "synthetic"),
        )
        snapshots = {
            region: RegionSnapshot(region, 0, 0, capacity=2)
            for region in ("a", "b")
        }
        plan = planner.plan(["r0", "r1"], snapshots, {"a": 1, "b": 500})
        self.assertEqual({item.region_id for item in plan.assignments}, {"a", "b"})
        self.assertGreater(planner.guard_audit["tpot_guard_activations"], 0)

    def test_unknown_external_background_fails_closed_without_crashing(self):
        planner = BaselineClosedLoopPlanner(
            problem(),
            "cleanest_now",
            corun_model=ObservableCorunModel(observable_payload(), "synthetic"),
        )
        snapshot = replace(
            RegionSnapshot("a", 1, 0, capacity=2),
            workload_requests=(("external", "prefill", 1024, 64),),
        )
        ttft, tpot = planner._guarded_latency_ms(
            10, 10, planner.request("r0"), "a", snapshot,
        )
        self.assertTrue(math.isinf(ttft))
        self.assertTrue(math.isinf(tpot))


class ResidualLatencyRuntimeTests(unittest.TestCase):
    def test_cold_uses_ceiling_anchor_and_margin(self):
        value = estimate_latency_surface(
            residual_payload(), 2048, 0, 2, output_tokens=64,
        )
        self.assertEqual(value, (401.0, 42.0))

    def test_warm_uses_cached_and_uncached_coordinates(self):
        value = estimate_latency_surface(
            residual_payload(), 1000, 800, 2, output_tokens=64,
        )
        self.assertEqual(value, (704.6, 18.0))

    def test_output_or_range_mismatch_fails_closed(self):
        self.assertEqual(
            estimate_latency_surface(
                residual_payload(), 2048, 0, 2, output_tokens=128,
            ),
            (math.inf, math.inf),
        )
        self.assertEqual(
            estimate_latency_surface(
                residual_payload(), 8192, 0, 2, output_tokens=64,
            ),
            (math.inf, math.inf),
        )


if __name__ == "__main__":
    unittest.main()
