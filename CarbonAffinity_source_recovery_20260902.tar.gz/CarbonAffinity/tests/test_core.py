from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from carbonaffinity.carbon import CarbonTrace, carbon_grams
from carbonaffinity.audit import integrate_telemetry
from carbonaffinity.config import validate_config
from carbonaffinity.models import RegionSnapshot, RequestSpec
from carbonaffinity.network import NetworkSpec
from carbonaffinity.policy import PolicySettings, RouterPolicy
from carbonaffinity.profile import HardwareProfile
from carbonaffinity.state import StateDirectory


def profile(region: str) -> HardwareProfile:
    return HardwareProfile(
        region_id=region,
        accelerator="A800",
        model="Qwen3.5-27B",
        base_request_j=0,
        cold_prefill_j_per_token=1.0,
        cached_prefill_j_per_token=0.01,
        decode_j_per_token=0,
        base_ttft_ms=10,
        cold_prefill_ms_per_token=0.1,
        cached_prefill_ms_per_token=0.001,
        base_tpot_ms=10,
        queue_ttft_ms_per_request=10,
    )


class CoreTests(unittest.TestCase):
    def carbon_trace(self, directory: Path, missing_b: bool = False) -> CarbonTrace:
        path = directory / "carbon.csv"
        lines = [
            "timestamp,region_id,forecast_lbs_per_mwh,historical_lbs_per_mwh",
            "1000,region_a,500,510",
        ]
        if not missing_b:
            lines.append("1000,region_b,100,110")
        path.write_text("\n".join(lines), encoding="utf-8")
        return CarbonTrace.from_csv(path, max_age_s=100)

    def test_carbon_unit_conversion(self) -> None:
        self.assertAlmostEqual(carbon_grams(3_600_000, 1000), 453.59237, places=5)

    def test_network_carbon_can_change_proposed_route_without_changing_cleanest_baseline(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            path = root / "carbon.csv"
            path.write_text(
                "timestamp,region_id,forecast_lbs_per_mwh,historical_lbs_per_mwh\n"
                "1000,region_a,100,100\n"
                "1000,region_b,110,110\n",
                encoding="utf-8",
            )
            carbon = CarbonTrace.from_csv(path, max_age_s=100)
            expensive_path = NetworkSpec(
                enabled=True,
                prompt_bytes_per_token=4.0,
                output_bytes_per_token=8.0,
                energy_kwh_per_gb=1000.0,
                carbon_g_per_kwh=1000.0,
            ).to_dict()
            free_path = NetworkSpec(enabled=True).to_dict()
            snapshots = {
                "region_a": RegionSnapshot(
                    "region_a", 0, 0, network=expensive_path
                ),
                "region_b": RegionSnapshot(
                    "region_b", 0, 0, network=free_path
                ),
            }
            request = RequestSpec("network", 0, 1000, 1, "network")
            profiles = {
                "region_a": profile("region_a"),
                "region_b": profile("region_b"),
            }
            proposed = RouterPolicy(
                PolicySettings(name="carbon_affinity", migration_hysteresis_g=0),
                carbon,
                profiles,
                StateDirectory(),
            ).decide(request, snapshots, 1001, 1001)
            cleanest = RouterPolicy(
                PolicySettings(name="cleanest_now", migration_hysteresis_g=0),
                carbon,
                profiles,
                StateDirectory(),
            ).decide(request, snapshots, 1001, 1001)

            self.assertEqual(proposed.selected_region, "region_b")
            self.assertEqual(cleanest.selected_region, "region_a")
            candidate_a = next(
                item for item in proposed.candidates
                if item.region_id == "region_a"
            )
            self.assertGreater(candidate_a.network_forecast_carbon_g, 0)

    def test_network_delay_is_a_shared_slo_constraint(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary))
            slow = NetworkSpec(enabled=True, rtt_ms=200).to_dict()
            fast = NetworkSpec(enabled=True, rtt_ms=0).to_dict()
            decision = RouterPolicy(
                PolicySettings(name="cleanest_now"),
                carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")},
                StateDirectory(),
            ).decide(
                RequestSpec(
                    "slo", 0, 10, 1, "slo", ttft_slo_ms=100
                ),
                {
                    "region_a": RegionSnapshot(
                        "region_a", 0, 0, network=slow
                    ),
                    "region_b": RegionSnapshot(
                        "region_b", 0, 0, network=fast
                    ),
                },
                1001,
                1001,
            )
            self.assertEqual(decision.selected_region, "region_b")

    def test_energy_counter_is_used_when_power_is_unavailable(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            carbon = self.carbon_trace(root)
            telemetry = root / "gpu.csv"
            telemetry.write_text(
                "wall_time_ns,elapsed_ms,power_w,total_energy_mj\n"
                "1000000000000,0,,1000\n"
                "1001000000000,1000,,3000\n",
                encoding="utf-8",
            )
            result = integrate_telemetry(telemetry, "region_a", carbon, None)
            self.assertEqual(result["energy_counter_intervals"], 1)
            self.assertEqual(result["power_integrated_intervals"], 0)
            self.assertAlmostEqual(result["gpu_energy_j"], 2.0)

    def test_cache_requires_explicit_shared_prefix_and_expires(self) -> None:
        state = StateDirectory()
        original = RequestSpec("a", 0, 1000, 10, "s", shared_prefix_tokens=0)
        state.update(original, "region_a", 1000, 10)
        no_evidence = RequestSpec("b", 1, 1100, 10, "s", shared_prefix_tokens=0)
        shared = RequestSpec("c", 2, 1100, 10, "s", shared_prefix_tokens=900)
        self.assertEqual(state.reusable_tokens("s", "region_a", no_evidence, 1001), 0)
        self.assertEqual(state.reusable_tokens("s", "region_a", shared, 1001), 900)
        self.assertEqual(state.reusable_tokens("s", "region_a", shared, 1011), 0)

    def test_state_aware_policy_can_prefer_cached_dirtier_region(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary))
            state = StateDirectory()
            prime = RequestSpec("prime", 0, 1000, 1, "session")
            state.update(prime, "region_a", 1000, 100)
            request = RequestSpec("turn", 1, 1000, 1, "session", shared_prefix_tokens=1000)
            policy = RouterPolicy(
                PolicySettings(migration_hysteresis_g=0), carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")}, state,
            )
            snapshots = {
                "region_a": RegionSnapshot("region_a", 0, 0),
                "region_b": RegionSnapshot("region_b", 0, 0),
            }
            decision = policy.decide(request, snapshots, 1001, 1001)
            self.assertEqual(decision.selected_region, "region_a")
            expired = policy.decide(request, snapshots, 1101, 1001)
            self.assertEqual(expired.selected_region, "region_b")

    def test_short_expected_lifecycle_keeps_real_cached_state(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            carbon = self.carbon_trace(root)
            model = root / "future.json"
            model.write_text(json.dumps({
                "workloads": {"agentic": {"2": {
                    "future_requests": 1,
                    "future_cold_tokens": 0,
                    "future_cached_tokens": 1000,
                    "future_output_tokens": 0,
                }}}
            }))
            state = StateDirectory()
            state.update(
                RequestSpec("prime", 0, 1000, 1, "session"),
                "region_a", 1000, 100,
            )
            policy = RouterPolicy(
                PolicySettings(
                    migration_hysteresis_g=0,
                    lifecycle_migration_enabled=True,
                    lifecycle_future_work_path=str(model),
                ),
                carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")},
                state,
            )
            decision = policy.decide(
                RequestSpec(
                    "turn", 1, 1000, 1, "session",
                    turn_id=2, shared_prefix_tokens=1000,
                    workload="agentic",
                ),
                {
                    "region_a": RegionSnapshot("region_a", 0, 0),
                    "region_b": RegionSnapshot("region_b", 0, 0),
                },
                1001, 1001,
            )
            self.assertEqual(decision.selected_region, "region_a")

    def test_expected_future_work_amortizes_one_time_cache_rebuild(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            carbon = self.carbon_trace(root)
            model = root / "future.json"
            model.write_text(json.dumps({
                "workloads": {"agentic": {"2": {
                    "future_requests": 32,
                    "future_cold_tokens": 0,
                    "future_cached_tokens": 32000,
                    "future_output_tokens": 0,
                }}}
            }))
            state = StateDirectory()
            state.update(
                RequestSpec("prime", 0, 1000, 1, "session"),
                "region_a", 1000, 100,
            )
            policy = RouterPolicy(
                PolicySettings(
                    migration_hysteresis_g=0,
                    lifecycle_migration_enabled=True,
                    lifecycle_future_work_path=str(model),
                    lifecycle_risk_mode="expected_value",
                ),
                carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")},
                state,
            )
            decision = policy.decide(
                RequestSpec(
                    "turn", 1, 1000, 1, "session",
                    turn_id=2, shared_prefix_tokens=1000,
                    workload="agentic",
                ),
                {
                    "region_a": RegionSnapshot("region_a", 0, 0),
                    "region_b": RegionSnapshot("region_b", 0, 0),
                },
                1001, 1001,
            )
            self.assertEqual(decision.selected_region, "region_b")
            self.assertIn("amortized", decision.reason)

    def test_future_work_rejects_turns_outside_calibrated_domain(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            model = root / "future.json"
            model.write_text(json.dumps({
                "workloads": {"agentic": {
                    "0": {"future_requests": 1},
                    "64": {"future_requests": 10},
                }}
            }))
            policy = RouterPolicy(
                PolicySettings(
                    lifecycle_migration_enabled=True,
                    lifecycle_future_work_path=str(model),
                ),
                self.carbon_trace(root),
                {"region_a": profile("region_a")},
                StateDirectory(),
            )
            self.assertIsNone(policy._expected_future_work(RequestSpec(
                "outside", 0, 1000, 1, "session",
                turn_id=1059, workload="agentic",
            )))

    def test_missing_carbon_falls_back_to_pressure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary), missing_b=True)
            state = StateDirectory()
            policy = RouterPolicy(
                PolicySettings(), carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")}, state,
            )
            request = RequestSpec("x", 0, 10, 1, "x")
            snapshots = {
                "region_a": RegionSnapshot("region_a", 0, 2),
                "region_b": RegionSnapshot("region_b", 0, 0),
            }
            decision = policy.decide(request, snapshots, 1001, 1001)
            self.assertTrue(decision.fallback)
            self.assertEqual(decision.policy, "pressure_only")
            self.assertEqual(decision.selected_region, "region_b")
            self.assertEqual(decision.reason, "carbon signal unavailable; pressure-only fallback")

    def test_no_feasible_region_reports_distinct_fallback_reason(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary))
            policy = RouterPolicy(
                PolicySettings(), carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")},
                StateDirectory(),
            )
            request = RequestSpec("x", 0, 1000, 1, "x", ttft_slo_ms=1, tpot_slo_ms=1)
            snapshots = {
                "region_a": RegionSnapshot("region_a", 0, 0),
                "region_b": RegionSnapshot("region_b", 0, 0),
            }
            decision = policy.decide(request, snapshots, 1001, 1001)
            self.assertTrue(decision.fallback)
            self.assertEqual(decision.reason, "no SLO-feasible region; pressure-only fallback")

    def test_adaptive_lease_can_release_cache_under_high_shadow_cost(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary))
            settings = PolicySettings(
                migration_hysteresis_g=0,
                ttl_candidates_s=(0, 60, 300),
                memory_shadow_g_per_gib_s=1000,
                kv_bytes_per_token=1_000_000,
                return_models={"default": {"return_probability": 0.9, "mean_gap_s": 30}},
            )
            policy = RouterPolicy(
                settings, carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")},
                StateDirectory(),
            )
            request = RequestSpec("lease", 0, 1000, 1, "lease")
            snapshots = {
                "region_a": RegionSnapshot("region_a", 0, 0),
                "region_b": RegionSnapshot("region_b", 0, 0),
            }
            decision = policy.decide(request, snapshots, 1001, 1001)
            self.assertEqual(decision.lease_ttl_s, 0)
            self.assertIn("max lease value", decision.lease_reason)

    def test_calibrated_carbon_risk_can_suppress_uncertain_migration(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary))
            state = StateDirectory()
            initial = RequestSpec("initial", 0, 1000, 1, "session")
            state.update(initial, "region_a", 1000, 300)
            policy = RouterPolicy(
                PolicySettings(
                    migration_hysteresis_g=0,
                    carbon_error_quantile_lbs_per_mwh=10000,
                ),
                carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")},
                state,
            )
            request = RequestSpec(
                "turn", 1, 1000, 1, "session", shared_prefix_tokens=0
            )
            decision = policy.decide(
                request,
                {
                    "region_a": RegionSnapshot("region_a", 0, 0),
                    "region_b": RegionSnapshot("region_b", 0, 0),
                },
                1001,
                1001,
            )
            self.assertEqual(decision.selected_region, "region_a")
            self.assertIn("forecast-risk", decision.reason)

    def test_proposed_policy_does_not_double_count_queue_pressure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary))
            snapshot = RegionSnapshot("region_a", 4, 4, capacity=8)
            proposed = RouterPolicy(
                PolicySettings(name="carbon_affinity", queue_penalty=1.0),
                carbon,
                {"region_a": profile("region_a")},
                StateDirectory(),
            )
            ablation = RouterPolicy(
                PolicySettings(name="cedar_like", queue_penalty=1.0),
                carbon,
                {"region_a": profile("region_a")},
                StateDirectory(),
            )
            self.assertEqual(proposed._score(snapshot, 2.0, True), 2.0)
            self.assertEqual(ablation._score(snapshot, 2.0, True), 3.0)

    def test_uncertain_small_energy_advantage_does_not_override_cleanest_grid(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            carbon_path = root / "carbon.csv"
            carbon_path.write_text(
                "timestamp,region_id,forecast_lbs_per_mwh,historical_lbs_per_mwh\n"
                "1000,region_a,110,110\n"
                "1000,region_b,100,100\n",
                encoding="utf-8",
            )
            carbon = CarbonTrace.from_csv(carbon_path, max_age_s=100)
            base = profile("region_b")
            slightly_cheaper = HardwareProfile(**{
                **profile("region_a").__dict__,
                "cold_prefill_j_per_token": 0.9,
            })
            policy = RouterPolicy(
                PolicySettings(
                    migration_hysteresis_g=0,
                    energy_error_quantile_solo_fraction=0.10,
                ),
                carbon,
                {"region_a": slightly_cheaper, "region_b": base},
                StateDirectory(),
            )
            decision = policy.decide(
                RequestSpec("x", 0, 1000, 1, "x"),
                {
                    "region_a": RegionSnapshot("region_a", 0, 0),
                    "region_b": RegionSnapshot("region_b", 0, 0),
                },
                1001,
                1001,
            )
            self.assertEqual(decision.selected_region, "region_b")
            self.assertIn("confidence intervals overlap", decision.reason)

    def test_main_config_rejects_tp8(self) -> None:
        config = {
            "regions": [
                {"id": "a", "model": "m", "api_base": "x", "profile": "p", "gpu_count": 8, "tensor_parallel_size": 8},
                {"id": "b", "model": "m", "api_base": "y", "profile": "q", "gpu_count": 1, "tensor_parallel_size": 1},
            ]
        }
        with self.assertRaisesRegex(ValueError, "gpu_count"):
            validate_config(config)

    def test_batch_model_uses_average_cost_energy_attribution(self) -> None:
        base = profile("region_a")
        calibrated = HardwareProfile(**{
            **base.__dict__,
            "batch_energy_model": {
                "global": {"1": 1.0, "2": 0.6, "4": 0.35, "8": 0.25}
            },
        })
        request = RequestSpec("batch", 0, 100, 1, "batch")
        solo = calibrated.estimate(
            request, 0, RegionSnapshot("region_a", 0, 0)
        )
        added = calibrated.estimate(
            request, 0, RegionSnapshot("region_a", 1, 0)
        )
        self.assertEqual(solo.projected_batch_size, 1)
        self.assertAlmostEqual(solo.allocated_energy_multiplier, 1.0)
        # At concurrency two, each request receives the measured average cost.
        self.assertAlmostEqual(added.allocated_energy_multiplier, 0.6)
        self.assertAlmostEqual(added.energy_j / solo.energy_j, 0.6)

    def test_batch_model_blends_cold_and_warm_curves(self) -> None:
        base = profile("region_a")
        calibrated = HardwareProfile(**{
            **base.__dict__,
            "batch_energy_model": {
                "cells": {
                    "cold|2048|32": {"1": 1.0, "2": 0.8},
                    "warm|2048|32": {"1": 1.0, "2": 0.5},
                }
            },
        })
        request = RequestSpec("blend", 0, 2048, 32, "blend")
        cold = calibrated.estimate(
            request, 0, RegionSnapshot("region_a", 1, 0)
        )
        warm = calibrated.estimate(
            request, 2048, RegionSnapshot("region_a", 1, 0)
        )
        self.assertAlmostEqual(cold.allocated_energy_multiplier, 0.8)
        self.assertAlmostEqual(warm.allocated_energy_multiplier, 0.5)
        self.assertLess(warm.energy_j, cold.energy_j)


if __name__ == "__main__":
    unittest.main()
