import base64
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from scripts.build_latency_residual_fit_transfer import build_payload, command
from scripts.build_latency_residual_transfer import DEPENDENCIES, INSTALLER, PROJECT


class FitTransferTests(unittest.TestCase):
    def test_bundle_roundtrip_and_installed_fit_tests(self):
        payload = build_payload()
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp)
            for name in DEPENDENCIES:
                target = project / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((PROJECT / name).read_bytes())
            installed = subprocess.run([sys.executable, "-c", INSTALLER,
                hashlib.sha256(payload).hexdigest(), str(project)],
                input=base64.b64encode(payload).decode(), text=True, capture_output=True, timeout=30)
            self.assertEqual(installed.returncode, 0, installed.stderr)
            bundle = Path(installed.stdout.strip())
            tested = subprocess.run([sys.executable, "-m", "unittest", "tests.test_latency_residual",
                "tests.test_residual_latency_candidate", "-q"], cwd=bundle,
                env={**os.environ, "PYTHONPATH": str(bundle) + os.pathsep + str(PROJECT), "PYTHONNOUSERSITE": "1"},
                text=True, capture_output=True, timeout=60)
            self.assertEqual(tested.returncode, 0, tested.stdout + tested.stderr)
            self.assertIn("Ran 16 tests", tested.stderr)
            manifest = json.loads((bundle / "TRANSFER_MANIFEST.json").read_text())
            self.assertIn("scripts/fit_residual_latency_candidate.py", manifest["files_sha256"])

    def test_bash_syntax_no_gpu_launch_and_explicit_input(self):
        script = command(build_payload())
        self.assertNotIn("nohup", script)
        self.assertNotIn(" -m scripts.run_latency_residual_campaign ", script)
        self.assertIn("DEV=/root/CarbonAffinity/results/latency_residual_dev_20260830T082216Z", script)
        self.assertLess(script.index("unittest tests.test_latency_residual"), script.index("-m scripts.fit_residual_latency_candidate"))
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if not bash.exists():
            self.skipTest("bash unavailable")
        checked = subprocess.run([str(bash), "-n"], input=script, text=True, capture_output=True, timeout=20)
        self.assertEqual(checked.returncode, 0, checked.stderr)
        with self.assertRaises(ValueError):
            command(build_payload(), "/root/CarbonAffinity/results/../profiles")


if __name__ == "__main__":
    unittest.main()
