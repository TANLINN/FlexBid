"""Probe artifact tests use synthetic rows, never physical GPU measurements."""
import ast
import itertools
import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
SOURCE = (PROJECT / 'scripts/run_latency_pause_probe.sh').read_text(encoding='utf-8')
BLOCKS = re.findall(r"<<'PY'\n(.*?)\nPY(?:\n|$)", SOURCE, re.S)


class LatencyPauseProbeTests(unittest.TestCase):
    def test_embedded_python_compiles(self):
        self.assertEqual(len(BLOCKS), 2)
        for block in BLOCKS:
            ast.parse(block)

    def test_file_launch_guard_and_error_context_present(self):
        self.assertIn('FILE_LAUNCH_REQUIRED', SOURCE)
        self.assertIn('set -Eeuo pipefail', SOURCE)
        self.assertIn('stage=%s exit=%s', SOURCE)
        self.assertIn('launcher_source.sh', SOURCE)

    def test_clipboard_helper_hash_checks_before_writing_and_uses_file(self):
        helper = (PROJECT / 'scripts/copy_latency_pause_probe_command.ps1').read_text(encoding='utf-8')
        self.assertLess(helper.index('if actual != expected:'), helper.index('NamedTemporaryFile'))
        self.assertIn('nohup bash "$PROBE_SCRIPT" "$PROBE"', helper)
        self.assertIn('2>&1 < /dev/null &', helper)
        self.assertNotIn('nohup bash -s', helper)

    def run_summary(self, mutation=None):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for gpu in (0, 6, 7):
                rows = [dict(gpu_index=gpu, mode=mode, prompt_tokens=12288,
                             concurrency=3, repeat=repeat, ttft_p95_ms=550,
                             tpot_p95_ms=40, cached_tokens=[11760] * 3,
                             results=[dict(success=True, output_tokens=64)] * 3)
                        for mode, repeat in itertools.product(('cold', 'warm'), range(5))]
                if mutation:
                    mutation(gpu, rows)
                target = root / 'raw' / f'gpu_{gpu}' / 'measurements.jsonl'
                target.parent.mkdir(parents=True)
                target.write_text(''.join(json.dumps(r) + '\n' for r in rows), encoding='utf-8')
            result = subprocess.run([sys.executable, '-c', BLOCKS[-1], str(root)],
                                    cwd=PROJECT, text=True, capture_output=True)
            marker = root / 'EXPERIMENT_COMPLETE.json'
            summary = root / 'DIAGNOSTIC_SUMMARY.json'
            return (result, json.loads(marker.read_text()) if marker.exists() else None,
                    json.loads(summary.read_text()) if summary.exists() else None)

    def test_complete_diagnostic_does_not_claim_validation(self):
        result, marker, summary = self.run_summary()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(marker['status'], 'COMPLETE')
        self.assertTrue(marker['diagnostic_only'])
        self.assertEqual(summary['rows'], 30)
        self.assertEqual(summary['gpus']['6']['warm_batches'], 5)

    def test_retains_slow_measurements_without_failure_filter(self):
        def mutation(gpu, rows):
            if gpu == 6:
                rows[-1]['ttft_p95_ms'] = 18000
        result, marker, summary = self.run_summary(mutation)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(summary['gpus']['6']['ttft_p95_ms_by_repeat'][-1], 18000)
        self.assertTrue(marker['diagnostic_only'])

    def test_duplicate_case_rejected(self):
        def mutation(gpu, rows):
            if gpu == 6:
                rows[-1] = dict(rows[-2])
        result, marker, _ = self.run_summary(mutation)
        self.assertNotEqual(result.returncode, 0)
        self.assertIsNone(marker)

    def test_missing_and_failed_results_rejected(self):
        for replacement in ([], [dict(success=False, output_tokens=64)] * 3):
            with self.subTest(replacement=replacement):
                def mutation(gpu, rows):
                    if gpu == 7:
                        rows[-1]['results'] = replacement
                result, marker, _ = self.run_summary(mutation)
                self.assertNotEqual(result.returncode, 0)
                self.assertIsNone(marker)


if __name__ == '__main__':
    unittest.main()
