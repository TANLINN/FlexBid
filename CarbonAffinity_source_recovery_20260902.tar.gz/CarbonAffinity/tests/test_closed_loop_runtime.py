from __future__ import annotations

import asyncio
import json
import tempfile
import threading
import unittest
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from carbonaffinity.models import RequestSpec
from carbonaffinity.region import RegionClient
from carbonaffinity.replay import run_replay


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.0"

    def log_message(self, *_args) -> None:
        pass

    def do_GET(self) -> None:
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(b"{}")

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        json.loads(self.rfile.read(length))
        events = [
            {"choices": [{"text": "a"}], "usage": None},
            {
                "choices": [{"text": "b"}],
                "usage": {
                    "prompt_tokens": 10,
                    "completion_tokens": 2,
                    "prompt_tokens_details": {"cached_tokens": 0},
                },
            },
        ]
        body = "".join(
            f"data: {json.dumps(item)}\n\n" for item in events
        ) + "data: [DONE]\n\n"
        encoded = body.encode()
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


@dataclass(frozen=True)
class _Decision:
    region_id: str

    def to_dict(self) -> dict:
        return {"region_id": self.region_id, "test": True}


class _Provider:
    def __init__(self, region_id: str) -> None:
        self.region_id = region_id
        self.completed = []
        self.closed = False

    async def assign(self, request, snapshots, carbon):
        assert set(snapshots) == set(carbon)
        return _Decision(self.region_id)

    async def complete(self, request_id, region_id, success):
        self.completed.append((request_id, region_id, success))

    async def close(self):
        self.closed = True


class ClosedLoopRuntimeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
        self.thread = threading.Thread(
            target=self.server.serve_forever,
            daemon=True,
        )
        self.thread.start()
        self.port = self.server.server_address[1]

    async def asyncTearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)

    async def test_admission_wait_is_in_end_to_end_ttft(self) -> None:
        client = RegionClient({
            "id": "region_a",
            "api_base": f"http://127.0.0.1:{self.port}/v1",
            "model": "mock",
            "admission_concurrency": 1,
        })
        try:
            await client._semaphore.acquire()
            task = asyncio.create_task(
                client.complete(
                    RequestSpec("queued", 0, 10, 2, "queued"),
                    [1] * 10,
                )
            )
            await asyncio.sleep(0.04)
            client._semaphore.release()
            result = await task
        finally:
            await client.close()
        self.assertGreaterEqual(result.admission_wait_ms, 30.0)
        self.assertIsNotNone(result.service_ttft_ms)
        self.assertGreaterEqual(
            (result.ttft_ms or 0.0)
            - (result.service_ttft_ms or 0.0),
            30.0,
        )

    async def test_replay_uses_provider_and_releases_reservation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            profile = {
                "accelerator": "A800",
                "model": "mock",
                "base_request_j": 1,
                "cold_prefill_j_per_token": 1,
                "cached_prefill_j_per_token": 0.1,
                "decode_j_per_token": 1,
                "base_ttft_ms": 1,
                "cold_prefill_ms_per_token": 0.1,
                "cached_prefill_ms_per_token": 0.01,
                "base_tpot_ms": 1,
                "queue_ttft_ms_per_request": 1,
                "uncertainty_margin": 1,
            }
            regions = []
            for name in ("region_a", "region_b"):
                (root / f"{name}.json").write_text(
                    json.dumps({**profile, "region_id": name})
                )
                regions.append({
                    "id": name,
                    "api_base": (
                        f"http://127.0.0.1:{self.port}/v1"
                    ),
                    "model": "mock",
                    "profile": f"{name}.json",
                    "admission_concurrency": 1,
                })
            (root / "carbon.csv").write_text(
                "timestamp,region_id,forecast_lbs_per_mwh,"
                "historical_lbs_per_mwh\n"
                "1000,region_a,500,500\n"
                "1000,region_b,100,100\n"
            )
            trace = root / "trace.jsonl"
            trace.write_text(json.dumps({
                "request_id": "r1",
                "session_id": "s1",
                "arrival_ms": 0,
                "prompt_tokens": 10,
                "max_output_tokens": 2,
                "prompt": "hello",
            }) + "\n")
            config = {
                "_root": str(root),
                "_config_path": str(root / "config.yaml"),
                "experiment": {"tokenizer": "unused"},
                "regions": regions,
                "carbon": {
                    "trace": "carbon.csv",
                    "clock_mode": "trace_relative",
                    "trace_start_timestamp": 1000,
                    "max_age_s": 100,
                },
                "routing": {
                    "policy": "carbon_affinity",
                    "migration_hysteresis_g": 0,
                },
                "lease": {"adaptive": False},
                "runtime": {"max_in_flight": 2},
            }
            provider = _Provider("region_a")
            output = root / "requests.jsonl"
            await run_replay(
                config,
                trace,
                output,
                assignment_provider=provider,
            )
            record = json.loads(output.read_text())
            self.assertEqual(
                record["decision"]["policy"],
                "joint_closed_loop_learned_future",
            )
            self.assertEqual(
                record["closed_loop"]["region_id"],
                "region_a",
            )
            self.assertEqual(provider.completed, [("r1", "region_a", True)])
            self.assertTrue(provider.closed)


if __name__ == "__main__":
    unittest.main()
