"""Synthetic tests only: no real model, network, GPU, or performance claims."""
import asyncio
import hashlib
import json
import tempfile
import unittest
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from carbonaffinity.artifacts import sha256, write_json
from carbonaffinity.models import CompletionResult
from scripts.latency_residual_protocol import BLOCK, GPUS, OUTPUT, VERSION, cases, design, features, result_checks
from scripts.measure_latency_residual import collect
from scripts.audit_latency_residual import audit
from scripts.latency_shape_probe_support import prewarm


def event(bt):
    key = (48, 128, 128, bt, *(["torch.bfloat16"] * 4), "torch.float32",
           "torch.bfloat16", "torch.int32", "torch.int32")
    return f"Triton autotuning for function chunk_fwd_kernel_o,\nwith key as {key},\nfinished after 0.01s\n"


def result(p, out=OUTPUT, cached=None):
    return CompletionResult("test", "test", True, 200, 1, 2, 3, 1, 1, out, p, cached)


class Materializer:
    def tokens(self, row):
        return [1] * row["prompt_tokens"]


class Client:
    def __init__(self):
        self.primed = set()
    async def reset_prefix_cache(self):
        self.primed.clear()
        return True
    async def complete(self, request, prompt, cache_salt):
        cached = (len(prompt) // BLOCK) * BLOCK if cache_salt in self.primed else None
        if request.max_output_tokens == 1:
            self.primed.add(cache_salt)
        return result(len(prompt), request.max_output_tokens, cached)


class ResidualProtocolTests(unittest.TestCase):
    def test_design_864_cases_and_actual_residuals(self):
        grid = cases()
        self.assertEqual(len(grid), 108)
        self.assertEqual(len({c["case_id"] for c in grid}), 108)
        self.assertEqual(design()["expected_rows"], 864)
        self.assertFalse(design()["model_fitting_in_this_run"])
        for case in grid:
            self.assertEqual(case["cached_context_target"] % BLOCK, 0)
            self.assertEqual(case["prompt_tokens"] % BLOCK, case["residual_target"])

    def test_null_is_not_zero_and_warm_cache_requires_exact_observation(self):
        raw = asdict(result(1600))
        self.assertTrue(all(result_checks(raw, 1600, 64).values()))
        self.assertIsNone(features(raw)["observed_uncached_tokens"])
        self.assertFalse(all(result_checks(raw, 1600, 64, 1568).values()))
        raw["cached_prompt_tokens_observed"] = 1568
        self.assertTrue(all(result_checks(raw, 1600, 64, 1568).values()))
        self.assertEqual(features(raw)["observed_uncached_tokens"], 32)
        raw["cached_prompt_tokens_observed"] = 1500  # >90% is still wrong for this design.
        self.assertFalse(all(result_checks(raw, 1600, 64, 1568).values()))

    def test_bad_tokens_fail_even_if_http_succeeded(self):
        raw = asdict(result(1600, cached=1568))
        for field, value in (("prompt_tokens_reported", 1599), ("output_tokens", 63),
                             ("success", False), ("ttft_ms", float("nan"))):
            self.assertFalse(all(result_checks({**raw, field: value}, 1600, 64, 1568).values()))

    def test_collector_full_single_gpu_grid(self):
        with tempfile.TemporaryDirectory() as temp:
            args = SimpleNamespace(gpu_index=0, output=Path(temp) / "measurements.jsonl", runtime_evidence="synthetic")
            with patch("scripts.measure_latency_residual.asyncio.sleep", new_callable=AsyncMock), patch("builtins.print"):
                asyncio.run(collect(args, Materializer(), Client()))
            rows = [json.loads(line) for line in args.output.read_text().splitlines()]
            self.assertEqual(len(rows), 108)
            self.assertEqual(len(list((Path(temp) / "primes").glob("*.json"))), 54)
            for row in rows:
                self.assertTrue(all(all(c.values()) for c in row["result_checks"]))
                for f in row["cache_features"]:
                    if row["mode"] == "warm":
                        self.assertEqual(f["observed_uncached_tokens"], row["residual_target"])
                    else:
                        self.assertIsNone(f["observed_uncached_tokens"])
            with self.assertRaises(FileExistsError):
                asyncio.run(collect(args, Materializer(), Client()))

    def test_failed_measured_row_is_saved_not_dropped(self):
        class BadClient(Client):
            async def complete(self, request, prompt, cache_salt):
                return result(len(prompt), 63)
        with tempfile.TemporaryDirectory() as temp:
            args = SimpleNamespace(gpu_index=0, output=Path(temp) / "measurements.jsonl", runtime_evidence="synthetic")
            with patch("builtins.print"), self.assertRaisesRegex(RuntimeError, "raw row retained"):
                asyncio.run(collect(args, Materializer(), BadClient()))
            rows = [json.loads(line) for line in args.output.read_text().splitlines()]
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["results"][0]["output_tokens"], 63)

    def test_eight_gpu_fixed_shape_prewarm_with_null_cache(self):
        class ShapeClient:
            endpoints, calls, closed = [], [], []
            def __init__(self, config, timeout):
                self.gpu = config["id"]
                self.endpoints.append(config["api_base"])
            async def complete(self, request, prompt, cache_salt):
                self.calls.append((self.gpu, len(prompt), cache_salt))
                return result(len(prompt))
            async def reset_prefix_cache(self):
                return True
            async def close(self):
                self.closed.append(self.gpu)
        with tempfile.TemporaryDirectory() as temp, patch.dict("os.environ", TRITON_PRINT_AUTOTUNING="1"):
            root = Path(temp)
            for gpu in GPUS:
                (root / f"vllm_gpu_{gpu}.log").write_text("".join(event(bt) for bt in (16, 32, 64)))
            with patch("builtins.print"):
                asyncio.run(prewarm(root, Materializer(), ShapeClient, gpus=GPUS))
            report = json.loads((root / "SHAPE_PREWARM.json").read_text())
            self.assertEqual(report["gpu_indices"], list(GPUS))
            self.assertEqual(report["requests"], 64)
            self.assertEqual(report["missing_cache_observations"], 64)
            self.assertEqual(len(set(x[2] for x in ShapeClient.calls)), 64)
            self.assertEqual(set(ShapeClient.endpoints), {f"http://127.0.0.1:{18000+g}/v1" for g in GPUS})
            self.assertEqual(len(ShapeClient.closed), 8)


def fixture(root):
    launch = {"runtime_cap": 784, "effective_cap_verified": True, "cache_block784_verified": True}
    write_json(root / "LAUNCH.json", launch)
    evidence = sha256(root / "LAUNCH.json")
    write_json(root / "PREREGISTRATION.json", {"design": design(), "expected_rows": 864,
               "code_sha256": {str(Path(__file__).resolve()): sha256(__file__)}})
    snapshots = {}
    for gpu in GPUS:
        data = "".join(event(bt) for bt in (16, 32, 64)).encode()
        (root / f"vllm_gpu_{gpu}.log").write_bytes(data)
        snapshots[str(gpu)] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        rows = []
        for case in cases():
            p, warm, n = case["prompt_tokens"], case["mode"] == "warm", case["concurrency"]
            cached = case["cached_context_target"] if warm else None
            records = [asdict(result(p, cached=cached)) for _ in range(n)]
            salt = f"gpu{gpu}-{case['case_id']}"
            rows.append({**case, "protocol": VERSION, "gpu_index": gpu, "results": records,
                "cache_features": [features(r) for r in records], "runtime_evidence_sha256": evidence,
                "result_checks": [result_checks(r, p, OUTPUT, cached) for r in records],
                "prime": asdict(result(p, out=1)) if warm else None,
                "cache_salts": [salt if warm else f"{salt}-{i}" for i in range(n)]})
        destination = root / "raw" / f"gpu_{gpu}" / "measurements.jsonl"
        destination.parent.mkdir(parents=True)
        destination.write_text("".join(json.dumps(r) + "\n" for r in rows))
    write_json(root / "SHAPE_PREWARM.json", {"gpu_indices": list(GPUS), "requests": 64,
               "checks": {"all_shape_keys_observed": True}, "logs": snapshots})


class ResidualAuditTests(unittest.TestCase):
    def test_complete_grid_is_only_development_pass(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            fixture(root)
            report = audit(root)
            self.assertEqual(report["status"], "PASS", report)
            self.assertFalse(report["candidate_frozen"])
            self.assertEqual(report["rows"], 864)
            self.assertEqual(report["stage"], "DEVELOPMENT_DATA_ONLY")

    def test_missing_rows_fabricated_features_and_new_tuning_fail(self):
        for issue in ("missing", "feature", "tuning"):
            with self.subTest(issue=issue), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                fixture(root)
                path = root / "raw/gpu_0/measurements.jsonl"
                lines = path.read_text().splitlines()
                if issue == "missing":
                    path.write_text("\n".join(lines[:-1]) + "\n")
                elif issue == "feature":
                    row = json.loads(lines[0])
                    row["cache_features"][0]["observed_uncached_tokens"] = 0
                    lines[0] = json.dumps(row)
                    path.write_text("\n".join(lines) + "\n")
                else:
                    with (root / "vllm_gpu_0.log").open("a") as out:
                        out.write(event(32))
                before = path.read_bytes()
                report = audit(root)
                self.assertEqual(report["status"], "FAIL")
                self.assertEqual(path.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
