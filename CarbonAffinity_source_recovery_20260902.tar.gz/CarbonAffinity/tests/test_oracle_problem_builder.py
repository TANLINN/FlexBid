from __future__ import annotations

import unittest
from types import SimpleNamespace

from scripts.build_offline_oracle_problem import split_serial_session_requests


class OracleProblemBuilderTests(unittest.TestCase):
    def test_repeated_session_requests_are_serialized(self) -> None:
        requests = [
            SimpleNamespace(session_id="a", request_id="a0"),
            SimpleNamespace(session_id="b", request_id="b0"),
            SimpleNamespace(session_id="a", request_id="a1"),
            SimpleNamespace(session_id="a", request_id="a2"),
            SimpleNamespace(session_id="b", request_id="b1"),
        ]
        epochs = split_serial_session_requests(requests)
        self.assertEqual(
            [[request.request_id for request in epoch] for epoch in epochs],
            [["a0", "b0"], ["a1", "b1"], ["a2"]],
        )
        for epoch in epochs:
            sessions = [request.session_id for request in epoch]
            self.assertEqual(len(sessions), len(set(sessions)))


if __name__ == "__main__":
    unittest.main()
