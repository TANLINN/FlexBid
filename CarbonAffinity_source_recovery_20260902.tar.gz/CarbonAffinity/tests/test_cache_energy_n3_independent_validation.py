import unittest

from scripts import cache_energy_n3_independent_validation as validation
from scripts import fit_cache_energy_n3_candidate as fit
from tests.test_fit_cache_energy_n3_candidate import synthetic_rows


def candidate():
    profiles = {
        str(gpu): fit.fit_gpu(synthetic_rows(gpu))
        for gpu in fit.GPUS
    }
    return {
        "candidate_frozen": False,
        "independent_validation_passed": False,
        "training_design": {
            "cached_targets": list(fit.CACHED_TARGETS),
            "prompt_tokens": list(fit.PROMPTS),
            "output_tokens": list(fit.OUTPUTS),
            "concurrency": list(fit.CONCURRENCIES),
        },
        "profiles": profiles,
    }


def heldout_rows(payload, multiplier=1.0):
    rows = []
    for gpu in validation.GPUS:
        for case in validation.schedule(gpu):
            row = {
                **case, "gpu_index": gpu, "valid": True,
                "reset": {"confirmed": True},
            }
            prediction = fit.predict(row, payload["profiles"][str(gpu)])
            row["total_energy_j"] = prediction * validation.CONCURRENCY * multiplier
            cached = case["cached_context_target"] if case["mode"] == "warm" else None
            row["results"] = [
                {"success": True, "cached_prompt_tokens_observed": cached}
                for _ in range(validation.CONCURRENCY)
            ]
            rows.append(row)
    return rows


class CacheEnergyIndependentValidationTests(unittest.TestCase):
    def test_schedule_is_exact_disjoint_counterbalanced_design(self):
        self.assertEqual(sum(len(validation.schedule(gpu)) for gpu in validation.GPUS), 96)
        for gpu in validation.GPUS:
            cases = validation.schedule(gpu)
            self.assertEqual(len(cases), 12)
            for first, second in zip(cases[::2], cases[1::2]):
                self.assertEqual(first["pair_id"], second["pair_id"])
                self.assertEqual({first["mode"], second["mode"]}, {"cold", "warm"})
        self.assertFalse(set(validation.CACHED_TARGETS) & set(fit.CACHED_TARGETS))
        self.assertNotIn(validation.OUTPUT, fit.OUTPUTS)
        self.assertNotIn(validation.CONCURRENCY, fit.CONCURRENCIES)

    def test_exact_predictions_pass(self):
        payload = candidate()
        report = validation.analyze(heldout_rows(payload), payload, {str(g): [] for g in validation.GPUS})
        self.assertEqual(report["status"], "PASS")
        self.assertTrue(all(report["acceptance"].values()))
        self.assertEqual(report["accuracy"]["overall"]["samples"], 96)
        self.assertEqual(report["paired_saving"]["sign_accuracy"], 1.0)

    def test_large_prediction_error_fails(self):
        payload = candidate()
        report = validation.analyze(
            heldout_rows(payload, multiplier=2.0), payload,
            {str(g): [] for g in validation.GPUS},
        )
        self.assertEqual(report["status"], "FAIL")
        self.assertFalse(report["acceptance"]["overall_median_ape"])


if __name__ == "__main__":
    unittest.main()
