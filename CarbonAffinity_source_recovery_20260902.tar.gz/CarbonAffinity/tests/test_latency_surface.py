from __future__ import annotations

import unittest

from carbonaffinity.models import RegionSnapshot, RequestSpec
from carbonaffinity.profile import HardwareProfile


def profile(model: dict | None) -> HardwareProfile:
    return HardwareProfile(
        region_id="region_a",
        accelerator="A800",
        model="Qwen3.5-27B",
        base_request_j=0,
        cold_prefill_j_per_token=1,
        cached_prefill_j_per_token=0.1,
        decode_j_per_token=1,
        base_ttft_ms=10,
        cold_prefill_ms_per_token=1,
        cached_prefill_ms_per_token=0.1,
        base_tpot_ms=5,
        queue_ttft_ms_per_request=7,
        latency_surface_model=model,
    )


def surface() -> dict:
    cells = {}
    for mode, offset in (("cold", 100), ("warm", 20)):
        for prompt, prompt_part in ((2048, 0), (8192, 40)):
            for concurrency, active_part in ((1, 0), (4, 30)):
                cells[f"{mode}|{prompt}|{concurrency}"] = {
                    "ttft_ms": offset + prompt_part + active_part,
                    "tpot_ms": offset / 10 + prompt_part / 10 + active_part / 10,
                    "samples": 8,
                }
    return {
        "prompt_buckets": [2048, 8192],
        "concurrency_buckets": [1, 4],
        "cells": cells,
        "one_sided_q95_residual_ms": {
            "cold": {"ttft_ms": 10, "tpot_ms": 1},
            "warm": {"ttft_ms": 2, "tpot_ms": 0.2},
        },
    }


class LatencySurfaceTests(unittest.TestCase):
    def test_exact_cold_cell_adds_margin_queue_and_rtt(self) -> None:
        estimate = profile(surface()).estimate(
            RequestSpec("x", 0, 2048, 16, "x"),
            0,
            RegionSnapshot("region_a", 0, 2, rtt_ms=11),
        )
        self.assertAlmostEqual(estimate.ttft_ms, 100 + 10 + 14 + 11)
        self.assertAlmostEqual(estimate.tpot_ms, 10 + 1)

    def test_prompt_concurrency_and_cache_are_interpolated(self) -> None:
        estimate = profile(surface()).estimate(
            RequestSpec("x", 0, 4096, 16, "x"),
            2048,
            RegionSnapshot("region_a", 1, 0),
        )
        # log2 prompt is halfway; concurrency=2 is one third from 1 to 4.
        cold_ttft = 100 + 20 + 10 + 10
        warm_ttft = 20 + 20 + 10 + 2
        self.assertAlmostEqual(estimate.ttft_ms, (cold_ttft + warm_ttft) / 2)
        cold_tpot = 10 + 2 + 1 + 1
        warm_tpot = 2 + 2 + 1 + 0.2
        self.assertAlmostEqual(estimate.tpot_ms, (cold_tpot + warm_tpot) / 2)

    def test_legacy_model_remains_the_fallback(self) -> None:
        estimate = profile(None).estimate(
            RequestSpec("x", 0, 100, 16, "x"),
            0,
            RegionSnapshot("region_a", 0, 0),
        )
        self.assertAlmostEqual(estimate.ttft_ms, 110)
        self.assertAlmostEqual(estimate.tpot_ms, 5)


if __name__ == "__main__":
    unittest.main()
