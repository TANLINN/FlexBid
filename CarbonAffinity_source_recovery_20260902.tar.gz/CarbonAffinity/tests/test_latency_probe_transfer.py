"""Synthetic transfer tests: no SSH, clipboard, servers, or GPUs."""
import base64
import hashlib
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from scripts.build_latency_probe_transfer import PROJECT, build_transfer


class ProbeTransferTests(unittest.TestCase):
    def source(self):
        return (PROJECT / 'scripts/run_latency_pause_probe.sh').read_bytes()

    def run_step(self, step):
        return subprocess.run([sys.executable, '-c', step['code']], capture_output=True, text=True)

    def test_roundtrip_short_commands_and_idempotent_retry(self):
        with tempfile.TemporaryDirectory() as temp:
            source = self.source()
            plan = build_transfer(source, parent=temp)
            for step in plan['steps']:
                self.assertLess(len(step['command']), 1200)
                result = self.run_step(step)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn(step['expected_marker'], result.stdout)
            self.assertEqual(Path(plan['script']).read_bytes(), source)
            for step in plan['steps']:
                self.assertEqual(self.run_step(step).returncode, 0)

    def test_corrupt_payload_rejected_before_part_write(self):
        with tempfile.TemporaryDirectory() as temp:
            plan = build_transfer(self.source(), parent=temp)
            self.assertEqual(self.run_step(plan['steps'][0]).returncode, 0)
            original = plan['steps'][1]['code']
            payload = original.split('base64.b64decode("')[1].split('"')[0]
            mutated = ('A' if payload[0] != 'A' else 'B') + payload[1:]
            step = {'code': original.replace(payload, mutated)}
            self.assertNotEqual(self.run_step(step).returncode, 0)
            self.assertFalse((Path(plan['script']).parent / 'part_00').exists())

    def test_missing_part_cannot_assemble_script(self):
        with tempfile.TemporaryDirectory() as temp:
            plan = build_transfer(self.source(), parent=temp)
            for step in plan['steps'][:-2]:
                self.assertEqual(self.run_step(step).returncode, 0)
            self.assertNotEqual(self.run_step(plan['steps'][-1]).returncode, 0)
            self.assertFalse(Path(plan['script']).exists())

    def test_existing_foreign_script_not_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            plan = build_transfer(self.source(), parent=temp)
            for step in plan['steps'][:-1]:
                self.assertEqual(self.run_step(step).returncode, 0)
            target = Path(plan['script'])
            target.write_bytes(b'preserve user contents')
            self.assertNotEqual(self.run_step(plan['steps'][-1]).returncode, 0)
            self.assertEqual(target.read_bytes(), b'preserve user contents')


if __name__ == '__main__':
    unittest.main()
