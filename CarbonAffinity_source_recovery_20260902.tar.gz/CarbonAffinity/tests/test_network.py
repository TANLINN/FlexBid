from __future__ import annotations

import unittest

from carbonaffinity.network import NetworkSpec, estimate_network, transfer_ms


class NetworkModelTests(unittest.TestCase):
    def test_disabled_model_is_exactly_zero(self) -> None:
        estimate = estimate_network(
            NetworkSpec(rtt_ms=80.0, energy_kwh_per_gb=1.0),
            prompt_tokens=100_000,
            output_tokens=1_000,
        )
        self.assertEqual(estimate.ttft_ms, 0.0)
        self.assertEqual(estimate.energy_j, 0.0)
        self.assertEqual(estimate.carbon_g, 0.0)

    def test_decimal_mbps_serialization_units(self) -> None:
        # 125,000 bytes = 1,000,000 bits, hence 10 ms at 100 Mbps.
        self.assertAlmostEqual(transfer_ms(125_000, 100.0), 10.0)

    def test_token_prediction_and_carbon_units(self) -> None:
        spec = NetworkSpec(
            enabled=True,
            rtt_ms=40.0,
            uplink_mbps=100.0,
            downlink_mbps=200.0,
            prompt_bytes_per_token=4.0,
            output_bytes_per_token=8.0,
            energy_kwh_per_gb=0.2,
            carbon_g_per_kwh=500.0,
        )
        estimate = estimate_network(
            spec,
            prompt_tokens=25_000,
            output_tokens=1_000,
        )

        self.assertEqual(estimate.request_bytes, 100_000)
        self.assertEqual(estimate.response_bytes, 8_000)
        self.assertAlmostEqual(estimate.request_transfer_ms, 8.0)
        self.assertAlmostEqual(estimate.response_transfer_ms, 0.32)
        self.assertAlmostEqual(estimate.ttft_ms, 48.00032)
        self.assertAlmostEqual(estimate.completion_ms, 48.32)
        self.assertAlmostEqual(estimate.energy_j, 77.76)
        self.assertAlmostEqual(estimate.carbon_g, 0.0108)

    def test_actual_wire_bytes_override_token_approximation(self) -> None:
        spec = NetworkSpec(
            enabled=True,
            rtt_ms=20.0,
            uplink_mbps=10.0,
            downlink_mbps=20.0,
        )
        estimate = estimate_network(
            spec,
            prompt_tokens=999,
            output_tokens=999,
            request_bytes=10_000,
            response_bytes=5_000,
            first_response_bytes=100,
        )
        self.assertEqual(estimate.request_bytes, 10_000)
        self.assertEqual(estimate.response_bytes, 5_000)
        self.assertAlmostEqual(estimate.ttft_ms, 28.04)
        self.assertAlmostEqual(estimate.completion_ms, 30.0)

    def test_region_config_is_explicit_and_validated(self) -> None:
        config = {
            "rtt_ms": 9,
            "network": {
                "enabled": True,
                "inject_delay": True,
                "rtt_ms": 55,
                "uplink_mbps": 50,
                "downlink_mbps": 100,
                "energy_kwh_per_gb": 0.06,
                "carbon_g_per_kwh": 300,
            },
        }
        spec = NetworkSpec.from_region_config(config)
        self.assertTrue(spec.enabled)
        self.assertTrue(spec.inject_delay)
        self.assertEqual(spec.rtt_ms, 55.0)

        with self.assertRaises(ValueError):
            NetworkSpec.from_region_config(
                {"network": {"enabled": True, "uplink_mbps": 0}}
            )


if __name__ == "__main__":
    unittest.main()
