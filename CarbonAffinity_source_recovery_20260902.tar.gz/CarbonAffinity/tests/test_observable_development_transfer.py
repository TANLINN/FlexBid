import ast
import gzip
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from scripts import build_observable_corun_development_command as builder
from scripts.build_latency_residual_validation_transfer import build_payload


class DevelopmentTransferTests(unittest.TestCase):
    def test_plain_source_roundtrip_python310_and_bash(self):
        text, raw = builder.command(), builder.payload()
        copied = text.split("<<'OBSERVABLE_DEVELOPMENT_SOURCE_EOF'\n", 1)[1].split("OBSERVABLE_DEVELOPMENT_SOURCE_EOF\n", 1)[0]
        self.assertEqual(copied.encode(), raw)
        self.assertEqual(len(raw.decode().split(builder.SEPARATOR)), 4)
        for name, source in zip(builder.NAMES, raw.decode().split(builder.SEPARATOR)):
            ast.parse(source, filename=name, feature_version=(3, 10))
        ast.parse(builder.INSTALLER, feature_version=(3, 10))
        self.assertLess(text.index("-m unittest"), text.index("nohup env"))
        self.assertIn("EXPECTED_ROWS=2208", text)
        self.assertNotIn("base64", text)
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if bash.is_file():
            result = subprocess.run([str(bash), "-n"], input=text, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_checked_installer_and_installed_26_test_suite(self):
        base_raw = build_payload()
        expected = "faa9f726faf33f9932dc92b4149e34dc594a6782565e8a771f7b3e5c7040ce2e"
        self.assertEqual(hashlib.sha256(base_raw).hexdigest(), expected)
        base_payload = json.loads(gzip.decompress(base_raw))
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            base = root / "results/residual_latency_transfer_faa9f726faf33f99"
            base.mkdir(parents=True)
            for name, code in base_payload["files"].items():
                p = base / name
                p.parent.mkdir(exist_ok=True, parents=True)
                p.write_bytes(code.encode())
            deps = {}
            for name in base_payload["required_core_lf_sha256"]:
                p = root / name
                p.parent.mkdir(exist_ok=True, parents=True)
                data = (builder.PROJECT / name).read_text(encoding="utf-8").encode()
                p.write_bytes(data)
                deps[name] = hashlib.sha256(data).hexdigest()
            (base / "TRANSFER_MANIFEST.json").write_text(json.dumps(dict(payload_sha256=expected,
                files_sha256={n: hashlib.sha256(c.encode()).hexdigest() for n, c in base_payload["files"].items()},
                required_core_lf_sha256=deps)))
            script = builder.INSTALLER.replace("project=Path('/root/CarbonAffinity')", "project=Path(" + repr(str(root)) + ")")
            raw = builder.payload()
            digest = hashlib.sha256(raw).hexdigest()
            def install(data=raw):
                return subprocess.run([sys.executable, "-c", script, digest], input=data, capture_output=True)
            self.assertNotEqual(install(raw + b"corrupt").returncode, 0)
            self.assertFalse(list(root.glob("results/observable_corun_development_transfer_*")))
            result = install()
            self.assertEqual(result.returncode, 0, result.stderr)
            destination = Path(result.stdout.decode().strip())
            self.assertEqual(install().returncode, 0)
            for name in builder.NAMES:
                self.assertEqual((destination / name).read_bytes(), (builder.PROJECT / name).read_text(encoding="utf-8").encode())
            env = {**os.environ, "PYTHONPATH": str(destination) + os.pathsep + str(builder.PROJECT), "PYTHONNOUSERSITE": "1"}
            tests = subprocess.run([sys.executable, "-m", "unittest", "tests.test_latency_residual",
                "tests.test_corun_observable_pilot", "tests.test_corun_observable_development", "-q"],
                cwd=destination, env=env, capture_output=True, text=True, timeout=120)
            self.assertEqual(tests.returncode, 0, tests.stderr)
            self.assertIn("Ran 26 tests", tests.stderr)
            target = destination / builder.NAMES[2]
            target.write_text("# preserve user changes")
            self.assertNotEqual(install().returncode, 0)
            self.assertEqual(target.read_text(), "# preserve user changes")


if __name__ == "__main__":
    unittest.main()
