from __future__ import annotations

import asyncio
import unittest
from collections import Counter

from carbonaffinity.closed_loop import (
    AsyncClosedLoopCoordinator,
    ClosedLoopPlanner,
)
from carbonaffinity.models import RegionSnapshot, RequestSpec
from carbonaffinity.offline_oracle import OracleProblem


def option() -> dict:
    return {
        "cold_energy_j": 10,
        "warm_energy_j": 5,
        "cold_ttft_ms": 10,
        "warm_ttft_ms": 5,
        "tpot_ms": 10,
    }


def problem() -> OracleProblem:
    return OracleProblem.from_dict(
        {
            "regions": [
                {"region_id": "a", "capacity": 2},
                {"region_id": "b", "capacity": 2},
            ],
            "epochs": [
                {
                    "epoch_id": "0",
                    "carbon_lbs_per_mwh": {
                        "a": 1,
                        "b": 500,
                    },
                    "requests": [
                        {
                            "request_id": request_id,
                            "session_id": session_id,
                            "ttft_slo_ms": 100,
                            "tpot_slo_ms": 100,
                            "options": {
                                "a": option(),
                                "b": option(),
                            },
                        }
                        for request_id, session_id in (
                            ("r0", "s0"),
                            ("r1", "s1"),
                            ("r2", "s2"),
                        )
                    ],
                }
            ],
        }
    )


def snapshots(active_a: int = 0) -> dict[str, RegionSnapshot]:
    return {
        "a": RegionSnapshot("a", active_a, 0, capacity=2),
        "b": RegionSnapshot("b", 0, 0, capacity=2),
    }


class ClosedLoopPlannerTests(unittest.TestCase):
    def test_background_load_and_joint_batch_are_reserved_atomically(self) -> None:
        planner = ClosedLoopPlanner(problem())
        plan = planner.plan(
            ["r0", "r1"],
            snapshots(active_a=1),
            {"a": 1, "b": 500},
        )
        routes = Counter(
            assignment.region_id
            for assignment in plan.assignments
        )
        self.assertEqual(routes, Counter({"a": 1, "b": 1}))
        self.assertEqual(planner.reserved, {"a": 1, "b": 1})
        for assignment in plan.assignments:
            if assignment.region_id == "a":
                self.assertEqual(assignment.background_load, 1)
                self.assertEqual(assignment.projected_total_load, 2)

    def test_second_batch_cannot_observe_reserved_region_as_empty(self) -> None:
        planner = ClosedLoopPlanner(problem())
        first = planner.plan(
            ["r0", "r1"], snapshots(), {"a": 1, "b": 500}
        )
        self.assertEqual(
            Counter(item.region_id for item in first.assignments),
            Counter({"a": 2}),
        )
        second = planner.plan(
            ["r2"], snapshots(), {"a": 1, "b": 500}
        )
        self.assertEqual(second.assignments[0].region_id, "b")
        self.assertEqual(dict(second.load_before)["a"], 2)

    def test_completion_releases_reservation_and_updates_placement(self) -> None:
        planner = ClosedLoopPlanner(problem())
        plan = planner.plan(
            ["r0"], snapshots(), {"a": 1, "b": 500}
        )
        assignment = plan.assignments[0]
        planner.complete(
            assignment.request_id,
            assignment.region_id,
            success=True,
        )
        self.assertEqual(planner.reserved[assignment.region_id], 0)
        self.assertEqual(
            planner.placements["s0"], assignment.region_id
        )


class AsyncClosedLoopCoordinatorTests(
    unittest.IsolatedAsyncioTestCase
):
    async def test_simultaneous_requests_share_one_atomic_plan(self) -> None:
        planner = ClosedLoopPlanner(problem())
        coordinator = AsyncClosedLoopCoordinator(
            planner,
            control_interval_ms=1,
        )
        requests = [
            RequestSpec("r0", 0, 1, 1, "s0"),
            RequestSpec("r1", 0, 1, 1, "s1"),
        ]
        decisions = await asyncio.gather(*(
            coordinator.assign(
                request,
                snapshots(),
                {"a": 1, "b": 500},
            )
            for request in requests
        ))
        self.assertEqual(
            {decision.batch_id for decision in decisions},
            {0},
        )
        self.assertEqual(
            Counter(decision.region_id for decision in decisions),
            Counter({"a": 2}),
        )
        self.assertEqual(planner.reserved["a"], 2)
        for request, decision in zip(requests, decisions):
            await coordinator.complete(
                request.request_id,
                decision.region_id,
                True,
            )
        await coordinator.close()
        self.assertEqual(planner.reserved["a"], 0)


if __name__ == "__main__":
    unittest.main()
