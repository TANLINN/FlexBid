import gzip
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from scripts import build_observable_corun_command as builder
from scripts.build_latency_residual_validation_transfer import build_payload


class TransferTests(unittest.TestCase):
    def test_guard_requires_exact_saved_failure_and_guarded_bash_is_valid(self):
        remote = "/root/CarbonAffinity/results/observable_corun_pilot_20260830T110355466618931Z"
        text = builder.command(remote)
        self.assertIn(remote, text)
        self.assertLess(text.index("V1_DECODE_OVERLAP_CONSTRUCTION_FAILURE_CONFIRMED"), text.index("if CORUN_BUNDLE="))
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if bash.is_file():
            result = subprocess.run([str(bash), "-n"], input=text, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "FATAL.json").write_text('{"status":"FAIL"}')
            row = dict(case_id="cold_small_decode2", checks=dict(schema_complete=False),
                collection_error="RuntimeError: background finished/failed before requested phase; case retained",
                results=dict(bg0=dict(success=True, output_tokens=192)))
            for gpu in range(8):
                p = root / "raw" / f"gpu_{gpu}" / "measurements.jsonl"
                p.parent.mkdir(parents=True)
                p.write_text("".join(json.dumps(r) + "\n" for r in [dict(checks=dict(ok=True))]*4 + [row]))
            def guard():
                return subprocess.run([sys.executable, "-c", builder.FAILURE_GUARD, str(root)], capture_output=True, text=True)
            result = guard()
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("CONSTRUCTION_FAILURE_CONFIRMED", result.stdout)
            row["results"]["bg0"]["success"] = False
            (root / "raw/gpu_7/measurements.jsonl").write_text("".join(json.dumps(r) + "\n" for r in [dict(checks=dict(ok=True))]*4 + [row]))
            self.assertNotEqual(guard().returncode, 0)

    def test_payload_roundtrip_and_bash_syntax(self):
        raw = builder.payload()
        text = builder.command()
        copied = text.split("<<'OBSERVABLE_CORUN_SOURCES_EOF'\n", 1)[1].split("OBSERVABLE_CORUN_SOURCES_EOF\n", 1)[0]
        self.assertEqual(copied.encode(), raw)
        for name, source in zip(builder.NAMES, raw.decode().split(builder.SEPARATOR)):
            compile(source, name, "exec")
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if bash.is_file():
            result = subprocess.run([str(bash), "-n"], input=text, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
        self.assertLess(text.index("-m unittest"), text.index("nohup env"))
        self.assertNotIn("base64", text)

    def test_install_checksums_exclusive_sources_and_all_installed_tests(self):
        original = build_payload()
        self.assertEqual(hashlib.sha256(original).hexdigest(), builder.BASE_DIGEST)
        base_payload = json.loads(gzip.decompress(original))
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            base = root / "results/residual_latency_transfer_faa9f726faf33f99"
            base.mkdir(parents=True)
            for name, code in base_payload["files"].items():
                p = base / name
                p.parent.mkdir(exist_ok=True, parents=True)
                p.write_bytes(code.encode())
            deps = {}
            for name in base_payload["required_core_lf_sha256"]:
                p = root / name
                p.parent.mkdir(exist_ok=True, parents=True)
                data = (builder.PROJECT / name).read_text(encoding="utf-8").encode()
                p.write_bytes(data)
                deps[name] = hashlib.sha256(data).hexdigest()
            (base / "TRANSFER_MANIFEST.json").write_text(json.dumps(dict(payload_sha256=builder.BASE_DIGEST,
                files_sha256={n: hashlib.sha256(c.encode()).hexdigest() for n, c in base_payload["files"].items()},
                required_core_lf_sha256=deps)))
            script = builder.INSTALLER.replace("project=Path('/root/CarbonAffinity')", "project=Path(" + repr(str(root)) + ")")
            raw = builder.payload()
            digest = hashlib.sha256(raw).hexdigest()
            def install(data):
                return subprocess.run([sys.executable, "-c", script, digest], input=data, capture_output=True)
            self.assertNotEqual(install(raw + b"corruption").returncode, 0)
            self.assertEqual(len(list(root.glob("results/observable_corun_transfer_*"))), 0)
            result = install(raw)
            self.assertEqual(result.returncode, 0, result.stderr)
            destination = Path(result.stdout.decode().strip())
            self.assertEqual(install(raw).returncode, 0)
            for name in builder.NAMES:
                self.assertEqual((destination / name).read_bytes(), (builder.PROJECT / name).read_text(encoding="utf-8").encode())
            env = {**os.environ, "PYTHONPATH": str(destination) + os.pathsep + str(builder.PROJECT), "PYTHONNOUSERSITE": "1"}
            tests = subprocess.run([sys.executable, "-m", "unittest", "tests.test_latency_residual", "tests.test_corun_observable_pilot", "-q"],
                                   cwd=destination, env=env, capture_output=True, text=True, timeout=100)
            self.assertEqual(tests.returncode, 0, tests.stderr)
            (destination / builder.NAMES[0]).write_text("# changed")
            self.assertNotEqual(install(raw).returncode, 0)
            self.assertEqual((destination / builder.NAMES[0]).read_text(), "# changed")


if __name__ == "__main__":
    unittest.main()
