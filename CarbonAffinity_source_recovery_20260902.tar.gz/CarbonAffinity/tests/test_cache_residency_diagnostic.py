import asyncio
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch

from carbonaffinity.models import CompletionResult
from scripts import cache_residency_diagnostic as diagnostic

REAL_ASYNCIO_SLEEP = asyncio.sleep


def result(request_id="probe", cached=None, output=64, prompt=31_744):
    return CompletionResult(
        request_id, "gpu_3", True, 200, 1, 2, 3, 100.0, 35.0,
        output, prompt, cached,
    )


def branch(branch_id, cached_values):
    return {
        "branch_id": branch_id,
        "probe_results": [
            {"cached_prompt_tokens_observed": value} for value in cached_values
        ],
    }


class FakeMaterializer:
    def __init__(self, _name):
        self.tokens_by_id = {}

    def tokens(self, row):
        marker = len(self.tokens_by_id) + 1
        value = self.tokens_by_id.setdefault(row["request_id"], marker)
        return [value] * row["prompt_tokens"]


class FakeClient:
    instance = None

    def __init__(self, config, *_args, **_kwargs):
        self.config = config
        self.calls = []
        self.closed = False
        self.active = {"prime": 0, "concurrent_n2": 0, "concurrent_n3": 0}
        self.peak = dict(self.active)
        FakeClient.instance = self

    async def complete(self, request, prompt, cache_salt):
        phase = "prime"
        if request.max_output_tokens == diagnostic.PROBE_OUTPUT_TOKENS:
            phase = request.request_id.rsplit("-probe-", 1)[0]
        self.active[phase] += 1
        self.peak[phase] = max(self.peak[phase], self.active[phase])
        self.calls.append((request.request_id, tuple(prompt), cache_salt))
        try:
            await REAL_ASYNCIO_SLEEP(0)
            cached = None
            if request.max_output_tokens == diagnostic.PROBE_OUTPUT_TOKENS:
                cached = diagnostic.EXPECTED_CACHED_TOKENS
            return result(
                request.request_id, cached, request.max_output_tokens, len(prompt)
            )
        finally:
            self.active[phase] -= 1

    async def close(self):
        self.closed = True


class CacheResidencyDiagnosticTests(unittest.TestCase):
    def test_reset_confirmation_requires_explicit_success(self):
        accepted = [
            (200, True),
            (200, ""),
            (200, {"success": True}),
            (200, {"reset": True}),
        ]
        rejected = [
            (500, True),
            (200, False),
            (200, None),
            (200, "true"),
            (200, {"success": False}),
            (200, {"reset": False}),
            (200, {}),
        ]
        for status, body in accepted:
            self.assertTrue(diagnostic.reset_confirmed(status, body))
        for status, body in rejected:
            self.assertFalse(diagnostic.reset_confirmed(status, body))

    def test_reset_log_evidence_distinguishes_engine_result(self):
        success_text = (
            "Resetting prefix cache...\n"
            "Successfully reset prefix cache\n"
        )
        failure_text = (
            "Resetting prefix cache...\n"
            "Failed to reset prefix cache because blocks are in use\n"
        )
        lines, success, failure = diagnostic.reset_log_evidence(success_text)
        self.assertEqual(len(lines), 1)
        self.assertTrue(success)
        self.assertFalse(failure)
        _, success, failure = diagnostic.reset_log_evidence(failure_text)
        self.assertFalse(success)
        self.assertTrue(failure)

    def test_branch_design_is_two_isolated_concurrency_questions(self):
        self.assertEqual(
            diagnostic.branch_specs(),
            (
                {"branch_id": "concurrent_n2", "prime_indices": (0, 1)},
                {"branch_id": "concurrent_n3", "prime_indices": (0, 1, 2)},
            ),
        )

    def test_cache_observation_is_not_an_integrity_requirement(self):
        record = {
            "success": True, "status_code": 200, "error": None,
            "prompt_tokens_reported": diagnostic.PROMPT_TOKENS,
            "output_tokens": diagnostic.PROBE_OUTPUT_TOKENS,
            "cached_prompt_tokens_observed": None,
        }
        self.assertEqual(diagnostic.request_errors(record, 64), [])
        self.assertFalse(diagnostic.exact_hit(record))

    def test_classification(self):
        exact = diagnostic.EXPECTED_CACHED_TOKENS
        cases = [
            ([None, exact], [exact, exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_NON_MONOTONE_INCONCLUSIVE"),
            ([exact, exact], [None, exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"),
            ([exact, exact], [exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"),
            ([exact], [exact, exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_NON_MONOTONE_INCONCLUSIVE"),
            ([], [exact, exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_NON_MONOTONE_INCONCLUSIVE"),
            ([], [None, exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_BELOW_2"),
            ([exact, exact], [],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"),
            ([exact, exact], [exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"),
            ([exact, exact, exact], [exact, exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_NON_MONOTONE_INCONCLUSIVE"),
            ([exact, exact], [exact, exact, exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"),
            ([exact, exact], [exact, exact, exact],
             "SINGLE_GPU_LONG_WARM_CONCURRENCY_AT_LEAST_3"),
        ]
        for n2, n3, expected in cases:
            branches = [branch("concurrent_n2", n2),
                        branch("concurrent_n3", n3)]
            self.assertEqual(diagnostic.classify(branches), expected)

    def test_collection_rebuilds_every_branch_and_reuses_prompt_and_salt(self):
        with tempfile.TemporaryDirectory(dir=".") as temporary:
            root = Path(temporary)
            reset = AsyncMock(
                return_value={"status_code": 200, "body": True,
                              "engine_success": True, "confirmed": True}
            )
            with patch("carbonaffinity.materialize.PromptMaterializer", FakeMaterializer), \
                 patch("carbonaffinity.region.RegionClient", FakeClient), \
                 patch.object(diagnostic, "physical_reset", reset), \
                 patch.object(diagnostic.asyncio, "sleep", AsyncMock()):
                branches = asyncio.run(diagnostic.run_diagnostic(
                    root, Path("/fake/model"), diagnostic.MODEL_NAME
                ))
            self.assertEqual(len(branches), 2)
            self.assertTrue(all(item["integrity_valid"] for item in branches))
            self.assertTrue(FakeClient.instance.closed)
            self.assertGreaterEqual(
                FakeClient.instance.config["admission_concurrency"], 3
            )
            self.assertEqual(reset.await_count, 2)
            self.assertEqual(FakeClient.instance.peak["prime"], 1)
            self.assertEqual(FakeClient.instance.peak["concurrent_n2"], 2)
            self.assertEqual(FakeClient.instance.peak["concurrent_n3"], 3)
            calls = FakeClient.instance.calls
            self.assertEqual(len(calls), 2 + 2 + 3 + 3)
            by_session = {}
            for request_id, prompt, salt in calls:
                session = int(salt.rsplit("-", 1)[1])
                by_session.setdefault(session, []).append((prompt, salt))
            self.assertEqual(
                {key: len(value) for key, value in by_session.items()},
                {0: 4, 1: 4, 2: 2},
            )
            self.assertNotIn(3, by_session)
            for values in by_session.values():
                self.assertEqual(len({value[0] for value in values}), 1)
                self.assertEqual(len({value[1] for value in values}), 1)
            self.assertEqual(branches[0]["prime_order"], [0, 1])
            self.assertEqual(branches[0]["probe_indices"], [0, 1])
            self.assertEqual(branches[1]["prime_order"], [0, 1, 2])
            self.assertEqual(branches[1]["probe_indices"], [0, 1, 2])
            self.assertEqual(diagnostic.classify(branches),
                             "SINGLE_GPU_LONG_WARM_CONCURRENCY_AT_LEAST_3")

    def test_probe_exception_is_retained_alongside_successful_probe(self):
        class OneProbeFails(FakeClient):
            async def complete(self, request, prompt, cache_salt):
                if request.request_id == "concurrent_n3-probe-1":
                    raise RuntimeError("synthetic failure")
                if request.request_id == "concurrent_n3-probe-2":
                    raise asyncio.CancelledError("synthetic cancellation")
                return await super().complete(request, prompt, cache_salt)

        with tempfile.TemporaryDirectory(dir=".") as temporary:
            root = Path(temporary)
            with patch("carbonaffinity.materialize.PromptMaterializer", FakeMaterializer), \
                 patch("carbonaffinity.region.RegionClient", OneProbeFails), \
                 patch.object(diagnostic, "physical_reset", AsyncMock(
                     return_value={"status_code": 200, "body": True,
                                   "engine_success": True,
                                   "confirmed": True})), \
                 patch.object(diagnostic.asyncio, "sleep", AsyncMock()):
                with self.assertRaises(RuntimeError):
                    asyncio.run(diagnostic.run_diagnostic(
                        root, Path("/fake/model"), diagnostic.MODEL_NAME
                    ))
            raw = json.loads(
                (root / "branches" / "concurrent_n3.json").read_text()
            )
            self.assertEqual(len(raw["probe_results"]), 3)
            failed = raw["probe_results"][1]
            self.assertFalse(failed["success"])
            self.assertIn("synthetic failure", failed["error"])
            cancelled = raw["probe_results"][2]
            self.assertFalse(cancelled["success"])
            self.assertIn("synthetic cancellation", cancelled["error"])


if __name__ == "__main__":
    unittest.main()
