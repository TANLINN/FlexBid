from __future__ import annotations

import unittest

from carbonaffinity.latency_surface import estimate_latency_surface


class LatencySurfaceRuntimeTests(unittest.TestCase):
    def model(self) -> dict:
        cells = {}
        for mode, base in (("cold", 100.0), ("warm", 20.0)):
            for prompt, prompt_extra in ((2048, 0.0), (8192, 40.0)):
                for concurrency, active_extra in ((1, 0.0), (4, 30.0)):
                    cells[f"{mode}|{prompt}|{concurrency}"] = {
                        "ttft_ms": base + prompt_extra + active_extra,
                        "tpot_ms": base / 10 + prompt_extra / 10 + active_extra / 10,
                    }
        return {
            "prompt_buckets": [2048, 8192],
            "concurrency_buckets": [1, 4],
            "cells": cells,
            "one_sided_q95_residual_ms": {
                "cold": {"ttft_ms": 10, "tpot_ms": 1},
                "warm": {"ttft_ms": 2, "tpot_ms": 0.2},
            },
        }

    def test_exact_endpoints_include_calibrated_margin(self) -> None:
        value = estimate_latency_surface(self.model(), 2048, 0, 1)
        self.assertEqual(value, (110.0, 11.0))

    def test_partial_cache_and_intermediate_anchors_interpolate(self) -> None:
        value = estimate_latency_surface(self.model(), 4096, 2048, 2)
        self.assertAlmostEqual(value[0], 96.0)
        self.assertAlmostEqual(value[1], 9.6)

    def test_missing_model_preserves_legacy_fallback(self) -> None:
        self.assertIsNone(estimate_latency_surface(None, 2048, 0, 1))


if __name__ == "__main__":
    unittest.main()
