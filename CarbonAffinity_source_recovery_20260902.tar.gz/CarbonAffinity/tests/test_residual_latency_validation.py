"""Synthetic independent-validation gates. Does not run or emulate a real GPU."""
import asyncio
import hashlib
import json
import tempfile
import unittest
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

from carbonaffinity.artifacts import read_rows, sha256, write_json
from scripts import residual_latency_validation as validation
from scripts.latency_residual_protocol import cases as development_cases, features, result_checks
from scripts.measure_latency_residual import collect
from scripts.residual_latency_candidate import fit_candidate
from tests.test_latency_residual import Client, Materializer, event, fixture, result


def candidate_fixture(root):
    dev = root / "development"
    fixture(dev)
    model, _ = fit_candidate(read_rows(dev / "raw"))
    import scripts.residual_latency_candidate as estimator
    import scripts.latency_residual_protocol as protocol
    fit_root = root / "fit"
    record = fit_root / "FIT_RECORD.json"
    write_json(record, {"fit_code_sha256": {str(Path(m.__file__).resolve()): sha256(m.__file__)
                                          for m in (estimator, protocol)}})
    model["development_source"] = {"fit_record_sha256": sha256(record)}
    path = fit_root / "candidate.json"
    write_json(path, model)
    return path


def validation_fixture(root):
    root.mkdir()
    extra = validation.prepare(root, SimpleNamespace())
    write_json(root / "PREREGISTRATION.json", {"design": validation.design(), "expected_rows": 432,
        "code_sha256": {str(Path(__file__).resolve()): sha256(__file__)}, **extra})
    write_json(root / "LAUNCH.json", {"runtime_cap": 784, "effective_cap_verified": True, "cache_block784_verified": True})
    evidence = sha256(root / "LAUNCH.json")
    snapshots = {}
    for gpu in range(8):
        data = "".join(event(bt) for bt in (16, 32, 64)).encode()
        (root / f"vllm_gpu_{gpu}.log").write_bytes(data)
        snapshots[str(gpu)] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        rows = []
        for case in validation.cases():
            warm, p, n = case["mode"] == "warm", case["prompt_tokens"], case["concurrency"]
            cache = case["cached_context_target"] if warm else None
            records = [asdict(result(p, cached=cache)) for _ in range(n)]
            salt = f"gpu{gpu}/{case['case_id']}"
            rows.append({**case, "protocol": validation.VERSION, "gpu_index": gpu,
                "results": records, "runtime_evidence_sha256": evidence,
                "cache_features": [features(r) for r in records],
                "result_checks": [result_checks(r, p, 64, cache) for r in records],
                "prime": asdict(result(p, out=1)) if warm else None,
                "cache_salts": [salt if warm else f"{salt}/{i}" for i in range(n)]})
        destination = root / "raw" / f"gpu_{gpu}" / "measurements.jsonl"
        destination.parent.mkdir(parents=True)
        destination.write_text("".join(json.dumps(r) + "\n" for r in rows))
    write_json(root / "SHAPE_PREWARM.json", {"gpu_indices": list(range(8)), "requests": 64,
        "checks": {"all_shape_keys_observed": True}, "logs": snapshots})


class ValidationTests(unittest.TestCase):
    def test_new_grid_and_unchanged_development(self):
        grid = validation.cases()
        self.assertEqual(len(grid), 54)
        self.assertEqual(validation.design()["expected_rows"], 432)
        for name in ("cached_context_target", "residual_target", "concurrency", "prompt_tokens"):
            self.assertFalse({c[name] for c in grid} & {c[name] for c in development_cases()})
        self.assertEqual(len(development_cases()), 108)

    def test_reused_collector_has_54_cases_and_exact_cache(self):
        with tempfile.TemporaryDirectory() as temp:
            args = SimpleNamespace(gpu_index=0, output=Path(temp) / "measurements.jsonl", runtime_evidence="fake")
            with patch("scripts.measure_latency_residual.asyncio.sleep", new_callable=AsyncMock), patch("builtins.print"):
                asyncio.run(collect(args, Materializer(), Client(), case_grid=validation.cases(), protocol=validation.VERSION))
            rows = read_rows(args.output)
            self.assertEqual(len(rows), 54)
            self.assertTrue(all(r["protocol"] == validation.VERSION for r in rows))
            self.assertTrue(all(all(all(c.values()) for c in r["result_checks"]) for r in rows))

    def test_prepare_hash_failure_writes_no_locked_model(self):
        with tempfile.TemporaryDirectory() as temp:
            parent = Path(temp)
            candidate = candidate_fixture(parent)
            output = parent / "run"
            output.mkdir()
            with patch.object(validation, "CANDIDATE_PATH", candidate), patch.object(validation, "CANDIDATE_SHA256", "0" * 64):
                with self.assertRaisesRegex(ValueError, "HASH_MISMATCH"):
                    validation.prepare(output, SimpleNamespace())
            self.assertEqual(list(output.iterdir()), [])

    def test_complete_grid_pass_preserves_candidate(self):
        with tempfile.TemporaryDirectory() as temp:
            parent = Path(temp)
            candidate = candidate_fixture(parent)
            before = candidate.read_bytes()
            with patch.object(validation, "CANDIDATE_PATH", candidate), patch.object(validation, "CANDIDATE_SHA256", sha256(candidate)):
                root = parent / "run"
                validation_fixture(root)
                report = validation.audit(root)
            self.assertEqual(report["status"], "PASS", report["checks"])
            self.assertEqual(before, candidate.read_bytes())
            self.assertFalse(report["candidate_frozen"])
            self.assertTrue(all(g["samples"] == 216 for g in report["overall"].values()))
            self.assertEqual(len(report["by_cell"]), 54)

    def test_per_gpu_fail_not_hidden_by_pooled_pass(self):
        with tempfile.TemporaryDirectory() as temp:
            parent = Path(temp)
            candidate = candidate_fixture(parent)
            with patch.object(validation, "CANDIDATE_PATH", candidate), patch.object(validation, "CANDIDATE_SHA256", sha256(candidate)):
                root = parent / "run"
                validation_fixture(root)
                path = root / "raw/gpu_0/measurements.jsonl"
                rows = read_rows(path)
                changed = 0
                for row in rows:
                    if row["mode"] == "warm" and changed < 2:
                        row["results"][0]["ttft_ms"] = 9999
                        changed += 1
                path.write_text("".join(json.dumps(r) + "\n" for r in rows))
                report = validation.audit(root)
            self.assertTrue(report["checks"]["all_raw_integrity_checks"])
            self.assertTrue(report["checks"]["each_mode_metric_coverage_95pct"])
            self.assertFalse(report["checks"]["each_gpu_mode_metric_coverage_95pct"])
            self.assertEqual(report["status"], "FAIL")
            self.assertEqual(len(report["underpredictions"]), 2)

    def test_missing_row_fake_cache_and_post_tuning_fail(self):
        with tempfile.TemporaryDirectory() as temp:
            parent = Path(temp)
            candidate = candidate_fixture(parent)
            with patch.object(validation, "CANDIDATE_PATH", candidate), patch.object(validation, "CANDIDATE_SHA256", sha256(candidate)):
                for issue in ("missing", "cache", "tuning", "forecast"):
                    with self.subTest(issue=issue):
                        root = parent / issue
                        validation_fixture(root)
                        path = root / "raw/gpu_0/measurements.jsonl"
                        rows = read_rows(path)
                        if issue == "missing":
                            path.write_text("".join(json.dumps(r) + "\n" for r in rows[:-1]))
                        elif issue == "cache":
                            next(r for r in rows if r["mode"] == "warm")["results"][0]["cached_prompt_tokens_observed"] = None
                            path.write_text("".join(json.dumps(r) + "\n" for r in rows))
                        elif issue == "tuning":
                            with (root / "vllm_gpu_0.log").open("a") as handle:
                                handle.write(event(32))
                        else:
                            predictions = root / "PREDICTIONS_BEFORE_MEASUREMENT.json"
                            data = json.loads(predictions.read_text())
                            next(iter(data.values()))["prediction_ms"]["ttft_ms"] = 9999
                            predictions.write_text(json.dumps(data))
                        before = path.read_bytes()
                        report = validation.audit(root)
                        self.assertEqual(report["status"], "FAIL")
                        self.assertEqual(path.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
