"""Exercise the real clipboard helper in print-only mode; never launch GPUs."""
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from scripts.build_latency_probe_transfer import PROJECT

BASH = shutil.which('bash') or 'E:/Program Files/Git/bin/bash.exe'
POWERSHELL = shutil.which('powershell')


@unittest.skipUnless(POWERSHELL and Path(BASH).is_file(), 'Windows helper tools required')
class SinglePasteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        command = [POWERSHELL, '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                   str(PROJECT / 'scripts/copy_latency_probe_short_steps.ps1'),
                   '-ShapeWarmup', '-PrintOnly']
        plan = subprocess.run(command, capture_output=True, text=True, check=True)
        cls.plan = json.loads(plan.stdout)
        result = subprocess.run(command + ['-SinglePaste'], capture_output=True,
                                text=True, check=True)
        cls.source = result.stdout

    def test_full_command_syntax_and_guarded_steps(self):
        result = subprocess.run([BASH, '-n'], input=self.source, text=True,
                                capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        for step in self.plan['steps']:
            self.assertIn(step['command'] + ' || exit 1', self.source)
        self.assertIn(self.plan['sha256'], self.source)
        self.assertIn('&& bash -n "$PROBE_SCRIPT"', self.source)
        self.assertNotIn('Read-Host', self.source)

    def simulate(self, failing_step=None):
        source = self.source
        for i, step in enumerate(self.plan['steps']):
            source = source.replace(step['command'],
                                    'false' if i == failing_step else f'echo STEP_{i}')
        # Replace the entire launch branch. No original Python command or nohup runs.
        begin = source.index('); then\n') + len('); then\n')
        end = source.index('\nelse\n    echo TRANSFER_FAILED_NOT_STARTED', begin)
        source = source[:begin] + 'echo WOULD_START' + source[end:]
        self.assertNotIn('nohup', source)
        self.assertNotIn('/.venv/bin/python', source)
        return subprocess.run([BASH], input='set -e\n' + source + '\necho TERMINAL_ALIVE\n',
                              capture_output=True, text=True)

    def test_success_reaches_launch_branch(self):
        result = self.simulate()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('WOULD_START', result.stdout)
        self.assertIn('TERMINAL_ALIVE', result.stdout)

    def test_failure_stops_following_steps_and_preserves_terminal(self):
        for index in (0, len(self.plan['steps']) // 2, len(self.plan['steps']) - 1):
            with self.subTest(index=index):
                result = self.simulate(index)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn('TRANSFER_FAILED_NOT_STARTED', result.stdout)
                self.assertNotIn('WOULD_START', result.stdout)
                self.assertNotIn(f'STEP_{index + 1}\n', result.stdout)
                self.assertIn('TERMINAL_ALIVE', result.stdout)


if __name__ == '__main__':
    unittest.main()
