import unittest

from scripts import cache_residency_frontier_driver as driver


def branch(branch_id, values):
    return {
        "branch_id": branch_id,
        "probe_results": [
            {"cached_prompt_tokens_observed": value}
            for value in values
        ],
    }


class CacheResidencyFrontierDriverTests(unittest.TestCase):
    def test_branch_specs(self):
        self.assertEqual(
            driver.branch_specs(),
            (
                {"branch_id": "concurrent_n2", "prime_indices": (0, 1)},
                {"branch_id": "concurrent_n3", "prime_indices": (0, 1, 2)},
            ),
        )

    def test_classification_boundaries(self):
        hit = driver.EXPECTED_CACHED_TOKENS
        cases = (
            ([hit, hit], [hit, hit, hit], "SINGLE_GPU_LONG_WARM_CONCURRENCY_AT_LEAST_3"),
            ([hit, hit], [hit, None, hit], "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"),
            ([hit, None], [hit, None, hit], "SINGLE_GPU_LONG_WARM_CONCURRENCY_BELOW_2"),
            ([hit, None], [hit, hit, hit], "SINGLE_GPU_LONG_WARM_CONCURRENCY_NON_MONOTONE_INCONCLUSIVE"),
            ([hit], [hit, hit, hit], "SINGLE_GPU_LONG_WARM_CONCURRENCY_NON_MONOTONE_INCONCLUSIVE"),
            ([hit, hit], [hit, hit], "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"),
        )
        for n2, n3, expected in cases:
            with self.subTest(n2=n2, n3=n3):
                self.assertEqual(
                    driver.classify([
                        branch("concurrent_n2", n2),
                        branch("concurrent_n3", n3),
                    ]),
                    expected,
                )


if __name__ == "__main__":
    unittest.main()
