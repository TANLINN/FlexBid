from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import yaml

from scripts.prepare_bounded_runtime_gate import prepare, trace_rows


def save(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload), encoding="utf-8")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class BoundedRuntimeGatePreparationTests(unittest.TestCase):
    def test_trace_is_exactly_bounded_to_runtime_model_domain(self):
        rows = trace_rows()
        self.assertEqual(len(rows), 40)
        self.assertTrue(all(row["max_output_tokens"] == 64 for row in rows))
        self.assertTrue(all(row["prompt_tokens"] in {8192, 16384} for row in rows))
        arrivals = {}
        for row in rows:
            arrivals.setdefault(row["arrival_ms"], []).append(row)
        self.assertEqual(sorted(len(group) for group in arrivals.values()).count(3), 8)
        self.assertLessEqual(max(map(len, arrivals.values())), 3)

    def test_prepare_builds_eight_profiles_and_external_freeze_record(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            base = {
                "experiment": {"name": "base", "trace": "old.jsonl"},
                "carbon": {"trace": "data/carbon.csv"},
                "regions": [{
                    "id": f"r{gpu}",
                    "profile": "old.json",
                    "site_manifest": f"manifests/r{gpu}.json",
                    "admission_concurrency": 8,
                } for gpu in range(8)],
                "runtime": {},
                "artifact_metadata": {},
            }
            base_path = root / "base.yaml"
            base_path.write_text(yaml.safe_dump(base), encoding="utf-8")

            energy_path = root / "energy.json"
            energy_profile = {
                "base_request_j": 1,
                "cold_prefill_j_per_token": 2,
                "cached_prefill_j_per_token": 3,
                "decode_j_per_token": 4,
                "batch_energy_model": {"cells": {}, "global": {"1": 1}},
            }
            save(energy_path, {
                "profiles": {str(gpu): dict(energy_profile) for gpu in range(8)}
            })
            energy_report = root / "energy_validation.json"
            save(energy_report, {
                "status": "PASS",
                "candidate_sha256": sha(energy_path),
                "failed_checks": [],
            })

            residual_path = root / "residual.json"
            save(residual_path, {
                "model_kind": "residual_latency_monotone_candidate_v1",
                "surfaces": {
                    "cold": {"axes": {"prompt_tokens": [1600, 32128]}},
                },
            })
            residual_freeze = root / "residual.freeze.json"
            save(residual_freeze, {
                "status": "FROZEN",
                "model_sha256": sha(residual_path),
            })

            observable_path = root / "observable.json"
            save(observable_path, {
                "model_kind": "observable_corun_stratified_monotone_candidate_v1",
            })
            observable_report = root / "observable_validation.json"
            save(observable_report, {
                "status": "PASS",
                "candidate_sha256": sha(observable_path),
                "failed_checks": [],
                "bounded_primary_validation_passed": True,
                "continuous_arrival_tpot_validated": False,
            })

            output = root / "bundle"
            manifest = prepare(argparse.Namespace(
                base_config=base_path,
                energy_candidate=energy_path,
                energy_validation=energy_report,
                residual_model=residual_path,
                residual_freeze_record=residual_freeze,
                observable_candidate=observable_path,
                observable_validation=observable_report,
                output_root=output,
            ))
            self.assertEqual(manifest["status"], "READY")
            self.assertEqual(len(manifest["profiles"]), 8)
            self.assertEqual(len((output / "bounded_trace.jsonl").read_text().splitlines()), 40)
            freeze = json.loads(
                (output / "models" / "observable_corun_v1.freeze.json").read_text()
            )
            self.assertEqual(freeze["status"], "FROZEN")
            config = yaml.safe_load((output / "config.yaml").read_text())
            self.assertEqual(
                [row["admission_concurrency"] for row in config["regions"]],
                [3] * 8,
            )
            self.assertTrue(Path(config["carbon"]["trace"]).is_absolute())
            self.assertTrue(all(
                Path(row["site_manifest"]).is_absolute()
                for row in config["regions"]
            ))


if __name__ == "__main__":
    unittest.main()
