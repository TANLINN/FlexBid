import base64
import hashlib
import os
import shlex
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path, PurePosixPath, PureWindowsPath
from unittest.mock import patch

from scripts.build_latency_residual_transfer import INSTALLER, DEPENDENCIES, PROJECT
from scripts.build_latency_residual_validation_transfer import build_payload, command
from scripts import build_latency_residual_validation_transfer as builder


class TransferTests(unittest.TestCase):
    def test_remote_candidate_argument_is_posix_on_both_build_hosts(self):
        expected = "/root/CarbonAffinity/results/latency_residual_candidate_20260830T093035635670917Z/residual_latency_candidate_v1.json"
        for path_type in (PureWindowsPath, PurePosixPath):
            with self.subTest(host=path_type.__name__), patch.object(builder, "CANDIDATE_PATH", path_type(expected)):
                script = command(b"not executed")
                guard = next(line.strip() for line in script.splitlines()
                             if line.strip().startswith("if /root/CarbonAffinity/.venv/bin/python -c "))
                argv = shlex.split(guard)
                candidate_arg = argv[argv.index("-c") + 2]
                self.assertEqual(candidate_arg, expected)
                self.assertNotIn("\\", candidate_arg)

    def test_generated_hash_guard_reads_file_and_rejects_wrong_hash(self):
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if not bash.exists():
            self.skipTest("bash unavailable")
        with tempfile.TemporaryDirectory() as temp:
            candidate = Path(temp) / "candidate with spaces.json"
            candidate.write_bytes(b'{"synthetic": true}\n')
            digest = hashlib.sha256(candidate.read_bytes()).hexdigest()
            for expected_hash, marker in ((digest, "HASH_PASS"), ("0" * 64, "HASH_FAIL")):
                with self.subTest(expected=marker), patch.object(builder, "CANDIDATE_PATH", candidate), \
                     patch.object(builder, "CANDIDATE_SHA256", expected_hash):
                    script = command(b"not executed")
                    guard = next(line.strip() for line in script.splitlines()
                                 if line.strip().startswith("if /root/CarbonAffinity/.venv/bin/python -c "))
                    guard = guard.replace("/root/CarbonAffinity/.venv/bin/python", shlex.quote(Path(sys.executable).as_posix()), 1)
                    # Execute ONLY the real generated read-only hash guard,
                    # never the installer, tests, or GPU launch branches.
                    harness = guard + '\n echo HASH_PASS\nelse\n echo HASH_FAIL\nfi\necho TERMINAL_STILL_ALIVE\n'
                    checked = subprocess.run([str(bash)], input=harness, text=True, capture_output=True, timeout=20,
                        env={**os.environ, "MSYS_NO_PATHCONV": "1", "MSYS2_ARG_CONV_EXCL": "*"})
                    self.assertEqual(checked.returncode, 0, checked.stderr)
                    self.assertIn("CANDIDATE_SHA256=" + digest, checked.stdout)
                    self.assertIn(marker, checked.stdout)
                    self.assertIn("TERMINAL_STILL_ALIVE", checked.stdout)

    def test_installed_bundle_tests_and_imports(self):
        payload = build_payload()
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp)
            for name in DEPENDENCIES:
                target = project / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes((PROJECT / name).read_bytes())
            installed = subprocess.run([sys.executable, "-c", INSTALLER,
                hashlib.sha256(payload).hexdigest(), str(project)],
                input=base64.b64encode(payload).decode(), text=True, capture_output=True, timeout=30)
            self.assertEqual(installed.returncode, 0, installed.stderr)
            bundle = Path(installed.stdout.strip())
            checked = subprocess.run([sys.executable, "-m", "unittest", "tests.test_latency_residual",
                "tests.test_residual_latency_candidate", "tests.test_residual_latency_validation", "-q"],
                cwd=bundle, env={**os.environ, "PYTHONPATH": str(bundle) + os.pathsep + str(PROJECT), "PYTHONNOUSERSITE": "1"},
                text=True, capture_output=True, timeout=60)
            self.assertEqual(checked.returncode, 0, checked.stdout + checked.stderr)
            self.assertIn("Ran 22 tests", checked.stderr)

    def test_bash_syntax_and_candidate_hash_gates_before_launch(self):
        script = command(build_payload())
        self.assertLess(script.index("unittest tests.test_latency_residual"), script.index("if /root/CarbonAffinity/.venv/bin/python -c"))
        self.assertLess(script.index("if /root/CarbonAffinity/.venv/bin/python -c"), script.index("nohup env"))
        self.assertIn("6e334c42c8de3bb64a41ebb594aef4785fd2ed0325230c8c9ea1c3cf33692c85", script)
        self.assertNotIn(" -m scripts.fit_residual_latency_candidate ", script)
        bash = Path("E:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path("/bin/bash")
        if not bash.exists():
            self.skipTest("bash unavailable")
        checked = subprocess.run([str(bash), "-n"], input=script, text=True, capture_output=True, timeout=20)
        self.assertEqual(checked.returncode, 0, checked.stderr)


if __name__ == "__main__":
    unittest.main()
