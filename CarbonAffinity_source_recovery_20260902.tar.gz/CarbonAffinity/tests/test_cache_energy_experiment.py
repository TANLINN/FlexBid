import copy
import itertools
import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock, patch

from carbonaffinity.models import CompletionResult
from scripts import cache_energy_experiment as experiment


def completion(cached=None):
    return {
        "success": True,
        "status_code": 200,
        "error": None,
        "prompt_tokens_reported": 1952,
        "output_tokens": 64,
        "cached_prompt_tokens_observed": cached,
        "ttft_ms": 120.0,
        "tpot_ms": 35.0,
    }


def synthetic_rows(warm_j_per_request=6.0):
    rows = []
    for gpu in experiment.GPUS:
        for case in experiment.schedule(gpu):
            row = dict(case, gpu_index=gpu, valid=True)
            per_request = 10.0 if row["mode"] == "cold" else warm_j_per_request
            row["total_energy_j"] = per_request * row["concurrency"]
            row["prime_energy_j"] = 0.0 if row["mode"] == "cold" else 12.0
            rows.append(row)
    return rows


class FakeMaterializer:
    def __init__(self):
        self.identities = {}

    def tokens(self, row):
        identity = row["request_id"]
        token = self.identities.setdefault(identity, len(self.identities) + 1)
        return [token] * row["prompt_tokens"]


class FakeClient:
    def __init__(self, failure=None, engine_log=None):
        self.primed = set()
        self.calls = []
        self.energy_mj = 1000.0
        self.failure = failure
        self.engine_log = engine_log
        self.reset_count = 0

    async def reset_prefix_cache(self):
        self.primed.clear()
        self.reset_count += 1
        if self.engine_log is not None:
            with self.engine_log.open("a", encoding="utf-8") as handle:
                handle.write("Successfully reset prefix cache\n")
        return True

    async def complete(self, request, prompt, cache_salt):
        prime = request.max_output_tokens == 1
        cached = len(prompt) // 784 * 784 if cache_salt in self.primed else None
        self.calls.append({
            "request_id": request.request_id,
            "prompt": tuple(prompt),
            "salt": cache_salt,
            "prime": prime,
        })
        self.energy_mj += 7000.0 if prime else 3000.0
        if prime:
            self.primed.add(cache_salt)
        result = CompletionResult(
            request.request_id, "gpu_0", True, 200, 1, 2, 3, 120.0, 35.0,
            request.max_output_tokens, len(prompt), cached,
        )
        if not prime and "-warm-" in request.request_id:
            if self.failure == "missing_warm_cache":
                result = replace(result, cached_prompt_tokens_observed=None)
            elif self.failure == "request_failure":
                result = replace(result, success=False, status_code=500, error="request failed")
        return result


class CacheEnergyExperimentTests(unittest.TestCase):
    def test_formal_concurrency_matches_measured_residency_frontier(self):
        self.assertEqual(experiment.CONCURRENCIES, (1, 3))

    def test_schedule_covers_design_and_counterbalances_adjacent_pairs(self):
        expected = set(itertools.product(
            experiment.CACHED, experiment.OUTPUTS,
            experiment.CONCURRENCIES, range(experiment.REPEATS),
            ("cold", "warm"),
        ))
        for gpu in experiment.GPUS:
            with self.subTest(gpu=gpu):
                cases = experiment.schedule(gpu)
                self.assertEqual(len(cases), 48)
                observed = {
                    (case["cached_context_target"], case["output_tokens"],
                     case["concurrency"], case["repeat"], case["mode"])
                    for case in cases
                }
                self.assertEqual(observed, expected)
                first_modes = {}
                for first, second in zip(cases[::2], cases[1::2]):
                    self.assertEqual(first["pair_id"], second["pair_id"])
                    self.assertEqual((first["order"], second["order"]), (0, 1))
                    self.assertEqual({first["mode"], second["mode"]}, {"cold", "warm"})
                    for case in (first, second):
                        self.assertEqual(
                            case["prompt_tokens"],
                            case["cached_context_target"] + experiment.RESIDUAL,
                        )
                    key = (first["cached_context_target"], first["output_tokens"],
                           first["concurrency"])
                    first_modes.setdefault(key, []).append(first["mode"])
                self.assertTrue(all(set(modes) == {"cold", "warm"}
                                    for modes in first_modes.values()))

    def test_counter_energy_is_converted_from_millijoules_to_joules(self):
        self.assertAlmostEqual(experiment.energy_delta(1000.0, 2250.0), 1.25)
        for before, after in (
            (1.0, 1.0), (2.0, 1.0), (float("nan"), 3.0),
            (1.0, float("nan")), (1.0, float("inf")),
            (float("-inf"), 1.0),
        ):
            with self.subTest(before=before, after=after):
                with self.assertRaises(ValueError):
                    experiment.energy_delta(before, after)

    def test_cold_cache_accepts_missing_or_zero_but_not_positive_observation(self):
        for cached in (None, 0):
            self.assertEqual(experiment.result_errors([completion(cached)], 1952, 64), [])
        self.assertTrue(experiment.result_errors([completion(784)], 1952, 64))

    def test_warm_cache_requires_exact_observed_target(self):
        self.assertEqual(
            experiment.result_errors([completion(1568)], 1952, 64, cached_target=1568),
            [],
        )
        for cached in (None, 0, 784, 1569):
            with self.subTest(cached=cached):
                self.assertTrue(experiment.result_errors(
                    [completion(cached)], 1952, 64, cached_target=1568,
                ))

    def test_result_metadata_and_latency_errors_are_reported(self):
        for key, value in (
            ("success", False), ("status_code", 500), ("error", "request failed"),
            ("prompt_tokens_reported", 1951), ("output_tokens", 63),
            ("ttft_ms", float("nan")), ("tpot_ms", -1.0),
        ):
            with self.subTest(field=key):
                record = completion()
                record[key] = value
                self.assertTrue(experiment.result_errors([record], 1952, 64))

    def test_reset_log_evidence_requires_success_without_failure(self):
        self.assertEqual(
            experiment.reset_log_evidence("Successfully reset prefix cache\n"),
            (["Successfully reset prefix cache"], True, False),
        )
        lines, success, failure = experiment.reset_log_evidence(
            "Successfully reset prefix cache\nFailed to reset prefix cache\n"
        )
        self.assertEqual(len(lines), 2)
        self.assertTrue(success)
        self.assertTrue(failure)

    def test_summary_pairs_requests_and_keeps_priming_separate(self):
        summary = experiment.summarize(synthetic_rows())
        self.assertEqual(summary["rows"], 384)
        self.assertEqual(summary["pairs"], 192)
        self.assertEqual(len(summary["groups"]), 12)
        for cached, output, concurrency in itertools.product(
            experiment.CACHED, experiment.OUTPUTS, experiment.CONCURRENCIES,
        ):
            key = f"p{cached + experiment.RESIDUAL}_o{output}_n{concurrency}"
            group = summary["groups"][key]
            self.assertEqual(group["pairs"], 16)
            self.assertAlmostEqual(group["cold_j_per_request"], 10.0)
            self.assertAlmostEqual(group["warm_j_per_request"], 6.0)
            self.assertAlmostEqual(group["paired_saving_pct"], 40.0)
            self.assertAlmostEqual(group["prime_energy_j"], 12.0)

    def test_summary_rejects_missing_or_duplicated_case(self):
        rows = synthetic_rows()
        for altered in (rows[:-1], rows[:-1] + [copy.deepcopy(rows[0])]):
            with self.assertRaises((ValueError, RuntimeError)):
                experiment.summarize(altered)

    def test_summary_rejects_invalid_rows_and_nonpositive_energy(self):
        for key, value in (("valid", False), ("total_energy_j", -1.0)):
            with self.subTest(field=key):
                rows = synthetic_rows()
                rows[0][key] = value
                with self.assertRaises((ValueError, RuntimeError)):
                    experiment.summarize(rows)

    def test_negative_measured_saving_is_not_clipped(self):
        summary = experiment.summarize(synthetic_rows(warm_j_per_request=12.0))
        for group in summary["groups"].values():
            self.assertAlmostEqual(group["paired_saving_pct"], -20.0)


class CacheEnergyCollectionTests(unittest.IsolatedAsyncioTestCase):
    async def test_single_gpu_collection_pairs_inputs_and_separates_prime_energy(self):
        with tempfile.TemporaryDirectory() as temp:
            args = SimpleNamespace(output_root=Path(temp), gpu_index=0)
            engine_log = args.output_root / "vllm_gpu_0.log"
            engine_log.touch()
            client = FakeClient(engine_log=engine_log)
            counter = Mock(side_effect=lambda: client.energy_mj)
            with patch.object(experiment.asyncio, "sleep", new_callable=AsyncMock), patch("builtins.print"):
                await experiment.collect(args, FakeMaterializer(), client, counter, engine_log)
            path = args.output_root / "raw/gpu_0/measurements.jsonl"
            rows = [json.loads(line) for line in path.read_text().splitlines()]

        self.assertEqual(len(rows), 48)
        self.assertEqual(client.reset_count, 48)
        self.assertTrue(all(row["reset"]["confirmed"] for row in rows))
        calls = {call["request_id"]: call for call in client.calls}
        measured = {(row["pair_id"], row["mode"]): row for row in rows}
        total_primes = 0
        for row in rows:
            self.assertTrue(row["valid"])
            concurrency = row["concurrency"]
            self.assertEqual(len(row["results"]), concurrency)
            self.assertAlmostEqual(row["total_energy_j"], 3.0 * concurrency)
            self.assertAlmostEqual(row["energy_per_request_j"], 3.0)
            self.assertEqual(len(set(row["cache_salts"])), concurrency)
            if row["mode"] == "cold":
                self.assertEqual(row["primes"], [])
                self.assertEqual(row["prime_energy_j"], 0.0)
                continue
            total_primes += concurrency
            self.assertEqual(len(row["primes"]), concurrency)
            self.assertAlmostEqual(row["prime_energy_j"], 7.0 * concurrency)
            cold = measured[row["pair_id"], "cold"]
            self.assertTrue(set(cold["cache_salts"]).isdisjoint(row["cache_salts"]))
            prompts = []
            for index in range(concurrency):
                cold_call = calls[f"{row['pair_id']}-cold-{index}"]
                warm_call = calls[f"{row['pair_id']}-warm-{index}"]
                prime_call = calls[f"{row['pair_id']}-prime-{index}"]
                self.assertEqual(cold_call["prompt"], warm_call["prompt"])
                self.assertEqual(prime_call["prompt"], warm_call["prompt"])
                self.assertEqual(prime_call["salt"], warm_call["salt"])
                prompts.append(warm_call["prompt"])
            self.assertEqual(len(set(prompts)), concurrency)
        self.assertEqual(sum(call["prime"] for call in client.calls), total_primes)
        self.assertEqual(counter.call_count, 2 * (48 + total_primes))

    async def test_invalid_warm_cache_or_request_is_retained_before_failure(self):
        for failure in ("missing_warm_cache", "request_failure"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as temp:
                args = SimpleNamespace(output_root=Path(temp), gpu_index=0)
                engine_log = args.output_root / "vllm_gpu_0.log"
                engine_log.touch()
                client = FakeClient(failure, engine_log)
                counter = Mock(side_effect=lambda: client.energy_mj)
                with patch.object(experiment.asyncio, "sleep", new_callable=AsyncMock), patch("builtins.print"):
                    with self.assertRaises(RuntimeError):
                        await experiment.collect(args, FakeMaterializer(), client, counter, engine_log)
                path = args.output_root / "raw/gpu_0/measurements.jsonl"
                rows = [json.loads(line) for line in path.read_text().splitlines()]
                self.assertEqual(len(rows), 2)
                self.assertTrue(rows[0]["valid"])
                self.assertEqual(rows[-1]["mode"], "warm")
                self.assertFalse(rows[-1]["valid"])
                self.assertIn("error", rows[-1])
                self.assertEqual(len(rows[-1]["results"]), rows[-1]["concurrency"])
                if failure == "missing_warm_cache":
                    self.assertTrue(all(result["cached_prompt_tokens_observed"] is None
                                        for result in rows[-1]["results"]))
                else:
                    self.assertTrue(all(result["success"] is False
                                        for result in rows[-1]["results"]))

    async def test_missing_physical_reset_evidence_is_retained_before_failure(self):
        with tempfile.TemporaryDirectory() as temp:
            args = SimpleNamespace(output_root=Path(temp), gpu_index=0)
            engine_log = args.output_root / "vllm_gpu_0.log"
            engine_log.touch()
            client = FakeClient()
            counter = Mock(side_effect=lambda: client.energy_mj)
            with patch.object(experiment.asyncio, "sleep", new_callable=AsyncMock), \
                    patch.object(experiment.time, "monotonic", side_effect=(0.0, 31.0)), \
                    patch("builtins.print"):
                with self.assertRaises(RuntimeError):
                    await experiment.collect(args, FakeMaterializer(), client, counter, engine_log)
            rows = [json.loads(line) for line in
                    (args.output_root / "raw/gpu_0/measurements.jsonl").read_text().splitlines()]
            self.assertEqual(len(rows), 1)
            self.assertFalse(rows[0]["valid"])
            self.assertFalse(rows[0]["reset"]["confirmed"])
            self.assertIn("physical prefix-cache reset", rows[0]["error"])


if __name__ == "__main__":
    unittest.main()
