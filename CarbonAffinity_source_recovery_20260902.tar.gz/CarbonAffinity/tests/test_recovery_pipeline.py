"""Synthetic full-grid pipeline tests; these are NOT benchmark results."""
import json
import tempfile
import unittest
from pathlib import Path

from carbonaffinity.artifacts import sha256, write_json
from carbonaffinity.corun_surface import fit_with_loo
from carbonaffinity.workload_experiments import cases
from scripts.validate_corun_ttft_surface import validate
from scripts.freeze_validated_model import freeze
from scripts.fit_recovered_energy_profiles import fit as fit_energy
from carbonaffinity.profile import HardwareProfile
from carbonaffinity.models import RequestSpec, RegionSnapshot


def fake_case(case, gpu, evidence):
    order = case["order"]
    p = case["background_tokens"] * case["background_count"] if order == "background_first" else 0
    d = case["background_output_tokens"] * case["background_count"] if order == "background_first" else 0
    a = case["background_output_tokens"] * case["background_count"] if order == "decode_first" else 0
    phase = {"baseline": "baseline", "background_first": "prefill_then_decode",
             "victim_first": "future_arrival_control", "decode_first": "active_decode"}[order]
    own = case["victim_prompt_tokens"] - case["victim_shared_tokens"]
    return {**case, "gpu_index": gpu, "failures": 0, "phase": phase,
            "admission_features": {"own": own, "prefill": p, "prefill_decode": d, "active_decode": a},
            "victim": {"ttft_ms": 100 + own * .01 + p * .01 + (a+d) * .1 + gpu, "success": True},
            "interferers": [{"success": True}] * case["background_count"], "warm_prime": None,
            "runtime_cap": 784, "runtime_cap_evidence": evidence}


class RecoveryPipelineTests(unittest.TestCase):
    def test_energy_profile_rebuilt_from_identifiable_measured_columns(self):
        rows = []
        for p in (2048, 8192, 32768):
            for out in (32, 128, 512):
                for mode in ("cold", "warm"):
                    cached = p if mode == "warm" else 0
                    solo = 5 + .02 * (p-cached) + .001 * cached + .05 * out
                    for load in (1, 4, 8):
                        for repeat in (0, 1):
                            rows.append({"prompt_tokens": p, "output_tokens": out, "mode": mode,
                                "concurrency": load, "repeat": repeat, "region_id": "gpu_0",
                                "results": [{"output_tokens": out}] * load, "cached_tokens": [cached] * load,
                                "dynamic_energy_per_request_j": solo / (1 + .1 * (load-1))})
        latency = {"prompt_buckets": [2048, 8192, 32768], "concurrency_buckets": [1, 4, 8],
                   "cells": {"cold|2048|1": {"ttft_ms": 100, "tpot_ms": 10}}}
        fitted = fit_energy(rows, latency, "synthetic-test-only", "synthetic-test-only")
        self.assertAlmostEqual(fitted["base_request_j"], 5)
        self.assertAlmostEqual(fitted["cold_prefill_j_per_token"], .02)
        self.assertAlmostEqual(fitted["cached_prefill_j_per_token"], .001)
        self.assertAlmostEqual(fitted["decode_j_per_token"], .05)
        self.assertEqual(HardwareProfile(**fitted).max_concurrency, 8)

    def test_full_corun_matrix_fit_validate_freeze_and_tamper(self):
        development = [fake_case(case, gpu, "synthetic") for gpu in range(8)
                       for kind in ("corun_development", "active_decode_development") for case in cases(kind)]
        self.assertEqual(len(development), 1680)
        model = fit_with_loo(development)
        self.assertEqual(model["development_evaluation"]["overall"]["out_of_domain"], 0)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            write_json(root / "candidate.json", model)
            write_json(root / "LAUNCH.json", {"synthetic_test_fixture": True, "runtime_cap": 784, "effective_cap_verified": True})
            evidence = sha256(root / "LAUNCH.json")
            rows = [fake_case(case, gpu, evidence) for gpu in range(8)
                    for kind in ("corun_validation", "active_decode_validation") for case in cases(kind)]
            with (root / "measurements.jsonl").open("w", encoding="utf-8") as handle:
                handle.write("".join(json.dumps(row) + "\n" for row in rows))
            prereg = {"candidate_sha256": sha256(root / "candidate.json"), "gpu_indices": list(range(8)),
                      "expected_rows": 672, "code_sha256": {str(Path(__file__)): sha256(__file__)},
                      "ttft_slo_ms": 16000, "minimum_coverage": .95}
            report = validate(root / "candidate.json", root, prereg)
            self.assertEqual(report["status"], "PASS", report["checks"])
            write_json(root / "report.json", report)
            freeze(root / "candidate.json", root / "report.json", root / "frozen.json")
            self.assertEqual(sha256(root / "candidate.json"), sha256(root / "frozen.json"))
            prereg["candidate_sha256"] = "incorrect"
            self.assertEqual(validate(root / "candidate.json", root, prereg)["status"], "FAIL")


if __name__ == "__main__":
    unittest.main()
