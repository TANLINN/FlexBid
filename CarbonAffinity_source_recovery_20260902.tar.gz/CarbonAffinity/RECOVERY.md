# 服务器回收后的代码恢复说明

恢复日期：2026-08-30。当前目录是恢复后的维护版本，旧目录修改前已另存为项目外的
`CarbonAffinity_before_recovery_20260830.tar.gz`。论文 LaTeX 未改动，旧实验结果没有补造。

## 1. 恢复了什么、没恢复什么

| 内容 | 当前状态 |
| --- | --- |
| 原始会话 trace、碳强度 CSV、四个规范化窗口 | 本机原文件仍在；不是从终端摘要反推的数据 |
| 多轮缓存路由、网络字节/碳成本、精确小规模 oracle | 保留本机实现并补齐接口、边界测试 |
| 联合在线规划器 | 保留增量交换，补齐固定点停止；线上入口默认 32 次、100 ms |
| 八区域实时闭环 | 重建预留、完成释放、实时 prefill/decode 状态、批内联合约束和可行拆批 |
| 五种策略 | pressure_only / cleanest_now / sticky / carbon_affinity / joint_planner，共用运行约束 |
| cap784 延迟、co-run 测量/训练/验证/冻结 | 新建可维护的 Python 流水线，不再拼接旧 shell 脚本 |
| 未来会话工作量模型 | 本机已重新训练 `profiles/recovered_future_work_candidate.json`；候选而非旧冻结模型 |
| 原 GPU 测量行、遥测 CSV、已验证延迟/能耗模型 | 未找回；必须重新跑 |
| 更早的本机 results 摘要、输入清单、schema 1 会话模型 | 原件保留；不能冒充回收前最新已冻结模型和八区域结果 |
| Qwen3.5-27B 权重 | 不在本恢复包内，需重新下载 |
| 8 月 21 日完整归档 | 尚未取得它的本地路径，未覆盖解压到当前目录 |

新代码依据本机源文件和用户提供的服务器源码/接口/日志重建，**不保证与丢失的服务器逐字节相同**。
测试里的 synthetic 数据仅验证软件逻辑，不能用于论文实验结果。

已重训未来工作量候选使用 3,429 个会话，排除了当前四个实验窗口内的 53 个完整会话；
训练会话与这 53 个会话无交集。未来如增加测试窗口，需要重新确定训练排除集。
它估计最多后续 32 轮工作量，输入仅当前已观察的 workload 和 turn；不是知道真实剩余轮数。

## 2. 重要语义与尚未解决的研究问题

- cap784 是上一台机器的试验配置，不是所有硬件的安全保证。新卡、驱动、模型版本都要记录并重新验证。
- TTFT 包含控制器等待和客户端准入等待；未来到达的请求不能用于当前路由决策。
- co-run 输入为：当前请求未缓存 prompt、正在 prefill 的初始未缓存 token 总量、这些请求的完整输出预算、正在 decode 的完整输出预算。没有按时间凭空扣减“剩余 token”。
- 内部预留与客户端状态按 request ID 取并集，不能重复相加，也不能只取一个总数的最大值而漏掉尚未发出的请求。
- 原 co-run v2 最后只到候选阶段。恢复版采用新 schema 3；active-decode 轴增加 384/896，以容纳两个 decoder 的**预算之和**。不能沿用旧模型哈希。
- 仅有纯 prefill/纯 decode 数据不能证明二者混合时安全；恢复版对未验证混合负载、超出模型域、缺失支持单元返回不可行。这可能造成等待或整次实验失败，不会静默当作安全。
- 相同总预算但不同并发形状、缓存失效、实际 continuous batching、混合负载仍需闭环验证。微基准通过不等于真实 trace 的 SLO 必然通过。
- 配置是同机八实例 + 区域碳轨迹 + 可选模拟 WAN。传输的是 prompt/历史文本及流式响应，`kv_transfer_bytes=0`。网络碳是模型估计，不是实际跨地域网络电表。
- `EXPERIMENT_COMPLETE.json` 表示采集流程完成；`AUTHORITATIVE_SLO_REPORT.json` 才回答五策略 SLO 检查。不能用单次能耗波动证明算法优于 cleanest-now；同路由结果尤其如此。
- 精确 oracle 仅对其离散模型的小规模问题精确，状态/转移超过限额会停止；不能把模型最优称为物理系统全局最优。
- 新能耗拟合输出是 development profile，仍需要独立误差审计；测量总 GPU 能耗与扣除空闲后的动态能耗应分开报告。

## 3. 本机检查

当前已建立独立的 Windows `.venv-recovery`。在本项目目录运行：

```powershell
.venv-recovery/Scripts/python.exe -m scripts.recovery_status
.venv-recovery/Scripts/python.exe -m unittest discover -s tests -v
.venv-recovery/Scripts/python.exe -m scripts.run_cpu_recovery_checks --output docs/recovery_checks_new.json
```

第三条须使用一个不存在的新报告文件名。CPU 回归包含模拟 HTTP 流、取消、原子预留、模型拟合→验证→冻结和篡改拒绝检查；没有启动真实 GPU。

## 4. 新 Linux GPU 服务器准备

先把恢复包复制到**新目录**解压，核对压缩包 SHA256 和包内 manifest，不要覆盖唯一备份。
不要把 Windows 虚拟环境复制过去。下面假定项目目录为 `/root/CarbonAffinity`、模型为 `/root/models/Qwen3.5-27B`。

```bash
cd /root/CarbonAffinity
python3 -m venv .venv
source .venv/bin/activate
export PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple
python -m pip install --upgrade pip 'setuptools==80.9.0' wheel
python -m pip install -e '.[trace]'
python -m pip install 'vllm==0.17.1' modelscope
python -m pip check
modelscope download --model Qwen/Qwen3.5-27B --local_dir /root/models/Qwen3.5-27B
python -m unittest discover -s tests -v
```

vLLM 0.17.1 是历史环境的重建起点，不保证适配新服务器。安装冲突应保留日志处理，不关闭 TLS 验证。
若缺少 `venv` 支持，需按新系统发行版安装对应 Python venv 包；若证书由平台签发，安装平台提供的 CA。
不要运行 `night_guard.py` 或 GPU 保活矩阵乘法，任何额外负载都会污染能耗和延迟。

启动器要求八张空闲 GPU，绑定 localhost:18000–18007，TP=1，cap784，max-num-seqs=8，
显存比例 0.92、上下文 65536。启动不足会留下每卡日志并退出，不会自动降低配置假装通过。
新卡放不下模型时应明确修改设计，而不是继续旧实验。

## 5. 重跑路径（每一阶段成功后再进行下一阶段）

所有 output-root 必须是新目录，不覆写失败数据。以下命令在项目根目录、虚拟环境内运行。
这些阶段不自动全部连跑：独立验证失败必须先解释原因，不能通过换阈值把同一测试集改成通过。

### A. 延迟模型

```bash
python -m scripts.run_recovery_gpu_campaign --stage latency-development --model-dir /root/models/Qwen3.5-27B --output-root results/rebuild_latency_dev_01
python -m scripts.recover_latency_surface --input-root results/rebuild_latency_dev_01/raw --output results/rebuild_latency_candidate_01.json
python -m scripts.run_recovery_gpu_campaign --stage latency-validation --model-dir /root/models/Qwen3.5-27B --candidate results/rebuild_latency_candidate_01.json --output-root results/rebuild_latency_val_01
python -m scripts.freeze_validated_model --candidate results/rebuild_latency_candidate_01.json --report results/rebuild_latency_val_01/INDEPENDENT_VALIDATION_REPORT.json --output profiles/cap784_latency_frozen.json
```

开发 800 行，独立插值验证 144 行。显式预热，不事后删除慢数据。冻结必须同时满足报告 PASS 与候选哈希一致。

### B. 能耗 profile

```bash
python -m scripts.run_recovery_gpu_campaign --stage energy-development --model-dir /root/models/Qwen3.5-27B --output-root results/rebuild_energy_dev_01
python -m scripts.fit_recovered_energy_profiles --input-root results/rebuild_energy_dev_01 --latency-model profiles/cap784_latency_frozen.json --latency-freeze-record profiles/cap784_latency_frozen.freeze.json --output-dir profiles/recovered_gpu --accelerator '填写 nvidia-smi 显示的实际 GPU 型号'
```

共 864 个 batch 测量，记录实际输出 token、缓存命中、NVML 总能量、空闲功率和动态能量。
只有四个系数可辨识、八卡数据完整时才创建 profile；该步骤不是独立能耗验证。

### C. co-run TTFT 候选与独立验证

```bash
python -m scripts.run_recovery_gpu_campaign --stage corun-development --model-dir /root/models/Qwen3.5-27B --output-root results/rebuild_corun_dev_01
python -m scripts.fit_corun_ttft_surface --input-roots results/rebuild_corun_dev_01 --output results/rebuild_corun_candidate_01.json
python -m scripts.run_recovery_gpu_campaign --stage corun-validation --model-dir /root/models/Qwen3.5-27B --candidate results/rebuild_corun_candidate_01.json --output-root results/rebuild_corun_val_01
python -m scripts.freeze_validated_model --candidate results/rebuild_corun_candidate_01.json --report results/rebuild_corun_val_01/INDEPENDENT_VALIDATION_REPORT.json --output profiles/corun_ttft_frozen.json
```

开发 1,680 行，恢复版独立验证 672 行，参数/代码/候选在启动前记录。新的验证设计不是丢失的旧验证数据。
若出现超域或混合负载导致失败，保留失败；不能把真实情况筛掉来声称 100% 覆盖。
旧 prefill-backlog 单独测量仍可用 `--stage backlog-development/backlog-validation`，但它不能替代 co-run 模型。

### D. 生成配置，运行五策略闭环

```bash
python -m scripts.prepare_recovered_inputs --tokenizer /root/models/Qwen3.5-27B --profile-dir profiles/recovered_gpu --repetitions 5
python -m scripts.run_recovery_gpu_campaign --stage five-policy --model-dir /root/models/Qwen3.5-27B --config configs/recovered_w01_r00.yaml --future-work-model profiles/recovered_future_work_candidate.json --corun-model profiles/corun_ttft_frozen.json --corun-freeze-record profiles/corun_ttft_frozen.freeze.json --max-requests 32 --seed 20260830 --output-root results/rebuild_five_policy_gate_01
```

先做 32 请求调试，再固定代码做完整窗口、多次策略顺序随机化及 GPU 映射轮换。
四窗口相同 repeat 的 request 数可以不同；不能把不同窗口凑成相同样本数。
生成器默认**网络关闭**，不是悄悄沿用丢失的网络模型。重新拟合网络字节模型后可用 `--network-model` 生成新的配置设计；
WAN 延迟/带宽/每 GB 能量是实验假设，需做敏感性分析。旧生成配置存在时生成器拒绝覆盖。
新网络字节拟合入口：`python -m scripts.fit_network_byte_model --requests .../requests.jsonl --output results/new_network_candidate.json`。
字节统计始终记录；使用不同窗口独立验证后才能把该候选用于正式报告。

逻辑区域的 `site_manifest` 字段不应被填成真实八个数据中心。实际 GPU/启动环境保存在 `LAUNCH.json`。
需要单卡清单时用 `scripts/collect_site_manifest.py`，明确标记同机模拟和真实 GPU UUID。

### E. CPU 优化器规模/预算实验

生成 D 中配置且 profile 就绪后：

```bash
python -m scripts.run_joint_planner_sweep --output-root results/rebuild_cpu_sweep_01 --config-pattern 'configs/recovered_w{window:02d}_r00.yaml' --max-price-iterations 32
```

此入口保留 `none` / `trace_horizon` 两组研究对照，后者明确使用未来 trace，不能标作可部署在线算法。
真实闭环使用 `learned_future`。CPU sweep 记录求解器返回状态、状态上限、规划时间和目标函数，
不消耗 GPU，也不生成“实测节碳”结果。改变代码或模型后必须使用新 output-root，不能续用旧案例。

## 6. 后台运行、进度和停止

下面以 co-run 开发为例。先确认没有同阶段或其他 GPU 实验在运行，再执行一次：

```bash
cd /root/CarbonAffinity
source .venv/bin/activate
RUN="results/corun_rebuild_$(date -u +%Y%m%dT%H%M%SZ)"
nohup .venv/bin/python -u -m scripts.run_recovery_gpu_campaign --stage corun-development --model-dir /root/models/Qwen3.5-27B --output-root "$RUN" > "${RUN}.launcher.log" 2>&1 < /dev/null &
RUN_PID=$!
echo "PID=$RUN_PID ROOT=$RUN"
watch -n 20 ".venv/bin/python -m scripts.recovery_status --root '$RUN'"
```

`Ctrl+C` 只退出 watch。需要停止时用该次启动输出的明确 PID，先核对 `ps -p PID -o pid,cmd`，再 `kill -TERM PID`。
启动器只清理自己启动的进程组，不会按宽泛 `pkill -f` 杀掉用户终端。
`healthy=0` 可能是采集完成后的主动清理；以完成/失败标记和行数共同判断。

### 延迟异常的定点复测（不是独立验证）

`scripts/run_latency_pause_probe.sh` 用于排查恢复版首次延迟验证中 GPU 6/7
在相近时刻出现的响应停顿。它只启动 GPU 0/6/7，保持 cap784，固定
prompt=12288、concurrency=3、output=64，冷/热各五次，共 30 条 batch 数据。
采集 GPU 频率/功率/利用率；系统有 vmstat 时同时采集 CPU 状态。
启动前检查 GPU 和端口空闲、主要测量代码与原失败验证一致；仅清理自有进程组。

```bash
bash scripts/run_latency_pause_probe.sh /root/CarbonAffinity/results/latency_pause_probe_unique_run
```

输出目录必须不存在。原失败验证路径固定在脚本中，迁移数据时需明确修改来源。
必须从已保存的文件启动，不支持 `nohup bash -s` 直接解释长 heredoc。
如果终端长粘贴丢字符，Windows 上运行
`scripts/copy_latency_probe_short_steps.ps1`。它每次复制一条短命令到剪贴板：
在服务器粘贴，确认对应的成功标记，再返回本地按 Enter；失败输入 r 重试该步。
分块分别校验 SHA256，完整重组后再次核对 UTF-8/LF 源码 SHA256；缺块、损坏、
已有内容冲突均停止。最后才复制启动命令，核对完整哈希和 Bash 语法后，使用
`nohup bash 文件路径 ... < /dev/null` 启动。脚本源副本和哈希保存在本次结果中。
旧的 `copy_latency_pause_probe_command.ps1` 生成长命令，不适合已出现丢字符的终端。
`DIAGNOSTIC_SUMMARY.json` 保留所有重复和慢测量；完成标记只表示诊断采集完整。
三卡、新进程、固定请求序列不同于原八卡验证：未复现不能证明异常消失，
更不能替代缓存尾部建模或改变原验证 FAIL。本机新增脚本和测试未启动实际 GPU。

#### 首次形状自动调优的固定预热诊断

用户提供的 autotune 复测中，GPU 0/6/7 的 `chunk_fwd_kernel_o`、key 第四项 32
分别在 warm repeat 1/2/1 调优约 4.24–4.25 秒，对应三个约 4.83 秒的慢批次。
该证据来自服务器粘贴日志，本机没有对应原始文件副本，不能据此声称所有旧异常均已解释。

本机运行以下命令，将完整安装、校验、启动指令一次复制到剪贴板；到服务器粘贴一次即可，
不需要手动确认 24 个步骤。分块由命令自动处理，失败只退出安装子 shell，保留交互终端。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\Desktop\Idea2\CarbonAffinity\scripts\copy_latency_probe_short_steps.ps1" -ShapeWarmup -SinglePaste
```

`-PrintOnly -SinglePaste` 只打印整段指令，不访问剪贴板或启动服务器。
不加 `-SinglePaste` 的逐块手动模式仅作为终端确实无法完整接收长粘贴时的备用方式。

`copy_latency_probe_short_steps.ps1 -ShapeWarmup` 生成独立诊断启动器，
不修改原测量器、原诊断启动器、vLLM 安装、模型或失败结果。通过同一个服务进程，
对每卡依次发送 16/32/64/2048-token 冷请求，各固定两遍、每次输出 64 tokens。
每请求使用独立 cache salt；记录所有预热结果，要求实际输入/输出数正确。
2026-08-30 的首轮 shape 预热在输入 16、输出 64、HTTP 200 时收到缓存读数 null，
被原来的零命中断言拦截。首次修订只允许短请求缺失读数，但随后三卡的 2048-token
请求也都成功而返回 null，因此该长度限制没有依据。核对
[vLLM v0.17.1 流式返回源码](https://github.com/vllm-project/vllm/blob/v0.17.1/vllm/entrypoints/openai/completion/serving.py)
发现缓存详情依赖 `enable_prompt_tokens_details and num_cached_tokens`，零命中时会省略。
当前修订统一允许固定 **诊断预热**计划中缺失缓存读数，原始 null 保留为未知，
不填成 0，也不声称实测零命中；实际正命中仍失败。预热是否覆盖目标形状必须由调优日志验证，
不是由缓存字段推断。策略写入新运行的预注册和预热报告，不修改旧失败记录。
正式 30 条测量的缓存检查和 BT 形状覆盖检查不变。预热失败报告包含实际字段与失败检查项，
等待其余 GPU 的有界预热任务结束、保存结果后再报告整体失败。
预热后清空前缀缓存，并要求日志里出现诊断所涉 dtype 家族的 BT=16/32/64 三种调优键。
覆盖不到则停止，不自动重试、不调整调优结果缓存。

随后执行原来的 30 条诊断采集。`SHAPE_PREWARM_EFFECT_REPORT.json` 要求日志前缀未改动、
预热后无新增调优、样本完整且没有 TTFT>=2000ms 的诊断尖峰。2000ms 是定位秒级停顿的
预先固定阈值，不是服务 SLO。任何失败都保留原始数据和失败报告；只有审计通过才写完成标记。
该三卡诊断通过也不能代替新的八卡开发/独立验证，缓存残余 token 的模型问题仍需单独处理。
预热记录使用 `prewarm/*.json`，不混入 `raw/*/measurements.jsonl`。

### 八卡残余 token 延迟开发采样（新的独立入口）

三卡固定预热诊断通过后，下一步使用 `run_latency_residual_campaign.py`。
这不是重跑旧的验证，也不拟合或冻结模型。旧验证的 FAIL 保持不变。
目标是把缓存上下文、实际未缓存尾部和并发数分开记录，替代仅凭 cold/warm
标签或统一 90% 命中率近似完整缓存的测量设计。

开发设计在采样前写入 PREREGISTRATION：8 卡；缓存上下文目标
1568/7840/31360；残余目标 32/384/768；并发 1/4/8；冷/热两种模式；
各重复两次；输出 64。共 864 个批次，每卡 108 个，不包括预热与 prime 请求。
784 的缓存块假设需由引擎日志及每个热请求的实际缓存读数共同核验。
热请求必须实测缓存数等于目标，并记录 `prompt_tokens_reported - cached_tokens`；
缺失读数不能冒充 0 或完整命中。冷请求使用独立 namespace，缺失读数保留为 null。
该开发范围仅覆盖同质同步批次，不证明混合到达、所有输出长度或服务 SLO。

本机 PowerShell 执行一次，然后到服务器粘贴一次：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\Desktop\Idea2\CarbonAffinity\scripts\copy_latency_residual_command.ps1"
```

命令先校验压缩传输内容、服务器核心文件的 LF 内容哈希，再把代码放进全新的
`results/residual_latency_transfer_<hash>/`，不覆盖服务器 scripts、核心代码或模型。
自检从该独立目录运行，避免旧 scripts 包遮蔽新代码。损坏或版本不一致会停止，
不能跳过哈希继续。自检通过才后台启动，并打印本次 `RUN` 路径。
`-PrintOnly` 仅输出指令，不访问剪贴板或启动实验。

```bash
cd /root/CarbonAffinity
watch -n 20 "/root/CarbonAffinity/.venv/bin/python -m scripts.recovery_status --root '$RUN'"
```

八卡均通过固定形状预热后才开始采样。预热失败不会启动采样；采样的坏请求先保存再报错。
预热后新增自动调优事件使开发审计失败，原始慢测量仍保留。审计核对完整案例矩阵、
请求字段、实测缓存残余、运行参数、源代码哈希及日志边界；只有通过才写完成标记。
若采样提前失败，读取 `$RUN/FATAL.json`、`${RUN}.launcher.log` 及对应 worker 日志。
完成后读取 `$RUN/RESIDUAL_DEVELOPMENT_AUDIT.json`。其中 PASS 只表示开发数据完整性
和预热条件通过，不表示延迟模型、八卡 SLO 或算法收益已验证；下一步还需独立的拟合与验证。
不要同时运行 GPU 保活负载或其他实验。备份整个 RUN 和对应 transfer 目录到本机。

#### 从 864 批次开发数据拟合残余 token 候选（CPU-only）

开发汇总显示同一缓存上下文、同一并发下，残余 token 数会显著改变 warm TTFT/TPOT。
新候选因此把 cold 的 `(总输入 tokens, 并发)` 与 warm 的
`(实际缓存 tokens, 实际未缓存 tokens, 并发)` 分开。只使用已审计开发原始数据；
不读取先前失败验证数据，不根据粘贴的舍入统计拟合，不安装进运行时。

当前方法是每格 batch-max 的最大值，加逐坐标单调上界；格间查询取各轴向上的锚点，
不做线性混合。边界以外（包括 warm 未缓存量大于 768、不同输出长度、并发大于 8）
显式返回域外，不能把未知缓存当作完全热缓存，也不保证该上界在新负载下成立。
该方法是在观察开发汇总后选择的，FIT_RECORD 如实记录，不称为开发采样前预注册。

8 个留一卡折中，每折只用其余 7 卡建表，报告未加余量时的覆盖率与最大正残差；
最终分别对 cold/warm 的 TTFT/TPOT 取所有折的最大正残差作余量，向上舍入到 .001 ms。
这是从开发集选择的余量，不是统计置信界；不能把加了该余量后的留一卡成绩再当成
独立验证。最终开发集覆盖率按最大值构造应为 100%，只用于实现自检。
目标 TPOT 是每请求平均 token 延迟的批次最大值，不是最大单 token 停顿。

本机运行以下命令，再到服务器一次粘贴：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\Desktop\Idea2\CarbonAffinity\scripts\copy_latency_residual_fit_command.ps1"
```

默认输入是已完成的 `/root/CarbonAffinity/results/latency_residual_dev_20260830T082216Z`；
需要其他结果时显式传 `-InputRoot '/root/CarbonAffinity/results/...'`。
安装包在独立 transfer 目录自检，通过后前台执行短 CPU 拟合，不调用 vLLM、不启动 GPU。
拟合前再次审计原始矩阵和日志，拟合前后对源文件核验 SHA256；输出必须为全新目录，
且不在原始数据目录内。不覆盖旧候选或写 profiles。

终端变量 `FIT` 指向新目录，其中保存：

- `FIT_RECORD.json`：方法选择、源数据/日志/代码哈希。
- `residual_latency_candidate_v1.json`：54 个模型格、余量与域外规则。
- `RESIDUAL_CANDIDATE_AUDIT.json`：逐折未加余量诊断、训练集回代结果、候选哈希。
- `FIT_COMPLETE.json`：拟合完成，明确 `model_validated=false`、`candidate_frozen=false`。

下一步必须在不改变候选字节的前提下，另行固定独立验证设计与门槛并采集新数据。
模型未验证前不得把训练覆盖率、候选生成成功或单调性等同于系统 SLO/碳收益。

#### 锁定候选后的八卡独立验证

当前验证绑定用户提供的候选原始 SHA256：
`6e334c42c8de3bb64a41ebb594aef4785fd2ed0325230c8c9ea1c3cf33692c85`，
来源目录是 `latency_residual_candidate_20260830T093035635670917Z`。
默认不允许自动换成另一个 latest 候选。启动器先核对候选和拟合记录的哈希、
估计器/开发协议源码与拟合时的一致性；候选原样复制到新验证目录，不修改原文件。

验证矩阵：缓存上下文 3920/15680/23520，残余 128/256/640，并发 2/3/6，
cold/warm 各一次，8 卡共 432 批次、每卡 54 批次。所有这几类坐标及总输入长度
均不同于本轮开发锚点。仍是同一硬件上的同质同步批次、输出 64、cap784，
不代表新硬件泛化、混合负载、实际业务所有状态或 SLO 已验证。

测量前生成 `PREREGISTRATION.json`、`CANDIDATE_LOCKED.json` 和
`PREDICTIONS_BEFORE_MEASUREMENT.json`。预先固定的通过要求是完整矩阵、
所有请求和实测缓存检查通过、模型/预测/代码不变、八卡预热通过且测量期无新增调优。
预测覆盖率对每个 cold/warm × TTFT/TPOT 分组总体至少 95%，每卡同类分组也至少 95%。
每卡每组 27 批次，因此允许最多一个未覆盖批次；两个即失败。逐格覆盖率另行报告，
不增加事后门槛。覆盖对象是批内最大请求 TTFT、批内最大请求平均 TPOT，
不是每个 token 的停顿上界；此轮不要求实际 TTFT/TPOT 的服务 SLO 违规数为零。
报告同时包含 actual/prediction、prediction/actual，避免只看覆盖率而忽略过度保守。

本机执行，再到服务器一次粘贴：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\Desktop\Idea2\CarbonAffinity\scripts\copy_latency_residual_validation_command.ps1"
```

自检和候选哈希核对通过才后台提交任务，新目录保存在终端变量 `VAL`。
源码包保存在新的不可覆盖 transfer 目录；已有开发数据、拟合候选、失败验证和核心代码保留。
不要同时运行保活负载。用以下指令看进度：

```bash
cd /root/CarbonAffinity
watch -n 20 "/root/CarbonAffinity/.venv/bin/python -m scripts.recovery_status --root '$VAL'"
```

判定以 `RESIDUAL_INDEPENDENT_VALIDATION_REPORT.json` 为准；失败会保留该报告
（若在启动/采样阶段失败则查看 `FATAL.json` 和 worker 日志），不重拟合或放宽门槛。
通过才写 `EXPERIMENT_COMPLETE.json`，仍不自动冻结候选或替换运行时模型。

### 当前进度与下一步（2026-08-30，用户粘贴的服务器报告）

`latency_residual_independent_validation_20260830T095245947041743Z` 报告 PASS，
432 批次、8 GPU，四组指标及逐 GPU 覆盖率均为 100%，完整性错误和测量期新增 autotuning 为零。
候选 SHA256 为 `6e334c42c8de3bb64a41ebb594aef4785fd2ed0325230c8c9ea1c3cf33692c85`。
这是用户提供的输出，本机没有取回对应原始结果；外部冻结命令的执行结果尚未核实。
冷/热 TTFT 的 prediction/actual 比值中位数分别为 2.439/2.545，保守性不可忽略。
不能把此数据用于缩小裕量后再宣称同一轮独立验证通过。

旧运行时 `latency_surface.py` 的冷热比例混合接口不能直接消费这个残余模型；
旧 co-run 测量器也没有记录实际缓存数。下一步先使用独立的
`scripts/corun_observable_pilot.py` 做 192 案例开发小试验，不替换原 profile 或核心代码。
它复用已验证的残余实验启动器、八卡固定形状预热、cap784、日志边界检查和自有进程清理。

每 GPU 为 3 种 victim（冷4096、冷16384、热16064且实测缓存15680）×8 种场景：
baseline、一个/两个 prefill、一个/两个 decode、晚到的一个/两个请求、一个prefill加一个decode。
背景输入16384、完整输出预算192，victim输出64，晚到间隔250ms，各格一次。
入场特征直接来自请求提交前的客户端实时快照，包含 ID、初始 prefill 预算和完整输出预算；
不是服务引擎进度，也不使用事后实际输出长度或按时间衰减的“剩余量”。
热请求在原始完成结果中必须验证缓存数；冷请求独立 namespace，null 仍为未知。
目标状态未观测到或请求失败会保留诊断行并停止，不补造或重标状态。

本轮 PASS 仅表示采样完整性和预热准备通过。16000ms 的 TTFT 超限数仅描述性报告，
不是本轮通过门槛，也没有使用残余模型为混合负载作已经验证的预测。
混合数据与纯阶段数据分开标注，不能无验证地相加拟合。

用户现在选择暂缓把服务器结果备份到本机，并要求直接服务器粘贴或手动复制文件。
新交付为 `output/observable_corun_pilot_server.txt`，直接全选复制到服务器终端，
不需要在本机运行 PowerShell，不使用 base64。命令先校验原 bundle 与新源码，
放到新的 `results/observable_corun_transfer_<hash>/`，自检通过才提交任务。
这只是交付新代码，不会同步或备份服务器数据。

#### 并发小试验第4条 decode1 的检查器修订

用户报告 `observable_corun_pilot_20260830T104215630418406Z` 各 GPU 4 行后退出。
本机核对发现原检查器错误要求 decode 条目仍携带16384个未完成prefill token；
真实 `RegionClient` 在首token处将该数清零，但保留192个完整输出预算。
原 FakeClient 没有清零，导致合成测试错误通过。这不是需要修改模型或放宽SLO的问题。
修订检查器及模拟客户端，并加入真实流解析器的 MockTransport 回归，直接观察
prefill→decode→完成释放，避免只依赖重复实现的fake状态。
模拟背景阶段改用事件同步等待受测请求入场，避免毫秒级sleep导致测试自身偶发竞态；
真实采样器的阶段检查和超时条件不变。
新命令首先只读核对旧结果8张卡第4条均为 `cold_small_decode1`，唯一失败项是
`live_identity_and_budgets`，快照恰好为decode/0/192。只有匹配才安装新独立源码目录、
自检并提交新的192例实验；不同错误则停下显示诊断，不修改或续写失败数据。
旧命令和旧32行记录保留；该阶段曾交付 `output/observable_corun_pilot_decode_fix_v2_server.txt`。
后续第五条失败见下，以上旧命令不再是当前启动入口。

#### 并发小试验第5条 decode2：阶段构造失败与V2设计

用户报告 `observable_corun_pilot_20260830T110355466618931Z` 各GPU5行。
全部卡的 `cold_small_decode2` 在获得双decode状态前已有背景完成；GPU0背景0正常
完成16384输入/192输出，背景1由失败清理取消，没有victim入场快照。
这确认V1双冷背景未成功构造所需状态，不证明具体引擎调度原因，也不是SLO或GPU硬件失败。

V2 (`observable-corun-development-pilot-v2`) 明确改变开发场景，不续写或重标V1失败数据：

- decode1/2的背景及mixed中的decode背景先逐条prime16064输入，之后要求实际缓存15680、
  残余384、完整输出192；每条背景使用独立salt，prime与测量使用同一prompt及salt。
- prefill1/2、future1/2以及mixed中的prefill背景保持冷16384输入/192输出。
- 每种victim类型先跑decode2、mixed，再跑其余6种场景；仍为24例/卡、8卡192例。
- prime成功不等于命中成功：测量响应中的实际缓存必须匹配，入场live snapshot必须匹配
  阶段和完整预算；不按时间衰减，不将完成请求重新标为decode，不延长输出预算。
- 若阶段构造失败，保存 `phase_failure`（最后快照、期望/实际阶段、任务完成状态）和
  `snapshot_before_cleanup`；不再用schema错误遮盖主因，不创建不存在的victim结果。
- 不改模型/核心RegionClient/SLO，不拟合，不作碳收益声明。prime成本不包含在victim指标内；
  整体遥测包含准备工作，不能把本微基准作为策略能耗对比。

当前复制入口：`output/observable_corun_pilot_v2_primed_decode_server.txt`。
命令先只读核对上述40条失败数据，再安装独立源码目录、执行CPU自检并提交新结果目录。
本地15项回归通过（其中包含安装后整套20项自检）；双背景真实流解析使用MockTransport，
不是实际vLLM验证。V2是否成功构造真实双decode状态，必须以新GPU结果为准。

#### V2已通过：下一轮正式开发矩阵

用户报告 `observable_corun_pilot_v2_20260830T120214747291107Z` 完成192例、
每卡24例，审计PASS，失败案例及预热后新增autotuning均为零；未取回服务器原始数据。
其中48例TTFT超过描述性16000ms阈值，不能将数据完整性PASS当作服务SLO通过。
冷/热及mixed的差异表明应分别建模，也不能直接把纯prefill与纯decode时延相加。

正式开发入口为 `scripts/corun_observable_development.py`，协议
`observable-corun-factorial-development-v1`。矩阵预先固定为：

- 6类victim：冷4096/16384输入；热缓存C=1568/31360与残余U=32/768的四种组合，输出均64。
- 每类23格：单/双decode的64/192输出；mixed中8192/16384冷prefill与两个阶段各64/192输出；
  baseline；单/双prefill的8192/16384输入和64/192输出；两种晚到对照。
- 每格重复两次，第二次全序倒置；8卡共2208例、276例/卡。192条晚到对照保留但不充当未来模型输入。
- decode背景仍先prime16064输入，要求测量中实际缓存15680、残余384；不延长输出以制造重叠，
  不将完成请求重标为decode。短预算双decode最先执行，阶段构造失败就保留证据并停止。
- 边界为最多两个背景请求（mixed为一个prefill加一个decode），不是所有并发或任意负载形状。
  冷输入8192/12288、热C=7840/23520与U=256/512、背景prefill12288及输出128留给后续验证设计。

新的矩阵通过可选protocol参数复用V2采样流程；当前源码增加了参数接口，不能声称与旧源码字节相同。
不修改旧transfer目录、核心RegionClient、既有候选或原始结果。启动前对刚通过的192例做只读再审计，
将前置证据哈希记录在新目录；正式审计要求原始顺序、案例集合、缓存/阶段/预算、代码及旧证据均未改变。
本轮只采开发数据，不拟合、不冻结、不验证模型，不作SLO或碳收益声明。

当前复制入口：`output/observable_corun_development_v1_server.txt`。
全选复制到服务器终端即可；安装到新的不可覆盖bundle，26项CPU自检通过才提交GPU任务。
本地另外两项传输测试覆盖文本/哈希、Python3.10/Bash语法、安装幂等性及安装后全部26项自检。
合成测试覆盖完整矩阵及审计失败保护，不替代实际GPU实验。

8卡并行，按已测时延粗估约1–2小时，实际以进度为准。不要并行运行GPU保活或其他测量。
新结果目录保存在服务器终端变量 `DEV`：

```bash
watch -n 20 "/root/CarbonAffinity/.venv/bin/python -m scripts.recovery_status --root '$DEV'"
```

结束后查看 `$DEV/OBSERVABLE_CORUN_DEVELOPMENT_AUDIT.json`；启动失败查看
`${DEV}.launcher.log` 和 `$DEV/FATAL.json`。旧实验报告和失败记录保持原样。

#### 正式开发采样通过与CPU候选拟合

用户报告 `observable_corun_development_v1_20260830T123817997849695Z` 完成2208例，
13项检查通过、失败案例零、每卡276例。描述性TTFT>16000ms共288例，晚到对照192例。
`model_fitted=False`、`candidate_frozen=False`，没有FATAL。本机只收到摘要，没有取回原始数据。

下一步入口为 `output/observable_corun_candidate_v1_server.txt`，全选复制到Linux服务器执行，
无需PowerShell/base64、不启动GPU。使用原开发bundle的已校验源码，增添独立拟合模块到新目录；
不覆盖采样源码、旧模型、旧结果。37项合成CPU自检通过后，只读重新审计上述开发目录，
再拟合到新的 `results/observable_corun_candidate_v1_<timestamp>/`，终端变量为 `FIT`。

候选由 `scripts/observable_corun_candidate.py` 和 `scripts/fit_observable_corun_candidate.py` 实现：

- 2016条用于拟合、192条晚到对照仅用于诊断；126格，每格8卡×2重复=16条。
- 冷/热及精确prefill/decode数量分层，共12层；mixed直接学习，不与纯阶段时延相加。
- 自身长度与缓存保留量、背景初始prefill预算与完整输出预算均来自提交前记录和实时快照。
  不读事后实际输出、实际缓存、完成时刻或未来背景作为预测特征；实际缓存仍由原采样审计验证。
- 每格取最大值并构造坐标单调上包络，中间坐标向上选锚点，范围外返回OOD，不悄悄截断。
  每次留出一张GPU拟合，使用开发集8折最大正残差确定分冷/热、分指标裕量，向上取整到0.001ms。
- 训练覆盖率100%是构造所致，不是新验证。裕量使用了全部开发折，留一卡数字不能再算独立验证。
  报告同时输出预测/实际比值、分层及重复差异，避免仅用高覆盖掩盖过度保守。
- 晚到对照不进入模型单元、裕量或候选通过门槛；其诊断超限原样报告，不能据此宣称连续到达负载已验证。
- 使用范围仍是最多两个背景、同阶段预算同质、decode背景已prime16064且缓存保留15680、
  victim输出64和cap784。任意背景年龄、不同decoder上下文、异质同阶段负载不在已测范围内。
- 预测TPOT是每请求平均TPOT，不是最大token停顿。冷缓存null仍为未知；warm保留量不能凭空假定。

拟合前后校验开发记录、源码和前置小试验证据哈希；变更则保留FATAL并拒绝产出候选。
输出候选始终 `candidate_frozen=False`、`independent_validation_passed=False`，不安装到路由器。
独立验证必须在候选和规则固定之后另起新数据。此前预留的中间坐标本轮不读取、不采集。

终端仅打印约30行，完整报告保存在 `$FIT/OBSERVABLE_CORUN_CANDIDATE_AUDIT.json`。
本地11项拟合测试覆盖对照污染不影响模型、真实留出GPU、拒绝OOD、输入不读事后字段、
源码/数据变更拒绝及不覆盖旧文件；另有两项传输测试核验Python3.10/Bash语法及安装后全部自检。
这些是合成CPU测试，不表示本机已拟合用户服务器数据，也不表示GPU泛化验证通过。

#### 候选拟合已完成：预留坐标独立验证

用户报告CPU拟合完成，候选为
`results/observable_corun_candidate_v1_20260830T143453639470198Z/observable_corun_candidate_v1.json`，
SHA256=`dc4aef7156118107a0c3e90b409d90d4c9b468138aa69039bae2498305b4d84b`。
冷TTFT/TPOT裕量37.935/1.363ms，热37.713/1.386ms。训练TTFT预测/实际中位数1.007/1.014，
这是锚点重代入结果，不能推断中间坐标同样紧。晚到对照TPOT覆盖率冷62.50%、热84.38%，
最大正残差0.202/0.177ms；这些失败诊断保留，不加到裕量里，也不宣称连续到达TPOT已验证。
原候选仍未冻结、未独立验证。本机只收到摘要，未取回模型/实验数据。

新协议 `observable-corun-independent-validation-v1` 由
`scripts/validate_observable_corun_candidate.py` 实现，不修改采样器或候选估计器：

- 冷输入8192/12288；热C=7840/23520×U=256/512；victim输出64。
- 每类8场景：baseline、单/双prefill、单/双decode、mixed、晚到单/双背景。
  冷prefill背景12288输入、128输出；decode背景仍prime16064并实际缓存15680，输出128。
- 各格两次，第二次全序倒置；8卡768例、每卡96例。其中576例主要验证、192例晚到对照。
- 在启动任何GPU服务之前核验候选SHA、FIT记录、开发/代码证据，原字节复制为
  `LOCKED_CANDIDATE.json`，全部96个case的预测保存到 `PREDICTIONS_BEFORE_MEASUREMENT.json`。
  `PREVALIDATION_LOCK.json` 及PREREGISTRATION记录哈希，不使用测量结果调整预测。
- 主要TTFT/平均TPOT覆盖率：每个冷/热指标总体、每卡冷/热指标、每个冷/热与阶段数量分组
  均须>=95%；主要TTFT在16000ms分类阈值下的漏报须为零。该分类检查不是服务SLO保证。
- 所有768条均须满足原始请求、真实缓存、阶段、顺序和预算完整性、代码/证据未变及预热后无新增调优。
  只要主要组失败，即使汇总覆盖率通过也判FAIL。失败不补跑替换、不重拟合、不改裕量。
- 晚到对照单独完整报告，不进入主要覆盖率通过条件；`continuous_arrival_tpot_validated=False`
  始终明确保留。PASS仅为有界入场状态下的主要验证；不是任意未来流量、背景年龄或最大token停顿验证。
- 此独立性指新运行和未参与训练的负载坐标，仍使用同8张GPU，不是新硬件泛化验证。
- 原候选文件、profiles和路由器均不写入；即使验证PASS，也不自动冻结或安装模型。

启动入口：`output/observable_corun_validation_v1_server.txt`，全选直接粘贴服务器。
先运行44项合成自检，再提交新实验；原fit bundle SHA保持不变。预计30–60分钟，仅供进度参考。

```bash
watch -n 20 "/root/CarbonAffinity/.venv/bin/python -m scripts.recovery_status --root '$VAL'"
```

完成后复制 `output/observable_corun_validation_v1_summary.txt` 的短指令回传摘要。
完整报告为 `$VAL/OBSERVABLE_CORUN_INDEPENDENT_VALIDATION_REPORT.json`；失败报告/FATAL保留。
本地7项验证回归覆盖候选锁定、完整768例模拟、分卡/分层失败、阈值漏报、对照诊断及篡改保护，
另有两项传输/短摘要测试（含安装后全部44项自检）。CPU回归不能替代本轮实际GPU结果。

## 7. 保存方式

- 源码、模型、配置、原始测量分开保留；每次实验保存代码和参数哈希。
- 每完成一阶段，把原始 `measurements.jsonl`、遥测、LAUNCH、PREREGISTRATION、候选和报告复制回本机。
- 验证成功的模型文件保持原始字节不变，冻结声明另存 `.freeze.json`，因此内部 candidate 字段可能仍为 false/候选。
- `.freeze.json` 的验证报告路径是生成时路径；迁移机器后应在明确核验哈希后重新生成本机外部冻结记录，不修改模型字节。
- 不依赖计算服务器的保活避免回收。备份必须至少有一份位于独立存储/本机，且实际做过 SHA 校验。

重新打包源码及现存数据：

```bash
python -m scripts.create_recovery_bundle --include-data --include-results --output ../CarbonAffinity_recovered_new.tar.gz
```

包内 `RECOVERY_BUNDLE_MANIFEST.json` 逐文件记录 SHA256；`--include-results` 会保留现存 results。
不包含外部大模型权重或虚拟环境。实验 results 必须完整备份，不能只复制 summary。
此次恢复包同时包含现存 data 和 results，并附压缩包校验文件；其中没有新产生的 GPU 实验结果。
