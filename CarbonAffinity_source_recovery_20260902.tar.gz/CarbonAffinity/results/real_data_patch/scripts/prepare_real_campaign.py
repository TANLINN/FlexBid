from __future__ import annotations

import argparse
import csv
import gzip
import json
import math
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import yaml


ROOT = Path(__file__).resolve().parents[1]
SYNTHETIC_START = datetime(2026, 1, 1, tzinfo=timezone.utc)
G_PER_KWH_TO_LB_PER_MWH = 2.2046226218487757
PAIR_LAYOUT = (
    (0, 1, 18000, 18001, "local_region_a", "local_region_b"),
    (2, 3, 18002, 18003, "high_reuse_a", "high_reuse_b"),
    (4, 5, 18004, 18005, "low_reuse_a", "low_reuse_b"),
    (6, 7, 18006, 18007, "burst_a", "burst_b"),
)


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def first_event_time(row: dict) -> Optional[datetime]:
    values = [
        event.get("timestamp")
        for event in row.get("timing_events", [])
        if event.get("timestamp")
    ]
    return parse_time(min(values)) if values else None


def finite_sample_quantile(values: list[float], coverage: float) -> float:
    ordered = sorted(values)
    rank = min(len(ordered) - 1, math.ceil((len(ordered) + 1) * coverage) - 1)
    return ordered[max(0, rank)]


def load_neso(path: Path) -> tuple[list[datetime], dict[datetime, tuple[float, float]]]:
    values: dict[datetime, tuple[float, float]] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            try:
                timestamp = parse_time(row["datetime"] + "Z")
                values[timestamp] = (float(row["North Scotland"]), float(row["London"]))
            except (KeyError, TypeError, ValueError):
                continue
    timestamps = sorted(values)
    if len(timestamps) < 3:
        raise RuntimeError("NESO trace has fewer than three usable rows")
    return timestamps, values


def load_tracelab(path: Path, carbon_min: datetime, carbon_max: datetime) -> list[dict]:
    rows: list[dict] = []
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            raw = json.loads(line)
            timestamp = first_event_time(raw)
            prompt = int(raw.get("input_tokens_total") or 0)
            output = int(raw.get("output_tokens") or 0)
            if (
                timestamp is None
                or timestamp < carbon_min
                or timestamp >= carbon_max
                or prompt < 128
                or prompt > 30_000
                or output < 1
                or output > 512
            ):
                continue
            raw["_timestamp"] = timestamp
            rows.append(raw)
    rows.sort(key=lambda row: (row["_timestamp"], row["session_id"], row["round_index"]))
    if not rows:
        raise RuntimeError("no TraceLab rows overlap the usable NESO interval")
    return rows


def choose_windows(rows: list[dict], count: int, window_minutes: int, minimum_rows: int) -> list[datetime]:
    span = timedelta(minutes=window_minutes)
    buckets: dict[datetime, list[dict]] = defaultdict(list)
    for row in rows:
        timestamp = row["_timestamp"]
        minute = (timestamp.minute // window_minutes) * window_minutes
        start = timestamp.replace(minute=minute, second=0, microsecond=0)
        buckets[start].append(row)
    eligible = []
    for start, values in sorted(buckets.items()):
        sessions = defaultdict(int)
        for row in values:
            sessions[str(row["session_id"])] += 1
        repeat_rows = sum(max(0, amount - 1) for amount in sessions.values())
        if len(values) >= minimum_rows and repeat_rows >= max(8, minimum_rows // 8):
            eligible.append(start)
    if len(eligible) < count:
        raise RuntimeError(
            f"only {len(eligible)} eligible real windows; need {count}. "
            "Lower --minimum-rows or increase --window-minutes."
        )
    # Even chronological quantiles avoid selecting windows merely because they
    # produce a favorable result or happen to have the highest activity.
    positions = [round(index * (len(eligible) - 1) / max(1, count - 1)) for index in range(count)]
    selected = [eligible[position] for position in positions]
    if any(right < left + span for left, right in zip(selected, selected[1:])):
        raise RuntimeError("selected windows overlap; use fewer windows")
    return selected


def normalize_window(
    rows: list[dict], start: datetime, minutes: int, compression: float, max_requests: int
) -> list[dict]:
    end = start + timedelta(minutes=minutes)
    selected = [row for row in rows if start <= row["_timestamp"] < end][:max_requests]
    previous: dict[str, dict] = {}
    normalized: list[dict] = []
    for raw in selected:
        session = str(raw["session_id"])
        prior = previous.get(session)
        request_id = str(raw.get("trace_key") or raw["round_id"])
        prompt_tokens = int(raw["input_tokens_total"])
        shared = 0
        parent = None
        tool_delay_ms = 0.0
        if prior is not None and int(raw.get("round_index") or 0) == int(prior.get("round_index") or 0) + 1:
            shared = min(
                prompt_tokens,
                int(prior["input_tokens_total"]),
                max(0, int(raw.get("prefix_tokens") or 0)),
            )
            parent = str(prior.get("trace_key") or prior["round_id"])
            observed_tool_ms = [
                float(tool.get("tool_internal_latency_ms") or tool.get("tool_wall_latency_ms") or 0)
                for tool in prior.get("tools", [])
            ]
            tool_delay_ms = min(10_000.0, sum(observed_tool_ms) / compression)
        row = {
            "request_id": request_id,
            "session_id": session,
            "turn_id": int(raw.get("round_index") or 0),
            "arrival_ms": (raw["_timestamp"] - start).total_seconds() * 1000.0 / compression,
            "prompt_tokens": prompt_tokens,
            "max_output_tokens": int(raw["output_tokens"]),
            "shared_prefix_tokens": shared,
            "tool_delay_ms": tool_delay_ms,
            "ttft_slo_ms": 16_000,
            "tpot_slo_ms": 300,
            "workload": "agentic",
            "source_provider": raw.get("provider"),
            "source_model": raw.get("model"),
            "source_timestamp": raw["_timestamp"].isoformat(),
        }
        if parent:
            row["parent_request_id"] = parent
        normalized.append(row)
        previous[session] = raw
    return normalized


def carbon_rows(
    timestamps: list[datetime],
    values: dict[datetime, tuple[float, float]],
    real_start: datetime,
    minutes: int,
    compression: float,
    coverage_s: float,
    region_a: str,
    region_b: str,
) -> tuple[list[dict], float]:
    previous = {timestamps[index]: values[timestamps[index - 1]] for index in range(1, len(timestamps))}
    calibration_start = real_start - timedelta(days=7)
    scores = []
    for timestamp in timestamps:
        if not (calibration_start <= timestamp < real_start) or timestamp not in previous:
            continue
        actual = values[timestamp]
        forecast = previous[timestamp]
        scores.append(max(abs(actual[0] - forecast[0]), abs(actual[1] - forecast[1])) * G_PER_KWH_TO_LB_PER_MWH)
    if not scores:
        raise RuntimeError(f"no pre-window carbon calibration data before {real_start}")
    q95 = finite_sample_quantile(scores, 0.95)
    # Carbon settlement covers long decode tails as well as nominal arrivals.
    # Each replayed second advances ``compression`` seconds in the archived
    # source trace, so this horizon is converted back to source time here.
    real_end = real_start + timedelta(
        minutes=minutes, seconds=coverage_s * compression
    )
    output = []
    for timestamp in timestamps:
        if not (real_start <= timestamp <= real_end) or timestamp not in previous:
            continue
        actual = values[timestamp]
        forecast = previous[timestamp]
        synthetic = SYNTHETIC_START + (timestamp - real_start) / compression
        for region, estimate, settled in (
            (region_a, forecast[0], actual[0]),
            (region_b, forecast[1], actual[1]),
        ):
            output.append({
                "timestamp": synthetic.isoformat().replace("+00:00", "Z"),
                "region_id": region,
                "forecast_lbs_per_mwh": estimate * G_PER_KWH_TO_LB_PER_MWH,
                "historical_lbs_per_mwh": settled * G_PER_KWH_TO_LB_PER_MWH,
            })
    if len(output) < 4:
        raise RuntimeError(f"too few carbon rows for {real_start}")
    return output, q95


def build_config(index: int, trace: Path, carbon: Path, q95: float) -> dict:
    gpu_a, gpu_b, port_a, port_b, region_a, region_b = PAIR_LAYOUT[index]
    return {
        "experiment": {
            "name": f"tracelab_neso_window_{index:02d}_same_host_mechanism",
            "mode": "same_host_real_trace_mechanism",
            "model": "Qwen3.5-27B",
            "tokenizer": "/root/models/Qwen3.5-27B",
            "trace": trace.relative_to(ROOT).as_posix(),
        },
        "regions": [
            {"id": region_a, "api_base": f"http://127.0.0.1:{port_a}/v1", "control_base": "http://127.0.0.1:1", "api_key": "EMPTY", "model": "Qwen3.5-27B", "profile": f"profiles/{region_a}.json", "site_manifest": f"manifests/{region_a}.json", "gpu_count": 1, "tensor_parallel_size": 1, "admission_concurrency": 8, "rtt_ms": 0},
            {"id": region_b, "api_base": f"http://127.0.0.1:{port_b}/v1", "control_base": "http://127.0.0.1:1", "api_key": "EMPTY", "model": "Qwen3.5-27B", "profile": f"profiles/{region_b}.json", "site_manifest": f"manifests/{region_b}.json", "gpu_count": 1, "tensor_parallel_size": 1, "admission_concurrency": 8, "rtt_ms": 20},
        ],
        "carbon": {"trace": carbon.relative_to(ROOT).as_posix(), "clock_mode": "trace_relative", "trace_start_timestamp": SYNTHETIC_START.isoformat().replace("+00:00", "Z"), "max_age_s": 180},
        "routing": {"policy": "carbon_affinity", "lease_ttl_s": 900, "carbon_weight": 1.0, "slo_violation_penalty": 1000.0, "queue_penalty": 0.02, "migration_hysteresis_g": 0.002, "uncertainty_penalty_g": 0.0, "carbon_error_quantile_lbs_per_mwh": q95},
        "lease": {"calibrated": False, "adaptive": False, "ttl_candidates_s": [900], "kv_bytes_per_token": 327680, "memory_shadow_g_per_gib_s": 0, "latency_value_g_per_ms": 0},
        "runtime": {"arrival_scale": 1.0, "duration_limit_s": None, "max_in_flight": 128, "request_timeout_s": 900},
        "artifact_metadata": {"same_host_only": True, "carbon_source": "NESO regional average operational intensity", "forecast_method": "30-minute persistence using only the previous observation", "risk_calibration": "95% split-conformal max regional persistence residual over preceding 7 days", "pair_gpus": [gpu_a, gpu_b]},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tracelab", type=Path, default=ROOT / "data/raw/syfi_coding_trace.jsonl.gz")
    parser.add_argument("--neso", type=Path, default=ROOT / "data/raw/regional_carbon_intensity.csv")
    parser.add_argument("--windows", type=int, default=4)
    parser.add_argument("--window-minutes", type=int, default=60)
    parser.add_argument("--minimum-rows", type=int, default=80)
    parser.add_argument("--max-requests", type=int, default=120)
    parser.add_argument("--time-compression", type=float, default=30.0)
    parser.add_argument("--carbon-coverage-s", type=float, default=7200.0)
    args = parser.parse_args()
    if args.windows != len(PAIR_LAYOUT):
        raise ValueError(f"this 8-GPU design requires exactly {len(PAIR_LAYOUT)} windows")
    carbon_timestamps, carbon_values = load_neso(args.neso)
    trace_rows = load_tracelab(args.tracelab, carbon_timestamps[1], carbon_timestamps[-1])
    starts = choose_windows(trace_rows, args.windows, args.window_minutes, args.minimum_rows)
    manifest = {"schema_version": 1, "selection": "even chronological quantiles among pre-specified eligible non-overlapping windows", "windows": []}
    for index, start in enumerate(starts):
        normalized = normalize_window(trace_rows, start, args.window_minutes, args.time_compression, args.max_requests)
        _, _, _, _, region_a, region_b = PAIR_LAYOUT[index]
        carbon, q95 = carbon_rows(
            carbon_timestamps, carbon_values, start, args.window_minutes,
            args.time_compression, args.carbon_coverage_s, region_a, region_b,
        )
        trace_path = ROOT / f"data/normalized/tracelab_real_window_{index:02d}.jsonl"
        carbon_path = ROOT / f"data/carbon/neso_real_window_{index:02d}.csv"
        config_path = ROOT / f"configs/real_window_{index:02d}.generated.yaml"
        trace_path.parent.mkdir(parents=True, exist_ok=True)
        carbon_path.parent.mkdir(parents=True, exist_ok=True)
        trace_path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in normalized), encoding="utf-8")
        with carbon_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=("timestamp", "region_id", "forecast_lbs_per_mwh", "historical_lbs_per_mwh"))
            writer.writeheader()
            writer.writerows(carbon)
        config_path.write_text(yaml.safe_dump(build_config(index, trace_path, carbon_path, q95), sort_keys=False), encoding="utf-8")
        sessions = len({row["session_id"] for row in normalized})
        repeat_rows = sum("parent_request_id" in row for row in normalized)
        manifest["windows"].append({
            "index": index, "source_start_utc": start.isoformat(), "requests": len(normalized),
            "sessions": sessions, "repeat_session_rows": repeat_rows,
            "source_prompt_tokens": sum(row["prompt_tokens"] for row in normalized),
            "source_output_tokens": sum(row["max_output_tokens"] for row in normalized),
            "physical_duration_s": args.window_minutes * 60 / args.time_compression,
            "carbon_q95_lbs_per_mwh": q95, "config": config_path.relative_to(ROOT).as_posix(),
        })
    output = ROOT / "results/real_data_preparation_manifest.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))
    print(f"REAL_DATA_PREPARATION_COMPLETE={output}")


if __name__ == "__main__":
    main()
