from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from carbonaffinity.carbon import carbon_grams


def main() -> None:
    parser = argparse.ArgumentParser(description="Fit the lease memory shadow price")
    parser.add_argument("--samples", type=Path, nargs="+", required=True)
    parser.add_argument("--arrival-rate-rps", type=float, required=True)
    parser.add_argument("--moer-lbs-per-mwh", type=float, required=True)
    parser.add_argument("--latency-value-g-per-ms", type=float, default=0.000001)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = []
    for path in args.samples:
        rows.extend(json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip())
    usable = [row for row in rows if row.get("result", {}).get("success")]
    if len(usable) < 6:
        raise RuntimeError("at least six successful pressure samples are required")
    x = np.asarray([[1.0, float(row["estimated_occupied_gib"])] for row in usable])
    energy = np.asarray([float(row["total_energy_j"]) for row in usable])
    latency = np.asarray([float(row["result"]["ttft_ms"]) for row in usable])
    energy_slope = max(0.0, float(np.linalg.lstsq(x, energy, rcond=None)[0][1]))
    latency_slope = max(0.0, float(np.linalg.lstsq(x, latency, rcond=None)[0][1]))
    request_cost_g_per_gib = (
        carbon_grams(energy_slope, args.moer_lbs_per_mwh)
        + args.latency_value_g_per_ms * latency_slope
    )
    shadow = args.arrival_rate_rps * request_cost_g_per_gib
    result = {
        "samples": len(usable),
        "arrival_rate_rps": args.arrival_rate_rps,
        "moer_lbs_per_mwh": args.moer_lbs_per_mwh,
        "marginal_energy_j_per_gib": energy_slope,
        "marginal_ttft_ms_per_gib": latency_slope,
        "latency_value_g_per_ms": args.latency_value_g_per_ms,
        "memory_shadow_g_per_gib_s": shadow,
        "note": "score-equivalent opportunity cost; not direct measured CO2",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

