from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def event_time(row: dict) -> datetime | None:
    values = [
        event.get("timestamp")
        for event in row.get("timing_events", [])
        if event.get("timestamp")
    ]
    if not values:
        return None
    return datetime.fromisoformat(min(values).replace("Z", "+00:00"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--trace",
        type=Path,
        default=ROOT / "data/raw/syfi_coding_trace.jsonl.gz",
    )
    parser.add_argument(
        "--development-manifest",
        type=Path,
        default=ROOT / "results/real_data_preparation_manifest.json",
    )
    parser.add_argument("--cap-turns", type=int, default=32)
    parser.add_argument("--max-turn", type=int, default=64)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results/session_horizon_model.json",
    )
    args = parser.parse_args()

    manifest = json.loads(args.development_manifest.read_text())
    excluded_windows = []
    for row in manifest["windows"]:
        start = datetime.fromisoformat(row["source_start_utc"])
        excluded_windows.append((start, start + timedelta(hours=1)))

    rows_by_session: dict[str, list[dict]] = defaultdict(list)
    excluded_sessions: set[str] = set()
    opener = gzip.open if args.trace.suffix == ".gz" else open
    with opener(args.trace, "rt", encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            timestamp = event_time(row)
            if timestamp is None:
                continue
            session = str(row["session_id"])
            if any(left <= timestamp < right for left, right in excluded_windows):
                excluded_sessions.add(session)
            prompt = int(row.get("input_tokens_total") or 0)
            output = int(row.get("output_tokens") or 0)
            if 128 <= prompt <= 30_000 and 1 <= output <= 512:
                rows_by_session[session].append(row)

    lengths = []
    for session, rows in rows_by_session.items():
        if session in excluded_sessions or not rows:
            continue
        lengths.append(max(int(row.get("round_index") or 0) for row in rows) + 1)
    if not lengths:
        raise RuntimeError("no training sessions remain after development exclusion")

    estimates = {}
    support = {}
    for turn in range(args.max_turn + 1):
        remaining = [length - turn - 1 for length in lengths if length > turn]
        if not remaining:
            break
        estimates[str(turn)] = sum(
            min(value, args.cap_turns) for value in remaining
        ) / len(remaining)
        support[str(turn)] = len(remaining)

    report = {
        "schema_version": 1,
        "estimator": "empirical conditional restricted mean remaining turns",
        "development_exclusion": "exclude every session touching a frozen development window",
        "cap_turns": args.cap_turns,
        "max_turn": args.max_turn,
        "training_sessions": len(lengths),
        "excluded_sessions": len(excluded_sessions),
        "expected_remaining_turns": {"agentic": estimates},
        "support": {"agentic": support},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"SESSION_HORIZON_MODEL_COMPLETE={args.output.resolve()}")


if __name__ == "__main__":
    main()
