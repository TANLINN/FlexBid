"""Train a candidate session-work table from raw trace, excluding whole sessions.

Normalized evaluation trace session IDs are the exclusion key. Supply ALL
development/held-out windows, not merely a request-level random split.
"""
from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict
from pathlib import Path

from carbonaffinity.artifacts import sha256, write_json


def train(trace_path, exclusion_traces, cap_turns=32, max_turn=64):
    excluded = {row["session_id"] for path in exclusion_traces for line in Path(path).read_text().splitlines() if line.strip() for row in [json.loads(line)]}
    if not excluded:
        raise ValueError("empty evaluation-session exclusion set")
    sessions = defaultdict(list)
    opener = gzip.open if str(trace_path).endswith(".gz") else open
    with opener(trace_path, "rt", encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            session = str(row["session_id"])
            if session in excluded:
                continue
            p, d = int(row.get("input_tokens_total") or 0), int(row.get("output_tokens") or 0)
            if 128 <= p <= 30000 and 1 <= d <= 512:
                sessions[session].append({key: row.get(key) for key in
                    ("round_index", "input_tokens_total", "output_tokens", "prefix_tokens")})
    samples = defaultdict(list)
    for session, rows in sessions.items():
        rows.sort(key=lambda row: int(row.get("round_index") or 0))
        for index, row in enumerate(rows):
            turn = int(row.get("round_index") or 0)
            if not 0 <= turn <= max_turn:
                continue
            totals = {name: 0 for name in ("future_requests", "future_cold_tokens", "future_cached_tokens", "future_output_tokens")}
            previous = row
            for future in rows[index + 1:index + 1 + cap_turns]:
                cached = 0
                if int(future.get("round_index") or 0) == int(previous.get("round_index") or 0) + 1:
                    cached = min(future["input_tokens_total"], previous["input_tokens_total"], max(0, int(future.get("prefix_tokens") or 0)))
                totals["future_requests"] += 1
                totals["future_cached_tokens"] += cached
                totals["future_cold_tokens"] += future["input_tokens_total"] - cached
                totals["future_output_tokens"] += future["output_tokens"]
                previous = future
            samples[turn].append(totals)
    if not samples:
        raise ValueError("no training samples after exclusions")
    return {"schema_version": 2, "status": "TRAINED_CANDIDATE_NOT_EVALUATED", "estimator": "conditional empirical mean cumulative future work",
            "max_turn": max_turn, "cap_turns": cap_turns, "training_sessions": len(sessions),
            "excluded_sessions": len(excluded), "session_leakage": len(set(sessions) & excluded),
            "workloads": {"agentic": {str(turn): {name: sum(row[name] for row in values) / len(values)
                           for name in values[0]} for turn, values in sorted(samples.items())}},
            "support": {"agentic": {str(turn): len(values) for turn, values in sorted(samples.items())}},
            "source_sha256": {"trace": sha256(trace_path), **{str(p): sha256(p) for p in exclusion_traces}},
            "excluded_session_ids": sorted(excluded), "future_trace_access_at_inference": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--exclude-traces", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    model = train(args.trace, args.exclude_traces)
    write_json(args.output, model)
    print(f"FUTURE_WORK_TRAINED sessions={model['training_sessions']} excluded={model['excluded_sessions']} leakage={model['session_leakage']}")


if __name__ == "__main__":
    main()
