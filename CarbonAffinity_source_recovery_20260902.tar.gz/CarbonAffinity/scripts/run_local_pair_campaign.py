from __future__ import annotations

import argparse
import asyncio
import json
import random
import signal
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from carbonaffinity.audit import audit_results
from carbonaffinity.carbon import CarbonTrace
from carbonaffinity.config import load_config, resolve_path
from carbonaffinity.region import RegionClient
from carbonaffinity.replay import run_replay


POLICIES = [
    "round_robin", "pressure_only", "cleanest_now", "sticky",
    "cedar_like", "carbon_affinity", "oracle_historical",
]


def carbon_start(config: dict) -> float:
    value = config["carbon"]["trace_start_timestamp"]
    if isinstance(value, (int, float)):
        return float(value)
    return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()


async def main_async(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    regions = config["regions"]
    if len(regions) != 2:
        raise RuntimeError("local pair campaign needs exactly two regions")
    gpu_indices = [args.gpu_a, args.gpu_b]
    trace = resolve_path(config, config["experiment"]["trace"])
    carbon = CarbonTrace.from_csv(
        resolve_path(config, config["carbon"]["trace"]),
        float(config["carbon"].get("max_age_s", 1800)),
    )
    clients = {region["id"]: RegionClient(region, 60.0) for region in regions}
    args.output_root.mkdir(parents=True, exist_ok=True)
    policies = list(args.policies or POLICIES)
    if "pressure_only" not in policies:
        raise ValueError("--policies must include pressure_only for paired savings")
    if args.policy_order_seed is not None:
        random.Random(args.policy_order_seed).shuffle(policies)
    (args.output_root / "POLICY_ORDER.json").write_text(
        json.dumps({
            "seed": args.policy_order_seed,
            "order": policies,
        }, indent=2),
        encoding="utf-8",
    )
    try:
        for policy in policies:
            policy_dir = args.output_root / policy
            marker = policy_dir / "POLICY_COMPLETE.json"
            if marker.exists():
                continue
            policy_dir.mkdir(parents=True, exist_ok=True)
            reset = await asyncio.gather(*(client.reset_prefix_cache() for client in clients.values()))
            if not all(reset):
                raise RuntimeError(f"prefix-cache reset failed before {policy}")
            samplers: list[subprocess.Popen] = []
            telemetry: dict[str, Path] = {}
            try:
                for region, gpu in zip(regions, gpu_indices):
                    output = policy_dir / f"{region['id']}_gpu.csv"
                    telemetry[region["id"]] = output
                    samplers.append(subprocess.Popen([
                        sys.executable, "-m", "carbonaffinity.telemetry",
                        "--output", str(output), "--gpu-index", str(gpu),
                        "--region-id", region["id"], "--interval-ms", str(args.interval_ms),
                    ]))
                await asyncio.sleep(args.lead_s)
                await run_replay(config, trace, policy_dir / "requests.jsonl", policy_name=policy)
                await asyncio.sleep(args.tail_s)
            finally:
                for sampler in samplers:
                    if sampler.poll() is None:
                        sampler.send_signal(signal.SIGINT)
                for sampler in samplers:
                    try:
                        sampler.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        sampler.terminate()
                        sampler.wait(timeout=5)
            report = audit_results(
                policy_dir / "requests.jsonl", telemetry, carbon, carbon_start(config)
            )
            (policy_dir / "audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
            if not report["passed"]:
                raise RuntimeError(f"audit failed for {policy}: {report}")
            marker.write_text(json.dumps({
                "policy": policy,
                "requests": report["requests"],
                "measured_gpu_energy_j": report["measured_gpu_energy_j"],
                "measured_operational_carbon_g": report["measured_operational_carbon_g"],
            }, indent=2), encoding="utf-8")
            await asyncio.sleep(args.cooldown_s)
        rows = []
        reference = None
        reports = {}
        for policy in policies:
            reports[policy] = json.loads((args.output_root / policy / "audit.json").read_text())
        reference = reports["pressure_only"]["measured_operational_carbon_g"]
        for policy in policies:
            report = reports[policy]
            carbon_g = report["measured_operational_carbon_g"]
            rows.append({
                "policy": policy,
                "requests": report["requests"],
                "measured_gpu_energy_j": report["measured_gpu_energy_j"],
                "measured_operational_carbon_g": carbon_g,
                "carbon_savings_vs_pressure_pct": 100.0 * (reference - carbon_g) / reference,
                "ttft_violation_rate": report["ttft_violation_rate"],
                "tpot_violation_rate": report["tpot_violation_rate"],
                "ttft_p95_ms": report["ttft_p95_ms"],
                "tpot_p95_ms": report["tpot_p95_ms"],
                "migrations": report["migrations"],
                "regions": report["regions"],
            })
        (args.output_root / "campaign_summary.json").write_text(
            json.dumps({"reference_policy": "pressure_only", "policies": rows}, indent=2),
            encoding="utf-8",
        )
        (args.output_root / "PIPELINE_COMPLETE.json").write_text(
            json.dumps({"completed_s": time.time(), "policies": len(rows)}, indent=2),
            encoding="utf-8",
        )
    finally:
        await asyncio.gather(*(client.close() for client in clients.values()))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--gpu-a", type=int, required=True)
    parser.add_argument("--gpu-b", type=int, required=True)
    parser.add_argument("--interval-ms", type=int, default=100)
    parser.add_argument("--lead-s", type=float, default=2.0)
    parser.add_argument("--tail-s", type=float, default=2.0)
    parser.add_argument("--cooldown-s", type=float, default=2.0)
    parser.add_argument("--policy-order-seed", type=int)
    parser.add_argument("--policies", nargs="+", choices=POLICIES)
    asyncio.run(main_async(parser.parse_args()))


if __name__ == "__main__":
    main()
