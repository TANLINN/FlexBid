"""Create a source/data backup with per-file hashes; no weights or GPU results fabricated."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import tarfile
from pathlib import Path

from carbonaffinity.artifacts import sha256, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--include-data", action="store_true")
    parser.add_argument("--include-results", action="store_true", help="also preserve existing result/manifest files, without claiming new measurements")
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    dirs = ["carbonaffinity", "scripts", "tests", "configs", "profiles", "manifests", "docs", "latex", "experiments"]
    if args.include_data:
        dirs.append("data")
    if args.include_results:
        dirs.append("results")
    paths = sorted({path for name in dirs for path in (project / name).rglob("*") if path.is_file()
                    and "__pycache__" not in path.parts and path.suffix != ".pyc"})
    paths += [project / name for name in ("README.md", "RECOVERY.md", "pyproject.toml") if (project / name).is_file()]
    if args.output.exists():
        raise FileExistsError(args.output)
    hashes = {path.relative_to(project).as_posix(): sha256(path) for path in paths}
    manifest = {"status": "SOURCE_RECOVERY_BUNDLE", "sha256": hashes, "contains_new_gpu_results": False,
                "includes_retained_results": args.include_results, "includes_retained_data": args.include_data}
    raw = json.dumps(manifest, indent=2).encode()
    with tarfile.open(args.output, "x:gz") as archive:
        for path in paths:
            archive.add(path, arcname="CarbonAffinity/" + path.relative_to(project).as_posix(), recursive=False)
        info = tarfile.TarInfo("CarbonAffinity/RECOVERY_BUNDLE_MANIFEST.json")
        info.size = len(raw)
        archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(args.output) as archive:
        for name, expected in hashes.items():
            actual = hashlib.sha256(archive.extractfile("CarbonAffinity/" + name).read()).hexdigest()
            if actual != expected:
                raise RuntimeError(f"bundle integrity failed: {name}")
    write_json(args.output.with_suffix(args.output.suffix + ".sha256.json"), {"archive": str(args.output), "sha256": sha256(args.output), "files": len(paths), "verified": True})
    print("VERIFIED_BUNDLE =", args.output.resolve())
    print("SHA256 =", sha256(args.output))


if __name__ == "__main__":
    main()
