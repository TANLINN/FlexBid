from carbonaffinity.calibrate import main


if __name__ == "__main__":
    main()

