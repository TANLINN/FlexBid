from __future__ import annotations

import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {
    "carbonaffinity/models.py": (
        "19c4360ad2b07385495c4e1d6b97af4c40d4cd12d3760b7d183b7a8953d883f2"
    ),
    "carbonaffinity/region.py": (
        "64b94462d19ed2f6e85f3a8f7a636c0d9ce4e2e47f4a0ad0512370440043dfab"
    ),
    "carbonaffinity/replay.py": (
        "c2c7785dfc861d39d283eb5fceb055ffdcef3b43eb9a25f28d3c8e758ca0ee55"
    ),
    "carbonaffinity/audit.py": (
        "446bfeca3891608e095bbf9d74e1d8ce209ec414185f650f09d8bd75aad80c2c"
    ),
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"{label}: expected exactly one target, found {count}"
        )
    return text.replace(old, new, 1)


def patch_models(text: str) -> str:
    if "admission_wall_time_ns" in text:
        return text
    return replace_once(
        text,
        "    cached_prompt_tokens_observed: int | None\n"
        "    network_request_bytes: int = 0\n",
        "    cached_prompt_tokens_observed: int | None\n"
        "    admission_wall_time_ns: int | None = None\n"
        "    admission_wait_ms: float = 0.0\n"
        "    service_ttft_ms: float | None = None\n"
        "    network_request_bytes: int = 0\n",
        "CompletionResult admission fields",
    )


def patch_region(text: str) -> str:
    if "admission_perf_ns = time.perf_counter_ns()" in text:
        return text
    text = replace_once(
        text,
        "    ) -> CompletionResult:\n"
        "        async with self._counter_lock:\n"
        "            self._waiting += 1\n",
        "    ) -> CompletionResult:\n"
        "        admission_perf_ns = time.perf_counter_ns()\n"
        "        admission_wall_ns = time.time_ns()\n"
        "        async with self._counter_lock:\n"
        "            self._waiting += 1\n",
        "RegionClient admission start",
    )
    text = replace_once(
        text,
        "            return await self._complete_inner(request, prompt, cache_salt)\n",
        "            return await self._complete_inner(\n"
        "                request,\n"
        "                prompt,\n"
        "                cache_salt,\n"
        "                admission_perf_ns,\n"
        "                admission_wall_ns,\n"
        "            )\n",
        "RegionClient inner call",
    )
    text = replace_once(
        text,
        "    async def _complete_inner(\n"
        "        self, request: RequestSpec, prompt: str | list[int], cache_salt: str | None\n"
        "    ) -> CompletionResult:\n",
        "    async def _complete_inner(\n"
        "        self,\n"
        "        request: RequestSpec,\n"
        "        prompt: str | list[int],\n"
        "        cache_salt: str | None,\n"
        "        admission_perf_ns: int,\n"
        "        admission_wall_ns: int,\n"
        "    ) -> CompletionResult:\n",
        "RegionClient inner signature",
    )
    text = replace_once(
        text,
        "        return CompletionResult(\n",
        "        service_ttft_ms = (\n"
        "            None\n"
        "            if first_perf_ns is None\n"
        "            else (first_perf_ns - dispatch_perf_ns) / 1e6\n"
        "        )\n"
        "        end_to_end_ttft_ms = (\n"
        "            None\n"
        "            if first_perf_ns is None\n"
        "            else (first_perf_ns - admission_perf_ns) / 1e6\n"
        "        )\n"
        "        return CompletionResult(\n",
        "RegionClient TTFT calculations",
    )
    text = replace_once(
        text,
        "            ttft_ms=(None if first_perf_ns is None else (first_perf_ns - dispatch_perf_ns) / 1e6),\n",
        "            ttft_ms=end_to_end_ttft_ms,\n",
        "RegionClient end-to-end TTFT",
    )
    text = replace_once(
        text,
        "            cached_prompt_tokens_observed=cached,\n"
        "            network_request_bytes=network_actual.request_bytes,\n",
        "            cached_prompt_tokens_observed=cached,\n"
        "            admission_wall_time_ns=admission_wall_ns,\n"
        "            admission_wait_ms=(\n"
        "                dispatch_perf_ns - admission_perf_ns\n"
        "            ) / 1e6,\n"
        "            service_ttft_ms=service_ttft_ms,\n"
        "            network_request_bytes=network_actual.request_bytes,\n",
        "RegionClient result admission fields",
    )
    return text


def patch_audit(text: str) -> str:
    if 'get("admission_wall_time_ns")' in text:
        return text
    return replace_once(
        text,
        "        dispatches = [int(row[\"completion\"][\"dispatch_wall_time_ns\"]) for row in rows]\n",
        "        dispatches = [\n"
        "            int(\n"
        "                row[\"completion\"].get(\"admission_wall_time_ns\")\n"
        "                or row[\"completion\"][\"dispatch_wall_time_ns\"]\n"
        "            )\n"
        "            for row in rows\n"
        "        ]\n",
        "audit admission measurement boundary",
    )


def patch_replay(text: str) -> str:
    if "assignment_provider: Any | None = None" in text:
        return text
    text = replace_once(
        text,
        "    forced_policy_name: str = \"joint_learned_future\",\n"
        ") -> None:\n"
        "    runtime = config.get(\"runtime\", {})\n",
        "    forced_policy_name: str = \"joint_learned_future\",\n"
        "    assignment_provider: Any | None = None,\n"
        ") -> None:\n"
        "    if forced_assignments is not None and assignment_provider is not None:\n"
        "        raise ValueError(\n"
        "            \"forced_assignments and assignment_provider are mutually exclusive\"\n"
        "        )\n"
        "    runtime = config.get(\"runtime\", {})\n",
        "run_replay provider signature",
    )
    provider_block = '''            closed_loop_decision = None
            if assignment_provider is not None:
                carbon_lbs_per_mwh = {}
                for region_id in clients:
                    observation = carbon.at(region_id, carbon_time_s)
                    if observation.forecast_lbs_per_mwh is None:
                        raise RuntimeError(
                            "closed-loop planner has no current carbon "
                            f"forecast for {region_id}"
                        )
                    carbon_lbs_per_mwh[region_id] = (
                        observation.forecast_lbs_per_mwh
                    )
                closed_loop_decision = await assignment_provider.assign(
                    request,
                    snapshots,
                    carbon_lbs_per_mwh,
                )
                forced_region = closed_loop_decision.region_id
                candidate_regions = {
                    candidate.region_id
                    for candidate in decision.candidates
                }
                if forced_region not in candidate_regions:
                    await assignment_provider.complete(
                        request.request_id,
                        forced_region,
                        False,
                    )
                    raise RuntimeError(
                        "closed-loop assignment selected unknown region "
                        f"{forced_region} for {request.request_id}"
                    )
                decision = replace(
                    decision,
                    selected_region=forced_region,
                    policy="joint_closed_loop_learned_future",
                    migrated=(
                        decision.previous_region is not None
                        and decision.previous_region != forced_region
                    ),
                    fallback=False,
                    reason=(
                        "atomic closed-loop joint assignment with live load "
                        "and observable-only learned continuation"
                    ),
                )
'''
    text = replace_once(
        text,
        "            decision = router.decide(request, snapshots, now_s, carbon_time_s)\n"
        "            if forced_assignments is not None:\n",
        "            decision = router.decide(request, snapshots, now_s, carbon_time_s)\n"
        + provider_block
        + "            if forced_assignments is not None:\n",
        "run_replay provider decision",
    )
    text = replace_once(
        text,
        "            result = await client.complete(request, prompt, cache_salt=cache_salt)\n",
        "            try:\n"
        "                result = await client.complete(\n"
        "                    request, prompt, cache_salt=cache_salt\n"
        "                )\n"
        "            except BaseException:\n"
        "                if closed_loop_decision is not None:\n"
        "                    await assignment_provider.complete(\n"
        "                        request.request_id,\n"
        "                        decision.selected_region,\n"
        "                        False,\n"
        "                    )\n"
        "                raise\n"
        "            if closed_loop_decision is not None:\n"
        "                await assignment_provider.complete(\n"
        "                    request.request_id,\n"
        "                    decision.selected_region,\n"
        "                    result.success,\n"
        "                )\n",
        "run_replay reservation release",
    )
    text = replace_once(
        text,
        "            request_runtime_s = max(0.0, (result.completed_wall_time_ns - result.dispatch_wall_time_ns) / 1e9)\n",
        "            request_runtime_s = max(\n"
        "                0.0,\n"
        "                (\n"
        "                    result.completed_wall_time_ns\n"
        "                    - (\n"
        "                        result.admission_wall_time_ns\n"
        "                        or result.dispatch_wall_time_ns\n"
        "                    )\n"
        "                )\n"
        "                / 1e9,\n"
        "            )\n",
        "run_replay admission settlement",
    )
    text = replace_once(
        text,
        "                \"decision\": decision.to_dict(),\n"
        "                \"completion\": asdict(result),\n",
        "                \"decision\": decision.to_dict(),\n"
        "                \"closed_loop\": (\n"
        "                    closed_loop_decision.to_dict()\n"
        "                    if closed_loop_decision is not None\n"
        "                    else None\n"
        "                ),\n"
        "                \"completion\": asdict(result),\n",
        "run_replay closed-loop audit record",
    )
    text = replace_once(
        text,
        "        output_handle.close()\n"
        "        await asyncio.gather(*(client.close() for client in clients.values()))\n",
        "        output_handle.close()\n"
        "        if assignment_provider is not None:\n"
        "            await assignment_provider.close()\n"
        "        await asyncio.gather(*(client.close() for client in clients.values()))\n",
        "run_replay provider close",
    )
    return text


def main() -> None:
    marker = ROOT / "results/CLOSED_LOOP_RUNTIME_INSTALL_COMPLETE.json"
    if marker.is_file():
        print(marker.read_text())
        print("CLOSED_LOOP_RUNTIME_ALREADY_INSTALLED")
        return

    actual = {
        relative: digest(ROOT / relative)
        for relative in EXPECTED
    }
    if actual != EXPECTED:
        raise RuntimeError(
            "live hashes changed since preflight: "
            + json.dumps(actual, indent=2)
        )

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = ROOT / f"results/closed_loop_runtime_backup_{stamp}"
    backup.mkdir(parents=True)
    for relative in EXPECTED:
        destination = backup / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / relative, destination)

    patchers = {
        "carbonaffinity/models.py": patch_models,
        "carbonaffinity/region.py": patch_region,
        "carbonaffinity/replay.py": patch_replay,
        "carbonaffinity/audit.py": patch_audit,
    }
    try:
        for relative, patcher in patchers.items():
            path = ROOT / relative
            updated = patcher(path.read_text(encoding="utf-8"))
            compile(updated, str(path), "exec")
            path.write_text(updated, encoding="utf-8")
    except BaseException:
        for relative in EXPECTED:
            shutil.copy2(backup / relative, ROOT / relative)
        print("CLOSED_LOOP_RUNTIME_PATCH_ROLLED_BACK")
        raise

    record = {
        "schema_version": 1,
        "status": "PATCHED_PENDING_TESTS",
        "installed_utc": datetime.now(timezone.utc).isoformat(),
        "backup": str(backup),
        "before_sha256": actual,
        "after_sha256": {
            relative: digest(ROOT / relative)
            for relative in EXPECTED
        },
    }
    marker.write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(json.dumps(record, indent=2))
    print("CLOSED_LOOP_RUNTIME_PATCH_PASS")


if __name__ == "__main__":
    main()
