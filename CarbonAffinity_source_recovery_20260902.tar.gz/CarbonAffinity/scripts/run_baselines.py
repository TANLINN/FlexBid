from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from carbonaffinity.config import load_config, resolve_path
from carbonaffinity.replay import run_replay


def main() -> None:
    parser = argparse.ArgumentParser(description="Run main routing policies sequentially")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--policies", nargs="+", default=[
        "round_robin", "pressure_only", "cleanest_now", "sticky",
        "cedar_like", "carbon_affinity", "oracle_historical",
    ])
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)
    trace = resolve_path(config, config["experiment"]["trace"])
    args.output_root.mkdir(parents=True, exist_ok=True)
    for policy in args.policies:
        policy_dir = args.output_root / policy
        policy_dir.mkdir(parents=True, exist_ok=True)
        output = policy_dir / "requests.jsonl"
        asyncio.run(run_replay(config, trace, output, policy, args.resume))
        (policy_dir / "REPLAY_COMPLETE.json").write_text(
            json.dumps({"policy": policy, "requests": sum(1 for _ in output.open(encoding="utf-8"))}, indent=2),
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
