from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml


def main() -> None:
    parser = argparse.ArgumentParser(description="Clone one measured profile into two smoke-only logical regions")
    parser.add_argument("--source-profile", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("profiles"))
    parser.add_argument("--config-template", type=Path)
    parser.add_argument("--config-output", type=Path)
    parser.add_argument("--model-dir", type=Path)
    parser.add_argument("--served-model-name")
    parser.add_argument("--api-base")
    args = parser.parse_args()
    profile = json.loads(args.source_profile.read_text(encoding="utf-8"))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for region in ("smoke_a", "smoke_b"):
        target = args.output_dir / f"{region}.json"
        target.write_text(json.dumps({**profile, "region_id": region}, indent=2), encoding="utf-8")
        print(target)
    if args.config_output:
        if not args.config_template or not args.model_dir or not args.served_model_name or not args.api_base:
            parser.error(
                "config generation requires --config-template, --model-dir, "
                "--served-model-name, and --api-base"
            )
        config = yaml.safe_load(args.config_template.read_text(encoding="utf-8"))
        config["experiment"]["model"] = args.served_model_name
        config["experiment"]["tokenizer"] = str(args.model_dir.resolve())
        for region in config["regions"]:
            region["api_base"] = args.api_base.rstrip("/")
            region["model"] = args.served_model_name
        args.config_output.parent.mkdir(parents=True, exist_ok=True)
        args.config_output.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
        print(args.config_output)


if __name__ == "__main__":
    main()
