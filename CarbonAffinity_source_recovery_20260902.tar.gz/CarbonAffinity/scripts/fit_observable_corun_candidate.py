"""CPU-only candidate fit; preserve original evidence and all frozen profiles."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, write_json
from scripts import corun_observable_development as dev
from scripts import observable_corun_candidate as candidate


def evidence_files(source):
    paths = [source / n for n in (dev.REPORT_NAME, "EXPERIMENT_COMPLETE.json", "PREREGISTRATION.json",
                                 "LAUNCH.json", "SHAPE_PREWARM.json", "PRIOR_PILOT_GATE.json")]
    paths += sorted((source / "raw").rglob("*.jsonl"))
    paths += [source / f"vllm_gpu_{g}.log" for g in range(8)]
    registered = json.loads((source / "PREREGISTRATION.json").read_text())
    gate = json.loads((source / "PRIOR_PILOT_GATE.json").read_text())
    paths += [Path(p) for p in registered["code_sha256"]]
    paths += [Path(p) for p in gate["sha256"]]
    return sorted(set(paths))


def source_snapshot(source):
    return {str(p): sha256(p) for p in evidence_files(source)}


def build(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    if output == source or output.is_relative_to(source) or source.is_relative_to(output):
        raise ValueError("output must be separate from source")
    if output.exists():
        raise FileExistsError("no overwrite or resume of fit output")
    if (source / "FATAL.json").exists():
        raise ValueError("source contains FATAL")
    saved = json.loads((source / dev.REPORT_NAME).read_text())
    complete = json.loads((source / "EXPERIMENT_COMPLETE.json").read_text())
    if (saved.get("status") != "PASS" or saved.get("stage") != dev.VERSION or
        complete.get("status") != "COMPLETE" or complete.get("rows") != 2208 or
        not saved.get("checks") or not all(v is True for v in saved["checks"].values())):
        raise ValueError("source needs completed/passing2208 development audit")
    before = source_snapshot(source)
    rechecked = dev.audit(source)
    if rechecked["status"] != "PASS":
        raise ValueError("source re-audit failed: " + json.dumps(rechecked["checks"]))
    rows = read_rows(source / "raw")
    output.mkdir(parents=True, exist_ok=False)
    try:
        import carbonaffinity.artifacts as artifacts
        import scripts.corun_observable_pilot as engine
        files = [Path(__file__).resolve()] + [Path(m.__file__).resolve() for m in (candidate, dev, engine, artifacts)]
        code_hashes = {str(p): sha256(p) for p in files}
        write_json(output / "FIT_RECORD.json", dict(stage="CPU_OBSERVABLE_CORUN_DEVELOPMENT_FIT_ONLY",
            created_utc=datetime.now(timezone.utc).isoformat(), source_root=str(source), source_sha256=before,
            fit_code_sha256=code_hashes, training_rows=2016, excluded_future_controls=192,
            method_selected_after_development=True, validation_data_read=False,
            candidate_frozen=False, source_reaudit_checks=rechecked["checks"]))
        model, diagnostics = candidate.fit_candidate(rows)
        after = source_snapshot(source)
        if before != after or any(sha256(p) != h for p, h in code_hashes.items()) or (source / "FATAL.json").exists():
            raise RuntimeError("source/evidence/code changed during fit")
        model["provenance"] = dict(source_root=str(source), source_rows=2208, training_rows=2016,
            excluded_future_control_rows=192, fit_record_sha256=sha256(output / "FIT_RECORD.json"))
        checks = dict(exact_2208_source_rows=len(rows) == 2208, source_reaudit_pass=rechecked["status"] == "PASS",
            fit2016_controls192=diagnostics["training_rows"] == 2016 and diagnostics["excluded_future_control_rows"] == 192,
            model_126_cells=sum(len(s["cells"]) for s in model["surfaces"].values()) == 126,
            eight_logo_folds=len(diagnostics["leave_one_gpu_out_without_margin"]) == 8,
            development_coverage_100pct=all(v["coverage"] == 1 for v in diagnostics["development_resubstitution"].values()),
            source_and_code_unchanged=True,
            not_frozen_not_validated=model["candidate_frozen"] is False and model["independent_validation_passed"] is False)
        if not all(checks.values()):
            raise RuntimeError("candidate construction checks failed: " + json.dumps(checks))
        model_path = output / "observable_corun_candidate_v1.json"
        write_json(model_path, model)
        report = dict(status="CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION", checks=checks,
            candidate=str(model_path), candidate_sha256=sha256(model_path), candidate_frozen=False,
            independent_validation_passed=False, margin_ms=model["margin_ms"], **diagnostics)
        write_json(output / "OBSERVABLE_CORUN_CANDIDATE_AUDIT.json", report)
        write_json(output / "FIT_COMPLETE.json", dict(status="COMPLETE", candidate_frozen=False,
            independent_validation_passed=False, candidate_sha256=report["candidate_sha256"],
            audit_sha256=sha256(output / "OBSERVABLE_CORUN_CANDIDATE_AUDIT.json")))
        return report
    except Exception as exc:
        write_json(output / "FATAL.json", dict(status="FAIL", error=f"{type(exc).__name__}: {exc}"))
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    report = build(args.input_root, args.output_root)
    print("STATUS =", report["status"])
    print("CHECKS =", json.dumps(report["checks"]))
    print("FIT_ROWS=2016 CONTROLS_EXCLUDED=192 CELLS=126")
    print("MARGINS_MS =", json.dumps(report["margin_ms"]))
    print("DEVELOPMENT RESUBSTITUTION (not independent validation)")
    for name, g in report["development_resubstitution"].items():
        print(name, f"n={g['samples']} coverage={g['coverage']:.2%} pred/actual_median={g['prediction_over_actual_median']:.3f}",
              f"FN={g.get('false_negatives', '-')} FP={g.get('false_positives', '-')}")
    print("LOGO BEFORE MARGIN (development diagnostics)")
    for fold in report["leave_one_gpu_out_without_margin"]:
        print("GPU", fold["heldout_gpu"], " ".join(f"{n}={g['coverage']:.1%}/+{g['positive_residual_max_ms']:.3f}ms"
              for n, g in fold["without_margin"].items()))
    print("FUTURE CONTROLS (excluded from cells, margin and acceptance)")
    for name, g in report["future_controls_diagnostic_only"].items():
        print(name, f"n={g['samples']} coverage={g['coverage']:.2%} max_positive_residual_ms={g['positive_residual_max_ms']:.3f}")
    print("CANDIDATE =", report["candidate"])
    print("CANDIDATE_SHA256 =", report["candidate_sha256"])
    print("CANDIDATE_FROZEN=False INDEPENDENT_VALIDATION_PASSED=False")
    print("OBSERVABLE_CORUN_CPU_FIT_COMPLETE")


if __name__ == "__main__":
    main()
