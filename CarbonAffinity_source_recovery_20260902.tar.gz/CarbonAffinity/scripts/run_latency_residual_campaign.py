"""Eight-GPU residual-token DEVELOPMENT only; separate from old validation runs."""
import argparse
import asyncio
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

from carbonaffinity.artifacts import sha256, write_json
from scripts.latency_residual_protocol import GPUS, VERSION, design


def arguments():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path("/root/CarbonAffinity"))
    parser.add_argument("--model-dir", type=Path, default=Path("/root/models/Qwen3.5-27B"))
    parser.add_argument("--model", default="Qwen3.5-27B")
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--prewarm-only", action="store_true")
    return parser.parse_args()


def main(campaign=None):
    args = arguments()
    stage = VERSION if campaign is None else campaign.VERSION
    run_design = design() if campaign is None else campaign.design()
    expected_rows = run_design["expected_rows"]
    if args.prewarm_only:
        from carbonaffinity.materialize import PromptMaterializer
        from carbonaffinity.region import RegionClient
        from scripts.latency_shape_probe_support import prewarm
        asyncio.run(prewarm(args.output_root, PromptMaterializer(str(args.model_dir)), RegionClient,
                            gpus=GPUS, first_port=18000, model=args.model))
        return
    if os.name != "posix":
        raise RuntimeError("real campaign requires Linux")
    project = args.project_root.resolve()
    source_root = Path(__file__).resolve().parents[1]
    root = args.output_root.resolve()
    if not root.is_relative_to(project / "results") or root == project / "results":
        raise ValueError("output must be a fresh child of project/results")
    root.mkdir(parents=True, exist_ok=False)
    children, handles, servers = [], [], []
    success = False

    def event(message):
        line = datetime.now(timezone.utc).isoformat() + " " + message
        print(line, flush=True)
        with (root / "events.log").open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")

    def spawn(command, path, extra=None):
        handle = path.open("x", encoding="utf-8")
        handles.append(handle)
        env = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONNOUSERSITE": "1",
               "PYTHONPATH": str(source_root) + os.pathsep + str(project),
               "TRITON_PRINT_AUTOTUNING": "1", **(extra or {})}
        # An immutable transfer bundle must precede the old project's scripts
        # package even for `python -m` (cwd otherwise outranks PYTHONPATH).
        process = subprocess.Popen(command, cwd=source_root, env=env, stdin=subprocess.DEVNULL,
                                   stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
        children.append(process)
        return process

    def wait_for(workers, timeout):
        deadline = time.monotonic() + timeout
        while True:
            if any(p.poll() not in (None, 0) for p in workers):
                raise RuntimeError("worker failed; inspect prewarm/worker logs")
            if any(p.poll() is not None for p in servers):
                raise RuntimeError("vLLM exited during campaign")
            if telemetry.poll() is not None:
                raise RuntimeError("GPU telemetry exited")
            if all(p.poll() == 0 for p in workers):
                return
            if time.monotonic() > deadline:
                raise TimeoutError("worker timeout")
            time.sleep(2)

    def interrupted(signum, _frame):
        raise InterruptedError(f"received signal {signum}")

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        if not (args.model_dir / "config.json").is_file():
            raise FileNotFoundError("model config missing")
        busy = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid,gpu_uuid",
                                        "--format=csv,noheader"], text=True).strip()
        if busy:
            raise RuntimeError("GPU_BUSY_NOT_STARTED: stop other GPU work explicitly")
        for gpu in GPUS:
            with socket.socket() as sock:
                sock.settimeout(1)
                if sock.connect_ex(("127.0.0.1", 18000 + gpu)) == 0:
                    raise RuntimeError(f"PORT_BUSY_NOT_STARTED: {18000 + gpu}")
        import carbonaffinity.artifacts, carbonaffinity.models, carbonaffinity.region
        import carbonaffinity.materialize, carbonaffinity.network
        import scripts.latency_residual_protocol, scripts.measure_latency_residual
        import scripts.audit_latency_residual, scripts.latency_shape_probe_support
        modules = (carbonaffinity.artifacts, carbonaffinity.models, carbonaffinity.region,
                   carbonaffinity.materialize, carbonaffinity.network, scripts.latency_residual_protocol,
                   scripts.measure_latency_residual, scripts.audit_latency_residual,
                   scripts.latency_shape_probe_support)
        code_paths = [Path(m.__file__).resolve() for m in modules] + [Path(__file__).resolve()]
        extra = {}
        if campaign is not None:
            # Locked-candidate preflight runs before any GPU process is started.
            extra = campaign.prepare(root, args)
            code_paths += campaign.code_paths()
        write_json(root / "PREREGISTRATION.json", {
            "schema_version": 1, "stage": stage, "created_utc": datetime.now(timezone.utc).isoformat(),
            "expected_rows": expected_rows, "design": run_design, **extra,
            "code_sha256": {str(p): sha256(p) for p in code_paths},
            "fixed_prewarm": {"prompts": [16, 32, 64, 2048], "passes": 2, "output": 64,
                              "null_cache_readings": "unknown, not zero; prewarm only"}})
        write_json(root / "SUPERVISOR.json", {"pid": os.getpid(), "stage": stage})
        commands = []
        for gpu in GPUS:
            command = [str(Path(sys.executable).with_name("vllm")), "serve", str(args.model_dir.resolve()),
                       "--served-model-name", args.model, "--host", "127.0.0.1", "--port", str(18000 + gpu),
                       "--tensor-parallel-size", "1", "--enable-prefix-caching", "--enable-prompt-tokens-details",
                       "--enable-chunked-prefill", "--max-num-batched-tokens", "784", "--max-num-seqs", "8",
                       "--max-model-len", "65536", "--gpu-memory-utilization", "0.92"]
            commands.append({"gpu": gpu, "command": command})
            servers.append(spawn(command, root / f"vllm_gpu_{gpu}.log", {"CUDA_VISIBLE_DEVICES": str(gpu)}))
        telemetry = spawn(["nvidia-smi", "--query-gpu=timestamp,index,uuid,utilization.gpu,power.draw,clocks.sm",
                           "--format=csv", "--loop=1"], root / "gpu_telemetry.csv")
        deadline = time.monotonic() + 1200
        with httpx.Client(timeout=2, trust_env=False) as client:
            while True:
                if any(p.poll() is not None for p in servers) or telemetry.poll() is not None:
                    raise RuntimeError("startup process exited; inspect engine/telemetry logs")
                ready = 0
                for gpu in GPUS:
                    try:
                        ready += client.get(f"http://127.0.0.1:{18000+gpu}/health").is_success
                    except httpx.HTTPError:
                        pass
                event(f"VLLM_READY={ready}/8")
                if ready == 8:
                    break
                if time.monotonic() > deadline:
                    raise TimeoutError("vLLM startup timeout")
                time.sleep(10)
        for gpu in GPUS:
            text = (root / f"vllm_gpu_{gpu}.log").read_text(errors="replace")
            if not re.search(r"max_num_batched_tokens[^0-9]*784([^0-9]|$)", text):
                raise RuntimeError(f"GPU {gpu}: effective cap784 not recorded")
            if not re.search(r"(?:attention )?block size to 784 tokens", text):
                raise RuntimeError(f"GPU {gpu}: expected cache block784 not recorded; do not guess cache targets")
        write_json(root / "LAUNCH.json", {"runtime_cap": 784, "effective_cap_verified": True,
                   "cache_block784_verified": True, "servers": commands, "python": sys.version,
                   "packages": subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True),
                   "nvidia_smi": subprocess.check_output(["nvidia-smi"], text=True)})
        event("FIXED_SHAPE_PREWARM_START")
        wait_for([spawn([sys.executable, "-m", "scripts.run_latency_residual_campaign", "--prewarm-only",
                         "--output-root", str(root), "--model-dir", str(args.model_dir.resolve()),
                         "--model", args.model], root / "shape_prewarm.log")], 900)
        event("FIXED_SHAPE_PREWARM_PASS")
        workers = []
        for gpu in GPUS:
            destination = root / "raw" / f"gpu_{gpu}"
            destination.mkdir(parents=True)
            measurement_module = "scripts.measure_latency_residual" if campaign is None else campaign.MEASUREMENT_MODULE
            workers.append(spawn([sys.executable, "-m", measurement_module,
                "--gpu-index", str(gpu), "--api-base", f"http://127.0.0.1:{18000+gpu}/v1",
                "--model", args.model, "--tokenizer", str(args.model_dir.resolve()),
                "--output", str(destination / "measurements.jsonl"),
                "--runtime-evidence", sha256(root / "LAUNCH.json")], destination / "worker.log"))
        event(f"MEASUREMENT_START stage={stage} expected_rows={expected_rows}")
        wait_for(workers, 14400)
        event("AUDIT_START stage=" + stage)
        from scripts.audit_latency_residual import audit
        report = audit(root) if campaign is None else campaign.audit(root)
        report_name = "RESIDUAL_DEVELOPMENT_AUDIT.json" if campaign is None else campaign.REPORT_NAME
        write_json(root / report_name, report)
        if report["status"] != "PASS":
            raise RuntimeError("audit failed; raw rows retained, no model fitted or modified")
        write_json(root / "EXPERIMENT_COMPLETE.json", {"status": "COMPLETE", "rows": expected_rows,
                   "stage": stage, "candidate_frozen": False, "model_fitted": False})
        event("CAMPAIGN_COMPLETE stage=" + stage)
        success = True
    except Exception as exc:
        write_json(root / "FATAL.json", {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"})
        event("FAILED=" + str(exc))
    finally:
        for process in children:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 15
        while any(p.poll() is None for p in children) and time.monotonic() < deadline:
            time.sleep(.2)
        for process in children:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
        for handle in handles:
            handle.close()
    raise SystemExit(0 if success else 1)


if __name__ == "__main__":
    main()
