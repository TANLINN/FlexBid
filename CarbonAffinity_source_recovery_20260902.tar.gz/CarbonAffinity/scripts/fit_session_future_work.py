from __future__ import annotations

import argparse
import gzip
import json
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def event_time(row: dict) -> datetime | None:
    values = [
        event.get("timestamp")
        for event in row.get("timing_events", [])
        if event.get("timestamp")
    ]
    if not values:
        return None
    return datetime.fromisoformat(min(values).replace("Z", "+00:00"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--trace",
        type=Path,
        default=ROOT / "data/raw/syfi_coding_trace.jsonl.gz",
    )
    parser.add_argument(
        "--development-manifest",
        type=Path,
        default=ROOT / "results/real_data_preparation_manifest.json",
    )
    parser.add_argument("--cap-turns", type=int, default=32)
    parser.add_argument("--max-turn", type=int, default=64)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results/session_future_work_model.json",
    )
    args = parser.parse_args()

    manifest = json.loads(args.development_manifest.read_text())
    windows = []
    for item in manifest["windows"]:
        start = datetime.fromisoformat(item["source_start_utc"])
        windows.append((start, start + timedelta(hours=1)))

    sessions: dict[str, list[tuple[datetime, dict]]] = defaultdict(list)
    excluded: set[str] = set()
    opener = gzip.open if args.trace.suffix == ".gz" else open
    with opener(args.trace, "rt", encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            timestamp = event_time(row)
            if timestamp is None:
                continue
            session = str(row["session_id"])
            if any(left <= timestamp < right for left, right in windows):
                excluded.add(session)
            prompt = int(row.get("input_tokens_total") or 0)
            output = int(row.get("output_tokens") or 0)
            if 128 <= prompt <= 30_000 and 1 <= output <= 512:
                sessions[session].append((timestamp, row))

    samples: dict[int, list[dict[str, float]]] = defaultdict(list)
    training_sessions = 0
    for session, values in sessions.items():
        if session in excluded:
            continue
        values.sort(
            key=lambda item: (
                int(item[1].get("round_index") or 0),
                item[0],
            )
        )
        if not values:
            continue
        training_sessions += 1
        for position, (_, current) in enumerate(values):
            turn = int(current.get("round_index") or 0)
            if turn > args.max_turn:
                continue
            totals = {
                "future_requests": 0.0,
                "future_cold_tokens": 0.0,
                "future_cached_tokens": 0.0,
                "future_output_tokens": 0.0,
                "future_source_duration_s": 0.0,
            }
            current_timestamp = values[position][0]
            previous = current
            for timestamp, future in values[
                position + 1 : position + 1 + args.cap_turns
            ]:
                prompt = int(future["input_tokens_total"])
                consecutive = int(future.get("round_index") or 0) == (
                    int(previous.get("round_index") or 0) + 1
                )
                cached = 0
                if consecutive:
                    cached = min(
                        prompt,
                        int(previous["input_tokens_total"]),
                        max(0, int(future.get("prefix_tokens") or 0)),
                    )
                totals["future_requests"] += 1
                totals["future_cached_tokens"] += cached
                totals["future_cold_tokens"] += prompt - cached
                totals["future_output_tokens"] += int(
                    future.get("output_tokens") or 0
                )
                totals["future_source_duration_s"] = max(
                    totals["future_source_duration_s"],
                    max(0.0, (timestamp - current_timestamp).total_seconds()),
                )
                previous = future
            samples[turn].append(totals)

    expected = {}
    support = {}
    fields = (
        "future_requests",
        "future_cold_tokens",
        "future_cached_tokens",
        "future_output_tokens",
        "future_source_duration_s",
    )
    for turn in sorted(samples):
        rows = samples[turn]
        expected[str(turn)] = {
            field: sum(row[field] for row in rows) / len(rows)
            for field in fields
        }
        support[str(turn)] = len(rows)

    report = {
        "schema_version": 1,
        "estimator": "conditional empirical mean cumulative future work",
        "cap_turns": args.cap_turns,
        "max_turn": args.max_turn,
        "training_sessions": training_sessions,
        "excluded_sessions": len(excluded),
        "workloads": {"agentic": expected},
        "support": {"agentic": support},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"SESSION_FUTURE_WORK_MODEL_COMPLETE={args.output.resolve()}")


if __name__ == "__main__":
    main()
