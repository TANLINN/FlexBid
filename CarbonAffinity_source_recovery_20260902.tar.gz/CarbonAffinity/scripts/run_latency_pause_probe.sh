#!/usr/bin/env bash
# Diagnostic only: preserve the failed validation and every new observation.
set -Eeuo pipefail
if [[ -z "${BASH_SOURCE[0]:-}" || ! -f "${BASH_SOURCE[0]}" ]]; then
    echo "FILE_LAUNCH_REQUIRED: save and verify this script before running bash script.sh" >&2
    exit 2
fi
PROBE_STAGE=preflight
trap 'rc=$?; printf "PROBE_ERROR line=%s stage=%s exit=%s\n" "$LINENO" "$PROBE_STAGE" "$rc" >&2' ERR
cd /root/CarbonAffinity
PROBE_ROOT="${1:?new absolute result directory required}"
[[ "$PROBE_ROOT" == /root/CarbonAffinity/results/latency_pause_probe_* ]]
mkdir -- "$PROBE_ROOT"
export PYTHONPATH="$PWD"
export PYTHONNOUSERSITE=1
OWNED_PGIDS=()
SERVER_PIDS=()
WORKER_PIDS=()
cleanup() {
    local rc=$?
    trap - EXIT INT TERM
    for pid in "${OWNED_PGIDS[@]}"; do kill -TERM -- "-$pid" 2>/dev/null || true; done
    sleep 2
    for pid in "${OWNED_PGIDS[@]}"; do
        kill -KILL -- "-$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
    done
    if [[ "$rc" -ne 0 ]]; then
        printf '{"status":"FAIL","exit_code":%s}\n' "$rc" > "$PROBE_ROOT/FATAL.json"
    fi
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
printf '{"pid":%s,"stage":"latency-diagnostic"}\n' "$$" > "$PROBE_ROOT/SUPERVISOR.json"
BUSY="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
[[ -z "$BUSY" ]] || { echo "GPU_BUSY_NOT_STARTED"; exit 1; }
.venv/bin/python - "$PROBE_ROOT" "${BASH_SOURCE[0]}" <<'PY'
import json, socket, sys
from pathlib import Path
from carbonaffinity.artifacts import sha256, write_json
root = Path(sys.argv[1])
prior = Path('results/recovered_latency_validation_20260830T041919Z')
old = json.loads((prior / 'PREREGISTRATION.json').read_text())
files = ['scripts/measure_concurrency.py', 'carbonaffinity/region.py',
         'carbonaffinity/models.py', 'carbonaffinity/materialize.py']
for name in files[:3]:
    assert sha256(name) == old['code_sha256'][str(Path(name).resolve())], name + ' changed'
for gpu in (0, 6, 7):
    with socket.socket() as s:
        assert s.connect_ex(('127.0.0.1', 18000 + gpu)) != 0, 'port occupied'
files.append(str(Path(sys.argv[2]).resolve()))
write_json(root / 'PREREGISTRATION.json', {
    'stage': 'latency-diagnostic', 'expected_rows': 30, 'gpu_indices': [0, 6, 7],
    'prompt_tokens': 12288, 'concurrency': 3, 'output_tokens': 64, 'repeats': 5,
    'diagnostic_only': True, 'prior_failed_validation': str(prior.resolve()),
    'different_context': '3 GPUs rather than 8; no proof of eight-GPU stability',
    'code_sha256': {name: sha256(name) for name in files}})
PY
cp -- "${BASH_SOURCE[0]}" "$PROBE_ROOT/launcher_source.sh"
nvidia-smi > "$PROBE_ROOT/nvidia_smi_start.txt"
.venv/bin/python -m pip freeze > "$PROBE_ROOT/packages.txt"
PROBE_STAGE=server_startup
for GPU in 0 6 7; do
    setsid env CUDA_VISIBLE_DEVICES="$GPU" .venv/bin/vllm serve /root/models/Qwen3.5-27B \
        --served-model-name Qwen3.5-27B --host 127.0.0.1 --port "$((18000 + GPU))" \
        --tensor-parallel-size 1 --enable-prefix-caching --enable-prompt-tokens-details \
        --enable-chunked-prefill --max-num-batched-tokens 784 --max-num-seqs 8 \
        --max-model-len 65536 --gpu-memory-utilization 0.92 \
        > "$PROBE_ROOT/vllm_gpu_${GPU}.log" 2>&1 < /dev/null &
    SERVER_PIDS+=("$!"); OWNED_PGIDS+=("$!")
done
setsid nvidia-smi --id=0,6,7 \
    --query-gpu=timestamp,index,uuid,pstate,utilization.gpu,memory.used,temperature.gpu,power.draw,clocks.sm \
    --format=csv --loop=1 > "$PROBE_ROOT/gpu_telemetry.csv" 2>&1 < /dev/null &
TELEMETRY_PID=$!
OWNED_PGIDS+=("$TELEMETRY_PID")
if command -v vmstat >/dev/null 2>&1; then
    setsid vmstat -t 1 > "$PROBE_ROOT/cpu_vmstat.log" 2>&1 < /dev/null &
    OWNED_PGIDS+=("$!")
fi
DEADLINE=$((SECONDS + 1200))
while true; do
    for pid in "${SERVER_PIDS[@]}"; do kill -0 "$pid" || { echo "VLLM_EXITED"; exit 1; }; done
    kill -0 "$TELEMETRY_PID" || { echo "GPU_TELEMETRY_EXITED"; exit 1; }
    READY=0
    for GPU in 0 6 7; do
        if curl -fsS --max-time 2 "http://127.0.0.1:$((18000 + GPU))/health" >/dev/null 2>&1; then
            READY=$((READY + 1))
        fi
    done
    echo "$(date -Is) VLLM_READY=$READY/3"
    [[ "$READY" -eq 3 ]] && break
    [[ "$SECONDS" -lt "$DEADLINE" ]] || { echo "STARTUP_TIMEOUT"; exit 1; }
    sleep 5
done
PROBE_STAGE=measurement
for GPU in 0 6 7; do
    grep -Eq 'max_num_batched_tokens[^0-9]*784([^0-9]|$)' "$PROBE_ROOT/vllm_gpu_${GPU}.log"
    mkdir -p "$PROBE_ROOT/raw/gpu_$GPU"
    setsid .venv/bin/python -u -m scripts.measure_concurrency \
        --api-base "http://127.0.0.1:$((18000 + GPU))/v1" --model Qwen3.5-27B \
        --tokenizer /root/models/Qwen3.5-27B --region-id "gpu_$GPU" --gpu-index "$GPU" \
        --prompt-tokens 12288 --concurrency 3 --output-tokens 64 --repeats 5 \
        --server-warmup-requests 2 --timeout-s 300 \
        --output "$PROBE_ROOT/raw/gpu_$GPU/measurements.jsonl" \
        > "$PROBE_ROOT/raw/gpu_$GPU/worker.log" 2>&1 < /dev/null &
    WORKER_PIDS+=("$!"); OWNED_PGIDS+=("$!")
done
DEADLINE=$((SECONDS + 1200))
while true; do
    ACTIVE=0
    for pid in "${WORKER_PIDS[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then ACTIVE=$((ACTIVE + 1)); else wait "$pid"; fi
    done
    [[ "$ACTIVE" -eq 0 ]] && break
    for pid in "${SERVER_PIDS[@]}"; do kill -0 "$pid"; done
    kill -0 "$TELEMETRY_PID"
    [[ "$SECONDS" -lt "$DEADLINE" ]] || { echo "MEASUREMENT_TIMEOUT"; exit 1; }
    sleep 2
done
PROBE_STAGE=summary
.venv/bin/python - "$PROBE_ROOT" <<'PY'
import itertools, json, sys
from pathlib import Path
from carbonaffinity.artifacts import read_rows, quantile, write_json
root = Path(sys.argv[1])
rows = read_rows(root / 'raw')
keys = [(r['gpu_index'], r['mode'], r['prompt_tokens'], r['concurrency'], r['repeat']) for r in rows]
expected = set(itertools.product([0,6,7], ['cold','warm'], [12288], [3], range(5)))
assert len(keys) == 30 and set(keys) == expected, 'incomplete or duplicate cases'
assert all(len(r['results']) == 3 and all(x['success'] and x['output_tokens'] == 64 for x in r['results']) for r in rows)
summary = {}
for gpu in (0,6,7):
    group = [r for r in rows if r['gpu_index'] == gpu and r['mode'] == 'warm']
    item = {'warm_batches': len(group),
        'ttft_p95_ms_by_repeat': [round(r['ttft_p95_ms'], 3) for r in group],
        'tpot_p95_ms_by_repeat': [round(r['tpot_p95_ms'], 3) for r in group],
        'cached_tokens': sorted({x for r in group for x in r['cached_tokens'] if x is not None}),
        'missing_cache_observations': sum(x is None for r in group for x in r['cached_tokens'])}
    summary[str(gpu)] = item
    print('GPU', gpu, json.dumps(item), flush=True)
write_json(root / 'DIAGNOSTIC_SUMMARY.json', {'diagnostic_only': True, 'rows': len(rows), 'gpus': summary})
write_json(root / 'EXPERIMENT_COMPLETE.json', {'status': 'COMPLETE', 'rows': len(rows),
    'diagnostic_only': True, 'note': 'No model validation or eight-GPU stability claim.'})
print('LATENCY_PAUSE_PROBE_COLLECTION_COMPLETE')
PY
