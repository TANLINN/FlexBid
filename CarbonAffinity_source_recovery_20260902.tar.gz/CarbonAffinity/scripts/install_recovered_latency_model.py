"""Install a newly validated envelope into profiles, with rollback; no code patching."""
from __future__ import annotations

import argparse
import json
import shutil
import tempfile
from pathlib import Path

from carbonaffinity.artifacts import sha256, write_json
from carbonaffinity.latency_surface import estimate_latency_surface


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--freeze-record", type=Path, required=True)
    parser.add_argument("--profiles", type=Path, nargs="+", required=True)
    parser.add_argument("--backup-root", type=Path, required=True)
    args = parser.parse_args()
    freeze = json.loads(args.freeze_record.read_text())
    if freeze.get("status") != "FROZEN" or freeze["model_sha256"] != sha256(args.model):
        raise ValueError("frozen model SHA mismatch")
    report = Path(freeze["validation_report"])
    if not report.is_file() or sha256(report) != freeze["validation_sha256"]:
        raise ValueError("validation evidence missing or changed")
    model = json.loads(args.model.read_text())
    estimate_latency_surface(model, min(model["prompt_buckets"]), 0, 1)
    paths = [path.resolve() for path in args.profiles]
    if len(paths) != len(set(paths)) or len({p.name for p in paths}) != len(paths):
        raise ValueError("duplicate profile paths or backup filenames")
    updates = []
    for path in paths:
        profile = json.loads(path.read_text())
        profile["latency_surface_model"] = model
        profile["max_concurrency"] = min(profile["max_concurrency"], max(model["concurrency_buckets"]))
        profile["max_prompt_tokens"] = min(profile["max_prompt_tokens"], max(model["prompt_buckets"]))
        updates.append(profile)
    args.backup_root.mkdir(parents=True, exist_ok=False)
    for path in paths:
        shutil.copy2(path, args.backup_root / path.name)
    try:
        for path, profile in zip(paths, updates):
            write_json(path, profile, overwrite=True)
    except BaseException:
        for path in paths:
            shutil.copy2(args.backup_root / path.name, path)
        raise
    write_json(args.backup_root / "INSTALL.json", {"status": "INSTALLED", "model_sha256": sha256(args.model), "profiles": {str(p): sha256(p) for p in paths}})
    print("LATENCY_MODEL_INSTALLED; energy coefficients unchanged; physical validation still required")


if __name__ == "__main__":
    main()
