from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path

from carbonaffinity.audit import audit_results
from carbonaffinity.carbon import CarbonTrace
from carbonaffinity.config import load_config, resolve_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--requests", type=Path, required=True)
    parser.add_argument("--telemetry", action="append", default=[], help="region_id=path.csv")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    telemetry = {}
    for item in args.telemetry:
        region, path = item.split("=", 1)
        telemetry[region] = Path(path)
    carbon = CarbonTrace.from_csv(resolve_path(config, config["carbon"]["trace"]), float(config["carbon"].get("max_age_s", 1800)))
    start = config["carbon"].get("trace_start_timestamp")
    if start is not None and not isinstance(start, (int, float)):
        start = datetime.fromisoformat(str(start).replace("Z", "+00:00")).timestamp()
    report = audit_results(args.requests, telemetry or None, carbon, float(start) if start is not None else None)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["passed"] else 2)


if __name__ == "__main__":
    main()

