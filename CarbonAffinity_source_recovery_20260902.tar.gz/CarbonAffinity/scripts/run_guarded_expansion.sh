#!/usr/bin/env bash
set -euo pipefail

ROOT="${CARBONAFFINITY_ROOT:-/root/CarbonAffinity}"
PYTHON="${PYTHON:-$ROOT/.venv/bin/python}"
STAMP="${STAMP:-$(date -u +%Y%m%dT%H%M%SZ)}"
OUTPUT_ROOT="$ROOT/results/local_expansion_guarded/$STAMP"

cd "$ROOT"
mkdir -p "$OUTPUT_ROOT/risk_calibration"

for endpoint in 18002 18003 18004 18005 18006 18007; do
  curl -fsS "http://127.0.0.1:${endpoint}/health" >/dev/null
done

for workload in high_reuse low_reuse burst; do
  "$PYTHON" scripts/calibrate_carbon_risk.py \
    --config "configs/local_${workload}.generated.yaml" \
    --quantile 0.95 \
    --output "$OUTPUT_ROOT/risk_calibration/${workload}.json"
done

printf '%s\n' "$OUTPUT_ROOT" > results/local_expansion_guarded_latest.txt

"$PYTHON" scripts/run_local_pair_campaign.py \
  --config configs/local_high_reuse.generated.yaml \
  --output-root "$OUTPUT_ROOT/high_reuse" \
  --gpu-a 2 --gpu-b 3 \
  > "$OUTPUT_ROOT/high_reuse.launcher.log" 2>&1 &
HIGH_PID=$!

"$PYTHON" scripts/run_local_pair_campaign.py \
  --config configs/local_low_reuse.generated.yaml \
  --output-root "$OUTPUT_ROOT/low_reuse" \
  --gpu-a 4 --gpu-b 5 \
  > "$OUTPUT_ROOT/low_reuse.launcher.log" 2>&1 &
LOW_PID=$!

"$PYTHON" scripts/run_local_pair_campaign.py \
  --config configs/local_burst.generated.yaml \
  --output-root "$OUTPUT_ROOT/burst" \
  --gpu-a 6 --gpu-b 7 \
  > "$OUTPUT_ROOT/burst.launcher.log" 2>&1 &
BURST_PID=$!

printf '%s\n' "$HIGH_PID" > "$OUTPUT_ROOT/high_reuse.pid"
printf '%s\n' "$LOW_PID" > "$OUTPUT_ROOT/low_reuse.pid"
printf '%s\n' "$BURST_PID" > "$OUTPUT_ROOT/burst.pid"

STATUS=0
wait "$HIGH_PID" || STATUS=1
wait "$LOW_PID" || STATUS=1
wait "$BURST_PID" || STATUS=1

if [[ "$STATUS" -ne 0 ]]; then
  printf 'one or more guarded campaigns failed\n' >&2
  exit "$STATUS"
fi

"$PYTHON" - "$OUTPUT_ROOT" <<'PY'
import json
import sys
import time
from pathlib import Path

root = Path(sys.argv[1])
payload = {
    "completed_utc_s": time.time(),
    "workloads": ["high_reuse", "low_reuse", "burst"],
    "policies_per_workload": 7,
}
(root / "EXPANSION_COMPLETE.json").write_text(
    json.dumps(payload, indent=2), encoding="utf-8"
)
print(f"GUARDED_EXPANSION_COMPLETE={root}")
PY
