#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODEL_DIR="${MODEL_DIR:-/root/models/Qwen3.5-27B}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BUNDLE_DIR="$ROOT/results/reuse_bundle_$STAMP"
ARCHIVE="$ROOT/results/reuse_bundle_$STAMP.tar.gz"

cd "$ROOT"
source .venv/bin/activate
mkdir -p "$BUNDLE_DIR/environment" "$BUNDLE_DIR/profiles" "$BUNDLE_DIR/manifests"

cp -a results/bootstrap/. "$BUNDLE_DIR/environment/bootstrap/" 2>/dev/null || true

python -m pip freeze > "$BUNDLE_DIR/environment/pip_freeze.txt"
nvidia-smi -q > "$BUNDLE_DIR/environment/nvidia_smi_q.txt"
nvidia-smi topo -m > "$BUNDLE_DIR/environment/nvidia_topology.txt" || true
vllm --version > "$BUNDLE_DIR/environment/vllm_version.txt" 2>&1 || true
python --version > "$BUNDLE_DIR/environment/python_version.txt" 2>&1
df -h > "$BUNDLE_DIR/environment/disk.txt"

find "$MODEL_DIR" -maxdepth 1 -type f -printf '%f,%s\n' \
  | sort > "$BUNDLE_DIR/environment/model_inventory.csv"
sha256sum "$MODEL_DIR/config.json" > "$BUNDLE_DIR/environment/model_config.sha256"

cp -a profiles/. "$BUNDLE_DIR/profiles/" 2>/dev/null || true
cp -a manifests/. "$BUNDLE_DIR/manifests/" 2>/dev/null || true
cp requirements.txt pyproject.toml "$BUNDLE_DIR/"

tar -czf "$BUNDLE_DIR/CarbonAffinity_code.tar.gz" \
  --exclude='.venv' \
  --exclude='results' \
  --exclude='__pycache__' \
  --exclude='*.pyc' \
  -C "$(dirname "$ROOT")" "$(basename "$ROOT")"

LATEST_SMOKE="$(find results/single_gpu_smoke -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort | tail -n 1 || true)"
if [[ -n "$LATEST_SMOKE" ]]; then
  cp -a "$LATEST_SMOKE" "$BUNDLE_DIR/latest_smoke"
fi

tar -czf "$ARCHIVE" -C "$(dirname "$BUNDLE_DIR")" "$(basename "$BUNDLE_DIR")"
echo "REUSE_BUNDLE=$ARCHIVE"
