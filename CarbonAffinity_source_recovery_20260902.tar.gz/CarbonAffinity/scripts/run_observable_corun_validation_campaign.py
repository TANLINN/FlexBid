"""Run observable co-run validation with serialized vLLM startup.

The shared residual-campaign supervisor starts all eight vLLM processes at
once.  Each process independently selects a local torch.distributed TCPStore
port, so simultaneous startup can race and select the same port.  This wrapper
keeps the established measurement and audit supervisor unchanged, but waits
for each vLLM health endpoint before allowing the next vLLM process to start.
"""
from __future__ import annotations

import http.client
import os
import signal
import subprocess
import time
from pathlib import Path
from typing import Callable, Sequence

def _is_vllm_serve(command: object) -> bool:
    if not isinstance(command, (list, tuple)) or len(command) < 2:
        return False
    return Path(os.fspath(command[0])).name == "vllm" and command[1] == "serve"


def _option(command: Sequence[object], name: str) -> str:
    try:
        index = command.index(name)
        return os.fspath(command[index + 1])
    except (ValueError, IndexError, TypeError) as exc:
        raise ValueError(f"vLLM command is missing {name}") from exc


def _healthy(port: int) -> bool:
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=2)
    try:
        connection.request("GET", "/health")
        response = connection.getresponse()
        response.read()
        return 200 <= response.status < 300
    except OSError:
        return False
    finally:
        connection.close()


def _stop_untracked(process: subprocess.Popen) -> None:
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    deadline = time.monotonic() + 5
    while process.poll() is None and time.monotonic() < deadline:
        time.sleep(0.1)
    if process.poll() is None:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


class SerializedVllmPopen:
    """Popen-compatible callable that serializes only vLLM server startup."""

    def __init__(
        self,
        original: Callable[..., subprocess.Popen],
        *,
        timeout_s: float = 1200,
        poll_s: float = 2,
        health: Callable[[int], bool] = _healthy,
    ) -> None:
        self.original = original
        self.timeout_s = timeout_s
        self.poll_s = poll_s
        self.health = health

    def __call__(self, command, *args, **kwargs):
        process = self.original(command, *args, **kwargs)
        if not _is_vllm_serve(command):
            return process

        port = int(_option(command, "--port"))
        visible_gpu = str(kwargs.get("env", {}).get("CUDA_VISIBLE_DEVICES", "unknown"))
        print(f"SERIAL_VLLM_START gpu={visible_gpu} port={port}", flush=True)
        deadline = time.monotonic() + self.timeout_s
        while True:
            return_code = process.poll()
            if return_code is not None:
                print(
                    f"SERIAL_VLLM_EXIT gpu={visible_gpu} port={port} exit={return_code}",
                    flush=True,
                )
                return process
            if self.health(port):
                print(f"SERIAL_VLLM_READY gpu={visible_gpu} port={port}", flush=True)
                return process
            if time.monotonic() >= deadline:
                _stop_untracked(process)
                raise TimeoutError(
                    f"vLLM startup timeout before health: gpu={visible_gpu} port={port}"
                )
            time.sleep(self.poll_s)


def main(campaign=None, runner_module=None) -> None:
    if runner_module is None:
        from scripts import run_latency_residual_campaign as runner_module

    original = runner_module.subprocess.Popen
    runner_module.subprocess.Popen = SerializedVllmPopen(original)
    try:
        runner_module.main(campaign=campaign)
    finally:
        runner_module.subprocess.Popen = original


if __name__ == "__main__":
    from scripts import validate_observable_corun_candidate as validation

    main(campaign=validation)
