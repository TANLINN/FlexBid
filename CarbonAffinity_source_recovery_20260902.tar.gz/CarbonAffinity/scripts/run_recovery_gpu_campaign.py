"""Linux supervisor, no textual shell patching and no broad process killing.

Creates a NEW result directory, owns its child process groups, preregisters
validation before any measurements, stops every owned child on all exits.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import httpx

from carbonaffinity.artifacts import sha256, write_json
from carbonaffinity.workload_experiments import cases

PROJECT = Path(__file__).resolve().parents[1]
KINDS = {
    "backlog-development": ["backlog_development"],
    "backlog-validation": ["backlog_validation"],
    "corun-development": ["corun_development", "active_decode_development"],
    "corun-validation": ["corun_validation", "active_decode_validation"],
    "latency-development": [], "latency-validation": [], "energy-development": [], "five-policy": [],
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=KINDS, required=True)
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--served-model-name", default="Qwen3.5-27B")
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--gpus", nargs="+", type=int, default=list(range(8)))
    parser.add_argument("--first-port", type=int, default=18000)
    parser.add_argument("--startup-timeout-s", type=float, default=1200)
    parser.add_argument("--worker-timeout-s", type=float, default=14400)
    parser.add_argument("--candidate", type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--future-work-model", type=Path)
    parser.add_argument("--corun-model", type=Path)
    parser.add_argument("--corun-freeze-record", type=Path)
    parser.add_argument("--max-requests", type=int, default=120)
    parser.add_argument("--seed", type=int, default=20260830)
    args = parser.parse_args()
    if os.name != "posix":
        raise RuntimeError("GPU supervisor requires Linux; local unit tests use mocked endpoints")
    # The fixed-shape prewarm verifies this setting in the supervisor process,
    # while every vLLM child inherits the same value through spawn().
    os.environ["TRITON_PRINT_AUTOTUNING"] = "1"
    if len(args.gpus) != len(set(args.gpus)) or len(args.gpus) != 8:
        raise ValueError("this eight-region experiment needs eight distinct GPUs")
    if not (args.model_dir / "config.json").is_file():
        raise FileNotFoundError("model weights/config missing")
    if args.stage == "five-policy" and not all((args.config, args.future_work_model)):
        raise ValueError("five-policy needs --config and --future-work-model")
    if args.stage in {"corun-validation", "latency-validation"} and not args.candidate:
        raise ValueError("validation requires --candidate")
    # Snapshot busy compute processes before taking any GPU. Never start a
    # retention burner; it invalidates timing and energy measurements.
    busy = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid,gpu_uuid", "--format=csv,noheader"], text=True).strip()
    if busy:
        raise RuntimeError("GPU compute processes already active; stop them explicitly before this campaign")
    for port in range(args.first_port, args.first_port + 8):
        with socket.socket() as sock:
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                raise RuntimeError(f"port {port} already occupied")
    root = args.output_root.resolve()
    root.mkdir(parents=True, exist_ok=False)
    children, logs = [], []
    code_paths = [PROJECT / "scripts" / name for name in (
        "run_recovery_gpu_campaign.py", "measure_corun_workload.py", "measure_prefill_decode_interference.py", "validate_corun_ttft_surface.py")]
    code_paths += [PROJECT / "carbonaffinity" / name for name in ("corun_surface.py", "workload_experiments.py", "artifacts.py")]
    code_paths += [PROJECT / "scripts" / name for name in ("measure_concurrency.py", "recover_latency_surface.py")]
    code_paths += [PROJECT / "carbonaffinity" / name for name in ("region.py", "models.py", "latency_surface.py")]
    code_paths += [PROJECT / "scripts/measure_batch_energy.py"]
    candidate_hash = None if args.candidate is None else sha256(args.candidate)
    prereg = {"schema_version": 1, "created_utc": datetime.now(timezone.utc).isoformat(),
              "stage": args.stage, "candidate_sha256": candidate_hash, "gpu_indices": args.gpus,
              "expected_rows": {"latency-development": 800, "latency-validation": 144,
                                "energy-development": 864, "five-policy": 5 * args.max_requests}.get(
                                    args.stage, 8 * sum(len(cases(kind)) for kind in KINDS[args.stage])),
              "ttft_slo_ms": 16000, "minimum_coverage": .95,
              "code_sha256": {str(path): sha256(path) for path in code_paths}}
    write_json(root / "PREREGISTRATION.json", prereg)
    write_json(root / "SUPERVISOR.json", {"pid": os.getpid(), "stage": args.stage})

    def event(message):
        line = datetime.now(timezone.utc).isoformat() + " " + message
        print(line, flush=True)
        with (root / "events.log").open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")

    def spawn(command, log_path, env=None):
        handle = log_path.open("x", encoding="utf-8")
        logs.append(handle)
        process = subprocess.Popen(command, cwd=PROJECT, stdout=handle, stderr=subprocess.STDOUT,
                                   stdin=subprocess.DEVNULL, start_new_session=True,
                                   env={**os.environ, "PYTHONPATH": str(PROJECT), **(env or {})})
        children.append(process)
        return process

    def interrupted(signum, frame):
        raise InterruptedError(f"received signal {signum}")

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    status = "FAIL"
    try:
        servers = []
        commands = []
        for index, gpu in enumerate(args.gpus):
            command = [str(Path(sys.executable).with_name("vllm")), "serve", str(args.model_dir.resolve()),
                       "--served-model-name", args.served_model_name, "--host", "127.0.0.1",
                       "--port", str(args.first_port + index), "--tensor-parallel-size", "1",
                       "--enable-prefix-caching", "--enable-prompt-tokens-details", "--enable-chunked-prefill",
                       "--max-num-batched-tokens", "784", "--max-num-seqs", "8",
                       "--max-model-len", "65536", "--gpu-memory-utilization", "0.92"]
            commands.append({"gpu": gpu, "command": command})
            server = spawn(
                command,
                root / f"vllm_gpu_{gpu}.log",
                {
                    "CUDA_VISIBLE_DEVICES": str(gpu),
                    "TRITON_PRINT_AUTOTUNING": "1",
                },
            )
            servers.append(server)
            event(f"PARALLEL_VLLM_START gpu={gpu} port={args.first_port + index}")
        deadline = time.monotonic() + args.startup_timeout_s
        ready_gpus = set()
        with httpx.Client(timeout=2, trust_env=False) as client:
            while True:
                for index, (gpu, server) in enumerate(zip(args.gpus, servers)):
                    if server.poll() is not None:
                        raise RuntimeError(
                            f"vLLM process exited during parallel startup: gpu={gpu}"
                        )
                    if gpu in ready_gpus:
                        continue
                    try:
                        ready = client.get(
                            f"http://127.0.0.1:{args.first_port + index}/health"
                        ).is_success
                    except httpx.HTTPError:
                        ready = False
                    if ready:
                        ready_gpus.add(gpu)
                        event(
                            f"PARALLEL_VLLM_READY gpu={gpu} "
                            f"port={args.first_port + index}"
                        )
                event(f"VLLM_READY={len(ready_gpus)}/8")
                if len(ready_gpus) == 8:
                    break
                if time.monotonic() >= deadline:
                    raise TimeoutError("parallel vLLM startup timeout")
                time.sleep(5)
        for gpu in args.gpus:
            text = (root / f"vllm_gpu_{gpu}.log").read_text(errors="replace")
            if not re.search(r"max_num_batched_tokens[\s\"']*[:=]\s*784\b", text):
                raise RuntimeError(f"effective cap784 not found in GPU {gpu} engine log")
        launch = {"runtime_cap": 784, "effective_cap_verified": True, "servers": commands,
                  "python": sys.version, "nvidia_smi": subprocess.check_output(["nvidia-smi"], text=True),
                  "packages": subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True)}
        write_json(root / "LAUNCH.json", launch)
        evidence = sha256(root / "LAUNCH.json")

        from carbonaffinity.materialize import PromptMaterializer
        from carbonaffinity.region import RegionClient
        from scripts.latency_shape_probe_support import prewarm

        event("FIXED_SHAPE_PREWARM_START")
        asyncio.run(prewarm(
            root,
            PromptMaterializer(str(args.model_dir.resolve())),
            RegionClient,
            gpus=tuple(args.gpus),
            first_port=args.first_port,
            model=args.served_model_name,
        ))
        event("FIXED_SHAPE_PREWARM_PASS")

        def wait_workers(workers):
            deadline = time.monotonic() + args.worker_timeout_s
            while any(worker.poll() is None for worker in workers):
                if any(worker.poll() not in (None, 0) for worker in workers):
                    raise RuntimeError("measurement worker failed; see worker logs")
                if any(server.poll() is not None for server in servers):
                    raise RuntimeError("vLLM died during measurement")
                if time.monotonic() > deadline:
                    raise TimeoutError("measurement timeout")
                time.sleep(2)
            if any(worker.returncode != 0 for worker in workers):
                raise RuntimeError("worker failed")

        for kind in KINDS[args.stage]:
            event("MEASUREMENT_START=" + kind)
            workers = []
            for index, gpu in enumerate(args.gpus):
                destination = root / kind / f"gpu_{gpu}"
                destination.mkdir(parents=True)
                workers.append(spawn([sys.executable, "-m", "scripts.measure_corun_workload",
                                      "--api-base", f"http://127.0.0.1:{args.first_port + index}/v1",
                                      "--model", args.served_model_name, "--tokenizer", str(args.model_dir.resolve()),
                                      "--gpu-index", str(gpu), "--kind", kind,
                                      "--output", str(destination / "measurements.jsonl"),
                                      "--runtime-evidence", evidence], destination / "worker.log"))
            wait_workers(workers)
            event("MEASUREMENT_COMPLETE=" + kind)
        if args.stage.startswith("latency"):
            development = args.stage == "latency-development"
            prompts = [2048, 4096, 8192, 16384, 32768] if development else [6144, 12288, 24576]
            concurrency = [1, 2, 4, 6, 8] if development else [3, 5, 7]
            workers = []
            for index, gpu in enumerate(args.gpus):
                destination = root / "raw" / f"gpu_{gpu}"
                destination.mkdir(parents=True)
                workers.append(spawn([sys.executable, "-m", "scripts.measure_concurrency",
                                      "--api-base", f"http://127.0.0.1:{args.first_port + index}/v1",
                                      "--model", args.served_model_name, "--tokenizer", str(args.model_dir.resolve()),
                                      "--region-id", f"gpu_{gpu}", "--gpu-index", str(gpu),
                                      "--prompt-tokens", *map(str, prompts), "--concurrency", *map(str, concurrency),
                                      "--output-tokens", "64", "--repeats", "2" if development else "1",
                                      "--server-warmup-requests", "2", "--output", str(destination / "measurements.jsonl")], destination / "worker.log"))
            wait_workers(workers)
        if args.stage == "five-policy":
            import random
            from urllib.parse import urlparse
            from carbonaffinity.config import load_config
            cfg = load_config(args.config)
            mapping = []
            for region in cfg["regions"]:
                url = urlparse(region["api_base"])
                if url.hostname not in {"127.0.0.1", "localhost"} or url.port not in range(args.first_port, args.first_port + 8):
                    raise ValueError("config endpoint is outside this supervisor's eight owned endpoints")
                mapping.append(args.gpus[url.port - args.first_port])
            if len(set(mapping)) != 8:
                raise ValueError("config must map one distinct GPU endpoint to each region")
            policies = ["pressure_only", "cleanest_now", "sticky", "carbon_affinity", "joint_planner"]
            random.Random(args.seed).shuffle(policies)
            write_json(root / "POLICY_ORDER.json", {"seed": args.seed, "policies": policies})
            for policy in policies:
                command = [sys.executable, "-m", "scripts.run_8vllm_closed_loop_policy",
                           "--config", str(args.config.resolve()), "--output-root", str(root / "policies" / policy),
                           "--future-work-model", str(args.future_work_model.resolve()),
                           "--gpu-indices", *map(str, mapping), "--scheduler", policy,
                           "--max-requests", str(args.max_requests)]
                if args.corun_model:
                    if not args.corun_freeze_record:
                        raise ValueError("--corun-model requires validated --corun-freeze-record")
                    command += ["--corun-model", str(args.corun_model.resolve()), "--corun-freeze-record", str(args.corun_freeze_record.resolve())]
                event("POLICY_START=" + policy)
                wait_workers([spawn(command, root / f"{policy}.log")])
                event("POLICY_COMPLETE=" + policy)
            results = {policy: json.loads((root / "policies" / policy / "CLOSED_LOOP_COMPLETE.json").read_text()) for policy in policies}
            from scripts.latency_shape_probe_support import tuning_events
            prewarm_record = json.loads((root / "SHAPE_PREWARM.json").read_text())
            post_prewarm_tuning = {}
            for gpu in args.gpus:
                path = root / f"vllm_gpu_{gpu}.log"
                before = prewarm_record["logs"][str(gpu)]
                data = path.read_bytes()
                if hashlib.sha256(data[:before["bytes"]]).hexdigest() != before["sha256"]:
                    raise RuntimeError(f"GPU {gpu} engine log changed before prewarm boundary")
                post_prewarm_tuning[str(gpu)] = tuning_events(
                    data[before["bytes"]:].decode(errors="replace")
                )
            if any(post_prewarm_tuning.values()):
                raise RuntimeError("new Triton autotuning occurred after fixed-shape prewarm")
            write_json(root / "AUTHORITATIVE_SLO_REPORT.json", {
                "status": "PASS" if all(row["slo_pass"] for row in results.values()) else "FAIL",
                "policies": results,
                "post_prewarm_tuning_events": post_prewarm_tuning,
                "note": "single-run differences are not statistical evidence of algorithmic carbon improvement",
            })
        if args.stage == "energy-development":
            workers = []
            for index, gpu in enumerate(args.gpus):
                destination = root / "raw" / f"gpu_{gpu}"
                destination.mkdir(parents=True)
                workers.append(spawn([sys.executable, "-m", "scripts.measure_batch_energy",
                    "--api-base", f"http://127.0.0.1:{args.first_port + index}/v1",
                    "--model", args.served_model_name, "--tokenizer", str(args.model_dir.resolve()),
                    "--region-id", f"gpu_{gpu}", "--gpu-index", str(gpu),
                    "--prompt-tokens", "2048", "8192", "32768", "--output-tokens", "32", "128", "512",
                    "--concurrency", "1", "4", "8", "--repeats", "2",
                    "--output", str(destination / "measurements.jsonl")], destination / "worker.log"))
            wait_workers(workers)
        if args.stage == "corun-validation":
            from scripts.validate_corun_ttft_surface import validate
            report = validate(args.candidate, root, prereg)
            write_json(root / "INDEPENDENT_VALIDATION_REPORT.json", report)
            if report["status"] != "PASS":
                raise RuntimeError("candidate failed independent validation; failure retained")
        if args.stage == "latency-validation":
            from scripts.recover_latency_surface import validate
            report = validate(args.candidate, root)
            write_json(root / "INDEPENDENT_VALIDATION_REPORT.json", report)
            if report["status"] != "PASS":
                raise RuntimeError("latency candidate failed independent validation")
        status = "COMPLETE"
        write_json(root / "EXPERIMENT_COMPLETE.json", {"status": status, "stage": args.stage,
                   "note": "collection completion is not proof of SLO or carbon advantage", "completed_s": time.time()})
    except Exception as error:
        write_json(root / "FATAL.json", {"status": "FAIL", "error": f"{type(error).__name__}: {error}"})
        event("FAILED=" + str(error))
    finally:
        # Signal ONLY process groups started above, never pgrep/pkill patterns.
        for process in children:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 20
        while any(p.poll() is None for p in children) and time.monotonic() < deadline:
            time.sleep(.2)
        for process in children:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
        for handle in logs:
            handle.close()
    raise SystemExit(0 if status == "COMPLETE" else 1)


if __name__ == "__main__":
    main()
