#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODEL_DIR="${MODEL_DIR:-/root/models/Qwen3.5-27B}"
MODEL_ID="${MODEL_ID:-Qwen/Qwen3.5-27B}"
TARGET_MODEL="${TARGET_MODEL:-qwen35_27b}"
DOWNLOAD_MODEL="${DOWNLOAD_MODEL:-0}"
INSTALL_VLLM="${INSTALL_VLLM:-0}"
VLLM_VERSION="${VLLM_VERSION:-0.17.1}"
PIP_INDEX_URL="${PIP_INDEX_URL:-https://mirrors.aliyun.com/pypi/simple/}"
export PIP_INDEX_URL
export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
unset PIP_EXTRA_INDEX_URL || true

cd "$ROOT"
mkdir -p results/bootstrap "$(dirname "$MODEL_DIR")"

python3 scripts/probe_one_gpu_capability.py \
  --gpu-index "${GPU_INDEX:-0}" \
  --workdir /root \
  --target-model "$TARGET_MODEL" \
  --allow-missing-vllm \
  --output results/bootstrap/hardware_capability_report.json

if [[ ! -d .venv ]]; then
  # vLLM has tight torch/transformers constraints; isolate it from the platform image.
  python3 -m venv .venv
fi
source .venv/bin/activate

if ! command -v vllm >/dev/null 2>&1; then
  if [[ "$INSTALL_VLLM" != "1" ]]; then
    echo "VLLM_MISSING: rerun with INSTALL_VLLM=1 (default version: $VLLM_VERSION)" >&2
    exit 2
  fi
  python -m pip install --index-url "$PIP_INDEX_URL" "vllm==$VLLM_VERSION"
fi

python -m pip install --index-url "$PIP_INDEX_URL" -r requirements.txt
python -m pip install -e . --no-deps

python scripts/probe_one_gpu_capability.py \
  --gpu-index "${GPU_INDEX:-0}" \
  --workdir /root \
  --target-model "$TARGET_MODEL" \
  --output results/bootstrap/runtime_capability_report.json

if [[ "$DOWNLOAD_MODEL" == "1" && ! -f "$MODEL_DIR/config.json" ]]; then
  # Keep the platform's validated torch/vLLM/transformers stack untouched.
  python -m pip install --index-url "$PIP_INDEX_URL" --no-deps 'modelscope>=1.20,<2'
  modelscope download \
    --model "$MODEL_ID" \
    --local_dir "$MODEL_DIR" \
    2>&1 | tee results/bootstrap/model_download.log
fi

if [[ ! -f "$MODEL_DIR/config.json" ]]; then
  echo "MODEL_MISSING: $MODEL_DIR/config.json" >&2
  echo "Rerun with DOWNLOAD_MODEL=1 or copy the model before continuing." >&2
  exit 2
fi

python scripts/check_one_gpu.py \
  --model-dir "$MODEL_DIR" \
  --output results/bootstrap/environment_report.json

echo "BOOTSTRAP_COMPLETE"
