#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODEL_DIR="${MODEL_DIR:-/root/models/Qwen3.5-27B}"
SERVED_MODEL_NAME="${SERVED_MODEL_NAME:-Qwen3.5-27B}"
GPU_INDEX="${GPU_INDEX:-0}"
API_BASE="${API_BASE:-http://127.0.0.1:18000/v1}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
RUN_DIR="$ROOT/results/single_gpu_smoke/$STAMP"
GENERATED_CONFIG="$ROOT/configs/single_gpu_smoke.generated.yaml"
TELEMETRY_PID=""

cd "$ROOT"
source .venv/bin/activate
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
mkdir -p "$RUN_DIR" profiles

cleanup() {
  if [[ -n "$TELEMETRY_PID" ]] && kill -0 "$TELEMETRY_PID" 2>/dev/null; then
    kill -TERM "$TELEMETRY_PID" 2>/dev/null || true
    wait "$TELEMETRY_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT INT TERM

curl -fsS "${API_BASE%/v1}/health" >/dev/null
curl -fsS "$API_BASE/models" > "$RUN_DIR/models.json"

python scripts/calibrate_region.py \
  --region-id smoke_a \
  --api-base "$API_BASE" \
  --model "$SERVED_MODEL_NAME" \
  --tokenizer "$MODEL_DIR" \
  --gpu-index "$GPU_INDEX" \
  --prompt-tokens 1024 4096 8192 \
  --output-tokens 16 64 \
  --repeats 2 \
  --settle-s 0.5 \
  --max-concurrency 4 \
  --output "$RUN_DIR/smoke_source.json"

python scripts/prepare_single_gpu_smoke.py \
  --source-profile "$RUN_DIR/smoke_source.json" \
  --output-dir profiles \
  --config-template configs/single_gpu_smoke.yaml \
  --config-output "$GENERATED_CONFIG" \
  --model-dir "$MODEL_DIR" \
  --served-model-name "$SERVED_MODEL_NAME" \
  --api-base "$API_BASE"

python scripts/sample_gpu.py \
  --region-id single_gpu_smoke \
  --gpu-index "$GPU_INDEX" \
  --interval-ms 100 \
  --output "$RUN_DIR/gpu.csv" &
TELEMETRY_PID=$!
sleep 2

curl -fsS "${API_BASE%/v1}/metrics" > "$RUN_DIR/metrics_before.prom"

python scripts/run_main.py \
  --config "$GENERATED_CONFIG" \
  --policy carbon_affinity \
  --output "$RUN_DIR/requests.jsonl"

curl -fsS "${API_BASE%/v1}/metrics" > "$RUN_DIR/metrics_after.prom"

cleanup
TELEMETRY_PID=""

python scripts/audit_results.py \
  --config "$GENERATED_CONFIG" \
  --requests "$RUN_DIR/requests.jsonl" \
  --output "$RUN_DIR/audit.json"

python scripts/check_one_gpu.py \
  --model-dir "$MODEL_DIR" \
  --output "$RUN_DIR/environment_report.json"

python scripts/validate_single_gpu_smoke.py \
  --requests "$RUN_DIR/requests.jsonl" \
  --audit "$RUN_DIR/audit.json" \
  --telemetry "$RUN_DIR/gpu.csv" \
  --metrics-before "$RUN_DIR/metrics_before.prom" \
  --metrics-after "$RUN_DIR/metrics_after.prom"

touch "$RUN_DIR/SMOKE_COMPLETE"
echo "SINGLE_GPU_SMOKE_COMPLETE=$RUN_DIR"
