from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import yaml

from carbonaffinity.carbon import carbon_grams


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--future-work", type=Path, required=True)
    args = parser.parse_args()

    config = yaml.safe_load(args.config.read_text())
    routing = config["routing"]
    profiles = {
        region["id"]: json.loads(Path(region["profile"]).read_text())
        for region in config["regions"]
    }
    model = json.loads(args.future_work.read_text())
    work = model["workloads"]["agentic"]

    rows = [
        json.loads(line)
        for line in (
            args.run / "carbon_affinity" / "requests.jsonl"
        ).read_text().splitlines()
        if line.strip()
    ]
    sessions = defaultdict(list)
    for row in rows:
        sessions[row["session_id"]].append(row)
    session, rows = max(sessions.items(), key=lambda item: len(item[1]))

    def future(turn: int) -> dict:
        keys = sorted(int(key) for key in work)
        eligible = [key for key in keys if key <= turn]
        return work[str(max(eligible) if eligible else min(keys))]

    def future_energy(region: str, values: dict) -> float:
        profile = profiles[region]
        return (
            values["future_requests"] * profile["base_request_j"]
            + values["future_cold_tokens"]
            * profile["cold_prefill_j_per_token"]
            + values["future_cached_tokens"]
            * profile["cached_prefill_j_per_token"]
            + values["future_output_tokens"]
            * profile["decode_j_per_token"]
        )

    common_q = float(
        routing.get("carbon_common_error_quantile_lbs_per_mwh", 0.0)
    )
    diff_q = float(
        routing.get("carbon_diff_error_quantile_lbs_per_mwh", 0.0)
    )
    hysteresis = float(routing.get("migration_hysteresis_g", 0.0))
    first_expected = None
    first_robust = None
    output = []
    for index, row in enumerate(rows):
        candidates = row["decision"]["candidates"]
        incumbent = next(
            item for item in candidates
            if item["region_id"] == "local_region_a"
        )
        feasible = [item for item in candidates if item["slo_feasible"]]
        cleanest = min(
            feasible,
            key=lambda item: item["forecast_lbs_per_mwh"],
        )
        if cleanest["region_id"] == incumbent["region_id"]:
            continue
        turn = int(row.get("turn_id", index))
        values = future(turn)
        incumbent_total = incumbent["energy_j"] + future_energy(
            incumbent["region_id"], values
        )
        cleanest_total = cleanest["energy_j"] + future_energy(
            cleanest["region_id"], values
        )
        benefit = carbon_grams(
            incumbent_total, incumbent["forecast_lbs_per_mwh"]
        ) - carbon_grams(
            cleanest_total, cleanest["forecast_lbs_per_mwh"]
        )
        risk_energy = (
            abs(cleanest_total - incumbent_total) * common_q
            + 0.5 * (cleanest_total + incumbent_total) * diff_q
        )
        risk = carbon_grams(risk_energy, 1.0)
        expected_pass = benefit > hysteresis
        robust_pass = benefit > hysteresis + risk
        if expected_pass and first_expected is None:
            first_expected = turn
        if robust_pass and first_robust is None:
            first_robust = turn
        output.append({
            "turn": turn,
            "future_requests": values["future_requests"],
            "future_output_tokens": values["future_output_tokens"],
            "benefit_g": benefit,
            "risk_g": risk,
            "expected_pass": expected_pass,
            "robust_pass": robust_pass,
        })

    print(f"SESSION={session} TURNS={len(rows)}")
    print(
        f"{'turn':>5s}{'future_n':>10s}{'future_out':>12s}"
        f"{'benefit_g':>13s}{'risk_g':>11s}{'EV':>7s}{'robust':>9s}"
    )
    for item in output:
        print(
            f"{item['turn']:5d}{item['future_requests']:10.2f}"
            f"{item['future_output_tokens']:12.1f}"
            f"{item['benefit_g']:13.6f}{item['risk_g']:11.6f}"
            f"{str(item['expected_pass']):>7s}"
            f"{str(item['robust_pass']):>9s}"
        )
    print(f"FIRST_EXPECTED_VALUE_TRIGGER={first_expected}")
    print(f"FIRST_EXISTING_ROBUST_TRIGGER={first_robust}")
    print("LIFECYCLE_TRIGGER_ANALYSIS_COMPLETE")


if __name__ == "__main__":
    main()
