from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path


WORKLOADS = (
    ("high_reuse", 2, 3),
    ("low_reuse", 4, 5),
    ("burst", 6, 7),
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--repetitions", type=int, default=5)
    parser.add_argument("--seed", type=int, default=20260818)
    args = parser.parse_args()
    project = Path(__file__).resolve().parents[1]
    args.output_root.mkdir(parents=True, exist_ok=True)
    for repetition in range(args.repetitions):
        repetition_root = args.output_root / f"rep_{repetition:02d}"
        repetition_root.mkdir(parents=True, exist_ok=True)
        processes: list[tuple[str, subprocess.Popen, object]] = []
        for workload_index, (workload, gpu_a, gpu_b) in enumerate(WORKLOADS):
            output = repetition_root / workload
            if (output / "PIPELINE_COMPLETE.json").exists():
                continue
            log = (repetition_root / f"{workload}.launcher.log").open("a")
            order_seed = args.seed + repetition * len(WORKLOADS) + workload_index
            command = [
                sys.executable,
                str(project / "scripts/run_local_pair_campaign.py"),
                "--config", str(project / f"configs/local_{workload}.generated.yaml"),
                "--output-root", str(output),
                "--gpu-a", str(gpu_a),
                "--gpu-b", str(gpu_b),
                "--policy-order-seed", str(order_seed),
            ]
            process = subprocess.Popen(
                command, cwd=project, stdout=log, stderr=subprocess.STDOUT
            )
            processes.append((workload, process, log))
        failures = []
        for workload, process, log in processes:
            return_code = process.wait()
            log.close()
            if return_code:
                failures.append({"workload": workload, "return_code": return_code})
        if failures:
            raise RuntimeError(f"repetition {repetition} failed: {failures}")
        (repetition_root / "REPETITION_COMPLETE.json").write_text(
            json.dumps({
                "repetition": repetition,
                "completed_s": time.time(),
                "workloads": [item[0] for item in WORKLOADS],
            }, indent=2),
            encoding="utf-8",
        )
    (args.output_root / "REPETITIONS_COMPLETE.json").write_text(
        json.dumps({
            "repetitions": args.repetitions,
            "seed": args.seed,
            "completed_s": time.time(),
        }, indent=2),
        encoding="utf-8",
    )
    print(f"LOCAL_REPETITIONS_COMPLETE={args.output_root}")


if __name__ == "__main__":
    main()
