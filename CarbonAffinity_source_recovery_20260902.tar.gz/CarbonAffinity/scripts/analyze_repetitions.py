from __future__ import annotations

import argparse
import json
import math
import random
import statistics
from pathlib import Path

from scripts.summarize_guarded_results import dynamic_metrics


WORKLOADS = ("high_reuse", "low_reuse", "burst")
BASELINES = (
    "round_robin", "pressure_only", "cleanest_now", "sticky",
    "cedar_like", "carbon_affinity", "oracle_historical",
)


def bootstrap_ci(values: list[float], samples: int, seed: int) -> tuple[float, float]:
    rng = random.Random(seed)
    means = sorted(
        statistics.mean(rng.choice(values) for _ in values)
        for _ in range(samples)
    )
    return (
        means[math.floor(0.025 * (samples - 1))],
        means[math.ceil(0.975 * (samples - 1))],
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--config-root", type=Path, default=Path("configs"))
    parser.add_argument("--bootstrap-samples", type=int, default=100_000)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repetitions = sorted(
        path for path in args.root.glob("rep_*")
        if (path / "REPETITION_COMPLETE").exists()
    )
    if not repetitions:
        raise RuntimeError("no completed repetitions")
    raw: dict[str, dict[str, list[dict]]] = {
        workload: {policy: [] for policy in BASELINES}
        for workload in WORKLOADS
    }
    for repetition_index, repetition in enumerate(repetitions):
        for workload in WORKLOADS:
            config_path = args.config_root / f"local_{workload}.generated.yaml"
            for policy in BASELINES:
                policy_dir = repetition / workload / policy
                audit = json.loads((policy_dir / "audit.json").read_text())
                dynamic = dynamic_metrics(policy_dir, config_path, audit)
                raw[workload][policy].append({
                    "repetition": repetition_index,
                    **dynamic,
                    "ttft_violation_rate": audit["ttft_violation_rate"],
                    "tpot_violation_rate": audit["tpot_violation_rate"],
                    "migrations": audit["migrations"],
                    "fallbacks": audit["fallback_decisions"],
                })
    report: dict[str, object] = {
        "repetitions": len(repetitions),
        "bootstrap_samples": args.bootstrap_samples,
        "workloads": {},
    }
    for workload_index, workload in enumerate(WORKLOADS):
        pressure = [
            row["dynamic_carbon_g"]
            for row in raw[workload]["pressure_only"]
        ]
        policy_reports = []
        for policy_index, policy in enumerate(BASELINES):
            rows = raw[workload][policy]
            savings = [
                100.0 * (reference - row["dynamic_carbon_g"]) / reference
                for reference, row in zip(pressure, rows)
            ]
            low, high = bootstrap_ci(
                savings, args.bootstrap_samples,
                3100 + workload_index * 100 + policy_index,
            )
            policy_reports.append({
                "policy": policy,
                "dynamic_carbon_g_mean": statistics.mean(
                    row["dynamic_carbon_g"] for row in rows
                ),
                "dynamic_energy_j_mean": statistics.mean(
                    row["dynamic_energy_j"] for row in rows
                ),
                "savings_vs_pressure_pct_mean": statistics.mean(savings),
                "savings_vs_pressure_pct_bootstrap_95_ci": [low, high],
                "wins_vs_pressure": sum(value > 0 for value in savings),
                "ttft_violation_rate_mean": statistics.mean(
                    row["ttft_violation_rate"] for row in rows
                ),
                "tpot_violation_rate_mean": statistics.mean(
                    row["tpot_violation_rate"] for row in rows
                ),
                "migrations_mean": statistics.mean(
                    row["migrations"] for row in rows
                ),
                "fallbacks_mean": statistics.mean(
                    row["fallbacks"] for row in rows
                ),
                "per_repetition_savings_pct": savings,
            })
        ca_rows = raw[workload]["carbon_affinity"]
        paired = {}
        for baseline_index, baseline in enumerate(BASELINES):
            if baseline == "carbon_affinity":
                continue
            baseline_rows = raw[workload][baseline]
            improvements = [
                100.0 * (base["dynamic_carbon_g"] - ca["dynamic_carbon_g"])
                / base["dynamic_carbon_g"]
                for ca, base in zip(ca_rows, baseline_rows)
            ]
            low, high = bootstrap_ci(
                improvements, args.bootstrap_samples,
                9100 + workload_index * 100 + baseline_index,
            )
            paired[baseline] = {
                "ca_improvement_pct_mean": statistics.mean(improvements),
                "bootstrap_95_ci": [low, high],
                "ca_wins": sum(value > 0 for value in improvements),
                "per_repetition_pct": improvements,
            }
        report["workloads"][workload] = {
            "policies": policy_reports,
            "paired_carbon_affinity_comparisons": paired,
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"repetitions={len(repetitions)}")
    for workload, payload in report["workloads"].items():
        print("\n" + "=" * 124)
        print(workload.upper())
        print("=" * 124)
        print(
            f"{'policy':20s}{'saving_mean':>14s}{'95% bootstrap CI':>25s}"
            f"{'wins':>8s}{'TTFTviol':>12s}{'TPOTviol':>12s}{'migrations':>12s}"
        )
        for row in payload["policies"]:
            low, high = row["savings_vs_pressure_pct_bootstrap_95_ci"]
            print(
                f"{row['policy']:20s}{row['savings_vs_pressure_pct_mean']:14.2f}"
                f"[{low:9.2f}, {high:9.2f}]{row['wins_vs_pressure']:8d}/5"
                f"{100*row['ttft_violation_rate_mean']:11.2f}%"
                f"{100*row['tpot_violation_rate_mean']:11.2f}%"
                f"{row['migrations_mean']:12.2f}"
            )
        print("\nCarbonAffinity paired advantage (positive means CA is better):")
        for baseline, comparison in payload["paired_carbon_affinity_comparisons"].items():
            low, high = comparison["bootstrap_95_ci"]
            print(
                f"  vs {baseline:18s}: {comparison['ca_improvement_pct_mean']:8.2f}% "
                f"CI=[{low:8.2f}, {high:8.2f}], wins={comparison['ca_wins']}/5"
            )
    print(f"\nREPETITION_ANALYSIS_COMPLETE={args.output}")


if __name__ == "__main__":
    main()
