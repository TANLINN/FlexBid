"""Prepare a five-policy runtime gate strictly inside validated model domains."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

import yaml


PROFILE_NAMES = (
    "local_region_a",
    "local_region_b",
    "high_reuse_a",
    "high_reuse_b",
    "low_reuse_a",
    "low_reuse_b",
    "burst_a",
    "burst_b",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path: Path) -> dict:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return payload


def validated(report: dict, candidate: Path) -> None:
    if report.get("status") != "PASS":
        raise ValueError("independent validation report is not PASS")
    recorded = report.get("candidate_sha256")
    if recorded is not None and recorded != digest(candidate):
        raise ValueError("candidate bytes do not match validation report")
    failed = report.get("failed_checks")
    if failed:
        raise ValueError("independent validation report contains failed checks")


def residual_frozen(record: dict, model: Path) -> None:
    status = str(record.get("status", ""))
    if "FROZEN" not in status:
        raise ValueError("residual latency deployment record is not frozen")
    expected = record.get("model_sha256") or record.get("candidate_sha256")
    if expected is not None and expected != digest(model):
        raise ValueError("residual latency model does not match freeze record")


def trace_rows() -> list[dict]:
    rows = []
    for index in range(8):
        arrival = index * 9000.0
        prime_id = f"cache-prime-{index}"
        session = f"cache-session-{index}"
        rows.append({
            "request_id": prime_id,
            "session_id": session,
            "turn_id": 0,
            "arrival_ms": arrival,
            "prompt_tokens": 8192,
            "shared_prefix_tokens": 0,
            "max_output_tokens": 64,
            "ttft_slo_ms": 16000,
            "tpot_slo_ms": 80,
            "workload": "bounded_runtime_gate",
        })
        rows.append({
            "request_id": f"cache-reuse-{index}",
            "session_id": session,
            "turn_id": 1,
            "parent_request_id": prime_id,
            "tool_delay_ms": 200,
            "arrival_ms": arrival,
            "prompt_tokens": 8192,
            "shared_prefix_tokens": 7840,
            "max_output_tokens": 64,
            "ttft_slo_ms": 16000,
            "tpot_slo_ms": 80,
            "workload": "bounded_runtime_gate",
        })
    burst_start = 80000.0
    for burst in range(8):
        for member in range(3):
            request_id = f"cold-burst-{burst}-{member}"
            rows.append({
                "request_id": request_id,
                "session_id": request_id,
                "turn_id": 0,
                "arrival_ms": burst_start + burst * 9000.0,
                "prompt_tokens": 16384,
                "shared_prefix_tokens": 0,
                "max_output_tokens": 64,
                "ttft_slo_ms": 16000,
                "tpot_slo_ms": 80,
                "workload": "bounded_runtime_gate",
            })
    return sorted(rows, key=lambda row: (row["arrival_ms"], row["request_id"]))


def hardware_profile(
    name: str,
    energy: dict,
    residual_model: dict,
) -> dict:
    cold_axis = residual_model["surfaces"]["cold"]["axes"]["prompt_tokens"]
    return {
        "region_id": name,
        "accelerator": "NVIDIA A800",
        "model": "Qwen3.5-27B",
        "base_request_j": float(energy["base_request_j"]),
        "cold_prefill_j_per_token": float(energy["cold_prefill_j_per_token"]),
        "cached_prefill_j_per_token": float(energy["cached_prefill_j_per_token"]),
        "decode_j_per_token": float(energy["decode_j_per_token"]),
        "base_ttft_ms": 0.0,
        "cold_prefill_ms_per_token": 0.0,
        "cached_prefill_ms_per_token": 0.0,
        "base_tpot_ms": 0.0,
        "queue_ttft_ms_per_request": 0.0,
        "uncertainty_margin": 1.0,
        "max_prompt_tokens": int(max(cold_axis)),
        "max_output_tokens": 64,
        "max_concurrency": 3,
        "batch_energy_model": energy["batch_energy_model"],
        "latency_surface_model": residual_model,
    }


def prepare(args: argparse.Namespace) -> dict:
    output = args.output_root.resolve()
    if output.exists():
        raise FileExistsError(output)
    output.mkdir(parents=True)

    energy_candidate = read_json(args.energy_candidate)
    energy_validation = read_json(args.energy_validation)
    validated(energy_validation, args.energy_candidate)
    profiles = energy_candidate.get("profiles")
    if not isinstance(profiles, dict) or set(profiles) != set(map(str, range(8))):
        raise ValueError("cache-energy candidate must contain GPU profiles 0..7")

    residual_model = read_json(args.residual_model)
    residual_record = read_json(args.residual_freeze_record)
    residual_frozen(residual_record, args.residual_model)
    if residual_model.get("model_kind") != "residual_latency_monotone_candidate_v1":
        raise ValueError("wrong residual latency model kind")

    observable_model = read_json(args.observable_candidate)
    observable_validation = read_json(args.observable_validation)
    validated(observable_validation, args.observable_candidate)
    if observable_model.get("model_kind") != "observable_corun_stratified_monotone_candidate_v1":
        raise ValueError("wrong observable co-run model kind")
    if observable_validation.get("bounded_primary_validation_passed") is not True:
        raise ValueError("bounded observable co-run validation did not pass")
    if observable_validation.get("continuous_arrival_tpot_validated") is not False:
        raise ValueError("unexpected observable validation scope declaration")

    model_dir = output / "models"
    profile_dir = output / "profiles"
    model_dir.mkdir()
    profile_dir.mkdir()
    observable_copy = model_dir / "observable_corun_v1.json"
    observable_report_copy = model_dir / "observable_corun_validation.json"
    shutil.copyfile(args.observable_candidate, observable_copy)
    shutil.copyfile(args.observable_validation, observable_report_copy)
    freeze_path = model_dir / "observable_corun_v1.freeze.json"
    freeze_path.write_text(json.dumps({
        "status": "FROZEN",
        "model_sha256": digest(observable_copy),
        "validation_report": str(observable_report_copy.resolve()),
        "validation_sha256": digest(observable_report_copy),
        "scope": {
            "runtime_cap": 784,
            "victim_output_tokens": 64,
            "backgrounds": "at most two; exact validated phase strata",
            "continuous_arrival_tpot_validated": False,
        },
    }, indent=2), encoding="utf-8")

    profile_paths = []
    for gpu, name in enumerate(PROFILE_NAMES):
        path = profile_dir / f"{name}.json"
        path.write_text(json.dumps(
            hardware_profile(name, profiles[str(gpu)], residual_model),
            indent=2,
        ), encoding="utf-8")
        profile_paths.append(path)

    trace = output / "bounded_trace.jsonl"
    rows = trace_rows()
    trace.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")

    base_config = args.base_config.resolve()
    base_root = base_config.parent.parent
    config = yaml.safe_load(base_config.read_text(encoding="utf-8"))
    if not isinstance(config, dict) or len(config.get("regions", [])) != 8:
        raise ValueError("base config must contain exactly eight regions")
    config["experiment"]["name"] = "bounded_validated_runtime_gate"
    config["experiment"]["trace"] = str(trace.resolve())
    carbon_trace = Path(config["carbon"]["trace"])
    if not carbon_trace.is_absolute():
        carbon_trace = base_root / carbon_trace
    config["carbon"]["trace"] = str(carbon_trace.resolve())
    for region, profile_path in zip(config["regions"], profile_paths):
        region["profile"] = str(profile_path.resolve())
        site_manifest = Path(region["site_manifest"])
        if not site_manifest.is_absolute():
            site_manifest = base_root / site_manifest
        region["site_manifest"] = str(site_manifest.resolve())
        region["admission_concurrency"] = 3
    config["runtime"]["max_in_flight"] = 24
    config["artifact_metadata"] = {
        "evaluation_role": "bounded_validated_runtime_gate",
        "runtime_cap": 784,
        "victim_output_tokens": 64,
        "continuous_arrival_tpot_validated": False,
        "claim_scope": "bounded five-policy systems smoke; not a real-trace or statistical advantage claim",
    }
    config_path = output / "config.yaml"
    config_path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")

    manifest = {
        "status": "READY",
        "requests": len(rows),
        "config": str(config_path),
        "trace": str(trace),
        "observable_model": str(observable_copy),
        "observable_freeze_record": str(freeze_path),
        "profiles": [str(path) for path in profile_paths],
        "scope": config["artifact_metadata"],
    }
    (output / "RUNTIME_GATE_INPUTS.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8",
    )
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-config", type=Path, required=True)
    parser.add_argument("--energy-candidate", type=Path, required=True)
    parser.add_argument("--energy-validation", type=Path, required=True)
    parser.add_argument("--residual-model", type=Path, required=True)
    parser.add_argument("--residual-freeze-record", type=Path, required=True)
    parser.add_argument("--observable-candidate", type=Path, required=True)
    parser.add_argument("--observable-validation", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    manifest = prepare(parser.parse_args())
    print(json.dumps(manifest, indent=2))
    print("BOUNDED_RUNTIME_GATE_INPUTS_READY")


if __name__ == "__main__":
    main()
