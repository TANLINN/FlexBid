"""Development integrity/readiness only. Never validate or freeze a model here."""
import hashlib
import json
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256
from scripts.latency_residual_protocol import GPUS, OUTPUT, VERSION, cases, design, features, result_checks
from scripts.latency_shape_probe_support import tuning_events


def audit(root):
    root = Path(root)
    rows = read_rows(root / "raw")
    prereg = json.loads((root / "PREREGISTRATION.json").read_text())
    launch = json.loads((root / "LAUNCH.json").read_text())
    prewarm = json.loads((root / "SHAPE_PREWARM.json").read_text())
    registered = {c["case_id"]: c for c in cases()}
    identities = [(r.get("gpu_index"), r.get("case_id")) for r in rows]
    expected = {(g, c) for g in GPUS for c in registered}
    failures = []
    by_gpu = {str(g): 0 for g in GPUS}
    for row in rows:
        case = registered.get(row.get("case_id"))
        if case is None:
            failures.append({"case_id": row.get("case_id"), "error": "unregistered case"})
            continue
        checks = {"registered_case_fields": all(row.get(k) == v for k, v in case.items()),
                  "protocol": row.get("protocol") == VERSION,
                  "runtime_evidence": row.get("runtime_evidence_sha256") == sha256(root / "LAUNCH.json"),
                  "exact_result_count": len(row.get("results", [])) == case["concurrency"]}
        checks["actual_request_checks"] = all(all(result_checks(r, case["prompt_tokens"], OUTPUT,
            case["cached_context_target"] if case["mode"] == "warm" else None).values())
            for r in row.get("results", []))
        checks["cache_features_recomputed"] = row.get("cache_features") == [features(r) for r in row.get("results", [])]
        checks["recorded_checks_recomputed"] = row.get("result_checks") == [result_checks(
            r, case["prompt_tokens"], OUTPUT, case["cached_context_target"] if case["mode"] == "warm" else None)
            for r in row.get("results", [])]
        salts = row.get("cache_salts", [])
        checks["salts_recorded"] = len(salts) == case["concurrency"] and all(isinstance(s, str) and s for s in salts)
        checks["salt_shape"] = len(set(salts)) == (1 if case["mode"] == "warm" else case["concurrency"])
        if case["mode"] == "warm":
            checks["prime_success"] = all(result_checks(row.get("prime") or {}, case["prompt_tokens"], 1).values())
            checks["residual_observed_exact"] = all(f["observed_uncached_tokens"] == case["residual_target"]
                                                    for f in row.get("cache_features", []))
        else:
            checks["cold_has_no_prime"] = row.get("prime") is None
        if not all(checks.values()):
            failures.append({"gpu": row.get("gpu_index"), "case_id": row["case_id"],
                             "failed_checks": [k for k, v in checks.items() if not v]})
        if str(row.get("gpu_index")) in by_gpu:
            by_gpu[str(row["gpu_index"])] += 1
    post_tuning = {}
    log_prefix_ok = True
    for gpu in GPUS:
        data = (root / f"vllm_gpu_{gpu}.log").read_bytes()
        snapshot = prewarm["logs"][str(gpu)]
        prefix_ok = hashlib.sha256(data[:snapshot["bytes"]]).hexdigest() == snapshot["sha256"]
        log_prefix_ok &= prefix_ok
        post_tuning[str(gpu)] = tuning_events(data[snapshot["bytes"]:].decode(errors="replace")) if prefix_ok else []
    checks = {"exact_864_cases": len(identities) == len(expected) and set(identities) == expected,
              "108_rows_per_gpu": all(n == len(registered) for n in by_gpu.values()),
              "preregistered_design_unchanged": prereg.get("design") == design(),
              "registered_expected_rows": prereg.get("expected_rows") == len(expected),
              "cap784_evidence": launch.get("runtime_cap") == 784 and launch.get("effective_cap_verified") is True,
              "cache_block784_evidence": launch.get("cache_block784_verified") is True,
              "eight_gpu_prewarm_verified": prewarm.get("gpu_indices") == list(GPUS)
                  and prewarm.get("requests") == 64 and prewarm["checks"]["all_shape_keys_observed"] is True,
              "all_raw_checks": not failures,
              "log_prefixes_unchanged": log_prefix_ok,
              "no_new_autotuning_after_prewarm": not any(post_tuning.values()),
              "code_unchanged": all(Path(p).is_file() and sha256(p) == h for p, h in prereg["code_sha256"].items())}
    return {"status": "PASS" if all(checks.values()) else "FAIL",
            "stage": "DEVELOPMENT_DATA_ONLY", "candidate_frozen": False,
            "checks": checks, "rows": len(rows), "rows_by_gpu": by_gpu,
            "failed_cases": failures, "post_prewarm_tuning_events": post_tuning,
            "cold_missing_cache_readings": sum(r.get("cached_prompt_tokens_observed") is None
                for row in rows if row["mode"] == "cold" for r in row["results"]),
            "note": "No fitting, heldout validation, model freeze, SLO or carbon-advantage claim."}
