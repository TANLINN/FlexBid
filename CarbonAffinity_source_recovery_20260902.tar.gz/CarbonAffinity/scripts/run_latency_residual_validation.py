"""Independent locked-candidate run; startup/ownership reused from tested supervisor."""
from scripts.run_latency_residual_campaign import main
from scripts import residual_latency_validation

if __name__ == "__main__":
    main(campaign=residual_latency_validation)
