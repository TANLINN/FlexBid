param([switch]$PrintOnly)
$ErrorActionPreference = 'Stop'
$validationProject = Split-Path $PSScriptRoot -Parent
$validationPython = Join-Path $validationProject '.venv-recovery/Scripts/python.exe'
Push-Location $validationProject
try {
    $validationLines = & $validationPython -m scripts.build_latency_residual_validation_transfer
    if ($LASTEXITCODE -ne 0) { throw 'Validation command generation failed; nothing copied or started.' }
} finally {
    Pop-Location
}
$validationCommand = ($validationLines -join "`n") + "`n"
if ($PrintOnly) { Write-Output $validationCommand; exit 0 }
Set-Clipboard -Value $validationCommand
Write-Host 'Independent validation command copied. Paste ONCE in the SERVER terminal.'
Write-Host 'Locked candidate: 6e334c42c8de3bb64a41ebb594aef4785fd2ed0325230c8c9ea1c3cf33692c85'
Write-Host 'Expected: 432 batches, 54/GPU. No refit, freeze, or overwrite of earlier results.'
