from __future__ import annotations

import argparse
import json
import math
import random
import statistics
from collections import defaultdict
from pathlib import Path

from scripts.summarize_guarded_results import dynamic_metrics


POLICIES = (
    "round_robin", "pressure_only", "cleanest_now", "sticky",
    "cedar_like", "carbon_affinity", "oracle_historical",
)


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, math.ceil(quantile * len(ordered)) - 1)]


def bootstrap_ci(values: list[float], samples: int, seed: int) -> list[float]:
    rng = random.Random(seed)
    means = sorted(
        statistics.mean(rng.choice(values) for _ in values)
        for _ in range(samples)
    )
    return [means[int(0.025 * (samples - 1))], means[int(0.975 * (samples - 1))]]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--config-root", type=Path, default=Path("configs"))
    parser.add_argument("--bootstrap-samples", type=int, default=100_000)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    repetitions = sorted(args.root.glob("rep_[0-9][0-9]"))
    if len(repetitions) != 5:
        raise RuntimeError(f"expected 5 repetitions, found {len(repetitions)}")

    rep_metrics: dict[int, dict[str, dict]] = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
    rep_latency: dict[int, dict[str, dict[str, list[float]]]] = defaultdict(
        lambda: defaultdict(lambda: {"ttft": [], "tpot": []})
    )
    window_cells: dict[int, dict[str, list[dict]]] = defaultdict(lambda: defaultdict(list))

    for rep_index, repetition in enumerate(repetitions):
        for window_index in range(4):
            window = repetition / f"window_{window_index:02d}"
            if not (window / "PIPELINE_COMPLETE.json").exists():
                raise RuntimeError(f"incomplete window: {window}")
            config = args.config_root / f"real_window_{window_index:02d}.generated.yaml"
            for policy in POLICIES:
                policy_dir = window / policy
                audit = json.loads((policy_dir / "audit.json").read_text())
                if not audit.get("passed"):
                    raise RuntimeError(f"failed audit: {policy_dir}")
                dynamic = dynamic_metrics(policy_dir, config, audit)
                rows = [
                    json.loads(line)
                    for line in (policy_dir / "requests.jsonl").read_text().splitlines()
                    if line.strip()
                ]
                ttft = [float(row["completion"]["ttft_ms"]) for row in rows if row["completion"].get("ttft_ms") is not None]
                tpot = [float(row["completion"]["tpot_ms"]) for row in rows if row["completion"].get("tpot_ms") is not None]
                cache_pairs = []
                for row in rows:
                    observed = row["completion"].get("cached_prompt_tokens_observed")
                    if observed is None:
                        continue
                    selected = row["decision"]["selected_region"]
                    predicted = next(
                        candidate["cached_tokens"] for candidate in row["decision"]["candidates"]
                        if candidate["region_id"] == selected
                    )
                    cache_pairs.append((int(predicted), int(observed)))
                cell = {
                    "dynamic_carbon_g": dynamic["dynamic_carbon_g"],
                    "dynamic_energy_j": dynamic["dynamic_energy_j"],
                    "total_carbon_g": audit["measured_operational_carbon_g"],
                    "total_energy_j": audit["measured_gpu_energy_j"],
                    "requests": len(rows),
                    "ttft_violations": sum(bool(row.get("ttft_violation")) for row in rows),
                    "tpot_violations": sum(bool(row.get("tpot_violation")) for row in rows),
                    "migrations": audit["migrations"],
                    "fallbacks": audit["fallback_decisions"],
                    "cache_abs_error": sum(abs(left - right) for left, right in cache_pairs),
                    "cache_correct": sum((left > 0) == (right > 0) for left, right in cache_pairs),
                    "cache_observations": len(cache_pairs),
                }
                window_cells[window_index][policy].append(cell)
                for key, value in cell.items():
                    rep_metrics[rep_index][policy][key] += value
                rep_latency[rep_index][policy]["ttft"].extend(ttft)
                rep_latency[rep_index][policy]["tpot"].extend(tpot)

    policy_reports = {}
    for policy_index, policy in enumerate(POLICIES):
        rows = [rep_metrics[index][policy] for index in range(5)]
        references = [rep_metrics[index]["pressure_only"]["dynamic_carbon_g"] for index in range(5)]
        savings = [100.0 * (reference - row["dynamic_carbon_g"]) / reference for reference, row in zip(references, rows)]
        all_ttft = sum((rep_latency[index][policy]["ttft"] for index in range(5)), [])
        all_tpot = sum((rep_latency[index][policy]["tpot"] for index in range(5)), [])
        requests = sum(row["requests"] for row in rows)
        observations = sum(row["cache_observations"] for row in rows)
        policy_reports[policy] = {
            "dynamic_carbon_g_mean_per_repetition": statistics.mean(row["dynamic_carbon_g"] for row in rows),
            "dynamic_energy_j_mean_per_repetition": statistics.mean(row["dynamic_energy_j"] for row in rows),
            "total_carbon_g_mean_per_repetition": statistics.mean(row["total_carbon_g"] for row in rows),
            "savings_vs_pressure_pct_mean": statistics.mean(savings),
            "savings_vs_pressure_pct_bootstrap_95_ci": bootstrap_ci(savings, args.bootstrap_samples, 4100 + policy_index),
            "wins_vs_pressure": sum(value > 0 for value in savings),
            "per_repetition_savings_pct": savings,
            "ttft_violation_rate": sum(row["ttft_violations"] for row in rows) / requests,
            "tpot_violation_rate": sum(row["tpot_violations"] for row in rows) / requests,
            "ttft_p95_ms": percentile(all_ttft, 0.95),
            "tpot_p95_ms": percentile(all_tpot, 0.95),
            "migrations_mean_per_repetition": statistics.mean(row["migrations"] for row in rows),
            "fallbacks_mean_per_repetition": statistics.mean(row["fallbacks"] for row in rows),
            "cache_prediction_mae_tokens": sum(row["cache_abs_error"] for row in rows) / observations if observations else None,
            "cache_hit_classification_accuracy": sum(row["cache_correct"] for row in rows) / observations if observations else None,
        }

    paired = {}
    for baseline_index, baseline in enumerate(POLICIES):
        if baseline == "carbon_affinity":
            continue
        values = []
        for rep_index in range(5):
            base = rep_metrics[rep_index][baseline]["dynamic_carbon_g"]
            carbon_affinity = rep_metrics[rep_index]["carbon_affinity"]["dynamic_carbon_g"]
            values.append(100.0 * (base - carbon_affinity) / base)
        paired[baseline] = {
            "carbon_affinity_advantage_pct_mean": statistics.mean(values),
            "bootstrap_95_ci": bootstrap_ci(values, args.bootstrap_samples, 8100 + baseline_index),
            "wins": sum(value > 0 for value in values),
            "per_repetition_pct": values,
        }

    per_window = {}
    for window_index in range(4):
        reference = window_cells[window_index]["pressure_only"]
        window_report = {}
        for policy_index, policy in enumerate(POLICIES):
            values = [
                100.0 * (base["dynamic_carbon_g"] - row["dynamic_carbon_g"]) / base["dynamic_carbon_g"]
                for base, row in zip(reference, window_cells[window_index][policy])
            ]
            window_report[policy] = {
                "savings_vs_pressure_pct_mean": statistics.mean(values),
                "bootstrap_95_ci": bootstrap_ci(values, args.bootstrap_samples, 12100 + window_index * 100 + policy_index),
                "wins": sum(value > 0 for value in values),
            }
        per_window[f"window_{window_index:02d}"] = window_report

    report = {
        "experimental_scope": "same-host eight-A800 mechanism study with real TraceLab requests and NESO regional carbon traces",
        "statistical_unit": "five repetitions; each repetition aggregates four fixed real-trace windows",
        "bootstrap_samples": args.bootstrap_samples,
        "policy_reports": policy_reports,
        "paired_carbon_affinity_comparisons": paired,
        "per_window_reports": per_window,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")

    print(f"{'policy':20s}{'saving% [95% CI]':>28s}{'wins':>8s}{'TTFTv':>10s}{'TPOTv':>10s}{'TTFTp95':>12s}{'TPOTp95':>12s}")
    for policy in POLICIES:
        row = policy_reports[policy]
        low, high = row["savings_vs_pressure_pct_bootstrap_95_ci"]
        print(
            f"{policy:20s}{row['savings_vs_pressure_pct_mean']:8.2f} [{low:7.2f},{high:7.2f}]"
            f"{row['wins_vs_pressure']:7d}/5{100*row['ttft_violation_rate']:9.2f}%"
            f"{100*row['tpot_violation_rate']:9.2f}%{row['ttft_p95_ms']:12.1f}{row['tpot_p95_ms']:12.1f}"
        )
    print("\nCarbonAffinity paired advantage:")
    for baseline, row in paired.items():
        low, high = row["bootstrap_95_ci"]
        print(f"  vs {baseline:18s}: {row['carbon_affinity_advantage_pct_mean']:7.2f}% [{low:7.2f},{high:7.2f}], wins={row['wins']}/5")
    print("\nCarbonAffinity savings vs pressure by real window:")
    for window, rows in per_window.items():
        row = rows["carbon_affinity"]
        low, high = row["bootstrap_95_ci"]
        print(f"  {window}: {row['savings_vs_pressure_pct_mean']:7.2f}% [{low:7.2f},{high:7.2f}], wins={row['wins']}/5")
    print(f"\nREAL_CAMPAIGN_ANALYSIS_COMPLETE={args.output}")


if __name__ == "__main__":
    main()
