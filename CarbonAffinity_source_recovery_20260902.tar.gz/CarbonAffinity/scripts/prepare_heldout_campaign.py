from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import yaml

import prepare_real_campaign as prep


ROOT = Path(__file__).resolve().parents[1]
COUNT = 8
WINDOW_MINUTES = 60
MINIMUM_ROWS = 80
MAX_REQUESTS = 120
TIME_COMPRESSION = 30.0
CARBON_COVERAGE_S = 7200.0


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    trace_path = ROOT / "data/raw/syfi_coding_trace.jsonl.gz"
    carbon_path = ROOT / "data/raw/regional_carbon_intensity.csv"
    development_path = ROOT / "results/real_data_preparation_manifest.json"
    development = json.loads(development_path.read_text())
    development_starts = [
        datetime.fromisoformat(row["source_start_utc"])
        for row in development["windows"]
    ]
    development_ranges = [
        (start, start + timedelta(minutes=WINDOW_MINUTES))
        for start in development_starts
    ]

    carbon_timestamps, carbon_values = prep.load_neso(carbon_path)
    trace_rows = prep.load_tracelab(
        trace_path, carbon_timestamps[1], carbon_timestamps[-1]
    )
    development_sessions = {
        str(row["session_id"])
        for row in trace_rows
        if any(left <= row["_timestamp"] < right for left, right in development_ranges)
    }

    buckets: dict[datetime, list[dict]] = defaultdict(list)
    for row in trace_rows:
        timestamp = row["_timestamp"]
        buckets[timestamp.replace(minute=0, second=0, microsecond=0)].append(row)

    candidates: list[datetime] = []
    for start, values in sorted(buckets.items()):
        sessions: dict[str, int] = defaultdict(int)
        for row in values:
            sessions[str(row["session_id"])] += 1
        repeat_rows = sum(max(0, amount - 1) for amount in sessions.values())
        overlaps_development = any(
            left < start + timedelta(minutes=WINDOW_MINUTES) and start < right
            for left, right in development_ranges
        )
        touches_development_session = any(
            session in development_sessions for session in sessions
        )
        if (
            len(values) >= MINIMUM_ROWS
            and repeat_rows >= 10
            and not overlaps_development
            and not touches_development_session
        ):
            candidates.append(start)

    if len(candidates) < COUNT:
        raise RuntimeError(f"only {len(candidates)} held-out candidates; need {COUNT}")
    positions = [
        round(index * (len(candidates) - 1) / (COUNT - 1))
        for index in range(COUNT)
    ]
    selected = [candidates[position] for position in positions]
    if len(set(selected)) != COUNT:
        raise RuntimeError("held-out quantile selection produced duplicate windows")

    preregistration = {
        "schema_version": 1,
        "status": "selected_before_model_refit_or_gpu_execution",
        "selection_rule": (
            "eight even chronological quantiles among hourly windows with at least "
            "80 requests and 10 repeated-session rows after excluding every window "
            "overlapping development time and every window touching a development session"
        ),
        "candidate_count": len(candidates),
        "candidate_positions": positions,
        "development_manifest_sha256": sha256(development_path),
        "raw_trace_sha256": sha256(trace_path),
        "raw_carbon_sha256": sha256(carbon_path),
        "selected_source_starts_utc": [start.isoformat() for start in selected],
    }
    preregistration_path = ROOT / "results/heldout_pre_registration_manifest.json"
    preregistration_path.write_text(json.dumps(preregistration, indent=2))

    heldout_sessions: set[str] = set()
    materialized = []
    for heldout_index, start in enumerate(selected):
        pair_index = heldout_index % len(prep.PAIR_LAYOUT)
        normalized = prep.normalize_window(
            trace_rows, start, WINDOW_MINUTES, TIME_COMPRESSION, MAX_REQUESTS
        )
        heldout_sessions.update(str(row["session_id"]) for row in normalized)
        _, _, _, _, region_a, region_b = prep.PAIR_LAYOUT[pair_index]
        carbon_rows, q95, common_q, differential_q = prep.carbon_rows(
            carbon_timestamps,
            carbon_values,
            start,
            WINDOW_MINUTES,
            TIME_COMPRESSION,
            CARBON_COVERAGE_S,
            region_a,
            region_b,
        )
        trace_output = ROOT / f"data/normalized/tracelab_heldout_window_{heldout_index:02d}.jsonl"
        carbon_output = ROOT / f"data/carbon/neso_heldout_window_{heldout_index:02d}.csv"
        config_output = ROOT / f"configs/heldout_window_{heldout_index:02d}.generated.yaml"
        trace_output.parent.mkdir(parents=True, exist_ok=True)
        carbon_output.parent.mkdir(parents=True, exist_ok=True)
        trace_output.write_text(
            "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in normalized)
        )
        with carbon_output.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=(
                    "timestamp",
                    "region_id",
                    "forecast_lbs_per_mwh",
                    "historical_lbs_per_mwh",
                ),
            )
            writer.writeheader()
            writer.writerows(carbon_rows)
        config = prep.build_config(
            pair_index, trace_output, carbon_output, q95, common_q, differential_q
        )
        config["experiment"]["name"] = f"heldout_tracelab_neso_{heldout_index:02d}"
        config["routing"]["lifecycle_migration"]["future_work_model"] = (
            "profiles/session_future_work_heldout_frozen.json"
        )
        config.setdefault("artifact_metadata", {}).update(
            {
                "split": "heldout",
                "heldout_index": heldout_index,
                "selection_manifest": "results/heldout_pre_registration_manifest.json",
            }
        )
        config_output.write_text(yaml.safe_dump(config, sort_keys=False))
        materialized.append(
            {
                "index": heldout_index,
                "pair_index": pair_index,
                "source_start_utc": start.isoformat(),
                "requests": len(normalized),
                "sessions": len({row["session_id"] for row in normalized}),
                "repeat_session_rows": sum("parent_request_id" in row for row in normalized),
                "trace": trace_output.relative_to(ROOT).as_posix(),
                "carbon": carbon_output.relative_to(ROOT).as_posix(),
                "config": config_output.relative_to(ROOT).as_posix(),
            }
        )

    if development_sessions & heldout_sessions:
        raise RuntimeError("development and held-out session sets overlap")
    materialization_path = ROOT / "results/heldout_materialization_manifest.json"
    materialization_path.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "pre_registration": preregistration_path.relative_to(ROOT).as_posix(),
                "development_sessions": len(development_sessions),
                "heldout_sessions": len(heldout_sessions),
                "session_overlap": 0,
                "windows": materialized,
            },
            indent=2,
        )
    )
    print(json.dumps(preregistration, indent=2))
    print(json.dumps(materialized, indent=2))
    print(f"HELDOUT_PREPARATION_COMPLETE={materialization_path}")


if __name__ == "__main__":
    main()
