from __future__ import annotations

import argparse
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, write_json
from carbonaffinity.corun_surface import fit_with_loo


def main():
    parser = argparse.ArgumentParser(description="Fit candidate; does not freeze or install it")
    parser.add_argument("--input-roots", type=Path, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = [row for root in args.input_roots for row in read_rows(root)]
    ids = [(row["gpu_index"], row["case_id"]) for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate development cases")
    if any("validation" in row["case_id"] for row in rows):
        raise ValueError("validation data cannot be used to refit this candidate")
    model = fit_with_loo(rows)
    model["training_sources"] = [{"path": str(path.resolve()), "sha256": sha256(path)}
                                 for root in args.input_roots for path in (sorted(root.rglob("measurements.jsonl")) if root.is_dir() else [root])]
    write_json(args.output, model)
    print(f"CANDIDATE_WRITTEN rows={len(rows)} margin_ms={model['uncertainty_margin_ms']} frozen=False sha256={sha256(args.output)}")


if __name__ == "__main__":
    main()
