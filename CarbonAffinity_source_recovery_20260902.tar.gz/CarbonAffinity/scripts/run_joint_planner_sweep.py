from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def append_jsonl(path: Path, row: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def completed_ids(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return {
        str(row["case_id"])
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
        for row in [json.loads(line)]
        if row.get("terminal")
    }


def run(
    command: list[str],
    log: Path,
    timeout_s: float,
    environment: dict[str, str],
) -> tuple[str, float]:
    started = time.monotonic()
    with log.open("a", encoding="utf-8") as handle:
        handle.write("COMMAND=" + json.dumps(command) + "\n")
        handle.flush()
        try:
            result = subprocess.run(
                command,
                cwd=ROOT,
                env=environment,
                stdout=handle,
                stderr=subprocess.STDOUT,
                timeout=timeout_s,
                check=False,
            )
            return (
                "PASS" if result.returncode == 0 else f"FAILED_{result.returncode}",
                time.monotonic() - started,
            )
        except subprocess.TimeoutExpired:
            handle.write(f"TIMEOUT_AFTER_S={timeout_s}\n")
            handle.flush()
            return "TIMEOUT", time.monotonic() - started


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Checkpointed online-planner correctness and scaling sweep."
    )
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--windows", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument("--region-counts", type=int, nargs="+", default=[2, 4, 8])
    parser.add_argument(
        "--request-counts", type=int, nargs="+", default=[8, 16, 24, 32, 48, 64]
    )
    parser.add_argument(
        "--epoch-ms", type=float, nargs="+", default=[250.0, 1000.0, 5000.0]
    )
    parser.add_argument(
        "--time-budgets-ms", type=float, nargs="+", default=[5.0, 20.0, 100.0]
    )
    parser.add_argument("--horizon-epochs", type=int, default=4)
    parser.add_argument("--max-price-iterations", type=int, default=32)
    parser.add_argument("--config-pattern", default="configs/recovered_w{window:02d}_r00.yaml",
                        help="project-relative format string; supports {window:02d}")
    parser.add_argument("--exact-timeout-s", type=float, default=180.0)
    parser.add_argument("--max-states", type=int, default=500_000)
    args = parser.parse_args()

    output = args.output_root.resolve()
    cases = output / "cases"
    cases.mkdir(parents=True, exist_ok=True)
    summary = output / "summary.jsonl"
    done = completed_ids(summary)
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(ROOT)
    variants = [
        (mode, budget)
        for mode in ("none", "trace_horizon")
        for budget in args.time_budgets_ms
    ]
    base_cases = (
        len(args.windows)
        * len(args.region_counts)
        * len(args.request_counts)
        * len(args.epoch_ms)
    )
    design = {
        "schema_version": 1,
        "status": "RUNNING",
        "started_s": time.time(),
        "purpose": "joint planner development correctness and scaling",
        "warning": (
            "trace_horizon uses realized future requests as a controlled "
            "continuation-value upper-bound; it is not the deployable predictor"
        ),
        "base_cases": base_cases,
        "online_variants_per_case": len(variants),
        "windows": args.windows,
        "region_counts": args.region_counts,
        "request_counts": args.request_counts,
        "epoch_ms": args.epoch_ms,
        "time_budgets_ms": args.time_budgets_ms,
        "continuation_modes": ["none", "trace_horizon"],
        "horizon_epochs": args.horizon_epochs,
        "max_price_iterations": args.max_price_iterations,
        "config_pattern": args.config_pattern,
        "exact_rule": "regions<=4 and requests<=16",
    }
    (output / "SWEEP_DESIGN.json").write_text(
        json.dumps(design, indent=2), encoding="utf-8"
    )

    index = 0
    for window in args.windows:
        config = ROOT / args.config_pattern.format(window=window)
        if not config.is_file():
            raise FileNotFoundError(
                f"{config}; generate recovered inputs or supply --config-pattern"
            )
        for regions in args.region_counts:
            for requests in args.request_counts:
                for epoch_ms in args.epoch_ms:
                    epoch_label = str(epoch_ms).replace(".", "p")
                    base_id = f"w{window:02d}_r{regions}_n{requests}_e{epoch_label}"
                    case_root = cases / base_id
                    case_root.mkdir(parents=True, exist_ok=True)
                    problem = case_root / "problem.json"
                    build_log = case_root / "build.log"
                    if not problem.is_file():
                        status, duration = run(
                            [
                                sys.executable,
                                str(ROOT / "scripts/build_offline_oracle_problem.py"),
                                "--config",
                                str(config),
                                "--output",
                                str(problem),
                                "--max-requests",
                                str(requests),
                                "--epoch-ms",
                                str(epoch_ms),
                                "--region-limit",
                                str(regions),
                            ],
                            build_log,
                            300.0,
                            environment,
                        )
                        if status != "PASS":
                            append_jsonl(
                                summary,
                                {
                                    "case_id": base_id + "_build",
                                    "base_case": base_id,
                                    "terminal": True,
                                    "status": status,
                                    "duration_s": duration,
                                },
                            )
                            continue

                    exact_objective = None
                    exact_status = "NOT_REQUESTED"
                    exact_path = case_root / "exact.json"
                    if regions <= 4 and requests <= 16:
                        if exact_path.is_file():
                            exact_status = "PASS"
                        else:
                            exact_status, _ = run(
                                [
                                    sys.executable,
                                    str(ROOT / "scripts/solve_offline_oracle.py"),
                                    "--input",
                                    str(problem),
                                    "--output",
                                    str(exact_path),
                                    "--max-states",
                                    str(args.max_states),
                                ],
                                case_root / "exact.log",
                                args.exact_timeout_s,
                                environment,
                            )
                        if exact_status == "PASS":
                            exact_objective = json.loads(
                                exact_path.read_text(encoding="utf-8")
                            )["cost"]["objective_carbon_g"]

                    for mode, budget in variants:
                        index += 1
                        budget_label = str(budget).replace(".", "p")
                        case_id = f"{base_id}_{mode}_b{budget_label}"
                        if case_id in done:
                            print(f"SKIP {index} {case_id}", flush=True)
                            continue
                        solution_path = case_root / f"online_{mode}_b{budget_label}.json"
                        status, duration = run(
                            [
                                sys.executable,
                                str(ROOT / "scripts/solve_online_planner.py"),
                                "--input",
                                str(problem),
                                "--output",
                                str(solution_path),
                                "--horizon-epochs",
                                str(args.horizon_epochs),
                                "--max-price-iterations",
                                str(args.max_price_iterations),
                                "--time-budget-ms",
                                str(budget),
                                "--continuation-mode",
                                mode,
                            ],
                            case_root / f"online_{mode}_b{budget_label}.log",
                            300.0,
                            environment,
                        )
                        row: dict[str, Any] = {
                            "case_id": case_id,
                            "base_case": base_id,
                            "terminal": True,
                            "status": status,
                            "window": window,
                            "regions": regions,
                            "requests": requests,
                            "epoch_ms": epoch_ms,
                            "continuation_mode": mode,
                            "time_budget_ms": budget,
                            "wall_duration_s": duration,
                            "exact_status": exact_status,
                            "exact_objective_carbon_g": exact_objective,
                            "problem_sha256": sha256(problem),
                        }
                        if status == "PASS":
                            solved = json.loads(solution_path.read_text(encoding="utf-8"))
                            objective = solved["cost"]["objective_carbon_g"]
                            row.update(
                                {
                                    "objective_carbon_g": objective,
                                    "migrations": solved["cost"]["migrations"],
                                    "total_planner_time_ms": solved[
                                        "total_planner_time_ms"
                                    ],
                                    "max_planner_time_ms": solved[
                                        "max_planner_time_ms"
                                    ],
                                    "budget_exhausted_epochs": solved[
                                        "budget_exhausted_epochs"
                                    ],
                                    "epochs": len(solved["steps"]),
                                    "gap_vs_exact_pct": (
                                        100.0
                                        * (objective - exact_objective)
                                        / exact_objective
                                        if exact_objective not in (None, 0.0)
                                        else None
                                    ),
                                    "solution_sha256": sha256(solution_path),
                                }
                            )
                        append_jsonl(summary, row)
                        print(
                            f"FINISH {index}/{base_cases * len(variants)} "
                            f"{case_id} status={status}",
                            flush=True,
                        )

    rows = [
        json.loads(line)
        for line in summary.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    final = {
        **design,
        "status": "COMPLETE",
        "completed_s": time.time(),
        "records": len(rows),
        "passed": sum(row.get("status") == "PASS" for row in rows),
        "failed": sum(row.get("status") != "PASS" for row in rows),
        "exact_passed_base_cases": len(
            {
                row["base_case"]
                for row in rows
                if row.get("exact_status") == "PASS"
            }
        ),
        "summary_sha256": sha256(summary),
    }
    (output / "SWEEP_COMPLETE.json").write_text(
        json.dumps(final, indent=2), encoding="utf-8"
    )
    print("JOINT_PLANNER_SWEEP_COMPLETE =", output, flush=True)


if __name__ == "__main__":
    main()
