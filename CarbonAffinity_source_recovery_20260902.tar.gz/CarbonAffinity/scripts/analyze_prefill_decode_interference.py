from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = min(
        len(ordered) - 1,
        max(0, int((len(ordered) - 1) * q + 0.999999)),
    )
    return ordered[index]


def summarize(values: list[float]) -> dict[str, float | None]:
    return {
        "samples": len(values),
        "median": statistics.median(values) if values else None,
        "q95": percentile(values, 0.95),
        "max": max(values) if values else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-rows", type=int, default=288)
    parser.add_argument("--tpot-slo-ms", type=float, default=300.0)
    args = parser.parse_args()

    rows = []
    for path in sorted(args.input_root.glob("gpu_*.jsonl")):
        rows.extend(
            json.loads(line)
            for line in path.read_text().splitlines()
            if line.strip()
        )
    failures = sum(int(row["failures"]) for row in rows)
    gpus = sorted({int(row["gpu_index"]) for row in rows})
    grouped: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[int(row["total_interfering_prefill_tokens"])].append(row)

    baseline_by_gpu: dict[int, float] = {}
    for gpu in gpus:
        values = [
            float(row["victim"]["mean_tpot_ms"])
            for row in rows
            if int(row["gpu_index"]) == gpu
            and int(row["prefill_count"]) == 0
            and row["victim"]["mean_tpot_ms"] is not None
        ]
        if values:
            baseline_by_gpu[gpu] = statistics.median(values)

    curves = []
    for total_tokens, cases in sorted(grouped.items()):
        tpots = [
            float(row["victim"]["mean_tpot_ms"])
            for row in cases
            if row["victim"]["mean_tpot_ms"] is not None
        ]
        p95_itls = [
            float(row["victim"]["p95_itl_ms"])
            for row in cases
            if row["victim"]["p95_itl_ms"] is not None
        ]
        slowdown = [
            float(row["victim"]["mean_tpot_ms"])
            / baseline_by_gpu[int(row["gpu_index"])]
            for row in cases
            if row["victim"]["mean_tpot_ms"] is not None
            and int(row["gpu_index"]) in baseline_by_gpu
        ]
        curves.append({
            "total_interfering_prefill_tokens": total_tokens,
            "cases": len(cases),
            "mean_tpot_ms": summarize(tpots),
            "p95_itl_ms": summarize(p95_itls),
            "slowdown_over_gpu_baseline": summarize(slowdown),
            "slo_violation_rate": (
                sum(value > args.tpot_slo_ms for value in tpots)
                / len(tpots)
                if tpots else None
            ),
        })

    safe_totals = [
        int(item["total_interfering_prefill_tokens"])
        for item in curves
        if item["mean_tpot_ms"]["q95"] is not None
        and float(item["mean_tpot_ms"]["q95"])
        <= args.tpot_slo_ms
    ]
    checks = {
        "expected_row_count": len(rows) == args.expected_rows,
        "all_eight_gpus": gpus == list(range(8)),
        "no_request_failures": failures == 0,
        "baseline_for_all_gpus": sorted(baseline_by_gpu) == list(range(8)),
    }
    report = {
        "schema_version": 1,
        "status": "PASS" if all(checks.values()) else "FAIL",
        "rows": len(rows),
        "gpus": gpus,
        "failures": failures,
        "tpot_slo_ms": args.tpot_slo_ms,
        "checks": checks,
        "baseline_tpot_ms_by_gpu": baseline_by_gpu,
        "curves": curves,
        "largest_empirically_safe_total_prefill_tokens": (
            max(safe_totals) if safe_totals else None
        ),
    }
    args.output.write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))
    if report["status"] != "PASS":
        raise SystemExit(1)
    print("PREFILL_DECODE_INTERFERENCE_AUDIT_PASS")


if __name__ == "__main__":
    main()
