from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = []
    for path in sorted(args.input_root.glob("gpu_*.jsonl")):
        rows.extend(json.loads(line) for line in path.read_text().splitlines() if line.strip())
    if not rows:
        raise RuntimeError("no batch-energy rows")
    cells: dict[tuple[int, int, str, int], list[dict]] = defaultdict(list)
    for row in rows:
        cells[(row["prompt_tokens"], row["output_tokens"], row["mode"], row["concurrency"])].append(row)
    ratios: dict[int, list[float]] = defaultdict(list)
    cell_ratios: dict[tuple[int, int, str], dict[int, list[float]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for (prompt, output, mode, concurrency), values in cells.items():
        baseline = cells.get((prompt, output, mode, 1), [])
        if not baseline:
            continue
        base = statistics.median(row["dynamic_energy_per_request_j"] for row in baseline)
        if base <= 0:
            continue
        ratios[concurrency].extend(
            row["dynamic_energy_per_request_j"] / base for row in values
        )
        cell_ratios[(prompt, output, mode)][concurrency].extend(
            row["dynamic_energy_per_request_j"] / base for row in values
        )
    global_curve = {
        str(concurrency): statistics.median(values)
        for concurrency, values in sorted(ratios.items())
    }
    conditional_curves = {
        f"{mode}|{prompt}|{output}": {
            str(concurrency): statistics.median(values)
            for concurrency, values in sorted(curves.items())
        }
        for (prompt, output, mode), curves in sorted(cell_ratios.items())
    }
    report = {
        "rows": len(rows),
        "gpus": sorted({row["gpu_index"] for row in rows}),
        "batch_energy_multipliers": global_curve,
        "batch_energy_multiplier_iqr": {
            str(concurrency): [
                statistics.quantiles(values, n=4)[0],
                statistics.quantiles(values, n=4)[2],
            ] if len(values) >= 4 else [min(values), max(values)]
            for concurrency, values in sorted(ratios.items())
        },
        "batch_energy_model": {
            "schema_version": 1,
            "semantics": "per-request dynamic energy relative to concurrency one",
            "global": global_curve,
            "cells": conditional_curves,
            "max_measured_concurrency": max(map(int, global_curve)),
            "marginal_floor": 0.05,
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
