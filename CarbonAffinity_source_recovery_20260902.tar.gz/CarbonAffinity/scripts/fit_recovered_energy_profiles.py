"""Rebuild eight development profiles from real NVML batches and validated latency.

Energy coefficients/batch curves remain development estimates. The output audit
does NOT confer independent energy-model validation on this training dataset.
"""
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import numpy as np

from carbonaffinity.artifacts import finite_nonnegative, read_rows, sha256, write_json
from carbonaffinity.profile import HardwareProfile
from scripts.fit_extended_profiles import batch_model, nonnegative_least_squares


def fit(rows, latency, model_name, accelerator):
    solo = [r for r in rows if r["concurrency"] == 1]
    x, y = [], []
    for row in solo:
        result = row["results"][0]
        cached = row["cached_tokens"][0]
        if row["mode"] == "warm" and (cached is None or cached < .9 * row["prompt_tokens"]):
            raise ValueError("warm energy calibration lacks observed prefix reuse")
        cached = min(row["prompt_tokens"], cached or 0)
        x.append([1, row["prompt_tokens"] - cached, cached, result["output_tokens"]])
        y.append(finite_nonnegative(row["dynamic_energy_per_request_j"]))
    if len(x) < 4 or np.linalg.matrix_rank(np.array(x)) != 4 or max(y) <= 0:
        raise ValueError("unidentifiable or zero-energy calibration")
    beta = nonnegative_least_squares(np.array(x, dtype=float), np.array(y))
    region = rows[0]["region_id"]
    profile = HardwareProfile(region_id=region, accelerator=accelerator, model=model_name,
        base_request_j=float(beta[0]), cold_prefill_j_per_token=float(beta[1]),
        cached_prefill_j_per_token=float(beta[2]), decode_j_per_token=float(beta[3]),
        base_ttft_ms=latency["cells"][f"cold|{min(latency['prompt_buckets'])}|1"]["ttft_ms"],
        cold_prefill_ms_per_token=0, cached_prefill_ms_per_token=0,
        base_tpot_ms=latency["cells"][f"cold|{min(latency['prompt_buckets'])}|1"]["tpot_ms"],
        queue_ttft_ms_per_request=0, uncertainty_margin=1,
        max_prompt_tokens=min(max(r["prompt_tokens"] for r in rows), max(latency["prompt_buckets"])),
        max_output_tokens=max(r["output_tokens"] for r in rows),
        max_concurrency=min(max(r["concurrency"] for r in rows), max(latency["concurrency_buckets"])),
        batch_energy_model=batch_model(rows), latency_surface_model=latency)
    from dataclasses import asdict
    return asdict(profile)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--latency-model", type=Path, required=True)
    parser.add_argument("--latency-freeze-record", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--model", default="Qwen3.5-27B")
    parser.add_argument("--accelerator", required=True, help="actual hardware name from nvidia-smi")
    args = parser.parse_args()
    freeze = json.loads(args.latency_freeze_record.read_text())
    if (freeze.get("status") != "FROZEN" or freeze["model_sha256"] != sha256(args.latency_model)
            or sha256(freeze["validation_report"]) != freeze["validation_sha256"]):
        raise ValueError("latency validation/freeze hashes mismatch")
    rows = read_rows(args.input_root / "raw")
    launch = json.loads((args.input_root / "LAUNCH.json").read_text())
    if launch.get("runtime_cap") != 784 or launch.get("effective_cap_verified") is not True:
        raise ValueError("energy runtime mode not verified")
    identities = [(r["gpu_index"], r["prompt_tokens"], r["output_tokens"], r["mode"], r["concurrency"], r["repeat"]) for r in rows]
    gpus = sorted({r["gpu_index"] for r in rows})
    expected = set(itertools.product(gpus, [2048, 8192, 32768], [32, 128, 512], ["cold", "warm"], [1, 4, 8], [0, 1]))
    if len(gpus) != 8 or len(rows) != 864 or set(identities) != expected or len(set(identities)) != len(rows):
        raise ValueError("energy measurement grid incomplete or duplicate")
    if any(len(r["results"]) != r["concurrency"] or any(not v["success"] for v in r["results"]) for r in rows):
        raise ValueError("energy measurement requests missing/failed")
    latency = json.loads(args.latency_model.read_text())
    profiles = {gpu: fit([r for r in rows if r["gpu_index"] == gpu], latency, args.model, args.accelerator) for gpu in gpus}
    args.output_dir.mkdir(parents=True, exist_ok=False)
    for gpu, profile in profiles.items():
        write_json(args.output_dir / f"gpu_{gpu}.json", profile)
    write_json(args.output_dir / "ENERGY_DEVELOPMENT_AUDIT.json", {
        "status": "DEVELOPMENT_FIT_COMPLETE_NOT_ENERGY_VALIDATED", "rows": len(rows),
        "latency_model_sha256": sha256(args.latency_model),
        "training_sha256": {str(p): sha256(p) for p in args.input_root.rglob("measurements.jsonl")},
        "profiles_sha256": {str(gpu): sha256(args.output_dir / f"gpu_{gpu}.json") for gpu in gpus}})
    print("ENERGY_PROFILES_REBUILT; independent energy validation still required")


if __name__ == "__main__":
    main()
