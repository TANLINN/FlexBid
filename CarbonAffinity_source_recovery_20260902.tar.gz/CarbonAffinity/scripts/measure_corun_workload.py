"""Co-run and active-decoder development/validation measurement worker.

Run one worker per isolated GPU endpoint. Controller starts/stops endpoints.
The case list is written before inference; every completed row is flushed.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import time
import uuid
from pathlib import Path

import httpx

from carbonaffinity.artifacts import write_json
from carbonaffinity.materialize import PromptMaterializer
from carbonaffinity.workload_experiments import cases, features_at_admission
from scripts.measure_prefill_decode_interference import prompt, reset_cache, stream_request


async def run_case(args, client, materializer, case):
    prefix = args.namespace + ":" + case["case_id"]
    await reset_cache(client, args.api_base.removesuffix("/v1"))
    victim_prompt = prompt(materializer, prefix + ":victim", case["victim_prompt_tokens"])
    shared = case["victim_shared_tokens"]
    warm_prime = None
    if shared:
        warm_prime = await stream_request(client, args.api_base, args.model, victim_prompt[:shared], prefix + ":prime", 1, cache_salt=prefix)
        if not warm_prime.success:
            raise RuntimeError(f"warm priming failed: {warm_prime.error}")

    async def timed(request_prompt, suffix, outputs, event=None, salt=None):
        start = time.perf_counter_ns()
        measurement = await stream_request(client, args.api_base, args.model, request_prompt,
                                           prefix + suffix, outputs, event, cache_salt=salt)
        end = time.perf_counter_ns()
        return {**measurement.to_dict(), "start_ns": start, "end_ns": end,
                "first_ns": None if measurement.ttft_ms is None else start + int(measurement.ttft_ms * 1e6)}

    tasks = []
    events = []
    background_prompts = [prompt(materializer, prefix + f":bg:{index}", case["background_tokens"])
                          for index in range(case["background_count"])]
    def start_background():
        for index, tokens in enumerate(background_prompts):
            event = asyncio.Event()
            events.append(event)
            tasks.append(asyncio.create_task(timed(tokens, f":bg:{index}", case["background_output_tokens"], event)))

    victim_task = None
    try:
        if case["order"] == "victim_first":
            victim_task = asyncio.create_task(timed(victim_prompt, ":victim", case["victim_output_tokens"], salt=prefix))
            await asyncio.sleep(case["offset_ms"] / 1000)
            start_background()
        else:
            start_background()
            await asyncio.sleep(0)
            if case["order"] == "decode_first":
                await asyncio.wait_for(asyncio.gather(*(event.wait() for event in events)), args.timeout_s)
            await asyncio.sleep(case["offset_ms"] / 1000)
            victim_task = asyncio.create_task(timed(victim_prompt, ":victim", case["victim_output_tokens"], salt=prefix))
        victim = await victim_task
        backgrounds = await asyncio.gather(*tasks)
    finally:
        all_tasks = tasks + ([victim_task] if victim_task is not None else [])
        for task in all_tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*all_tasks, return_exceptions=True)
    phase = {"baseline": "baseline", "background_first": "prefill_then_decode",
             "victim_first": "future_arrival_control", "decode_first": "active_decode"}[case["order"]]
    return {"schema_version": 3, **case, "gpu_index": args.gpu_index, "phase": phase,
            "runtime_cap": args.runtime_cap, "runtime_cap_evidence": args.runtime_evidence,
            "admission_features": features_at_admission(case["victim_prompt_tokens"] - shared, victim["start_ns"], backgrounds),
            "victim": victim, "interferers": backgrounds,
            "warm_prime": None if warm_prime is None else warm_prime.to_dict(),
            "failures": int(not victim["success"]) + sum(not row["success"] for row in backgrounds),
            "feature_semantics": "initial uncached prompt and full output budgets; phases at victim client dispatch; no time decay"}


async def main_async(args):
    if args.output.exists():
        raise FileExistsError("refusing to overwrite measurements; use a new output directory")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.namespace = uuid.uuid4().hex
    case_list = cases(args.kind)
    write_json(args.output.parent / "CASES.json", case_list)
    materializer = PromptMaterializer(args.tokenizer)
    async with httpx.AsyncClient(timeout=args.timeout_s, trust_env=False) as client:
        health = await client.get(args.api_base.removesuffix("/v1") + "/health")
        health.raise_for_status()
        # Explicit prewarm excluded by construction, not by deleting a slow row.
        warmup = await stream_request(client, args.api_base, args.model,
                                     prompt(materializer, args.namespace, 2048), args.namespace, 64)
        if not warmup.success:
            raise RuntimeError("server prewarm failed")
        with args.output.open("x", encoding="utf-8") as handle:
            for index, case in enumerate(case_list, 1):
                row = await run_case(args, client, materializer, case)
                handle.write(json.dumps(row, allow_nan=False) + "\n")
                handle.flush()
                print(f"GPU {args.gpu_index}: {index}/{len(case_list)} failures={row['failures']}", flush=True)
                if row["failures"]:
                    raise RuntimeError("measurement request failure; row preserved")
    write_json(args.output.parent / "COMPLETE.json", {"status": "COMPLETE", "rows": len(case_list)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--gpu-index", type=int, required=True)
    parser.add_argument("--kind", choices=[a + "_" + b for a in ("backlog", "corun", "active_decode") for b in ("development", "validation")], required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-cap", type=int, default=784)
    parser.add_argument("--runtime-evidence", required=True, help="SHA256 of verified engine launch manifest")
    parser.add_argument("--timeout-s", type=float, default=900)
    asyncio.run(main_async(parser.parse_args()))


if __name__ == "__main__":
    main()
