"""Verified one-paste CPU candidate-fit bundle. No GPU launch, no runtime install."""
import argparse
import base64
import gzip
import hashlib
import json
import shlex
import textwrap
from pathlib import Path

from scripts.build_latency_residual_transfer import INSTALLER, PROJECT, build_payload as development_payload

DEFAULT_SOURCE = "/root/CarbonAffinity/results/latency_residual_dev_20260830T082216Z"
FIT_FILES = ("scripts/residual_latency_candidate.py", "scripts/fit_residual_latency_candidate.py",
             "tests/test_residual_latency_candidate.py")


def build_payload():
    payload = json.loads(gzip.decompress(development_payload()))
    for name in FIT_FILES:
        code = (PROJECT / name).read_text(encoding="utf-8")
        compile(code, name, "exec")
        payload["files"][name] = code
    payload["scope"] = "CPU candidate fit only; separate from development source and runtime models; no validation"
    return gzip.compress(json.dumps(payload, ensure_ascii=True, sort_keys=True).encode(), mtime=0)


def command(payload, source=DEFAULT_SOURCE):
    if not source.startswith("/root/CarbonAffinity/results/") or ".." in source.split("/"):
        raise ValueError("explicit server results directory required")
    digest = hashlib.sha256(payload).hexdigest()
    encoded = "\n".join(textwrap.wrap(base64.b64encode(payload).decode(), 100))
    install = "/root/CarbonAffinity/.venv/bin/python -c " + shlex.quote(INSTALLER)
    return f'''if FIT_BUNDLE="$({install} {digest} /root/CarbonAffinity <<'RESIDUAL_FIT_BUNDLE_EOF'
{encoded}
RESIDUAL_FIT_BUNDLE_EOF
)"; then
    if (cd "$FIT_BUNDLE" && PYTHONPATH="$FIT_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -m unittest tests.test_latency_residual tests.test_residual_latency_candidate -q); then
        DEV={shlex.quote(source)}
        FIT="/root/CarbonAffinity/results/latency_residual_candidate_$(date -u +%Y%m%dT%H%M%S%NZ)"
        if (cd "$FIT_BUNDLE" && PYTHONPATH="$FIT_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -u -m scripts.fit_residual_latency_candidate --input-root "$DEV" --output-root "$FIT"); then
            echo "FIT=$FIT"
            echo "CPU_FIT_COMPLETE_NOT_FROZEN_NOT_VALIDATED"
        else
            echo "FIT=$FIT"
            echo "CPU_FIT_FAILED_NO_RUNTIME_MODEL_INSTALLED"
        fi
    else
        echo "FIT_SELF_TEST_FAILED_NOT_STARTED"
    fi
else
    echo "FIT_TRANSFER_FAILED_NOT_STARTED"
fi
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", default=DEFAULT_SOURCE)
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    payload = build_payload()
    output = command(payload, args.input_root)
    if args.metadata:
        print(json.dumps({"sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload),
                          "input_root": args.input_root, "stage": "CPU_FIT_ONLY", "lines": len(output.splitlines())}))
    else:
        print(output, end="")


if __name__ == "__main__":
    main()
