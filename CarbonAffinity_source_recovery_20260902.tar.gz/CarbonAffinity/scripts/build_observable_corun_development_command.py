"""One plaintext paste: immutable source bundle, self-tests, then 2208-case run."""
import argparse
import hashlib
import shlex
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
NAMES = ("scripts/corun_observable_pilot.py", "tests/test_corun_observable_pilot.py",
         "scripts/corun_observable_development.py", "tests/test_corun_observable_development.py")
SEPARATOR = "\n# === OBSERVABLE_DEVELOPMENT_NEXT_SOURCE ===\n"
INSTALLER = '''import hashlib,json,sys
from pathlib import Path
project=Path('/root/CarbonAffinity')
raw=sys.stdin.buffer.read()
digest=hashlib.sha256(raw).hexdigest()
if digest!=sys.argv[1]:
    raise SystemExit('SOURCE_CHECKSUM_FAILED_NOT_INSTALLED')
base=project/'results/residual_latency_transfer_faa9f726faf33f99'
manifest=json.loads((base/'TRANSFER_MANIFEST.json').read_text())
if manifest['payload_sha256']!='faa9f726faf33f9932dc92b4149e34dc594a6782565e8a771f7b3e5c7040ce2e':
    raise SystemExit('BASE_BUNDLE_MISMATCH')
def safe(name):
    p=Path(name)
    if p.is_absolute() or '..' in p.parts or p.parts[0] not in ('scripts','tests'):
        raise SystemExit('UNSAFE_SOURCE_PATH')
    return p
files={}
for name,expected in manifest['files_sha256'].items():
    data=(base/safe(name)).read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected:
        raise SystemExit('BASE_SOURCE_CHANGED: '+name)
    files[name]=data
for name,expected in manifest['required_core_lf_sha256'].items():
    if hashlib.sha256((project/name).read_text(encoding='utf-8').encode()).hexdigest()!=expected:
        raise SystemExit('CORE_SOURCE_CHANGED: '+name)
names=('scripts/corun_observable_pilot.py','tests/test_corun_observable_pilot.py',
       'scripts/corun_observable_development.py','tests/test_corun_observable_development.py')
parts=raw.decode('utf-8').split('\\n# === OBSERVABLE_DEVELOPMENT_NEXT_SOURCE ===\\n')
if len(parts)!=len(names):
    raise SystemExit('SOURCE_BOUNDARY_INVALID')
for name,source in zip(names,parts):
    if name in files:
        raise SystemExit('UNEXPECTED_SOURCE_COLLISION')
    files[name]=source.encode()
destination=project/'results'/('observable_corun_development_transfer_'+digest[:16])
if destination.is_symlink():
    raise SystemExit('SYMLINK_DESTINATION_REJECTED')
for name,data in files.items():
    relative=safe(name)
    compile(data,name,'exec')
    target=destination/relative
    if target.is_symlink() or target.parent.is_symlink():
        raise SystemExit('SYMLINK_SOURCE_REJECTED')
    if target.exists() and target.read_bytes()!=data:
        raise SystemExit('EXISTING_SOURCE_DIFFERS: '+name)
record=dict(source_payload_sha256=digest,base_payload_sha256=manifest['payload_sha256'],
    files_sha256={n:hashlib.sha256(d).hexdigest() for n,d in files.items()},
    required_core_lf_sha256=manifest['required_core_lf_sha256'],
    scope='2208-case observable co-run factorial DEVELOPMENT only; no model fitting or GPU validation claim')
record_bytes=(json.dumps(record,sort_keys=True,indent=2)+'\\n').encode()
record_path=destination/'DEVELOPMENT_TRANSFER_MANIFEST.json'
if record_path.is_symlink() or (record_path.exists() and record_path.read_bytes()!=record_bytes):
    raise SystemExit('EXISTING_MANIFEST_DIFFERS')
for name,data in files.items():
    target=destination/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        with target.open('xb') as handle:
            handle.write(data)
    if target.read_bytes()!=data:
        raise SystemExit('INSTALLED_HASH_MISMATCH')
if not record_path.exists():
    with record_path.open('xb') as handle:
        handle.write(record_bytes)
print(destination)
'''


def payload():
    sources = [PROJECT.joinpath(n).read_text(encoding="utf-8") for n in NAMES]
    for name, source in zip(NAMES, sources):
        if SEPARATOR in source or "\nOBSERVABLE_DEVELOPMENT_SOURCE_EOF\n" in source:
            raise ValueError("delimiter collision")
        compile(source, name, "exec")
    return SEPARATOR.join(sources).encode()


def command():
    raw = payload()
    digest = hashlib.sha256(raw).hexdigest()
    return f'''cd /root/CarbonAffinity
if DEV_BUNDLE="$(/root/CarbonAffinity/.venv/bin/python -c {shlex.quote(INSTALLER)} {digest} <<'OBSERVABLE_DEVELOPMENT_SOURCE_EOF'
{raw.decode()}OBSERVABLE_DEVELOPMENT_SOURCE_EOF
)"; then
    if (cd "$DEV_BUNDLE" && PYTHONPATH="$DEV_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -m unittest tests.test_latency_residual tests.test_corun_observable_pilot tests.test_corun_observable_development -q); then
        DEV="/root/CarbonAffinity/results/observable_corun_development_v1_$(date -u +%Y%m%dT%H%M%S%NZ)"
        nohup env PYTHONPATH="$DEV_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -u "$DEV_BUNDLE/scripts/corun_observable_development.py" --project-root /root/CarbonAffinity --model-dir /root/models/Qwen3.5-27B --output-root "$DEV" > "${{DEV}}.launcher.log" 2>&1 < /dev/null &
        echo "PID=$! DEV=$DEV"
        echo "OBSERVABLE_CORUN_DEVELOPMENT_SUBMITTED_EXPECTED_ROWS=2208"
        echo "Not success yet: watch progress and inspect OBSERVABLE_CORUN_DEVELOPMENT_AUDIT.json when finished."
    else
        echo "DEVELOPMENT_SELF_TEST_FAILED_NOT_STARTED"
    fi
else
    echo "DEVELOPMENT_INSTALL_FAILED_NOT_STARTED"
fi
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = command().encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as handle:
        handle.write(data)
    print(f"OUTPUT={args.output.resolve()} LINES={len(data.splitlines())} SHA256={hashlib.sha256(data).hexdigest()}")


if __name__ == "__main__":
    main()
