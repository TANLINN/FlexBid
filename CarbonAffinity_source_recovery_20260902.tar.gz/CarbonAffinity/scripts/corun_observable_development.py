"""Fixed 2208-case development design. No fitting, validation or model install."""
import hashlib
import itertools
import json
import sys
from collections import Counter
from functools import lru_cache
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, write_json
from scripts import corun_observable_pilot as engine

VERSION = "observable-corun-factorial-development-v1"
MEASUREMENT_MODULE = "scripts.corun_observable_development"
REPORT_NAME = "OBSERVABLE_CORUN_DEVELOPMENT_AUDIT.json"
PILOT_ROOT = Path("/root/CarbonAffinity/results/observable_corun_pilot_v2_20260830T120214747291107Z")
EXPECTED_ROWS = 2208
REPEATS = 2
VICTIMS = (("cold_p4096", 4096, 0), ("cold_p16384", 16384, 0)) + tuple(
    (f"warm_c{c}_u{u}", c + u, c)
    for c, u in itertools.product((1568, 31360), (32, 768)))
RESERVED = dict(cold_prompt_tokens=[8192, 12288], warm_cached_tokens=[7840, 23520],
                warm_residual_tokens=[256, 512], background_prefill_tokens=[12288],
                background_output_tokens=[128])


def background(role, prompt=16384, output=192, decode=False):
    return dict(role=role, prompt_tokens=16064 if decode else prompt,
                cached_target=15680 if decode else 0, output_tokens=output)


def workloads():
    rows = []
    # Short-budget double decode first: detect failed phase construction early.
    for n, output in itertools.product((2, 1), (64, 192)):
        rows.append((f"decode{n}_o{output}", f"decode{n}",
                     [background(f"bg{i}", output=output, decode=True) for i in range(n)]))
    for p, po, do in itertools.product((8192, 16384), (64, 192), (64, 192)):
        rows.append((f"mixed_p{p}_po{po}_do{do}", "mixed",
                     [background("bg0", output=do, decode=True), background("bg1", p, po)]))
    rows.append(("baseline", "baseline", []))
    for n, p, output in itertools.product((1, 2), (8192, 16384), (64, 192)):
        rows.append((f"prefill{n}_p{p}_o{output}", f"prefill{n}",
                     [background(f"bg{i}", p, output) for i in range(n)]))
    for n in (1, 2):
        rows.append((f"future{n}", f"future{n}", [background(f"bg{i}") for i in range(n)]))
    return rows


@lru_cache(maxsize=1)
def cases():
    base = [dict(cell_id=f"{mode}_{label}", mode=mode, prompt_tokens=p, cached_target=c,
                 output_tokens=64, scenario=scenario, backgrounds=specs, future_offset_ms=250,
                 phase_role="future_arrival_control" if scenario.startswith("future") else "fit_development")
            for mode, p, c in VICTIMS for label, scenario, specs in workloads()]
    # Reverse the entire order on repeat 1; counterbalance deterministic order,
    # not independent new GPUs or random trace repeats.
    return tuple(dict(c, case_id=f"{c['cell_id']}_r{repeat}", repeat=repeat)
                 for repeat in range(REPEATS) for c in (base if repeat == 0 else reversed(base)))


def design():
    return dict(protocol=VERSION, expected_rows=EXPECTED_ROWS, rows_per_gpu=len(cases()),
        gpu_indices=list(range(8)), cases=list(cases()), runtime_cap=784,
        victim_profiles=[dict(mode=m, prompt_tokens=p, cached_target=c) for m, p, c in VICTIMS],
        workload_cells=23, repeats=REPEATS, second_repeat_order="reverse of first",
        admission_features="live controller snapshot: identity, phase, full per-request reservations; not engine progress",
        cache_semantics="cold null unknown; warm exact observed cache and matching priming prompt/salt required",
        decode_background="prime16064 and observe15680; output64 or192; no forced prolongation or phase relabel",
        future_control="backgrounds absent at victim admission; retain control results, no future inputs in model fitting",
        reserved_for_later_validation=RESERVED,
        scope="bounded development matrix; <=2 backgrounds, mixed=1+1; homogeneous per-phase background budgets",
        exclusions="no model fit/freeze/install; no claim beyond sampled domain, no additive mixed model or energy comparison",
        ttft_reporting_threshold_ms=16000, slo_is_pass_gate=False,
        validity_gates="exact case order/cache/phase/request/code/provenance; zero post-prewarm tuning; no dropped retries")


def prepare(root, args):
    prior = PILOT_ROOT
    if (prior / "FATAL.json").exists():
        raise ValueError("prior pilot has a fatal marker")
    complete = json.loads((prior / "EXPERIMENT_COMPLETE.json").read_text())
    saved = json.loads((prior / engine.REPORT_NAME).read_text())
    if complete.get("status") != "COMPLETE" or complete.get("rows") != 192 or saved.get("status") != "PASS":
        raise ValueError("prior V2 pilot not complete/pass")
    audited = engine.audit(prior)
    if audited["status"] != "PASS" or saved.get("stage") != engine.VERSION:
        raise ValueError("prior V2 pilot failed read-only re-audit")
    paths = [prior / n for n in ("EXPERIMENT_COMPLETE.json", engine.REPORT_NAME,
        "PREREGISTRATION.json", "LAUNCH.json", "SHAPE_PREWARM.json")]
    paths += sorted((prior / "raw").glob("gpu_*/measurements.jsonl"))
    paths += [prior / f"vllm_gpu_{g}.log" for g in range(8)]
    record = dict(status="PASS", source_root=str(prior), used_for_fitting=False,
                  sha256={str(p): sha256(p) for p in paths})
    write_json(root / "PRIOR_PILOT_GATE.json", record)
    return dict(model_fitting_in_this_run=False, prior_latency_model_used=False,
                prior_pilot_gate_sha256=sha256(root / "PRIOR_PILOT_GATE.json"))


def code_paths():
    return [Path(__file__).resolve(), Path(engine.__file__).resolve()]


def audit(root):
    root = Path(root)
    report = engine.audit(root, protocol=sys.modules[__name__])
    rows = read_rows(root / "raw")
    counts = Counter(r.get("gpu_index") for r in rows)
    expected_order = [c["case_id"] for c in cases()]
    actual_orders = {}
    for gpu in range(8):
        path = root / "raw" / f"gpu_{gpu}" / "measurements.jsonl"
        actual_orders[gpu] = [json.loads(line)["case_id"] for line in path.read_text().splitlines() if line.strip()]
    registered = json.loads((root / "PREREGISTRATION.json").read_text())
    gate = json.loads((root / "PRIOR_PILOT_GATE.json").read_text())
    report["checks"].update(
        rows_276_per_gpu=all(counts[g] == 276 for g in range(8)),
        exact_preregistered_order=all(v == expected_order for v in actual_orders.values()),
        prior_gate_unchanged=registered.get("prior_pilot_gate_sha256") == sha256(root / "PRIOR_PILOT_GATE.json"),
        prior_pilot_unchanged=gate.get("status") == "PASS" and bool(gate.get("sha256")) and
            all(Path(p).is_file() and sha256(p) == digest for p, digest in gate["sha256"].items()))
    report["status"] = "PASS" if all(report["checks"].values()) else "FAIL"
    report["rows_by_gpu"] = {str(g): counts[g] for g in range(8)}
    report["candidate_frozen"] = False
    report["model_fitted"] = False
    report["future_control_rows"] = sum(r.get("phase_role") == "future_arrival_control" for r in rows)
    report["note"] = "Development only: assess data before candidate fitting; controls not future model inputs; no SLO/model/carbon claim."
    return report


if __name__ == "__main__":
    engine.main(campaign=sys.modules[__name__])
