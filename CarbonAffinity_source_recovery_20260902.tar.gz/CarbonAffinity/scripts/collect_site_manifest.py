from __future__ import annotations

import argparse
import hashlib
import json
import platform
import socket
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path


def command(args: list[str]) -> str:
    result = subprocess.run(args, text=True, capture_output=True, check=True)
    return result.stdout.strip()


def main() -> None:
    parser = argparse.ArgumentParser(description="Record physical-site evidence for the main experiment")
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--grid-region", required=True, help="carbon provider balancing-authority/zone ID")
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--tensor-parallel-size", type=int, default=1)
    parser.add_argument("--datacenter-label", default="undisclosed")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.tensor_parallel_size != 1:
        parser.error("main experiment manifest requires tensor_parallel_size=1")
    config_path = args.model_dir / "config.json"
    if not config_path.is_file():
        parser.error(f"missing model config: {config_path}")
    fields = command([
        "nvidia-smi", "-i", str(args.gpu_index),
        "--query-gpu=name,uuid,memory.total,driver_version,power.default_limit,power.min_limit,power.max_limit",
        "--format=csv,noheader,nounits",
    ]).split(",")
    if len(fields) != 7:
        raise RuntimeError("unexpected nvidia-smi output")
    fields = [field.strip() for field in fields]
    manifest = {
        "schema_version": 1,
        "captured_utc": datetime.now(timezone.utc).isoformat(),
        "wall_time_ns": time.time_ns(),
        "region_id": args.region_id,
        "grid_region": args.grid_region,
        "datacenter_label": args.datacenter_label,
        "hostname": socket.gethostname(),
        "platform": platform.platform(),
        "gpu_index": args.gpu_index,
        "tensor_parallel_size": args.tensor_parallel_size,
        "gpu": {
            "name": fields[0], "uuid": fields[1], "memory_total_mib": float(fields[2]),
            "driver_version": fields[3], "default_power_limit_w": float(fields[4]),
            "min_power_limit_w": float(fields[5]), "max_power_limit_w": float(fields[6]),
        },
        "model_dir_name": args.model_dir.name,
        "model_config_sha256": hashlib.sha256(config_path.read_bytes()).hexdigest(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()

