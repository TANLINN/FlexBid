from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, write_json
from carbonaffinity.corun_surface import CorunTTFTModel, evaluate
from carbonaffinity.workload_experiments import cases


def validate(model_path, root, preregistration):
    model_path, root = Path(model_path), Path(root)
    model = CorunTTFTModel.from_json(model_path)
    checks = {"candidate_hash_unchanged": sha256(model_path) == preregistration["candidate_sha256"]}
    rows = read_rows(root)
    expected = {(gpu, row["case_id"]): row for gpu in preregistration["gpu_indices"]
                for kind in ("corun_validation", "active_decode_validation") for row in cases(kind)}
    ids = [(row.get("gpu_index"), row.get("case_id")) for row in rows]
    checks["exact_case_set"] = set(ids) == set(expected)
    checks["no_duplicates"] = len(ids) == len(set(ids))
    checks["expected_rows"] = len(rows) == len(expected) == preregistration["expected_rows"]
    checks["case_parameters_unchanged"] = all(identity in expected and all(row.get(k) == v for k, v in expected[identity].items()) for identity, row in zip(ids, rows))
    checks["request_failures_zero"] = all(row.get("failures") == 0 and row["victim"]["success"] and all(x["success"] for x in row["interferers"]) for row in rows)
    checks["warm_prime_success"] = all(row.get("warm_prime") is None or row["warm_prime"]["success"] for row in rows)
    checks["cap784_every_row"] = all(row.get("runtime_cap") == 784 for row in rows)
    launch_path = root / "LAUNCH.json"
    checks["launch_evidence"] = launch_path.is_file() and all(row.get("runtime_cap_evidence") == sha256(launch_path) for row in rows)
    launch = json.loads(launch_path.read_text()) if launch_path.is_file() else {}
    checks["effective_cap_verified"] = launch.get("runtime_cap") == 784 and launch.get("effective_cap_verified") is True
    checks["eight_gpus"] = len(set(preregistration["gpu_indices"])) == 8
    checks["nonempty_code_manifest"] = bool(preregistration["code_sha256"])
    checks["code_unchanged"] = all(Path(path).is_file() and sha256(path) == digest for path, digest in preregistration["code_sha256"].items())
    summary = evaluate(model, rows, preregistration["ttft_slo_ms"])
    checks["all_group_coverage"] = bool(summary) and all(group["coverage"] >= preregistration["minimum_coverage"] for group in summary.values())
    checks["slo_false_negatives_zero"] = summary["overall"]["false_negatives"] == 0
    checks["out_of_domain_zero"] = summary["overall"]["out_of_domain"] == 0
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks,
            "candidate_sha256": sha256(model_path), "candidate_frozen": False,
            "rows": len(rows), "by_gpu_counts": dict(Counter(row["gpu_index"] for row in rows)),
            "groups": summary, "refit_on_validation": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--preregistration", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = validate(args.model, args.root, json.loads(args.preregistration.read_text(encoding="utf-8")))
    except Exception as error:
        result = {"status": "FAIL", "analysis_error": f"{type(error).__name__}: {error}"}
    write_json(args.output, result)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
