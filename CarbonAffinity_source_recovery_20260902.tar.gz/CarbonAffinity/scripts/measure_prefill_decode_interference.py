from __future__ import annotations

import argparse
import asyncio
import json
import random
import statistics
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from carbonaffinity.materialize import PromptMaterializer


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = min(
        len(ordered) - 1,
        max(0, int((len(ordered) - 1) * q + 0.999999)),
    )
    return ordered[index]


@dataclass
class StreamMeasurement:
    request_id: str
    prompt_tokens: int
    requested_output_tokens: int
    success: bool
    status_code: int | None
    ttft_ms: float | None
    completion_ms: float
    output_tokens: int
    token_events: int
    mean_tpot_ms: float | None
    p95_itl_ms: float | None
    max_itl_ms: float | None
    error: str | None

    def to_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


async def reset_cache(client: httpx.AsyncClient, root: str) -> None:
    response = await client.post(root + "/reset_prefix_cache")
    if response.status_code not in (200, 404):
        response.raise_for_status()


async def stream_request(
    client: httpx.AsyncClient,
    api_base: str,
    model: str,
    prompt: list[int],
    request_id: str,
    output_tokens: int,
    first_token_event: asyncio.Event | None = None,
    cache_salt: str | None = None,
) -> StreamMeasurement:
    started_ns = time.perf_counter_ns()
    first_ns: int | None = None
    previous_ns: int | None = None
    gaps_ms: list[float] = []
    token_events = 0
    completion_tokens = 0
    status_code: int | None = None
    error: str | None = None
    try:
        payload = {
            "model": model,
            "prompt": prompt,
            "max_tokens": output_tokens,
            "temperature": 0.0,
            "ignore_eos": True,
            "stream": True,
            "stream_options": {"include_usage": True},
            "cache_salt": cache_salt if cache_salt is not None else request_id,
        }
        async with client.stream(
            "POST",
            api_base + "/completions",
            json=payload,
        ) as response:
            status_code = response.status_code
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                message = json.loads(data)
                usage = message.get("usage")
                if usage:
                    completion_tokens = int(
                        usage.get(
                            "completion_tokens",
                            completion_tokens,
                        )
                    )
                choices = message.get("choices") or []
                if choices and choices[0].get("text"):
                    now_ns = time.perf_counter_ns()
                    token_events += 1
                    if first_ns is None:
                        first_ns = now_ns
                        if first_token_event is not None:
                            first_token_event.set()
                    if previous_ns is not None:
                        gaps_ms.append(
                            (now_ns - previous_ns) / 1e6
                        )
                    previous_ns = now_ns
                    if not usage:
                        completion_tokens += 1
    except asyncio.CancelledError:
        raise
    except Exception as exception:
        error = f"{type(exception).__name__}: {exception}"
        if first_token_event is not None:
            first_token_event.set()
    completed_ns = time.perf_counter_ns()
    if first_token_event is not None:
        first_token_event.set()
    return StreamMeasurement(
        request_id=request_id,
        prompt_tokens=len(prompt),
        requested_output_tokens=output_tokens,
        success=error is None and first_ns is not None,
        status_code=status_code,
        ttft_ms=(
            None
            if first_ns is None
            else (first_ns - started_ns) / 1e6
        ),
        completion_ms=(completed_ns - started_ns) / 1e6,
        output_tokens=completion_tokens,
        token_events=token_events,
        mean_tpot_ms=(
            statistics.mean(gaps_ms) if gaps_ms else None
        ),
        p95_itl_ms=percentile(gaps_ms, 0.95),
        max_itl_ms=max(gaps_ms) if gaps_ms else None,
        error=error,
    )


def prompt(
    materializer: PromptMaterializer,
    request_id: str,
    prompt_tokens: int,
) -> list[int]:
    return materializer.tokens({
        "request_id": request_id,
        "session_id": request_id,
        "prompt_tokens": prompt_tokens,
        "shared_prefix_tokens": 0,
    })


async def run_case(
    args: argparse.Namespace,
    client: httpx.AsyncClient,
    materializer: PromptMaterializer,
    prefill_tokens: int,
    prefill_count: int,
    repeat: int,
) -> dict[str, Any]:
    case_id = (
        f"g{args.gpu_index}_p{prefill_tokens}_"
        f"n{prefill_count}_r{repeat}"
    )
    await reset_cache(client, args.api_base.removesuffix("/v1"))
    first_token = asyncio.Event()
    victim_prompt = prompt(
        materializer,
        case_id + "-victim",
        args.victim_prompt_tokens,
    )
    victim_task = asyncio.create_task(stream_request(
        client,
        args.api_base,
        args.model,
        victim_prompt,
        case_id + "-victim",
        args.victim_output_tokens,
        first_token,
    ))
    try:
        await asyncio.wait_for(
            first_token.wait(),
            timeout=args.timeout_s,
        )
    except BaseException:
        victim_task.cancel()
        raise
    await asyncio.sleep(args.interference_delay_ms / 1000.0)
    interferer_tasks = []
    for index in range(prefill_count):
        request_id = case_id + f"-interferer-{index}"
        interferer_tasks.append(asyncio.create_task(stream_request(
            client,
            args.api_base,
            args.model,
            prompt(materializer, request_id, prefill_tokens),
            request_id,
            args.interferer_output_tokens,
        )))
    victim = await victim_task
    interferers = (
        await asyncio.gather(*interferer_tasks)
        if interferer_tasks
        else []
    )
    failures = [
        item for item in [victim, *interferers]
        if not item.success
    ]
    return {
        "case_id": case_id,
        "region_id": args.region_id,
        "gpu_index": args.gpu_index,
        "prefill_tokens_per_request": prefill_tokens,
        "prefill_count": prefill_count,
        "total_interfering_prefill_tokens": (
            prefill_tokens * prefill_count
        ),
        "repeat": repeat,
        "interference_delay_ms": args.interference_delay_ms,
        "victim": victim.to_dict(),
        "interferers": [item.to_dict() for item in interferers],
        "failures": len(failures),
    }


async def measure(args: argparse.Namespace) -> None:
    args.output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    if args.resume and args.output.is_file():
        rows = [
            json.loads(line)
            for line in args.output.read_text().splitlines()
            if line.strip()
        ]
    completed = {row["case_id"] for row in rows}
    cases = [
        (tokens, count, repeat)
        for tokens in args.prefill_tokens
        for count in args.prefill_count
        for repeat in range(args.repeats)
    ]
    random.Random(args.seed + args.gpu_index).shuffle(cases)
    materializer = PromptMaterializer(args.tokenizer)
    client = httpx.AsyncClient(
        timeout=httpx.Timeout(args.timeout_s),
        headers={"Authorization": f"Bearer {args.api_key}"},
        limits=httpx.Limits(
            max_connections=max(args.prefill_count) + 8,
            max_keepalive_connections=max(args.prefill_count) + 4,
        ),
    )
    try:
        for ordinal, (tokens, count, repeat) in enumerate(cases, 1):
            case_id = (
                f"g{args.gpu_index}_p{tokens}_n{count}_r{repeat}"
            )
            if case_id in completed:
                continue
            row = await run_case(
                args,
                client,
                materializer,
                tokens,
                count,
                repeat,
            )
            rows.append(row)
            args.output.write_text(
                "".join(json.dumps(item) + "\n" for item in rows),
                encoding="utf-8",
            )
            print(
                f"CASE {ordinal}/{len(cases)} {case_id} "
                f"tpot={row['victim']['mean_tpot_ms']} "
                f"p95_itl={row['victim']['p95_itl_ms']} "
                f"failures={row['failures']}",
                flush=True,
            )
            await asyncio.sleep(args.settle_s)
    finally:
        await client.aclose()
    print(
        f"PREFILL_DECODE_GPU_COMPLETE={args.gpu_index} "
        f"rows={len(rows)}",
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--gpu-index", type=int, required=True)
    parser.add_argument(
        "--prefill-tokens",
        type=int,
        nargs="+",
        default=[4096, 8192, 16384],
    )
    parser.add_argument(
        "--prefill-count",
        type=int,
        nargs="+",
        default=[0, 1, 2, 3],
    )
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--victim-prompt-tokens", type=int, default=2048)
    parser.add_argument("--victim-output-tokens", type=int, default=128)
    parser.add_argument("--interferer-output-tokens", type=int, default=8)
    parser.add_argument("--interference-delay-ms", type=float, default=25.0)
    parser.add_argument("--settle-s", type=float, default=0.5)
    parser.add_argument("--timeout-s", type=float, default=900.0)
    parser.add_argument("--seed", type=int, default=20260828)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    asyncio.run(measure(parser.parse_args()))


if __name__ == "__main__":
    main()
