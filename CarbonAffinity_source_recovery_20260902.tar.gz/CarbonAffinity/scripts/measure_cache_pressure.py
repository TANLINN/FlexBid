from __future__ import annotations

import argparse
import asyncio
import json
from dataclasses import asdict
from pathlib import Path

import pynvml

from carbonaffinity.calibrate import _measured_completion
from carbonaffinity.materialize import PromptMaterializer
from carbonaffinity.models import RequestSpec
from carbonaffinity.region import RegionClient


async def measure(args: argparse.Namespace) -> None:
    materializer = PromptMaterializer(args.tokenizer)
    client = RegionClient({
        "id": args.region_id, "api_base": args.api_base, "api_key": args.api_key,
        "model": args.model, "admission_concurrency": 1,
    }, args.timeout_s)
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(args.gpu_index)
    rows = []
    try:
        for sessions in args.occupancy_sessions:
            for repeat in range(args.repeats):
                if not await client.reset_prefix_cache():
                    raise RuntimeError("prefix-cache reset was not acknowledged")
                probe_raw = {
                    "request_id": f"probe-{sessions}-{repeat}", "session_id": "pressure-probe",
                    "prompt_tokens": args.probe_tokens, "shared_prefix_tokens": args.probe_tokens,
                }
                probe_prompt = materializer.tokens(probe_raw)
                probe = RequestSpec(
                    request_id=probe_raw["request_id"], arrival_ms=0,
                    prompt_tokens=args.probe_tokens, max_output_tokens=args.output_tokens,
                    session_id="pressure-probe", shared_prefix_tokens=args.probe_tokens,
                )
                prime = await client.complete(probe, probe_prompt)
                if not prime.success:
                    raise RuntimeError(f"probe prime failed: {prime.error}")
                for index in range(sessions):
                    filler_raw = {
                        "request_id": f"fill-{sessions}-{repeat}-{index}",
                        "session_id": f"fill-{sessions}-{repeat}-{index}",
                        "prompt_tokens": args.filler_tokens,
                        "shared_prefix_tokens": args.filler_tokens,
                    }
                    filler = RequestSpec(
                        request_id=filler_raw["request_id"], arrival_ms=0,
                        prompt_tokens=args.filler_tokens, max_output_tokens=1,
                        session_id=filler_raw["session_id"], shared_prefix_tokens=args.filler_tokens,
                    )
                    result = await client.complete(filler, materializer.tokens(filler_raw))
                    if not result.success:
                        raise RuntimeError(f"cache filler failed: {result.error}")
                result, before_ns, after_ns, total_energy_j, energy_source, power_samples = await _measured_completion(
                    client, probe, probe_prompt, handle
                )
                rows.append({
                    "region_id": args.region_id,
                    "occupancy_sessions": sessions,
                    "estimated_occupied_gib": sessions * args.filler_tokens * args.kv_bytes_per_token / 2**30,
                    "filler_tokens": args.filler_tokens,
                    "probe_tokens": args.probe_tokens,
                    "kv_bytes_per_token": args.kv_bytes_per_token,
                    "total_energy_j": total_energy_j,
                    "energy_source": energy_source,
                    "power_samples": power_samples,
                    "measurement_duration_s": (after_ns - before_ns) / 1e9,
                    "result": asdict(result),
                })
                args.output.parent.mkdir(parents=True, exist_ok=True)
                args.output.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
    finally:
        pynvml.nvmlShutdown()
        await client.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Measure marginal cache-pressure cost on one A800")
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--api-base", default="http://127.0.0.1:18000/v1")
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--occupancy-sessions", type=int, nargs="+", default=[0, 4, 8, 16, 32])
    parser.add_argument("--filler-tokens", type=int, default=8192)
    parser.add_argument("--probe-tokens", type=int, default=8192)
    parser.add_argument("--output-tokens", type=int, default=64)
    parser.add_argument("--kv-bytes-per-token", type=float, required=True)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--timeout-s", type=float, default=900)
    parser.add_argument("--output", type=Path, required=True)
    asyncio.run(measure(parser.parse_args()))


if __name__ == "__main__":
    main()

