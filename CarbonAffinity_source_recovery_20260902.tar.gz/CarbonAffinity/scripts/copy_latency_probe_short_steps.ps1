param([switch]$PrintOnly, [switch]$ShapeWarmup, [switch]$SinglePaste)
$ErrorActionPreference = 'Stop'
$probeProject = Split-Path $PSScriptRoot -Parent
$probePython = Join-Path $probeProject '.venv-recovery/Scripts/python.exe'
$probeBuilder = Join-Path $PSScriptRoot 'build_latency_probe_transfer.py'
$probeBuilderArgs = @()
if ($ShapeWarmup) { $probeBuilderArgs += '--shape-warmup' }
$probeJson = & $probePython $probeBuilder @probeBuilderArgs
if ($LASTEXITCODE -ne 0) { throw 'Could not generate verified transfer commands' }
$probePlan = ($probeJson -join "`n") | ConvertFrom-Json
if ($PrintOnly -and -not $SinglePaste) { Write-Output $probeJson; exit 0 }
if (-not $SinglePaste) {
Write-Host ('Short commands: {0}; no server experiment is started by this helper.' -f $probePlan.steps.Count)
Write-Host 'For each step: paste in SERVER, wait for its OK marker, then return HERE.'
$probeIndex = 0
while ($probeIndex -lt $probePlan.steps.Count) {
    $probeStep = $probePlan.steps[$probeIndex]
    Set-Clipboard -Value ($probeStep.command + "`n")
    Write-Host ('Step {0}/{1} copied ({2} characters).' -f ($probeIndex + 1), $probePlan.steps.Count, $probeStep.command.Length)
    Write-Host ('Expected server output: {0}' -f $probeStep.expected_marker)
    $probeAnswer = Read-Host 'After server OK press Enter; if failed type r to retry; q to stop'
    if ($probeAnswer -eq 'q') { exit 0 }
    if ($probeAnswer -eq '') { $probeIndex++ }
}
Write-Host ('Verified source target: {0}' -f $probePlan.script)
Write-Host ('Expected SHA256: {0}' -f $probePlan.sha256)
}
$probeLaunch = @'
PROBE_SCRIPT="__SCRIPT__"
if cd /root/CarbonAffinity && .venv/bin/python -c 'import hashlib,sys; assert hashlib.sha256(open(sys.argv[1],"rb").read()).hexdigest()==sys.argv[2]' "$PROBE_SCRIPT" "__HASH__" && bash -n "$PROBE_SCRIPT"; then
    PROBE="/root/CarbonAffinity/results/__PREFIX__$(date -u +%Y%m%dT%H%M%SZ)"
    nohup bash "$PROBE_SCRIPT" "$PROBE" > "${PROBE}.launcher.log" 2>&1 < /dev/null &
    echo "PROBE_PID=$! ROOT=$PROBE"
else
    echo "SOURCE_OR_SYNTAX_FAILED_NOT_STARTED"
fi
'@
$probeLaunch = $probeLaunch.Replace('__SCRIPT__', $probePlan.script).Replace('__HASH__', $probePlan.sha256).Replace('__PREFIX__', $probePlan.result_prefix).Replace("`r`n", "`n")
if ($SinglePaste) {
    # Explicit guards are required: errexit is ignored in an if-tested subshell.
    # exit only terminates this installer subshell, never the interactive terminal.
    $probeCommands = @($probePlan.steps | ForEach-Object { $_.command + ' || exit 1' })
    $probeLaunch = "if (`n" + ($probeCommands -join "`n") + "`n); then`n" + $probeLaunch + "`nelse`n    echo TRANSFER_FAILED_NOT_STARTED`nfi"
    if ($PrintOnly) { Write-Output $probeLaunch; exit 0 }
    Set-Clipboard -Value ($probeLaunch + "`n")
    Write-Host 'ONE complete command copied. Paste once in SERVER; no manual step confirmations.'
    Write-Host 'All part/source checks and Bash syntax must pass before the 30-row diagnostic starts.'
    Write-Host ('Expected SHA256: {0}' -f $probePlan.sha256)
    exit 0
}
Set-Clipboard -Value ($probeLaunch + "`n")
Write-Host 'Final START command copied. Paste once in SERVER to launch the 30-row diagnostic.'
