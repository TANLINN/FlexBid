#!/usr/bin/env bash
# Read-only location/region evidence collector for CarbonAffinity testbeds.
# It queries only non-secret placement fields from common cloud metadata APIs.

set -u

TIMEOUT_S="${REGION_CHECK_TIMEOUT_S:-4}"

heading() {
  printf '\n=== %s ===\n' "$1"
}

get() {
  curl -fsS --max-time "$TIMEOUT_S" "$@" 2>/dev/null || true
}

show_if_present() {
  local label="$1"
  local value="$2"
  if [[ -n "$value" ]]; then
    printf '%s=%s\n' "$label" "$value"
  fi
}

heading "host"
printf 'timestamp_utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
printf 'hostname=%s\n' "$(hostname 2>/dev/null || true)"
printf 'private_addresses=%s\n' "$(hostname -I 2>/dev/null | xargs || true)"
printf 'default_route=%s\n' "$(ip route get 1.1.1.1 2>/dev/null | head -n 1 || true)"
if command -v nvidia-smi >/dev/null 2>&1; then
  nvidia-smi --query-gpu=index,name,uuid --format=csv,noheader 2>/dev/null || true
fi

heading "allowlisted platform variables"
found_env=0
for key in \
  REGION REGION_ID ZONE ZONE_ID AVAILABILITY_ZONE \
  AWS_REGION AWS_DEFAULT_REGION AWS_AVAILABILITY_ZONE \
  AZURE_REGION AZURE_LOCATION \
  GOOGLE_CLOUD_REGION GOOGLE_CLOUD_ZONE \
  ALIBABA_CLOUD_REGION_ID ALIBABA_CLOUD_ZONE_ID \
  ALICLOUD_REGION_ID ALICLOUD_ZONE_ID; do
  if [[ -n "${!key-}" ]]; then
    printf '%s=%s\n' "$key" "${!key}"
    found_env=1
  fi
done
if [[ "$found_env" -eq 0 ]]; then
  echo "none"
fi

heading "Alibaba Cloud metadata"
aliyun_token="$(get -X PUT \
  -H 'X-aliyun-ecs-metadata-token-ttl-seconds: 60' \
  http://100.100.100.200/latest/api/token)"
for field in region-id zone-id instance/instance-type; do
  if [[ -n "$aliyun_token" ]]; then
    value="$(get -H "X-aliyun-ecs-metadata-token: $aliyun_token" \
      "http://100.100.100.200/latest/meta-data/$field")"
  else
    value="$(get "http://100.100.100.200/latest/meta-data/$field")"
  fi
  show_if_present "${field//\//_}" "$value"
done

heading "AWS metadata"
aws_token="$(get -X PUT \
  -H 'X-aws-ec2-metadata-token-ttl-seconds: 60' \
  http://169.254.169.254/latest/api/token)"
if [[ -n "$aws_token" ]]; then
  for field in placement/region placement/availability-zone placement/availability-zone-id instance-type; do
    value="$(get -H "X-aws-ec2-metadata-token: $aws_token" \
      "http://169.254.169.254/latest/meta-data/$field")"
    show_if_present "${field//\//_}" "$value"
  done
fi

heading "Azure metadata"
for field in location zone physicalZone vmSize; do
  value="$(get -H 'Metadata: true' \
    "http://169.254.169.254/metadata/instance/compute/$field?api-version=2025-04-07&format=text")"
  show_if_present "$field" "$value"
done

heading "Google Cloud metadata"
gcp_zone="$(get -H 'Metadata-Flavor: Google' \
  http://metadata.google.internal/computeMetadata/v1/instance/zone)"
show_if_present "zone" "$gcp_zone"

heading "public egress geolocation (supporting evidence only)"
public_json="$(get https://ipinfo.io/json)"
if [[ -n "$public_json" ]]; then
  printf '%s\n' "$public_json"
else
  echo "unavailable"
fi

cat <<'EOF'

Interpretation:
1. Prefer provider metadata region/zone over public-IP geolocation.
2. A different zone inside one cloud region is not necessarily a different grid.
3. A public egress location can be wrong when the platform uses NAT or a proxy.
4. Keep the original platform region label or order page as additional evidence.
EOF
