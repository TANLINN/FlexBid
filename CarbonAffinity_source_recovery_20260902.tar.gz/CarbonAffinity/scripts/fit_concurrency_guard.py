from __future__ import annotations

import argparse
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path


def quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, max(0, math.ceil(q * len(ordered)) - 1))]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--profiles", type=Path, nargs="+", required=True)
    parser.add_argument("--quantile", type=float, default=0.95)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = []
    for path in sorted(args.input_root.glob("*.jsonl")):
        rows.extend(json.loads(line) for line in path.read_text().splitlines() if line.strip())
    if not rows:
        raise RuntimeError("no concurrency measurements")
    baselines: dict[tuple[str, int, str], list[dict]] = defaultdict(list)
    for row in rows:
        baselines[(row["region_id"], row["prompt_tokens"], row["mode"])].append(row)
    warm_ttft_slopes, warm_tpot_slopes = [], []
    cold_ttft_cells, cold_tpot_cells = [], []
    for cell_rows in baselines.values():
        one = [row for row in cell_rows if row["concurrency"] == 1]
        if not one:
            continue
        base_ttft = statistics.median(float(row["ttft_p95_ms"]) for row in one)
        valid_tpot = [float(row["tpot_p95_ms"]) for row in one if row.get("tpot_p95_ms") is not None]
        base_tpot = statistics.median(valid_tpot) if valid_tpot else 0.0
        for row in cell_rows:
            extra = int(row["concurrency"]) - 1
            if extra <= 0:
                continue
            ttft_slope = max(0.0, (float(row["ttft_p95_ms"]) - base_ttft) / extra)
            if row.get("tpot_p95_ms") is not None:
                tpot_slope = max(0.0, (float(row["tpot_p95_ms"]) - base_tpot) / extra)
            else:
                tpot_slope = 0.0
            if row["mode"] == "warm":
                warm_ttft_slopes.append(ttft_slope)
                warm_tpot_slopes.append(tpot_slope)
            else:
                cold_ttft_cells.append((int(row["prompt_tokens"]), ttft_slope))
                cold_tpot_cells.append((int(row["prompt_tokens"]), tpot_slope))
    if not warm_ttft_slopes or not warm_tpot_slopes or not cold_ttft_cells or not cold_tpot_cells:
        raise RuntimeError("insufficient concurrency levels")
    ttft_base = quantile(warm_ttft_slopes, args.quantile)
    tpot_base = quantile(warm_tpot_slopes, args.quantile)
    ttft_cold = quantile([
        max(0.0, slope - ttft_base) / tokens
        for tokens, slope in cold_ttft_cells
    ], args.quantile)
    tpot_cold = quantile([
        max(0.0, slope - tpot_base) / tokens
        for tokens, slope in cold_tpot_cells
    ], args.quantile)
    report = {
        "rows": len(rows), "quantile": args.quantile,
        "active_ttft_base_ms_per_request": ttft_base,
        "active_ttft_ms_per_cold_token_per_request": ttft_cold,
        "tpot_active_base_ms_per_request": tpot_base,
        "tpot_active_ms_per_cold_token_per_request": tpot_cold,
        "regions": sorted({row["region_id"] for row in rows}),
    }
    for path in args.profiles:
        profile = json.loads(path.read_text())
        # Zero the superseded global slopes and install the stratified model.
        profile["active_ttft_ms_per_request"] = 0.0
        profile["tpot_ms_per_active_request"] = 0.0
        profile["active_ttft_base_ms_per_request"] = ttft_base
        profile["active_ttft_ms_per_cold_token_per_request"] = ttft_cold
        profile["tpot_active_base_ms_per_request"] = tpot_base
        profile["tpot_active_ms_per_cold_token_per_request"] = tpot_cold
        path.write_text(json.dumps(profile, indent=2), encoding="utf-8")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
