"""Fit per-GPU service-energy candidates from the paired cache-energy campaign."""
from __future__ import annotations

import argparse
import itertools
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

import numpy as np


GPUS = tuple(range(8))
CACHED_TARGETS = (1568, 7840, 31360)
PROMPTS = tuple(value + 384 for value in CACHED_TARGETS)
OUTPUTS = (64, 192)
CONCURRENCIES = (1, 3)
REPEATS = (0, 1)
MODES = ("cold", "warm")


def read_rows(root: Path) -> list[dict]:
    rows = []
    for path in sorted((root / "raw").glob("gpu_*/measurements.jsonl")):
        rows.extend(json.loads(line) for line in path.read_text().splitlines()
                    if line.strip())
    return rows


def nonnegative_least_squares(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    best = np.zeros(x.shape[1], dtype=float)
    best_error = float(np.dot(y, y))
    for mask in range(1, 1 << x.shape[1]):
        columns = [index for index in range(x.shape[1]) if mask & (1 << index)]
        values = np.linalg.lstsq(x[:, columns], y, rcond=None)[0]
        if np.any(values < 0):
            continue
        candidate = np.zeros(x.shape[1], dtype=float)
        candidate[columns] = values
        error = float(np.sum((x @ candidate - y) ** 2))
        if error < best_error:
            best, best_error = candidate, error
    return best


def validate_source(root: Path, rows: list[dict]) -> dict:
    expected = set(itertools.product(
        GPUS, CACHED_TARGETS, OUTPUTS, CONCURRENCIES, REPEATS, MODES,
    ))
    identities = [(
        int(row["gpu_index"]), int(row["cached_context_target"]),
        int(row["output_tokens"]), int(row["concurrency"]),
        int(row["repeat"]), str(row["mode"]),
    ) for row in rows]
    summary = json.loads((root / "CACHE_ENERGY_SUMMARY.json").read_text())
    checks = {
        "exact_384_rows": len(rows) == 384,
        "complete_unique_design": len(set(identities)) == 384 and set(identities) == expected,
        "all_rows_valid": all(row.get("valid") is True for row in rows),
        "all_physical_resets_confirmed": all(
            row.get("reset", {}).get("confirmed") is True for row in rows
        ),
        "all_requests_succeeded": all(
            len(row.get("results", [])) == int(row["concurrency"])
            and all(result.get("success") is True for result in row["results"])
            for row in rows
        ),
        "warm_cache_exact": all(
            result.get("cached_prompt_tokens_observed") == row["cached_context_target"]
            for row in rows if row["mode"] == "warm" for result in row["results"]
        ),
        "cold_cache_none_or_zero": all(
            result.get("cached_prompt_tokens_observed") in (None, 0)
            for row in rows if row["mode"] == "cold" for result in row["results"]
        ),
        "steady_state_observed": summary.get("steady_state_observed") is True,
        "post_prewarm_tuning_zero": not any(
            summary.get("post_prewarm_tuning_events", {}).values()
        ),
        "complete_marker": json.loads(
            (root / "EXPERIMENT_COMPLETE.json").read_text()
        ).get("status") == "COMPLETE",
        "fatal_absent": not (root / "FATAL.json").exists(),
    }
    if not all(checks.values()):
        raise ValueError("cache-energy source failed integrity checks: " + json.dumps(checks))
    return checks


def features(row: dict) -> list[float]:
    prompt = int(row["prompt_tokens"])
    cached = int(row["cached_context_target"]) if row["mode"] == "warm" else 0
    return [1.0, prompt - cached, cached, float(row["output_tokens"])]


def per_request_energy(row: dict) -> float:
    value = float(row["total_energy_j"]) / int(row["concurrency"])
    if not math.isfinite(value) or value <= 0:
        raise ValueError("invalid per-request energy")
    return value


def fit_gpu(rows: list[dict]) -> dict:
    solo = [row for row in rows if int(row["concurrency"]) == 1]
    x = np.asarray([features(row) for row in solo], dtype=float)
    y = np.asarray([per_request_energy(row) for row in solo], dtype=float)
    if len(solo) != 24 or np.linalg.matrix_rank(x) != 4:
        raise ValueError("per-GPU solo-energy design is incomplete or rank deficient")
    beta = nonnegative_least_squares(x, y)

    grouped: dict[tuple[str, int, int], dict[int, list[float]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for row in rows:
        key = str(row["mode"]), int(row["prompt_tokens"]), int(row["output_tokens"])
        grouped[key][int(row["concurrency"])].append(per_request_energy(row))
    cells = {}
    for (mode, prompt, output), curves in sorted(grouped.items()):
        if set(curves) != {1, 3} or any(len(values) != 2 for values in curves.values()):
            raise ValueError("per-GPU batch cell is incomplete")
        baseline = statistics.median(curves[1])
        cells[f"{mode}|{prompt}|{output}"] = {
            "1": 1.0,
            "3": statistics.median(curves[3]) / baseline,
        }
    return {
        "base_request_j": float(beta[0]),
        "cold_prefill_j_per_token": float(beta[1]),
        "cached_prefill_j_per_token": float(beta[2]),
        "decode_j_per_token": float(beta[3]),
        "batch_energy_model": {
            "schema_version": 1,
            "semantics": "per-request total service energy relative to concurrency one",
            "prompt_buckets": list(PROMPTS),
            "output_buckets": list(OUTPUTS),
            "global": {},
            "cells": cells,
            "max_measured_concurrency": 3,
        },
    }


def nearest_bucket(value: int, buckets: list[int]) -> int:
    value = max(1, value)
    return min(buckets, key=lambda bucket: abs(math.log2(value / bucket)))


def batch_multiplier(model: dict, prompt: int, output: int, mode: str, n: int) -> float:
    prompt_bucket = nearest_bucket(prompt, model["prompt_buckets"])
    output_bucket = nearest_bucket(output, model["output_buckets"])
    curve = {
        int(key): float(value)
        for key, value in model["cells"][f"{mode}|{prompt_bucket}|{output_bucket}"].items()
    }
    totals = []
    running = 0.0
    for anchor in sorted(curve):
        running = max(running, anchor * curve[anchor])
        totals.append((anchor, running))
    n = max(1, min(n, totals[-1][0]))
    if n == totals[0][0]:
        return totals[0][1] / n
    for (left_n, left_total), (right_n, right_total) in zip(totals, totals[1:]):
        if n <= right_n:
            weight = (n - left_n) / (right_n - left_n)
            return (left_total + weight * (right_total - left_total)) / n
    return totals[-1][1] / n


def predict(row: dict, profile: dict) -> float:
    base, cold, cached, output = features(row)
    solo = (
        base * profile["base_request_j"]
        + cold * profile["cold_prefill_j_per_token"]
        + cached * profile["cached_prefill_j_per_token"]
        + output * profile["decode_j_per_token"]
    )
    return solo * batch_multiplier(
        profile["batch_energy_model"], int(row["prompt_tokens"]),
        int(row["output_tokens"]), str(row["mode"]), int(row["concurrency"]),
    )


def metric(values: list[float]) -> dict:
    ordered = sorted(values)
    def q(fraction):
        position = (len(ordered) - 1) * fraction
        left = int(position)
        right = min(left + 1, len(ordered) - 1)
        weight = position - left
        return ordered[left] * (1 - weight) + ordered[right] * weight
    return {
        "samples": len(values),
        "median": statistics.median(values),
        "q95": q(.95),
        "maximum": max(values),
    }


def evaluate(rows: list[dict], profiles: dict[str, dict]) -> dict:
    groups = defaultdict(list)
    for row in rows:
        actual = per_request_energy(row)
        predicted = predict(row, profiles[str(row["gpu_index"])])
        if not math.isfinite(predicted) or predicted <= 0:
            raise ValueError("candidate emitted invalid energy")
        ape = abs(predicted - actual) / actual
        groups["overall"].append(ape)
        groups[f"{row['mode']}|n{row['concurrency']}"] .append(ape)
        groups[f"gpu_{row['gpu_index']}"] .append(ape)
    return {key: metric(values) for key, values in sorted(groups.items())}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = args.input_root.resolve()
    rows = read_rows(root)
    checks = validate_source(root, rows)
    profiles = {
        str(gpu): fit_gpu([row for row in rows if int(row["gpu_index"]) == gpu])
        for gpu in GPUS
    }
    evaluation = evaluate(rows, profiles)
    candidate = {
        "schema_version": 1,
        "status": "CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION",
        "candidate_frozen": False,
        "independent_validation_passed": False,
        "source_root": str(root),
        "energy_scope": "NVML total GPU energy over batch service interval; idle power in interval included",
        "setup_scope": "warm prime energy excluded from service-energy fit",
        "training_design": {
            "gpus": list(GPUS), "cached_targets": list(CACHED_TARGETS),
            "prompt_tokens": list(PROMPTS), "output_tokens": list(OUTPUTS),
            "concurrency": list(CONCURRENCIES), "repeats": list(REPEATS),
            "rows": len(rows),
        },
        "runtime_semantics": {
            "prompt_output_bucket_selection": "nearest_log2",
            "batch_total_interpolation": "linear_between_n1_and_n3_then_equal_allocation",
        },
        "profiles": profiles,
        "development_evaluation": evaluation,
        "source_checks": checks,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError(args.output)
    args.output.write_text(json.dumps(candidate, indent=2), encoding="utf-8")
    print("STATUS =", candidate["status"])
    print("ROWS =", len(rows), "PROFILES =", len(profiles))
    print("DEVELOPMENT_APE =", json.dumps(evaluation, sort_keys=True))
    print("CANDIDATE =", args.output.resolve())
    print("CANDIDATE_FROZEN = False")


if __name__ == "__main__":
    main()
