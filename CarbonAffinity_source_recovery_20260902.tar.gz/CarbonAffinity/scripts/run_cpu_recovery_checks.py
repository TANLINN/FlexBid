"""Compile and test the recovered source without importing/starting CUDA."""
from __future__ import annotations

import argparse
import compileall
import platform
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path

from carbonaffinity.artifacts import sha256, write_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("use a fresh test report name")
    root = Path(__file__).resolve().parents[1]
    compiled = all(compileall.compile_dir(root / name, quiet=1, force=True) for name in ("carbonaffinity", "scripts", "tests"))
    suite = unittest.defaultTestLoader.discover(str(root / "tests"))
    count = suite.countTestCases()
    if count == 0:
        raise RuntimeError("test discovery found zero tests")
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    sources = sorted(p for name in ("carbonaffinity", "scripts", "tests") for p in (root / name).glob("*.py"))
    data = sorted(p for name in ("raw", "normalized", "carbon") for p in (root / "data" / name).glob("*") if p.is_file())
    report = {"status": "PASS" if compiled and result.wasSuccessful() and not result.skipped else "FAIL",
              "created_utc": datetime.now(timezone.utc).isoformat(), "python": sys.version, "platform": platform.platform(),
              "compiled": compiled, "tests_run": result.testsRun, "failures": len(result.failures),
              "errors": len(result.errors), "skipped": len(result.skipped),
              "physical_gpu_validation_performed": False, "restored_historical_gpu_measurements": False,
              "source_sha256": {p.relative_to(root).as_posix(): sha256(p) for p in sources},
              "retained_data_sha256": {p.relative_to(root).as_posix(): sha256(p) for p in data}}
    write_json(args.output, report)
    print("RECOVERY_CPU_CHECKS =", report["status"], "tests =", result.testsRun)
    print("REPORT =", args.output.resolve())
    raise SystemExit(0 if report["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
