from __future__ import annotations

import argparse
import csv
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Callable

from carbonaffinity.carbon import CarbonTrace, carbon_grams
from carbonaffinity.config import load_config, resolve_path


Candidate = dict[str, Any]
Record = dict[str, Any]
HistoricalLookup = Callable[[str, float], float | None]


def read_jsonl(path: Path) -> list[Record]:
    return [
        json.loads(line)
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def selected_candidate(record: Record) -> Candidate:
    selected = record["decision"]["selected_region"]
    return next(
        candidate
        for candidate in record["decision"]["candidates"]
        if candidate["region_id"] == selected
    )


def same_state_cleanest(record: Record) -> Candidate:
    """Return cleanest-now's choice under this record's exact candidate state."""
    candidates = record["decision"]["candidates"]
    feasible = [row for row in candidates if row.get("slo_feasible")]
    selectable = feasible or candidates
    return min(
        selectable,
        key=lambda row: (
            float("inf")
            if row.get("forecast_lbs_per_mwh") is None
            else float(row["forecast_lbs_per_mwh"]),
            float(row.get("score", 0.0)),
            str(row["region_id"]),
        ),
    )


def future_request_counts(rows: list[Record]) -> dict[str, int]:
    sessions: dict[str, list[Record]] = defaultdict(list)
    for row in rows:
        sessions[str(row.get("session_id") or row["request_id"])].append(row)
    result: dict[str, int] = {}
    for session_rows in sessions.values():
        ordered = sorted(
            session_rows,
            key=lambda row: (
                float(row.get("arrival_ms", 0.0)),
                int(row.get("turn_id", 0)),
                str(row["request_id"]),
            ),
        )
        for index, row in enumerate(ordered):
            result[str(row["request_id"])] = len(ordered) - index - 1
    return result


def request_runtime_s(record: Record) -> float:
    completion = record["completion"]
    return max(
        0.0,
        (
            int(completion["completed_wall_time_ns"])
            - int(completion["dispatch_wall_time_ns"])
        )
        / 1e9,
    )


def settled_candidate_carbon(
    record: Record,
    candidate: Candidate,
    historical_lookup: HistoricalLookup | None,
) -> float | None:
    if historical_lookup is None:
        return None
    carbon_time_s = float(record["routing_carbon_timestamp_s"]) + request_runtime_s(record)
    intensity = historical_lookup(str(candidate["region_id"]), carbon_time_s)
    if intensity is None:
        return None
    return carbon_grams(float(candidate["energy_j"]), intensity)


def candidate_fields(prefix: str, candidate: Candidate) -> dict[str, Any]:
    return {
        f"{prefix}_region": candidate["region_id"],
        f"{prefix}_cached_tokens": int(candidate.get("cached_tokens", 0)),
        f"{prefix}_energy_j": float(candidate.get("energy_j", 0.0)),
        f"{prefix}_state_loss_energy_j": float(
            candidate.get("state_loss_energy_j", 0.0)
        ),
        f"{prefix}_forecast_intensity_lbs_per_mwh": candidate.get(
            "forecast_lbs_per_mwh"
        ),
        f"{prefix}_forecast_carbon_g": candidate.get("forecast_carbon_g"),
        f"{prefix}_ttft_ms": float(candidate.get("ttft_ms", 0.0)),
        f"{prefix}_tpot_ms": float(candidate.get("tpot_ms", 0.0)),
        f"{prefix}_slo_feasible": bool(candidate.get("slo_feasible")),
        f"{prefix}_queue_depth": int(candidate.get("queue_depth", 0)),
        f"{prefix}_projected_batch_size": int(
            candidate.get("projected_batch_size", 1)
        ),
        f"{prefix}_allocated_energy_multiplier": float(
            candidate.get("allocated_energy_multiplier", 1.0)
        ),
    }


def analyze_pair(
    ca_rows: list[Record],
    clean_rows: list[Record],
    repetition: str,
    window: str,
    historical_lookup: HistoricalLookup | None = None,
) -> list[dict[str, Any]]:
    ca_by_id = {str(row["request_id"]): row for row in ca_rows}
    clean_by_id = {str(row["request_id"]): row for row in clean_rows}
    if ca_by_id.keys() != clean_by_id.keys():
        missing_ca = sorted(clean_by_id.keys() - ca_by_id.keys())
        missing_clean = sorted(ca_by_id.keys() - clean_by_id.keys())
        raise RuntimeError(
            f"request mismatch in {repetition}/{window}: "
            f"missing_ca={missing_ca[:3]}, missing_cleanest={missing_clean[:3]}"
        )

    future_counts = future_request_counts(ca_rows)
    output: list[dict[str, Any]] = []
    for request_id, ca in ca_by_id.items():
        clean = clean_by_id[request_id]
        ca_selected = selected_candidate(ca)
        ca_cleanest = same_state_cleanest(ca)
        clean_selected = selected_candidate(clean)
        ca_settled = settled_candidate_carbon(
            ca, ca_selected, historical_lookup
        )
        cleanest_counterfactual_settled = settled_candidate_carbon(
            ca, ca_cleanest, historical_lookup
        )
        future = future_counts[request_id]

        row: dict[str, Any] = {
            "repetition": repetition,
            "window": window,
            "request_id": request_id,
            "session_id": str(ca.get("session_id") or request_id),
            "turn_id": int(ca.get("turn_id", 0)),
            "actual_future_requests_in_window": future,
            "terminal_request_in_window": future == 0,
            "prompt_tokens": int(ca.get("prompt_tokens", 0)),
            "shared_prefix_tokens": int(ca.get("shared_prefix_tokens", 0)),
            "max_output_tokens": int(ca.get("max_output_tokens", 0)),
            "ca_previous_region": ca["decision"].get("previous_region"),
            "ca_migrated": bool(ca["decision"].get("migrated")),
            "ca_reason": str(ca["decision"].get("reason", "")),
            "cleanest_previous_region": clean["decision"].get(
                "previous_region"
            ),
            "cleanest_migrated": bool(clean["decision"].get("migrated")),
            "observed_routes_equal": (
                ca_selected["region_id"] == clean_selected["region_id"]
            ),
            "same_state_routes_equal": (
                ca_selected["region_id"] == ca_cleanest["region_id"]
            ),
            "ca_settled_profile_carbon_g": ca.get(
                "settled_profile_carbon_g"
            ),
            "cleanest_observed_settled_profile_carbon_g": clean.get(
                "settled_profile_carbon_g"
            ),
            "ca_state_counterfactual_settled_carbon_g": ca_settled,
            "cleanest_state_counterfactual_settled_carbon_g": (
                cleanest_counterfactual_settled
            ),
        }
        row.update(candidate_fields("ca", ca_selected))
        row.update(candidate_fields("same_state_cleanest", ca_cleanest))
        row.update(candidate_fields("observed_cleanest", clean_selected))

        ca_forecast = ca_selected.get("forecast_carbon_g")
        clean_forecast = ca_cleanest.get("forecast_carbon_g")
        row["ca_predicted_advantage_vs_same_state_cleanest_g"] = (
            float(clean_forecast) - float(ca_forecast)
            if ca_forecast is not None and clean_forecast is not None
            else None
        )
        row["ca_settled_advantage_vs_same_state_cleanest_g"] = (
            cleanest_counterfactual_settled - ca_settled
            if ca_settled is not None
            and cleanest_counterfactual_settled is not None
            else None
        )
        output.append(row)
    return output


def mean_or_none(values: list[float]) -> float | None:
    return statistics.mean(values) if values else None


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    observed_different = [row for row in rows if not row["observed_routes_equal"]]
    same_state_different = [
        row for row in rows if not row["same_state_routes_equal"]
    ]
    terminal_same_state_different = [
        row
        for row in same_state_different
        if row["terminal_request_in_window"]
    ]
    terminal_migrations = [
        row
        for row in rows
        if row["terminal_request_in_window"] and row["ca_migrated"]
    ]
    predicted_advantages = [
        float(row["ca_predicted_advantage_vs_same_state_cleanest_g"])
        for row in same_state_different
        if row["ca_predicted_advantage_vs_same_state_cleanest_g"] is not None
    ]
    settled_advantages = [
        float(row["ca_settled_advantage_vs_same_state_cleanest_g"])
        for row in same_state_different
        if row["ca_settled_advantage_vs_same_state_cleanest_g"] is not None
    ]
    return {
        "requests": len(rows),
        "observed_route_matches": len(rows) - len(observed_different),
        "observed_route_match_rate": (
            (len(rows) - len(observed_different)) / len(rows) if rows else None
        ),
        "same_state_route_matches": len(rows) - len(same_state_different),
        "same_state_route_match_rate": (
            (len(rows) - len(same_state_different)) / len(rows)
            if rows
            else None
        ),
        "same_state_divergences": len(same_state_different),
        "terminal_same_state_divergences": len(
            terminal_same_state_different
        ),
        "terminal_carbon_affinity_migrations": len(terminal_migrations),
        "same_state_divergence_reasons": dict(
            Counter(row["ca_reason"] for row in same_state_different)
        ),
        "predicted_advantage_g_on_same_state_divergences": {
            "sum": sum(predicted_advantages),
            "mean": mean_or_none(predicted_advantages),
            "positive": sum(value > 0 for value in predicted_advantages),
            "negative": sum(value < 0 for value in predicted_advantages),
        },
        "settled_counterfactual_advantage_g_on_same_state_divergences": {
            "sum": sum(settled_advantages),
            "mean": mean_or_none(settled_advantages),
            "positive": sum(value > 0 for value in settled_advantages),
            "negative": sum(value < 0 for value in settled_advantages),
        },
    }


def make_historical_lookup(config_path: Path) -> HistoricalLookup:
    config = load_config(config_path)
    carbon = CarbonTrace.from_csv(
        resolve_path(config, config["carbon"]["trace"]),
        max_age_s=float(config["carbon"].get("max_age_s", 1800.0)),
    )

    def lookup(region_id: str, timestamp_s: float) -> float | None:
        return carbon.at(region_id, timestamp_s).historical_lbs_per_mwh

    return lookup


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Compare CarbonAffinity with cleanest-now both across observed "
            "runs and under CarbonAffinity's identical candidate state."
        )
    )
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--config-root", type=Path, default=Path("configs"))
    parser.add_argument(
        "--config-pattern",
        default="heldout_window_{window:02d}.generated.yaml",
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--csv", type=Path)
    args = parser.parse_args()

    root = args.root.resolve()
    repetitions = sorted(
        path
        for path in root.glob("rep_[0-9][0-9]")
        if path.is_dir()
    )
    if not repetitions:
        raise RuntimeError(f"no repetition directories under {root}")

    all_rows: list[dict[str, Any]] = []
    cell_summaries: dict[str, dict[str, Any]] = {}
    measured_carbon = Counter()
    for repetition in repetitions:
        windows = sorted(
            path
            for path in repetition.glob("window_[0-9][0-9]")
            if path.is_dir()
        )
        if not windows:
            raise RuntimeError(f"no window directories under {repetition}")
        for window in windows:
            window_index = int(window.name.rsplit("_", 1)[1])
            config_path = args.config_root / args.config_pattern.format(
                window=window_index
            )
            lookup = make_historical_lookup(config_path)
            ca_dir = window / "carbon_affinity"
            clean_dir = window / "cleanest_now"
            ca_audit = json.loads((ca_dir / "audit.json").read_text())
            clean_audit = json.loads((clean_dir / "audit.json").read_text())
            if not ca_audit.get("passed") or not clean_audit.get("passed"):
                raise RuntimeError(f"failed audit in {repetition.name}/{window.name}")
            measured_carbon["carbon_affinity"] += float(
                ca_audit["measured_operational_carbon_g"]
            )
            measured_carbon["cleanest_now"] += float(
                clean_audit["measured_operational_carbon_g"]
            )
            cell_rows = analyze_pair(
                read_jsonl(ca_dir / "requests.jsonl"),
                read_jsonl(clean_dir / "requests.jsonl"),
                repetition.name,
                window.name,
                lookup,
            )
            all_rows.extend(cell_rows)
            cell_summaries[f"{repetition.name}/{window.name}"] = summarize(
                cell_rows
            )

    summary = summarize(all_rows)
    summary["measured_operational_carbon_g"] = dict(measured_carbon)
    clean_carbon = measured_carbon["cleanest_now"]
    summary["measured_ca_advantage_vs_cleanest_pct"] = (
        100.0
        * (clean_carbon - measured_carbon["carbon_affinity"])
        / clean_carbon
        if clean_carbon
        else None
    )
    report = {
        "scope": {
            "root": str(root),
            "repetitions": len(repetitions),
            "comparison": "carbon_affinity vs cleanest_now",
        },
        "interpretation": {
            "observed_route_match": (
                "Compares routes from two independently executed policies; "
                "their prior cache and queue histories may differ."
            ),
            "same_state_route_match": (
                "Compares CarbonAffinity's selected route with the cleanest "
                "SLO-feasible candidate in CarbonAffinity's own candidate "
                "snapshot, holding cache, queue and batch state fixed."
            ),
            "settled_counterfactual": (
                "Uses candidate profile energy times settled regional carbon; "
                "it is model-based and is not per-request physical telemetry."
            ),
        },
        "overall": summary,
        "cells": cell_summaries,
    }

    output = args.output or root / "route_divergence_report.json"
    csv_output = args.csv or root / "route_divergence_rows.csv"
    output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    with csv_output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_rows[0]))
        writer.writeheader()
        writer.writerows(all_rows)

    print(f"requests = {summary['requests']}")
    print(
        "observed route match = "
        f"{summary['observed_route_matches']}/{summary['requests']} "
        f"({100 * summary['observed_route_match_rate']:.2f}%)"
    )
    print(
        "same-state route match = "
        f"{summary['same_state_route_matches']}/{summary['requests']} "
        f"({100 * summary['same_state_route_match_rate']:.2f}%)"
    )
    print(
        "terminal same-state divergences = "
        f"{summary['terminal_same_state_divergences']}"
    )
    print(
        "terminal CarbonAffinity migrations = "
        f"{summary['terminal_carbon_affinity_migrations']}"
    )
    print(
        "measured CA advantage vs cleanest = "
        f"{summary['measured_ca_advantage_vs_cleanest_pct']:.4f}%"
    )
    print(f"ROUTE_DIVERGENCE_REPORT={output}")
    print(f"ROUTE_DIVERGENCE_ROWS={csv_output}")


if __name__ == "__main__":
    main()
