from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import statistics
import time
from pathlib import Path
from dataclasses import asdict
import uuid

import pynvml

from carbonaffinity.materialize import PromptMaterializer
from carbonaffinity.models import RequestSpec
from carbonaffinity.region import RegionClient


def energy_mj(handle) -> float | None:
    try:
        return float(pynvml.nvmlDeviceGetTotalEnergyConsumption(handle))
    except (pynvml.NVMLError, AttributeError):
        return None


def power_w(handle) -> float | None:
    try:
        return pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
    except pynvml.NVMLError:
        return None


async def idle_power(handle, samples: int = 10, interval_s: float = 0.05) -> float:
    values = []
    for _ in range(samples):
        value = power_w(handle)
        if value is not None:
            values.append(value)
        await asyncio.sleep(interval_s)
    if not values:
        raise RuntimeError("NVML power telemetry unavailable")
    return statistics.median(values)


async def main_async(args: argparse.Namespace) -> None:
    if args.output.exists() and not args.resume:
        raise FileExistsError("use a new measurement output; existing data preserved")
    run_namespace = uuid.uuid4().hex
    materializer = PromptMaterializer(args.tokenizer)
    client = RegionClient({
        "id": args.region_id,
        "api_base": args.api_base,
        "api_key": args.api_key,
        "model": args.model,
        "admission_concurrency": max(args.concurrency),
    }, args.timeout_s)
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(args.gpu_index)
    rows = []
    if args.output.exists() and args.resume:
        rows = [json.loads(line) for line in args.output.read_text().splitlines() if line.strip()]
    complete = {
        (row["prompt_tokens"], row["output_tokens"], row["mode"], row["concurrency"], row["repeat"])
        for row in rows
    }
    try:
        warmup_raw = {"request_id": run_namespace, "session_id": run_namespace,
                      "prompt_tokens": 2048, "shared_prefix_tokens": 0}
        for number in range(2):
            warmup = RequestSpec(run_namespace + str(number), 0, 2048, 64, run_namespace)
            result = await client.complete(warmup, materializer.tokens(warmup_raw), cache_salt=run_namespace)
            if not result.success:
                raise RuntimeError("energy measurement prewarm failed")
        for prompt_tokens in args.prompt_tokens:
            for output_tokens in args.output_tokens:
                for mode in ("cold", "warm"):
                    for concurrency in args.concurrency:
                        for repeat in range(args.repeats):
                            key = (prompt_tokens, output_tokens, mode, concurrency, repeat)
                            if key in complete:
                                continue
                            namespace = f"{run_namespace}-{args.region_id}-{prompt_tokens}-{output_tokens}-{mode}-{concurrency}-{repeat}"
                            salt = hashlib.sha256(namespace.encode()).hexdigest()
                            if not await client.reset_prefix_cache():
                                raise RuntimeError("prefix-cache reset failed")
                            common_raw = {
                                "request_id": namespace,
                                "session_id": namespace,
                                "prompt_tokens": prompt_tokens,
                                "shared_prefix_tokens": prompt_tokens if mode == "warm" else 0,
                            }
                            common_prompt = materializer.tokens(common_raw)
                            if mode == "warm":
                                prime = RequestSpec(
                                    request_id=namespace + "-prime", arrival_ms=0,
                                    prompt_tokens=prompt_tokens, max_output_tokens=1,
                                    session_id=namespace, shared_prefix_tokens=prompt_tokens,
                                )
                                result = await client.complete(prime, common_prompt, cache_salt=salt)
                                if not result.success:
                                    raise RuntimeError(f"cache prime failed: {result.error}")
                                await asyncio.sleep(args.settle_s)
                            requests = []
                            for index in range(concurrency):
                                if mode == "warm":
                                    prompt = common_prompt
                                    request_salt = salt
                                else:
                                    raw = {
                                        "request_id": f"{namespace}-{index}",
                                        "session_id": f"{namespace}-{index}",
                                        "prompt_tokens": prompt_tokens,
                                        "shared_prefix_tokens": 0,
                                    }
                                    prompt = materializer.tokens(raw)
                                    request_salt = hashlib.sha256(f"{namespace}-{index}".encode()).hexdigest()
                                request = RequestSpec(
                                    request_id=f"{namespace}-request-{index}", arrival_ms=0,
                                    prompt_tokens=prompt_tokens, max_output_tokens=output_tokens,
                                    session_id=f"{namespace}-session-{index}",
                                    shared_prefix_tokens=prompt_tokens if mode == "warm" else 0,
                                )
                                requests.append(client.complete(request, prompt, cache_salt=request_salt))
                            idle_w = await idle_power(handle)
                            before_mj = energy_mj(handle)
                            before_ns = time.perf_counter_ns()
                            results = await asyncio.gather(*requests)
                            after_ns = time.perf_counter_ns()
                            after_mj = energy_mj(handle)
                            failures = [result for result in results if not result.success]
                            if failures:
                                raise RuntimeError(f"{len(failures)}/{len(results)} requests failed")
                            duration_s = (after_ns - before_ns) / 1e9
                            if before_mj is None or after_mj is None or after_mj < before_mj:
                                raise RuntimeError("NVML total-energy counter unavailable")
                            total_j = (after_mj - before_mj) / 1000.0
                            dynamic_j = max(0.0, total_j - idle_w * duration_s)
                            row = {
                                "region_id": args.region_id,
                                "gpu_index": args.gpu_index,
                                "prompt_tokens": prompt_tokens,
                                "output_tokens": output_tokens,
                                "mode": mode,
                                "concurrency": concurrency,
                                "repeat": repeat,
                                "duration_s": duration_s,
                                "idle_power_w": idle_w,
                                "total_energy_j": total_j,
                                "dynamic_energy_j": dynamic_j,
                                "dynamic_energy_per_request_j": dynamic_j / concurrency,
                                "cached_tokens": [result.cached_prompt_tokens_observed for result in results],
                                "results": [asdict(result) for result in results],
                            }
                            rows.append(row)
                            args.output.parent.mkdir(parents=True, exist_ok=True)
                            with args.output.open("a", encoding="utf-8") as handle_out:
                                handle_out.write(json.dumps(row) + "\n")
                                handle_out.flush()
                            print(json.dumps(row), flush=True)
                            await asyncio.sleep(args.settle_s)
    finally:
        pynvml.nvmlShutdown()
        await client.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--gpu-index", type=int, required=True)
    parser.add_argument("--prompt-tokens", type=int, nargs="+", default=[2048, 8192])
    parser.add_argument("--output-tokens", type=int, nargs="+", default=[32, 128, 512])
    parser.add_argument("--concurrency", type=int, nargs="+", default=[1, 2, 4, 8])
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--settle-s", type=float, default=0.5)
    parser.add_argument("--timeout-s", type=float, default=900)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    asyncio.run(main_async(parser.parse_args()))


if __name__ == "__main__":
    main()
