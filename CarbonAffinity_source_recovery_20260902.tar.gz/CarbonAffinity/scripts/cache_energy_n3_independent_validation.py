"""Independent held-out validation for the cache-energy n=1/3 candidate."""
from __future__ import annotations

import argparse
import asyncio
import itertools
import json
import math
import os
import random
import re
import signal
import socket
import statistics
import subprocess
import sys
import time
import uuid
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

try:
    from scripts import cache_energy_formal_n3 as energy
except ImportError:
    from scripts import cache_energy_experiment as energy
from scripts import fit_cache_energy_n3_candidate as fit


GPUS = tuple(range(8))
CACHED_TARGETS = (3920, 15680, 23520)
RESIDUAL = 384
OUTPUT = 128
CONCURRENCY = 2
REPEATS = (0, 1)
EXPECTED_ROWS = 96

THRESHOLDS = {
    "overall_median_ape_max": .10,
    "overall_q95_ape_max": .20,
    "group_q95_ape_max": .25,
    "pair_saving_sign_accuracy_min": 1.0,
    "pair_saving_error_q95_pp_max": 10.0,
}


def save(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)


def schedule(gpu: int) -> list[dict]:
    grid = list(itertools.product(CACHED_TARGETS, REPEATS))
    random.Random(20260901 + gpu).shuffle(grid)
    rows = []
    for cached, repeat in grid:
        modes = ("cold", "warm") if (gpu + repeat) % 2 == 0 else ("warm", "cold")
        for order, mode in enumerate(modes):
            rows.append({
                "pair_id": f"c{cached}_o{OUTPUT}_n{CONCURRENCY}_r{repeat}",
                "cached_context_target": cached,
                "prompt_tokens": cached + RESIDUAL,
                "output_tokens": OUTPUT,
                "concurrency": CONCURRENCY,
                "repeat": repeat,
                "mode": mode,
                "order": order,
            })
    return rows


async def collect(args, materializer, client, counter, engine_log: Path) -> None:
    from carbonaffinity.models import RequestSpec

    destination = args.output_root / "raw" / f"gpu_{args.gpu_index}" / "measurements.jsonl"
    destination.parent.mkdir(parents=True, exist_ok=True)
    namespace = uuid.uuid4().hex
    with destination.open("x", encoding="utf-8") as handle:
        for case in schedule(args.gpu_index):
            row = {
                **case,
                "gpu_index": args.gpu_index,
                "valid": False,
                "primes": [],
                "prime_energy_j": 0.0,
            }
            try:
                row["reset"] = await energy.physical_reset(client, engine_log)
                if not row["reset"]["confirmed"]:
                    raise RuntimeError("physical prefix-cache reset was not confirmed")
                prompts, salts = [], []
                for index in range(CONCURRENCY):
                    identity = f"energy-validation-{args.gpu_index}-{case['pair_id']}-{index}"
                    prompts.append(materializer.tokens({
                        "request_id": identity,
                        "session_id": identity,
                        "prompt_tokens": case["prompt_tokens"],
                        "shared_prefix_tokens": 0,
                    }))
                    salts.append(f"{namespace}:{identity}:{case['mode']}")
                row["cache_salts"] = salts
                if case["mode"] == "warm":
                    for index, (prompt, salt) in enumerate(zip(prompts, salts)):
                        identity = f"{case['pair_id']}-prime-{index}"
                        request = RequestSpec(identity, 0, len(prompt), 1, identity)
                        prime = await energy.meter([
                            lambda r=request, p=prompt, s=salt:
                            client.complete(r, p, cache_salt=s)
                        ], counter)
                        row["primes"].append(prime)
                        errors = energy.result_errors(prime["results"], len(prompt), 1)
                        if errors or prime.get("energy_error"):
                            raise RuntimeError(
                                f"prime failed: {errors} {prime.get('energy_error', '')}"
                            )
                        row["prime_energy_j"] += prime["total_energy_j"]
                jobs = []
                for index, (prompt, salt) in enumerate(zip(prompts, salts)):
                    identity = f"{case['pair_id']}-{case['mode']}-{index}"
                    request = RequestSpec(identity, 0, len(prompt), OUTPUT, identity)
                    jobs.append(
                        lambda r=request, p=prompt, s=salt:
                        client.complete(r, p, cache_salt=s)
                    )
                await asyncio.sleep(2.0)
                row.update(await energy.meter(jobs, counter))
                expected_cache = case["cached_context_target"] if case["mode"] == "warm" else None
                errors = energy.result_errors(
                    row["results"], case["prompt_tokens"], OUTPUT, expected_cache
                )
                if errors or row.get("energy_error"):
                    raise RuntimeError(
                        f"measurement failed: {errors} {row.get('energy_error', '')}"
                    )
                row["energy_per_request_j"] = row["total_energy_j"] / CONCURRENCY
                row["valid"] = True
            except Exception as exc:
                row["error"] = f"{type(exc).__name__}: {exc}"
            handle.write(json.dumps(row, allow_nan=False) + "\n")
            handle.flush()
            print(
                f"gpu={args.gpu_index} pair={case['pair_id']} mode={case['mode']} "
                f"valid={row['valid']} joules={row.get('total_energy_j')}",
                flush=True,
            )
            if not row["valid"]:
                raise RuntimeError(row["error"])


def quantile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    left = int(position)
    right = min(left + 1, len(ordered) - 1)
    weight = position - left
    return ordered[left] * (1 - weight) + ordered[right] * weight


def metrics(values: list[float]) -> dict:
    return {
        "samples": len(values),
        "median": statistics.median(values),
        "q95": quantile(values, .95),
        "maximum": max(values),
    }


def analyze(rows: list[dict], candidate: dict, tuning: dict[str, list]) -> dict:
    expected = {
        (gpu, case["pair_id"], case["mode"])
        for gpu in GPUS for case in schedule(gpu)
    }
    actual_keys = [
        (int(row["gpu_index"]), str(row["pair_id"]), str(row["mode"]))
        for row in rows
    ]
    source_design = candidate["training_design"]
    integrity = {
        "exact_96_rows": len(rows) == EXPECTED_ROWS,
        "12_rows_per_gpu": all(
            sum(int(row["gpu_index"]) == gpu for row in rows) == 12 for gpu in GPUS
        ),
        "complete_unique_design": len(set(actual_keys)) == EXPECTED_ROWS
        and set(actual_keys) == expected,
        "candidate_not_frozen": candidate.get("candidate_frozen") is False
        and candidate.get("independent_validation_passed") is False,
        "heldout_cached_targets": not set(CACHED_TARGETS)
        & set(source_design["cached_targets"]),
        "heldout_prompts": not {value + RESIDUAL for value in CACHED_TARGETS}
        & set(source_design["prompt_tokens"]),
        "heldout_output": OUTPUT not in source_design["output_tokens"],
        "heldout_concurrency": CONCURRENCY not in source_design["concurrency"],
        "all_rows_valid": all(row.get("valid") is True for row in rows),
        "physical_resets_confirmed": all(
            row.get("reset", {}).get("confirmed") is True for row in rows
        ),
        "requests_succeeded": all(
            len(row.get("results", [])) == CONCURRENCY
            and all(result.get("success") is True for result in row["results"])
            for row in rows
        ),
        "warm_cache_exact": all(
            result.get("cached_prompt_tokens_observed") == row["cached_context_target"]
            for row in rows if row["mode"] == "warm" for result in row["results"]
        ),
        "cold_cache_none_or_zero": all(
            result.get("cached_prompt_tokens_observed") in (None, 0)
            for row in rows if row["mode"] == "cold" for result in row["results"]
        ),
        "post_prewarm_tuning_zero": not any(tuning.values()),
    }

    ape_groups: dict[str, list[float]] = defaultdict(list)
    predicted = {}
    for row in rows:
        profile = candidate["profiles"][str(row["gpu_index"])]
        prediction = fit.predict(row, profile)
        actual = float(row["total_energy_j"]) / CONCURRENCY
        ape = abs(prediction - actual) / actual
        key = int(row["gpu_index"]), str(row["pair_id"]), str(row["mode"])
        predicted[key] = prediction
        ape_groups["overall"].append(ape)
        ape_groups[str(row["mode"])].append(ape)
        ape_groups[f"gpu_{row['gpu_index']}"].append(ape)
    accuracy = {key: metrics(values) for key, values in sorted(ape_groups.items())}

    actual_rows = {
        (int(row["gpu_index"]), str(row["pair_id"]), str(row["mode"])): row
        for row in rows
    }
    saving_errors, sign_correct = [], 0
    pair_results = []
    for gpu, pair_id, mode in sorted(expected):
        if mode != "cold":
            continue
        cold = actual_rows[gpu, pair_id, "cold"]
        warm = actual_rows[gpu, pair_id, "warm"]
        actual_saving = 100 * (1 - warm["total_energy_j"] / cold["total_energy_j"])
        predicted_saving = 100 * (
            1 - predicted[gpu, pair_id, "warm"] / predicted[gpu, pair_id, "cold"]
        )
        error = abs(predicted_saving - actual_saving)
        saving_errors.append(error)
        correct = (actual_saving > 0) == (predicted_saving > 0)
        sign_correct += int(correct)
        pair_results.append({
            "gpu_index": gpu,
            "pair_id": pair_id,
            "actual_saving_pct": actual_saving,
            "predicted_saving_pct": predicted_saving,
            "absolute_error_percentage_points": error,
            "sign_correct": correct,
        })
    saving = metrics(saving_errors)
    saving["sign_accuracy"] = sign_correct / len(pair_results)

    acceptance = {
        "integrity": all(integrity.values()),
        "overall_median_ape": accuracy["overall"]["median"]
        <= THRESHOLDS["overall_median_ape_max"],
        "overall_q95_ape": accuracy["overall"]["q95"]
        <= THRESHOLDS["overall_q95_ape_max"],
        "each_mode_q95_ape": all(
            accuracy[mode]["q95"] <= THRESHOLDS["group_q95_ape_max"]
            for mode in ("cold", "warm")
        ),
        "each_gpu_q95_ape": all(
            accuracy[f"gpu_{gpu}"]["q95"] <= THRESHOLDS["group_q95_ape_max"]
            for gpu in GPUS
        ),
        "saving_sign_accuracy": saving["sign_accuracy"]
        >= THRESHOLDS["pair_saving_sign_accuracy_min"],
        "saving_error_q95_pp": saving["q95"]
        <= THRESHOLDS["pair_saving_error_q95_pp_max"],
    }
    return {
        "status": "PASS" if all(acceptance.values()) else "FAIL",
        "candidate_frozen": False,
        "rows": len(rows),
        "thresholds": THRESHOLDS,
        "integrity": integrity,
        "acceptance": acceptance,
        "accuracy": accuracy,
        "paired_saving": saving,
        "pair_results": pair_results,
        "post_prewarm_tuning_events": tuning,
    }


def worker(args) -> None:
    import pynvml
    from carbonaffinity.materialize import PromptMaterializer
    from carbonaffinity.region import RegionClient

    pynvml.nvmlInit()
    try:
        handle = pynvml.nvmlDeviceGetHandleByIndex(args.gpu_index)
        counter = lambda: float(pynvml.nvmlDeviceGetTotalEnergyConsumption(handle))
        counter()

        async def run():
            client = RegionClient({
                "id": f"gpu_{args.gpu_index}",
                "api_base": f"http://127.0.0.1:{18000 + args.gpu_index}/v1",
                "api_key": "EMPTY",
                "model": args.model,
                "admission_concurrency": CONCURRENCY,
            }, 300)
            try:
                await collect(
                    args, PromptMaterializer(str(args.model_dir)), client, counter,
                    args.output_root / f"vllm_gpu_{args.gpu_index}.log",
                )
            finally:
                await client.close()
        asyncio.run(run())
    finally:
        pynvml.nvmlShutdown()


def campaign(args) -> None:
    import httpx
    import pynvml

    if os.name != "posix":
        raise RuntimeError("GPU campaign requires Linux")
    project, root = args.project_root.resolve(), args.output_root.resolve()
    if not root.is_relative_to(project / "results") or root == project / "results":
        raise ValueError("output must be a new directory under project/results")
    root.mkdir(parents=True, exist_ok=False)
    children, logs, servers = [], [], []
    telemetry = None

    def event(message: str) -> None:
        line = datetime.now(timezone.utc).isoformat() + " " + message
        print(line, flush=True)
        with (root / "events.log").open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")

    def spawn(command, path, extra=None):
        handle = path.open("x", encoding="utf-8")
        logs.append(handle)
        env = {
            **os.environ,
            "PYTHONPATH": str(project),
            "PYTHONNOUSERSITE": "1",
            "PYTHONUNBUFFERED": "1",
            "TRITON_PRINT_AUTOTUNING": "1",
            **(extra or {}),
        }
        process = subprocess.Popen(
            command, cwd=project, env=env, stdin=subprocess.DEVNULL,
            stdout=handle, stderr=subprocess.STDOUT, start_new_session=True,
        )
        children.append(process)
        return process

    def check_servers() -> None:
        for gpu, process in zip(GPUS, servers):
            if process.poll() is not None:
                raise RuntimeError(f"GPU {gpu} server exited: see vllm_gpu_{gpu}.log")
        if telemetry is not None and telemetry.poll() is not None:
            raise RuntimeError("GPU telemetry exited")

    def wait(workers, seconds: float) -> None:
        deadline = time.monotonic() + seconds
        while True:
            check_servers()
            if any(process.poll() not in (None, 0) for process in workers):
                raise RuntimeError("worker failed: inspect worker logs")
            if all(process.poll() == 0 for process in workers):
                return
            if time.monotonic() > deadline:
                raise TimeoutError("worker timeout")
            time.sleep(2)

    def interrupted(signum, frame):
        raise InterruptedError(f"signal {signum}")

    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, interrupted)
    try:
        support = energy.load_support(args.support_file)
        candidate = json.loads(args.candidate.read_text())
        if candidate.get("status") != "CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION":
            raise ValueError("candidate status is not ready for independent validation")
        if candidate.get("candidate_frozen") is not False:
            raise ValueError("candidate must remain unfrozen during validation")
        busy = subprocess.check_output(
            ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"],
            text=True,
        ).strip()
        if busy:
            raise RuntimeError("GPUs busy: stop the other workload explicitly before starting")
        for gpu in GPUS:
            with socket.socket() as sock:
                sock.settimeout(1)
                if sock.connect_ex(("127.0.0.1", 18000 + gpu)) == 0:
                    raise RuntimeError(f"port {18000 + gpu} occupied")
        pynvml.nvmlInit()
        try:
            for gpu in GPUS:
                pynvml.nvmlDeviceGetTotalEnergyConsumption(
                    pynvml.nvmlDeviceGetHandleByIndex(gpu)
                )
        finally:
            pynvml.nvmlShutdown()
        save(root / "PREREGISTRATION.json", {
            "stage": "cache-energy-n3-independent-validation",
            "candidate": str(args.candidate),
            "expected_rows": EXPECTED_ROWS,
            "cached_targets": list(CACHED_TARGETS),
            "prompt_tokens": [value + RESIDUAL for value in CACHED_TARGETS],
            "output_tokens": [OUTPUT],
            "concurrency": [CONCURRENCY],
            "repeats": list(REPEATS),
            "thresholds": THRESHOLDS,
            "case_order": {str(gpu): schedule(gpu) for gpu in GPUS},
        })
        save(root / "SUPERVISOR.json", {"pid": os.getpid()})
        telemetry = spawn([
            "nvidia-smi",
            "--query-gpu=timestamp,index,uuid,utilization.gpu,power.draw,clocks.sm",
            "--format=csv", "--loop=1",
        ], root / "gpu_telemetry.csv")
        commands = []
        with httpx.Client(timeout=2, trust_env=False) as client:
            for gpu in GPUS:
                event(f"STARTING_GPU={gpu}")
                command = [
                    str(Path(sys.executable).with_name("vllm")), "serve", str(args.model_dir),
                    "--served-model-name", args.model,
                    "--host", "127.0.0.1", "--port", str(18000 + gpu),
                    "--tensor-parallel-size", "1", "--enable-prefix-caching",
                    "--enable-prompt-tokens-details", "--enable-chunked-prefill",
                    "--max-num-batched-tokens", "784", "--max-num-seqs", "8",
                    "--max-model-len", "65536", "--gpu-memory-utilization", "0.92",
                ]
                commands.append(command)
                servers.append(spawn(command, root / f"vllm_gpu_{gpu}.log", {
                    "CUDA_VISIBLE_DEVICES": str(gpu),
                    "VLLM_SERVER_DEV_MODE": "1",
                }))
                deadline = time.monotonic() + 1200
                while True:
                    check_servers()
                    try:
                        if client.get(f"http://127.0.0.1:{18000 + gpu}/health").is_success:
                            break
                    except httpx.HTTPError:
                        pass
                    if time.monotonic() > deadline:
                        raise TimeoutError(f"GPU {gpu} startup timeout")
                    time.sleep(5)
                text = (root / f"vllm_gpu_{gpu}.log").read_text(errors="replace")
                if not re.search(r"max_num_batched_tokens[^0-9]*784([^0-9]|$)", text):
                    raise RuntimeError(f"GPU {gpu}: cap784 not observed")
                if not re.search(r"(?:attention )?block size to 784 tokens", text):
                    raise RuntimeError(f"GPU {gpu}: cache block784 not observed")
                event(f"VLLM_READY={gpu + 1}/8")
        save(root / "RUNTIME.json", {"commands": commands, "python": sys.version})
        base = [
            sys.executable, "-u", str(Path(__file__).resolve()),
            "--project-root", str(project), "--output-root", str(root),
            "--model-dir", str(args.model_dir), "--model", args.model,
            "--support-file", str(args.support_file), "--candidate", str(args.candidate),
        ]
        event("FIXED_SHAPE_PREWARM_START")
        wait([spawn(base + ["--mode", "prewarm"], root / "shape_prewarm.log")], 900)
        event(f"MEASUREMENT_START expected_rows={EXPECTED_ROWS}")
        workers = []
        for gpu in GPUS:
            destination = root / "raw" / f"gpu_{gpu}"
            destination.mkdir(parents=True)
            workers.append(spawn(
                base + ["--mode", "worker", "--gpu-index", str(gpu)],
                destination / "worker.log",
            ))
        wait(workers, 7200)
        rows = [
            json.loads(line)
            for path in sorted((root / "raw").glob("gpu_*/measurements.jsonl"))
            for line in path.read_text().splitlines() if line.strip()
        ]
        before = json.loads((root / "SHAPE_PREWARM.json").read_text())
        tuning = {}
        for gpu in GPUS:
            data = (root / f"vllm_gpu_{gpu}.log").read_bytes()
            offset = before["logs"][str(gpu)]["bytes"]
            if len(data) < offset:
                raise RuntimeError("engine log truncated")
            tuning[str(gpu)] = support.tuning_events(
                data[offset:].decode(errors="replace")
            )
        report = analyze(rows, candidate, tuning)
        save(root / "ENERGY_VALIDATION_REPORT.json", report)
        save(root / "EXPERIMENT_COMPLETE.json", {
            "status": "COMPLETE",
            "rows": len(rows),
            "validation_status": report["status"],
        })
        event("CACHE_ENERGY_INDEPENDENT_VALIDATION_" + report["status"])
        print(json.dumps(report, indent=2), flush=True)
    except Exception as exc:
        save(root / "FATAL.json", {
            "status": "FAIL", "error": f"{type(exc).__name__}: {exc}"
        })
        event("FAILED=" + str(exc))
        raise
    finally:
        for sig in (signal.SIGTERM, signal.SIGINT):
            signal.signal(sig, signal.SIG_IGN)
        for process in children:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 15
        while any(process.poll() is None for process in children) and time.monotonic() < deadline:
            time.sleep(.2)
        for process in children:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
        for handle in logs:
            handle.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("run", "worker", "prewarm"), default="run")
    parser.add_argument("--project-root", type=Path, default=Path("/root/CarbonAffinity"))
    parser.add_argument("--model-dir", type=Path, default=Path("/root/models/Qwen3.5-27B"))
    parser.add_argument("--model", default="Qwen3.5-27B")
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--support-file", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--gpu-index", type=int, choices=GPUS)
    args = parser.parse_args()
    sys.path.insert(0, str(args.project_root.resolve()))
    args.output_root = args.output_root.resolve()
    args.support_file = args.support_file.resolve()
    args.model_dir = args.model_dir.resolve()
    args.candidate = args.candidate.resolve()
    if args.mode == "run":
        campaign(args)
    elif args.mode == "worker":
        if args.gpu_index is None:
            parser.error("worker requires --gpu-index")
        worker(args)
    else:
        from carbonaffinity.materialize import PromptMaterializer
        from carbonaffinity.region import RegionClient
        support = energy.load_support(args.support_file)
        asyncio.run(support.prewarm(
            args.output_root, PromptMaterializer(str(args.model_dir)), RegionClient,
            gpus=GPUS, first_port=18000, model=args.model,
        ))


if __name__ == "__main__":
    main()
