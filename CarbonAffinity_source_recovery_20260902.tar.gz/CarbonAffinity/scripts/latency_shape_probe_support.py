"""Diagnostic-only fixed shape prewarm and audit; no production model changes.

Embedded into a verified file launcher by build_latency_shape_probe.py.
No measurements or tuning events are discarded. The 2000 ms threshold detects
the previously observed multi-second TTFT spike, not a service SLO.
"""
from __future__ import annotations

import ast
import asyncio
import hashlib
import itertools
import json
import os
import re
import sys
import time
import uuid
from dataclasses import asdict
from pathlib import Path

GPUS = (0, 6, 7)
PROMPTS = (16, 32, 64, 2048)
CACHE_OBSERVATION_POLICY = "optional_for_shape_prewarm; null remains unknown, not observed zero"
PASSES = 2
OUTPUT = 64
SPIKE_MS = 2000.0
CONCURRENT_PROMPT = 12288
CONCURRENT_WIDTH = 3


def tuning_events(text):
    events = []
    for part in text.split("Triton autotuning for function ")[1:]:
        key = re.search(r"with key as ([^\n]+)", part)
        elapsed = re.search(r"finished after ([0-9.]+)s", part)
        if key is None or elapsed is None:
            raise ValueError("incomplete tuning log; cannot establish coverage")
        value = ast.literal_eval(key.group(1).strip().rstrip(","))
        if not isinstance(value, tuple):
            raise ValueError("unexpected tuning key format")
        events.append({"kernel": part.splitlines()[0].rstrip(",\r"),
                       "key": list(value), "seconds": float(elapsed.group(1))})
    return events


def observed_o_blocks(events):
    # Match the diagnosed dtype/shape family, not unrelated tuned variants.
    tail = ["torch.bfloat16"] * 4 + ["torch.float32", "torch.bfloat16",
                                    "torch.int32", "torch.int32"]
    return {e["key"][3] for e in events
            if e["kernel"] == "chunk_fwd_kernel_o" and len(e["key"]) == 12
            and e["key"][:3] == [48, 128, 128] and e["key"][4:] == tail}


def fixed_schedule():
    return list(itertools.product(range(PASSES), PROMPTS))


async def prewarm(root, materializer, client_factory, *, gpus=GPUS,
                  first_port=18000, model="Qwen3.5-27B"):
    from carbonaffinity.artifacts import write_json
    from carbonaffinity.models import RequestSpec

    if os.environ.get("TRITON_PRINT_AUTOTUNING") != "1":
        raise RuntimeError("TRITON_PRINT_AUTOTUNING=1 required")
    gpus = tuple(gpus)
    if not gpus or len(set(gpus)) != len(gpus):
        raise ValueError("distinct nonempty GPU list required")
    ports = {gpu: first_port + (gpu if gpus == GPUS else index)
             for index, gpu in enumerate(gpus)}
    salt = uuid.uuid4().hex

    async def worker(gpu):
        client = client_factory({"id": f"gpu_{gpu}",
                                 "api_base": f"http://127.0.0.1:{ports[gpu]}/v1",
                                 "api_key": "EMPTY", "model": model,
                                 "admission_concurrency": CONCURRENT_WIDTH}, 120)
        records = []

        def validate(result, *, request_id, prompt_tokens, output_tokens,
                     cache_salt, artifact):
            records.append(asdict(result))
            # vLLM v0.17.1 completion_stream_generator only attaches cache
            # details when num_cached_tokens is truthy (zero is omitted).
            # Shape prewarm is not a cache-hit measurement. Keep missing
            # readings as None; formal measurements retain their cache checks.
            missing_allowed = result.cached_prompt_tokens_observed is None
            checks = {
                "request_succeeded": result.success,
                "output_tokens_exact": result.output_tokens == output_tokens,
                "prompt_tokens_exact": result.prompt_tokens_reported == prompt_tokens,
                "cache_observation_acceptable": (
                    result.cached_prompt_tokens_observed == 0 or missing_allowed),
            }
            write_json(root / "prewarm" / artifact,
                       {"diagnostic_prewarm_only": True, "result": records[-1],
                        "cache_salt": cache_salt, "checks": checks,
                        "missing_cache_observation_allowed": missing_allowed})
            if not all(checks.values()):
                detail = {"request_id": request_id,
                          "failed_checks": [k for k, v in checks.items() if not v],
                          "expected_prompt_tokens": prompt_tokens,
                          "expected_output_tokens": output_tokens,
                          "actual": {k: records[-1][k] for k in (
                              "success", "status_code", "error", "output_tokens",
                              "prompt_tokens_reported", "cached_prompt_tokens_observed")}}
                raise RuntimeError("prewarm result mismatch: " + json.dumps(detail))

        try:
            for repeat, prompt_tokens in fixed_schedule():
                request_id = f"shape-prewarm-{gpu}-{repeat}-{prompt_tokens}"
                request = RequestSpec(request_id=request_id, arrival_ms=0,
                                      prompt_tokens=prompt_tokens,
                                      max_output_tokens=OUTPUT, session_id=request_id)
                prompt = materializer.tokens({"request_id": request_id,
                                              "prompt_tokens": prompt_tokens,
                                              "shared_prefix_tokens": 0})
                cache_salt = f"{salt}:{request_id}"
                result = await client.complete(request, prompt, cache_salt=cache_salt)
                validate(result, request_id=request_id,
                         prompt_tokens=prompt_tokens, output_tokens=OUTPUT,
                         cache_salt=cache_salt,
                         artifact=f"gpu_{gpu}_{repeat}_{prompt_tokens}.json")

            warm_sessions = []
            for index in range(CONCURRENT_WIDTH):
                session_id = f"shape-prewarm-warm-{gpu}-{index}"
                prompt = materializer.tokens({"request_id": session_id,
                                              "prompt_tokens": CONCURRENT_PROMPT,
                                              "shared_prefix_tokens": 0})
                cache_salt = f"{salt}:{session_id}"
                request_id = f"{session_id}-prime"
                request = RequestSpec(request_id=request_id, arrival_ms=0,
                                      prompt_tokens=CONCURRENT_PROMPT,
                                      max_output_tokens=1, session_id=session_id)
                result = await client.complete(request, prompt, cache_salt=cache_salt)
                validate(result, request_id=request_id,
                         prompt_tokens=CONCURRENT_PROMPT, output_tokens=1,
                         cache_salt=cache_salt,
                         artifact=f"gpu_{gpu}_concurrent_prime_{index}.json")
                warm_sessions.append((index, session_id, prompt, cache_salt))

            async def warm_probe(index, session_id, prompt, cache_salt):
                request_id = f"{session_id}-probe"
                request = RequestSpec(request_id=request_id, arrival_ms=0,
                                      prompt_tokens=CONCURRENT_PROMPT,
                                      max_output_tokens=OUTPUT, session_id=session_id)
                result = await client.complete(request, prompt, cache_salt=cache_salt)
                return index, request_id, cache_salt, result

            probes = await asyncio.gather(*(
                warm_probe(index, session_id, prompt, cache_salt)
                for index, session_id, prompt, cache_salt in warm_sessions
            ))
            for index, request_id, cache_salt, result in probes:
                validate(result, request_id=request_id,
                         prompt_tokens=CONCURRENT_PROMPT, output_tokens=OUTPUT,
                         cache_salt=cache_salt,
                         artifact=f"gpu_{gpu}_concurrent_probe_{index}.json")
            if not await client.reset_prefix_cache():
                raise RuntimeError(f"GPU {gpu}: reset after shape prewarm failed")
        finally:
            await client.close()
        return records

    # Preserve other GPUs' diagnostic results before reporting worker failures.
    # The launcher still enforces a bounded prewarm deadline and owns cleanup.
    results = await asyncio.gather(*(worker(gpu) for gpu in gpus), return_exceptions=True)
    errors = {str(gpu): f"{type(value).__name__}: {value}"
              for gpu, value in zip(gpus, results) if isinstance(value, BaseException)}
    if errors:
        write_json(root / "SHAPE_PREWARM_FAILURE.json",
                   {"status": "FAIL", "diagnostic_only": True, "errors": errors})
        raise RuntimeError("shape prewarm failed: " + json.dumps(errors))
    snapshots = {}
    for gpu in gpus:
        data = (root / f"vllm_gpu_{gpu}.log").read_bytes()
        events = tuning_events(data.decode(errors="replace"))
        blocks = observed_o_blocks(events)
        snapshots[str(gpu)] = {"bytes": len(data),
                               "sha256": hashlib.sha256(data).hexdigest(),
                               "observed_o_blocks": sorted(blocks), "events": events}
    expected_per_gpu = len(fixed_schedule()) + 2 * CONCURRENT_WIDTH
    fixed_schedule_completed = all(len(group) == expected_per_gpu for group in results)
    report = {"diagnostic_only": True, "gpu_indices": list(gpus),
               "fixed_prompt_tokens": list(PROMPTS),
               "passes": PASSES, "output_tokens": OUTPUT,
              "concurrent_warm_prompt_tokens": CONCURRENT_PROMPT,
              "concurrent_warm_width": CONCURRENT_WIDTH,
              "cache_observation_policy": CACHE_OBSERVATION_POLICY,
              "missing_cache_observation_allowed_for_prompts": list(PROMPTS),
              "missing_cache_observations": sum(
                  r["cached_prompt_tokens_observed"] is None for group in results for r in group),
              "cache_isolation": "unique per-request salt; null readings remain unknown, not zero",
              "requests": sum(map(len, results)), "logs": snapshots,
              "completed_wall_time_ns": time.time_ns(),
              "checks": {
                  "fixed_schedule_completed": fixed_schedule_completed,
                  # A warm Triton cache legitimately emits no new autotuning
                  # lines.  Keep this as evidence, not an acceptance condition.
                  "all_shape_keys_observed": all(
                      {16, 32, 64}.issubset(set(x["observed_o_blocks"]))
                      for x in snapshots.values()),
              }}
    write_json(root / "SHAPE_PREWARM.json", report)
    if not report["checks"]["fixed_schedule_completed"]:
        raise RuntimeError("fixed shape prewarm schedule incomplete")
    print("FIXED_SHAPE_PREWARM_PASS", flush=True)


def audit(root):
    from carbonaffinity.artifacts import read_rows, write_json

    prior = json.loads((root / "SHAPE_PREWARM.json").read_text())
    rows = read_rows(root / "raw")
    expected = set(itertools.product(GPUS, ("cold", "warm"), (12288,), (3,), range(5)))
    actual = [(r["gpu_index"], r["mode"], r["prompt_tokens"], r["concurrency"], r["repeat"])
              for r in rows]
    after = {}
    for gpu in GPUS:
        data = (root / f"vllm_gpu_{gpu}.log").read_bytes()
        snap = prior["logs"][str(gpu)]
        if hashlib.sha256(data[:snap["bytes"]]).hexdigest() != snap["sha256"]:
            raise RuntimeError("engine log changed or truncated; audit stopped")
        after[str(gpu)] = tuning_events(data[snap["bytes"]:].decode(errors="replace"))
    warm = [r for r in rows if r["mode"] == "warm"]
    spikes = [{"gpu": r["gpu_index"], "repeat": r["repeat"],
               "ttft_ms": r["ttft_p95_ms"], "tpot_ms": r["tpot_p95_ms"]}
              for r in warm if r["ttft_p95_ms"] >= SPIKE_MS]
    checks = {
        "fixed_prewarm_verified": prior["checks"].get(
            "fixed_schedule_completed",
            prior["checks"].get("all_shape_keys_observed", False),
        ),
        "thirty_unique_cases": len(actual) == 30 and set(actual) == expected,
        "requests_succeeded": all(len(r["results"]) == 3 and all(
            x["success"] and x["output_tokens"] == OUTPUT for x in r["results"])
            for r in rows),
        "observed_cache_unchanged": all(r["cached_tokens"] == [11760] * 3 for r in warm),
        "no_new_autotuning_after_prewarm": not any(after.values()),
        "no_diagnostic_ttft_spikes": not spikes,
    }
    report = {"status": "PASS" if all(checks.values()) else "FAIL",
              "diagnostic_only": True, "checks": checks,
              "diagnostic_ttft_spike_threshold_ms": SPIKE_MS,
              "threshold_is_service_slo": False,
              "post_prewarm_tuning_events": after, "spikes": spikes,
              "note": "Three-GPU diagnostic only; no latency model or eight-GPU validation claim."}
    write_json(root / "SHAPE_PREWARM_EFFECT_REPORT.json", report)
    print(json.dumps(report, indent=2), flush=True)
    if report["status"] != "PASS":
        raise RuntimeError("shape prewarm diagnostic failed; all raw records preserved")


def main():
    mode, root = sys.argv[1], Path(sys.argv[2])
    if mode == "prewarm":
        from carbonaffinity.materialize import PromptMaterializer
        from carbonaffinity.region import RegionClient
        asyncio.run(prewarm(root, PromptMaterializer("/root/models/Qwen3.5-27B"), RegionClient))
    elif mode == "audit":
        audit(root)
    else:
        raise ValueError("unknown diagnostic stage")


if __name__ == "__main__":
    main()
