"""Fit/validate a cap784 monotone latency envelope with explicit prewarm.

This reconstructs the method, not the lost coefficients. No slow observations
are deleted; startup requests must be excluded by the measurement protocol.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path

from carbonaffinity.artifacts import finite_nonnegative, quantile, read_rows, sha256, write_json
from carbonaffinity.latency_surface import estimate_latency_surface


def fit(rows):
    prompts = sorted({int(row["prompt_tokens"]) for row in rows})
    loads = sorted({int(row["concurrency"]) for row in rows})
    model = {"schema_version": 3, "runtime_mode": "chunked_prefill_cap_784",
             "interpolation": "monotone_upper_envelope", "candidate_frozen": False,
             "status": "CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION", "prompt_buckets": prompts,
             "concurrency_buckets": loads, "cells": {}, "one_sided_q95_residual_ms": {}}
    for mode in ("cold", "warm"):
        for p, c in itertools.product(prompts, loads):
            group = [row for row in rows if row["mode"] == mode and row["prompt_tokens"] == p and row["concurrency"] == c]
            if not group:
                raise ValueError(f"missing training cell: {mode}|{p}|{c}")
            row_out = {metric: max(finite_nonnegative(row[metric.replace("_ms", "_p95_ms")]) for row in group) for metric in ("ttft_ms", "tpot_ms")}
            for metric in ("ttft_ms", "tpot_ms"):
                # Monotonicity in prompt/concurrency; never infer an upper bound
                # by linearly interpolating down through a scheduling step.
                row_out[metric] = max([row_out[metric]] + [value[metric] for name, value in model["cells"].items()
                    if name.startswith(mode + "|") and int(name.split("|")[1]) <= p and int(name.split("|")[2]) <= c])
            row_out["samples"] = len(group)
            model["cells"][f"{mode}|{p}|{c}"] = row_out
    return model


def fit_loo(rows):
    gpus = sorted({row["gpu_index"] for row in rows})
    if len(gpus) != 8:
        raise ValueError("eight GPU folds required")
    residuals = {(mode, metric): [] for mode in ("cold", "warm") for metric in ("ttft_ms", "tpot_ms")}
    for gpu in gpus:
        model = fit([row for row in rows if row["gpu_index"] != gpu])
        for row in rows:
            if row["gpu_index"] != gpu:
                continue
            estimate = estimate_latency_surface(model, row["prompt_tokens"], row["prompt_tokens"] if row["mode"] == "warm" else 0, row["concurrency"])
            for metric, bound in zip(("ttft_ms", "tpot_ms"), estimate):
                residuals[row["mode"], metric].append(max(0, row[metric.replace("_ms", "_p95_ms")] - bound))
    model = fit(rows)
    model["one_sided_q95_residual_ms"] = {
        mode: {metric: max(residuals[mode, metric]) + (5 if metric == "ttft_ms" else .5)
               for metric in ("ttft_ms", "tpot_ms")} for mode in ("cold", "warm")}
    return model


def validate(model_path, root):
    root = Path(root)
    model = json.loads(Path(model_path).read_text(encoding="utf-8"))
    prereg = json.loads((root / "PREREGISTRATION.json").read_text())
    rows = read_rows(root / "raw")
    identities = [(r["gpu_index"], r["mode"], r["prompt_tokens"], r["concurrency"], r["repeat"]) for r in rows]
    expected = set(itertools.product(prereg["gpu_indices"], ["cold", "warm"], [6144, 12288, 24576], [3, 5, 7], [0]))
    launch = json.loads((root / "LAUNCH.json").read_text())
    checks = {"candidate_hash_unchanged": sha256(model_path) == prereg["candidate_sha256"],
              "exact_cases": set(identities) == expected and len(identities) == len(expected),
              "effective_cap_evidence": launch.get("effective_cap_verified") is True and launch.get("runtime_cap") == 784,
              "registered_rows": prereg["expected_rows"] == len(rows) == 144,
              "requests_success": all(result["success"] for row in rows for result in row["results"]),
              "warm_cache_observed": all(all(value is not None and value >= .9 * row["prompt_tokens"] for value in row["cached_tokens"]) for row in rows if row["mode"] == "warm"),
              "no_training_anchor_overlap": all(r["prompt_tokens"] not in model["prompt_buckets"] for r in rows),
              "code_unchanged": all(Path(p).is_file() and sha256(p) == h for p, h in prereg["code_sha256"].items())}
    groups = {}
    for row in rows:
        bound = estimate_latency_surface(model, row["prompt_tokens"], row["prompt_tokens"] if row["mode"] == "warm" else 0, row["concurrency"])
        if bound is None or any(not math.isfinite(v) or v <= 0 for v in bound):
            raise ValueError("invalid or out-of-domain validation prediction")
        for metric, value in zip(("ttft_ms", "tpot_ms"), bound):
            actual = finite_nonnegative(row[metric.replace("_ms", "_p95_ms")])
            groups.setdefault(row["mode"] + "_" + metric, []).append(actual / value)
    summary = {name: {"samples": len(values), "coverage": sum(v <= 1 for v in values) / len(values),
                      "q95_ratio": quantile(values, .95), "max_ratio": max(values)} for name, values in groups.items()}
    checks["four_metric_groups"] = len(summary) == 4
    checks["all_mode_metric_coverage"] = bool(summary) and all(v["coverage"] >= .95 for v in summary.values())
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "groups": summary,
            "candidate_sha256": sha256(model_path), "rows": len(rows), "candidate_frozen": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = read_rows(args.input_root)
    if any(not result["success"] for row in rows for result in row["results"]):
        raise ValueError("development has request failures")
    ids = [(r["gpu_index"], r["mode"], r["prompt_tokens"], r["concurrency"], r["repeat"]) for r in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate development rows")
    model = fit_loo(rows)
    model["training_sources"] = [{"path": str(p.resolve()), "sha256": sha256(p)} for p in args.input_root.rglob("measurements.jsonl")]
    write_json(args.output, model)
    print(f"LATENCY_CANDIDATE_READY rows={len(rows)} cells={len(model['cells'])} frozen=False")


if __name__ == "__main__":
    main()
