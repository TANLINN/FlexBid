from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
START = datetime(2026, 1, 1, tzinfo=timezone.utc)


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")


def high_reuse() -> list[dict]:
    rows = []
    lengths = [2048, 4096, 6144, 8192]
    for session in range(12):
        base = session * 700
        previous = None
        for turn, length in enumerate(lengths):
            request_id = f"agent-{session:02d}-t{turn}"
            row = {
                "request_id": request_id, "session_id": f"agent-{session:02d}",
                "turn_id": turn, "arrival_ms": base + turn * 2600,
                "prompt_tokens": length, "max_output_tokens": 32,
                "shared_prefix_tokens": 0 if turn == 0 else lengths[turn - 1],
                "tool_delay_ms": 900 if turn else 0,
                "ttft_slo_ms": 10000, "tpot_slo_ms": 250, "workload": "agentic",
            }
            if previous is not None:
                row["parent_request_id"] = previous
            rows.append(row)
            previous = request_id
    return rows


def low_reuse() -> list[dict]:
    lengths = [2048, 4096, 8192]
    return [{
        "request_id": f"rag-{index:03d}", "session_id": f"rag-{index:03d}",
        "turn_id": 0, "arrival_ms": index * 1000,
        "prompt_tokens": lengths[index % len(lengths)], "max_output_tokens": 32,
        "shared_prefix_tokens": 0, "ttft_slo_ms": 10000,
        "tpot_slo_ms": 250, "workload": "rag",
    } for index in range(48)]


def burst() -> list[dict]:
    rows = []
    for session in range(16):
        burst_id = session // 4
        base = burst_id * 3500 + (session % 4) * 30
        previous = None
        for turn, length in enumerate((2048, 5120, 8192)):
            request_id = f"burst-{session:02d}-t{turn}"
            row = {
                "request_id": request_id, "session_id": f"burst-{session:02d}",
                "turn_id": turn, "arrival_ms": base + turn * 1500,
                "prompt_tokens": length, "max_output_tokens": 32,
                "shared_prefix_tokens": 0 if turn == 0 else (2048 if turn == 1 else 5120),
                "tool_delay_ms": 300 if turn else 0,
                "ttft_slo_ms": 12000, "tpot_slo_ms": 300, "workload": "agentic",
            }
            if previous is not None:
                row["parent_request_id"] = previous
            rows.append(row)
            previous = request_id
    return rows


def write_carbon(
    path: Path, region_a: str, region_b: str, noisy: bool, phase_seconds: int
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["timestamp,region_id,forecast_lbs_per_mwh,historical_lbs_per_mwh"]
    for second in range(0, 121):
        phase = (second // phase_seconds) % 2
        forecast_a, forecast_b = ((620, 160) if phase == 0 else (180, 600))
        if noisy:
            # Forecast occasionally points to the wrong winner; historical MOER
            # is used only for settlement and the oracle baseline.
            historical_a, historical_b = (
                (220, 560) if second % 12 < 5 else (580, 200)
            )
        else:
            historical_a, historical_b = forecast_a + 10, forecast_b - 5
        timestamp = (START + timedelta(seconds=second)).isoformat().replace("+00:00", "Z")
        lines.append(f"{timestamp},{region_a},{forecast_a},{historical_a}")
        lines.append(f"{timestamp},{region_b},{forecast_b},{historical_b}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def config(name: str, a: str, b: str, port_a: int, port_b: int, trace: Path, carbon: Path) -> dict:
    return {
        "experiment": {
            "name": f"local_expansion_{name}_NOT_FOR_GEO_CLAIMS",
            "mode": "same_host_physical_gpu_expansion",
            "model": "Qwen3.5-27B", "tokenizer": "/root/models/Qwen3.5-27B",
            "trace": str(trace.relative_to(ROOT)).replace("\\", "/"),
        },
        "regions": [
            {"id": a, "api_base": f"http://127.0.0.1:{port_a}/v1", "control_base": "http://127.0.0.1:1", "api_key": "EMPTY", "model": "Qwen3.5-27B", "profile": f"profiles/{a}.json", "site_manifest": f"manifests/{a}.json", "gpu_count": 1, "tensor_parallel_size": 1, "admission_concurrency": 8, "rtt_ms": 0},
            {"id": b, "api_base": f"http://127.0.0.1:{port_b}/v1", "control_base": "http://127.0.0.1:1", "api_key": "EMPTY", "model": "Qwen3.5-27B", "profile": f"profiles/{b}.json", "site_manifest": f"manifests/{b}.json", "gpu_count": 1, "tensor_parallel_size": 1, "admission_concurrency": 8, "rtt_ms": 20},
        ],
        "carbon": {"trace": str(carbon.relative_to(ROOT)).replace("\\", "/"), "clock_mode": "trace_relative", "trace_start_timestamp": "2026-01-01T00:00:00Z", "max_age_s": 1800},
        "routing": {"policy": "carbon_affinity", "lease_ttl_s": 900, "carbon_weight": 1.0, "slo_violation_penalty": 1000.0, "queue_penalty": 0.02, "migration_hysteresis_g": 0.002, "uncertainty_penalty_g": 0.001 if name == "burst" else 0.0},
        "lease": {"calibrated": False, "adaptive": False, "ttl_candidates_s": [900], "kv_bytes_per_token": 327680, "memory_shadow_g_per_gib_s": 0, "latency_value_g_per_ms": 0},
        "runtime": {"arrival_scale": 1.0, "duration_limit_s": None, "max_in_flight": 128, "request_timeout_s": 900},
    }


def main() -> None:
    specifications = [
        ("high_reuse", "high_reuse_a", "high_reuse_b", 18002, 18003, high_reuse(), False, 20),
        ("low_reuse", "low_reuse_a", "low_reuse_b", 18004, 18005, low_reuse(), False, 20),
        ("burst", "burst_a", "burst_b", 18006, 18007, burst(), True, 5),
    ]
    for name, a, b, port_a, port_b, rows, noisy, phase_seconds in specifications:
        trace = ROOT / "data" / "normalized" / f"local_{name}.jsonl"
        carbon = ROOT / "data" / "carbon" / f"moer.local_{name}.csv"
        output = ROOT / "configs" / f"local_{name}.generated.yaml"
        write_jsonl(trace, rows)
        write_carbon(carbon, a, b, noisy, phase_seconds)
        output.write_text(yaml.safe_dump(
            config(name, a, b, port_a, port_b, trace, carbon), sort_keys=False
        ), encoding="utf-8")
        print(f"prepared {name}: requests={len(rows)} config={output}")


if __name__ == "__main__":
    main()
