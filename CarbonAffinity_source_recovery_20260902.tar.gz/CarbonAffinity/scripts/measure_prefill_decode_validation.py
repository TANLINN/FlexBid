from __future__ import annotations

import argparse
import asyncio
import json
import random
from pathlib import Path

import httpx

from carbonaffinity.materialize import PromptMaterializer
from measure_prefill_decode_interference import (
    prompt,
    reset_cache,
    stream_request,
)


SHAPES = (
    (7168, 7168, 7168, 7168),
    (4096, 8192, 16384),
    (8192, 8192, 8192, 8192),
    (8192, 10240, 14336),
    (12288, 12288, 12288),
    (8192, 12288, 16384),
    (10240, 10240, 10240, 10240),
    (8192, 14336, 18432),
)

VICTIMS = (
    (8192, 64),
    (2048, 256),
)


async def run_case(
    args: argparse.Namespace,
    client: httpx.AsyncClient,
    materializer: PromptMaterializer,
    shape_index: int,
    victim_index: int,
    repeat: int,
) -> dict:
    shape = SHAPES[shape_index]
    victim_prompt_tokens, victim_output_tokens = VICTIMS[victim_index]
    case_id = (
        f"validation-g{args.gpu_index}-s{shape_index}-"
        f"v{victim_index}-r{repeat}"
    )
    await reset_cache(client, args.api_base.removesuffix("/v1"))
    first_token = asyncio.Event()
    victim_task = asyncio.create_task(stream_request(
        client,
        args.api_base,
        args.model,
        prompt(
            materializer,
            case_id + "-victim",
            victim_prompt_tokens,
        ),
        case_id + "-victim",
        victim_output_tokens,
        first_token,
    ))
    try:
        await asyncio.wait_for(
            first_token.wait(),
            timeout=args.timeout_s,
        )
    except BaseException:
        victim_task.cancel()
        raise
    await asyncio.sleep(args.interference_delay_ms / 1000.0)
    interferer_tasks = []
    for index, prompt_tokens in enumerate(shape):
        request_id = case_id + f"-interferer-{index}"
        interferer_tasks.append(asyncio.create_task(stream_request(
            client,
            args.api_base,
            args.model,
            prompt(materializer, request_id, prompt_tokens),
            request_id,
            args.interferer_output_tokens,
        )))
    victim = await victim_task
    interferers = await asyncio.gather(*interferer_tasks)
    failures = [
        item for item in [victim, *interferers]
        if not item.success
    ]
    return {
        "case_id": case_id,
        "region_id": args.region_id,
        "gpu_index": args.gpu_index,
        "shape_index": shape_index,
        "prefill_shape": list(shape),
        "prefill_count": len(shape),
        "total_interfering_prefill_tokens": sum(shape),
        "victim_index": victim_index,
        "victim_prompt_tokens": victim_prompt_tokens,
        "victim_output_tokens": victim_output_tokens,
        "repeat": repeat,
        "interference_delay_ms": args.interference_delay_ms,
        "victim": victim.to_dict(),
        "interferers": [item.to_dict() for item in interferers],
        "failures": len(failures),
    }


async def measure(args: argparse.Namespace) -> None:
    args.output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    if args.resume and args.output.is_file():
        rows = [
            json.loads(line)
            for line in args.output.read_text().splitlines()
            if line.strip()
        ]
    completed = {row["case_id"] for row in rows}
    cases = [
        (shape_index, victim_index, repeat)
        for shape_index in range(len(SHAPES))
        for victim_index in range(len(VICTIMS))
        for repeat in range(args.repeats)
    ]
    random.Random(args.seed + args.gpu_index).shuffle(cases)
    materializer = PromptMaterializer(args.tokenizer)
    client = httpx.AsyncClient(
        timeout=httpx.Timeout(args.timeout_s),
        headers={"Authorization": f"Bearer {args.api_key}"},
        limits=httpx.Limits(
            max_connections=16,
            max_keepalive_connections=12,
        ),
    )
    try:
        for ordinal, (shape_index, victim_index, repeat) in enumerate(
            cases, 1
        ):
            case_id = (
                f"validation-g{args.gpu_index}-s{shape_index}-"
                f"v{victim_index}-r{repeat}"
            )
            if case_id in completed:
                continue
            row = await run_case(
                args,
                client,
                materializer,
                shape_index,
                victim_index,
                repeat,
            )
            rows.append(row)
            args.output.write_text(
                "".join(json.dumps(item) + "\n" for item in rows),
                encoding="utf-8",
            )
            print(
                f"CASE {ordinal}/{len(cases)} {case_id} "
                f"total={row['total_interfering_prefill_tokens']} "
                f"p95_itl={row['victim']['p95_itl_ms']} "
                f"failures={row['failures']}",
                flush=True,
            )
            await asyncio.sleep(args.settle_s)
    finally:
        await client.aclose()
    print(
        f"PREFILL_VALIDATION_GPU_COMPLETE={args.gpu_index} "
        f"rows={len(rows)}",
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--gpu-index", type=int, required=True)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--interferer-output-tokens", type=int, default=8)
    parser.add_argument("--interference-delay-ms", type=float, default=25.0)
    parser.add_argument("--settle-s", type=float, default=0.5)
    parser.add_argument("--timeout-s", type=float, default=900.0)
    parser.add_argument("--seed", type=int, default=2026082801)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    asyncio.run(measure(parser.parse_args()))


if __name__ == "__main__":
    main()
