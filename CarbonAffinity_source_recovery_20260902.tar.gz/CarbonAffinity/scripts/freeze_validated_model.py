"""Copy candidate bytes only after independent validation; metadata stays external."""
from __future__ import annotations

import argparse
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from carbonaffinity.artifacts import sha256, write_json


def freeze(candidate, report_path, destination):
    candidate, report_path, destination = map(Path, (candidate, report_path, destination))
    report = json.loads(report_path.read_text(encoding="utf-8"))
    digest = sha256(candidate)
    if report.get("status") != "PASS" or report.get("candidate_sha256") != digest:
        raise ValueError("validation PASS and matching candidate SHA256 required")
    if not report.get("checks") or not all(value is True for value in report["checks"].values()):
        raise ValueError("not every validation check passed")
    if destination.exists() or destination.with_suffix(".freeze.json").exists():
        raise FileExistsError("existing frozen model preserved")
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(candidate, destination)
    if sha256(destination) != digest:
        raise RuntimeError("copy hash mismatch")
    record = {"status": "FROZEN", "model_sha256": digest, "model": str(destination.resolve()),
              "validation_report": str(report_path.resolve()), "validation_sha256": sha256(report_path),
              "frozen_utc": datetime.now(timezone.utc).isoformat(), "refit_on_validation": False}
    write_json(destination.with_suffix(".freeze.json"), record)
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(freeze(args.candidate, args.report, args.output), indent=2))


if __name__ == "__main__":
    main()
