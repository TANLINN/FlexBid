from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from carbonaffinity.artifacts import quantile, read_rows, sha256, write_json


def fit_affine(x, y):
    matrix = np.column_stack([np.ones(len(x)), x])
    if len(x) < 3 or np.linalg.matrix_rank(matrix) != 2:
        raise ValueError("token lengths must vary to identify intercept and slope")
    beta = np.linalg.lstsq(matrix, y, rcond=None)[0]
    # Two-variable nonnegative least squares: compare interior and boundaries.
    candidates = [np.maximum(beta, 0), np.array([np.mean(y), 0]),
                  np.array([0, max(0, np.dot(x, y) / np.dot(x, x))])]
    return min(candidates, key=lambda b: np.sum((matrix @ b - y) ** 2)).tolist()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--requests", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = read_rows(args.requests)
    if any(not row["completion"]["success"] for row in rows):
        raise ValueError("failed request rows present")
    request = fit_affine(np.array([row["prompt_tokens"] for row in rows]), np.array([row["completion"]["network_request_bytes"] for row in rows]))
    response = fit_affine(np.array([row["completion"]["output_tokens"] for row in rows]), np.array([row["completion"]["network_response_bytes"] for row in rows]))
    if min(sum(row["completion"][key] for row in rows) for key in ("network_request_bytes", "network_response_bytes")) <= 0:
        raise ValueError("request bytes not observed (network disabled?)")
    result = {"status": "DEVELOPMENT_CANDIDATE", "source_sha256": sha256(args.requests), "samples": len(rows),
              "network_config": {"request_base_bytes": request[0], "prompt_bytes_per_token": request[1],
                "response_base_bytes": response[0], "output_bytes_per_token": response[1],
                "first_response_bytes": quantile([row["completion"]["network_first_response_bytes"] for row in rows], .95)},
              "semantics": "application JSON/SSE bytes, not Ethernet/IP/TLS wire bytes; independent window validation required"}
    write_json(args.output, result)
    print("NETWORK_BYTE_CANDIDATE_WRITTEN (not validated)")


if __name__ == "__main__":
    main()
