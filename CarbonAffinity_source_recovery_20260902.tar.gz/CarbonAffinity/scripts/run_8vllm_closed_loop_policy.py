from __future__ import annotations

import argparse
import asyncio
import json
import os
import signal
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path

from carbonaffinity.audit import audit_results
from carbonaffinity.baseline_closed_loop import (
    BASELINE_POLICIES,
    BaselineClosedLoopPlanner,
)
from carbonaffinity.carbon import CarbonTrace
from carbonaffinity.closed_loop import (
    AsyncClosedLoopCoordinator,
    ClosedLoopPlanner,
)
from carbonaffinity.config import load_config, resolve_path
from carbonaffinity.offline_oracle import OracleProblem
from carbonaffinity.online_planner import OnlinePlannerSettings
from carbonaffinity.region import RegionClient
from carbonaffinity.replay import run_replay
from carbonaffinity.artifacts import sha256, write_json
from carbonaffinity.observable_corun import load_corun_model


def carbon_start(config: dict) -> float:
    value = config["carbon"]["trace_start_timestamp"]
    if isinstance(value, (int, float)):
        return float(value)
    return datetime.fromisoformat(
        str(value).replace("Z", "+00:00")
    ).timestamp()


def crop_trace(source: Path, destination: Path, limit: int) -> list[dict]:
    rows = [
        json.loads(line)
        for line in source.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    rows.sort(
        key=lambda row: (
            float(row["arrival_ms"]),
            str(row["request_id"]),
        )
    )
    rows = rows[:limit]
    destination.write_text(
        "".join(
            json.dumps(row, ensure_ascii=False) + "\n"
            for row in rows
        ),
        encoding="utf-8",
    )
    return rows


async def stop_samplers(samplers: list[subprocess.Popen]) -> None:
    for sampler in samplers:
        if sampler.poll() is None:
            sampler.send_signal(signal.SIGINT)
    for sampler in samplers:
        try:
            sampler.wait(timeout=15)
        except subprocess.TimeoutExpired:
            sampler.terminate()
            sampler.wait(timeout=5)


async def check_and_reset(regions: list[dict], tokenizer: str | None = None) -> None:
    clients = {
        region["id"]: RegionClient(region, 60.0)
        for region in regions
    }
    try:
        health = await asyncio.gather(*(
            client.healthy() for client in clients.values()
        ))
        if not all(health):
            raise RuntimeError(
                "unhealthy vLLM regions: "
                + repr([
                    region_id
                    for region_id, ok in zip(clients, health)
                    if not ok
                ])
            )
        if tokenizer is not None:
            from carbonaffinity.materialize import PromptMaterializer
            from carbonaffinity.models import RequestSpec
            materializer = PromptMaterializer(tokenizer)
            async def prewarm(region_id, client):
                raw = {"request_id": "prewarm-" + region_id, "session_id": "prewarm-" + region_id,
                       "prompt_tokens": 2048, "shared_prefix_tokens": 0}
                request = RequestSpec(raw["request_id"], 0, 2048, 64, raw["session_id"])
                for _ in range(2):
                    result = await client.complete(request, materializer.tokens(raw))
                    if not result.success:
                        raise RuntimeError("policy prewarm failed: " + region_id)
            await asyncio.gather(*(prewarm(key, client) for key, client in clients.items()))
        reset = await asyncio.gather(*(
            client.reset_prefix_cache()
            for client in clients.values()
        ))
        if not all(reset):
            raise RuntimeError("prefix-cache reset failed")
    finally:
        await asyncio.gather(*(
            client.close() for client in clients.values()
        ))


async def main_async(args: argparse.Namespace) -> None:
    project_root = Path(__file__).resolve().parents[1]
    config = load_config(args.config)
    regions = list(config["regions"])
    if len(regions) != 8 or len(args.gpu_indices) != 8:
        raise ValueError(
            "closed-loop vLLM run requires eight regions and GPUs"
        )

    if len(set(args.gpu_indices)) != 8:
        raise ValueError("GPU mapping must contain eight distinct indices")
    args.output_root.mkdir(parents=True, exist_ok=False)
    corun_model = None
    if args.corun_model:
        if not args.corun_freeze_record:
            raise ValueError("co-run deployment requires a freeze record")
        freeze = json.loads(args.corun_freeze_record.read_text())
        report_path = Path(freeze["validation_report"])
        if (freeze.get("status") != "FROZEN" or freeze.get("model_sha256") != sha256(args.corun_model)
                or not report_path.is_file() or sha256(report_path) != freeze["validation_sha256"]):
            raise ValueError("co-run freeze/model/validation hashes do not agree")
        corun_model = load_corun_model(args.corun_model)
    trace_source = resolve_path(
        config, config["experiment"]["trace"]
    )
    trace_path = args.output_root / "pilot_trace.jsonl"
    rows = crop_trace(trace_source, trace_path, args.max_requests)
    raw_problem = args.output_root / "problem.raw.json"
    learned_problem = args.output_root / "problem.learned.json"

    commands = [
        [
            sys.executable,
            "scripts/build_offline_oracle_problem.py",
            "--config", str(args.config),
            "--output", str(raw_problem),
            "--max-requests", str(args.max_requests),
            "--epoch-ms", str(args.epoch_ms),
            "--region-limit", "8",
        ],
        [
            sys.executable,
            "scripts/annotate_learned_future_work.py",
            "--input", str(raw_problem),
            "--model", str(args.future_work_model),
            "--output", str(learned_problem),
        ],
    ]
    for command in commands:
        subprocess.run(
            command,
            cwd=project_root,
            env={
                **os.environ,
                "PYTHONPATH": str(project_root),
            },
            check=True,
        )

    template = OracleProblem.from_json(learned_problem)
    if args.scheduler == "joint_planner":
        planner = ClosedLoopPlanner(
            template,
            OnlinePlannerSettings(
                horizon_epochs=0,
                max_price_iterations=args.max_price_iterations,
                time_budget_ms=args.time_budget_ms,
                continuation_mode="learned_future",
            ),
            corun_model=corun_model,
        )
    else:
        planner = BaselineClosedLoopPlanner(
            template,
            args.scheduler,
            corun_model=corun_model,
        )
    coordinator = AsyncClosedLoopCoordinator(
        planner,
        control_interval_ms=args.control_interval_ms,
    )
    write_json(args.output_root / "RUN_INPUTS.json", {
        "config_sha256": sha256(args.config), "future_model_sha256": sha256(args.future_work_model),
        "corun_model_sha256": None if corun_model is None else corun_model.model_sha256,
        "runtime_code_sha256": {str(path.relative_to(project_root)): sha256(path)
                                for path in sorted((project_root / "carbonaffinity").glob("*.py"))},
    })

    await check_and_reset(regions, config["experiment"].get("tokenizer"))
    telemetry: dict[str, Path] = {}
    samplers: list[subprocess.Popen] = []
    try:
        for region, gpu in zip(regions, args.gpu_indices):
            path = args.output_root / f"{region['id']}_gpu.csv"
            telemetry[region["id"]] = path
            samplers.append(subprocess.Popen([
                sys.executable,
                "-m", "carbonaffinity.telemetry",
                "--output", str(path),
                "--gpu-index", str(gpu),
                "--region-id", str(region["id"]),
                "--interval-ms", "100",
            ], cwd=project_root))
        await asyncio.sleep(2)
        await run_replay(
            config,
            trace_path,
            args.output_root / "requests.jsonl",
            assignment_provider=coordinator,
        )
        await asyncio.sleep(2)
    finally:
        await stop_samplers(samplers)

    carbon = CarbonTrace.from_csv(
        resolve_path(config, config["carbon"]["trace"]),
        float(config["carbon"].get("max_age_s", 1800)),
    )
    report = audit_results(
        args.output_root / "requests.jsonl",
        telemetry,
        carbon,
        carbon_start(config),
    )
    (args.output_root / "audit.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    if not report["passed"] or report["requests"] != len(rows):
        raise RuntimeError(
            f"closed-loop vLLM audit failed: {report}"
        )

    plans = coordinator.plans
    records = [
        json.loads(line)
        for line in (
            args.output_root / "requests.jsonl"
        ).read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    route_counts = Counter(
        row["decision"]["selected_region"] for row in records
    )
    marker = {
        "status": "COMPLETE",
        "mode": "atomic_closed_loop",
        "scheduler": args.scheduler,
        "regions": 8,
        "requests": len(rows),
        "control_interval_ms": args.control_interval_ms,
        "planner_batches": len(plans),
        "routes": dict(route_counts),
        "planner_max_ms": max(
            (plan.planner_time_ms for plan in plans),
            default=0.0,
        ),
        "planner_budget_exhausted_batches": sum(
            plan.budget_exhausted for plan in plans
        ),
        "maximum_projected_region_load": max(
            (
                assignment.projected_total_load
                for plan in plans
                for assignment in plan.assignments
            ),
            default=0,
        ),
        "ttft_violation_rate": report["ttft_violation_rate"],
        "tpot_violation_rate": report["tpot_violation_rate"],
        "measured_gpu_energy_j": report["measured_gpu_energy_j"],
        "measured_operational_carbon_g": report[
            "measured_operational_carbon_g"
        ],
        "completed_s": time.time(),
        "integrity_pass": bool(report["passed"]),
        "slo_pass": report["ttft_violation_rate"] == 0 and report["tpot_violation_rate"] == 0,
        "corun_guard": dict(planner.guard_audit),
    }
    (args.output_root / "CLOSED_LOOP_COMPLETE.json").write_text(
        json.dumps(marker, indent=2), encoding="utf-8"
    )
    print(json.dumps(marker, indent=2))
    print("8VLLM_CLOSED_LOOP_COLLECTION_COMPLETE")
    print("SLO_PASS=" + str(marker["slo_pass"]))
    if args.require_zero_slo_violations and not marker["slo_pass"]:
        raise RuntimeError("integrity passed but SLO gate failed")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument(
        "--future-work-model", type=Path, required=True
    )
    parser.add_argument(
        "--gpu-indices", type=int, nargs=8, required=True
    )
    parser.add_argument(
        "--scheduler",
        choices=("joint_planner",) + BASELINE_POLICIES,
        required=True,
    )
    parser.add_argument("--max-requests", type=int, default=64)
    parser.add_argument("--epoch-ms", type=float, default=1000.0)
    parser.add_argument("--corun-model", type=Path)
    parser.add_argument("--corun-freeze-record", type=Path)
    parser.add_argument("--require-zero-slo-violations", action="store_true")
    parser.add_argument(
        "--control-interval-ms", type=float, default=100.0
    )
    parser.add_argument(
        "--max-price-iterations", type=int, default=32
    )
    parser.add_argument(
        "--time-budget-ms", type=float, default=100.0
    )
    asyncio.run(main_async(parser.parse_args()))


if __name__ == "__main__":
    main()
