"""One plaintext paste for immutable validation code; model stays unchanged."""
import argparse
import hashlib
import shlex
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
NAMES = ("scripts/validate_observable_corun_candidate.py", "tests/test_observable_corun_validation.py")
SEPARATOR = "\n# === OBSERVABLE_CORUN_VALIDATION_NEXT_SOURCE ===\n"
INSTALLER = '''import hashlib,json,sys
from pathlib import Path
project=Path('/root/CarbonAffinity')
raw=sys.stdin.buffer.read()
digest=hashlib.sha256(raw).hexdigest()
if digest!=sys.argv[1]:
    raise SystemExit('SOURCE_CHECKSUM_FAILED_NOT_INSTALLED')
base=project/'results/observable_corun_fit_transfer_90207d3fe0c9f468'
manifest=json.loads((base/'CORUN_FIT_TRANSFER_MANIFEST.json').read_text())
if manifest['source_payload_sha256']!='90207d3fe0c9f468e1d5fdccfe103d969a90d3d6ca0de2d6535c250e28cdae7a':
    raise SystemExit('FIT_BASE_BUNDLE_MISMATCH')
def safe(name,folders=('scripts','tests')):
    p=Path(name)
    if p.is_absolute() or '..' in p.parts or not p.parts or p.parts[0] not in folders:
        raise SystemExit('UNSAFE_SOURCE_PATH')
    return p
files={}
for name,expected in manifest['files_sha256'].items():
    data=(base/safe(name)).read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected:
        raise SystemExit('BASE_SOURCE_CHANGED: '+name)
    files[name]=data
for name,expected in manifest['required_core_lf_sha256'].items():
    if hashlib.sha256((project/safe(name,('carbonaffinity',))).read_text(encoding='utf-8').encode()).hexdigest()!=expected:
        raise SystemExit('CORE_SOURCE_CHANGED: '+name)
names=('scripts/validate_observable_corun_candidate.py','tests/test_observable_corun_validation.py')
parts=raw.decode('utf-8').split('\\n# === OBSERVABLE_CORUN_VALIDATION_NEXT_SOURCE ===\\n')
if len(parts)!=len(names):
    raise SystemExit('SOURCE_BOUNDARY_INVALID')
for name,source in zip(names,parts):
    if name in files:
        raise SystemExit('UNEXPECTED_SOURCE_COLLISION')
    files[name]=source.encode()
destination=project/'results'/('observable_corun_validation_transfer_'+digest[:16])
if destination.is_symlink():
    raise SystemExit('SYMLINK_DESTINATION_REJECTED')
for name,data in files.items():
    relative=safe(name)
    compile(data,name,'exec')
    target=destination/relative
    if target.is_symlink() or target.parent.is_symlink():
        raise SystemExit('SYMLINK_SOURCE_REJECTED')
    if target.exists() and target.read_bytes()!=data:
        raise SystemExit('EXISTING_SOURCE_DIFFERS: '+name)
record=dict(source_payload_sha256=digest,base_payload_sha256=manifest['source_payload_sha256'],
    files_sha256={n:hashlib.sha256(d).hexdigest() for n,d in files.items()},
    required_core_lf_sha256=manifest['required_core_lf_sha256'],
    scope='768-row independent workload validation; no refit, freeze or runtime installation')
record_bytes=(json.dumps(record,sort_keys=True,indent=2)+'\\n').encode()
record_path=destination/'CORUN_VALIDATION_TRANSFER_MANIFEST.json'
if record_path.is_symlink() or (record_path.exists() and record_path.read_bytes()!=record_bytes):
    raise SystemExit('EXISTING_MANIFEST_DIFFERS')
for name,data in files.items():
    target=destination/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        with target.open('xb') as handle:
            handle.write(data)
    if target.read_bytes()!=data:
        raise SystemExit('INSTALLED_HASH_MISMATCH')
if not record_path.exists():
    with record_path.open('xb') as handle:
        handle.write(record_bytes)
print(destination)
'''

SUMMARY = '''cd /root/CarbonAffinity
.venv/bin/python - "${VAL:-}" <<'CORUN_VALIDATION_SUMMARY_EOF'
import json,sys
from pathlib import Path
if not sys.argv[1]:
    raise SystemExit("VAL is empty: set VAL to the printed validation output root first")
root=Path(sys.argv[1])
path=root/'OBSERVABLE_CORUN_INDEPENDENT_VALIDATION_REPORT.json'
print('ROOT =',root)
for name in ('EXPERIMENT_COMPLETE.json','FATAL.json'):
    p=root/name
    print(name,json.loads(p.read_text()) if p.exists() else 'ABSENT')
if not path.exists():
    raise SystemExit('REPORT_MISSING: inspect launcher/worker logs; not a validation pass')
r=json.loads(path.read_text())
print('STATUS =',r.get('status','MISSING'),'rows =',r.get('rows'))
print('failed_checks =',[k for k,v in r.get('checks',{}).items() if v is not True])
print('candidate_sha256 =',r.get('candidate_sha256'))
print('primary_rows =',r.get('primary_rows'),'future_controls =',r.get('future_control_rows'))
print('PRIMARY COVERAGE (new heldout data)')
for name,g in r.get('primary_overall',{}).items():
    print(name,'n=',g['samples'],'coverage=',round(g['coverage'],4),
          'pred/actual_median=',round(g['prediction_over_actual_median'],3),
          'FN=',g.get('false_negatives','-'),'FP=',g.get('false_positives','-'))
print('failed_gpu_groups =',r.get('failed_gpu_groups','NOT_EVALUATED'))
print('failed_stratum_groups =',r.get('failed_stratum_groups','NOT_EVALUATED'))
print('FUTURE CONTROLS (diagnostic, excluded from primary coverage)')
for name,g in r.get('future_controls_diagnostic_only',{}).items():
    print(name,'n=',g['samples'],'coverage=',round(g['coverage'],4),
          'max_positive_residual_ms=',round(g['positive_residual_max_ms'],3))
print('bounded_primary_validation_passed =',r.get('bounded_primary_validation_passed'))
print('continuous_arrival_tpot_validated =',r.get('continuous_arrival_tpot_validated'))
print('candidate_frozen =',r.get('candidate_frozen'))
print('OBSERVABLE_CORUN_VALIDATION_RESULT_CAPTURE_COMPLETE')
CORUN_VALIDATION_SUMMARY_EOF
'''


def payload():
    parts = [PROJECT.joinpath(n).read_text(encoding="utf-8") for n in NAMES]
    for name, source in zip(NAMES, parts):
        if SEPARATOR in source or "\nOBSERVABLE_CORUN_VALIDATION_SOURCE_EOF\n" in source:
            raise ValueError("delimiter collision")
        compile(source, name, "exec")
    return SEPARATOR.join(parts).encode()


def command():
    raw = payload()
    digest = hashlib.sha256(raw).hexdigest()
    return f'''cd /root/CarbonAffinity
if VAL_BUNDLE="$(/root/CarbonAffinity/.venv/bin/python -c {shlex.quote(INSTALLER)} {digest} <<'OBSERVABLE_CORUN_VALIDATION_SOURCE_EOF'
{raw.decode()}OBSERVABLE_CORUN_VALIDATION_SOURCE_EOF
)"; then
    if (cd "$VAL_BUNDLE" && PYTHONPATH="$VAL_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -m unittest tests.test_latency_residual tests.test_corun_observable_pilot tests.test_corun_observable_development tests.test_observable_corun_candidate tests.test_observable_corun_validation -q); then
        VAL="/root/CarbonAffinity/results/observable_corun_independent_validation_v1_$(date -u +%Y%m%dT%H%M%S%NZ)"
        nohup env PYTHONPATH="$VAL_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -u "$VAL_BUNDLE/scripts/validate_observable_corun_candidate.py" --project-root /root/CarbonAffinity --model-dir /root/models/Qwen3.5-27B --output-root "$VAL" > "${{VAL}}.launcher.log" 2>&1 < /dev/null &
        echo "PID=$! VAL=$VAL"
        echo "OBSERVABLE_CORUN_VALIDATION_SUBMITTED_EXPECTED_ROWS=768"
        echo "Candidate locked before server startup; no refit. Check logs/report, not a pass yet."
    else
        echo "CORUN_VALIDATION_SELF_TEST_FAILED_NOT_STARTED"
    fi
else
    echo "CORUN_VALIDATION_INSTALL_FAILED_NOT_STARTED"
fi
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--summary-output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists() or args.summary_output.exists():
        raise FileExistsError("preserve existing delivery artifacts")
    for path, content in ((args.output, command()), (args.summary_output, SUMMARY)):
        data = content.encode()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('xb') as f:
            f.write(data)
        print(f"OUTPUT={path.resolve()} LINES={len(data.splitlines())} SHA256={hashlib.sha256(data).hexdigest()}")


if __name__ == "__main__":
    main()
