"""Single-GPU frontier diagnosis for concurrent long-prefix residency."""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import os
import signal
import socket
import subprocess
import time
from dataclasses import asdict
from pathlib import Path

GPU = 3
PORT = 18003
PROMPT_TOKENS = 31_744
EXPECTED_CACHED_TOKENS = 31_360
PROBE_OUTPUT_TOKENS = 64
SESSIONS = tuple(range(3))
MODEL_NAME = "Qwen3.5-27B"


class TerminationRequested(RuntimeError):
    pass


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)


def branch_specs() -> tuple[dict[str, object], ...]:
    return (
        {
            "branch_id": "concurrent_n2",
            "prime_indices": (0, 1),
        },
        {
            "branch_id": "concurrent_n3",
            "prime_indices": SESSIONS,
        },
    )


def request_errors(record: dict[str, object], output_tokens: int) -> list[str]:
    checks = {
        "success": record.get("success") is True and record.get("status_code") == 200,
        "error": record.get("error") is None,
        "prompt_tokens": record.get("prompt_tokens_reported") == PROMPT_TOKENS,
        "output_tokens": record.get("output_tokens") == output_tokens,
    }
    return [name for name, valid in checks.items() if not valid]


def exact_hit(record: dict[str, object]) -> bool:
    value = record.get("cached_prompt_tokens_observed")
    return type(value) is int and value == EXPECTED_CACHED_TOKENS


def classify(branches: list[dict[str, object]]) -> str:
    by_id = {str(branch["branch_id"]): branch for branch in branches}
    n2 = by_id["concurrent_n2"]["probe_results"]
    n3 = by_id["concurrent_n3"]["probe_results"]
    n2_all_hit = len(n2) == 2 and all(exact_hit(record) for record in n2)
    n3_all_hit = len(n3) == 3 and all(exact_hit(record) for record in n3)
    if not n2_all_hit and n3_all_hit:
        return "SINGLE_GPU_LONG_WARM_CONCURRENCY_NON_MONOTONE_INCONCLUSIVE"
    if not n2_all_hit:
        return "SINGLE_GPU_LONG_WARM_CONCURRENCY_BELOW_2"
    if n3_all_hit:
        return "SINGLE_GPU_LONG_WARM_CONCURRENCY_AT_LEAST_3"
    return "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"


def load_support(path: Path):
    spec = importlib.util.spec_from_file_location("residency_prewarm_support", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load support file: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def reset_confirmed(status_code: int, body: object) -> bool:
    if status_code != 200:
        return False
    if body is True:
        return True

    if body == "":
        return True
    if isinstance(body, dict):
        return body.get("success") is True or body.get("reset") is True
    return False


def reset_log_evidence(text: str) -> tuple[list[str], bool, bool]:
    lines = [
        line for line in text.splitlines()
        if "reset prefix cache" in line.lower()
    ]
    success = any(
        "successfully reset prefix cache" in line.lower()
        for line in lines
    )
    failure = any(
        "failed to reset prefix cache" in line.lower()
        for line in lines
    )
    return lines, success, failure


async def physical_reset(
    api_root: str, engine_log: Path
) -> dict[str, object]:
    import httpx

    log_offset = engine_log.stat().st_size
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(api_root + "/reset_prefix_cache")
    record: dict[str, object] = {"status_code": response.status_code}
    try:
        record["body"] = response.json()
    except ValueError:
        record["body"] = response.text
    deadline = time.monotonic() + 30
    engine_lines: list[str] = []
    engine_success = False
    engine_failure = False
    while time.monotonic() < deadline:
        text = engine_log.read_bytes()[log_offset:].decode(errors="replace")
        engine_lines, engine_success, engine_failure = reset_log_evidence(
            text
        )
        if engine_success or engine_failure:
            break
        await asyncio.sleep(0.05)
    record["engine_log"] = engine_lines
    record["engine_success"] = engine_success
    record["engine_failure"] = engine_failure
    record["confirmed"] = (
        reset_confirmed(response.status_code, record["body"])
        and engine_success
        and not engine_failure
    )
    return record


async def completion_record(
    client: object,
    request: object,
    prompt: list[int],
    cache_salt: str,
    session_index: int,
) -> dict[str, object]:
    def failure(exc: BaseException) -> dict[str, object]:
        return {
            "request_id": request.request_id,
            "success": False,
            "status_code": None,
            "error": f"{type(exc).__name__}: {exc}",
            "prompt_tokens_reported": None,
            "output_tokens": None,
            "cached_prompt_tokens_observed": None,
        }

    started = time.perf_counter_ns()
    try:
        result = await client.complete(request, prompt, cache_salt=cache_salt)
        record = asdict(result)
    except asyncio.CancelledError as exc:
        record = failure(exc)
    except Exception as exc:
        record = failure(exc)
    record["wall_duration_ms"] = (time.perf_counter_ns() - started) / 1e6
    record["session_index"] = session_index
    return record


async def run_diagnostic(
    root: Path, model_dir: Path, model_name: str
) -> list[dict[str, object]]:
    from carbonaffinity.materialize import PromptMaterializer
    from carbonaffinity.models import RequestSpec
    from carbonaffinity.region import RegionClient

    materializer = PromptMaterializer(str(model_dir))
    prompts = []
    salts = []
    for index in SESSIONS:
        session = f"residency-session-{index}"
        prompts.append(materializer.tokens({
            "request_id": session,
            "session_id": session,
            "prompt_tokens": PROMPT_TOKENS,
            "shared_prefix_tokens": 0,
        }))
        salts.append(f"cache-residency-v1:{session}")

    client = RegionClient({
        "id": f"gpu_{GPU}",
        "api_base": f"http://127.0.0.1:{PORT}/v1",
        "api_key": "EMPTY",
        "model": model_name,
        "admission_concurrency": len(SESSIONS),
    }, 300)
    branches: list[dict[str, object]] = []
    try:
        for spec in branch_specs():
            branch_id = str(spec["branch_id"])
            indices = tuple(spec["prime_indices"])
            branch: dict[str, object] = {
                "branch_id": branch_id,
                "prime_order": list(indices),
                "probe_indices": list(indices),
                "prompt_tokens": PROMPT_TOKENS,
                "expected_cached_tokens": EXPECTED_CACHED_TOKENS,
                "prime_results": [],
                "probe_results": [],
                "integrity_valid": False,
            }
            path = root / "branches" / f"{branch_id}.json"
            try:
                branch["reset"] = await physical_reset(
                    f"http://127.0.0.1:{PORT}",
                    root / f"vllm_gpu_{GPU}.log",
                )
                if branch["reset"].get("confirmed") is not True:
                    raise RuntimeError("physical prefix-cache reset was not confirmed")
                await asyncio.sleep(0.2)
                for index in indices:
                    request = RequestSpec(
                        request_id=f"{branch_id}-prime-{index}",
                        arrival_ms=0,
                        prompt_tokens=PROMPT_TOKENS,
                        max_output_tokens=1,
                        session_id=f"residency-session-{index}",
                    )
                    record = await completion_record(
                        client, request, prompts[index], salts[index], index
                    )
                    branch["prime_results"].append(record)
                    errors = request_errors(record, 1)
                    if errors:
                        raise RuntimeError(f"prime {index} failed: {errors}")
                await asyncio.sleep(2.0)

                async def probe(index: int) -> dict[str, object]:
                    request = RequestSpec(
                        request_id=f"{branch_id}-probe-{index}",
                        arrival_ms=0,
                        prompt_tokens=PROMPT_TOKENS,
                        max_output_tokens=PROBE_OUTPUT_TOKENS,
                        session_id=f"residency-session-{index}",
                    )
                    record = await completion_record(
                        client, request, prompts[index], salts[index], index
                    )
                    record["exact_expected_cache"] = exact_hit(record)
                    return record

                branch["probe_results"] = await asyncio.gather(
                    *(probe(index) for index in indices)
                )
                failures = [
                    {"session_index": record["session_index"],
                     "errors": request_errors(record, PROBE_OUTPUT_TOKENS)}
                    for record in branch["probe_results"]
                    if request_errors(record, PROBE_OUTPUT_TOKENS)
                ]
                if failures:
                    raise RuntimeError(f"probe integrity failed: {failures}")
                branch["integrity_valid"] = True
            except Exception as exc:
                branch["error"] = f"{type(exc).__name__}: {exc}"
            write_json(path, branch)
            branches.append(branch)
            print(
                branch_id,
                [record.get("cached_prompt_tokens_observed")
                 for record in branch["probe_results"]],
                flush=True,
            )
            if not branch["integrity_valid"]:
                raise RuntimeError(branch["error"])
    finally:
        await client.close()
    return branches


def wait_ready(
    process: subprocess.Popen[bytes],
    telemetry: subprocess.Popen[bytes],
    deadline_s: float = 1200,
) -> None:
    import httpx

    deadline = time.monotonic() + deadline_s
    while True:
        if process.poll() is not None:
            raise RuntimeError("vLLM exited during startup")
        if telemetry.poll() is not None:
            raise RuntimeError("GPU telemetry exited during startup")
        try:
            if httpx.get(f"http://127.0.0.1:{PORT}/health", timeout=2).is_success:
                return
        except httpx.HTTPError:
            pass
        if time.monotonic() >= deadline:
            raise RuntimeError("vLLM startup timeout")
        print(datetime_now(), "VLLM_READY=0/1", flush=True)
        time.sleep(5)


def datetime_now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


def process_group_exists(pgid: int) -> bool:
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def terminate_group(process: subprocess.Popen[bytes] | None) -> None:
    if process is None:
        return
    pgid = process.pid
    process.poll()
    try:
        os.killpg(pgid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    deadline = time.monotonic() + 15
    while process_group_exists(pgid) and time.monotonic() < deadline:
        process.poll()
        time.sleep(0.2)
    if process_group_exists(pgid):
        try:
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    try:
        process.wait(timeout=15)
    except (subprocess.TimeoutExpired, ChildProcessError):
        pass


def run(args: argparse.Namespace) -> None:
    if os.name != "posix":
        raise RuntimeError("this diagnostic requires Linux")
    root = args.output_root.resolve()
    project = args.project_root.resolve()
    if root.parent != project / "results":
        raise ValueError("output root must be a new direct child of project/results")
    gpu_uuid = subprocess.check_output([
        "nvidia-smi", f"--id={GPU}", "--query-gpu=uuid", "--format=csv,noheader",
    ], text=True).strip()
    applications = subprocess.check_output([
        "nvidia-smi", "--query-compute-apps=gpu_uuid,pid", "--format=csv,noheader",
    ], text=True).splitlines()
    if any(line.split(",", 1)[0].strip() == gpu_uuid for line in applications if line.strip()):
        raise RuntimeError(f"GPU {GPU} already has a compute process")
    root.mkdir(parents=False, exist_ok=False)
    write_json(root / "RUN.json", {
        "stage": "single-gpu-long-prefix-residency-frontier",
        "diagnostic_only": True,
        "gpu_index": GPU,
        "port": PORT,
        "prompt_tokens": PROMPT_TOKENS,
        "expected_cached_tokens": EXPECTED_CACHED_TOKENS,
        "sessions": len(SESSIONS),
        "branches": [spec["branch_id"] for spec in branch_specs()],
        "source_residency_run": str(args.source_residency_run),
    })
    server = telemetry = None
    server_log = telemetry_log = None
    def terminate_from_signal(signum: int, _frame: object) -> None:
        raise TerminationRequested(f"received signal {signum}")

    previous_sigterm = signal.signal(signal.SIGTERM, terminate_from_signal)
    previous_sigint = signal.signal(signal.SIGINT, terminate_from_signal)
    try:
        with socket.socket() as sock:
            if sock.connect_ex(("127.0.0.1", PORT)) == 0:
                raise RuntimeError(f"port {PORT} is already occupied")
        server_log = (root / f"vllm_gpu_{GPU}.log").open("xb")
        env = os.environ.copy()
        env.update(
            CUDA_VISIBLE_DEVICES=str(GPU),
            TRITON_PRINT_AUTOTUNING="1",
            # The loopback-only diagnostic requires the real cache-reset API
            # so every branch starts from an independent physical cache state.
            VLLM_SERVER_DEV_MODE="1",
        )
        command = [
            str(project / ".venv/bin/vllm"), "serve", str(args.model_dir),
            "--served-model-name", args.model_name, "--host", "127.0.0.1",
            "--port", str(PORT), "--tensor-parallel-size", "1",
            "--enable-prefix-caching", "--enable-prompt-tokens-details",
            "--enable-chunked-prefill", "--max-num-batched-tokens", "784",
            "--max-num-seqs", "8", "--max-model-len", "65536",
            "--gpu-memory-utilization", "0.92",
        ]
        server = subprocess.Popen(command, cwd=project, env=env,
                                  stdout=server_log, stderr=subprocess.STDOUT,
                                  stdin=subprocess.DEVNULL, start_new_session=True)
        write_json(root / "SUPERVISOR.json", {"pid": os.getpid(), "server_pid": server.pid})
        telemetry_log = (root / "gpu_telemetry.csv").open("xb")
        telemetry = subprocess.Popen([
            "nvidia-smi", f"--id={GPU}",
            "--query-gpu=timestamp,index,uuid,utilization.gpu,memory.used,power.draw,clocks.sm",
            "--format=csv", "--loop=1",
        ], stdout=telemetry_log, stderr=subprocess.STDOUT,
           stdin=subprocess.DEVNULL, start_new_session=True)
        wait_ready(server, telemetry)
        print(datetime_now(), "VLLM_READY=1/1", flush=True)

        support = load_support(args.support_file)
        from carbonaffinity.materialize import PromptMaterializer
        from carbonaffinity.region import RegionClient
        os.environ["TRITON_PRINT_AUTOTUNING"] = "1"
        asyncio.run(support.prewarm(
            root, PromptMaterializer(str(args.model_dir)), RegionClient,
            gpus=(GPU,), first_port=PORT, model=args.model_name
        ))
        log_offset = (root / f"vllm_gpu_{GPU}.log").stat().st_size
        branches = asyncio.run(
            run_diagnostic(root, args.model_dir, args.model_name)
        )
        if telemetry.poll() is not None:
            raise RuntimeError(
                "GPU telemetry exited during measurement; inspect gpu_telemetry.csv"
            )
        data = (root / f"vllm_gpu_{GPU}.log").read_bytes()[log_offset:]
        later_tuning = support.tuning_events(data.decode(errors="replace"))
        report = {
            "status": "COMPLETE",
            "diagnostic_only": True,
            "classification": classify(branches),
            "post_prewarm_tuning_events": later_tuning,
            "branches": branches,
            "cache_observation_semantics": "null is unknown, not observed zero",
        }
        write_json(root / "RESIDENCY_FRONTIER.json", report)
        write_json(root / "EXPERIMENT_COMPLETE.json", {
            "status": "COMPLETE", "branches": len(branches),
            "classification": report["classification"],
        })
        print("CLASSIFICATION =", report["classification"], flush=True)
        print("CACHE_RESIDENCY_FRONTIER_COMPLETE =", root, flush=True)
    except Exception as exc:
        write_json(root / "FATAL.json", {
            "status": "FAIL", "error": f"{type(exc).__name__}: {exc}"
        })
        raise
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        terminate_group(telemetry)
        terminate_group(server)
        if telemetry_log is not None:
            telemetry_log.close()
        if server_log is not None:
            server_log.close()
        signal.signal(signal.SIGTERM, previous_sigterm)
        signal.signal(signal.SIGINT, previous_sigint)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, default=Path("/root/CarbonAffinity"))
    parser.add_argument("--model-dir", type=Path, default=Path("/root/models/Qwen3.5-27B"))
    parser.add_argument("--model-name", default=MODEL_NAME)
    parser.add_argument("--support-file", type=Path, required=True)
    parser.add_argument("--source-residency-run", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    return parser.parse_args()


if __name__ == "__main__":
    run(parse_args())
