"""CPU-only fit from audited residual development data; never installs/freezes."""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, write_json
from scripts.audit_latency_residual import audit
from scripts.residual_latency_candidate import fit_candidate


def source_files(root):
    names = ["PREREGISTRATION.json", "LAUNCH.json", "SHAPE_PREWARM.json",
             "RESIDUAL_DEVELOPMENT_AUDIT.json", "EXPERIMENT_COMPLETE.json"]
    paths = [root / name for name in names]
    paths += sorted((root / "raw").rglob("*.jsonl"))
    paths += sorted((root / "raw").rglob("*.json"))
    paths += sorted((root / "prewarm").glob("*.json"))
    paths += [root / f"vllm_gpu_{gpu}.log" for gpu in range(8)]
    if any(not p.is_file() for p in paths):
        raise ValueError("source evidence file missing")
    return paths


def build(source, output):
    source, output = Path(source).resolve(), Path(output).resolve()
    if output == source or output.is_relative_to(source) or source.is_relative_to(output):
        raise ValueError("fit output must be separate from development source")
    if output.exists():
        raise FileExistsError("output exists; no overwrite/resume")
    saved = json.loads((source / "RESIDUAL_DEVELOPMENT_AUDIT.json").read_text())
    complete = json.loads((source / "EXPERIMENT_COMPLETE.json").read_text())
    if saved.get("status") != "PASS" or complete.get("status") != "COMPLETE" or complete.get("rows") != 864:
        raise ValueError("source must have passing development audit and 864-row completion")
    files = source_files(source)
    before = {str(p.relative_to(source)): sha256(p) for p in files}
    rechecked = audit(source)
    if rechecked["status"] != "PASS":
        raise ValueError("source audit recheck failed: " + json.dumps(rechecked["checks"]))
    rows = read_rows(source / "raw")
    output.mkdir(parents=True, exist_ok=False)
    try:
        import scripts.residual_latency_candidate as candidate_module
        import scripts.audit_latency_residual as audit_module
        import scripts.latency_residual_protocol as protocol_module
        import carbonaffinity.artifacts as artifacts_module
        paths = [Path(__file__).resolve()] + [Path(m.__file__).resolve() for m in
                 (candidate_module, audit_module, protocol_module, artifacts_module)]
        fit_record = {"created_utc": datetime.now(timezone.utc).isoformat(),
            "stage": "CPU_CANDIDATE_FIT_FROM_DEVELOPMENT_ONLY", "source_root": str(source),
            "source_sha256": before, "fit_code_sha256": {str(p): sha256(p) for p in paths},
            "method_selection": "Selected after inspection of development summary; not preregistered before development sampling",
            "validation_data_read": False, "candidate_frozen": False}
        write_json(output / "FIT_RECORD.json", fit_record)
        model, diagnostics = fit_candidate(rows)
        after = {str(p.relative_to(source)): sha256(p) for p in source_files(source)}
        if after != before:
            raise RuntimeError("source changed during fit; do not use candidate")
        model["development_source"] = {"root": str(source), "rows": len(rows),
                                       "fit_record_sha256": sha256(output / "FIT_RECORD.json")}
        candidate_path = output / "residual_latency_candidate_v1.json"
        write_json(candidate_path, model)
        checks = {"864_development_batches": len(rows) == 864,
                  "54_model_cells": sum(len(s["cells"]) for s in model["surfaces"].values()) == 54,
                  "eight_loo_folds": len(diagnostics["leave_one_gpu_out_without_margin"]) == 8,
                  "source_unchanged": before == after,
                  "development_coverage_100pct": all(g["coverage"] == 1.0 for g in diagnostics["development_resubstitution"].values()),
                  "not_frozen_not_validated": model["candidate_frozen"] is False and model["independent_validation_passed"] is False}
        report = {"status": "CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION" if all(checks.values()) else "FAIL",
                  "checks": checks, "source_root": str(source), "candidate": str(candidate_path),
                  "candidate_sha256": sha256(candidate_path), "candidate_frozen": False,
                  "margin_ms": model["margin_ms"], **diagnostics}
        write_json(output / "RESIDUAL_CANDIDATE_AUDIT.json", report)
        if not all(checks.values()):
            raise RuntimeError("candidate construction checks failed")
        write_json(output / "FIT_COMPLETE.json", {"status": "COMPLETE", "model_validated": False,
                   "candidate_frozen": False, "candidate_sha256": report["candidate_sha256"],
                   "audit_sha256": sha256(output / "RESIDUAL_CANDIDATE_AUDIT.json")})
        return report
    except Exception as exc:
        write_json(output / "FATAL.json", {"status": "FAIL", "error": f"{type(exc).__name__}: {exc}"})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    report = build(args.input_root, args.output_root)
    print("STATUS =", report["status"])
    print("CHECKS =", json.dumps(report["checks"]))
    print("MARGINS_MS =", json.dumps(report["margin_ms"]))
    print("LOO: per GPU, coverage BEFORE margin; diagnostic only")
    for fold in report["leave_one_gpu_out_without_margin"]:
        print("GPU", fold["heldout_gpu"], " ".join(
            f"{name}={g['coverage']:.1%}/+{g['positive_residual_max_ms']:.3f}ms"
            for name, g in fold["without_margin"].items()))
    print("DEVELOPMENT_RESUBSTITUTION =", json.dumps(report["development_resubstitution"]))
    print("CANDIDATE =", report["candidate"])
    print("CANDIDATE_SHA256 =", report["candidate_sha256"])
    print("CANDIDATE_FROZEN = False; INDEPENDENT_VALIDATION_PASSED = False")
    print("RESIDUAL_CANDIDATE_CPU_FIT_COMPLETE")


if __name__ == "__main__":
    main()
