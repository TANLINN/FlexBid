from __future__ import annotations

import argparse
import json
from pathlib import Path

from carbonaffinity.artifacts import sha256, write_json
from carbonaffinity.config import load_config, resolve_path
from carbonaffinity.future_work import annotate_problem
from carbonaffinity.profile import HardwareProfile


def main():
    parser = argparse.ArgumentParser(description="Annotate using only workload/observed turn and a trained table")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    problem = json.loads(args.input.read_text(encoding="utf-8"))
    model = json.loads(args.model.read_text(encoding="utf-8"))
    config = load_config(args.config or problem["source"]["config"])
    profiles = {row["id"]: HardwareProfile.from_json(resolve_path(config, row["profile"])) for row in config["regions"]}
    inside, outside = annotate_problem(problem, model, profiles)
    problem.setdefault("source", {})["learned_continuation"] = {
        "mode": "observable_only_expected_work", "model": str(args.model.resolve()),
        "model_sha256": sha256(args.model), "future_trace_access": False,
        "model_turn_range": [0, model.get("max_turn", 64)],
        "in_domain_requests": inside, "out_of_domain_requests": outside,
        "future_carbon_assumption": "current intensity persists over expected remaining work",
    }
    write_json(args.output, problem)
    print(f"LEARNED_FUTURE_ANNOTATION_COMPLETE in_domain={inside} out_of_domain={outside}")


if __name__ == "__main__":
    main()
