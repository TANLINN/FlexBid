from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="Fit workload-stratified session return-time models")
    parser.add_argument("--trace", type=Path, required=True, help="training split only")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    rows = [json.loads(line) for line in args.trace.read_text(encoding="utf-8").splitlines() if line.strip()]
    sessions = defaultdict(list)
    for row in rows:
        sessions[str(row.get("session_id") or row["request_id"])].append(row)
    groups = defaultdict(lambda: {"opportunities": 0, "gaps": []})
    for turns in sessions.values():
        turns.sort(key=lambda row: (float(row.get("arrival_ms", 0)), int(row.get("turn_id", 0))))
        for index, row in enumerate(turns):
            workload = str(row.get("workload", row.get("source", "default")))
            groups[workload]["opportunities"] += 1
            groups["default"]["opportunities"] += 1
            if index + 1 < len(turns):
                gap_s = max(0.0, (float(turns[index + 1].get("arrival_ms", 0)) - float(row.get("arrival_ms", 0))) / 1000.0)
                groups[workload]["gaps"].append(gap_s)
                groups["default"]["gaps"].append(gap_s)
    fitted = {}
    for name, values in groups.items():
        gaps = values["gaps"]
        opportunities = values["opportunities"]
        fitted[name] = {
            "return_probability": len(gaps) / opportunities if opportunities else 0.0,
            "mean_gap_s": statistics.mean(gaps) if gaps else 1.0,
            "median_gap_s": statistics.median(gaps) if gaps else None,
            "returned_turns": len(gaps),
            "opportunities": opportunities,
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(fitted, indent=2), encoding="utf-8")
    print(json.dumps(fitted, indent=2))


if __name__ == "__main__":
    main()
