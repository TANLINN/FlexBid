from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="Derive KV-cache bytes/token from a model config")
    parser.add_argument("--model-config", type=Path, required=True)
    parser.add_argument("--attention-layers", type=int, help="override for hybrid attention/state-space models")
    parser.add_argument("--bytes-per-element", type=int, default=2)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config = json.loads(args.model_config.read_text(encoding="utf-8"))
    text = config.get("text_config", config)
    heads = int(text["num_attention_heads"])
    kv_heads = int(text.get("num_key_value_heads", heads))
    head_dim = int(text.get("head_dim", int(text["hidden_size"]) // heads))
    layer_types = text.get("layer_types")
    if args.attention_layers is not None:
        attention_layers = args.attention_layers
        source = "command_line_override"
    elif isinstance(layer_types, list):
        attention_layers = sum("attention" in str(value).lower() for value in layer_types)
        source = "config.layer_types"
    else:
        attention_layers = int(text["num_hidden_layers"])
        source = "config.num_hidden_layers"
    if attention_layers <= 0:
        raise RuntimeError("could not derive a positive number of attention layers")
    # One key and one value tensor per attention layer.
    bytes_per_token = attention_layers * kv_heads * head_dim * 2 * args.bytes_per_element
    result = {
        "attention_layers": attention_layers,
        "attention_layer_source": source,
        "num_key_value_heads": kv_heads,
        "head_dim": head_dim,
        "bytes_per_element": args.bytes_per_element,
        "kv_bytes_per_token": bytes_per_token,
        "warning": "For hybrid/custom cache implementations, verify against vLLM allocated cache blocks.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

