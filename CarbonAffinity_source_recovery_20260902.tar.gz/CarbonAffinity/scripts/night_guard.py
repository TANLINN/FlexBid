from __future__ import annotations

import concurrent.futures
import json
import os
import subprocess
import sys
import time
import urllib.request
import uuid
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
OUTPUT_ROOT = Path((RESULTS / "real_campaign_latest.txt").read_text().strip())
EVENT_LOG = RESULTS / "night_guard" / "events.log"
PID_FILE = OUTPUT_ROOT / "launcher.pid"
MAX_RESTARTS = 3


def log(message: str) -> None:
    EVENT_LOG.parent.mkdir(parents=True, exist_ok=True)
    with EVENT_LOG.open("a", encoding="utf-8") as stream:
        stream.write(f"{time.ctime()} {message}\n")


def campaign_pid() -> int | None:
    try:
        pid = int(PID_FILE.read_text().strip())
        command = Path(f"/proc/{pid}/cmdline").read_bytes().replace(b"\0", b" ")
        return pid if b"run_real_campaign.py" in command else None
    except (OSError, ValueError):
        return None


def marker_exists() -> bool:
    return any((OUTPUT_ROOT / name).exists() for name in (
        "REAL_CAMPAIGN_COMPLETE.json", "CAMPAIGN_PARTIAL.json"
    ))


def start_campaign(attempt: int) -> subprocess.Popen[bytes]:
    log_path = OUTPUT_ROOT / f"launcher.guard.{attempt}.log"
    stream = log_path.open("ab")
    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT)
    process = subprocess.Popen([
        sys.executable, "-u", str(ROOT / "scripts/run_real_campaign.py"),
        "--output-root", str(OUTPUT_ROOT), "--repetitions", "5", "--seed", "20260818",
    ], cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    PID_FILE.write_text(str(process.pid))
    log(f"restart attempt={attempt} pid={process.pid}")
    return process


def keepalive(port: int) -> str:
    payload = json.dumps({
        "model": "Qwen3.5-27B", "prompt": [101] * 8192,
        "max_tokens": 64, "temperature": 0.0, "ignore_eos": True,
        "cache_salt": uuid.uuid4().hex,
    }).encode()
    request = urllib.request.Request(
        f"http://127.0.0.1:{port}/v1/completions", data=payload,
        headers={"Content-Type": "application/json", "Authorization": "Bearer EMPTY"},
    )
    with urllib.request.urlopen(request, timeout=300) as response:
        return f"{port}:{response.status}"


def retention_loop() -> None:
    log("campaign finished or recovery exhausted; starting vLLM retention pulses")
    while True:
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(keepalive, 18000 + gpu) for gpu in range(8)]
            results = []
            for future in futures:
                try:
                    results.append(future.result())
                except Exception as error:  # retention must survive endpoint failures
                    results.append(f"ERROR:{type(error).__name__}:{error}")
        log("retention " + " ".join(results))
        time.sleep(180)


def main() -> None:
    restarts = 0
    while not marker_exists():
        pid = campaign_pid()
        if pid is not None:
            time.sleep(30)
            continue
        if restarts >= MAX_RESTARTS:
            log("recovery attempts exhausted")
            break
        restarts += 1
        process = start_campaign(restarts)
        process.wait()
        log(f"restarted campaign exited code={process.returncode}")
    retention_loop()


if __name__ == "__main__":
    main()
