from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path

import yaml


def conformal_quantile(values: list[float], coverage: float) -> float:
    ordered = sorted(values)
    # Split-conformal finite-sample rank.  Capping is necessary when the
    # requested coverage is unattainable with the available calibration size.
    rank = math.ceil((len(ordered) + 1) * coverage) - 1
    return ordered[min(len(ordered) - 1, max(0, rank))]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--quantile", type=float, default=0.95)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config = yaml.safe_load(args.config.read_text())
    root = args.config.resolve().parent.parent
    trace = Path(config["carbon"]["trace"])
    if not trace.is_absolute():
        trace = root / trace
    with trace.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))
    # A routing decision compares regions at the same timestamp.  Calibrating
    # individual region rows would not cover that joint comparison.  Use the
    # maximum absolute regional residual at each timestamp as the conformal
    # score; then q * (E_winner + E_incumbent) bounds the carbon-difference
    # error whenever the timestamp-level score is covered.
    by_timestamp: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        forecast = row.get("forecast_lbs_per_mwh")
        historical = row.get("historical_lbs_per_mwh")
        if forecast in (None, "") or historical in (None, ""):
            continue
        by_timestamp[str(row["timestamp"])].append(
            abs(float(forecast) - float(historical))
        )
    scores = [max(values) for values in by_timestamp.values() if values]
    if not scores:
        raise RuntimeError("carbon trace has no paired forecast/historical observations")
    calibrated = conformal_quantile(scores, args.quantile)
    config.setdefault("routing", {})["carbon_error_quantile_lbs_per_mwh"] = calibrated
    args.config.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    report = {
        "config": str(args.config),
        "timestamp_groups": len(scores),
        "coverage": args.quantile,
        "score": "max absolute regional forecast residual per timestamp",
        "carbon_error_quantile_lbs_per_mwh": calibrated,
        "score_min": min(scores), "score_max": max(scores),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
