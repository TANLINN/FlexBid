from __future__ import annotations

import argparse
import asyncio
import json
import statistics
import time
import uuid
from dataclasses import asdict
from pathlib import Path

from carbonaffinity.materialize import PromptMaterializer
from carbonaffinity.models import RequestSpec
from carbonaffinity.region import RegionClient


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    index = min(len(values) - 1, max(0, int((len(values) - 1) * q + 0.999999)))
    return values[index]


async def measure(args: argparse.Namespace) -> None:
    if args.output.exists() and not args.resume:
        raise FileExistsError("use a new output path; existing measurements preserved")
    namespace = uuid.uuid4().hex
    materializer = PromptMaterializer(args.tokenizer)
    client = RegionClient({
        "id": args.region_id,
        "api_base": args.api_base,
        "api_key": args.api_key,
        "model": args.model,
        "admission_concurrency": max(args.concurrency),
    }, args.timeout_s)
    rows: list[dict] = []
    if args.output.exists() and args.resume:
        rows = [
            json.loads(line) for line in args.output.read_text().splitlines()
            if line.strip()
        ]
    completed = {
        (row["prompt_tokens"], row["mode"], row["concurrency"], row["repeat"])
        for row in rows
    }
    try:
        if not rows and args.server_warmup_requests > 0:
            warmup_raw = {
                "request_id": "latency-gate-server-warmup",
                "session_id": "latency-gate-server-warmup",
                "prompt_tokens": args.server_warmup_prompt_tokens,
                "shared_prefix_tokens": 0,
            }
            warmup_prompt = materializer.tokens(warmup_raw)
            for index in range(args.server_warmup_requests):
                warmup = RequestSpec(
                    request_id=f"latency-gate-server-warmup-{index}",
                    arrival_ms=0,
                    prompt_tokens=args.server_warmup_prompt_tokens,
                    max_output_tokens=args.server_warmup_output_tokens,
                    session_id=f"latency-gate-server-warmup-{index}",
                )
                result = await client.complete(warmup, warmup_prompt)
                if not result.success:
                    raise RuntimeError(f"server warmup failed: {result.error}")
            if not await client.reset_prefix_cache():
                raise RuntimeError("prefix-cache reset after server warmup failed")
            print(
                "SERVER_WARMUP_COMPLETE",
                f"requests={args.server_warmup_requests}",
                f"prompt_tokens={args.server_warmup_prompt_tokens}",
                flush=True,
            )
        for prompt_tokens in args.prompt_tokens:
            for mode in ("cold", "warm"):
                for concurrency in args.concurrency:
                    for repeat in range(args.repeats):
                        key = (prompt_tokens, mode, concurrency, repeat)
                        if key in completed:
                            continue
                        if not await client.reset_prefix_cache():
                            raise RuntimeError("prefix-cache reset failed")
                        common_raw = {
                            "request_id": f"warm-{prompt_tokens}-{repeat}",
                            "session_id": f"warm-{prompt_tokens}-{repeat}",
                            "prompt_tokens": prompt_tokens,
                            "shared_prefix_tokens": prompt_tokens,
                        }
                        common_prompt = materializer.tokens(common_raw)
                        salt = f"{namespace}:{mode}:{prompt_tokens}:{concurrency}:{repeat}"
                        if mode == "warm":
                            prime = RequestSpec(
                                request_id=f"prime-{prompt_tokens}-{repeat}", arrival_ms=0,
                                prompt_tokens=prompt_tokens, max_output_tokens=1,
                                session_id=common_raw["session_id"], shared_prefix_tokens=prompt_tokens,
                            )
                            result = await client.complete(prime, common_prompt, cache_salt=salt)
                            if not result.success:
                                raise RuntimeError(f"warm prime failed: {result.error}")
                        requests = []
                        for index in range(concurrency):
                            if mode == "warm":
                                prompt = common_prompt
                            else:
                                raw = {
                                    "request_id": f"cold-{prompt_tokens}-{concurrency}-{repeat}-{index}",
                                    "session_id": f"cold-{prompt_tokens}-{concurrency}-{repeat}-{index}",
                                    "prompt_tokens": prompt_tokens,
                                    "shared_prefix_tokens": 0,
                                }
                                prompt = materializer.tokens(raw)
                            request = RequestSpec(
                                request_id=f"measure-{mode}-{prompt_tokens}-{concurrency}-{repeat}-{index}",
                                arrival_ms=0, prompt_tokens=prompt_tokens,
                                max_output_tokens=args.output_tokens,
                                session_id=f"measure-{mode}-{prompt_tokens}-{concurrency}-{repeat}-{index}",
                                shared_prefix_tokens=prompt_tokens if mode == "warm" else 0,
                            )
                            requests.append(client.complete(
                                request, prompt, cache_salt=salt if mode == "warm" else f"{salt}:{index}",
                                estimated_cached_tokens=prompt_tokens if mode == "warm" else 0,
                            ))
                        started_ns = time.perf_counter_ns()
                        results = await asyncio.gather(*requests)
                        duration_s = (time.perf_counter_ns() - started_ns) / 1e9
                        failures = [result for result in results if not result.success]
                        if failures:
                            raise RuntimeError(f"{len(failures)}/{len(results)} requests failed")
                        ttfts = [float(result.ttft_ms) for result in results if result.ttft_ms is not None]
                        tpots = [float(result.tpot_ms) for result in results if result.tpot_ms is not None]
                        row = {
                            "region_id": args.region_id,
                            "gpu_index": args.gpu_index,
                            "prompt_tokens": prompt_tokens,
                            "mode": mode,
                            "concurrency": concurrency,
                            "repeat": repeat,
                            "output_tokens": args.output_tokens,
                            "batch_duration_s": duration_s,
                            "ttft_p50_ms": statistics.median(ttfts),
                            "ttft_p95_ms": percentile(ttfts, 0.95),
                            "tpot_p50_ms": statistics.median(tpots),
                            "tpot_p95_ms": percentile(tpots, 0.95),
                            "cached_tokens": [result.cached_prompt_tokens_observed for result in results],
                            "results": [asdict(result) for result in results],
                        }
                        rows.append(row)
                        args.output.parent.mkdir(parents=True, exist_ok=True)
                        with args.output.open("a", encoding="utf-8") as handle:
                            handle.write(json.dumps(row) + "\n")
                            handle.flush()
                        print(f"GPU {args.gpu_index}: rows={len(rows)} mode={mode} prompt={prompt_tokens} concurrency={concurrency}", flush=True)
                        await asyncio.sleep(args.settle_s)
    finally:
        await client.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--gpu-index", type=int, required=True)
    parser.add_argument("--prompt-tokens", type=int, nargs="+", default=[2048, 8192])
    parser.add_argument("--output-tokens", type=int, default=64)
    parser.add_argument("--concurrency", type=int, nargs="+", default=[1, 2, 4, 8])
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--settle-s", type=float, default=0.5)
    parser.add_argument("--server-warmup-requests", type=int, default=2)
    parser.add_argument("--server-warmup-prompt-tokens", type=int, default=2048)
    parser.add_argument("--server-warmup-output-tokens", type=int, default=16)
    parser.add_argument("--timeout-s", type=float, default=900)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    asyncio.run(measure(parser.parse_args()))


if __name__ == "__main__":
    main()
