"""Export a plain-source server paste, without clipboard/PowerShell or base64."""
import argparse
import hashlib
import json
import shlex
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
BASE_DIGEST = "faa9f726faf33f9932dc92b4149e34dc594a6782565e8a771f7b3e5c7040ce2e"
NAMES = ("scripts/corun_observable_pilot.py", "tests/test_corun_observable_pilot.py")
SEPARATOR = "\n# === OBSERVABLE_CORUN_TEST_SOURCE_BOUNDARY ===\n"
FAILURE_GUARD = '''import json,sys
from pathlib import Path
root=Path(sys.argv[1])
if not (root/'FATAL.json').is_file() or (root/'EXPERIMENT_COMPLETE.json').exists():
    raise SystemExit('NOT_THE_FAILED_RUN_NOT_STARTED')
for gpu in range(8):
    rows=[json.loads(s) for s in (root/'raw'/('gpu_'+str(gpu))/'measurements.jsonl').read_text().splitlines() if s.strip()]
    if len(rows)!=5 or not all(all(r.get('checks',{}).values()) and r.get('checks') for r in rows[:4]):
        raise SystemExit('UNEXPECTED_EARLIER_CASES_GPU_'+str(gpu))
    row=rows[-1]
    failed=[k for k,v in row.get('checks',{}).items() if v is not True]
    error=row.get('collection_error','')
    bg0=row.get('results',{}).get('bg0',{})
    print('GPU',gpu,'case=',row.get('case_id'),'failed=',failed,'error=',error,flush=True)
    if (row.get('case_id')!='cold_small_decode2' or failed!=['schema_complete']
        or 'background finished/failed before requested phase' not in error
        or row.get('admission_snapshot') is not None
        or bg0.get('success') is not True or bg0.get('output_tokens')!=192):
        raise SystemExit('DIFFERENT_FAILURE_NOT_STARTED; send the printed diagnosis')
print('V1_DECODE_OVERLAP_CONSTRUCTION_FAILURE_CONFIRMED')
'''
INSTALLER = '''import hashlib,json,sys
from pathlib import Path
project=Path('/root/CarbonAffinity')
raw=sys.stdin.buffer.read()
if hashlib.sha256(raw).hexdigest()!=sys.argv[1]:
    raise SystemExit('SOURCE_CHECKSUM_FAILED_NOT_INSTALLED')
base=project/'results/residual_latency_transfer_faa9f726faf33f99'
manifest=json.loads((base/'TRANSFER_MANIFEST.json').read_text())
if manifest['payload_sha256']!='faa9f726faf33f9932dc92b4149e34dc594a6782565e8a771f7b3e5c7040ce2e':
    raise SystemExit('BASE_BUNDLE_MISMATCH')
files={}
for name,digest in manifest['files_sha256'].items():
    data=(base/name).read_bytes()
    if hashlib.sha256(data).hexdigest()!=digest:
        raise SystemExit('BASE_SOURCE_CHANGED: '+name)
    files[name]=data
for name,digest in manifest['required_core_lf_sha256'].items():
    if hashlib.sha256((project/name).read_text(encoding='utf-8').encode()).hexdigest()!=digest:
        raise SystemExit('CORE_SOURCE_CHANGED: '+name)
parts=raw.decode('utf-8').split('\\n# === OBSERVABLE_CORUN_TEST_SOURCE_BOUNDARY ===\\n')
if len(parts)!=2:
    raise SystemExit('SOURCE_BOUNDARY_INVALID')
for name,source in zip(('scripts/corun_observable_pilot.py','tests/test_corun_observable_pilot.py'),parts):
    if name in files:
        raise SystemExit('UNEXPECTED_SOURCE_COLLISION')
    files[name]=source.encode()
destination=project/'results'/('observable_corun_transfer_'+sys.argv[1][:16])
if destination.is_symlink():
    raise SystemExit('SYMLINK_DESTINATION_REJECTED')
for name,data in files.items():
    relative=Path(name)
    if relative.is_absolute() or '..' in relative.parts or relative.parts[0] not in ('scripts','tests'):
        raise SystemExit('UNSAFE_SOURCE_PATH')
    compile(data,name,'exec')
    target=destination/relative
    if target.is_symlink() or target.parent.is_symlink():
        raise SystemExit('SYMLINK_SOURCE_REJECTED')
    if target.exists() and target.read_bytes()!=data:
        raise SystemExit('EXISTING_SOURCE_DIFFERS: '+name)
for name,data in files.items():
    target=destination/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        with target.open('xb') as handle:
            handle.write(data)
    if target.read_bytes()!=data:
        raise SystemExit('INSTALLED_HASH_MISMATCH')
record=dict(source_payload_sha256=sys.argv[1],base_payload_sha256=manifest['payload_sha256'],
    files_sha256={n:hashlib.sha256(d).hexdigest() for n,d in files.items()},
    required_core_lf_sha256=manifest['required_core_lf_sha256'],scope='v2: 192-case co-run development pilot; primed decode backgrounds, not v1 continuation')
target=destination/'PILOT_TRANSFER_MANIFEST.json'
data=(json.dumps(record,sort_keys=True,indent=2)+'\\n').encode()
if target.exists() and target.read_bytes()!=data:
    raise SystemExit('EXISTING_MANIFEST_DIFFERS')
if not target.exists():
    with target.open('xb') as handle:
        handle.write(data)
print(destination)
'''


def payload():
    sources = [PROJECT.joinpath(n).read_text(encoding="utf-8") for n in NAMES]
    if any(SEPARATOR in source or "\nOBSERVABLE_CORUN_SOURCES_EOF\n" in source for source in sources):
        raise ValueError("source delimiter collision")
    for name, source in zip(NAMES, sources):
        compile(source, name, "exec")
    return SEPARATOR.join(sources).encode()


def command(failure_root=None):
    raw = payload()
    digest = hashlib.sha256(raw).hexdigest()
    body = f'''cd /root/CarbonAffinity
if CORUN_BUNDLE="$(/root/CarbonAffinity/.venv/bin/python -c {shlex.quote(INSTALLER)} {digest} <<'OBSERVABLE_CORUN_SOURCES_EOF'
{raw.decode()}OBSERVABLE_CORUN_SOURCES_EOF
)"; then
    if (cd "$CORUN_BUNDLE" && PYTHONPATH="$CORUN_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -m unittest tests.test_latency_residual tests.test_corun_observable_pilot -q); then
        CORUN="/root/CarbonAffinity/results/observable_corun_pilot_v2_$(date -u +%Y%m%dT%H%M%S%NZ)"
        nohup env PYTHONPATH="$CORUN_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -u "$CORUN_BUNDLE/scripts/corun_observable_pilot.py" --project-root /root/CarbonAffinity --model-dir /root/models/Qwen3.5-27B --output-root "$CORUN" > "${{CORUN}}.launcher.log" 2>&1 < /dev/null &
        echo "PID=$! CORUN=$CORUN"
        echo "OBSERVABLE_CORUN_PILOT_V2_SUBMITTED_EXPECTED_ROWS=192"
    else
        echo "PILOT_SELF_TEST_FAILED_NOT_STARTED"
    fi
else
    echo "PILOT_INSTALL_FAILED_NOT_STARTED"
fi
'''
    if failure_root is None:
        return body
    # Treat the argument as a remote POSIX path even when this generator runs
    # on Windows. Never silently turn /root into a backslash filename.
    from pathlib import PurePosixPath
    remote = str(PurePosixPath(str(failure_root).replace("\\", "/")))
    return f'''cd /root/CarbonAffinity
if /root/CarbonAffinity/.venv/bin/python -c {shlex.quote(FAILURE_GUARD)} {shlex.quote(remote)}; then
{body}else
    echo "FAILURE_NOT_CONFIRMED_NOT_INSTALLED_NOT_STARTED"
fi
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--confirm-failed-root", help="remote Linux result directory; no local path conversion")
    args = parser.parse_args()
    text = command(args.confirm_failed_root)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open("x", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
        print(json.dumps(dict(path=str(args.output.resolve()), lines=len(text.splitlines()),
                              sha256=hashlib.sha256(text.encode()).hexdigest())))
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
