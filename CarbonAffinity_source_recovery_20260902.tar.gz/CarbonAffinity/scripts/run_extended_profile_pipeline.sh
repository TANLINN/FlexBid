#!/usr/bin/env bash
set -euo pipefail

ROOT="/root/CarbonAffinity"
cd "$ROOT"
source .venv/bin/activate

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
GATE="$ROOT/results/extended_profile_gate_$STAMP"
MAIN="$ROOT/results/real_tracelab_neso_extended_$STAMP"
mkdir -p "$GATE" "$ROOT/results/night_guard"
printf '%s\n' "$GATE" > results/extended_profile_gate_latest.txt
printf '%s\n' "$MAIN" > results/extended_real_campaign_latest.txt

start_guard() {
  if ! pgrep -af '^bash scripts/night_guard\.sh$' >/dev/null; then
    setsid -f bash scripts/night_guard.sh \
      > results/night_guard/guard.after_extended_pipeline.log 2>&1
  fi
}
trap start_guard EXIT

# A guard launched through setsid owns its retention workers' process group.
while read -r pid; do
  [[ -n "$pid" ]] || continue
  pgid="$(ps -o pgid= -p "$pid" | tr -d ' ')"
  [[ -n "$pgid" ]] && kill -TERM -- "-$pgid" 2>/dev/null || true
done < <(pgrep -f '^bash scripts/night_guard\.sh$' || true)

for _ in $(seq 1 36); do
  busy="$(nvidia-smi --query-gpu=utilization.gpu \
    --format=csv,noheader,nounits | awk '$1 > 10 {count++} END {print count+0}')"
  [[ "$busy" == 0 ]] && break
  sleep 5
done
[[ "$busy" == 0 ]] || { echo "RETENTION_LOAD_STILL_ACTIVE"; exit 3; }

pids=()
for index in 0 1 2 3; do
  gpu_a=$((index * 2))
  gpu_b=$((gpu_a + 1))
  .venv/bin/python -u scripts/run_local_pair_campaign.py \
    --config "configs/real_window_0${index}.generated.yaml" \
    --output-root "$GATE/window_0${index}" \
    --gpu-a "$gpu_a" --gpu-b "$gpu_b" \
    --policy-order-seed "$((20260850 + index))" \
    --policies pressure_only sticky carbon_affinity \
    > "$GATE/window_0${index}.log" 2>&1 &
  pids+=("$!")
done

for pid in "${pids[@]}"; do
  wait "$pid"
done

GATE="$GATE" .venv/bin/python - <<'PY'
import json
import os
from pathlib import Path

root = Path(os.environ["GATE"])
policies = ("pressure_only", "sticky", "carbon_affinity")
report = {}
for policy in policies:
    rows = [
        json.loads((root / f"window_{index:02d}" / policy / "audit.json").read_text())
        for index in range(4)
    ]
    requests = sum(row["requests"] for row in rows)
    report[policy] = {
        "requests": requests,
        "request_failures": sum(row["request_failures"] for row in rows),
        "fallbacks": sum(row["fallback_decisions"] for row in rows),
        "fallback_rate": sum(row["fallback_decisions"] for row in rows) / requests,
        "ttft_violation_rate": sum(row["ttft_violation_rate"] * row["requests"] for row in rows) / requests,
        "tpot_violation_rate": sum(row["tpot_violation_rate"] * row["requests"] for row in rows) / requests,
        "telemetry_valid": all(row["telemetry_valid"] for row in rows),
    }

ca = report["carbon_affinity"]
passed = (
    all(row["requests"] == 408 for row in report.values())
    and all(row["request_failures"] == 0 for row in report.values())
    and all(row["telemetry_valid"] for row in report.values())
    and ca["fallback_rate"] <= 0.20
    and ca["ttft_violation_rate"] <= 0.10
    and ca["tpot_violation_rate"] <= 0.10
)
(root / "GATE_REPORT.json").write_text(
    json.dumps({"passed": passed, "policies": report}, indent=2)
)
print(json.dumps({"passed": passed, "policies": report}, indent=2))
if not passed:
    raise SystemExit(2)
PY

echo "EXTENDED_PROFILE_GATE_PASS"
.venv/bin/python -u scripts/run_real_campaign.py \
  --output-root "$MAIN" --repetitions 5 --seed 20260860
test -f "$MAIN/REAL_CAMPAIGN_COMPLETE.json"
echo "EXTENDED_REAL_CAMPAIGN_COMPLETE=$MAIN"
