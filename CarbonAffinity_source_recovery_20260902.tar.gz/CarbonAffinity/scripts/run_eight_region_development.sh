#!/usr/bin/env bash
set -euo pipefail

cd /root/CarbonAffinity

PYTHON_BIN="$PWD/.venv/bin/python"
VLLM_BIN="$PWD/.venv/bin/vllm"
MODEL_DIR="/root/models/Qwen3.5-27B"
SERVED_MODEL="Qwen3.5-27B"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="${1:-$PWD/results/eight_region_development_$STAMP}"
PROFILE_IDS=(
  local_region_a local_region_b
  high_reuse_a high_reuse_b
  low_reuse_a low_reuse_b
  burst_a burst_b
)

mkdir -p "$OUTPUT_ROOT/vllm"
printf '%s\n' "$$" > "$OUTPUT_ROOT/supervisor.pid"
printf '%s\n' "$OUTPUT_ROOT" > results/eight_region_development_latest.txt

fatal() {
  printf '%s\n' "$1" | tee "$OUTPUT_ROOT/FATAL"
  exit 1
}

[[ -x "$PYTHON_BIN" ]] || fatal "PYTHON_MISSING=$PYTHON_BIN"
[[ -x "$VLLM_BIN" ]] || fatal "VLLM_MISSING=$VLLM_BIN"
[[ -f "$MODEL_DIR/config.json" ]] || fatal "MODEL_MISSING=$MODEL_DIR"

if ps -eo args= | grep -E \
  '[n]ight_guard.sh|[e]mergency_.*retention|[r]un_local_(pair|multiregion)_campaign.py|[r]un_real_campaign.py|[m]easure_(batch_energy|concurrency).py|[v]llm serve' \
  > "$OUTPUT_ROOT/conflicting_processes.txt"
then
  fatal "CONFLICTING_PROCESS; see $OUTPUT_ROOT/conflicting_processes.txt"
fi

"$PYTHON_BIN" -m py_compile \
  carbonaffinity/config.py \
  scripts/prepare_eight_region_development.py \
  scripts/run_local_multiregion_campaign.py
PYTHONPATH="$PWD" "$PYTHON_BIN" scripts/prepare_eight_region_development.py \
  | tee "$OUTPUT_ROOT/input_preparation.log"
cp results/eight_region_development_inputs/FROZEN_INPUT_MANIFEST.json \
  "$OUTPUT_ROOT/FROZEN_INPUT_MANIFEST.json"
cp results/eight_region_development_inputs/FROZEN_INPUT_MANIFEST.sha256 \
  "$OUTPUT_ROOT/FROZEN_INPUT_MANIFEST.sha256"

server_pids=()
collect_process_tree() {
  local parent="$1"
  local child
  for child in $(pgrep -P "$parent" 2>/dev/null || true); do
    collect_process_tree "$child"
  done
  printf '%s\n' "$parent"
}
cleanup() {
  set +e
  cleanup_pids=()
  for pid in "${server_pids[@]:-}"; do
    if [[ -n "$pid" ]]; then
      while IFS= read -r member; do
        cleanup_pids+=("$member")
      done < <(collect_process_tree "$pid")
    fi
  done
  if [[ "${#cleanup_pids[@]}" -gt 0 ]]; then
    kill -TERM "${cleanup_pids[@]}" 2>/dev/null
    sleep 10
    kill -KILL "${cleanup_pids[@]}" 2>/dev/null
  fi
}
trap cleanup EXIT INT TERM

echo "$(date -Is) STARTING_VLLM_8" | tee "$OUTPUT_ROOT/events.log"
for gpu in $(seq 0 7); do
  port=$((18000 + gpu))
  CUDA_VISIBLE_DEVICES="$gpu" \
  VLLM_USE_FLASHINFER_SAMPLER=0 \
  HF_HUB_OFFLINE=1 \
  TRANSFORMERS_OFFLINE=1 \
  "$VLLM_BIN" serve "$MODEL_DIR" \
    --served-model-name "$SERVED_MODEL" \
    --host 127.0.0.1 \
    --port "$port" \
    --tensor-parallel-size 1 \
    --enable-prefix-caching \
    --enable-prompt-tokens-details \
    --max-model-len 65536 \
    --max-num-seqs 8 \
    --gpu-memory-utilization 0.92 \
    --language-model-only \
    > "$OUTPUT_ROOT/vllm/gpu_${gpu}.log" 2>&1 &
  server_pids[$gpu]="$!"
  echo "${server_pids[$gpu]}" > "$OUTPUT_ROOT/vllm/gpu_${gpu}.pid"
done

deadline=$((SECONDS + 1200))
while true; do
  ready=0
  for port in $(seq 18000 18007); do
    curl -fsS "http://127.0.0.1:${port}/health" >/dev/null 2>&1 \
      && ready=$((ready + 1))
  done
  echo "$(date -Is) VLLM_READY=$ready/8" | tee -a "$OUTPUT_ROOT/events.log"
  [[ "$ready" -eq 8 ]] && break
  [[ "$SECONDS" -lt "$deadline" ]] || fatal "VLLM_STARTUP_TIMEOUT"
  for gpu in $(seq 0 7); do
    kill -0 "${server_pids[$gpu]}" 2>/dev/null \
      || fatal "VLLM_GPU_${gpu}_EXITED"
  done
  sleep 10
done

echo "$(date -Is) PREWARM_START" | tee -a "$OUTPUT_ROOT/events.log"
prewarm_pids=()
for gpu in $(seq 0 7); do
  "$PYTHON_BIN" -u scripts/prewarm_latency_endpoint.py \
    --region-id "${PROFILE_IDS[$gpu]}" \
    --api-base "http://127.0.0.1:$((18000 + gpu))/v1" \
    > "$OUTPUT_ROOT/vllm/gpu_${gpu}.prewarm.log" 2>&1 &
  prewarm_pids[$gpu]="$!"
done
for gpu in $(seq 0 7); do
  wait "${prewarm_pids[$gpu]}" || fatal "PREWARM_GPU_${gpu}_FAILED"
done
echo "$(date -Is) PREWARM_PASS" | tee -a "$OUTPUT_ROOT/events.log"

for rep in $(seq 0 4); do
  mkdir -p "$OUTPUT_ROOT/rep_$(printf '%02d' "$rep")"
  gpu_indices=()
  for logical in $(seq 0 7); do
    gpu_indices+=("$(((logical + rep) % 8))")
  done
  for window in $(seq 0 3); do
    rep_id="$(printf '%02d' "$rep")"
    window_id="$(printf '%02d' "$window")"
    cell="$OUTPUT_ROOT/rep_${rep_id}/window_${window_id}"
    config="configs/eight_region_dev_w${window_id}_r${rep_id}.generated.yaml"
    log="$OUTPUT_ROOT/rep_${rep_id}/window_${window_id}.log"
    echo "$(date -Is) CELL_START rep=$rep window=$window mapping=${gpu_indices[*]}" \
      | tee -a "$OUTPUT_ROOT/events.log"
    PYTHONPATH="$PWD" "$PYTHON_BIN" -u \
      scripts/run_local_multiregion_campaign.py \
      --config "$config" \
      --output-root "$cell" \
      --gpu-indices "${gpu_indices[@]}" \
      --policy-order-seed "$((2026082800 + rep * 10 + window))" \
      --policies pressure_only cleanest_now sticky carbon_affinity \
      > "$log" 2>&1 \
      || fatal "CELL_FAILED rep=$rep window=$window log=$log"
    echo "$(date -Is) CELL_PASS rep=$rep window=$window" \
      | tee -a "$OUTPUT_ROOT/events.log"
  done
  printf '{"repetition":%s,"completed_s":%s}\n' \
    "$rep" "$(date +%s)" > "$OUTPUT_ROOT/rep_$(printf '%02d' "$rep")/REPETITION_COMPLETE.json"
done

policy_markers="$(find "$OUTPUT_ROOT" -name POLICY_COMPLETE.json -type f | wc -l)"
pipeline_markers="$(find "$OUTPUT_ROOT" -name PIPELINE_COMPLETE.json -type f | wc -l)"
[[ "$policy_markers" -eq 80 ]] || fatal "POLICY_COUNT_MISMATCH=$policy_markers"
[[ "$pipeline_markers" -eq 20 ]] || fatal "PIPELINE_COUNT_MISMATCH=$pipeline_markers"
printf '{"status":"COMPLETE","regions":8,"repetitions":5,"windows":4,"policy_runs":80,"completed_s":%s}\n' \
  "$(date +%s)" > "$OUTPUT_ROOT/EXPERIMENT_COMPLETE.json"
echo "EIGHT_REGION_DEVELOPMENT_COMPLETE=$OUTPUT_ROOT"
