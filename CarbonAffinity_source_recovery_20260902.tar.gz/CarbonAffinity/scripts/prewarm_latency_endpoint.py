from __future__ import annotations

import argparse
import asyncio

from carbonaffinity.materialize import PromptMaterializer
from carbonaffinity.models import RequestSpec
from carbonaffinity.region import RegionClient


async def prewarm(args: argparse.Namespace) -> None:
    materializer = PromptMaterializer(args.tokenizer)
    client = RegionClient({
        "id": args.region_id,
        "api_base": args.api_base,
        "api_key": "EMPTY",
        "model": args.model,
        "admission_concurrency": 1,
    }, args.timeout_s)
    raw = {
        "request_id": f"prewarm-{args.region_id}",
        "session_id": f"prewarm-{args.region_id}",
        "prompt_tokens": args.prompt_tokens,
        "shared_prefix_tokens": 0,
    }
    prompt = materializer.tokens(raw)
    try:
        if not await client.reset_prefix_cache():
            raise RuntimeError("prefix-cache reset before warmup failed")
        for index in range(args.requests):
            request = RequestSpec(
                request_id=f"prewarm-{args.region_id}-{index}",
                arrival_ms=0,
                prompt_tokens=args.prompt_tokens,
                max_output_tokens=args.output_tokens,
                session_id=f"prewarm-{args.region_id}-{index}",
            )
            result = await client.complete(request, prompt)
            if not result.success:
                raise RuntimeError(f"warmup request failed: {result.error}")
            print(
                f"PREWARM_REQUEST region={args.region_id} index={index} "
                f"ttft_ms={result.ttft_ms} tpot_ms={result.tpot_ms}",
                flush=True,
            )
        if not await client.reset_prefix_cache():
            raise RuntimeError("prefix-cache reset after warmup failed")
    finally:
        await client.close()
    print(f"LATENCY_ENDPOINT_PREWARM_PASS={args.region_id}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--model", default="Qwen3.5-27B")
    parser.add_argument("--tokenizer", default="/root/models/Qwen3.5-27B")
    parser.add_argument("--requests", type=int, default=2)
    parser.add_argument("--prompt-tokens", type=int, default=2048)
    parser.add_argument("--output-tokens", type=int, default=16)
    parser.add_argument("--timeout-s", type=float, default=900)
    asyncio.run(prewarm(parser.parse_args()))


if __name__ == "__main__":
    main()
