from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

from carbonaffinity.config import load_config, resolve_path
from carbonaffinity.replay import run_replay


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one two-region CarbonAffinity replay")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--trace", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--policy", choices=[
        "carbon_affinity", "cleanest_now", "sticky", "pressure_only",
        "cedar_like", "oracle_historical", "round_robin",
    ])
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)
    trace = args.trace or resolve_path(config, config["experiment"]["trace"])
    asyncio.run(run_replay(config, trace.resolve(), args.output.resolve(), args.policy, args.resume))


if __name__ == "__main__":
    main()
