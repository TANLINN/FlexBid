from __future__ import annotations

import argparse
import json
import os
import re
import signal
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

RUN_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$")


class AgentState:
    def __init__(self, root: Path, region_id: str, gpu_index: int, token: str, manifest: Path):
        self.root = root
        self.region_id = region_id
        self.gpu_index = gpu_index
        self.token = token
        self.manifest = json.loads(manifest.read_text(encoding="utf-8"))
        self.process: subprocess.Popen | None = None
        self.run_id: str | None = None
        self.lock = threading.Lock()

    def output(self, run_id: str) -> Path:
        if not RUN_ID.fullmatch(run_id):
            raise ValueError("invalid run_id")
        return self.root / f"{run_id}.csv"

    def start(self, run_id: str, interval_ms: int) -> dict:
        if interval_ms < 20:
            raise ValueError("interval_ms must be at least 20")
        with self.lock:
            if self.process and self.process.poll() is None:
                raise RuntimeError(f"telemetry already running for {self.run_id}")
            output = self.output(run_id)
            output.parent.mkdir(parents=True, exist_ok=True)
            if output.exists():
                raise FileExistsError(f"telemetry output exists: {output}")
            self.process = subprocess.Popen([
                sys.executable, "-m", "carbonaffinity.telemetry",
                "--output", str(output), "--gpu-index", str(self.gpu_index),
                "--region-id", self.region_id, "--interval-ms", str(interval_ms),
            ], cwd=self.root.parent, start_new_session=True)
            self.run_id = run_id
            return {"pid": self.process.pid, "run_id": run_id, "output": str(output)}

    def stop(self) -> dict:
        with self.lock:
            if not self.process:
                return {"stopped": False, "reason": "not running"}
            process, run_id = self.process, self.run_id
            if process.poll() is None:
                if os.name == "posix":
                    os.killpg(process.pid, signal.SIGTERM)
                else:
                    process.terminate()
                process.wait(timeout=30)
            return_code = process.returncode
            self.process = None
            self.run_id = None
            return {"stopped": True, "run_id": run_id, "return_code": return_code}


def handler_factory(state: AgentState):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, format_string, *args) -> None:
            sys.stderr.write((format_string % args) + "\n")

        def _authorized(self) -> bool:
            return self.headers.get("Authorization") == f"Bearer {state.token}"

        def _json(self, status: int, payload: dict) -> None:
            body = json.dumps(payload).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> dict:
            length = int(self.headers.get("Content-Length", "0"))
            return json.loads(self.rfile.read(length) or b"{}")

        def do_GET(self) -> None:
            if not self._authorized():
                self._json(401, {"error": "unauthorized"})
                return
            path = urlparse(self.path).path
            if path == "/status":
                running = state.process is not None and state.process.poll() is None
                self._json(200, {"region_id": state.region_id, "running": running, "run_id": state.run_id, "manifest": state.manifest})
                return
            if path.startswith("/telemetry/"):
                name = path.removeprefix("/telemetry/")
                metadata = name.endswith(".metadata.json")
                run_id = name[:-14] if metadata else (name[:-4] if name.endswith(".csv") else "")
                try:
                    target = state.output(run_id).with_suffix(".metadata.json") if metadata else state.output(run_id)
                except ValueError as exc:
                    self._json(400, {"error": str(exc)})
                    return
                if not target.is_file():
                    self._json(404, {"error": "not found"})
                    return
                body = target.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/json" if metadata else "text/csv")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            self._json(404, {"error": "not found"})

        def do_POST(self) -> None:
            if not self._authorized():
                self._json(401, {"error": "unauthorized"})
                return
            try:
                if self.path == "/telemetry/start":
                    body = self._body()
                    self._json(200, state.start(str(body["run_id"]), int(body.get("interval_ms", 100))))
                elif self.path == "/telemetry/stop":
                    self._json(200, state.stop())
                else:
                    self._json(404, {"error": "not found"})
            except (KeyError, ValueError, RuntimeError, FileExistsError) as exc:
                self._json(409, {"error": f"{type(exc).__name__}: {exc}"})

    return Handler


def main() -> None:
    parser = argparse.ArgumentParser(description="Local-only CarbonAffinity regional control sidecar")
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=19000)
    parser.add_argument("--token", default=os.environ.get("CARBONAFFINITY_CONTROL_TOKEN"))
    args = parser.parse_args()
    if not args.token or len(args.token) < 16:
        parser.error("a control token of at least 16 characters is required")
    state = AgentState(args.output_root.resolve(), args.region_id, args.gpu_index, args.token, args.manifest)
    server = ThreadingHTTPServer((args.host, args.port), handler_factory(state))
    try:
        server.serve_forever()
    finally:
        state.stop()
        server.server_close()


if __name__ == "__main__":
    main()

