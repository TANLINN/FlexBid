"""Heldout-only collector: uses the same request mechanics, with a fixed new grid."""
import argparse
import asyncio
from pathlib import Path

from scripts.measure_latency_residual import collect
from scripts.residual_latency_validation import VERSION, cases


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu-index", type=int, required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-evidence", required=True)
    args = parser.parse_args()
    from carbonaffinity.materialize import PromptMaterializer
    from carbonaffinity.region import RegionClient

    async def run():
        client = RegionClient({"id": f"gpu_{args.gpu_index}", "api_base": args.api_base,
                               "model": args.model, "admission_concurrency": 8}, 300)
        try:
            await collect(args, PromptMaterializer(args.tokenizer), client, case_grid=cases(), protocol=VERSION)
        finally:
            await client.close()
    asyncio.run(run())


if __name__ == "__main__":
    main()
