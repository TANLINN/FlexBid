from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import statistics
import subprocess
import sys
import time
from pathlib import Path


def command(args: list[str]) -> dict:
    try:
        result = subprocess.run(args, text=True, capture_output=True)
    except OSError as exc:
        return {
            "command": args,
            "return_code": 127,
            "stdout": "",
            "stderr": f"{type(exc).__name__}: {exc}",
        }
    return {
        "command": args,
        "return_code": result.returncode,
        "stdout": result.stdout.strip(),
        "stderr": result.stderr.strip(),
    }


def mem_total_gib() -> float:
    for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
        if line.startswith("MemTotal:"):
            return int(line.split()[1]) / 1024**2
    raise RuntimeError("MemTotal not found")


def first_csv_number(result: dict, column: int = 0) -> float | None:
    if result.get("return_code") != 0 or not result.get("stdout"):
        return None
    try:
        return float(result["stdout"].splitlines()[0].split(",")[column].strip())
    except (ValueError, IndexError):
        return None


def torch_probe(gpu_index: int) -> dict:
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("torch.cuda.is_available() is false")
    torch.cuda.set_device(gpu_index)
    properties = torch.cuda.get_device_properties(gpu_index)
    free_bytes, total_bytes = torch.cuda.mem_get_info(gpu_index)
    bf16 = bool(torch.cuda.is_bf16_supported())
    dtype = torch.bfloat16 if bf16 else torch.float16

    matrix_n = 8192
    left = torch.randn((matrix_n, matrix_n), device="cuda", dtype=dtype)
    right = torch.randn((matrix_n, matrix_n), device="cuda", dtype=dtype)
    for _ in range(3):
        torch.mm(left, right)
    torch.cuda.synchronize()
    matmul_ms = []
    for _ in range(7):
        start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        start.record()
        torch.mm(left, right)
        end.record()
        end.synchronize()
        matmul_ms.append(start.elapsed_time(end))
    median_matmul_ms = statistics.median(matmul_ms)
    matmul_tflops = 2 * matrix_n**3 / (median_matmul_ms / 1000.0) / 1e12

    copy_bytes = 512 * 1024**2
    source = torch.empty(copy_bytes // 2, device="cuda", dtype=torch.float16)
    target = torch.empty_like(source)
    copy_ms = []
    for _ in range(10):
        start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
        start.record()
        target.copy_(source)
        end.record()
        end.synchronize()
        copy_ms.append(start.elapsed_time(end))
    median_copy_ms = statistics.median(copy_ms)
    copy_bandwidth_gbps = 2 * copy_bytes / (median_copy_ms / 1000.0) / 1e9
    del left, right, source, target
    torch.cuda.empty_cache()

    return {
        "torch_version": torch.__version__,
        "cuda_runtime": torch.version.cuda,
        "gpu_name": properties.name,
        "compute_capability": [properties.major, properties.minor],
        "total_vram_gib": total_bytes / 2**30,
        "free_vram_gib": free_bytes / 2**30,
        "bf16_supported": bf16,
        "benchmark_dtype": str(dtype),
        "matmul_n": matrix_n,
        "matmul_median_ms": median_matmul_ms,
        "matmul_effective_tflops": matmul_tflops,
        "device_copy_median_ms": median_copy_ms,
        "device_copy_effective_gbps_read_plus_write": copy_bandwidth_gbps,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Probe an A800 before downloading an LLM")
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--workdir", type=Path, default=Path("/root"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--target-model",
        choices=("qwen35_27b", "smoke_only"),
        default="qwen35_27b",
        help="Use smoke_only only for a non-paper software-path check with a smaller model.",
    )
    parser.add_argument(
        "--allow-missing-vllm",
        action="store_true",
        help="Qualify hardware before runtime installation; vLLM remains reported as not ready.",
    )
    args = parser.parse_args()
    disk = shutil.disk_usage(args.workdir)
    gpu_query = command([
        "nvidia-smi", "-i", str(args.gpu_index),
        "--query-gpu=index,name,uuid,memory.total,driver_version,pstate,clocks.current.sm,clocks.max.sm,power.draw,power.limit,power.default_limit,power.min_limit,power.max_limit",
        "--format=csv,noheader,nounits",
    ])
    processes = command([
        "nvidia-smi", "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
        "--format=csv,noheader,nounits",
    ])
    torch_result = None
    torch_error = None
    try:
        torch_result = torch_probe(args.gpu_index)
    except Exception as exc:
        torch_error = f"{type(exc).__name__}: {exc}"
    telemetry_query = command([
        "nvidia-smi", "-i", str(args.gpu_index),
        "--query-gpu=power.draw,utilization.gpu,memory.used,temperature.gpu",
        "--format=csv,noheader,nounits",
    ])
    power_draw_w = first_csv_number(telemetry_query)
    energy_query = command([
        "nvidia-smi", "-i", str(args.gpu_index),
        "--query-gpu=total_energy_consumption",
        "--format=csv,noheader,nounits",
    ])
    total_energy_mj = first_csv_number(energy_query)
    host_ram_gib = mem_total_gib()
    vllm = command(["vllm", "--version"]) if shutil.which("vllm") else None
    common_checks = {
        "nvidia_smi_ok": gpu_query["return_code"] == 0,
        "a800_detected": "A800" in gpu_query["stdout"],
        "torch_cuda_probe_ok": torch_result is not None,
        "bf16_supported": bool(torch_result and torch_result["bf16_supported"]),
        "vllm_available": bool(vllm and vllm["return_code"] == 0),
        "energy_telemetry_readable": (
            (power_draw_w is not None and power_draw_w >= 0)
            or (total_energy_mj is not None and total_energy_mj >= 0)
        ),
        "no_existing_compute_process": not processes["stdout"].strip(),
    }
    target_checks = {
        "qwen35_27b": {
            "vram_at_least_75_gib": bool(torch_result and torch_result["total_vram_gib"] >= 75),
            "free_vram_at_least_70_gib": bool(torch_result and torch_result["free_vram_gib"] >= 70),
            "host_ram_at_least_64_gib": host_ram_gib >= 64,
            "disk_free_at_least_100_gib": disk.free / 2**30 >= 100,
        },
        "smoke_only": {
            "vram_at_least_20_gib": bool(torch_result and torch_result["total_vram_gib"] >= 20),
            "free_vram_at_least_16_gib": bool(torch_result and torch_result["free_vram_gib"] >= 16),
            "host_ram_at_least_32_gib": host_ram_gib >= 32,
            "disk_free_at_least_50_gib": disk.free / 2**30 >= 50,
        },
    }[args.target_model]
    checks = {**common_checks, **target_checks}
    hardware_checks = {key: value for key, value in checks.items() if key != "vllm_available"}
    hardware_candidate = all(hardware_checks.values())
    runtime_candidate = all(checks.values())
    recommendations = {
        "host_ram_at_least_96_gib": host_ram_gib >= 96,
        "disk_free_at_least_150_gib": disk.free / 2**30 >= 150,
    }
    report = {
        "schema_version": 1,
        "target_model": args.target_model,
        "timestamp_s": time.time(),
        "hostname": platform.node(),
        "platform": platform.platform(),
        "python": sys.version,
        "cpu_count": os.cpu_count(),
        "host_ram_gib": host_ram_gib,
        "disk_total_gib": disk.total / 2**30,
        "disk_free_gib": disk.free / 2**30,
        "nvidia_smi": gpu_query,
        "telemetry_query": telemetry_query,
        "power_draw_w": power_draw_w,
        "energy_counter_query": energy_query,
        "total_energy_mj": total_energy_mj,
        "telemetry_capabilities": {
            "instantaneous_power_readable": power_draw_w is not None and power_draw_w >= 0,
            "total_energy_counter_readable": total_energy_mj is not None and total_energy_mj >= 0,
        },
        "compute_processes": processes,
        "vllm": vllm,
        "torch_probe": torch_result,
        "torch_probe_error": torch_error,
        "qwen35_27b_memory_estimate": {
            "nominal_bf16_weights_gib": 27_000_000_000 * 2 / 2**30,
            "warning": (
                "Nominal weights exclude CUDA graphs, activations, allocator fragmentation, "
                "vLLM engine buffers, and KV cache; only a real vLLM startup proves fit."
            ),
        },
        "hard_checks": checks,
        "hardware_candidate": hardware_candidate,
        "runtime_candidate": runtime_candidate,
        "recommendations": recommendations,
        "candidate": hardware_candidate if args.allow_missing_vllm else runtime_candidate,
        "qualification_mode": "hardware" if args.allow_missing_vllm else "hardware_and_runtime",
        "qwen35_27b_bf16_candidate": args.target_model == "qwen35_27b" and hardware_candidate,
        "note": (
            "Throughput is recorded for cross-server comparison, not used as a universal pass/fail threshold. "
            "A smoke_only pass does not qualify the machine or its results for the paper's Qwen3.5-27B experiments. "
            "hardware_candidate may be true while runtime_candidate is false when vLLM is not installed."
        ),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["candidate"] else 2)


if __name__ == "__main__":
    main()
