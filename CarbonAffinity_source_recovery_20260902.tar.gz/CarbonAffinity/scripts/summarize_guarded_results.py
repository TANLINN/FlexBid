from __future__ import annotations

import argparse
import csv
import json
import statistics
from datetime import datetime
from pathlib import Path

from carbonaffinity.carbon import CarbonTrace, carbon_grams
from carbonaffinity.config import load_config, resolve_path


WORKLOADS = ("high_reuse", "low_reuse", "burst")


def dynamic_metrics(policy_dir: Path, config_path: Path, audit: dict) -> dict:
    config = load_config(config_path)
    carbon = CarbonTrace.from_csv(
        resolve_path(config, config["carbon"]["trace"]),
        float(config["carbon"].get("max_age_s", 1800)),
    )
    start_ns, end_ns = audit["measurement_window_wall_time_ns"]
    anchor = audit["carbon_time_anchor"]
    anchor_ns = int(anchor["wall_time_ns"])
    anchor_carbon_s = float(anchor["carbon_timestamp_s"])
    energy_j = 0.0
    carbon_g = 0.0
    idle_by_region: dict[str, float] = {}
    for region_summary in audit["telemetry"]:
        region = region_summary["region_id"]
        path = policy_dir / f"{region}_gpu.csv"
        with path.open(newline="", encoding="utf-8-sig") as handle:
            rows = list(csv.DictReader(handle))
        idle_samples = [
            float(row["power_w"])
            for row in rows
            if row.get("wall_time_ns") and row.get("power_w")
            and not start_ns <= int(row["wall_time_ns"]) <= end_ns
        ]
        idle_w = statistics.median(idle_samples) if idle_samples else 0.0
        idle_by_region[region] = idle_w
        usable = [
            row for row in rows
            if row.get("wall_time_ns")
            and (row.get("power_w") or row.get("total_energy_mj"))
        ]
        for left, right in zip(usable, usable[1:]):
            left_ns = int(left["wall_time_ns"])
            right_ns = int(right["wall_time_ns"])
            midpoint_ns = (left_ns + right_ns) // 2
            if not start_ns <= midpoint_ns <= end_ns:
                continue
            duration_s = max(0.0, (right_ns - left_ns) / 1e9)
            left_counter = left.get("total_energy_mj")
            right_counter = right.get("total_energy_mj")
            if (
                left_counter and right_counter
                and float(right_counter) >= float(left_counter)
            ):
                interval_j = (float(right_counter) - float(left_counter)) / 1000.0
            elif left.get("power_w") and right.get("power_w"):
                interval_j = duration_s * (
                    float(left["power_w"]) + float(right["power_w"])
                ) / 2.0
            else:
                continue
            dynamic_j = max(0.0, interval_j - idle_w * duration_s)
            carbon_time_s = anchor_carbon_s + (midpoint_ns - anchor_ns) / 1e9
            intensity = carbon.at(region, carbon_time_s).historical_lbs_per_mwh
            if intensity is None:
                continue
            energy_j += dynamic_j
            carbon_g += carbon_grams(dynamic_j, intensity)
    return {
        "dynamic_energy_j": energy_j,
        "dynamic_carbon_g": carbon_g,
        "idle_power_w": idle_by_region,
        "duration_s": (end_ns - start_ns) / 1e9,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--config-root", type=Path, default=Path("configs"))
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result: dict[str, dict] = {}
    for workload in WORKLOADS:
        policies = []
        directory = args.root / workload
        for policy_dir in sorted(path for path in directory.iterdir() if path.is_dir()):
            audit_path = policy_dir / "audit.json"
            requests_path = policy_dir / "requests.jsonl"
            if not audit_path.exists() or not requests_path.exists():
                continue
            audit = json.loads(audit_path.read_text())
            rows = [
                json.loads(line) for line in requests_path.read_text().splitlines()
                if line.strip()
            ]
            dynamic = dynamic_metrics(
                policy_dir,
                args.config_root / f"local_{workload}.generated.yaml",
                audit,
            )
            observed_hits = sum(
                int(row["completion"].get("cached_prompt_tokens_observed") or 0)
                for row in rows
            )
            predicted_hits = sum(
                int(next(
                    candidate for candidate in row["decision"]["candidates"]
                    if candidate["region_id"] == row["decision"]["selected_region"]
                )["cached_tokens"])
                for row in rows
            )
            policies.append({
                "policy": policy_dir.name,
                **dynamic,
                "total_energy_j": audit["measured_gpu_energy_j"],
                "total_carbon_g": audit["measured_operational_carbon_g"],
                "ttft_violation_rate": audit["ttft_violation_rate"],
                "tpot_violation_rate": audit["tpot_violation_rate"],
                "migrations": audit["migrations"],
                "fallbacks": audit["fallback_decisions"],
                "cache_observed_tokens": observed_hits,
                "cache_predicted_tokens": predicted_hits,
                "cache_prediction_mae_tokens": audit["cache_prediction_mae_tokens"],
                "cache_hit_classification_accuracy": audit["cache_hit_classification_accuracy"],
            })
        reference = next(
            row["dynamic_carbon_g"] for row in policies
            if row["policy"] == "pressure_only"
        )
        for row in policies:
            row["dynamic_saving_vs_pressure_pct"] = (
                100.0 * (reference - row["dynamic_carbon_g"]) / reference
            )
        result[workload] = {"policies": policies}
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    for workload, payload in result.items():
        print("\n" + "=" * 150)
        print(workload.upper())
        print("=" * 150)
        print(
            f"{'policy':20s}{'dyn_C':>11s}{'save_%':>10s}{'dyn_E':>11s}"
            f"{'total_C':>11s}{'duration':>10s}{'obs_hit':>11s}"
            f"{'pred_hit':>11s}{'cache_MAE':>11s}{'cache_acc':>11s}"
        )
        for row in payload["policies"]:
            print(
                f"{row['policy']:20s}{row['dynamic_carbon_g']:11.6f}"
                f"{row['dynamic_saving_vs_pressure_pct']:10.2f}"
                f"{row['dynamic_energy_j']:11.1f}{row['total_carbon_g']:11.6f}"
                f"{row['duration_s']:10.1f}{row['cache_observed_tokens']:11d}"
                f"{row['cache_predicted_tokens']:11d}"
                f"{(row['cache_prediction_mae_tokens'] or 0):11.1f}"
                f"{(row['cache_hit_classification_accuracy'] or 0):11.3f}"
            )
    print("\nDYNAMIC_AND_CACHE_SUMMARY_COMPLETE")


if __name__ == "__main__":
    main()
