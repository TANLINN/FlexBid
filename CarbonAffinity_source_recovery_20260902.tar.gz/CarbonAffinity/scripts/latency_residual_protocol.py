"""Preregistered development design, not a fitted/validated latency model."""
import itertools
import math

VERSION = "residual-latency-development-v1"
GPUS = tuple(range(8))
BLOCK = 784
CACHED_CONTEXTS = (1568, 7840, 31360)
RESIDUALS = (32, 384, 768)
CONCURRENCIES = (1, 4, 8)
REPEATS = 2
OUTPUT = 64


def cases():
    result = []
    for cached, residual, concurrency, mode, repeat in itertools.product(
            CACHED_CONTEXTS, RESIDUALS, CONCURRENCIES, ("cold", "warm"), range(REPEATS)):
        result.append({"case_id": f"c{cached}_u{residual}_n{concurrency}_{mode}_r{repeat}",
                       "cached_context_target": cached, "residual_target": residual,
                       "prompt_tokens": cached + residual, "concurrency": concurrency,
                       "mode": mode, "repeat": repeat, "output_tokens": OUTPUT})
    return result


def design():
    return {"protocol": VERSION, "gpu_indices": list(GPUS), "block_tokens_assumption": BLOCK,
            "cached_context_targets": list(CACHED_CONTEXTS), "residual_targets": list(RESIDUALS),
            "concurrency": list(CONCURRENCIES), "repeats": REPEATS, "output_tokens": OUTPUT,
            "rows_per_gpu": len(cases()), "expected_rows": len(cases()) * len(GPUS),
            "candidate_frozen": False, "model_fitting_in_this_run": False,
            "warm_cache_rule": "positive observed cache equals target on every request; no hit-ratio threshold",
            "cold_cache_rule": "fresh per-request namespace, reject positive cache; null remains unknown",
            "remaining_tokens_rule": "actual prompt minus observed cache; unknown stays null",
            "post_prewarm_autotuning_rule": "retain all rows; any new tuning event fails development-readiness",
            "scope": "homogeneous simultaneous batches, output64, no mixed arrival or SLO guarantee",
            "case_order": "cached_context,residual,concurrency,mode,repeat; identical on each GPU"}


def result_checks(result, prompt, output, expected_cache=None):
    cached = result.get("cached_prompt_tokens_observed")
    checks = {"success": result.get("success") is True and result.get("status_code") == 200,
              "prompt_tokens": result.get("prompt_tokens_reported") == prompt,
              "output_tokens": result.get("output_tokens") == output}
    if expected_cache is not None:
        checks["observed_warm_cache_exact"] = type(cached) is int and cached == expected_cache
    else:
        checks["cold_no_observed_positive_cache"] = cached is None or (type(cached) is int and cached == 0)
    for metric in ("ttft_ms",):
        value = result.get(metric)
        checks[metric + "_finite"] = isinstance(value, (int, float)) and math.isfinite(value) and value >= 0
    if output > 1:
        value = result.get("tpot_ms")
        checks["tpot_ms_finite"] = isinstance(value, (int, float)) and math.isfinite(value) and value >= 0
    return checks


def features(result):
    prompt, cached = result.get("prompt_tokens_reported"), result.get("cached_prompt_tokens_observed")
    if type(prompt) is not int or type(cached) is not int or not 0 <= cached <= prompt:
        return {"observed_cached_tokens": cached, "observed_uncached_tokens": None}
    return {"observed_cached_tokens": cached, "observed_uncached_tokens": prompt - cached}
