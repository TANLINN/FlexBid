"""One-paste immutable source bundle; no overwrite of server project code."""
import argparse
import base64
import gzip
import hashlib
import json
import shlex
import textwrap
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
FILES = ("scripts/latency_residual_protocol.py", "scripts/measure_latency_residual.py",
         "scripts/audit_latency_residual.py", "scripts/run_latency_residual_campaign.py",
         "scripts/latency_shape_probe_support.py", "tests/test_latency_residual.py")
DEPENDENCIES = tuple("carbonaffinity/" + name + ".py" for name in
                     ("models", "region", "network", "materialize", "artifacts"))


def build_payload():
    files = {p: (PROJECT / p).read_text(encoding="utf-8").replace("\r\n", "\n") for p in FILES}
    files.update({"scripts/__init__.py": "", "tests/__init__.py": ""})
    for name, code in files.items():
        compile(code, name, "exec")
    dependencies = {p: hashlib.sha256((PROJECT / p).read_text(encoding="utf-8").encode()).hexdigest()
                    for p in DEPENDENCIES}
    payload = {"files": files, "required_core_lf_sha256": dependencies,
               "scope": "new standalone development bundle; never overwrite core code/models/results"}
    return gzip.compress(json.dumps(payload, ensure_ascii=True, sort_keys=True).encode(), mtime=0)


INSTALLER = '''import base64,gzip,hashlib,json,sys
from pathlib import Path
compressed=base64.b64decode("".join(sys.stdin.read().split()),validate=True)
if hashlib.sha256(compressed).hexdigest()!=sys.argv[1]:
    raise SystemExit("TRANSFER_CHECKSUM_FAILED_NOT_INSTALLED")
payload=json.loads(gzip.decompress(compressed))
project=Path(sys.argv[2]).resolve()
for name,expected in payload["required_core_lf_sha256"].items():
    path=project/name
    if not path.is_file() or hashlib.sha256(path.read_text(encoding="utf-8").encode()).hexdigest()!=expected:
        raise SystemExit("CORE_VERSION_MISMATCH_NOT_STARTED: "+name)
destination=project/"results"/("residual_latency_transfer_"+sys.argv[1][:16])
if destination.is_symlink():
    raise SystemExit("SYMLINK_DESTINATION_REJECTED")
files=payload["files"]
for name,code in files.items():
    relative=Path(name)
    if relative.is_absolute() or ".." in relative.parts or relative.parts[0] not in ("scripts","tests"):
        raise SystemExit("UNSAFE_SOURCE_PATH")
    compile(code,name,"exec")
    target=destination/relative
    if target.parent.is_symlink() or target.is_symlink():
        raise SystemExit("SYMLINK_SOURCE_REJECTED")
    if target.exists() and target.read_bytes()!=code.encode():
        raise SystemExit("EXISTING_SOURCE_DIFFERS_NOT_OVERWRITTEN: "+name)
destination.mkdir(parents=True,exist_ok=True)
for name,code in files.items():
    target=destination/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        with target.open("xb") as handle:
            handle.write(code.encode())
    if target.read_bytes()!=code.encode():
        raise SystemExit("INSTALLED_SOURCE_CHECK_FAILED: "+name)
manifest=destination/"TRANSFER_MANIFEST.json"
record=json.dumps({"payload_sha256":sys.argv[1],"required_core_lf_sha256":payload["required_core_lf_sha256"],
    "files_sha256":{name:hashlib.sha256(code.encode()).hexdigest() for name,code in files.items()}},indent=2)+"\\n"
if manifest.exists() and manifest.read_text()!=record:
    raise SystemExit("EXISTING_MANIFEST_DIFFERS")
if not manifest.exists():
    with manifest.open("x",encoding="utf-8") as handle:
        handle.write(record)
print(destination)
'''


def command(payload):
    digest = hashlib.sha256(payload).hexdigest()
    encoded = "\n".join(textwrap.wrap(base64.b64encode(payload).decode(), 100))
    install = "/root/CarbonAffinity/.venv/bin/python -c " + shlex.quote(INSTALLER)
    return f'''if RESIDUAL_BUNDLE="$({install} {digest} /root/CarbonAffinity <<'RESIDUAL_BUNDLE_EOF'
{encoded}
RESIDUAL_BUNDLE_EOF
)"; then
    if (cd "$RESIDUAL_BUNDLE" && PYTHONPATH="$RESIDUAL_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -m unittest tests.test_latency_residual -v); then
        RUN="/root/CarbonAffinity/results/latency_residual_dev_$(date -u +%Y%m%dT%H%M%SZ)"
        nohup env PYTHONPATH="$RESIDUAL_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -u "$RESIDUAL_BUNDLE/scripts/run_latency_residual_campaign.py" --project-root /root/CarbonAffinity --model-dir /root/models/Qwen3.5-27B --output-root "$RUN" > "${{RUN}}.launcher.log" 2>&1 < /dev/null &
        echo "PID=$! ROOT=$RUN"
        echo "RESIDUAL_DEVELOPMENT_SUBMITTED_EXPECTED_ROWS=864"
    else
        echo "RESIDUAL_BUNDLE_TEST_FAILED_NOT_STARTED"
    fi
else
    echo "RESIDUAL_BUNDLE_INSTALL_FAILED_NOT_STARTED"
fi
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    payload = build_payload()
    if args.metadata:
        print(json.dumps({"sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload),
                          "files": list(FILES), "expected_rows": 864}))
    else:
        print(command(payload), end="")


if __name__ == "__main__":
    main()
