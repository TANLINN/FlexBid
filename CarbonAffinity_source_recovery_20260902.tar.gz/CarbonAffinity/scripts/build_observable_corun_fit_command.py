"""Plain source transfer + CPU-only fit. No GPU launch or runtime installation."""
import argparse
import hashlib
import shlex
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
SOURCE = "/root/CarbonAffinity/results/observable_corun_development_v1_20260830T123817997849695Z"
NAMES = ("scripts/observable_corun_candidate.py", "scripts/fit_observable_corun_candidate.py",
         "tests/test_observable_corun_candidate.py")
SEPARATOR = "\n# === OBSERVABLE_CORUN_FIT_NEXT_SOURCE ===\n"
INSTALLER = '''import hashlib,json,sys
from pathlib import Path
project=Path('/root/CarbonAffinity')
raw=sys.stdin.buffer.read()
digest=hashlib.sha256(raw).hexdigest()
if digest!=sys.argv[1]:
    raise SystemExit('SOURCE_CHECKSUM_FAILED_NOT_INSTALLED')
base=project/'results/observable_corun_development_transfer_1174f944b0eda2af'
manifest=json.loads((base/'DEVELOPMENT_TRANSFER_MANIFEST.json').read_text())
if manifest['source_payload_sha256']!='1174f944b0eda2af84491c5d531f73ffbcddc9d76d19c9db85c0ecd18d75f2ca':
    raise SystemExit('DEVELOPMENT_BASE_BUNDLE_MISMATCH')
def safe(name,folders=('scripts','tests')):
    p=Path(name)
    if p.is_absolute() or '..' in p.parts or not p.parts or p.parts[0] not in folders:
        raise SystemExit('UNSAFE_SOURCE_PATH')
    return p
files={}
for name,expected in manifest['files_sha256'].items():
    data=(base/safe(name)).read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected:
        raise SystemExit('BASE_SOURCE_CHANGED: '+name)
    files[name]=data
for name,expected in manifest['required_core_lf_sha256'].items():
    p=project/safe(name,('carbonaffinity',))
    if hashlib.sha256(p.read_text(encoding='utf-8').encode()).hexdigest()!=expected:
        raise SystemExit('CORE_SOURCE_CHANGED: '+name)
names=('scripts/observable_corun_candidate.py','scripts/fit_observable_corun_candidate.py',
       'tests/test_observable_corun_candidate.py')
parts=raw.decode('utf-8').split('\\n# === OBSERVABLE_CORUN_FIT_NEXT_SOURCE ===\\n')
if len(parts)!=len(names):
    raise SystemExit('SOURCE_BOUNDARY_INVALID')
for name,source in zip(names,parts):
    if name in files:
        raise SystemExit('UNEXPECTED_SOURCE_COLLISION')
    files[name]=source.encode()
destination=project/'results'/('observable_corun_fit_transfer_'+digest[:16])
if destination.is_symlink():
    raise SystemExit('SYMLINK_DESTINATION_REJECTED')
for name,data in files.items():
    relative=safe(name)
    compile(data,name,'exec')
    target=destination/relative
    if target.is_symlink() or target.parent.is_symlink():
        raise SystemExit('SYMLINK_SOURCE_REJECTED')
    if target.exists() and target.read_bytes()!=data:
        raise SystemExit('EXISTING_SOURCE_DIFFERS: '+name)
record=dict(source_payload_sha256=digest,base_payload_sha256=manifest['source_payload_sha256'],
    files_sha256={n:hashlib.sha256(d).hexdigest() for n,d in files.items()},
    required_core_lf_sha256=manifest['required_core_lf_sha256'],
    scope='CPU DEVELOPMENT fit only; no independent validation, GPU launch, freeze or runtime installation')
record_bytes=(json.dumps(record,sort_keys=True,indent=2)+'\\n').encode()
record_path=destination/'CORUN_FIT_TRANSFER_MANIFEST.json'
if record_path.is_symlink() or (record_path.exists() and record_path.read_bytes()!=record_bytes):
    raise SystemExit('EXISTING_MANIFEST_DIFFERS')
for name,data in files.items():
    target=destination/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if not target.exists():
        with target.open('xb') as handle:
            handle.write(data)
    if target.read_bytes()!=data:
        raise SystemExit('INSTALLED_HASH_MISMATCH')
if not record_path.exists():
    with record_path.open('xb') as handle:
        handle.write(record_bytes)
print(destination)
'''


def payload():
    parts = [PROJECT.joinpath(n).read_text(encoding="utf-8") for n in NAMES]
    for name, source in zip(NAMES, parts):
        if SEPARATOR in source or "\nOBSERVABLE_CORUN_FIT_SOURCE_EOF\n" in source:
            raise ValueError("delimiter collision")
        compile(source, name, "exec")
    return SEPARATOR.join(parts).encode()


def command():
    raw = payload()
    digest = hashlib.sha256(raw).hexdigest()
    return f'''cd /root/CarbonAffinity
if FIT_BUNDLE="$(/root/CarbonAffinity/.venv/bin/python -c {shlex.quote(INSTALLER)} {digest} <<'OBSERVABLE_CORUN_FIT_SOURCE_EOF'
{raw.decode()}OBSERVABLE_CORUN_FIT_SOURCE_EOF
)"; then
    if (cd "$FIT_BUNDLE" && PYTHONPATH="$FIT_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -m unittest tests.test_latency_residual tests.test_corun_observable_pilot tests.test_corun_observable_development tests.test_observable_corun_candidate -q); then
        CORUN_DEV={shlex.quote(SOURCE)}
        FIT="/root/CarbonAffinity/results/observable_corun_candidate_v1_$(date -u +%Y%m%dT%H%M%S%NZ)"
        if (cd "$FIT_BUNDLE" && PYTHONPATH="$FIT_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -u -m scripts.fit_observable_corun_candidate --input-root "$CORUN_DEV" --output-root "$FIT"); then
            echo "FIT=$FIT"
            echo "CPU_FIT_COMPLETE_NOT_FROZEN_NOT_VALIDATED"
        else
            echo "FIT=$FIT"
            echo "CPU_FIT_FAILED_NO_RUNTIME_MODEL_INSTALLED"
        fi
    else
        echo "CORUN_FIT_SELF_TEST_FAILED_NOT_STARTED"
    fi
else
    echo "CORUN_FIT_INSTALL_FAILED_NOT_STARTED"
fi
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    data = command().encode()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as handle:
        handle.write(data)
    print(f"OUTPUT={args.output.resolve()} LINES={len(data.splitlines())} SHA256={hashlib.sha256(data).hexdigest()}")


if __name__ == "__main__":
    main()
