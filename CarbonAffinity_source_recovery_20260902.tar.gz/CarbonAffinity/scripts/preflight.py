from __future__ import annotations

import argparse
import asyncio
import json
import os
import platform
import time
from pathlib import Path

from carbonaffinity.carbon import CarbonTrace
from carbonaffinity.config import config_fingerprint, load_config, resolve_path
from carbonaffinity.control import SiteControlClient
from carbonaffinity.profile import HardwareProfile
from carbonaffinity.region import RegionClient


async def inspect(config: dict) -> dict:
    checks: dict[str, bool] = {}
    details: dict = {}
    clients = [RegionClient(region, 30.0) for region in config["regions"]]
    try:
        health = await asyncio.gather(*(client.healthy() for client in clients))
        checks["both_endpoints_healthy"] = all(health)
        details["endpoint_health"] = dict(zip((region["id"] for region in config["regions"]), health))
        served = await asyncio.gather(*(client.models() for client in clients), return_exceptions=True)
        details["served_models"] = {
            region["id"]: (value if isinstance(value, list) else repr(value))
            for region, value in zip(config["regions"], served)
        }
        checks["configured_model_is_served"] = all(
            isinstance(value, list) and region["model"] in value
            for region, value in zip(config["regions"], served)
        )
        resets = await asyncio.gather(*(client.reset_prefix_cache() for client in clients), return_exceptions=True)
        details["prefix_cache_reset"] = [value if isinstance(value, bool) else repr(value) for value in resets]
        checks["prefix_cache_reset_supported"] = all(value is True for value in resets)
        salt_support = await asyncio.gather(*(client.supports_cache_salt() for client in clients))
        details["cache_salt_support"] = dict(zip((region["id"] for region in config["regions"]), salt_support))
        checks["cache_salt_supported"] = all(salt_support)
    finally:
        await asyncio.gather(*(client.close() for client in clients))
    profiles = {}
    for region in config["regions"]:
        profile = HardwareProfile.from_json(resolve_path(config, region["profile"]))
        profiles[region["id"]] = profile
    checks["profile_region_match"] = all(profiles[region["id"]].region_id == region["id"] for region in config["regions"])
    checks["profile_model_match"] = all(profiles[region["id"]].model == region["model"] for region in config["regions"])
    carbon = CarbonTrace.from_csv(resolve_path(config, config["carbon"]["trace"]), float(config["carbon"].get("max_age_s", 1800)))
    checks["carbon_has_both_regions"] = all(region["id"] in carbon.rows for region in config["regions"])
    checks["main_is_two_single_gpu_regions"] = all(int(region["gpu_count"]) == 1 and int(region["tensor_parallel_size"]) == 1 for region in config["regions"])
    manifests = []
    for region in config["regions"]:
        manifest_path = resolve_path(config, region["site_manifest"])
        manifests.append(json.loads(manifest_path.read_text(encoding="utf-8")))
    details["site_manifests"] = manifests
    checks["manifest_region_match"] = all(
        manifest.get("region_id") == region["id"]
        for manifest, region in zip(manifests, config["regions"])
    )
    checks["two_distinct_physical_gpus"] = len({manifest.get("gpu", {}).get("uuid") for manifest in manifests}) == 2
    checks["both_manifests_are_a800"] = all("A800" in str(manifest.get("gpu", {}).get("name")) for manifest in manifests)
    model_hashes = [manifest.get("model_config_sha256") for manifest in manifests]
    checks["identical_model_config_hash"] = all(model_hashes) and len(set(model_hashes)) == 1
    checks["distinct_grid_regions"] = len({manifest.get("grid_region") for manifest in manifests}) == 2
    lease = config.get("lease", {})
    checks["lease_model_calibrated"] = bool(lease.get("calibrated", False))
    checks["nonnegative_memory_shadow_price"] = float(lease.get("memory_shadow_g_per_gib_s", -1.0)) >= 0
    token = os.environ.get("CARBONAFFINITY_CONTROL_TOKEN", "")
    checks["control_token_present"] = len(token) >= 16
    if checks["control_token_present"]:
        controls = [SiteControlClient(region["control_base"], token, 30.0) for region in config["regions"]]
        try:
            live_status = await asyncio.gather(*(control.status() for control in controls), return_exceptions=True)
        finally:
            await asyncio.gather(*(control.close() for control in controls))
        details["live_site_status"] = [value if isinstance(value, dict) else repr(value) for value in live_status]
        checks["both_site_agents_reachable"] = all(isinstance(value, dict) for value in live_status)
        checks["live_manifest_matches"] = all(
            isinstance(value, dict)
            and value.get("region_id") == region["id"]
            and value.get("manifest", {}).get("gpu", {}).get("uuid") == manifest.get("gpu", {}).get("uuid")
            for value, region, manifest in zip(live_status, config["regions"], manifests)
        )
    else:
        checks["both_site_agents_reachable"] = False
        checks["live_manifest_matches"] = False
    return {
        "passed": all(checks.values()),
        "timestamp_s": time.time(),
        "python": platform.python_version(),
        "config_fingerprint": config_fingerprint(config),
        "checks": checks,
        "details": details,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = asyncio.run(inspect(load_config(args.config)))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["passed"] else 2)


if __name__ == "__main__":
    main()
