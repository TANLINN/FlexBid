"""Eight-GPU DEVELOPMENT pilot: live client phases, exact warm cache, no fitting.

Run with --gpu-index for the sampler; otherwise reuse the verified residual
supervisor unchanged. Controller admission snapshots are not engine counters.
"""
import argparse
import asyncio
import hashlib
import json
import sys
import time
import uuid
from dataclasses import asdict
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, quantile
from carbonaffinity.models import RequestSpec
from scripts.latency_residual_protocol import GPUS, result_checks, features
from scripts.latency_shape_probe_support import tuning_events

VERSION = "observable-corun-development-pilot-v2"
MEASUREMENT_MODULE = "scripts.corun_observable_pilot"
REPORT_NAME = "OBSERVABLE_CORUN_PILOT_AUDIT.json"
SCENARIOS = ("decode2", "mixed", "baseline", "prefill1", "prefill2", "decode1",
             "future1", "future2")


def background_specs(scenario):
    n = 0 if scenario == "baseline" else (2 if scenario == "mixed" else int(scenario[-1]))
    result = []
    for i in range(n):
        primed = scenario.startswith("decode") or (scenario == "mixed" and i == 0)
        result.append(dict(role=f"bg{i}", prompt_tokens=16064 if primed else 16384,
                           cached_target=15680 if primed else 0, output_tokens=192))
    return result


def cases():
    return [dict(case_id=f"{mode}_{scenario}", mode=mode, scenario=scenario,
                 prompt_tokens=p, cached_target=c, output_tokens=64,
                 backgrounds=background_specs(scenario),
                 future_offset_ms=250)
            for mode, p, c in (("cold_small", 4096, 0), ("cold_long", 16384, 0),
                               ("warm", 16064, 15680)) for scenario in SCENARIOS]


def design():
    return dict(protocol=VERSION, expected_rows=192, rows_per_gpu=24,
                gpu_indices=list(GPUS), cases=cases(), runtime_cap=784,
                snapshot="live controller state immediately before victim admission; not engine state",
                workloads="initial cold prompt reservations and FULL output budgets; never time-decayed",
                warm_cache="full-prompt prime; require observed15680 and residual384",
                cold_cache="fresh namespaces; null stays unknown, not measured zero",
                decode_background="individually prime16064; require observed15680, residual384, output192; verify live decode phase",
                case_order="per victim mode: decode2,mixed,baseline,prefill1,prefill2,decode1,future1,future2",
                prior_v1="cold16384/output192 backgrounds failed to overlap in decode; old failed rows are not reused",
                gates="exact cases/cache/phase/request/code integrity; no post-prewarm tuning",
                ttft_reporting_threshold_ms=16000, slo_is_pass_gate=False,
                scope="development pilot only; no fit, model install, freeze, carbon comparison or SLO guarantee")


def prepare(root, args):
    return {"model_fitting_in_this_run": False, "prior_latency_model_used": False}


def code_paths():
    return [Path(__file__).resolve()]


def phase_counts(snapshot):
    entries = snapshot["workload_requests"]
    return (sum(e[1] == "prefill" for e in entries),
            sum(e[1] == "decode" for e in entries))


def expected_phases(scenario):
    if scenario.startswith("prefill"):
        return int(scenario[-1]), 0
    if scenario.startswith("decode"):
        return 0, int(scenario[-1])
    return (1, 1) if scenario == "mixed" else (0, 0)


class PhaseNotObserved(RuntimeError):
    def __init__(self, message, snapshot, expected, jobs):
        super().__init__(message)
        self.evidence = dict(expected=list(expected), actual=list(phase_counts(snapshot)),
                             snapshot=snapshot, jobs_done=[j.done() for j in jobs], wall_ns=time.time_ns())


async def await_phases(client, jobs, expected, timeout=180):
    deadline = time.monotonic() + timeout
    while True:
        snapshot = asdict(client.snapshot())
        if phase_counts(snapshot) == expected:
            return
        if any(job.done() for job in jobs):
            raise PhaseNotObserved("background finished/failed before requested phase; case retained", snapshot, expected, jobs)
        if time.monotonic() >= deadline:
            raise PhaseNotObserved("requested client phase not observed before timeout", snapshot, expected, jobs)
        await asyncio.sleep(.005)


async def run_case(args, materializer, client, case, namespace, protocol=None):
    protocol = protocol or sys.modules[__name__]
    row = dict(case, protocol=protocol.VERSION, gpu_index=args.gpu_index,
               runtime_evidence_sha256=args.runtime_evidence, requests={}, results={}, prime=None,
               background_primes={})
    jobs = {}
    identity = f"{namespace}:g{args.gpu_index}:{case['case_id']}"
    victim_tokens = materializer.tokens(dict(request_id=identity, prompt_tokens=case["prompt_tokens"], shared_prefix_tokens=0))

    async def submit(role, tokens, output, salt, cached=0):
        spec = RequestSpec(identity + ":" + role, 0, len(tokens), output, identity + ":" + role)
        row["requests"][role] = dict(request_id=spec.request_id, prompt_tokens=len(tokens),
                                     output_budget=output, cache_salt=salt,
                                     prompt_sha256=hashlib.sha256(json.dumps(tokens).encode()).hexdigest())
        return await client.complete(spec, tokens, cache_salt=salt, estimated_cached_tokens=cached)

    background_tokens = {}

    def background(index):
        role = f"bg{index}"
        spec = case["backgrounds"][index]
        jobs[role] = asyncio.create_task(submit(role, background_tokens[role], spec["output_tokens"],
                                               identity + role, spec["cached_target"]))

    async def victim():
        # There is no await between taking the live snapshot and entering the
        # request admission call. Never reconstruct this from completed output.
        row["admission_snapshot"] = asdict(client.snapshot())
        row["admission_snapshot_wall_ns"] = time.time_ns()
        row["own_uncached_reservation"] = case["prompt_tokens"] - case["cached_target"]
        return await submit("victim", victim_tokens, 64, identity, case["cached_target"])

    try:
        if client.snapshot().workload_requests:
            raise RuntimeError("previous case still active")
        if not await client.reset_prefix_cache():
            raise RuntimeError("cache reset failed")
        if case["cached_target"]:
            prime = RequestSpec(identity + ":prime", 0, case["prompt_tokens"], 1, identity)
            row["prime"] = asdict(await client.complete(prime, victim_tokens, cache_salt=identity))
            if not all(result_checks(row["prime"], case["prompt_tokens"], 1).values()):
                raise RuntimeError("warm prime failed")
        # Prepare decode workloads before the measured case, with the exact
        # same prompt and per-role salt. Cold-prefill/future roles stay cold.
        # Priming success is not cache evidence: final background responses
        # must separately report the exact expected cache amount.
        for spec in case["backgrounds"]:
            role = spec["role"]
            tokens = materializer.tokens(dict(request_id=identity + role,
                prompt_tokens=spec["prompt_tokens"], shared_prefix_tokens=0))
            background_tokens[role] = tokens
            if spec["cached_target"]:
                prime = RequestSpec(identity + ":" + role + ":prime", 0, len(tokens), 1, identity + role)
                result = asdict(await client.complete(prime, tokens, cache_salt=identity + role))
                row["background_primes"][role] = dict(result=result, cache_salt=identity + role,
                    prompt_sha256=hashlib.sha256(json.dumps(tokens).encode()).hexdigest())
                if not all(result_checks(result, len(tokens), 1).values()):
                    raise RuntimeError("decode background prime failed: " + role)
        scenario = case["scenario"]
        if scenario.startswith("future"):
            jobs["victim"] = asyncio.create_task(victim())
            await asyncio.sleep(case["future_offset_ms"] / 1000)
            for i in range(int(scenario[-1])):
                background(i)
        else:
            if scenario == "mixed":
                background(0)
                await await_phases(client, list(jobs.values()), (0, 1))
                background(1)
            elif scenario != "baseline":
                for i in range(int(scenario[-1])):
                    background(i)
            await await_phases(client, list(jobs.values()), expected_phases(scenario))
            jobs["victim"] = asyncio.create_task(victim())
        await asyncio.gather(*jobs.values(), return_exceptions=True)
    except Exception as exc:
        row["collection_error"] = f"{type(exc).__name__}: {exc}"
        if isinstance(exc, PhaseNotObserved):
            row["phase_failure"] = exc.evidence
        row["snapshot_before_cleanup"] = asdict(client.snapshot())
    finally:
        for job in jobs.values():
            if not job.done():
                job.cancel()
        if jobs:
            values = await asyncio.gather(*jobs.values(), return_exceptions=True)
            row["results"] = {role: asdict(value) if not isinstance(value, BaseException)
                              else dict(success=False, error=repr(value))
                              for role, value in zip(jobs, values)}
        row["snapshot_after_completion"] = asdict(client.snapshot())
    row["cache_features"] = {role: features(value) for role, value in row["results"].items()}
    row["checks"] = check_row(row, protocol)
    return row


def check_row(row, protocol=None):
    protocol = protocol or sys.modules[__name__]
    # Keep the causal error visible if phase construction fails before the
    # victim exists; do not obscure it with an unrelated schema-only error.
    if "collection_error" in row:
        return {"no_collection_error": False,
                "admission_snapshot_present": "admission_snapshot" in row}
    try:
        case = next(c for c in protocol.cases() if c["case_id"] == row["case_id"])
        scenario = case["scenario"]
        n = 0 if scenario == "baseline" else (2 if scenario == "mixed" else int(scenario[-1]))
        roles = {"victim"} | {f"bg{i}" for i in range(n)}
        specs = {spec["role"]: spec for spec in case["backgrounds"]}
        results, requests = row["results"], row["requests"]
        snap = row["admission_snapshot"]
        entries = snap["workload_requests"]
        pref = [e for e in entries if e[1] == "prefill"]
        dec = [e for e in entries if e[1] == "decode"]
        checks = dict(metadata=row["protocol"] == protocol.VERSION and all(row.get(k) == v for k, v in case.items()),
                      no_collection_error="collection_error" not in row,
                      exact_roles=set(results) == roles and set(requests) == roles,
                      phases=phase_counts(snap) == expected_phases(scenario),
                      workload_released=not row["snapshot_after_completion"]["workload_requests"],
                      own_reservation=row["own_uncached_reservation"] == case["prompt_tokens"] - case["cached_target"],
                      live_budgets=(snap["estimated_prefill_tokens"] == sum(e[2] for e in pref)
                          and snap["prefill_decode_tokens"] == sum(e[3] for e in pref)
                          and snap["active_decode_tokens"] == sum(e[3] for e in dec)),
                      unique_namespaces=len({r["cache_salt"] for r in requests.values()}) == len(roles),
                      cache_features=row["cache_features"] == {k: features(v) for k, v in results.items()})
        expected_ids = set() if scenario == "baseline" or scenario.startswith("future") else {requests[f"bg{i}"]["request_id"] for i in range(n)}
        id_specs = {requests[role]["request_id"]: spec for role, spec in specs.items()}
        checks["live_identity_and_budgets"] = (len(entries) == len(expected_ids)
            and {e[0] for e in entries} == expected_ids
            # RegionClient clears outstanding prefill work at the first token;
            # the complete output reservation persists through decode.
            and all(e[1] in ("prefill", "decode")
                    and e[2] == (id_specs[e[0]]["prompt_tokens"] - id_specs[e[0]]["cached_target"]
                                  if e[1] == "prefill" else 0)
                    and e[3] == id_specs[e[0]]["output_tokens"] for e in entries))
        for role in roles:
            spec = case if role == "victim" else specs[role]
            p, output, cache = spec["prompt_tokens"], spec["output_tokens"], spec["cached_target"] or None
            checks[role + "_request"] = (all(result_checks(results[role], p, output, cache).values())
                and results[role]["request_id"] == requests[role]["request_id"]
                and requests[role]["prompt_tokens"] == p and requests[role]["output_budget"] == output)
        expected_primes = {role for role, spec in specs.items() if spec["cached_target"]}
        primes = row["background_primes"]
        checks["background_primes"] = (set(primes) == expected_primes and all(
            all(result_checks(primes[role]["result"], specs[role]["prompt_tokens"], 1).values())
            and primes[role]["cache_salt"] == requests[role]["cache_salt"]
            and primes[role]["prompt_sha256"] == requests[role]["prompt_sha256"]
            and primes[role]["result"]["request_id"] == requests[role]["request_id"] + ":prime"
            for role in expected_primes))
        checks["prime"] = (all(result_checks(row["prime"], case["prompt_tokens"], 1).values())
                           if case["cached_target"] else row["prime"] is None)
        return checks
    except (KeyError, TypeError, ValueError, StopIteration, IndexError):
        return {"schema_complete": False}


async def collect(args, materializer, client, grid=None, protocol=None):
    protocol = protocol or sys.modules[__name__]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    namespace = uuid.uuid4().hex
    with args.output.open("x", encoding="utf-8") as handle:
        for case in protocol.cases() if grid is None else grid:
            row = await run_case(args, materializer, client, case, namespace, protocol)
            handle.write(json.dumps(row, allow_nan=False) + "\n")
            handle.flush()
            print(f"GPU {args.gpu_index} {case['case_id']} checks={all(row['checks'].values())}", flush=True)
            if not all(row["checks"].values()):
                raise RuntimeError("case integrity failed; raw row retained: " + case["case_id"])


def audit(root, protocol=None):
    protocol = protocol or sys.modules[__name__]
    root = Path(root)
    rows = read_rows(root / "raw")
    registered = json.loads((root / "PREREGISTRATION.json").read_text())
    launch = json.loads((root / "LAUNCH.json").read_text())
    prewarm = json.loads((root / "SHAPE_PREWARM.json").read_text())
    expected = {(g, c["case_id"]) for g in GPUS for c in protocol.cases()}
    keys = [(r.get("gpu_index"), r.get("case_id")) for r in rows]
    checked = [(r, check_row(r, protocol)) for r in rows]
    failed = [dict(gpu=r.get("gpu_index"), case=r.get("case_id"), checks=c) for r, c in checked
              if not all(c.values()) or r.get("checks") != c]
    post = {}
    prefixes = True
    for g in GPUS:
        raw = (root / f"vllm_gpu_{g}.log").read_bytes()
        old = prewarm["logs"][str(g)]
        prefixes &= hashlib.sha256(raw[:old["bytes"]]).hexdigest() == old["sha256"]
        post[str(g)] = tuning_events(raw[old["bytes"]:].decode(errors="replace"))
    checks = dict(preregistration_unchanged=registered.get("design") == protocol.design() and registered.get("expected_rows") == len(expected),
        raw_integrity=not failed, launch_evidence=all(r.get("runtime_evidence_sha256") == sha256(root / "LAUNCH.json") for r in rows),
        cap_and_block=launch.get("runtime_cap") == 784 and launch.get("effective_cap_verified") is True and launch.get("cache_block784_verified") is True,
        prewarm=prewarm.get("gpu_indices") == list(GPUS) and prewarm.get("requests") == 64 and prewarm["checks"]["all_shape_keys_observed"] is True,
        log_prefixes=prefixes, no_post_prewarm_autotuning=not any(post.values()),
        code_unchanged=bool(registered.get("code_sha256")) and all(Path(p).is_file() and sha256(p) == h for p, h in registered["code_sha256"].items()))
    checks[f"exact_{len(expected)}_cases"] = len(keys) == len(expected) and set(keys) == expected
    summary = {}
    for case in protocol.cases():
        valid = [r for r, c in checked if r.get("case_id") == case["case_id"] and all(c.values())]
        if valid:
            vals = [r["results"]["victim"]["ttft_ms"] for r in valid]
            tpots = [r["results"]["victim"]["tpot_ms"] for r in valid]
            summary[case["case_id"]] = dict(samples=len(vals), median_ttft_ms=quantile(vals, .5), max_ttft_ms=max(vals),
                over_16000ms=sum(v > 16000 for v in vals), median_tpot_ms=quantile(tpots, .5), max_mean_tpot_ms=max(tpots))
    return dict(status="PASS" if all(checks.values()) else "FAIL", stage=protocol.VERSION, rows=len(rows),
        checks=checks, failed_cases=failed, by_case=summary, post_prewarm_tuning_events=post,
        note="Development integrity only, not SLO/model validation. No prior model or runtime files changed.")


def main(campaign=None):
    campaign = campaign or sys.modules[__name__]
    if "--gpu-index" not in sys.argv:
        from scripts.run_latency_residual_campaign import main as supervisor
        supervisor(campaign=campaign)
        return
    parser = argparse.ArgumentParser()
    for name in ("api-base", "model", "tokenizer", "runtime-evidence"):
        parser.add_argument("--" + name, required=True)
    parser.add_argument("--gpu-index", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    from carbonaffinity.materialize import PromptMaterializer
    from carbonaffinity.region import RegionClient
    async def run():
        client = RegionClient(dict(id=f"gpu_{args.gpu_index}", api_base=args.api_base, model=args.model, admission_concurrency=8), 300)
        try:
            await collect(args, PromptMaterializer(args.tokenizer), client, protocol=campaign)
        finally:
            await client.close()
    asyncio.run(run())


if __name__ == "__main__":
    main()
