"""Development candidate estimator; not wired into admission/routing."""
import itertools
import math
from collections import defaultdict

from scripts.latency_residual_protocol import CACHED_CONTEXTS, CONCURRENCIES, OUTPUT, RESIDUALS

METRICS = ("ttft_ms", "tpot_ms")
MODEL_KIND = "residual_latency_monotone_candidate_v1"
AXIS_NAMES = {"cold": ("prompt_tokens", "concurrency"),
              "warm": ("cached_tokens", "uncached_tokens", "concurrency")}
AXES = {
    "cold": {"prompt_tokens": sorted(c + u for c in CACHED_CONTEXTS for u in RESIDUALS),
             "concurrency": list(CONCURRENCIES)},
    "warm": {"cached_tokens": list(CACHED_CONTEXTS), "uncached_tokens": list(RESIDUALS),
             "concurrency": list(CONCURRENCIES)},
}


def batch_observation(row):
    mode = row["mode"]
    records = row["results"]
    if mode not in AXES or len(records) != row["concurrency"] or not records:
        raise ValueError("invalid batch mode/count")
    if any(x.get("success") is not True or x.get("status_code") != 200
           or x.get("output_tokens") != OUTPUT or x.get("prompt_tokens_reported") != row["prompt_tokens"]
           for x in records):
        raise ValueError("invalid measured request")
    if mode == "warm":
        caches = [x.get("cached_prompt_tokens_observed") for x in records]
        if any(type(c) is not int or c != row["cached_context_target"] for c in caches):
            raise ValueError("warm cache must be observed exactly, never imputed")
        cached = caches[0]
        residual = row["prompt_tokens"] - cached
        if residual != row["residual_target"]:
            raise ValueError("warm residual mismatch")
        coordinate = (cached, residual, row["concurrency"])
    else:
        if any(x.get("cached_prompt_tokens_observed") not in (None, 0) for x in records):
            raise ValueError("cold control has observed cache hits")
        # This is the explicitly isolated cold CONTROL, not a claim that null
        # is an observed zero-cache value in arbitrary runtime requests.
        coordinate = (row["prompt_tokens"], row["concurrency"])
    values = {}
    for metric in METRICS:
        samples = [x.get(metric) for x in records]
        if any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in samples):
            raise ValueError("nonfinite/negative/missing latency")
        values[metric] = max(samples)
    return {"mode": mode, "coordinate": coordinate, "gpu": row["gpu_index"],
            "case_id": row["case_id"], "metrics": values}


def key(coordinate):
    return "|".join(map(str, coordinate))


def fit_cells(observations):
    """Max per cell, followed by the least coordinatewise nondecreasing majorant."""
    groups = defaultdict(list)
    for item in observations:
        groups[(item["mode"], tuple(item["coordinate"]))].append(item)
    surfaces = {}
    expected = set()
    for mode, axes in AXES.items():
        coordinates = list(itertools.product(*(axes[name] for name in AXIS_NAMES[mode])))
        cells = {}
        for coordinate in coordinates:
            expected.add((mode, coordinate))
            items = groups.get((mode, coordinate), [])
            if not items:
                raise ValueError(f"missing training cell: {mode}/{coordinate}")
            cells[key(coordinate)] = {
                "samples": len(items),
                "gpus": sorted({x["gpu"] for x in items}),
                "raw_max_ms": {m: max(x["metrics"][m] for x in items) for m in METRICS},
            }
        for coordinate in coordinates:
            predecessors = [p for p in coordinates if all(a <= b for a, b in zip(p, coordinate))]
            cells[key(coordinate)]["upper_ms"] = {
                m: max(cells[key(p)]["raw_max_ms"][m] for p in predecessors) for m in METRICS}
        surfaces[mode] = {"axes": axes, "cells": cells}
    if set(groups) != expected:
        raise ValueError("unregistered training coordinates")
    return {"schema_version": 1, "model_kind": MODEL_KIND,
            "status": "CANDIDATE_REQUIRES_INDEPENDENT_VALIDATION", "candidate_frozen": False,
            "independent_validation_passed": False, "surfaces": surfaces,
            "margin_ms": {mode: {m: 0.0 for m in METRICS} for mode in AXES},
            "method": "cell maxima + coordinatewise monotone majorant + ceiling-anchor lookup + LOO max-positive-residual margin",
            "target": "maximum per-request TTFT and mean TPOT within a homogeneous simultaneous batch",
            "assumptions": {"runtime_cap": 784, "output_tokens": OUTPUT,
                "fixed_shape_prewarm_required": True,
                "cold": "fresh isolated cold-control namespace; missing cache is unknown, not measured zero",
                "warm": "known positive cached context and actual residual; no cold/warm mixture shortcut"},
            "scope_limits": ["not a statistical confidence bound", "no service-SLO guarantee",
                "not validated between anchors", "not evaluated for mixed arrivals/background workloads",
                "mean TPOT is not maximum token stall", "not installed in runtime",
                "partial prefixes with residual above 768 are out of domain"]}


def predict(model, mode, coordinate, *, output_tokens=OUTPUT, runtime_cap=784):
    if model.get("model_kind") != MODEL_KIND:
        raise ValueError("wrong model kind")
    reason = None
    if mode not in model["surfaces"]:
        reason = "unsupported mode"
    elif output_tokens != OUTPUT or runtime_cap != 784:
        reason = "unsupported output length/runtime cap"
    else:
        axes = model["surfaces"][mode]["axes"]
        anchors_in_order = [axes[name] for name in AXIS_NAMES[mode]]
        if len(coordinate) != len(axes) or any(type(v) is not int for v in coordinate):
            reason = "coordinates must be exact integer token/load counts"
        elif any(v < anchors[0] or v > anchors[-1] for v, anchors in zip(coordinate, anchors_in_order)):
            reason = "outside sampled coordinate range"
    if reason:
        return {"in_domain": False, "reason": reason, "prediction_ms": None,
                "independently_validated": False}
    chosen = tuple(next(a for a in anchors if a >= v) for v, anchors in zip(coordinate, anchors_in_order))
    cell = model["surfaces"][mode]["cells"][key(chosen)]
    predictions = {m: cell["upper_ms"][m] + model["margin_ms"][mode][m] for m in METRICS}
    if any(not math.isfinite(v) or v < 0 for v in predictions.values()):
        raise ValueError("corrupt prediction")
    return {"in_domain": True, "lookup_coordinate": list(chosen),
            "anchor_point": tuple(coordinate) == chosen, "prediction_ms": predictions,
            "independently_validated": False}


def evaluate(model, observations):
    groups = defaultdict(list)
    for item in observations:
        prediction = predict(model, item["mode"], item["coordinate"])
        if not prediction["in_domain"]:
            raise ValueError("development observation out of domain")
        for metric in METRICS:
            actual, upper = item["metrics"][metric], prediction["prediction_ms"][metric]
            groups[item["mode"] + "_" + metric].append((actual, upper))
    return {name: {"samples": len(values), "coverage": sum(a <= p for a, p in values) / len(values),
                   "positive_residual_max_ms": max(max(0.0, a - p) for a, p in values)}
            for name, values in sorted(groups.items())}


def fit_candidate(rows):
    observations = [batch_observation(row) for row in rows]
    gpus = sorted({x["gpu"] for x in observations})
    if gpus != list(range(8)):
        raise ValueError("eight development GPUs required")
    folds = []
    margin = {mode: {m: 0.0 for m in METRICS} for mode in AXES}
    for gpu in gpus:
        training = [x for x in observations if x["gpu"] != gpu]
        heldout = [x for x in observations if x["gpu"] == gpu]
        fold_model = fit_cells(training)
        diagnostics = evaluate(fold_model, heldout)
        folds.append({"heldout_gpu": gpu, "training_gpus": [g for g in gpus if g != gpu],
                      "training_batches": len(training), "heldout_batches": len(heldout),
                      "without_margin": diagnostics})
        for mode in AXES:
            for metric in METRICS:
                margin[mode][metric] = max(margin[mode][metric],
                    diagnostics[mode + "_" + metric]["positive_residual_max_ms"])
    model = fit_cells(observations)
    model["margin_ms"] = {mode: {m: math.ceil(v * 1000) / 1000 for m, v in values.items()}
                          for mode, values in margin.items()}
    model["margin_semantics"] = "Learned from all 8 development LOO folds; not a fresh heldout evaluation or confidence bound. Rounded upward to .001 ms."
    return model, {"leave_one_gpu_out_without_margin": folds,
                   "development_resubstitution": evaluate(model, observations),
                   "development_coverage_is_expected_by_construction": True,
                   "margin_adjusted_loo_is_not_reported_as_independent_validation": True}
