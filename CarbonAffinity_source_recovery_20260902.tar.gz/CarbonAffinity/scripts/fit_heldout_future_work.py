from __future__ import annotations

import gzip
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CAP_TURNS = 32
MAX_TURN = 64


def event_time(row: dict) -> datetime | None:
    timestamps = [
        event.get("timestamp")
        for event in row.get("timing_events", [])
        if event.get("timestamp")
    ]
    if not timestamps:
        return None
    return datetime.fromisoformat(min(timestamps).replace("Z", "+00:00"))


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    trace_path = ROOT / "data/raw/syfi_coding_trace.jsonl.gz"
    development_path = ROOT / "results/real_data_preparation_manifest.json"
    preregistration_path = ROOT / "results/heldout_pre_registration_manifest.json"
    materialization_path = ROOT / "results/heldout_materialization_manifest.json"
    development = json.loads(development_path.read_text())
    heldout = json.loads(preregistration_path.read_text())
    development_ranges = [
        (
            datetime.fromisoformat(row["source_start_utc"]),
            datetime.fromisoformat(row["source_start_utc"]) + timedelta(hours=1),
        )
        for row in development["windows"]
    ]
    heldout_ranges = [
        (datetime.fromisoformat(value), datetime.fromisoformat(value) + timedelta(hours=1))
        for value in heldout["selected_source_starts_utc"]
    ]

    sessions: dict[str, list[tuple[datetime, dict]]] = defaultdict(list)
    development_excluded: set[str] = set()
    heldout_excluded: set[str] = set()
    with gzip.open(trace_path, "rt", encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            timestamp = event_time(row)
            if timestamp is None:
                continue
            session = str(row["session_id"])
            if any(left <= timestamp < right for left, right in development_ranges):
                development_excluded.add(session)
            if any(left <= timestamp < right for left, right in heldout_ranges):
                heldout_excluded.add(session)
            prompt = int(row.get("input_tokens_total") or 0)
            output = int(row.get("output_tokens") or 0)
            if 128 <= prompt <= 30_000 and 1 <= output <= 512:
                sessions[session].append((timestamp, row))

    excluded = development_excluded | heldout_excluded
    samples: dict[int, list[dict[str, float]]] = defaultdict(list)
    training_sessions = 0
    training_ids: set[str] = set()
    for session, values in sessions.items():
        if session in excluded:
            continue
        values.sort(key=lambda item: (int(item[1].get("round_index") or 0), item[0]))
        if not values:
            continue
        training_sessions += 1
        training_ids.add(session)
        for position, (_, current) in enumerate(values):
            turn = int(current.get("round_index") or 0)
            if turn < 0 or turn > MAX_TURN:
                continue
            totals = {
                "future_requests": 0.0,
                "future_cold_tokens": 0.0,
                "future_cached_tokens": 0.0,
                "future_output_tokens": 0.0,
                "future_source_duration_s": 0.0,
            }
            current_timestamp = values[position][0]
            previous = current
            for timestamp, future in values[position + 1 : position + 1 + CAP_TURNS]:
                prompt = int(future["input_tokens_total"])
                consecutive = int(future.get("round_index") or 0) == (
                    int(previous.get("round_index") or 0) + 1
                )
                cached = 0
                if consecutive:
                    cached = min(
                        prompt,
                        int(previous["input_tokens_total"]),
                        max(0, int(future.get("prefix_tokens") or 0)),
                    )
                totals["future_requests"] += 1
                totals["future_cached_tokens"] += cached
                totals["future_cold_tokens"] += prompt - cached
                totals["future_output_tokens"] += int(future.get("output_tokens") or 0)
                totals["future_source_duration_s"] = max(
                    totals["future_source_duration_s"],
                    max(0.0, (timestamp - current_timestamp).total_seconds()),
                )
                previous = future
            samples[turn].append(totals)

    if training_ids & excluded:
        raise RuntimeError("excluded session leaked into future-work training")
    fields = (
        "future_requests",
        "future_cold_tokens",
        "future_cached_tokens",
        "future_output_tokens",
        "future_source_duration_s",
    )
    expected = {
        str(turn): {
            field: sum(row[field] for row in rows) / len(rows)
            for field in fields
        }
        for turn, rows in sorted(samples.items())
    }
    support = {str(turn): len(rows) for turn, rows in sorted(samples.items())}
    report = {
        "schema_version": 2,
        "estimator": "conditional empirical mean cumulative future work",
        "cap_turns": CAP_TURNS,
        "max_turn": MAX_TURN,
        "training_sessions": training_sessions,
        "development_excluded_sessions": len(development_excluded),
        "heldout_excluded_sessions": len(heldout_excluded),
        "total_excluded_sessions": len(excluded),
        "exclusion_overlap_sessions": len(development_excluded & heldout_excluded),
        "data_leakage_sessions": 0,
        "source_sha256": {
            "raw_trace": sha256(trace_path),
            "development_manifest": sha256(development_path),
            "heldout_preregistration": sha256(preregistration_path),
            "heldout_materialization": sha256(materialization_path),
        },
        "workloads": {"agentic": expected},
        "support": {"agentic": support},
    }
    output = ROOT / "profiles/session_future_work_heldout_frozen.json"
    output.write_text(json.dumps(report, indent=2))
    print(
        json.dumps(
            {
                key: report[key]
                for key in (
                    "training_sessions",
                    "development_excluded_sessions",
                    "heldout_excluded_sessions",
                    "total_excluded_sessions",
                    "exclusion_overlap_sessions",
                    "data_leakage_sessions",
                )
            },
            indent=2,
        )
    )
    print("model_turns =", len(expected), "range =", min(map(int, expected)), max(map(int, expected)))
    for turn in (0, 1, 2, 4, 8, 16, 32, 64):
        if str(turn) in expected:
            print("turn", turn, "support=", support[str(turn)], "expected=", expected[str(turn)])
    print("MODEL_SHA256 =", sha256(output))
    print(f"HELDOUT_FUTURE_WORK_MODEL_COMPLETE={output}")


if __name__ == "__main__":
    main()
