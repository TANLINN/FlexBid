"""Bounded DEVELOPMENT candidate. No runtime wiring or statistical guarantee."""
import itertools
import math
from collections import Counter, defaultdict
from functools import lru_cache

from carbonaffinity.artifacts import quantile
from scripts import corun_observable_development as dev
from scripts import corun_observable_pilot as sampler

KIND = "observable_corun_stratified_monotone_candidate_v1"
METRICS = ("ttft_ms", "tpot_ms")
THRESHOLD_MS = 16000  # descriptive classification only, not a fit acceptance gate


def integer(value, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError("nonnegative integer reservation required")
    return value


def coordinates(query):
    """Only admission-time fields. Reject heterogeneous/unsupported workloads.

    cached_reservation is an a-priori reservation, NOT a completed-response
    cache reading. The experiment audits those readings separately afterwards.
    """
    p = integer(query["prompt_tokens"], 1)
    c = integer(query["cached_reservation"])
    integer(query["output_budget"], 1)
    if c >= p or query["output_budget"] != 64 or query["runtime_cap"] != 784:
        raise ValueError("unsupported own context/output/runtime")
    mode = "warm" if c else "cold"
    if not c and query.get("cold_namespace_isolated") is not True:
        raise ValueError("cold control must explicitly have an isolated namespace")
    coord = [c, p - c] if c else [p]
    names = ["cached_reservation", "own_uncached_tokens"] if c else ["prompt_tokens"]
    phase = {"prefill": [], "decode": []}
    for bg in query["backgrounds"]:
        if bg["phase"] not in phase:
            raise ValueError("unsupported phase")
        bp = integer(bg["prompt_tokens"], 1)
        bc = integer(bg["cached_reservation"])
        bo = integer(bg["output_budget"], 1)
        outstanding = integer(bg["prefill_reservation"])
        if bg["phase"] == "decode":
            if (bp, bc, outstanding) != (16064, 15680, 0):
                raise ValueError("decode context outside primed16064/cached15680 protocol")
            phase["decode"].append((bo,))
        else:
            if bc != 0 or outstanding != bp or bg.get("cold_namespace_isolated") is not True:
                raise ValueError("prefill backgrounds must be isolated cold reservations")
            phase["prefill"].append((outstanding, bo))
    np, nd = len(phase["prefill"]), len(phase["decode"])
    if (np, nd) not in ((0, 0), (1, 0), (2, 0), (0, 1), (0, 2), (1, 1)):
        raise ValueError("unsupported background phase counts")
    for label in ("prefill", "decode"):
        items = phase[label]
        if len(set(items)) > 1:
            raise ValueError("heterogeneous per-phase workloads are out of domain")
        if items:
            coord.extend(items[0])
            names.extend(["prefill_tokens_per_request", "prefill_output_budget_per_request"]
                         if label == "prefill" else ["decode_output_budget_per_request"])
    return f"{mode}|prefill{np}|decode{nd}", tuple(coord), names


def admission_query(row):
    """Never read results, cache_features, elapsed times or future-only jobs."""
    requests = row["requests"]
    own = requests["victim"]
    p = integer(own["prompt_tokens"], 1)
    c = p - integer(row["own_uncached_reservation"], 1)
    active = row["admission_snapshot"]["workload_requests"]
    if len({entry[0] for entry in active}) != len(active):
        raise ValueError("duplicate active identities")
    by_id = {r["request_id"]: role for role, r in requests.items()}
    specs = {bg["role"]: bg for bg in row["backgrounds"]}
    backgrounds = []
    for request_id, phase, prefill, output in active:
        role = by_id[request_id]
        request, spec = requests[role], specs[role]
        # These spec reservations were fixed before collection, not inferred
        # from measured cache/output or completion times.
        backgrounds.append(dict(phase=phase, prefill_reservation=prefill,
            prompt_tokens=request["prompt_tokens"], cached_reservation=spec["cached_target"],
            output_budget=output, cold_namespace_isolated=spec["cached_target"] == 0))
        if output != request["output_budget"]:
            raise ValueError("snapshot/output reservation mismatch")
    return dict(prompt_tokens=p, cached_reservation=c, output_budget=own["output_budget"],
                cold_namespace_isolated=c == 0, runtime_cap=784, backgrounds=backgrounds)


def design_query(case):
    pref, dec = sampler.expected_phases(case["scenario"])
    active = []
    if pref or dec:
        for i, spec in enumerate(case["backgrounds"]):
            phase = "decode" if case["scenario"].startswith("decode") or (case["scenario"] == "mixed" and i == 0) else "prefill"
            active.append(dict(phase=phase, prompt_tokens=spec["prompt_tokens"],
                cached_reservation=spec["cached_target"], output_budget=spec["output_tokens"],
                prefill_reservation=spec["prompt_tokens"] - spec["cached_target"] if phase == "prefill" else 0,
                cold_namespace_isolated=spec["cached_target"] == 0))
    return dict(prompt_tokens=case["prompt_tokens"], cached_reservation=case["cached_target"],
        output_budget=case["output_tokens"], cold_namespace_isolated=case["cached_target"] == 0,
        runtime_cap=784, backgrounds=active)


@lru_cache(maxsize=1)
def registry():
    result = {}
    for case in dev.cases():
        if case["phase_role"] != "fit_development":
            continue
        stratum, coord, names = coordinates(design_query(case))
        entry = result.setdefault(stratum, dict(names=names, coordinates=set()))
        entry["coordinates"].add(coord)
    for entry in result.values():
        entry["coordinates"] = sorted(entry["coordinates"])
        entry["axes"] = [sorted({c[i] for c in entry["coordinates"]}) for i in range(len(entry["names"]))]
        if set(itertools.product(*entry["axes"])) != set(entry["coordinates"]):
            raise ValueError("training stratum is not a complete grid")
    return result


def observation(row):
    query = admission_query(row)
    stratum, coord, _ = coordinates(query)
    result = row["results"]["victim"]
    if result.get("success") is not True or result.get("output_tokens") != 64:
        raise ValueError("invalid victim result")
    values = {m: result[m] for m in METRICS}
    if any(type(v) not in (int, float) or not math.isfinite(v) or v <= 0 for v in values.values()):
        raise ValueError("missing, nonfinite or nonpositive latency")
    return dict(query=query, stratum=stratum, coordinate=coord, metrics=values,
                gpu=row["gpu_index"], case_id=row["case_id"], repeat=row["repeat"],
                role=row["phase_role"])


def key(coord):
    return "|".join(map(str, coord))


def fit_cells(observations):
    groups = defaultdict(list)
    for item in observations:
        if item["role"] != "fit_development":
            raise ValueError("controls cannot enter fitting")
        groups[item["stratum"], tuple(item["coordinate"])].append(item)
    expected = {(s, c) for s, entry in registry().items() for c in entry["coordinates"]}
    if set(groups) != expected:
        raise ValueError("missing or unregistered model cells")
    surfaces = {}
    for stratum, spec in registry().items():
        cells = {}
        for coord in spec["coordinates"]:
            items = groups[stratum, coord]
            cells[key(coord)] = dict(samples=len(items), gpus=sorted({x["gpu"] for x in items}),
                raw_max_ms={m: max(x["metrics"][m] for x in items) for m in METRICS})
        for coord in spec["coordinates"]:
            predecessors = [c for c in spec["coordinates"] if all(a <= b for a, b in zip(c, coord))]
            cells[key(coord)]["upper_ms"] = {
                m: max(cells[key(c)]["raw_max_ms"][m] for c in predecessors) for m in METRICS}
        surfaces[stratum] = dict(axis_names=spec["names"], axes=spec["axes"], cells=cells)
    return dict(schema_version=1, model_kind=KIND, surfaces=surfaces,
        status="CANDIDATE_REQUIRES_INDEPENDENT_VALIDATION", candidate_frozen=False,
        independent_validation_passed=False,
        margin_ms={mode: {m: 0.0 for m in METRICS} for mode in ("cold", "warm")},
        method="separate mode and exact phase counts; cell maxima, monotone majorant, ceiling anchors, development LOGO max-residual margin",
        target="single arriving victim TTFT and mean TPOT; not maximum token stall",
        feature_semantics="admission-time initial prefill and FULL output reservations; no elapsed-time decay, measured outputs, or future arrivals",
        required_context=dict(runtime_cap=784, cache_block=784, max_num_seqs=8, victim_output_budget=64,
            fixed_shape_prewarm=True, decode_background_prompt=16064, decode_cached_reservation=15680),
        limitations=["not a statistical confidence bound or SLO guarantee", "no independent validation yet",
            "cold cache null stays unknown, never measured zero", "warm reservations require independently established cache evidence",
            "phase counts are exact strata, not interpolated or added", "<=2 backgrounds, mixed=1+1",
            "same-phase backgrounds must be homogeneous", "near-immediate phase admission only; arbitrary ages not validated",
            "no continuous arrival stream or overlapping future background guarantee", "not installed in routing/runtime"],
        reserved_for_validation=dev.RESERVED)


def predict(model, query):
    if model.get("model_kind") != KIND:
        raise ValueError("wrong model kind")
    try:
        stratum, coord, _ = coordinates(query)
    except (KeyError, TypeError, ValueError) as exc:
        return dict(in_domain=False, prediction_ms=None, reason=str(exc), independently_validated=False)
    surface = model["surfaces"].get(stratum)
    if surface is None or any(v < a[0] or v > a[-1] for v, a in zip(coord, surface["axes"])):
        return dict(in_domain=False, prediction_ms=None, reason="outside sampled stratum/range", independently_validated=False)
    chosen = tuple(next(a for a in anchors if a >= v) for v, anchors in zip(coord, surface["axes"]))
    cell = surface["cells"][key(chosen)]
    prediction = {m: cell["upper_ms"][m] + model["margin_ms"][stratum.split("|")[0]][m] for m in METRICS}
    if any(not math.isfinite(v) or v <= 0 for v in prediction.values()):
        raise ValueError("corrupt prediction")
    return dict(in_domain=True, stratum=stratum, lookup_coordinate=list(chosen), anchor_point=coord == chosen,
                prediction_ms=prediction, independently_validated=False)


def evaluate(model, observations, *, by_stratum=False):
    groups = defaultdict(list)
    for item in observations:
        prediction = predict(model, item["query"])
        if not prediction["in_domain"]:
            raise ValueError("development observation out of domain")
        label = item["stratum"] if by_stratum else item["stratum"].split("|")[0]
        for m in METRICS:
            groups[label + "_" + m].append((item["metrics"][m], prediction["prediction_ms"][m]))
    result = {}
    for label, pairs in sorted(groups.items()):
        item = dict(samples=len(pairs), coverage=sum(a <= p for a, p in pairs) / len(pairs),
            positive_residual_max_ms=max(max(0.0, a - p) for a, p in pairs),
            actual_over_prediction_q95=quantile([a / p for a, p in pairs], .95),
            prediction_over_actual_median=quantile([p / a for a, p in pairs], .5),
            prediction_over_actual_max=max(p / a for a, p in pairs))
        if label.endswith("ttft_ms"):
            item.update(actual_over_16000ms=sum(a > THRESHOLD_MS for a, p in pairs),
                predicted_over_16000ms=sum(p > THRESHOLD_MS for a, p in pairs),
                false_negatives=sum(a > THRESHOLD_MS >= p for a, p in pairs),
                false_positives=sum(p > THRESHOLD_MS >= a for a, p in pairs))
        result[label] = item
    return result


def fit_candidate(rows):
    expected = {(g, c["case_id"]) for g in range(8) for c in dev.cases()}
    keys = [(r["gpu_index"], r["case_id"]) for r in rows]
    if len(keys) != 2208 or set(keys) != expected:
        raise ValueError("exact 2208 unique development cases required")
    for row in rows:
        checks = sampler.check_row(row, dev)
        if not all(checks.values()) or checks != row["checks"]:
            raise ValueError("raw row failed read-only recheck: " + row["case_id"])
    all_items = [observation(row) for row in rows]
    training = [x for x in all_items if x["role"] == "fit_development"]
    controls = [x for x in all_items if x["role"] == "future_arrival_control"]
    if len(training) != 2016 or len(controls) != 192:
        raise ValueError("unexpected fit/control partition")
    count = Counter((x["stratum"], x["coordinate"]) for x in training)
    if len(count) != 126 or set(count.values()) != {16}:
        raise ValueError("126 cells with16 observations each required")
    margin = {mode: {m: 0.0 for m in METRICS} for mode in ("cold", "warm")}
    folds = []
    for gpu in range(8):
        train = [x for x in training if x["gpu"] != gpu]
        hold = [x for x in training if x["gpu"] == gpu]
        fold_model = fit_cells(train)
        ev = evaluate(fold_model, hold)
        folds.append(dict(heldout_gpu=gpu, training_gpus=[g for g in range(8) if g != gpu],
            training_rows=len(train), heldout_rows=len(hold), without_margin=ev))
        for mode in margin:
            for m in METRICS:
                margin[mode][m] = max(margin[mode][m], ev[mode + "_" + m]["positive_residual_max_ms"])
    model = fit_cells(training)
    model["margin_ms"] = {mode: {m: math.ceil(v * 1000) / 1000 for m, v in values.items()} for mode, values in margin.items()}
    model["margin_semantics"] = "max positive residual across8 development LOGO folds, rounded upward .001ms; not independent validation"
    return model, dict(training_rows=2016, excluded_future_control_rows=192, model_cells=126,
        leave_one_gpu_out_without_margin=folds, development_resubstitution=evaluate(model, training),
        development_by_stratum=evaluate(model, training, by_stratum=True),
        repeat_diagnostics={str(rep): evaluate(model, [x for x in training if x["repeat"] == rep]) for rep in (0, 1)},
        future_controls_diagnostic_only=evaluate(model, controls),
        development_coverage_expected_by_construction=True,
        controls_never_used_for_cells_margins_or_acceptance=True,
        method_selected_after_development=True, validation_data_read=False)
