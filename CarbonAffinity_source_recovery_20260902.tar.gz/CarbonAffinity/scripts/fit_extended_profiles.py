from __future__ import annotations

import argparse
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

import numpy as np


def nonnegative_least_squares(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    """Exact NNLS for the small (three-column) profile regressions."""
    best = np.zeros(x.shape[1], dtype=float)
    best_error = float(np.dot(y, y))
    for mask in range(1, 1 << x.shape[1]):
        columns = [index for index in range(x.shape[1]) if mask & (1 << index)]
        candidate = np.zeros(x.shape[1], dtype=float)
        values = np.linalg.lstsq(x[:, columns], y, rcond=None)[0]
        if np.any(values < 0):
            continue
        candidate[columns] = values
        error = float(np.sum((x @ candidate - y) ** 2))
        if error < best_error:
            best, best_error = candidate, error
    return best


def read_jsonl(paths: list[Path]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                rows.append(json.loads(line))
    return rows


def quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, math.ceil(q * len(ordered)) - 1))
    return ordered[index]


def batch_model(rows: list[dict]) -> dict:
    groups: dict[tuple[int, int, str], dict[int, list[float]]] = defaultdict(
        lambda: defaultdict(list)
    )
    for row in rows:
        groups[(
            int(row["prompt_tokens"]), int(row["output_tokens"]), str(row["mode"])
        )][int(row["concurrency"])].append(
            float(row["dynamic_energy_per_request_j"])
        )
    cells: dict[str, dict[str, float]] = {}
    pooled: dict[int, list[float]] = defaultdict(list)
    for (prompt, output, mode), curves in sorted(groups.items()):
        baseline = statistics.median(curves[1])
        if baseline <= 0:
            continue
        ratios = {
            str(concurrency): statistics.median(values) / baseline
            for concurrency, values in sorted(curves.items())
        }
        cells[f"{mode}|{prompt}|{output}"] = ratios
        for concurrency, values in curves.items():
            pooled[concurrency].extend(value / baseline for value in values)
    return {
        "schema_version": 1,
        "semantics": "per-request dynamic energy relative to concurrency one",
        "global": {
            str(concurrency): statistics.median(values)
            for concurrency, values in sorted(pooled.items())
        },
        "cells": cells,
        "max_measured_concurrency": max(pooled),
        "marginal_floor": 0.05,
    }


def active_slopes(rows: list[dict], q: float) -> dict[str, float]:
    groups: dict[tuple[int, int, str], list[dict]] = defaultdict(list)
    for row in rows:
        groups[(int(row["gpu_index"]), int(row["prompt_tokens"]), str(row["mode"]))].append(row)
    warm_ttft: list[float] = []
    warm_tpot: list[float] = []
    cold_ttft: list[tuple[int, float]] = []
    cold_tpot: list[tuple[int, float]] = []
    for (_, prompt, mode), values in groups.items():
        base_rows = [row for row in values if int(row["concurrency"]) == 1]
        if not base_rows:
            continue
        base_ttft = statistics.median(float(row["ttft_p95_ms"]) for row in base_rows)
        base_tpot = statistics.median(float(row["tpot_p95_ms"]) for row in base_rows)
        for row in values:
            extra = int(row["concurrency"]) - 1
            if extra <= 0:
                continue
            ttft = max(0.0, (float(row["ttft_p95_ms"]) - base_ttft) / extra)
            tpot = max(0.0, (float(row["tpot_p95_ms"]) - base_tpot) / extra)
            if mode == "warm":
                warm_ttft.append(ttft)
                warm_tpot.append(tpot)
            else:
                cold_ttft.append((prompt, ttft))
                cold_tpot.append((prompt, tpot))
    if not warm_ttft or not cold_ttft:
        raise RuntimeError("insufficient concurrency measurements")
    ttft_base = quantile(warm_ttft, q)
    tpot_base = quantile(warm_tpot, q)
    return {
        "active_ttft_base_ms_per_request": ttft_base,
        "active_ttft_ms_per_cold_token_per_request": quantile(
            [max(0.0, slope - ttft_base) / prompt for prompt, slope in cold_ttft], q
        ),
        "tpot_active_base_ms_per_request": tpot_base,
        "tpot_active_ms_per_cold_token_per_request": quantile(
            [max(0.0, slope - tpot_base) / prompt for prompt, slope in cold_tpot], q
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-batch-root", type=Path, required=True)
    parser.add_argument("--long-root", type=Path, required=True)
    parser.add_argument("--profile-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--quantile", type=float, default=0.95)
    args = parser.parse_args()

    batch_rows = read_jsonl(
        sorted(args.base_batch_root.glob("gpu_*.jsonl"))
        + sorted(args.long_root.glob("batch_gpu_*.jsonl"))
    )
    concurrency_rows = read_jsonl(sorted(args.long_root.glob("concurrency_gpu_*.jsonl")))
    if not batch_rows or not concurrency_rows:
        raise RuntimeError("batch or concurrency data is empty")
    model = batch_model(batch_rows)
    slopes = active_slopes(concurrency_rows, args.quantile)
    profiles = sorted(args.profile_root.glob("*.json"))
    by_gpu: dict[int, list[dict]] = defaultdict(list)
    for row in batch_rows:
        if int(row["concurrency"]) == 1:
            by_gpu[int(row["gpu_index"])].append(row)
    report = {
        "batch_rows": len(batch_rows),
        "concurrency_rows": len(concurrency_rows),
        "batch_cells": len(model["cells"]),
        "active_slopes": slopes,
        "profiles": {},
    }
    region_to_gpu = {
        str(row["region_id"]): int(row["gpu_index"])
        for row in concurrency_rows
    }
    for path in profiles:
        profile = json.loads(path.read_text(encoding="utf-8"))
        region = str(profile["region_id"])
        if region not in region_to_gpu:
            continue
        gpu = region_to_gpu[region]
        rows = by_gpu[gpu]
        x, y = [], []
        for row in rows:
            prompt = int(row["prompt_tokens"])
            cached = prompt if row["mode"] == "warm" else 0
            x.append([1.0, prompt - cached, cached, int(row["output_tokens"])])
            y.append(float(row["dynamic_energy_j"]))
        beta = nonnegative_least_squares(np.asarray(x), np.asarray(y))
        latency_rows = [
            row for row in concurrency_rows
            if int(row["gpu_index"]) == gpu and int(row["concurrency"]) == 1
        ]
        tx, ty, tpots = [], [], []
        # Preserve the validated low-context fit as pseudo-observations, then
        # anchor its extrapolation with the new physical long-context samples.
        for prompt in (512, 2048, 8192, 16384):
            for cached in (0, prompt):
                tx.append([1.0, prompt - cached, cached])
                ty.append(
                    float(profile["base_ttft_ms"])
                    + (prompt - cached) * float(profile["cold_prefill_ms_per_token"])
                    + cached * float(profile["cached_prefill_ms_per_token"])
                )
        for row in latency_rows:
            prompt = int(row["prompt_tokens"])
            cached = prompt if row["mode"] == "warm" else 0
            tx.append([1.0, prompt - cached, cached])
            ty.append(float(row["ttft_p95_ms"]))
            tpots.append(float(row["tpot_p95_ms"]))
        ttft_beta = nonnegative_least_squares(np.asarray(tx), np.asarray(ty))
        profile.update({
            "base_request_j": float(beta[0]),
            "cold_prefill_j_per_token": float(beta[1]),
            "cached_prefill_j_per_token": float(beta[2]),
            "decode_j_per_token": float(beta[3]),
            "base_ttft_ms": float(ttft_beta[0]),
            "cold_prefill_ms_per_token": float(ttft_beta[1]),
            "cached_prefill_ms_per_token": float(ttft_beta[2]),
            "base_tpot_ms": statistics.median(tpots),
            "active_ttft_ms_per_request": 0.0,
            "tpot_ms_per_active_request": 0.0,
            **slopes,
            "uncertainty_margin": 1.0,
            "max_prompt_tokens": 30000,
            "max_output_tokens": 512,
            "max_concurrency": 8,
            "batch_energy_model": model,
        })
        path.write_text(json.dumps(profile, indent=2), encoding="utf-8")
        report["profiles"][region] = {
            "gpu": gpu,
            "energy_beta": [float(value) for value in beta],
            "ttft_beta": [float(value) for value in ttft_beta],
            "base_tpot_ms": profile["base_tpot_ms"],
            "energy_samples": len(rows),
            "latency_samples": len(latency_rows),
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
