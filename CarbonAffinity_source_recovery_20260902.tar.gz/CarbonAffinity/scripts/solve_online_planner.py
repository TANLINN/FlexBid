from __future__ import annotations

import argparse
from pathlib import Path

from carbonaffinity.offline_oracle import OracleProblem
from carbonaffinity.online_planner import (
    OnlinePlannerSettings,
    solution_json,
    solve_online,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--horizon-epochs", type=int, default=0)
    parser.add_argument("--max-price-iterations", type=int, default=32)
    parser.add_argument("--time-budget-ms", type=float, default=100.0)
    parser.add_argument("--initial-step-g", type=float, default=0.01)
    parser.add_argument(
        "--continuation-mode",
        choices=("none", "learned_future", "trace_horizon"),
        default="none",
    )
    args = parser.parse_args()
    problem = OracleProblem.from_json(args.input)
    solution = solve_online(
        problem,
        OnlinePlannerSettings(
            horizon_epochs=args.horizon_epochs,
            max_price_iterations=args.max_price_iterations,
            time_budget_ms=args.time_budget_ms,
            initial_step_g=args.initial_step_g,
            continuation_mode=args.continuation_mode,
        ),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(solution_json(solution), encoding="utf-8")
    print("status =", solution.status)
    print("objective_carbon_g =", f"{solution.cost.objective_carbon_g:.9f}")
    print("migrations =", solution.cost.migrations)
    print("max_planner_time_ms =", f"{solution.max_planner_time_ms:.3f}")
    print("budget_exhausted_epochs =", solution.budget_exhausted_epochs)
    print("ONLINE_PLANNER_COMPLETE =", args.output.resolve())


if __name__ == "__main__":
    main()
