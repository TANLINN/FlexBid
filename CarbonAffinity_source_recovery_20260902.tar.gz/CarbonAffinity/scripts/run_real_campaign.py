from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path


PAIR_GPUS = ((0, 1), (2, 3), (4, 5), (6, 7))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--repetitions", type=int, default=1)
    parser.add_argument("--seed", type=int, default=20260818)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    args.output_root.mkdir(parents=True, exist_ok=True)
    all_failures = []
    for repetition in range(args.repetitions):
        repetition_root = args.output_root / f"rep_{repetition:02d}"
        repetition_root.mkdir(parents=True, exist_ok=True)
        running = []
        for index, (gpu_a, gpu_b) in enumerate(PAIR_GPUS):
            output = repetition_root / f"window_{index:02d}"
            if (output / "PIPELINE_COMPLETE.json").exists():
                continue
            log_path = repetition_root / f"window_{index:02d}.launcher.log"
            log = log_path.open("a", encoding="utf-8")
            command = [
                sys.executable, str(root / "scripts/run_local_pair_campaign.py"),
                "--config", str(root / f"configs/real_window_{index:02d}.generated.yaml"),
                "--output-root", str(output), "--gpu-a", str(gpu_a), "--gpu-b", str(gpu_b),
                "--policy-order-seed", str(args.seed + repetition * 4 + index),
            ]
            running.append((index, subprocess.Popen(command, cwd=root, stdout=log, stderr=subprocess.STDOUT), log))
        failures = []
        for index, process, log in running:
            code = process.wait()
            log.close()
            if code:
                failures.append({"window": index, "return_code": code})
        if failures:
            failure_marker = repetition_root / "WINDOW_FAILURES.json"
            failure_marker.write_text(json.dumps(failures, indent=2), encoding="utf-8")
            all_failures.extend({"repetition": repetition, **failure} for failure in failures)
            print(f"real-data repetition {repetition} has failures; continuing: {failures}")
            continue
        (repetition_root / "WINDOW_FAILURES.json").unlink(missing_ok=True)
        (repetition_root / "REPETITION_COMPLETE.json").write_text(json.dumps({"repetition": repetition, "completed_s": time.time()}, indent=2), encoding="utf-8")
    if all_failures:
        failure_manifest = args.output_root / "FAILED_WINDOWS.json"
        failure_manifest.write_text(json.dumps(all_failures, indent=2), encoding="utf-8")
        partial_marker = args.output_root / "CAMPAIGN_PARTIAL.json"
        partial_marker.write_text(json.dumps({"failures": all_failures, "completed_s": time.time()}, indent=2), encoding="utf-8")
        print(f"CAMPAIGN_PARTIAL={partial_marker}")
        return
    (args.output_root / "FAILED_WINDOWS.json").unlink(missing_ok=True)
    (args.output_root / "CAMPAIGN_PARTIAL.json").unlink(missing_ok=True)
    marker = args.output_root / "REAL_CAMPAIGN_COMPLETE.json"
    marker.write_text(json.dumps({"repetitions": args.repetitions, "completed_s": time.time()}, indent=2), encoding="utf-8")
    print(f"REAL_CAMPAIGN_COMPLETE={marker}")


if __name__ == "__main__":
    main()
