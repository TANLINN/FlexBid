"""Derive a self-contained shape-prewarm diagnostic from the unchanged probe."""
import hashlib
from pathlib import Path

BASE_SHA256 = "4a2a5d9ceee4023170177ed100ba57f30876ee46a77f35ca11bf16d75af83f90"
PROJECT = Path(__file__).resolve().parents[1]


def make_source(base):
    if hashlib.sha256(base.encode()).hexdigest() != BASE_SHA256:
        raise ValueError("base probe changed; review before generating new launcher")
    support = (PROJECT / "scripts/latency_shape_probe_support.py").read_text(encoding="utf-8")
    compile(support, "embedded_shape_probe", "exec")

    def replace(old, new):
        nonlocal base
        if base.count(old) != 1:
            raise ValueError(f"expected one launcher anchor: {old!r}")
        base = base.replace(old, new, 1)

    replace("export PYTHONNOUSERSITE=1\n", "export PYTHONNOUSERSITE=1\n"
            "export TRITON_PRINT_AUTOTUNING=1\nexport PYTHONUNBUFFERED=1\n")
    replace("    'diagnostic_only': True, 'prior_failed_validation': str(prior.resolve()),",
            "    'fixed_shape_prewarm': {'prompts': [16,32,64,2048], 'passes': 2, 'output': 64},\n"
            "    'prewarm_missing_cache_allowed_prompts': [16,32,64,2048],\n"
            "    'prewarm_cache_observation_policy': 'optional_for_shape_prewarm; formal cache checks unchanged',\n"
            "    'prewarm_null_cache_semantics': 'unknown, not observed zero; unique request salt',\n"
            "    'diagnostic_ttft_spike_threshold_ms': 2000, 'threshold_is_service_slo': False,\n"
            "    'TRITON_PRINT_AUTOTUNING': '1', 'PYTHONUNBUFFERED': '1',\n"
            "    'diagnostic_only': True, 'prior_failed_validation': str(prior.resolve()),")
    prewarm = '''PROBE_STAGE=fixed_shape_prewarm
setsid .venv/bin/python -u - prewarm "$PROBE_ROOT" > "$PROBE_ROOT/shape_prewarm.log" 2>&1 <<'SHAPE_PY' &
''' + support + '''
SHAPE_PY
PREWARM_PID=$!
OWNED_PGIDS+=("$PREWARM_PID")
DEADLINE=$((SECONDS + 900))
while kill -0 "$PREWARM_PID" 2>/dev/null; do
    for pid in "${SERVER_PIDS[@]}"; do kill -0 "$pid"; done
    kill -0 "$TELEMETRY_PID"
    [[ "$SECONDS" -lt "$DEADLINE" ]] || { echo "SHAPE_PREWARM_TIMEOUT"; exit 1; }
    sleep 2
done
wait "$PREWARM_PID"
echo "FIXED_SHAPE_PREWARM_PASS"
PROBE_STAGE=measurement
'''
    replace("PROBE_STAGE=measurement\n", prewarm)
    # Gate completion only after the read-only post-prewarm audit succeeds.
    anchor = "write_json(root / 'EXPERIMENT_COMPLETE.json',"
    replace(anchor, "import subprocess\nsubprocess.run([sys.executable, '-c', "
            + repr(support) + ", 'audit', str(root)], check=True)\n" + anchor)
    return base
