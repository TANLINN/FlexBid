from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path


EXPECTED_MODEL_SHA256 = "77c64eadbba261430ab205d1d455e3fc3abe92e682363888e583059db216bf0f"
EXPECTED_VALIDATION_SHA256 = "24731d1b676049bc9e946c0567dd9cda3d1d2c606d169ab93309bff4d0a2089b"
TARGET_PROFILES = {
    "burst_a.json", "burst_b.json",
    "high_reuse_a.json", "high_reuse_b.json",
    "local_region_a.json", "local_region_b.json",
    "low_reuse_a.json", "low_reuse_b.json",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def patched_profile_source(source: str) -> str:
    if "latency_surface_model" in source or "estimate_latency_surface" in source:
        raise RuntimeError("profile.py already contains a latency-surface patch")
    import_anchor = "from .models import RequestSpec, RegionSnapshot\n"
    if source.count(import_anchor) != 1:
        raise RuntimeError("profile import anchor not found exactly once")
    source = source.replace(
        import_anchor,
        import_anchor + "from .latency_surface import estimate_latency_surface\n",
        1,
    )
    field_pattern = re.compile(
        r"(?m)^(    batch_energy_model:[^\n]*\n)"
    )
    if len(field_pattern.findall(source)) != 1:
        raise RuntimeError("batch_energy_model field anchor not found exactly once")
    source = field_pattern.sub(
        r"\1    latency_surface_model: dict | None = None\n",
        source,
        count=1,
    )
    estimate_at = source.find("    def estimate(")
    if estimate_at < 0:
        raise RuntimeError("estimate method not found")
    latency_start = source.find("        ttft = (\n", estimate_at)
    return_start = source.find("        return ServiceEstimate(\n", latency_start)
    if latency_start < 0 or return_start < 0:
        raise RuntimeError("legacy latency block boundaries not found")
    legacy = source[latency_start:return_start]
    if legacy.count("        ttft = (") != 1 or legacy.count("        tpot = (") != 1:
        raise RuntimeError("legacy latency block is structurally unexpected")
    indented_legacy = "".join(
        "    " + line if line.strip() else line
        for line in legacy.splitlines(keepends=True)
    )
    replacement = (
        "        surface_latency = estimate_latency_surface(\n"
        "            self.latency_surface_model,\n"
        "            request.prompt_tokens,\n"
        "            cached,\n"
        "            snapshot.active_requests + 1,\n"
        "        )\n"
        "        if surface_latency is None:\n"
        + indented_legacy
        + "        else:\n"
        "            ttft, tpot = surface_latency\n"
        "            ttft = (\n"
        "                ttft\n"
        "                + snapshot.queue_depth * self.queue_ttft_ms_per_request\n"
        "                + snapshot.rtt_ms\n"
        "            ) * self.uncertainty_margin\n"
        "            tpot = tpot * self.uncertainty_margin\n"
    )
    return source[:latency_start] + replacement + source[return_start:]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--validation-report", type=Path, required=True)
    parser.add_argument("--profiles", type=Path, required=True)
    parser.add_argument("--latency-module", type=Path, required=True)
    args = parser.parse_args()

    if sha256(args.model) != EXPECTED_MODEL_SHA256:
        raise RuntimeError("candidate model SHA256 mismatch")
    if sha256(args.validation_report) != EXPECTED_VALIDATION_SHA256:
        raise RuntimeError("validation report SHA256 mismatch")
    model = json.loads(args.model.read_text(encoding="utf-8"))
    validation = json.loads(args.validation_report.read_text(encoding="utf-8"))
    if validation.get("status") != "PASS":
        raise RuntimeError("independent validation did not pass")
    if validation.get("model_sha256") != EXPECTED_MODEL_SHA256:
        raise RuntimeError("validation report refers to another model")
    if not all(validation.get("checks", {}).values()):
        raise RuntimeError("one or more independent validation checks failed")

    root = Path.cwd()
    profile_source_path = root / "carbonaffinity/profile.py"
    latency_destination = root / "carbonaffinity/latency_surface.py"
    profile_paths = sorted(
        args.profiles / name for name in TARGET_PROFILES
    )
    missing_profiles = [path for path in profile_paths if not path.is_file()]
    if missing_profiles:
        raise RuntimeError(f"missing hardware profiles: {missing_profiles}")

    original_source = profile_source_path.read_text(encoding="utf-8")
    new_source = patched_profile_source(original_source)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup = root / "results" / f"latency_surface_install_backup_{stamp}"
    freeze = root / "results" / f"latency_surface_runtime_frozen_{stamp}"
    (backup / "profiles").mkdir(parents=True)
    (freeze / "profiles").mkdir(parents=True)
    shutil.copy2(profile_source_path, backup / "profile.py")
    for path in profile_paths:
        shutil.copy2(path, backup / "profiles" / path.name)
    (backup / "SOURCE_SHA256SUMS.json").write_text(json.dumps({
        "profile.py": sha256(profile_source_path),
        **{f"profiles/{path.name}": sha256(path) for path in profile_paths},
    }, indent=2), encoding="utf-8")

    shutil.copy2(args.latency_module, latency_destination)
    temporary_source = profile_source_path.with_suffix(".py.installing")
    temporary_source.write_text(new_source, encoding="utf-8")
    os.replace(temporary_source, profile_source_path)

    for path in profile_paths:
        before = json.loads(path.read_text(encoding="utf-8"))
        after = dict(before)
        after["latency_surface_model"] = model
        if {key: value for key, value in after.items() if key != "latency_surface_model"} != before:
            raise RuntimeError(f"non-latency profile field changed for {path}")
        temporary = path.with_suffix(".json.installing")
        temporary.write_text(json.dumps(after, indent=2), encoding="utf-8")
        os.replace(temporary, path)

    shutil.copy2(profile_source_path, freeze / "profile.py")
    shutil.copy2(latency_destination, freeze / "latency_surface.py")
    shutil.copy2(args.model, freeze / "latency_surface_candidate.json")
    shutil.copy2(args.validation_report, freeze / "independent_validation_report.json")
    for path in profile_paths:
        shutil.copy2(path, freeze / "profiles" / path.name)
    manifest = {
        "schema_version": 1,
        "status": "VALIDATED_AND_INSTALLED",
        "model_sha256": EXPECTED_MODEL_SHA256,
        "validation_sha256": EXPECTED_VALIDATION_SHA256,
        "backup": str(backup.resolve()),
        "files": {
            str(path.relative_to(freeze)): sha256(path)
            for path in sorted(freeze.rglob("*")) if path.is_file()
        },
    }
    (freeze / "INSTALL_MANIFEST.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    (root / "results/latency_surface_install_backup_latest.txt").write_text(
        str(backup.resolve()), encoding="utf-8"
    )
    (root / "results/latency_surface_runtime_latest.txt").write_text(
        str(freeze.resolve()), encoding="utf-8"
    )
    print("LATENCY_SURFACE_RUNTIME_INSTALL_COMPLETE")
    print(f"BACKUP={backup.resolve()}")
    print(f"FROZEN={freeze.resolve()}")


if __name__ == "__main__":
    main()
