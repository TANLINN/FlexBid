"""Run the N2/N3 cache-residency frontier from a verified N4 runtime."""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
from pathlib import Path
from types import ModuleType

GPU = 3
PORT = 18003
PROMPT_TOKENS = 31_744
EXPECTED_CACHED_TOKENS = 31_360
PROBE_OUTPUT_TOKENS = 64
SESSIONS = (0, 1, 2)
MODEL_NAME = "Qwen3.5-27B"


def branch_specs() -> tuple[dict[str, object], ...]:
    return (
        {"branch_id": "concurrent_n2", "prime_indices": (0, 1)},
        {"branch_id": "concurrent_n3", "prime_indices": SESSIONS},
    )


def exact_hit(record: dict[str, object]) -> bool:
    value = record.get("cached_prompt_tokens_observed")
    return type(value) is int and value == EXPECTED_CACHED_TOKENS


def classify(branches: list[dict[str, object]]) -> str:
    by_id = {str(branch["branch_id"]): branch for branch in branches}
    n2 = by_id["concurrent_n2"]["probe_results"]
    n3 = by_id["concurrent_n3"]["probe_results"]
    n2_all_hit = len(n2) == 2 and all(exact_hit(record) for record in n2)
    n3_all_hit = len(n3) == 3 and all(exact_hit(record) for record in n3)
    if not n2_all_hit and n3_all_hit:
        return "SINGLE_GPU_LONG_WARM_CONCURRENCY_NON_MONOTONE_INCONCLUSIVE"
    if not n2_all_hit:
        return "SINGLE_GPU_LONG_WARM_CONCURRENCY_BELOW_2"
    if n3_all_hit:
        return "SINGLE_GPU_LONG_WARM_CONCURRENCY_AT_LEAST_3"
    return "SINGLE_GPU_LONG_WARM_CONCURRENCY_2_ONLY"


def load_legacy(path: Path) -> ModuleType:
    spec = importlib.util.spec_from_file_location(
        "cache_residency_verified_runtime", path
    )
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load verified runtime: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    expected = {
        "GPU": GPU,
        "PORT": PORT,
        "PROMPT_TOKENS": PROMPT_TOKENS,
        "EXPECTED_CACHED_TOKENS": EXPECTED_CACHED_TOKENS,
        "PROBE_OUTPUT_TOKENS": PROBE_OUTPUT_TOKENS,
    }
    for name, value in expected.items():
        if getattr(module, name, None) != value:
            raise RuntimeError(
                f"verified runtime {name}={getattr(module, name, None)!r}; "
                f"expected {value!r}"
            )
    for name in (
        "physical_reset",
        "completion_record",
        "request_errors",
        "write_json",
        "run",
    ):
        if not callable(getattr(module, name, None)):
            raise RuntimeError(f"verified runtime missing callable: {name}")
    source = path.read_text(errors="replace")
    for anchor in (
        "log_offset",
        "engine_success",
        "engine_failure",
        "VLLM_SERVER_DEV_MODE",
    ):
        if anchor not in source:
            raise RuntimeError(f"verified reset runtime missing: {anchor}")
    return module


async def run_frontier(
    legacy: ModuleType,
    root: Path,
    model_dir: Path,
    model_name: str,
) -> list[dict[str, object]]:
    from carbonaffinity.materialize import PromptMaterializer
    from carbonaffinity.models import RequestSpec
    from carbonaffinity.region import RegionClient

    materializer = PromptMaterializer(str(model_dir))
    prompts: list[list[int]] = []
    salts: list[str] = []
    for index in SESSIONS:
        session = f"residency-session-{index}"
        prompts.append(materializer.tokens({
            "request_id": session,
            "session_id": session,
            "prompt_tokens": PROMPT_TOKENS,
            "shared_prefix_tokens": 0,
        }))
        salts.append(f"cache-residency-v1:{session}")

    client = RegionClient({
        "id": f"gpu_{GPU}",
        "api_base": f"http://127.0.0.1:{PORT}/v1",
        "api_key": "EMPTY",
        "model": model_name,
        "admission_concurrency": len(SESSIONS),
    }, 300)
    branches: list[dict[str, object]] = []
    try:
        for spec in branch_specs():
            branch_id = str(spec["branch_id"])
            indices = tuple(spec["prime_indices"])
            branch: dict[str, object] = {
                "branch_id": branch_id,
                "prime_order": list(indices),
                "probe_indices": list(indices),
                "prompt_tokens": PROMPT_TOKENS,
                "expected_cached_tokens": EXPECTED_CACHED_TOKENS,
                "prime_results": [],
                "probe_results": [],
                "integrity_valid": False,
            }
            output = root / "branches" / f"{branch_id}.json"
            try:
                branch["reset"] = await legacy.physical_reset(
                    f"http://127.0.0.1:{PORT}",
                    root / f"vllm_gpu_{GPU}.log",
                )
                if branch["reset"].get("confirmed") is not True:
                    raise RuntimeError(
                        "physical prefix-cache reset was not confirmed"
                    )
                await asyncio.sleep(0.2)
                for index in indices:
                    request = RequestSpec(
                        request_id=f"{branch_id}-prime-{index}",
                        arrival_ms=0,
                        prompt_tokens=PROMPT_TOKENS,
                        max_output_tokens=1,
                        session_id=f"residency-session-{index}",
                    )
                    record = await legacy.completion_record(
                        client, request, prompts[index], salts[index], index
                    )
                    branch["prime_results"].append(record)
                    errors = legacy.request_errors(record, 1)
                    if errors:
                        raise RuntimeError(f"prime {index} failed: {errors}")
                await asyncio.sleep(2.0)

                async def probe(index: int) -> dict[str, object]:
                    request = RequestSpec(
                        request_id=f"{branch_id}-probe-{index}",
                        arrival_ms=0,
                        prompt_tokens=PROMPT_TOKENS,
                        max_output_tokens=PROBE_OUTPUT_TOKENS,
                        session_id=f"residency-session-{index}",
                    )
                    record = await legacy.completion_record(
                        client, request, prompts[index], salts[index], index
                    )
                    record["exact_expected_cache"] = exact_hit(record)
                    return record

                branch["probe_results"] = await asyncio.gather(
                    *(probe(index) for index in indices)
                )
                failures = [
                    {
                        "session_index": record["session_index"],
                        "errors": legacy.request_errors(
                            record, PROBE_OUTPUT_TOKENS
                        ),
                    }
                    for record in branch["probe_results"]
                    if legacy.request_errors(record, PROBE_OUTPUT_TOKENS)
                ]
                if failures:
                    raise RuntimeError(f"probe integrity failed: {failures}")
                branch["integrity_valid"] = True
            except Exception as exc:
                branch["error"] = f"{type(exc).__name__}: {exc}"
            legacy.write_json(output, branch)
            branches.append(branch)
            print(
                branch_id,
                [
                    record.get("cached_prompt_tokens_observed")
                    for record in branch["probe_results"]
                ],
                flush=True,
            )
            if not branch["integrity_valid"]:
                raise RuntimeError(branch["error"])
    finally:
        await client.close()
    return branches


def install_frontier(legacy: ModuleType) -> None:
    original_write_json = legacy.write_json

    def frontier_write_json(path: Path, value: object) -> None:
        path = Path(path)
        if path.name == "RUN.json" and isinstance(value, dict):
            value = dict(value)
            value["stage"] = "single-gpu-long-prefix-residency-frontier"
            if "source_failed_run" in value:
                value["source_residency_run"] = value.pop("source_failed_run")
        if path.name in {
            "RESIDENCY_DIAGNOSIS.json",
            "RESIDENCY_DIAGNOSTIC.json",
        }:
            path = path.with_name("RESIDENCY_FRONTIER.json")
        original_write_json(path, value)

    async def installed_run_diagnostic(
        root: Path, model_dir: Path, model_name: str
    ) -> list[dict[str, object]]:
        return await run_frontier(
            legacy, root, model_dir, model_name
        )

    legacy.SESSIONS = SESSIONS
    legacy.branch_specs = branch_specs
    legacy.exact_hit = exact_hit
    legacy.classify = classify
    legacy.run_diagnostic = installed_run_diagnostic
    legacy.write_json = frontier_write_json


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--legacy-source", type=Path, required=True)
    parser.add_argument(
        "--project-root", type=Path, default=Path("/root/CarbonAffinity")
    )
    parser.add_argument(
        "--model-dir", type=Path, default=Path("/root/models/Qwen3.5-27B")
    )
    parser.add_argument("--model-name", default=MODEL_NAME)
    parser.add_argument("--support-file", type=Path, required=True)
    parser.add_argument("--source-residency-run", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    legacy = load_legacy(args.legacy_source.resolve())
    install_frontier(legacy)
    legacy_args = argparse.Namespace(
        project_root=args.project_root,
        model_dir=args.model_dir,
        model_name=args.model_name,
        support_file=args.support_file,
        source_failed_run=args.source_residency_run,
        output_root=args.output_root,
    )
    legacy.run(legacy_args)
    report = args.output_root / "RESIDENCY_FRONTIER.json"
    if not report.is_file():
        raise RuntimeError(f"frontier result was not created: {report}")
    print("CACHE_RESIDENCY_FRONTIER_COMPLETE =", args.output_root, flush=True)


if __name__ == "__main__":
    main()
