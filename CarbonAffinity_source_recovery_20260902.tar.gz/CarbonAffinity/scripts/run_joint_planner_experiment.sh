#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUTPUT="${1:?usage: run_joint_planner_experiment.sh OUTPUT_ROOT}"
cd "$ROOT"
mkdir -p "$OUTPUT"
printf '%s\n' "$$" > "$OUTPUT/supervisor.pid"
printf '{"status":"RUNNING","started_s":%s}\n' \
  "$(date +%s)" > "$OUTPUT/EXPERIMENT_RUNNING.json"

if [[ -x .venv/bin/python ]]; then
  PYTHON_BIN="$ROOT/.venv/bin/python"
else
  PYTHON_BIN="$(command -v python)"
fi
export PYTHONPATH="$ROOT"

on_error() {
  local rc=$?
  printf '{"status":"FAILED","exit_code":%s,"failed_s":%s}\n' \
    "$rc" "$(date +%s)" > "$OUTPUT/SWEEP_FATAL.json"
  exit "$rc"
}
trap on_error ERR

"$PYTHON_BIN" scripts/install_eight_region_support.py
"$PYTHON_BIN" scripts/prepare_eight_region_development.py

"$PYTHON_BIN" -m unittest discover \
  -s tests -p 'test_online_planner.py' -v \
  > "$OUTPUT/unit_tests.log" 2>&1
"$PYTHON_BIN" -m unittest discover \
  -s tests -p 'test_offline_oracle.py' -v \
  >> "$OUTPUT/unit_tests.log" 2>&1
"$PYTHON_BIN" -m unittest discover \
  -s tests -p 'test_oracle_problem_builder.py' -v \
  >> "$OUTPUT/unit_tests.log" 2>&1

"$PYTHON_BIN" -u scripts/run_joint_planner_sweep.py \
  --output-root "$OUTPUT" \
  --windows 0 1 2 3 \
  --region-counts 2 4 8 \
  --request-counts 8 16 24 32 48 64 \
  --epoch-ms 250 1000 5000 \
  --time-budgets-ms 5 20 100 \
  --horizon-epochs 4 \
  --exact-timeout-s 180 \
  --max-states 500000

"$PYTHON_BIN" scripts/summarize_joint_planner_sweep.py \
  --input "$OUTPUT/summary.jsonl" \
  --output "$OUTPUT/SWEEP_REPORT.json" \
  | tee "$OUTPUT/SWEEP_REPORT.txt"

"$PYTHON_BIN" - "$OUTPUT/SWEEP_REPORT.json" <<'PY'
import json
import sys

report = json.load(open(sys.argv[1], encoding="utf-8"))
overall = report["overall"]
assert overall["records"] == 1296, overall
assert overall["passed"] == 1296, overall
assert overall["failed"] == 0, overall
assert overall["max_planner_time_ms"]["median"] is not None, overall
print("JOINT_PLANNER_SWEEP_INTEGRITY_PASS")
PY

printf '{"status":"COMPLETE","completed_s":%s}\n' \
  "$(date +%s)" > "$OUTPUT/EXPERIMENT_COMPLETE.json"
echo "JOINT_PLANNER_EXPERIMENT_COMPLETE=$OUTPUT"
