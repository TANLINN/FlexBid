from __future__ import annotations

import json
from pathlib import Path

from carbonaffinity.models import RegionSnapshot, RequestSpec
from carbonaffinity.profile import HardwareProfile


TARGETS = (
    "burst_a.json", "burst_b.json",
    "high_reuse_a.json", "high_reuse_b.json",
    "local_region_a.json", "local_region_b.json",
    "low_reuse_a.json", "low_reuse_b.json",
)


def main() -> None:
    root = Path.cwd()
    backup = Path(
        (root / "results/latency_surface_install_backup_latest.txt")
        .read_text(encoding="utf-8").strip()
    )
    for name in TARGETS:
        old = json.loads((backup / "profiles" / name).read_text(encoding="utf-8"))
        current_path = root / "profiles" / name
        current = json.loads(current_path.read_text(encoding="utf-8"))
        latency = current.pop("latency_surface_model", None)
        assert latency is not None, name
        assert current == old, f"non-latency profile drift: {name}"
        profile = HardwareProfile.from_json(current_path)
        request = RequestSpec(
            request_id="latency-runtime-check",
            arrival_ms=0,
            prompt_tokens=8192,
            max_output_tokens=64,
            session_id="latency-runtime-check",
            shared_prefix_tokens=4096,
        )
        estimate = profile.estimate(
            request,
            4096,
            RegionSnapshot(
                region_id=profile.region_id,
                active_requests=3,
                queue_depth=1,
                rtt_ms=20,
                capacity=8,
            ),
        )
        assert estimate.energy_j > 0
        assert estimate.ttft_ms > 20
        assert estimate.tpot_ms > 0
        print(
            name,
            f"energy_j={estimate.energy_j:.3f}",
            f"ttft_ms={estimate.ttft_ms:.3f}",
            f"tpot_ms={estimate.tpot_ms:.3f}",
        )
    print("LATENCY_SURFACE_RUNTIME_VERIFY_PASS")


if __name__ == "__main__":
    main()
