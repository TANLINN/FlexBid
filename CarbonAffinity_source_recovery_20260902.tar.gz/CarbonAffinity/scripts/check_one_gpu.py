from __future__ import annotations

import argparse
import importlib
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path


def command(args: list[str]) -> dict:
    result = subprocess.run(args, text=True, capture_output=True)
    return {"command": args, "return_code": result.returncode, "stdout": result.stdout.strip(), "stderr": result.stderr.strip()}


def main() -> None:
    parser = argparse.ArgumentParser(description="Single-A800 environment and artifact precheck")
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    imports = {}
    for name in ("httpx", "yaml", "numpy", "pynvml", "transformers", "torch", "vllm"):
        try:
            module = importlib.import_module(name)
            imports[name] = {"ok": True, "version": getattr(module, "__version__", None)}
        except Exception as exc:
            imports[name] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    report = {
        "schema_version": 1,
        "timestamp_s": time.time(),
        "python": sys.version,
        "executables": {name: shutil.which(name) for name in ("python", "vllm", "nvidia-smi")},
        "imports": imports,
        "gpu": command([
            "nvidia-smi", "--query-gpu=index,name,uuid,memory.total,driver_version,power.draw,power.limit,power.default_limit,power.min_limit,power.max_limit",
            "--format=csv,noheader,nounits",
        ]),
        "compute_processes": command([
            "nvidia-smi", "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
            "--format=csv,noheader,nounits",
        ]),
        "vllm_version": command(["vllm", "--version"]) if shutil.which("vllm") else None,
        "disk": command(["df", "-h", str(args.model_dir.parent)]),
        "model_dir": str(args.model_dir.resolve()),
        "model_config_present": (args.model_dir / "config.json").is_file(),
    }
    gpu_text = report["gpu"]["stdout"]
    checks = {
        "nvidia_smi_ok": report["gpu"]["return_code"] == 0,
        "one_or_more_a800": "A800" in gpu_text,
        "vllm_available": bool(shutil.which("vllm")) and imports["vllm"]["ok"],
        "runtime_dependencies": all(imports[name]["ok"] for name in ("httpx", "yaml", "numpy", "pynvml", "transformers", "torch")),
        "model_config_present": report["model_config_present"],
    }
    report["checks"] = checks
    report["passed"] = all(checks.values())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report["passed"] else 2)


if __name__ == "__main__":
    main()

