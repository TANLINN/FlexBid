"""Collect exact cache/residual observations, preserving every completed result."""
import argparse
import asyncio
import json
import time
import uuid
from dataclasses import asdict
from pathlib import Path

from carbonaffinity.artifacts import write_json
from carbonaffinity.models import RequestSpec
from scripts.latency_residual_protocol import OUTPUT, VERSION, cases, features, result_checks


async def collect(args, materializer, client, *, case_grid=None, protocol=VERSION):
    output = args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    namespace = uuid.uuid4().hex
    # Exclusive create: no silent resume and no overwrite of failed observations.
    with output.open("x", encoding="utf-8") as handle:
        for case in cases() if case_grid is None else case_grid:
            identity = f"residual-{args.gpu_index}-{case['case_id']}"
            prompt_tokens = case["prompt_tokens"]
            if not await client.reset_prefix_cache():
                raise RuntimeError("prefix-cache reset failed")
            salt = f"{namespace}:{identity}"
            common = materializer.tokens({"request_id": identity, "prompt_tokens": prompt_tokens,
                                          "shared_prefix_tokens": 0})
            prime_record = None
            if case["mode"] == "warm":
                prime = RequestSpec(identity + "-prime", 0, prompt_tokens, 1, identity)
                result = await client.complete(prime, common, cache_salt=salt)
                prime_record = asdict(result)
                checks = result_checks(prime_record, prompt_tokens, 1)
                write_json(output.parent / "primes" / (case["case_id"] + ".json"),
                           {"result": prime_record, "checks": checks, "cache_salt": salt})
                if not all(checks.values()):
                    raise RuntimeError("warm prime failed: " + json.dumps(checks))
            jobs = []
            salts = []
            for index in range(case["concurrency"]):
                request_id = f"{identity}-{index}"
                request = RequestSpec(request_id, 0, prompt_tokens, OUTPUT, request_id)
                warm = case["mode"] == "warm"
                prompt = common if warm else materializer.tokens(
                    {"request_id": request_id, "prompt_tokens": prompt_tokens, "shared_prefix_tokens": 0})
                request_salt = salt if warm else f"{salt}:{index}"
                salts.append(request_salt)
                jobs.append(client.complete(request, prompt, cache_salt=request_salt))
            start = time.time_ns()
            results = await asyncio.gather(*jobs, return_exceptions=True)
            records = [asdict(r) if not isinstance(r, BaseException) else
                       {"success": False, "error": f"{type(r).__name__}: {r}"} for r in results]
            checks = [result_checks(r, prompt_tokens, OUTPUT,
                      case["cached_context_target"] if case["mode"] == "warm" else None) for r in records]
            row = {"schema_version": 1, "protocol": protocol, **case, "gpu_index": args.gpu_index,
                   "started_wall_time_ns": start, "completed_wall_time_ns": time.time_ns(),
                   "results": records, "result_checks": checks, "cache_salts": salts,
                   "cache_features": [features(r) for r in records], "prime": prime_record,
                   "runtime_evidence_sha256": args.runtime_evidence,
                   "requested_context_and_residual_are_not_measured_cache": True}
            handle.write(json.dumps(row, allow_nan=False) + "\n")
            handle.flush()
            print(f"GPU {args.gpu_index} CASE={case['case_id']} pass={all(all(c.values()) for c in checks)}", flush=True)
            if not all(all(c.values()) for c in checks):
                raise RuntimeError("measured case failed checks; raw row retained: " + json.dumps(checks))
            await asyncio.sleep(.5)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu-index", type=int, required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--runtime-evidence", required=True)
    args = parser.parse_args()
    from carbonaffinity.materialize import PromptMaterializer
    from carbonaffinity.region import RegionClient

    async def run():
        client = RegionClient({"id": f"gpu_{args.gpu_index}", "api_base": args.api_base,
                               "model": args.model, "admission_concurrency": 8}, 300)
        try:
            await collect(args, PromptMaterializer(args.tokenizer), client)
        finally:
            await client.close()
    asyncio.run(run())


if __name__ == "__main__":
    main()
