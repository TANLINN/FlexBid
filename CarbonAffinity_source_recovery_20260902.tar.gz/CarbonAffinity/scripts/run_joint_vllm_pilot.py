from __future__ import annotations

import argparse
import asyncio
import json
import signal
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from carbonaffinity.audit import audit_results
from carbonaffinity.carbon import CarbonTrace
from carbonaffinity.config import load_config, resolve_path
from carbonaffinity.region import RegionClient
from carbonaffinity.replay import run_replay


def carbon_start(config: dict) -> float:
    value = config["carbon"]["trace_start_timestamp"]
    if isinstance(value, (int, float)):
        return float(value)
    return datetime.fromisoformat(
        str(value).replace("Z", "+00:00")
    ).timestamp()


def crop_trace(source: Path, destination: Path, limit: int) -> list[dict]:
    rows = [
        json.loads(line)
        for line in source.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    rows.sort(key=lambda row: (float(row["arrival_ms"]), str(row["request_id"])))
    rows = rows[:limit]
    destination.write_text(
        "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows),
        encoding="utf-8",
    )
    return rows


async def stop_samplers(samplers: list[subprocess.Popen]) -> None:
    for sampler in samplers:
        if sampler.poll() is None:
            sampler.send_signal(signal.SIGINT)
    for sampler in samplers:
        try:
            sampler.wait(timeout=15)
        except subprocess.TimeoutExpired:
            sampler.terminate()
            sampler.wait(timeout=5)


async def main_async(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    regions = list(config["regions"])
    if len(regions) != 8 or len(args.gpu_indices) != 8:
        raise ValueError("joint vLLM pilot requires eight regions and GPUs")

    args.output_root.mkdir(parents=True, exist_ok=True)
    trace_source = resolve_path(config, config["experiment"]["trace"])
    pilot_trace = args.output_root / "pilot_trace.jsonl"
    rows = crop_trace(trace_source, pilot_trace, args.max_requests)

    raw_problem = args.output_root / "problem.raw.json"
    learned_problem = args.output_root / "problem.learned.json"
    solution_path = args.output_root / "joint_solution.json"

    commands = [
        [
            sys.executable,
            "scripts/build_offline_oracle_problem.py",
            "--config", str(args.config),
            "--output", str(raw_problem),
            "--max-requests", str(args.max_requests),
            "--epoch-ms", str(args.epoch_ms),
            "--region-limit", "8",
        ],
        [
            sys.executable,
            "scripts/annotate_learned_future_work.py",
            "--input", str(raw_problem),
            "--model", str(args.future_work_model),
            "--output", str(learned_problem),
        ],
        [
            sys.executable,
            "scripts/solve_online_planner.py",
            "--input", str(learned_problem),
            "--output", str(solution_path),
            "--continuation-mode", "learned_future",
            "--horizon-epochs", "0",
            "--max-price-iterations", "32",
            "--time-budget-ms", str(args.time_budget_ms),
        ],
    ]
    for command in commands:
        subprocess.run(
            command,
            cwd=Path(__file__).resolve().parents[1],
            env={**dict(__import__("os").environ), "PYTHONPATH": str(Path.cwd())},
            check=True,
        )

    solution = json.loads(solution_path.read_text())
    assignments = {
        request_id: region_id
        for step in solution["steps"]
        for request_id, region_id in step["assignments"]
    }
    expected_ids = {str(row["request_id"]) for row in rows}
    if set(assignments) != expected_ids:
        raise RuntimeError(
            f"assignment coverage mismatch: {len(assignments)} != {len(expected_ids)}"
        )
    if solution["budget_exhausted_epochs"] != 0:
        raise RuntimeError("joint planner exhausted its online time budget")

    clients = {region["id"]: RegionClient(region, 60.0) for region in regions}
    health = await asyncio.gather(*(client.healthy() for client in clients.values()))
    if not all(health):
        raise RuntimeError(
            "unhealthy vLLM regions: "
            + repr([
                region_id for region_id, ok in zip(clients, health) if not ok
            ])
        )
    reset = await asyncio.gather(
        *(client.reset_prefix_cache() for client in clients.values())
    )
    if not all(reset):
        raise RuntimeError("prefix-cache reset failed")

    telemetry: dict[str, Path] = {}
    samplers: list[subprocess.Popen] = []
    try:
        for region, gpu in zip(regions, args.gpu_indices):
            telemetry_path = args.output_root / f"{region['id']}_gpu.csv"
            telemetry[region["id"]] = telemetry_path
            samplers.append(
                subprocess.Popen([
                    sys.executable,
                    "-m", "carbonaffinity.telemetry",
                    "--output", str(telemetry_path),
                    "--gpu-index", str(gpu),
                    "--region-id", str(region["id"]),
                    "--interval-ms", "100",
                ])
            )
        await asyncio.sleep(2)
        requests_path = args.output_root / "requests.jsonl"
        await run_replay(
            config,
            pilot_trace,
            requests_path,
            forced_assignments=assignments,
            forced_policy_name="joint_learned_future",
        )
        await asyncio.sleep(2)
    finally:
        await stop_samplers(samplers)
        await asyncio.gather(*(client.close() for client in clients.values()))

    carbon = CarbonTrace.from_csv(
        resolve_path(config, config["carbon"]["trace"]),
        float(config["carbon"].get("max_age_s", 1800)),
    )
    report = audit_results(
        args.output_root / "requests.jsonl",
        telemetry,
        carbon,
        carbon_start(config),
    )
    (args.output_root / "audit.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    if not report["passed"] or report["requests"] != len(rows):
        raise RuntimeError(f"joint vLLM pilot audit failed: {report}")

    route_counts: dict[str, int] = {}
    for region in assignments.values():
        route_counts[region] = route_counts.get(region, 0) + 1
    marker = {
        "status": "COMPLETE",
        "regions": 8,
        "requests": len(rows),
        "routes": route_counts,
        "planner_max_ms": solution["max_planner_time_ms"],
        "planner_budget_exhausted_epochs": 0,
        "measured_gpu_energy_j": report["measured_gpu_energy_j"],
        "measured_operational_carbon_g": report[
            "measured_operational_carbon_g"
        ],
        "completed_s": time.time(),
    }
    (args.output_root / "PILOT_COMPLETE.json").write_text(
        json.dumps(marker, indent=2), encoding="utf-8"
    )
    print(json.dumps(marker, indent=2))
    print("JOINT_8VLLM_PILOT_PASS")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--future-work-model", type=Path, required=True)
    parser.add_argument("--gpu-indices", type=int, nargs=8, required=True)
    parser.add_argument("--max-requests", type=int, default=64)
    parser.add_argument("--epoch-ms", type=float, default=1000.0)
    parser.add_argument("--time-budget-ms", type=float, default=100.0)
    asyncio.run(main_async(parser.parse_args()))


if __name__ == "__main__":
    main()
