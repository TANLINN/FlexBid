from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path


REQUIRED_FIELDS = {
    "gpu_index",
    "prompt_tokens",
    "mode",
    "concurrency",
    "repeat",
    "ttft_p95_ms",
    "tpot_p95_ms",
}


def quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    if not ordered:
        return 0.0
    return float(ordered[min(len(ordered) - 1, math.ceil(q * len(ordered)) - 1)])


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_rows(root: Path) -> list[dict]:
    rows = []
    for path in sorted(root.rglob("*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if REQUIRED_FIELDS.issubset(row):
                rows.append(row)
    return rows


def predict(model: dict, row: dict, metric: str) -> float:
    mode = str(row["mode"])
    prompt = int(row["prompt_tokens"])
    concurrency = int(row["concurrency"])
    cell = model["cells"].get(f"{mode}|{prompt}|{concurrency}")
    if cell is None:
        raise KeyError(f"validation point is not a calibrated anchor: {mode}|{prompt}|{concurrency}")
    margin = float(model["one_sided_q95_residual_ms"][mode][metric])
    return float(cell[metric]) + margin


def summary(values: list[float]) -> dict:
    return {
        "samples": len(values),
        "median": statistics.median(values) if values else None,
        "q90": quantile(values, 0.90),
        "q95": quantile(values, 0.95),
        "max": max(values) if values else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Validate a frozen latency surface on an independent warmed run."
    )
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-rows", type=int, default=144)
    parser.add_argument("--minimum-coverage", type=float, default=0.90)
    args = parser.parse_args()

    model = json.loads(args.model.read_text(encoding="utf-8"))
    if model.get("status") != "CANDIDATE_REQUIRES_INDEPENDENT_VALIDATION":
        raise RuntimeError("model is not a frozen validation candidate")
    if args.input_root.resolve().as_posix() == model["training"]["input_root"]:
        raise RuntimeError("validation root equals training root")
    rows = load_rows(args.input_root)
    by_metric = {
        "ttft_ms": {"covered": 0, "errors": [], "ratios": []},
        "tpot_ms": {"covered": 0, "errors": [], "ratios": []},
    }
    by_mode: dict[str, dict[str, list[bool]]] = defaultdict(
        lambda: {"ttft_ms": [], "tpot_ms": []}
    )
    for row in rows:
        for metric, field in (("ttft_ms", "ttft_p95_ms"), ("tpot_ms", "tpot_p95_ms")):
            actual = float(row[field])
            upper = predict(model, row, metric)
            is_covered = actual <= upper
            by_metric[metric]["covered"] += is_covered
            by_metric[metric]["errors"].append(abs(actual - upper))
            by_metric[metric]["ratios"].append(actual / max(1e-9, upper))
            by_mode[str(row["mode"])][metric].append(is_covered)

    coverage = {
        metric: values["covered"] / max(1, len(rows))
        for metric, values in by_metric.items()
    }
    startup_shape = [
        row for row in rows
        if str(row["mode"]) == "cold"
        and int(row["prompt_tokens"]) == 2048
        and int(row["concurrency"]) == 1
    ]
    checks = {
        "expected_row_count": len(rows) == args.expected_rows,
        "ttft_coverage": coverage["ttft_ms"] >= args.minimum_coverage,
        "tpot_coverage": coverage["tpot_ms"] >= args.minimum_coverage,
        "all_eight_gpus": sorted({int(row["gpu_index"]) for row in rows}) == list(range(8)),
        "startup_shape_complete": len(startup_shape) == 8,
        "no_startup_scale_ttft": (
            len(startup_shape) == 8
            and max(float(row["ttft_p95_ms"]) for row in startup_shape) < 5000
        ),
    }
    report = {
        "schema_version": 1,
        "status": "PASS" if all(checks.values()) else "FAIL",
        "model": args.model.resolve().as_posix(),
        "model_sha256": digest(args.model),
        "validation_root": args.input_root.resolve().as_posix(),
        "rows": len(rows),
        "checks": checks,
        "startup_shape": {
            "mode": "cold",
            "prompt_tokens": 2048,
            "concurrency": 1,
            "rows": len(startup_shape),
            "max_ttft_ms": max(
                (float(row["ttft_p95_ms"]) for row in startup_shape),
                default=None,
            ),
        },
        "coverage": coverage,
        "coverage_by_mode": {
            mode: {
                metric: sum(values) / len(values)
                for metric, values in metrics.items()
            }
            for mode, metrics in by_mode.items()
        },
        "absolute_error_to_conservative_prediction_ms": {
            metric: summary(values["errors"])
            for metric, values in by_metric.items()
        },
        "actual_over_conservative_prediction": {
            metric: summary(values["ratios"])
            for metric, values in by_metric.items()
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    if report["status"] != "PASS":
        raise SystemExit(2)
    print("INDEPENDENT_LATENCY_SURFACE_VALIDATION_PASS")


if __name__ == "__main__":
    main()
