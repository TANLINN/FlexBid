from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def metric_total(path: Path, name: str) -> float:
    total = 0.0
    found = False
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith(name + "{") or line.startswith(name + " "):
            total += float(line.rsplit(None, 1)[-1])
            found = True
    if not found:
        raise RuntimeError(f"metric {name} is missing from {path}")
    return total


def main() -> None:
    parser = argparse.ArgumentParser(description="Strict semantic validation for the one-GPU smoke run")
    parser.add_argument("--requests", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    parser.add_argument("--telemetry", type=Path, required=True)
    parser.add_argument("--metrics-before", type=Path, required=True)
    parser.add_argument("--metrics-after", type=Path, required=True)
    args = parser.parse_args()

    rows = [
        json.loads(line)
        for line in args.requests.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    audit = json.loads(args.audit.read_text(encoding="utf-8"))
    failures: list[str] = []
    if not audit.get("passed"):
        failures.append("base audit did not pass")
    if len(rows) != 4:
        failures.append(f"expected 4 smoke requests, observed {len(rows)}")
    with args.telemetry.open("r", encoding="utf-8-sig", newline="") as handle:
        telemetry_rows = list(csv.DictReader(handle))
    usable_telemetry = [
        row for row in telemetry_rows
        if row.get("wall_time_ns") and (row.get("power_w") or row.get("total_energy_mj"))
    ]
    if len(usable_telemetry) < 2:
        failures.append(f"telemetry has only {len(usable_telemetry)} usable rows")
    fallback_count = sum(bool(row["decision"].get("fallback")) for row in rows)
    if fallback_count:
        failures.append(f"{fallback_count} routing decisions used fallback")

    observed = [row["completion"].get("cached_prompt_tokens_observed") for row in rows]
    metric_name = "vllm:prefix_cache_hits_total"
    cache_hits_before = metric_total(args.metrics_before, metric_name)
    cache_hits_after = metric_total(args.metrics_after, metric_name)
    cache_hit_tokens_delta = cache_hits_after - cache_hits_before
    if cache_hit_tokens_delta <= 0:
        failures.append("no physical prefix-cache hit-token increment was measured")

    reused_rows = [
        row for row in rows
        if int(row.get("shared_prefix_tokens") or 0) > 0
    ]
    if not reused_rows:
        failures.append("smoke trace has no multi-turn shared-prefix request")

    report = {
        "passed": not failures,
        "requests": len(rows),
        "usable_telemetry_rows": len(usable_telemetry),
        "fallback_decisions": fallback_count,
        "per_request_cache_observations": observed,
        "per_request_cache_observation_available": any(value is not None for value in observed),
        "prefix_cache_hit_tokens_before": cache_hits_before,
        "prefix_cache_hit_tokens_after": cache_hits_after,
        "prefix_cache_hit_tokens_delta": cache_hit_tokens_delta,
        "failures": failures,
    }
    print(json.dumps(report, indent=2))
    if failures:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
