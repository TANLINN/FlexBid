from __future__ import annotations

import argparse
import asyncio
import json
import os
import random
import time
from datetime import datetime
from pathlib import Path

from carbonaffinity.audit import audit_results
from carbonaffinity.carbon import CarbonTrace
from carbonaffinity.config import config_fingerprint, load_config, resolve_path
from carbonaffinity.control import SiteControlClient
from carbonaffinity.region import RegionClient
from carbonaffinity.replay import run_replay


POLICIES = [
    "round_robin", "pressure_only", "cleanest_now", "sticky",
    "cedar_like", "carbon_affinity", "oracle_historical",
]


def carbon_start(config: dict) -> float | None:
    if config.get("carbon", {}).get("clock_mode") == "wall":
        return None
    value = config["carbon"].get("trace_start_timestamp")
    if isinstance(value, (int, float)):
        return float(value)
    return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()


async def campaign(args: argparse.Namespace) -> None:
    config = load_config(args.config)
    if config.get("experiment", {}).get("mode", "paper_main") != "paper_main":
        raise RuntimeError("run_campaign.py refuses smoke/dry-run configurations")
    preflight_path = args.preflight or resolve_path(config, config.get("runtime", {}).get("preflight_report", "results/preflight.json"))
    if not preflight_path.is_file():
        raise RuntimeError(f"missing preflight report: {preflight_path}")
    preflight = json.loads(preflight_path.read_text(encoding="utf-8"))
    if not preflight.get("passed") or preflight.get("config_fingerprint") != config_fingerprint(config):
        raise RuntimeError("preflight did not pass for this exact configuration")
    token = os.environ.get("CARBONAFFINITY_CONTROL_TOKEN")
    if not token or len(token) < 16:
        raise RuntimeError("set CARBONAFFINITY_CONTROL_TOKEN to the site-agent token")
    controls = {
        region["id"]: SiteControlClient(str(region["control_base"]), token)
        for region in config["regions"]
    }
    inference_clients = {
        region["id"]: RegionClient(region, 60.0) for region in config["regions"]
    }
    carbon = CarbonTrace.from_csv(
        resolve_path(config, config["carbon"]["trace"]),
        float(config["carbon"].get("max_age_s", 1800)),
    )
    trace = resolve_path(config, config["experiment"]["trace"])
    policies = list(args.policies)
    random.Random(args.seed).shuffle(policies)
    args.output_root.mkdir(parents=True, exist_ok=True)
    manifest = {
        "config_fingerprint": config_fingerprint(config),
        "seed": args.seed,
        "policy_order": policies,
        "started_s": time.time(),
    }
    (args.output_root / "campaign_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    try:
        statuses = await asyncio.gather(*(client.status() for client in controls.values()))
        if any(status.get("running") for status in statuses):
            raise RuntimeError("a regional telemetry sampler is already running")
        for policy in policies:
            policy_dir = args.output_root / policy
            marker = policy_dir / "POLICY_COMPLETE.json"
            if args.resume and marker.exists():
                continue
            policy_dir.mkdir(parents=True, exist_ok=True)
            run_id = f"{args.run_prefix}-{policy}-{time.time_ns()}"
            started_regions: list[str] = []
            replay_error: BaseException | None = None
            try:
                reset = await asyncio.gather(
                    *(client.reset_prefix_cache() for client in inference_clients.values())
                )
                if not all(reset):
                    raise RuntimeError("vLLM prefix-cache reset was not acknowledged by both regions")
                for region_id, client in controls.items():
                    await client.start_telemetry(run_id, args.telemetry_interval_ms)
                    started_regions.append(region_id)
                await asyncio.sleep(args.telemetry_lead_s)
                await run_replay(
                    config, trace, policy_dir / "requests.jsonl",
                    policy_name=policy, resume=args.resume,
                )
                await asyncio.sleep(args.telemetry_tail_s)
            except BaseException as exc:
                replay_error = exc
            finally:
                stop_results = await asyncio.gather(
                    *(controls[region_id].stop_telemetry() for region_id in started_regions),
                    return_exceptions=True,
                )
                stop_failures = [result for result in stop_results if isinstance(result, BaseException)]
                if replay_error is None and stop_failures:
                    replay_error = RuntimeError(f"telemetry stop failed: {stop_failures}")
            for region_id in started_regions:
                await controls[region_id].download(run_id, policy_dir / f"{region_id}_gpu.csv")
                await controls[region_id].download(run_id, policy_dir / f"{region_id}_gpu.metadata.json", metadata=True)
            if replay_error is not None:
                raise replay_error
            telemetry = {region_id: policy_dir / f"{region_id}_gpu.csv" for region_id in controls}
            report = audit_results(policy_dir / "requests.jsonl", telemetry, carbon, carbon_start(config))
            (policy_dir / "audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
            if not report["passed"]:
                raise RuntimeError(f"policy audit failed: {policy}")
            marker.write_text(json.dumps({
                "policy": policy,
                "completed_s": time.time(),
                "requests": report["requests"],
                "measured_gpu_energy_j": report.get("measured_gpu_energy_j"),
                "measured_operational_carbon_g": report.get("measured_operational_carbon_g"),
            }, indent=2), encoding="utf-8")
            if args.cooldown_s > 0:
                await asyncio.sleep(args.cooldown_s)
        summaries = {}
        for policy in policies:
            summaries[policy] = json.loads((args.output_root / policy / "audit.json").read_text(encoding="utf-8"))
        reference = summaries.get("pressure_only", {}).get("measured_operational_carbon_g")
        table = []
        for policy in POLICIES:
            if policy not in summaries:
                continue
            item = summaries[policy]
            carbon_g = item.get("measured_operational_carbon_g")
            savings = (
                100.0 * (reference - carbon_g) / reference
                if reference and carbon_g is not None else None
            )
            table.append({
                "policy": policy,
                "requests": item.get("requests"),
                "measured_gpu_energy_j": item.get("measured_gpu_energy_j"),
                "measured_operational_carbon_g": carbon_g,
                "carbon_savings_vs_pressure_pct": savings,
                "ttft_violation_rate": item.get("ttft_violation_rate"),
                "tpot_violation_rate": item.get("tpot_violation_rate"),
                "ttft_p95_ms": item.get("ttft_p95_ms"),
                "tpot_p95_ms": item.get("tpot_p95_ms"),
                "migrations": item.get("migrations"),
                "regions": item.get("regions"),
            })
        (args.output_root / "campaign_summary.json").write_text(
            json.dumps({"reference_policy": "pressure_only", "policies": table}, indent=2),
            encoding="utf-8",
        )
        manifest["completed_s"] = time.time()
        (args.output_root / "PIPELINE_COMPLETE.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    finally:
        await asyncio.gather(*(client.close() for client in controls.values()))
        await asyncio.gather(*(client.close() for client in inference_clients.values()))


def main() -> None:
    parser = argparse.ArgumentParser(description="One-command two-region paper campaign")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--preflight", type=Path)
    parser.add_argument("--policies", nargs="+", default=POLICIES)
    parser.add_argument("--seed", type=int, default=20260817)
    parser.add_argument("--run-prefix", default="main")
    parser.add_argument("--telemetry-interval-ms", type=int, default=100)
    parser.add_argument("--telemetry-lead-s", type=float, default=5.0)
    parser.add_argument("--telemetry-tail-s", type=float, default=5.0)
    parser.add_argument("--cooldown-s", type=float, default=60.0)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    asyncio.run(campaign(args))


if __name__ == "__main__":
    main()
