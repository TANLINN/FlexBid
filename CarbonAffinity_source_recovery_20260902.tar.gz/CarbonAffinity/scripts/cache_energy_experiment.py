"""Paired GPU service energy for independent cold and cached sessions."""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import itertools
import json
import math
import os
import random
import re
import signal
import socket
import statistics
import subprocess
import sys
import time
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

GPUS = tuple(range(8))
CACHED = (1568, 7840, 31360)
RESIDUAL = 384
OUTPUTS = (64, 192)
CONCURRENCIES = (1, 3)
REPEATS = 2


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, allow_nan=False)


def schedule(gpu):
    grid = list(itertools.product(CACHED, OUTPUTS, CONCURRENCIES))
    random.Random(20260831 + gpu).shuffle(grid)
    rows = []
    for repeat in range(REPEATS):
        for cached, output, concurrency in grid:
            modes = ("cold", "warm") if (gpu + repeat) % 2 == 0 else ("warm", "cold")
            for order, mode in enumerate(modes):
                rows.append(dict(pair_id=f"c{cached}_o{output}_n{concurrency}_r{repeat}",
                    cached_context_target=cached, prompt_tokens=cached + RESIDUAL,
                    output_tokens=output, concurrency=concurrency, repeat=repeat,
                    mode=mode, order=order))
    return rows


def energy_delta(before_mj, after_mj):
    if not all(isinstance(x, (float, int)) and math.isfinite(x) for x in (before_mj, after_mj)):
        raise ValueError("NVML energy counter missing/nonfinite")
    if before_mj < 0 or after_mj <= before_mj:
        raise ValueError("NVML energy counter did not increase")
    return (after_mj - before_mj) / 1000.0


def result_errors(records, prompt_tokens, output_tokens, cached_target=None):
    errors = []
    for index, record in enumerate(records):
        cached = record.get("cached_prompt_tokens_observed")
        checks = {
            "success": record.get("success") is True and record.get("status_code") == 200,
            "error": record.get("error") is None,
            "prompt_tokens": record.get("prompt_tokens_reported") == prompt_tokens,
            "output_tokens": record.get("output_tokens") == output_tokens,
            "cache": (cached is None or (type(cached) is int and cached == 0))
                if cached_target is None else type(cached) is int and cached == cached_target,
        }
        for metric in ("ttft_ms", "tpot_ms") if output_tokens > 1 else ("ttft_ms",):
            value = record.get(metric)
            checks[metric] = isinstance(value, (int, float)) and math.isfinite(value) and value >= 0
        errors.extend(f"request {index}: {key}" for key, valid in checks.items() if not valid)
    return errors


def reset_log_evidence(text):
    lines = [line for line in text.splitlines()
             if "reset prefix cache" in line.lower()]
    success = any("successfully reset prefix cache" in line.lower() for line in lines)
    failure = any("failed to reset prefix cache" in line.lower() for line in lines)
    return lines, success, failure


async def physical_reset(client, engine_log, timeout_s=30.0):
    offset = engine_log.stat().st_size
    api_success = await client.reset_prefix_cache()
    deadline = time.monotonic() + timeout_s
    lines, engine_success, engine_failure = [], False, False
    while time.monotonic() < deadline:
        data = engine_log.read_bytes()
        if len(data) < offset:
            raise RuntimeError("engine log truncated during prefix-cache reset")
        lines, engine_success, engine_failure = reset_log_evidence(
            data[offset:].decode(errors="replace")
        )
        if engine_success or engine_failure:
            break
        await asyncio.sleep(.05)
    return {
        "api_success": api_success,
        "engine_log": lines,
        "engine_success": engine_success,
        "engine_failure": engine_failure,
        "confirmed": bool(api_success and engine_success and not engine_failure),
    }


async def meter(jobs, counter):
    # The interval includes response completion, not tokenization or cache setup.
    before_ns = time.perf_counter_ns()
    before_mj = counter()
    started = time.time_ns()
    results = await asyncio.gather(*(job() for job in jobs), return_exceptions=True)
    counter_error = None
    try:
        after_mj = counter()
    except Exception as exc:
        after_mj = None
        counter_error = f"{type(exc).__name__}: {exc}"
    ended_ns = time.perf_counter_ns()
    records = [asdict(item) if not isinstance(item, BaseException) else
               {"success": False, "error": f"{type(item).__name__}: {item}"} for item in results]
    row = dict(started_wall_time_ns=started, completed_wall_time_ns=time.time_ns(),
               duration_s=(ended_ns - before_ns) / 1e9,
               energy_before_mj=before_mj, energy_after_mj=after_mj, results=records)
    try:
        row["total_energy_j"] = energy_delta(before_mj, after_mj)
    except ValueError as exc:
        row["total_energy_j"] = None
        row["energy_error"] = counter_error or str(exc)
    return row


async def collect(args, materializer, client, counter, engine_log):
    from carbonaffinity.models import RequestSpec
    destination = args.output_root / "raw" / f"gpu_{args.gpu_index}" / "measurements.jsonl"
    destination.parent.mkdir(parents=True, exist_ok=True)
    namespace = uuid.uuid4().hex
    with destination.open("x", encoding="utf-8") as handle:
        for case in schedule(args.gpu_index):
            row = {**case, "gpu_index": args.gpu_index, "valid": False, "primes": [],
                   "prime_energy_j": 0.0}
            try:
                row["reset"] = await physical_reset(client, engine_log)
                if not row["reset"]["confirmed"]:
                    raise RuntimeError("physical prefix-cache reset was not confirmed")
                # Each session has its own tokens and salt; cold/warm pairs reuse tokens exactly.
                prompts, salts = [], []
                for index in range(case["concurrency"]):
                    identity = f"energy-{args.gpu_index}-{case['pair_id']}-{index}"
                    prompts.append(materializer.tokens(dict(request_id=identity,
                        session_id=identity, prompt_tokens=case["prompt_tokens"], shared_prefix_tokens=0)))
                    salts.append(f"{namespace}:{identity}:{case['mode']}")
                row["cache_salts"] = salts
                if case["mode"] == "warm":
                    for index, (prompt, salt) in enumerate(zip(prompts, salts)):
                        identity = f"{case['pair_id']}-prime-{index}"
                        request = RequestSpec(identity, 0, len(prompt), 1, identity)
                        prime = await meter([lambda r=request, p=prompt, s=salt:
                                             client.complete(r, p, cache_salt=s)], counter)
                        row["primes"].append(prime)
                        errors = result_errors(prime["results"], len(prompt), 1)
                        if errors or prime.get("energy_error"):
                            raise RuntimeError(f"prime failed: {errors} {prime.get('energy_error', '')}")
                        row["prime_energy_j"] += prime["total_energy_j"]
                jobs = []
                for index, (prompt, salt) in enumerate(zip(prompts, salts)):
                    identity = f"{case['pair_id']}-{case['mode']}-{index}"
                    request = RequestSpec(identity, 0, len(prompt), case["output_tokens"], identity)
                    jobs.append(lambda r=request, p=prompt, s=salt: client.complete(r, p, cache_salt=s))
                await asyncio.sleep(2.0)
                row.update(await meter(jobs, counter))
                expected_cache = case["cached_context_target"] if case["mode"] == "warm" else None
                errors = result_errors(row["results"], case["prompt_tokens"], case["output_tokens"], expected_cache)
                if errors or row.get("energy_error"):
                    raise RuntimeError(f"measurement failed: {errors} {row.get('energy_error', '')}")
                row["energy_per_request_j"] = row["total_energy_j"] / case["concurrency"]
                row["valid"] = True
            except Exception as exc:
                row["error"] = f"{type(exc).__name__}: {exc}"
            handle.write(json.dumps(row, allow_nan=False) + "\n")
            handle.flush()
            print(f"gpu={args.gpu_index} pair={case['pair_id']} mode={case['mode']} "
                  f"valid={row['valid']} joules={row.get('total_energy_j')}", flush=True)
            if not row["valid"]:
                raise RuntimeError(row["error"])


def summarize(rows):
    expected = {(gpu, c["pair_id"], c["mode"]): c for gpu in GPUS for c in schedule(gpu)}
    actual = {}
    for row in rows:
        key = row["gpu_index"], row["pair_id"], row["mode"]
        if key in actual or key not in expected:
            raise ValueError("duplicate or unexpected measurement")
        if row.get("valid") is not True or any(row.get(k) != v for k, v in expected[key].items()):
            raise ValueError("invalid result or mismatched case")
        if not math.isfinite(row["total_energy_j"]) or row["total_energy_j"] <= 0:
            raise ValueError("invalid measured energy")
        if not math.isfinite(row["prime_energy_j"]) or row["prime_energy_j"] < 0:
            raise ValueError("invalid cache setup energy")
        actual[key] = row
    if set(actual) != set(expected):
        raise ValueError(f"incomplete measurements: {len(actual)}/{len(expected)}")
    pairs, groups = [], {}
    for (gpu, pair_id, mode), cold in actual.items():
        if mode != "cold":
            continue
        warm = actual[gpu, pair_id, "warm"]
        n = cold["concurrency"]
        item = dict(gpu_index=gpu, pair_id=pair_id,
            cold_j_per_request=cold["total_energy_j"] / n,
            warm_j_per_request=warm["total_energy_j"] / n,
            paired_saving_pct=100 * (1 - warm["total_energy_j"] / cold["total_energy_j"]),
            prime_energy_j=warm["prime_energy_j"])
        pairs.append(item)
        name = f"p{cold['prompt_tokens']}_o{cold['output_tokens']}_n{n}"
        groups.setdefault(name, []).append(item)
    medians = {name: {"pairs": len(items), **{key: statistics.median(item[key] for item in items)
               for key in ("cold_j_per_request", "warm_j_per_request", "paired_saving_pct", "prime_energy_j")}}
               for name, items in sorted(groups.items())}
    return dict(rows=len(rows), pairs=len(pairs), groups=medians, pair_results=pairs,
        energy_scope="single GPU counter over batch service interval; includes idle power in that interval",
        setup_scope="prime_energy_j is the sum for N independent sessions, excluded from warm service energy",
        exclusions="CPU, network, inter-request cache-retention time, server startup and shape prewarm")


def load_support(path):
    if not path.is_file():
        raise FileNotFoundError(f"existing fixed-shape prewarm helper missing: {path}")
    spec = importlib.util.spec_from_file_location("energy_prewarm_support", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def worker(args):
    import pynvml
    from carbonaffinity.materialize import PromptMaterializer
    from carbonaffinity.region import RegionClient
    pynvml.nvmlInit()
    try:
        handle = pynvml.nvmlDeviceGetHandleByIndex(args.gpu_index)
        counter = lambda: float(pynvml.nvmlDeviceGetTotalEnergyConsumption(handle))
        counter()
        async def run():
            client = RegionClient(dict(id=f"gpu_{args.gpu_index}",
                api_base=f"http://127.0.0.1:{18000 + args.gpu_index}/v1", api_key="EMPTY",
                model=args.model, admission_concurrency=max(CONCURRENCIES)), 300)
            try:
                await collect(args, PromptMaterializer(str(args.model_dir)), client, counter,
                              args.output_root / f"vllm_gpu_{args.gpu_index}.log")
            finally:
                await client.close()
        asyncio.run(run())
    finally:
        pynvml.nvmlShutdown()


def campaign(args):
    import httpx
    import pynvml
    if os.name != "posix":
        raise RuntimeError("GPU campaign requires Linux")
    project, root = args.project_root.resolve(), args.output_root.resolve()
    if not root.is_relative_to(project / "results") or root == project / "results":
        raise ValueError("output must be a new directory under project/results")
    root.mkdir(parents=True, exist_ok=False)
    children, logs, servers = [], [], []
    telemetry = None
    def event(message):
        line = datetime.now(timezone.utc).isoformat() + " " + message
        print(line, flush=True)
        with (root / "events.log").open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    def spawn(command, path, extra=None):
        handle = path.open("x", encoding="utf-8")
        logs.append(handle)
        env = {**os.environ, "PYTHONPATH": str(project), "PYTHONNOUSERSITE": "1",
               "PYTHONUNBUFFERED": "1", "TRITON_PRINT_AUTOTUNING": "1", **(extra or {})}
        p = subprocess.Popen(command, cwd=project, env=env, stdin=subprocess.DEVNULL,
                             stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
        children.append(p)
        return p
    def check_servers():
        for gpu, p in zip(GPUS, servers):
            if p.poll() is not None:
                raise RuntimeError(f"GPU {gpu} server exited: see vllm_gpu_{gpu}.log")
        if telemetry is not None and telemetry.poll() is not None:
            raise RuntimeError("GPU telemetry exited")
    def wait(workers, seconds):
        deadline = time.monotonic() + seconds
        while True:
            check_servers()
            if any(p.poll() not in (None, 0) for p in workers):
                raise RuntimeError("worker failed: inspect shape_prewarm.log or raw/gpu_*/worker.log")
            if all(p.poll() == 0 for p in workers):
                return
            if time.monotonic() > deadline:
                raise TimeoutError("worker timeout")
            time.sleep(2)
    def interrupted(signum, frame):
        raise InterruptedError(f"signal {signum}")
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, interrupted)
    try:
        support = load_support(args.support_file)
        if not (args.model_dir / "config.json").is_file():
            raise FileNotFoundError("model config missing")
        busy = subprocess.check_output(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True).strip()
        if busy:
            raise RuntimeError("GPUs busy: stop the other workload explicitly before starting")
        for gpu in GPUS:
            with socket.socket() as sock:
                sock.settimeout(1)
                if sock.connect_ex(("127.0.0.1", 18000 + gpu)) == 0:
                    raise RuntimeError(f"port {18000 + gpu} occupied")
        pynvml.nvmlInit()
        try:
            for gpu in GPUS:
                pynvml.nvmlDeviceGetTotalEnergyConsumption(pynvml.nvmlDeviceGetHandleByIndex(gpu))
        finally:
            pynvml.nvmlShutdown()
        save(root / "RUN.json", dict(stage="cache-energy-paired-measurement", expected_rows=384,
            cached_contexts=CACHED, residual_tokens=RESIDUAL, output_tokens=OUTPUTS,
            concurrency=CONCURRENCIES, repeats=REPEATS, cache_scope="independent per-request namespaces",
            case_order={str(gpu): schedule(gpu) for gpu in GPUS}, support_file=str(args.support_file)))
        save(root / "SUPERVISOR.json", dict(pid=os.getpid()))
        telemetry = spawn(["nvidia-smi", "--query-gpu=timestamp,index,uuid,utilization.gpu,power.draw,clocks.sm",
                           "--format=csv", "--loop=1"], root / "gpu_telemetry.csv")
        commands = []
        with httpx.Client(timeout=2, trust_env=False) as client:
            # Serialize initialization to reduce concurrent internal-port allocation races.
            for gpu in GPUS:
                event(f"STARTING_GPU={gpu}")
                command = [str(Path(sys.executable).with_name("vllm")), "serve", str(args.model_dir),
                    "--served-model-name", args.model, "--host", "127.0.0.1", "--port", str(18000 + gpu),
                    "--tensor-parallel-size", "1", "--enable-prefix-caching", "--enable-prompt-tokens-details",
                    "--enable-chunked-prefill", "--max-num-batched-tokens", "784", "--max-num-seqs", "8",
                    "--max-model-len", "65536", "--gpu-memory-utilization", "0.92"]
                commands.append(command)
                servers.append(spawn(command, root / f"vllm_gpu_{gpu}.log", {
                    "CUDA_VISIBLE_DEVICES": str(gpu),
                    "VLLM_SERVER_DEV_MODE": "1",
                }))
                deadline = time.monotonic() + 1200
                while True:
                    check_servers()
                    try:
                        if client.get(f"http://127.0.0.1:{18000 + gpu}/health").is_success:
                            break
                    except httpx.HTTPError:
                        pass
                    if time.monotonic() > deadline:
                        raise TimeoutError(f"GPU {gpu} startup timeout")
                    time.sleep(5)
                text = (root / f"vllm_gpu_{gpu}.log").read_text(errors="replace")
                if not re.search(r"max_num_batched_tokens[^0-9]*784([^0-9]|$)", text):
                    raise RuntimeError(f"GPU {gpu}: cap784 not observed")
                if not re.search(r"(?:attention )?block size to 784 tokens", text):
                    raise RuntimeError(f"GPU {gpu}: cache block784 not observed")
                event(f"VLLM_READY={gpu + 1}/8")
        save(root / "RUNTIME.json", dict(commands=commands, python=sys.version,
            packages=subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True)))
        base = [sys.executable, "-u", str(Path(__file__).resolve()), "--project-root", str(project),
                "--output-root", str(root), "--model-dir", str(args.model_dir), "--model", args.model,
                "--support-file", str(args.support_file)]
        event("FIXED_SHAPE_PREWARM_START")
        wait([spawn(base + ["--mode", "prewarm"], root / "shape_prewarm.log")], 900)
        event("MEASUREMENT_START expected_rows=384")
        workers = []
        for gpu in GPUS:
            destination = root / "raw" / f"gpu_{gpu}"
            destination.mkdir(parents=True)
            workers.append(spawn(base + ["--mode", "worker", "--gpu-index", str(gpu)], destination / "worker.log"))
        wait(workers, 14400)
        rows = [json.loads(line) for path in sorted((root / "raw").glob("gpu_*/measurements.jsonl"))
                for line in path.read_text().splitlines() if line.strip()]
        summary = summarize(rows)
        before = json.loads((root / "SHAPE_PREWARM.json").read_text())
        tuning = {}
        for gpu in GPUS:
            data = (root / f"vllm_gpu_{gpu}.log").read_bytes()
            offset = before["logs"][str(gpu)]["bytes"]
            if len(data) < offset:
                raise RuntimeError("engine log truncated")
            tuning[str(gpu)] = support.tuning_events(data[offset:].decode(errors="replace"))
        summary["post_prewarm_tuning_events"] = tuning
        summary["steady_state_observed"] = not any(tuning.values())
        save(root / "CACHE_ENERGY_SUMMARY.json", summary)
        for key, values in summary["groups"].items():
            print(key, json.dumps(values), flush=True)
        if any(tuning.values()):
            event("WARNING extra autotuning observed; do not interpret as steady-state energy")
        save(root / "EXPERIMENT_COMPLETE.json", dict(status="COMPLETE", rows=len(rows), pairs=summary["pairs"],
             steady_state_observed=summary["steady_state_observed"]))
        event("CACHE_ENERGY_COLLECTION_COMPLETE")
    except Exception as exc:
        save(root / "FATAL.json", dict(status="FAIL", error=f"{type(exc).__name__}: {exc}"))
        event("FAILED=" + str(exc))
        raise
    finally:
        for sig in (signal.SIGTERM, signal.SIGINT):
            signal.signal(sig, signal.SIG_IGN)
        # Only groups created by this supervisor are stopped.
        for p in children:
            try:
                os.killpg(p.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        deadline = time.monotonic() + 15
        while any(p.poll() is None for p in children) and time.monotonic() < deadline:
            time.sleep(.2)
        for p in children:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            p.wait()
        for handle in logs:
            handle.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("run", "worker", "prewarm"), default="run")
    parser.add_argument("--project-root", type=Path, default=Path("/root/CarbonAffinity"))
    parser.add_argument("--model-dir", type=Path, default=Path("/root/models/Qwen3.5-27B"))
    parser.add_argument("--model", default="Qwen3.5-27B")
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--support-file", type=Path, required=True)
    parser.add_argument("--gpu-index", type=int, choices=GPUS)
    args = parser.parse_args()
    sys.path.insert(0, str(args.project_root.resolve()))
    args.output_root = args.output_root.resolve()
    args.support_file = args.support_file.resolve()
    args.model_dir = args.model_dir.resolve()
    if args.mode == "run":
        campaign(args)
    elif args.mode == "worker":
        if args.gpu_index is None:
            parser.error("worker requires --gpu-index")
        worker(args)
    else:
        from carbonaffinity.materialize import PromptMaterializer
        from carbonaffinity.region import RegionClient
        support = load_support(args.support_file)
        asyncio.run(support.prewarm(args.output_root, PromptMaterializer(str(args.model_dir)),
                    RegionClient, gpus=GPUS, first_port=18000, model=args.model))


if __name__ == "__main__":
    main()
