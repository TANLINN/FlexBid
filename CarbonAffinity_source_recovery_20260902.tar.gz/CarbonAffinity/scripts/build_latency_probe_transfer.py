"""Generate short, independently verified paste commands; never launch a GPU."""
from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
import json
import shlex
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
PYTHON = '/root/CarbonAffinity/.venv/bin/python'


def build_transfer(source: bytes, *, parent='/root/CarbonAffinity/results', python=PYTHON):
    digest = hashlib.sha256(source).hexdigest()
    destination = str(Path(parent) / ('probe_transfer_' + digest[:16])).replace('\\', '/')
    compressed = gzip.compress(source, mtime=0)
    chunks = [compressed[i:i + 300] for i in range(0, len(compressed), 300)]
    steps = []

    def add(code, marker):
        steps.append({'command': shlex.quote(python) + ' -c ' + shlex.quote(code),
                      'code': code, 'expected_marker': marker})

    add('from pathlib import Path; '
        f'p=Path({destination!r}); p.mkdir(parents=True,exist_ok=True); '
        'print("TRANSFER_DIRECTORY_READY")', 'TRANSFER_DIRECTORY_READY')
    for i, chunk in enumerate(chunks):
        encoded = base64.b64encode(chunk).decode('ascii')
        checksum = hashlib.sha256(chunk).hexdigest()
        marker = f'PART_{i + 1:02d}_OF_{len(chunks):02d}_OK'
        # Double-quoted Python literals keep the surrounding shell quoting simple.
        code = ('import base64,hashlib; from pathlib import Path; '
                f'd=base64.b64decode("{encoded}",validate=True); '
                f'assert hashlib.sha256(d).hexdigest()=="{checksum}","PART_HASH_FAILED"; '
                f'p=Path("{destination}/part_{i:02d}"); '
                'assert not p.exists() or p.read_bytes()==d,"EXISTING_PART_DIFFERS"; '
                'p.write_bytes(d) if not p.exists() else None; '
                'assert p.read_bytes()==d,"PART_WRITE_FAILED"; '
                f'print("{marker}")')
        add(code, marker)
    code = ('import gzip,hashlib; from pathlib import Path; '
            f'p=Path("{destination}"); '
            f'd=gzip.decompress(b"".join((p/("part_%02d"%i)).read_bytes() for i in range({len(chunks)}))); ')
    # Use explicit filename formatting instead of globbing: missing parts fail.
    code += (f'assert hashlib.sha256(d).hexdigest()=="{digest}","FULL_SOURCE_HASH_FAILED"; '
             'f=p/"launcher.sh"; '
             'assert not f.exists() or f.read_bytes()==d,"EXISTING_SCRIPT_DIFFERS"; '
             'f.write_bytes(d) if not f.exists() else None; '
             'assert f.read_bytes()==d,"SCRIPT_WRITE_FAILED"; '
             'print("FULL_SOURCE_VERIFIED",str(f))')
    add(code, 'FULL_SOURCE_VERIFIED')
    return {'sha256': digest, 'source_bytes': len(source), 'compressed_bytes': len(compressed),
            'chunks': len(chunks), 'script': destination + '/launcher.sh', 'steps': steps}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--shape-warmup', action='store_true')
    args = parser.parse_args()
    source = (PROJECT / 'scripts/run_latency_pause_probe.sh').read_text(encoding='utf-8')
    source = source.replace('\r\n', '\n').rstrip('\r\n') + '\n'
    if args.shape_warmup:
        if __package__:
            from .build_latency_shape_probe import make_source
        else:
            from build_latency_shape_probe import make_source
        source = make_source(source)
    transfer = build_transfer(source.encode('utf-8'))
    transfer['result_prefix'] = ('latency_pause_probe_shape_warmup_'
                                 if args.shape_warmup else 'latency_pause_probe_')
    # Do not print internal helper source as an extra user-visible instruction.
    for step in transfer['steps']:
        step.pop('code')
    print(json.dumps(transfer))


if __name__ == '__main__':
    main()
