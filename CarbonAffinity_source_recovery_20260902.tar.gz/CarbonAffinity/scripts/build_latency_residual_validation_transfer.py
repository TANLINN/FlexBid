"""One-paste eight-GPU validation launcher with locked candidate and pass criteria."""
import argparse
import base64
import gzip
import hashlib
import json
import shlex
import textwrap

from scripts.build_latency_residual_fit_transfer import build_payload as fit_payload
from scripts.build_latency_residual_transfer import INSTALLER, PROJECT
from scripts.residual_latency_validation import CANDIDATE_PATH, CANDIDATE_SHA256

FILES = ("scripts/residual_latency_validation.py", "scripts/measure_latency_residual_validation.py",
         "scripts/run_latency_residual_validation.py", "tests/test_residual_latency_validation.py")


def build_payload():
    payload = json.loads(gzip.decompress(fit_payload()))
    for name in FILES:
        code = (PROJECT / name).read_text(encoding="utf-8")
        compile(code, name, "exec")
        payload["files"][name] = code
    payload["scope"] = "Independent validation only: new 432-batch grid; locked candidate; no fit, freeze or runtime install"
    return gzip.compress(json.dumps(payload, ensure_ascii=True, sort_keys=True).encode(), mtime=0)


def command(payload):
    digest = hashlib.sha256(payload).hexdigest()
    encoded = "\n".join(textwrap.wrap(base64.b64encode(payload).decode(), 100))
    install = "/root/CarbonAffinity/.venv/bin/python -c " + shlex.quote(INSTALLER)
    hash_check = 'import hashlib,sys; from pathlib import Path; p=Path(sys.argv[1]); actual=hashlib.sha256(p.read_bytes()).hexdigest(); print("CANDIDATE_SHA256="+actual); sys.exit(0 if actual==sys.argv[2] else 1)'
    return f'''if VALIDATION_BUNDLE="$({install} {digest} /root/CarbonAffinity <<'RESIDUAL_VALIDATION_BUNDLE_EOF'
{encoded}
RESIDUAL_VALIDATION_BUNDLE_EOF
)"; then
    if (cd "$VALIDATION_BUNDLE" && PYTHONPATH="$VALIDATION_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -m unittest tests.test_latency_residual tests.test_residual_latency_candidate tests.test_residual_latency_validation -q); then
        if /root/CarbonAffinity/.venv/bin/python -c {shlex.quote(hash_check)} {shlex.quote(CANDIDATE_PATH.as_posix())} {CANDIDATE_SHA256}; then
            VAL="/root/CarbonAffinity/results/latency_residual_independent_validation_$(date -u +%Y%m%dT%H%M%S%NZ)"
            nohup env PYTHONPATH="$VALIDATION_BUNDLE:/root/CarbonAffinity" PYTHONNOUSERSITE=1 /root/CarbonAffinity/.venv/bin/python -u "$VALIDATION_BUNDLE/scripts/run_latency_residual_validation.py" --project-root /root/CarbonAffinity --model-dir /root/models/Qwen3.5-27B --output-root "$VAL" > "${{VAL}}.launcher.log" 2>&1 < /dev/null &
            echo "PID=$! VAL=$VAL"
            echo "INDEPENDENT_VALIDATION_SUBMITTED_EXPECTED_ROWS=432"
        else
            echo "CANDIDATE_HASH_CHECK_FAILED_NOT_STARTED"
        fi
    else
        echo "VALIDATION_SELF_TEST_FAILED_NOT_STARTED"
    fi
else
    echo "VALIDATION_TRANSFER_FAILED_NOT_STARTED"
fi
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--metadata", action="store_true")
    args = parser.parse_args()
    payload = build_payload()
    output = command(payload)
    if args.metadata:
        print(json.dumps({"sha256": hashlib.sha256(payload).hexdigest(), "bytes": len(payload),
                          "lines": len(output.splitlines()), "expected_rows": 432,
                          "candidate_sha256": CANDIDATE_SHA256,
                          "candidate_path": CANDIDATE_PATH.as_posix()}))
    else:
        print(output, end="")


if __name__ == "__main__":
    main()
