"""Locked-candidate heldout workload validation; never fits or installs models."""
import itertools
import json
import sys
from collections import Counter
from functools import lru_cache
from pathlib import Path

from carbonaffinity.artifacts import read_rows, sha256, write_json
from scripts import corun_observable_pilot as engine
from scripts import corun_observable_development as dev
from scripts import observable_corun_candidate as estimator

VERSION = "observable-corun-independent-validation-v1"
MEASUREMENT_MODULE = "scripts.validate_observable_corun_candidate"
REPORT_NAME = "OBSERVABLE_CORUN_INDEPENDENT_VALIDATION_REPORT.json"
CANDIDATE = Path("/root/CarbonAffinity/results/observable_corun_candidate_v1_20260830T143453639470198Z/observable_corun_candidate_v1.json")
EXPECTED_SHA256 = "dc4aef7156118107a0c3e90b409d90d4c9b468138aa69039bae2498305b4d84b"
EXPECTED_ROWS = 768
MIN_COVERAGE = .95


@lru_cache(maxsize=1)
def cases():
    victims = [(f"cold_p{p}", p, 0) for p in dev.RESERVED["cold_prompt_tokens"]]
    victims += [(f"warm_c{c}_u{u}", c + u, c) for c, u in itertools.product(
        dev.RESERVED["warm_cached_tokens"], dev.RESERVED["warm_residual_tokens"])]
    base = []
    for mode, prompt, cached in victims:
        for scenario in engine.SCENARIOS:
            backgrounds = engine.background_specs(scenario)
            for bg in backgrounds:
                bg["output_tokens"] = 128
                if not bg["cached_target"]:
                    bg["prompt_tokens"] = 12288
            base.append(dict(cell_id=f"{mode}_{scenario}", mode=mode, prompt_tokens=prompt,
                cached_target=cached, output_tokens=64, scenario=scenario, backgrounds=backgrounds,
                future_offset_ms=250, phase_role="future_arrival_control" if scenario.startswith("future") else "primary_validation"))
    return tuple(dict(c, case_id=f"{c['cell_id']}_r{rep}", repeat=rep)
                 for rep in range(2) for c in (base if rep == 0 else reversed(base)))


def design():
    return dict(protocol=VERSION, expected_rows=768, rows_per_gpu=96, gpu_indices=list(range(8)),
        cases=list(cases()), primary_rows=576, future_control_rows=192,
        candidate_sha256=EXPECTED_SHA256, runtime_cap=784, repeats=2,
        second_repeat_order="reverse of first", heldout_coordinates=dev.RESERVED,
        primary_gates=dict(min_coverage=MIN_COVERAGE, metrics=["ttft_ms", "tpot_ms"],
            groups=["each mode/metric pooled", "each GPU/mode/metric", "each mode/phase-count/metric"],
            ttft_classification_threshold_ms=16000, ttft_classification_false_negatives=0),
        controls="require raw integrity, exclude from primary metric gates; report separately even if undercovered",
        validity_gates="exact cases/order/cache/phase/reservations/code; no new autotuning; candidate and predictions locked before any GPU server",
        independence="new workload coordinates and new run; same8 GPUs, not a claim of new independent hardware",
        no_fit=True, no_margin_changes=True, no_dropped_retries=True, candidate_frozen=False,
        scope="bounded initial-state workload validation only; no service-SLO or continuous-arrival TPOT guarantee",
        target="victim TTFT and mean TPOT, not max inter-token stall",
        known_development_limit="late-arrival controls had TPOT undercoverage; preserved, not absorbed into margin")


def prediction_plan(model):
    plan = {}
    for case in cases():
        query = estimator.design_query(case)
        prediction = estimator.predict(model, query)
        if not prediction["in_domain"]:
            raise ValueError("validation design is OOD: " + case["case_id"])
        plan[case["case_id"]] = dict(query=query, prediction=prediction, role=case["phase_role"])
    return plan


def verified_candidate():
    if sha256(CANDIDATE) != EXPECTED_SHA256:
        raise ValueError("CANDIDATE_HASH_MISMATCH_NOT_STARTED")
    root = CANDIDATE.parent
    if (root / "FATAL.json").exists():
        raise ValueError("candidate directory contains FATAL")
    model = json.loads(CANDIDATE.read_text())
    audit_path, record_path, done_path = [root / n for n in
        ("OBSERVABLE_CORUN_CANDIDATE_AUDIT.json", "FIT_RECORD.json", "FIT_COMPLETE.json")]
    audit, record, done = [json.loads(p.read_text()) for p in (audit_path, record_path, done_path)]
    if (model.get("model_kind") != estimator.KIND or model.get("candidate_frozen") is not False or
        model.get("independent_validation_passed") is not False or
        audit.get("status") != "CANDIDATE_READY_FOR_INDEPENDENT_VALIDATION" or
        not audit.get("checks") or not all(v is True for v in audit["checks"].values()) or
        done.get("status") != "COMPLETE" or done.get("audit_sha256") != sha256(audit_path) or
        done.get("candidate_sha256") != EXPECTED_SHA256 or audit.get("candidate_sha256") != EXPECTED_SHA256 or
        model.get("provenance", {}).get("fit_record_sha256") != sha256(record_path)):
        raise ValueError("candidate fit provenance mismatch")
    if (record.get("validation_data_read") is not False or record.get("training_rows") != 2016 or
        record.get("excluded_future_controls") != 192 or
        not record.get("source_sha256") or not record.get("fit_code_sha256")):
        raise ValueError("development-only source record required")
    evidence = {str(p): sha256(p) for p in (CANDIDATE, audit_path, record_path, done_path)}
    for mapping in (record["source_sha256"], record["fit_code_sha256"]):
        for name, expected in mapping.items():
            if sha256(name) != expected:
                raise ValueError("fit/development evidence changed: " + name)
            evidence[name] = expected
    return model, evidence


def prepare(root, args):
    model, evidence = verified_candidate()
    plan = prediction_plan(model)
    with (root / "LOCKED_CANDIDATE.json").open("xb") as handle:
        handle.write(CANDIDATE.read_bytes())
    if sha256(root / "LOCKED_CANDIDATE.json") != EXPECTED_SHA256:
        raise ValueError("candidate changed during locking")
    write_json(root / "PREDICTIONS_BEFORE_MEASUREMENT.json", plan)
    write_json(root / "PREVALIDATION_LOCK.json", dict(status="LOCKED_FOR_VALIDATION_NOT_RUNTIME_FROZEN",
        candidate_sha256=EXPECTED_SHA256, candidate_source=str(CANDIDATE), evidence_sha256=evidence,
        prediction_plan_sha256=sha256(root / "PREDICTIONS_BEFORE_MEASUREMENT.json"),
        no_refit=True, no_margin_change=True, no_validation_results_read=True))
    return dict(candidate_sha256=EXPECTED_SHA256,
        prevalidation_lock_sha256=sha256(root / "PREVALIDATION_LOCK.json"),
        prediction_plan_sha256=sha256(root / "PREDICTIONS_BEFORE_MEASUREMENT.json"),
        candidate_frozen=False, model_fitting_in_this_run=False)


def code_paths():
    return [Path(m.__file__).resolve() for m in (sys.modules[__name__], engine, dev, estimator)]


def audit(root):
    root = Path(root)
    report = engine.audit(root, protocol=sys.modules[__name__])
    rows = read_rows(root / "raw")
    registered = json.loads((root / "PREREGISTRATION.json").read_text())
    lock = json.loads((root / "PREVALIDATION_LOCK.json").read_text())
    plan_path = root / "PREDICTIONS_BEFORE_MEASUREMENT.json"
    plan = json.loads(plan_path.read_text())
    counts = Counter(r.get("gpu_index") for r in rows)
    ordered_ids = [c["case_id"] for c in cases()]
    ordered = all([json.loads(line)["case_id"] for line in
        (root / "raw" / f"gpu_{g}" / "measurements.jsonl").read_text().splitlines() if line.strip()] == ordered_ids
        for g in range(8))
    primary = [r for r in rows if r.get("phase_role") == "primary_validation"]
    controls = [r for r in rows if r.get("phase_role") == "future_arrival_control"]
    fit_coordinates = {(estimator.coordinates(estimator.design_query(c))[:2])
        for c in dev.cases() if c["phase_role"] == "fit_development"}
    new_coordinates = [estimator.coordinates(estimator.design_query(c))[:2]
        for c in cases() if c["phase_role"] == "primary_validation"]
    report["checks"].update(rows96_per_gpu=all(counts[g] == 96 for g in range(8)), exact_preregistered_order=ordered,
        partition576_primary192_controls=len(primary) == 576 and len(controls) == 192,
        no_training_coordinate_overlap=not any(c in fit_coordinates for c in new_coordinates),
        candidate_bytes_unchanged=sha256(root / "LOCKED_CANDIDATE.json") == EXPECTED_SHA256 == lock.get("candidate_sha256") == registered.get("candidate_sha256"),
        lock_unchanged=registered.get("prevalidation_lock_sha256") == sha256(root / "PREVALIDATION_LOCK.json"),
        prediction_plan_hash_unchanged=sha256(plan_path) == registered.get("prediction_plan_sha256") == lock.get("prediction_plan_sha256"),
        prior_evidence_unchanged=bool(lock.get("evidence_sha256")) and all(Path(p).is_file() and sha256(p) == h for p, h in lock["evidence_sha256"].items()))
    report.update(candidate_sha256=EXPECTED_SHA256, candidate_frozen=False, model_fitted=False,
        rows_by_gpu={str(g): counts[g] for g in range(8)}, primary_rows=len(primary), future_control_rows=len(controls),
        bounded_primary_validation_passed=False, continuous_arrival_tpot_validated=False,
        classification_threshold_ms=16000,
        note="Bounded heldout primary validation only; controls reported separately. No refit, freeze, runtime install, service-SLO or continuous-arrival TPOT claim.")
    if not all(report["checks"].values()):
        report["status"] = "FAIL"
        return report
    model = json.loads((root / "LOCKED_CANDIDATE.json").read_text())
    report["checks"]["prediction_plan_reproduced"] = plan == prediction_plan(model)
    report["checks"]["live_queries_equal_locked_design"] = all(
        estimator.admission_query(r) == plan[r["case_id"]]["query"] for r in rows)
    if not all(report["checks"].values()):
        report["status"] = "FAIL"
        return report
    items = [estimator.observation(r) for r in primary]
    overall = estimator.evaluate(model, items)
    by_gpu = {str(g): estimator.evaluate(model, [x for x in items if x["gpu"] == g]) for g in range(8)}
    by_stratum = estimator.evaluate(model, items, by_stratum=True)
    controls_report = estimator.evaluate(model, [estimator.observation(r) for r in controls])
    bad_gpu = [dict(gpu=g, group=k, coverage=v["coverage"], samples=v["samples"])
        for g, groups in by_gpu.items() for k, v in groups.items() if v["coverage"] < MIN_COVERAGE]
    bad_stratum = [dict(group=k, coverage=v["coverage"], samples=v["samples"])
        for k, v in by_stratum.items() if v["coverage"] < MIN_COVERAGE]
    report["checks"].update(primary_mode_metric_coverage95=all(g["coverage"] >= MIN_COVERAGE for g in overall.values()),
        every_gpu_mode_metric_coverage95=not bad_gpu, every_phase_stratum_metric_coverage95=not bad_stratum,
        primary_ttft_classification_false_negatives_zero=all(g.get("false_negatives", 0) == 0 for g in overall.values()))
    report.update(primary_overall=overall, primary_by_gpu=by_gpu, primary_by_stratum=by_stratum,
        failed_gpu_groups=bad_gpu, failed_stratum_groups=bad_stratum,
        future_controls_diagnostic_only=controls_report,
        primary_repeat_diagnostics={str(rep): estimator.evaluate(model, [x for x in items if x["repeat"] == rep]) for rep in (0, 1)})
    report["status"] = "PASS" if all(report["checks"].values()) else "FAIL"
    report["bounded_primary_validation_passed"] = report["status"] == "PASS"
    return report


if __name__ == "__main__":
    engine.main(campaign=sys.modules[__name__])
