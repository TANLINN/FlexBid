#!/usr/bin/env bash
set -euo pipefail

cd /root/CarbonAffinity

OUTPUT_ROOT="${1:?usage: run_latency_surface_validation.sh OUTPUT_ROOT MODEL_CANDIDATE}"
MODEL_CANDIDATE="${2:?usage: run_latency_surface_validation.sh OUTPUT_ROOT MODEL_CANDIDATE}"
PYTHON_BIN="$PWD/.venv/bin/python"
VLLM_BIN="$PWD/.venv/bin/vllm"
MODEL_DIR="/root/models/Qwen3.5-27B"
SERVED_MODEL="Qwen3.5-27B"
REGIONS=(
  local_region_a local_region_b
  high_reuse_a high_reuse_b
  low_reuse_a low_reuse_b
  burst_a burst_b
)

mkdir -p "$OUTPUT_ROOT/raw" "$OUTPUT_ROOT/vllm"
printf '%s\n' "$$" > "$OUTPUT_ROOT/supervisor.pid"

if [[ ! -x "$PYTHON_BIN" || ! -x "$VLLM_BIN" ]]; then
  echo "VENV_RUNTIME_MISSING" | tee "$OUTPUT_ROOT/FATAL"
  exit 2
fi
if [[ ! -f "$MODEL_DIR/config.json" ]]; then
  echo "MODEL_MISSING=$MODEL_DIR" | tee "$OUTPUT_ROOT/FATAL"
  exit 2
fi
if [[ ! -f "$MODEL_CANDIDATE" ]]; then
  echo "LATENCY_MODEL_MISSING=$MODEL_CANDIDATE" | tee "$OUTPUT_ROOT/FATAL"
  exit 2
fi

if ps -eo args= | grep -E \
  '[n]ight_guard.sh|[e]mergency_.*retention|[r]un_local_pair_campaign.py|[r]un_real_campaign.py|[m]easure_(batch_energy|concurrency).py|[v]llm serve' \
  > "$OUTPUT_ROOT/conflicting_processes.txt"
then
  echo "CONFLICTING_PROCESS; refusing to overlap" | tee "$OUTPUT_ROOT/FATAL"
  cat "$OUTPUT_ROOT/conflicting_processes.txt"
  exit 3
fi

server_pids=()
worker_pids=()
collect_process_tree() {
  local parent="$1"
  local child
  for child in $(pgrep -P "$parent" 2>/dev/null || true); do
    collect_process_tree "$child"
  done
  printf '%s\n' "$parent"
}
cleanup() {
  set +e
  for pid in "${worker_pids[@]:-}"; do
    [[ -n "$pid" ]] && kill -TERM "$pid" 2>/dev/null
  done
  cleanup_pids=()
  for pid in "${server_pids[@]:-}"; do
    if [[ -n "$pid" ]]; then
      while IFS= read -r member; do
        cleanup_pids+=("$member")
      done < <(collect_process_tree "$pid")
    fi
  done
  if [[ "${#cleanup_pids[@]}" -gt 0 ]]; then
    kill -TERM "${cleanup_pids[@]}" 2>/dev/null
  fi
  sleep 10
  if [[ "${#cleanup_pids[@]}" -gt 0 ]]; then
    kill -KILL "${cleanup_pids[@]}" 2>/dev/null
  fi
}
trap cleanup EXIT INT TERM

echo "$(date -Is) STARTING_VLLM" | tee "$OUTPUT_ROOT/events.log"
for gpu in $(seq 0 7); do
  port=$((18000 + gpu))
  CUDA_VISIBLE_DEVICES="$gpu" \
  VLLM_USE_FLASHINFER_SAMPLER=0 \
  HF_HUB_OFFLINE=1 \
  TRANSFORMERS_OFFLINE=1 \
  "$VLLM_BIN" serve "$MODEL_DIR" \
    --served-model-name "$SERVED_MODEL" \
    --host 127.0.0.1 \
    --port "$port" \
    --tensor-parallel-size 1 \
    --enable-prefix-caching \
    --enable-prompt-tokens-details \
    --max-model-len 65536 \
    --max-num-seqs 8 \
    --gpu-memory-utilization 0.92 \
    --language-model-only \
    > "$OUTPUT_ROOT/vllm/gpu_${gpu}.log" 2>&1 &
  server_pids[$gpu]="$!"
  echo "${server_pids[$gpu]}" > "$OUTPUT_ROOT/vllm/gpu_${gpu}.pid"
done

deadline=$((SECONDS + 1200))
while true; do
  ready=0
  for port in $(seq 18000 18007); do
    if curl -fsS "http://127.0.0.1:${port}/health" >/dev/null 2>&1; then
      ready=$((ready + 1))
    fi
  done
  echo "$(date -Is) VLLM_READY=$ready/8" | tee -a "$OUTPUT_ROOT/events.log"
  [[ "$ready" -eq 8 ]] && break
  if [[ "$SECONDS" -ge "$deadline" ]]; then
    echo "VLLM_STARTUP_TIMEOUT" | tee "$OUTPUT_ROOT/FATAL"
    exit 4
  fi
  for gpu in $(seq 0 7); do
    if ! kill -0 "${server_pids[$gpu]}" 2>/dev/null; then
      echo "VLLM_GPU_${gpu}_EXITED" | tee "$OUTPUT_ROOT/FATAL"
      tail -n 100 "$OUTPUT_ROOT/vllm/gpu_${gpu}.log"
      exit 4
    fi
  done
  sleep 10
done

echo "$(date -Is) EXPLICIT_PREWARM_START" | tee -a "$OUTPUT_ROOT/events.log"
worker_pids=()
for gpu in $(seq 0 7); do
  "$PYTHON_BIN" -u scripts/prewarm_latency_endpoint.py \
    --region-id "${REGIONS[$gpu]}" \
    --api-base "http://127.0.0.1:$((18000 + gpu))/v1" \
    > "$OUTPUT_ROOT/vllm/gpu_${gpu}.prewarm.log" 2>&1 &
  worker_pids[$gpu]="$!"
done
for gpu in $(seq 0 7); do
  if ! wait "${worker_pids[$gpu]}"; then
    echo "PREWARM_GPU_${gpu}_FAILED" | tee "$OUTPUT_ROOT/FATAL"
    cat "$OUTPUT_ROOT/vllm/gpu_${gpu}.prewarm.log"
    exit 5
  fi
done
worker_pids=()
echo "$(date -Is) EXPLICIT_PREWARM_PASS" | tee -a "$OUTPUT_ROOT/events.log"

echo "$(date -Is) VALIDATION_MEASUREMENT_START" | tee -a "$OUTPUT_ROOT/events.log"
for gpu in $(seq 0 7); do
  "$PYTHON_BIN" -u scripts/measure_concurrency.py \
    --region-id "${REGIONS[$gpu]}" \
    --api-base "http://127.0.0.1:$((18000 + gpu))/v1" \
    --model "$SERVED_MODEL" \
    --tokenizer "$MODEL_DIR" \
    --gpu-index "$gpu" \
    --prompt-tokens 2048 8192 32768 \
    --output-tokens 64 \
    --concurrency 1 4 8 \
    --repeats 1 \
    --settle-s 1.0 \
    --timeout-s 900 \
    --output "$OUTPUT_ROOT/raw/gpu_${gpu}.jsonl" \
    --resume \
    > "$OUTPUT_ROOT/raw/gpu_${gpu}.log" 2>&1 &
  worker_pids[$gpu]="$!"
done

failures=0
for gpu in $(seq 0 7); do
  if wait "${worker_pids[$gpu]}"; then
    touch "$OUTPUT_ROOT/raw/gpu_${gpu}.complete"
  else
    touch "$OUTPUT_ROOT/raw/gpu_${gpu}.failed"
    failures=$((failures + 1))
  fi
done
worker_pids=()

rows="$(find "$OUTPUT_ROOT/raw" -name 'gpu_*.jsonl' -type f -exec cat {} + 2>/dev/null | wc -l)"
echo "$(date -Is) VALIDATION_ROWS=$rows FAILURES=$failures" | tee -a "$OUTPUT_ROOT/events.log"
if [[ "$failures" -ne 0 || "$rows" -ne 144 ]]; then
  echo "VALIDATION_MEASUREMENT_FAILED rows=$rows failures=$failures" | tee "$OUTPUT_ROOT/FATAL"
  exit 6
fi

"$PYTHON_BIN" scripts/validate_latency_surface.py \
  --input-root "$OUTPUT_ROOT/raw" \
  --model "$MODEL_CANDIDATE" \
  --output "$OUTPUT_ROOT/independent_validation_report.json" \
  | tee "$OUTPUT_ROOT/independent_validation_report.txt"

printf '{"status":"COMPLETE","rows":144,"completed_s":%s}\n' \
  "$(date +%s)" > "$OUTPUT_ROOT/VALIDATION_COMPLETE.json"
echo "INDEPENDENT_LATENCY_VALIDATION_COMPLETE=$OUTPUT_ROOT"
