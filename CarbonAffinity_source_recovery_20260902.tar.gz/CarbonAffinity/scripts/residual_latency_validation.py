"""Locked-candidate independent validation; never adjusts/fits/freezes a model."""
import hashlib
import itertools
import json
import math
from collections import defaultdict
from pathlib import Path

from carbonaffinity.artifacts import read_rows, quantile, sha256, write_json
from scripts.latency_residual_protocol import GPUS, OUTPUT, cases as development_cases, features, result_checks
from scripts.latency_shape_probe_support import tuning_events
from scripts.residual_latency_candidate import MODEL_KIND, batch_observation, predict

VERSION = "residual-latency-independent-validation-v1"
MEASUREMENT_MODULE = "scripts.measure_latency_residual_validation"
REPORT_NAME = "RESIDUAL_INDEPENDENT_VALIDATION_REPORT.json"
CANDIDATE_PATH = Path("/root/CarbonAffinity/results/latency_residual_candidate_20260830T093035635670917Z/residual_latency_candidate_v1.json")
CANDIDATE_SHA256 = "6e334c42c8de3bb64a41ebb594aef4785fd2ed0325230c8c9ea1c3cf33692c85"
CONTEXTS, RESIDUALS, LOADS = (3920, 15680, 23520), (128, 256, 640), (2, 3, 6)


def cases():
    return [{"case_id": f"heldout_c{c}_u{u}_n{n}_{mode}_r0", "cached_context_target": c,
             "residual_target": u, "prompt_tokens": c + u, "concurrency": n,
             "mode": mode, "repeat": 0, "output_tokens": OUTPUT}
            for c, u, n, mode in itertools.product(CONTEXTS, RESIDUALS, LOADS, ("cold", "warm"))]


def design():
    return {"protocol": VERSION, "expected_rows": 432, "rows_per_gpu": 54,
            "gpu_indices": list(GPUS), "cached_context_targets": list(CONTEXTS),
            "residual_targets": list(RESIDUALS), "concurrency": list(LOADS),
            "repeats": 1, "output_tokens": OUTPUT, "runtime_cap": 784,
            "candidate_sha256": CANDIDATE_SHA256, "coverage_threshold": .95,
            "coverage_unit": "batch maximum of per-request TTFT / mean TPOT",
            "coverage_groups": "each cold/warm metric overall and on every GPU",
            "integrity": "exact matrix; no request errors; exact observed warm cache/residual; unchanged code/model; no post-prewarm tuning",
            "no_refit_or_margin_adjustment": True, "candidate_frozen": False,
            "scope": "new coordinates on same eight GPUs; output64 homogeneous simultaneous batches; not a service SLO, mixed-load, all-domain or new-hardware guarantee",
            "case_order": "context,residual,concurrency,mode; identical on every GPU",
            "per_cell_coverage": "reported diagnostically; not an additional pass/fail gate"}


def code_paths():
    import scripts.measure_latency_residual_validation as measure
    import scripts.residual_latency_candidate as estimator
    import scripts.run_latency_residual_validation as wrapper
    return [Path(__file__).resolve(), Path(measure.__file__).resolve(),
            Path(estimator.__file__).resolve(), Path(wrapper.__file__).resolve()]


def coordinate(case):
    return ((case["prompt_tokens"], case["concurrency"]) if case["mode"] == "cold" else
            (case["cached_context_target"], case["residual_target"], case["concurrency"]))


def load_locked(path):
    data = Path(path).read_bytes()
    if hashlib.sha256(data).hexdigest() != CANDIDATE_SHA256:
        raise ValueError("CANDIDATE_HASH_MISMATCH_NOT_STARTED")
    model = json.loads(data)
    if (model.get("model_kind") != MODEL_KIND or model.get("candidate_frozen") is not False
            or model.get("independent_validation_passed") is not False):
        raise ValueError("candidate schema/status mismatch")
    return data, model


def prepare(root, args):
    data, model = load_locked(CANDIDATE_PATH)
    fit_root = CANDIDATE_PATH.parent
    fit_record_path = fit_root / "FIT_RECORD.json"
    if sha256(fit_record_path) != model["development_source"]["fit_record_sha256"]:
        raise ValueError("FIT_RECORD_HASH_MISMATCH")
    fit_record = json.loads(fit_record_path.read_text())
    # The estimator implementation must be the same one used for the fitted
    # candidate; LF normalization only makes Windows/Linux line endings portable.
    import scripts.residual_latency_candidate as estimator
    import scripts.latency_residual_protocol as protocol
    for module in (estimator, protocol):
        current = Path(module.__file__)
        original_paths = [Path(p) for p in fit_record["fit_code_sha256"] if Path(p).name == current.name]
        if len(original_paths) != 1 or sha256(original_paths[0]) != fit_record["fit_code_sha256"][str(original_paths[0])]:
            raise ValueError("fitted predictor source missing/changed")
        if original_paths[0].read_text(encoding="utf-8") != current.read_text(encoding="utf-8"):
            raise ValueError("validation predictor differs from fitted predictor")
    predictions = {c["case_id"]: predict(model, c["mode"], coordinate(c)) for c in cases()}
    if not all(p["in_domain"] for p in predictions.values()):
        raise ValueError("validation design is out of candidate domain")
    with (root / "CANDIDATE_LOCKED.json").open("xb") as handle:
        handle.write(data)
    write_json(root / "PREDICTIONS_BEFORE_MEASUREMENT.json", predictions)
    return {"candidate_source": str(CANDIDATE_PATH), "candidate_sha256": CANDIDATE_SHA256,
            "prediction_sha256": sha256(root / "PREDICTIONS_BEFORE_MEASUREMENT.json"),
            "fit_record_sha256": sha256(fit_record_path), "validation_data_used_for_refit": False}


def statistics(values):
    actuals, predictions = zip(*values)
    ratios = [a / p for a, p in values if p > 0]
    reverse = [p / a for a, p in values if a > 0]
    return {"samples": len(values), "covered": sum(a <= p for a, p in values),
            "coverage": sum(a <= p for a, p in values) / len(values),
            "actual_over_prediction_q95": quantile(ratios, .95) if ratios else None,
            "actual_over_prediction_max": max(ratios) if ratios else None,
            "prediction_over_actual_median": quantile(reverse, .5) if reverse else None,
            "prediction_over_actual_q95": quantile(reverse, .95) if reverse else None,
            "zero_actual_count": sum(a == 0 for a in actuals),
            "zero_prediction_count": sum(p == 0 for p in predictions),
            "max_underprediction_ms": max(max(0., a - p) for a, p in values)}


def audit(root):
    root = Path(root)
    _, model = load_locked(root / "CANDIDATE_LOCKED.json")
    registered = json.loads((root / "PREREGISTRATION.json").read_text())
    forecast_file = root / "PREDICTIONS_BEFORE_MEASUREMENT.json"
    forecasts = json.loads(forecast_file.read_text())
    launch = json.loads((root / "LAUNCH.json").read_text())
    warmup = json.loads((root / "SHAPE_PREWARM.json").read_text())
    rows = read_rows(root / "raw")
    planned = {c["case_id"]: c for c in cases()}
    keys = [(r.get("gpu_index"), r.get("case_id")) for r in rows]
    expected = {(gpu, c) for gpu in GPUS for c in planned}
    checks = {"exact_432_cases": len(keys) == len(expected) and set(keys) == expected,
        "54_rows_per_gpu": all(sum(r.get("gpu_index") == gpu for r in rows) == 54 for gpu in GPUS),
        "preregistration_unchanged": registered.get("design") == design() and registered.get("expected_rows") == 432,
        "candidate_sha_recorded": registered.get("candidate_sha256") == CANDIDATE_SHA256,
        "source_candidate_unchanged": sha256(registered["candidate_source"]) == CANDIDATE_SHA256,
        "predictions_unchanged": sha256(forecast_file) == registered.get("prediction_sha256"),
        "predictions_recomputed_exact": forecasts == {c["case_id"]: predict(model, c["mode"], coordinate(c)) for c in cases()},
        "all_predictions_in_domain": all(p["in_domain"] for p in forecasts.values()),
        "runtime_cap_and_block": launch.get("runtime_cap") == 784 and launch.get("effective_cap_verified") is True
            and launch.get("cache_block784_verified") is True,
        "eight_gpu_prewarm": warmup.get("gpu_indices") == list(GPUS) and warmup.get("requests") == 64
            and warmup["checks"]["all_shape_keys_observed"] is True,
        "code_unchanged": bool(registered.get("code_sha256")) and all(Path(p).is_file() and sha256(p) == h
            for p, h in registered["code_sha256"].items()),
        "no_training_coordinate_overlap": not ({(c["mode"], *coordinate(c)) for c in cases()} &
            {(c["mode"], *coordinate(c)) for c in development_cases()})}
    errors, violations = [], []
    grouped, by_gpu, by_cell = defaultdict(list), defaultdict(list), defaultdict(list)
    for row in rows:
        case = planned.get(row.get("case_id"))
        try:
            if case is None or row.get("protocol") != VERSION or any(row.get(k) != v for k, v in case.items()):
                raise ValueError("unregistered case metadata")
            records = row.get("results", [])
            expected_cache = case["cached_context_target"] if case["mode"] == "warm" else None
            recomputed = [result_checks(r, case["prompt_tokens"], OUTPUT, expected_cache) for r in records]
            if len(records) != case["concurrency"] or not all(all(c.values()) for c in recomputed):
                raise ValueError("request/token/cache/latency checks failed")
            if row.get("result_checks") != recomputed or row.get("cache_features") != [features(r) for r in records]:
                raise ValueError("recorded checks/features differ from raw")
            if row.get("runtime_evidence_sha256") != sha256(root / "LAUNCH.json"):
                raise ValueError("runtime evidence differs")
            salts = row.get("cache_salts", [])
            if len(salts) != case["concurrency"] or not all(isinstance(s, str) and s for s in salts):
                raise ValueError("missing cache namespaces")
            if len(set(salts)) != (1 if case["mode"] == "warm" else case["concurrency"]):
                raise ValueError("wrong cache namespace isolation")
            if case["mode"] == "warm":
                if not all(result_checks(row.get("prime") or {}, case["prompt_tokens"], 1).values()):
                    raise ValueError("warm prime failed")
            elif row.get("prime") is not None:
                raise ValueError("cold case has prime")
            item = batch_observation(row)
            forecast = forecasts[case["case_id"]]["prediction_ms"]
            for metric, actual in item["metrics"].items():
                upper = forecast[metric]
                if not math.isfinite(upper) or upper < 0:
                    raise ValueError("invalid forecast")
                name = case["mode"] + "_" + metric
                grouped[name].append((actual, upper))
                by_gpu[(str(row["gpu_index"]), name)].append((actual, upper))
                by_cell[(case["case_id"], metric)].append((actual, upper))
                if actual > upper:
                    violations.append({"gpu": row["gpu_index"], "case_id": case["case_id"],
                                       "metric": metric, "actual_ms": actual, "predicted_ms": upper})
        except (ValueError, KeyError, TypeError) as exc:
            errors.append({"gpu": row.get("gpu_index"), "case_id": row.get("case_id"), "error": str(exc)})
    checks["all_raw_integrity_checks"] = not errors
    names = [mode + "_" + metric for mode in ("cold", "warm") for metric in ("ttft_ms", "tpot_ms")]
    overall = {name: statistics(values) for name, values in grouped.items()}
    per_gpu = {str(g): {name: statistics(by_gpu[(str(g), name)]) for name in names if by_gpu[(str(g), name)]} for g in GPUS}
    checks["each_mode_metric_coverage_95pct"] = all(name in overall and overall[name]["samples"] == 216
        and overall[name]["coverage"] >= .95 for name in names)
    checks["each_gpu_mode_metric_coverage_95pct"] = all(name in per_gpu[str(g)]
        and per_gpu[str(g)][name]["samples"] == 27 and per_gpu[str(g)][name]["coverage"] >= .95
        for g in GPUS for name in names)
    post_events = {}
    checks["prewarm_log_prefix_unchanged"] = True
    for gpu in GPUS:
        content = (root / f"vllm_gpu_{gpu}.log").read_bytes()
        prior = warmup["logs"][str(gpu)]
        if hashlib.sha256(content[:prior["bytes"]]).hexdigest() != prior["sha256"]:
            checks["prewarm_log_prefix_unchanged"] = False
            post_events[str(gpu)] = [{"error": "log prefix changed"}]
        else:
            post_events[str(gpu)] = tuning_events(content[prior["bytes"]:].decode(errors="replace"))
    checks["no_new_autotuning_after_prewarm"] = not any(post_events.values())
    return {"status": "PASS" if all(checks.values()) else "FAIL", "stage": VERSION,
            "candidate_sha256": CANDIDATE_SHA256, "candidate_frozen": False, "rows": len(rows),
            "checks": checks, "overall": overall, "by_gpu": per_gpu,
            "by_cell": {c: {m: statistics(by_cell[(c, m)]) for m in ("ttft_ms", "tpot_ms") if by_cell[(c, m)]} for c in planned},
            "underpredictions": violations, "integrity_errors": errors, "post_prewarm_tuning_events": post_events,
            "note": "No refit. PASS only evaluates this heldout grid; no runtime installation, freeze, service SLO or carbon-advantage claim."}
