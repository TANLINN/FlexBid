param([switch]$PrintOnly)
$ErrorActionPreference = 'Stop'
$residualProject = Split-Path $PSScriptRoot -Parent
$residualPython = Join-Path $residualProject '.venv-recovery/Scripts/python.exe'
$residualBuilder = Join-Path $PSScriptRoot 'build_latency_residual_transfer.py'
$residualLines = & $residualPython $residualBuilder
if ($LASTEXITCODE -ne 0) { throw 'Bundle generation failed; nothing copied or started.' }
$residualCommand = ($residualLines -join "`n") + "`n"
if ($PrintOnly) { Write-Output $residualCommand; exit 0 }
Set-Clipboard -Value $residualCommand
Write-Host 'Complete command copied. Paste ONCE in the SERVER terminal.'
Write-Host 'Installs an isolated source bundle, checks core hashes and tests, then starts eight-GPU development.'
Write-Host 'Expected: 864 batches (108/GPU). Does not fit/freeze a model or overwrite previous results.'
