"""Rebuild runnable eight-region configs from retained traces, without overwriting them."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import yaml

from carbonaffinity.artifacts import sha256, write_json

PROJECT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--model", default="Qwen3.5-27B")
    parser.add_argument("--profile-dir", type=Path, required=True, help="directory with gpu_0.json ... gpu_7.json")
    parser.add_argument("--repetitions", type=int, default=5)
    parser.add_argument("--network-model", type=Path, help="newly calibrated byte-model JSON; absent means network disabled")
    args = parser.parse_args()
    network = None if args.network_model is None else json.loads(args.network_model.read_text())
    records = []
    excluded = set()
    for window in range(4):
        trace = PROJECT / f"data/normalized/tracelab_real_window_{window:02d}.jsonl"
        carbon = PROJECT / f"data/carbon/neso_eight_region_dev_{window:02d}.csv"
        if not trace.is_file() or not carbon.is_file():
            raise FileNotFoundError("retained trace/carbon files missing; inspect the old archive")
        rows = [json.loads(line) for line in trace.read_text().splitlines() if line.strip()]
        excluded.update(row["session_id"] for row in rows)
        for repeat in range(args.repetitions):
            regions = []
            for index in range(8):
                gpu = (index + repeat) % 8
                row = {"id": f"neso_region_{index:02d}", "api_base": f"http://127.0.0.1:{18000 + gpu}/v1",
                       "control_base": "http://127.0.0.1:1", "model": args.model, "api_key": "EMPTY",
                       "profile": str(args.profile_dir.resolve() / f"gpu_{gpu}.json"),
                       "site_manifest": f"manifests/gpu_{gpu}.json", "gpu_count": 1,
                       "tensor_parallel_size": 1, "admission_concurrency": 8, "rtt_ms": 0}
                if network is not None:
                    row["network"] = {**network["network_config"], "enabled": True, "inject_delay": True,
                        "rtt_ms": [10, 20, 40, 60, 80, 100, 120, 150][index],
                        "uplink_mbps": [1000, 900, 750, 600, 500, 400, 300, 250][index],
                        "downlink_mbps": [1000, 900, 750, 600, 500, 400, 300, 250][index],
                        "energy_kwh_per_gb": [.005, .0075, .01, .0125, .015, .02, .025, .03][index],
                        "carbon_g_per_kwh": 400}
                regions.append(row)
            config = {"experiment": {"name": f"recovered_w{window:02d}_r{repeat:02d}", "model": args.model,
                        "tokenizer": args.tokenizer, "trace": str(trace.relative_to(PROJECT))},
                      "regions": regions, "carbon": {"trace": str(carbon.relative_to(PROJECT)), "clock_mode": "trace_relative",
                        "trace_start_timestamp": "2026-01-01T00:00:00Z", "max_age_s": 180},
                      "routing": {"policy": "carbon_affinity"}, "runtime": {"arrival_scale": 1, "max_in_flight": 64},
                      "artifact_metadata": {"status": "RECOVERED_CONFIGURATION_NOT_VALIDATED", "same_host_only": True,
                        "network_scenario": "disabled" if network is None else "assumed_WAN_not_physical_measurement",
                        "logical_region_to_gpu": [(i + repeat) % 8 for i in range(8)]}}
            path = PROJECT / f"configs/recovered_w{window:02d}_r{repeat:02d}.yaml"
            with path.open("x", encoding="utf-8") as handle:
                yaml.safe_dump(config, handle, sort_keys=False)
            records.append({"config": str(path), "sha256": sha256(path)})
    write_json(PROJECT / "results/recovered_input_manifest.json", {"status": "INPUTS_RECONSTRUCTED", "configs": records,
               "excluded_session_ids": sorted(excluded), "not_a_new_heldout_test": True})
    print(f"RECOVERED_CONFIGS={len(records)}; profile files must be newly calibrated before running")


if __name__ == "__main__":
    main()
