"""Concise local recovery/dependency status, or progress for one campaign root."""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path)
    args = parser.parse_args()
    if args.root:
        root = args.root
        print("ROOT =", root)
        rows = 0
        for path in sorted(root.rglob("measurements.jsonl")):
            with path.open(encoding="utf-8") as handle:
                count = sum(bool(line.strip()) for line in handle)
            rows += count
            print(path.relative_to(root), count)
        print("measurement rows =", rows)
        for path in sorted((root / "policies").glob("*/requests.jsonl")):
            with path.open(encoding="utf-8") as handle:
                print(path.parent.name, "requests =", sum(bool(line.strip()) for line in handle))
        if (root / "PREREGISTRATION.json").is_file():
            prereg = json.loads((root / "PREREGISTRATION.json").read_text())
            print("expected rows/requests =", prereg.get("expected_rows"), "stage =", prereg.get("stage"))
        for name in ("FATAL.json", "EXPERIMENT_COMPLETE.json", "INDEPENDENT_VALIDATION_REPORT.json", "AUTHORITATIVE_SLO_REPORT.json"):
            if (root / name).is_file():
                report = json.loads((root / name).read_text())
                print(name, "status=", report.get("status"), report.get("error", ""))
        if (root / "events.log").is_file():
            print("\n".join((root / "events.log").read_text().splitlines()[-5:]))
        return
    project = Path(__file__).resolve().parents[1]
    for name in ("numpy", "yaml", "httpx", "pynvml", "transformers", "torch", "vllm"):
        print(f"dependency {name}: {'installed' if importlib.util.find_spec(name) else 'missing'}")
    for path in ("data/raw/syfi_coding_trace.jsonl.gz", "data/raw/regional_carbon_intensity.csv",
                 "profiles/gpu_0.json", "profiles/cap784_latency_frozen.json", "profiles/corun_ttft_frozen.json"):
        print(path, "PRESENT" if (project / path).is_file() else "MISSING/NEEDS_CALIBRATION")
    print("Physical experiment success cannot be inferred from local source restoration.")


if __name__ == "__main__":
    main()
