#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODEL_DIR="${MODEL_DIR:-/root/models/Qwen3.5-27B}"
SERVED_MODEL_NAME="${SERVED_MODEL_NAME:-Qwen3.5-27B}"
GPU_INDEX="${GPU_INDEX:-0}"
PORT="${PORT:-18000}"
MAX_MODEL_LEN="${MAX_MODEL_LEN:-32768}"

cd "$ROOT"
source .venv/bin/activate
mkdir -p results/vllm

if curl -fsS "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1; then
  echo "vLLM is already healthy on port $PORT"
  exit 0
fi

CUDA_VISIBLE_DEVICES="$GPU_INDEX" \
VLLM_USE_FLASHINFER_SAMPLER=0 \
HF_HUB_OFFLINE=1 \
TRANSFORMERS_OFFLINE=1 \
nohup vllm serve "$MODEL_DIR" \
  --served-model-name "$SERVED_MODEL_NAME" \
  --host 127.0.0.1 \
  --port "$PORT" \
  --tensor-parallel-size 1 \
  --enable-prefix-caching \
  --enable-prompt-tokens-details \
  --max-model-len "$MAX_MODEL_LEN" \
  --max-num-seqs 8 \
  --gpu-memory-utilization 0.92 \
  --language-model-only \
  > results/vllm/server.log 2>&1 &

PID=$!
echo "$PID" > results/vllm/server.pid

for _ in $(seq 1 180); do
  if curl -fsS "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1; then
    echo "VLLM_READY PID=$PID PORT=$PORT"
    exit 0
  fi
  if ! kill -0 "$PID" 2>/dev/null; then
    echo "vLLM exited during startup" >&2
    tail -n 200 results/vllm/server.log >&2
    exit 1
  fi
  sleep 5
done

echo "vLLM startup timed out" >&2
tail -n 200 results/vllm/server.log >&2
exit 1
