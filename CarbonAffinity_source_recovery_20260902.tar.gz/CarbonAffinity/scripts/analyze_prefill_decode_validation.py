from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = min(
        len(ordered) - 1,
        max(0, int((len(ordered) - 1) * q + 0.999999)),
    )
    return ordered[index]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--calibration-report", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-rows", type=int, default=384)
    parser.add_argument("--candidate", type=int, default=32768)
    parser.add_argument("--tail-slo-ms", type=float, default=300.0)
    args = parser.parse_args()

    paths = sorted(args.input_root.glob("gpu_*.jsonl"))
    rows = [
        json.loads(line)
        for path in paths
        for line in path.read_text().splitlines()
        if line.strip()
    ]
    failures = sum(int(row["failures"]) for row in rows)
    gpus = sorted({int(row["gpu_index"]) for row in rows})
    totals: dict[int, list[dict]] = defaultdict(list)
    shapes: dict[tuple, list[dict]] = defaultdict(list)
    for row in rows:
        total = int(row["total_interfering_prefill_tokens"])
        totals[total].append(row)
        shapes[(
            tuple(row["prefill_shape"]),
            int(row["victim_prompt_tokens"]),
            int(row["victim_output_tokens"]),
        )].append(row)

    total_curve = []
    for total, cases in sorted(totals.items()):
        values = [
            float(row["victim"]["p95_itl_ms"])
            for row in cases
            if row["victim"]["p95_itl_ms"] is not None
        ]
        q95 = percentile(values, 0.95)
        total_curve.append({
            "total_prefill_tokens": total,
            "cases": len(cases),
            "p95_itl_q95_ms": q95,
            "tail_slo_violation_rate": (
                sum(value > args.tail_slo_ms for value in values)
                / len(values)
                if values else None
            ),
            "within_candidate": total <= args.candidate,
            "passed_tail_slo": (
                q95 is not None and q95 <= args.tail_slo_ms
            ),
        })

    shape_curve = []
    for (shape, victim_prompt, victim_output), cases in sorted(
        shapes.items()
    ):
        values = [
            float(row["victim"]["p95_itl_ms"])
            for row in cases
            if row["victim"]["p95_itl_ms"] is not None
        ]
        q95 = percentile(values, 0.95)
        shape_curve.append({
            "prefill_shape": list(shape),
            "total_prefill_tokens": sum(shape),
            "victim_prompt_tokens": victim_prompt,
            "victim_output_tokens": victim_output,
            "cases": len(cases),
            "p95_itl_q95_ms": q95,
            "passed_tail_slo": (
                q95 is not None and q95 <= args.tail_slo_ms
            ),
        })

    candidate_rows = [
        row for row in total_curve
        if row["within_candidate"]
    ]
    checks = {
        "expected_row_count": len(rows) == args.expected_rows,
        "all_eight_gpus": gpus == list(range(8)),
        "no_request_failures": failures == 0,
        "candidate_was_not_refit": True,
        "all_loads_at_or_below_candidate_pass": (
            bool(candidate_rows)
            and all(row["passed_tail_slo"] for row in candidate_rows)
        ),
        "candidate_boundary_present": any(
            row["total_prefill_tokens"] == args.candidate
            for row in total_curve
        ),
    }
    report = {
        "schema_version": 1,
        "status": "PASS" if all(checks.values()) else "FAIL",
        "role": "independent_prefill_capacity_validation",
        "candidate_prefill_token_capacity": args.candidate,
        "candidate_refit_on_validation": False,
        "tail_token_slo_ms": args.tail_slo_ms,
        "rows": len(rows),
        "gpus": gpus,
        "failures": failures,
        "checks": checks,
        "total_curve": total_curve,
        "shape_curve": shape_curve,
        "calibration_report": str(args.calibration_report.resolve()),
        "calibration_report_sha256": hashlib.sha256(
            args.calibration_report.read_bytes()
        ).hexdigest(),
        "validation_source_sha256": {
            path.name: hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths
        },
    }
    args.output.write_text(
        json.dumps(report, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))
    if report["status"] != "PASS":
        raise SystemExit(1)
    print("PREFILL_CAPACITY_INDEPENDENT_VALIDATION_PASS")


if __name__ == "__main__":
    main()
