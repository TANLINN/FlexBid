param([switch]$PrintOnly)
$ErrorActionPreference = 'Stop'
$probePath = Join-Path $PSScriptRoot 'run_latency_pause_probe.sh'
$probeBody = [IO.File]::ReadAllText($probePath).Replace("`r`n", "`n").TrimEnd([char[]]"`r`n") + "`n"
if ($probeBody.Contains("`r")) { throw 'Unexpected CR in script' }
$probeBytes = [Text.UTF8Encoding]::new($false).GetBytes($probeBody)
$probeHasher = [Security.Cryptography.SHA256]::Create()
try {
    $probeHash = [BitConverter]::ToString($probeHasher.ComputeHash($probeBytes)).Replace('-', '').ToLowerInvariant()
} finally {
    $probeHasher.Dispose()
}
$probeHead = @'
cd /root/CarbonAffinity
if PROBE_SCRIPT="$(.venv/bin/python -c '
import hashlib, sys, tempfile
from pathlib import Path
data = sys.stdin.buffer.read()
expected = sys.argv[1]
actual = hashlib.sha256(data).hexdigest()
if actual != expected:
    raise SystemExit("SOURCE_CHECKSUM_FAILED_NOT_INSTALLED: " + actual)
with tempfile.NamedTemporaryFile(mode="wb", prefix="latency_pause_probe_", suffix=".sh", dir="scripts", delete=False) as handle:
    handle.write(data)
    path = Path(handle.name).resolve()
if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
    raise SystemExit("INSTALLED_CHECKSUM_FAILED_NOT_STARTED")
print(path)
' '__EXPECTED_SHA256__' <<'LATENCY_PROBE_SOURCE_EOF'
'@
$probeTail = @'
LATENCY_PROBE_SOURCE_EOF
)"
then
    if bash -n "$PROBE_SCRIPT"; then
        PROBE="/root/CarbonAffinity/results/latency_pause_probe_$(date -u +%Y%m%dT%H%M%SZ)"
        echo "SCRIPT=$PROBE_SCRIPT"
        sha256sum "$PROBE_SCRIPT"
        nohup bash "$PROBE_SCRIPT" "$PROBE" > "${PROBE}.launcher.log" 2>&1 < /dev/null &
        PROBE_PID=$!
        echo "PROBE_PID=$PROBE_PID ROOT=$PROBE"
        echo "PROBE_SUBMITTED_CHECK_LOG_FOR_STARTUP"
    else
        echo "SCRIPT_SYNTAX_FAILED_NOT_STARTED"
    fi
else
    echo "SCRIPT_INSTALL_FAILED_NOT_STARTED"
fi
'@
$probeCommand = ($probeHead.Replace('__EXPECTED_SHA256__', $probeHash) + "`n" + $probeBody + $probeTail + "`n").Replace("`r`n", "`n")
if ($PrintOnly) {
    Write-Output $probeCommand
} else {
    Set-Clipboard -Value $probeCommand
    Write-Host "Copied verified FILE-based launch command. SHA256=$probeHash"
    Write-Host 'Paste in the Linux server terminal. No GPU process was started locally.'
}
