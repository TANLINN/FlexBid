param(
    [string]$InputRoot = '/root/CarbonAffinity/results/latency_residual_dev_20260830T082216Z',
    [switch]$PrintOnly
)
$ErrorActionPreference = 'Stop'
$fitProject = Split-Path $PSScriptRoot -Parent
$fitPython = Join-Path $fitProject '.venv-recovery/Scripts/python.exe'
Push-Location $fitProject
try {
    $fitLines = & $fitPython -m scripts.build_latency_residual_fit_transfer --input-root $InputRoot
    if ($LASTEXITCODE -ne 0) { throw 'Fit command generation failed; nothing copied or started.' }
} finally {
    Pop-Location
}
$fitCommand = ($fitLines -join "`n") + "`n"
if ($PrintOnly) { Write-Output $fitCommand; exit 0 }
Set-Clipboard -Value $fitCommand
Write-Host 'CPU-only fit command copied. Paste ONCE in the SERVER terminal.'
Write-Host "Development source: $InputRoot"
Write-Host 'Checks source integrity, builds a new candidate, and records LOO diagnostics.'
Write-Host 'No GPU launch, no overwrite of development data, no model freeze or runtime installation.'
