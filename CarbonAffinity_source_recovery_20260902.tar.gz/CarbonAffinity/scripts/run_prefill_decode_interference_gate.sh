#!/usr/bin/env bash
set -euo pipefail

cd /root/CarbonAffinity

OUTPUT_ROOT="${1:?usage: run_prefill_decode_interference_gate.sh OUTPUT_ROOT}"
PYTHON_BIN="$PWD/.venv/bin/python"
VLLM_BIN="$PWD/.venv/bin/vllm"
MODEL_DIR="/root/models/Qwen3.5-27B"
SERVED_MODEL="Qwen3.5-27B"

mkdir -p "$OUTPUT_ROOT/raw" "$OUTPUT_ROOT/vllm" "$OUTPUT_ROOT/cache"
printf '%s\n' "$$" > "$OUTPUT_ROOT/supervisor.pid"

fatal() {
  printf '%s\n' "$1" | tee "$OUTPUT_ROOT/FATAL"
  exit 1
}

[[ -x "$PYTHON_BIN" ]] || fatal "PYTHON_MISSING=$PYTHON_BIN"
[[ -x "$VLLM_BIN" ]] || fatal "VLLM_MISSING=$VLLM_BIN"
[[ -f "$MODEL_DIR/config.json" ]] || fatal "MODEL_MISSING=$MODEL_DIR"

if ps -eo args= | grep -E \
  '[n]ight_guard.sh|[e]mergency_.*retention|[r]un_local_(pair|multiregion)_campaign.py|[r]un_joint_8vllm|[m]easure_(batch_energy|concurrency|prefill_decode).py|[v]llm serve' \
  > "$OUTPUT_ROOT/conflicting_processes.txt"
then
  fatal "CONFLICTING_PROCESS_FOUND"
fi

server_pids=()
worker_pids=()

collect_process_tree() {
  local parent="$1"
  local child
  for child in $(pgrep -P "$parent" 2>/dev/null || true); do
    collect_process_tree "$child"
  done
  printf '%s\n' "$parent"
}

cleanup() {
  set +e
  for pid in "${worker_pids[@]:-}"; do
    [[ -n "$pid" ]] && kill -TERM "$pid" 2>/dev/null
  done
  cleanup_pids=()
  for pid in "${server_pids[@]:-}"; do
    if [[ -n "$pid" ]]; then
      while IFS= read -r member; do
        cleanup_pids+=("$member")
      done < <(collect_process_tree "$pid")
    fi
  done
  if [[ "${#cleanup_pids[@]}" -gt 0 ]]; then
    kill -TERM "${cleanup_pids[@]}" 2>/dev/null
    sleep 10
    kill -KILL "${cleanup_pids[@]}" 2>/dev/null
  fi
}

trap cleanup EXIT INT TERM

echo "$(date -Is) STARTING_VLLM_8" | tee "$OUTPUT_ROOT/events.log"
for gpu in $(seq 0 7); do
  port=$((18000 + gpu))
  mkdir -p \
    "$OUTPUT_ROOT/cache/gpu_${gpu}/torch" \
    "$OUTPUT_ROOT/cache/gpu_${gpu}/triton" \
    "$OUTPUT_ROOT/cache/gpu_${gpu}/vllm"
  CUDA_VISIBLE_DEVICES="$gpu" \
  TORCHINDUCTOR_CACHE_DIR="$OUTPUT_ROOT/cache/gpu_${gpu}/torch" \
  TRITON_CACHE_DIR="$OUTPUT_ROOT/cache/gpu_${gpu}/triton" \
  VLLM_CACHE_ROOT="$OUTPUT_ROOT/cache/gpu_${gpu}/vllm" \
  VLLM_USE_FLASHINFER_SAMPLER=0 \
  HF_HUB_OFFLINE=1 \
  TRANSFORMERS_OFFLINE=1 \
  "$VLLM_BIN" serve "$MODEL_DIR" \
    --served-model-name "$SERVED_MODEL" \
    --host 127.0.0.1 \
    --port "$port" \
    --tensor-parallel-size 1 \
    --enable-prefix-caching \
    --enable-prompt-tokens-details \
    --max-model-len 65536 \
    --max-num-seqs 8 \
    --gpu-memory-utilization 0.92 \
    --language-model-only \
    > "$OUTPUT_ROOT/vllm/gpu_${gpu}.log" 2>&1 &
  server_pids[$gpu]="$!"
  printf '%s\n' "${server_pids[$gpu]}" \
    > "$OUTPUT_ROOT/vllm/gpu_${gpu}.pid"
done

deadline=$((SECONDS + 1800))
while true; do
  ready=0
  for port in $(seq 18000 18007); do
    curl -fsS "http://127.0.0.1:${port}/health" >/dev/null 2>&1 \
      && ready=$((ready + 1))
  done
  echo "$(date -Is) VLLM_READY=$ready/8" | tee -a "$OUTPUT_ROOT/events.log"
  [[ "$ready" -eq 8 ]] && break
  [[ "$SECONDS" -lt "$deadline" ]] || fatal "VLLM_STARTUP_TIMEOUT"
  for gpu in $(seq 0 7); do
    kill -0 "${server_pids[$gpu]}" 2>/dev/null \
      || fatal "VLLM_GPU_${gpu}_EXITED"
  done
  sleep 10
done

echo "$(date -Is) PREWARM_START" | tee -a "$OUTPUT_ROOT/events.log"
for gpu in $(seq 0 7); do
  "$PYTHON_BIN" -u scripts/prewarm_latency_endpoint.py \
    --region-id "interference_gpu_${gpu}" \
    --api-base "http://127.0.0.1:$((18000 + gpu))/v1" \
    --requests 2 \
    --prompt-tokens 2048 \
    --output-tokens 32 \
    > "$OUTPUT_ROOT/vllm/gpu_${gpu}.prewarm.log" 2>&1 &
  worker_pids[$gpu]="$!"
done
for gpu in $(seq 0 7); do
  wait "${worker_pids[$gpu]}" || fatal "PREWARM_GPU_${gpu}_FAILED"
done
worker_pids=()
echo "$(date -Is) PREWARM_PASS" | tee -a "$OUTPUT_ROOT/events.log"

echo "$(date -Is) INTERFERENCE_MEASUREMENT_START" \
  | tee -a "$OUTPUT_ROOT/events.log"
for gpu in $(seq 0 7); do
  "$PYTHON_BIN" -u scripts/measure_prefill_decode_interference.py \
    --region-id "interference_gpu_${gpu}" \
    --api-base "http://127.0.0.1:$((18000 + gpu))/v1" \
    --model "$SERVED_MODEL" \
    --tokenizer "$MODEL_DIR" \
    --gpu-index "$gpu" \
    --prefill-tokens 4096 8192 16384 \
    --prefill-count 0 1 2 3 \
    --repeats 3 \
    --victim-prompt-tokens 2048 \
    --victim-output-tokens 128 \
    --interferer-output-tokens 8 \
    --interference-delay-ms 25 \
    --settle-s 0.5 \
    --timeout-s 900 \
    --output "$OUTPUT_ROOT/raw/gpu_${gpu}.jsonl" \
    --resume \
    > "$OUTPUT_ROOT/raw/gpu_${gpu}.log" 2>&1 &
  worker_pids[$gpu]="$!"
done

failures=0
for gpu in $(seq 0 7); do
  if wait "${worker_pids[$gpu]}"; then
    touch "$OUTPUT_ROOT/raw/gpu_${gpu}.complete"
  else
    touch "$OUTPUT_ROOT/raw/gpu_${gpu}.failed"
    failures=$((failures + 1))
  fi
done
worker_pids=()

rows="$(find "$OUTPUT_ROOT/raw" -name 'gpu_*.jsonl' -type f \
  -exec cat {} + 2>/dev/null | wc -l)"
echo "$(date -Is) ROWS=$rows FAILURES=$failures" \
  | tee -a "$OUTPUT_ROOT/events.log"
[[ "$failures" -eq 0 ]] || fatal "MEASUREMENT_WORKER_FAILURES=$failures"
[[ "$rows" -eq 288 ]] || fatal "MEASUREMENT_ROW_MISMATCH=$rows"

"$PYTHON_BIN" scripts/analyze_prefill_decode_interference.py \
  --input-root "$OUTPUT_ROOT/raw" \
  --output "$OUTPUT_ROOT/interference_report.json" \
  --expected-rows 288 \
  --tpot-slo-ms 300 \
  | tee "$OUTPUT_ROOT/interference_report.txt"

printf '{"status":"COMPLETE","rows":288,"gpus":8,"completed_s":%s}\n' \
  "$(date +%s)" > "$OUTPUT_ROOT/INTERFERENCE_GATE_COMPLETE.json"
echo "PREFILL_DECODE_INTERFERENCE_GATE_COMPLETE=$OUTPUT_ROOT"
