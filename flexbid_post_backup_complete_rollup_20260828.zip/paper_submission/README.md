# FlexBid EuroSys paper

This directory contains the submission-oriented manuscript for:

> **FlexBid: Recovery-Aware Demand Response for Hybrid LLM Serving**

The paper follows one argument: deferring batch inference creates debt, so the
largest safe power commitment is the largest curtailment trajectory that still
has an online-SLO-safe path to the batch deadline. The controller is therefore
a dynamic, risk-calibrated viability MPC rather than a fixed action or a
per-epoch configuration filter.

## Structure

1. Introduction
2. Background and Motivation
3. FlexBid Overview and Model
4. Risk-Calibrated Viability MPC
5. Implementation
6. Evaluation Methodology
7. Related Work and Scope
8. Conclusion

The current implementation claim is intentionally limited to one metered power
domain with warm vLLM replicas. Cross-node RTT, KV migration, bandwidth
contention, and cold activation are identified as extensions, not claimed as
evaluated contributions.

## Build

Run `latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex` from this
directory. Reviewer self-audits and their resulting revisions are recorded in
`review_history/`.
