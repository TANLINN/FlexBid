"""Risk-calibrated viability MPC for hybrid online--batch serving.

The old controller selected one action from a hand-written menu.  This module
instead optimizes a *sequence* of joint replica, batch-concurrency, and power-cap
actions over the demand-response event and its recovery horizon.  Only the first
action is applied; the runtime re-solves after observing fresh telemetry.
"""

from __future__ import annotations

import math
import time
from dataclasses import asdict, dataclass, field
from typing import Iterable, Mapping, Protocol

from .contracts import FlexibilityContract
from .modeling import HybridBounds, HybridPrediction
from .types import HybridAction


class PredictiveModel(Protocol):
    def predict(self, row: dict) -> HybridPrediction: ...

    def bounds(self, row: dict, mode: str) -> HybridBounds: ...


@dataclass(frozen=True)
class ControlState:
    """Measured and forecast state at one MPC re-planning instant."""

    source: str
    event_remaining_s: float
    deadline_remaining_s: float
    backlog_tokens: float
    current_action: str
    ttft_slo_ms: float
    tpot_slo_ms: float
    workload_features: Mapping[str, float] = field(default_factory=dict)
    baseline_power_w: float | None = None
    baseline_ttft_ms: float | None = None
    baseline_tpot_ms: float | None = None
    baseline_batch_tps: float | None = None
    committed_bid_w: float | None = None
    replica_dwell_remaining_s: float = 0.0
    cohort_remaining_tokens: float | None = None
    dr_debt_tokens: float | None = None
    contract: FlexibilityContract | None = None
    previous_power_w: float | None = None
    settlement_elapsed_s: float = 0.0
    settlement_delivered_ws: float = 0.0

    def __post_init__(self) -> None:
        if self.event_remaining_s < 0:
            raise ValueError("event_remaining_s cannot be negative")
        if self.deadline_remaining_s < self.event_remaining_s:
            raise ValueError("deadline cannot precede the end of the event")
        if self.backlog_tokens < 0:
            raise ValueError("backlog_tokens cannot be negative")
        if self.committed_bid_w is not None and self.committed_bid_w < 0:
            raise ValueError("committed_bid_w cannot be negative")
        if self.replica_dwell_remaining_s < 0:
            raise ValueError("replica_dwell_remaining_s cannot be negative")
        if self.cohort_remaining_tokens is not None and self.cohort_remaining_tokens < 0:
            raise ValueError("cohort_remaining_tokens cannot be negative")
        if self.dr_debt_tokens is not None and self.dr_debt_tokens < 0:
            raise ValueError("dr_debt_tokens cannot be negative")
        if self.previous_power_w is not None and self.previous_power_w < 0:
            raise ValueError("previous_power_w cannot be negative")
        if self.settlement_elapsed_s < 0:
            raise ValueError("settlement_elapsed_s cannot be negative")
        if not math.isfinite(self.settlement_delivered_ws):
            raise ValueError("settlement_delivered_ws must be finite")
        for name in (
            "baseline_power_w", "baseline_ttft_ms",
            "baseline_tpot_ms", "baseline_batch_tps",
        ):
            value = getattr(self, name)
            if value is not None and value < 0:
                raise ValueError(f"{name} cannot be negative")

    @property
    def debt_tokens(self) -> float:
        """DR-induced service debt, with legacy backlog compatibility."""

        return float(
            self.backlog_tokens if self.dr_debt_tokens is None
            else self.dr_debt_tokens
        )

    @property
    def cohort_tokens(self) -> float:
        """Remaining pre-event batch cohort work."""

        return float(self.cohort_remaining_tokens or 0.0)


@dataclass(frozen=True)
class MPCParameters:
    control_period_s: float = 10.0
    calibration_mode: str = "episode"
    debt_quantum_tokens: float = 1024.0
    terminal_tolerance_tokens: float = 1024.0
    switch_penalty: float = 25.0
    recovery_power_weight: float = 0.02
    recovery_service_credit: float = 0.001
    maximum_states_per_step: int = 20_000
    replica_min_dwell_s: float = 120.0
    solve_budget_s: float = 10.0
    terminal_cohort_tolerance_tokens: float = 1024.0
    debt_penalty: float = 0.001
    slo_risk_penalty: float = 1.0

    def __post_init__(self) -> None:
        if self.control_period_s <= 0:
            raise ValueError("control_period_s must be positive")
        if self.debt_quantum_tokens <= 0:
            raise ValueError("debt_quantum_tokens must be positive")
        if self.terminal_tolerance_tokens < 0:
            raise ValueError("terminal_tolerance_tokens cannot be negative")
        if self.maximum_states_per_step <= 0:
            raise ValueError("maximum_states_per_step must be positive")
        if self.replica_min_dwell_s < 0:
            raise ValueError("replica_min_dwell_s cannot be negative")
        if self.solve_budget_s <= 0:
            raise ValueError("solve_budget_s must be positive")
        if self.terminal_cohort_tolerance_tokens < 0:
            raise ValueError("terminal_cohort_tolerance_tokens cannot be negative")
        if self.debt_penalty < 0 or self.slo_risk_penalty < 0:
            raise ValueError("objective penalties cannot be negative")


@dataclass(frozen=True)
class ActionEnvelope:
    action: HybridAction
    power_lower_w: float
    power_upper_w: float
    ttft_upper_ms: float
    tpot_upper_ms: float
    batch_tps_lower: float
    guaranteed_reduction_w: float
    expected_reduction_w: float
    slo_safe: bool

    def as_dict(self) -> dict:
        value = asdict(self)
        value["action"] = self.action.as_dict()
        return value


@dataclass(frozen=True)
class PlanStep:
    index: int
    stage: str
    duration_s: float
    action: HybridAction
    backlog_before_tokens: float
    backlog_after_tokens: float
    guaranteed_reduction_w: float
    batch_tps_lower: float
    ttft_upper_ms: float
    tpot_upper_ms: float
    cohort_before_tokens: float = 0.0
    cohort_after_tokens: float = 0.0
    predicted_power_upper_w: float = math.inf
    settlement_interval_complete: bool = False

    def as_dict(self) -> dict:
        value = asdict(self)
        value["action"] = self.action.as_dict()
        return value


@dataclass(frozen=True)
class MPCPlan:
    feasible: bool
    committed_bid_w: float
    objective: float
    steps: tuple[PlanStep, ...]
    terminal_backlog_tokens: float
    solve_time_ms: float
    evaluated_actions: int
    pareto_actions: int
    reason: str
    terminal_cohort_tokens: float = 0.0

    @property
    def first_action(self) -> HybridAction:
        if not self.steps:
            raise RuntimeError("plan has no action")
        return self.steps[0].action

    def as_dict(self) -> dict:
        value = asdict(self)
        value["steps"] = [step.as_dict() for step in self.steps]
        return value


@dataclass
class _Node:
    score: float
    debt: float
    cohort: float
    replica_dwell_s: float
    previous_power_w: float | None
    settlement_elapsed_s: float
    settlement_delivered_ws: float
    previous: "_Node | None"
    step: PlanStep | None


@dataclass(frozen=True)
class _HorizonStep:
    stage: str
    duration_s: float
    closes_settlement: bool = False
    recovery_elapsed_s: float = 0.0
    event_elapsed_s: float = 0.0


def _unwind(node: _Node) -> tuple[PlanStep, ...]:
    values = []
    current: _Node | None = node
    while current is not None and current.step is not None:
        values.append(current.step)
        current = current.previous
    values.reverse()
    return tuple(values)


def _row(state: ControlState, action: HybridAction) -> dict:
    return {
        **dict(state.workload_features),
        "source": state.source,
        "online_replicas": action.online_replicas,
        "batch_concurrency": action.batch_concurrency,
        "power_cap_w": action.power_cap_w,
        "ttft_slo_ms": state.ttft_slo_ms,
        "tpot_slo_ms": state.tpot_slo_ms,
        "name": action.name,
        "baseline_power_w": state.baseline_power_w,
        "baseline_ttft_ms": state.baseline_ttft_ms,
        "baseline_tpot_ms": state.baseline_tpot_ms,
        "baseline_batch_tps": state.baseline_batch_tps,
    }


def pareto_prune(
    envelopes: Iterable[ActionEnvelope], current_action: str,
) -> list[ActionEnvelope]:
    """Remove actions no better in reduction, service, or SLO headroom.

    Keeping the current action preserves a potentially useful zero-switch-cost
    transition even when its steady-state envelope is dominated.
    """

    values = list(envelopes)
    result: list[ActionEnvelope] = []
    for candidate in values:
        dominated = False
        if candidate.action.name != current_action:
            for other in values:
                if other.action.name == candidate.action.name:
                    continue
                weakly_better = (
                    other.guaranteed_reduction_w
                    >= candidate.guaranteed_reduction_w - 1e-9
                    and other.batch_tps_lower >= candidate.batch_tps_lower - 1e-9
                    and other.ttft_upper_ms <= candidate.ttft_upper_ms + 1e-9
                    and other.tpot_upper_ms <= candidate.tpot_upper_ms + 1e-9
                )
                strictly_better = (
                    other.guaranteed_reduction_w
                    > candidate.guaranteed_reduction_w + 1e-9
                    or other.batch_tps_lower > candidate.batch_tps_lower + 1e-9
                    or other.ttft_upper_ms < candidate.ttft_upper_ms - 1e-9
                    or other.tpot_upper_ms < candidate.tpot_upper_ms - 1e-9
                )
                if weakly_better and strictly_better:
                    dominated = True
                    break
        if not dominated:
            result.append(candidate)
    return sorted(result, key=lambda item: item.action.name)


class ViabilityMPC:
    """Finite-horizon robust controller over a discrete joint action lattice."""

    def __init__(
        self,
        model: PredictiveModel,
        actions: Iterable[HybridAction],
        parameters: MPCParameters | None = None,
        *,
        baseline_action: str = "hybrid_full",
    ):
        self.model = model
        self.actions = tuple(actions)
        self.actions_by_name = {action.name: action for action in self.actions}
        self.parameters = parameters or MPCParameters()
        self.baseline_action = baseline_action
        names = [action.name for action in self.actions]
        if len(names) != len(set(names)):
            raise ValueError("action names must be unique")
        if baseline_action not in names:
            raise ValueError(f"baseline action is missing: {baseline_action}")

    def envelopes(self, state: ControlState) -> list[ActionEnvelope]:
        baseline_action = next(
            action for action in self.actions if action.name == self.baseline_action
        )
        baseline_row = _row(state, baseline_action)
        baseline_prediction = self.model.predict(baseline_row)
        baseline_bounds = self.model.bounds(
            baseline_row, self.parameters.calibration_mode
        )
        baseline_safe = (
            math.isfinite(baseline_bounds.power_lower_w)
            and baseline_bounds.ttft_upper_ms <= state.ttft_slo_ms
            and baseline_bounds.tpot_upper_ms <= state.tpot_slo_ms
        )
        if not baseline_safe:
            return []
        result = []
        for action in self.actions:
            row = _row(state, action)
            supports = getattr(self.model, "supports", None)
            if supports is not None and not supports(row):
                continue
            prediction = self.model.predict(row)
            bounds = self.model.bounds(row, self.parameters.calibration_mode)
            reference = (
                state.contract.reference_at(
                    state.contract.event_s - state.event_remaining_s
                )
                if state.contract is not None else math.inf
            )
            reference_lower = (
                reference if math.isfinite(reference)
                else baseline_bounds.power_lower_w
            )
            reduction = reference_lower - bounds.power_upper_w
            result.append(ActionEnvelope(
                action=action,
                power_lower_w=bounds.power_lower_w,
                power_upper_w=bounds.power_upper_w,
                ttft_upper_ms=bounds.ttft_upper_ms,
                tpot_upper_ms=bounds.tpot_upper_ms,
                batch_tps_lower=bounds.batch_tokens_per_s_lower,
                guaranteed_reduction_w=reduction,
                expected_reduction_w=(
                    baseline_prediction.power_mean_w - prediction.power_mean_w
                ),
                slo_safe=(
                    math.isfinite(reduction)
                    and bounds.ttft_upper_ms <= state.ttft_slo_ms
                    and bounds.tpot_upper_ms <= state.tpot_slo_ms
                ),
            ))
        return result

    def _durations(self, state: ControlState) -> list[_HorizonStep]:
        """Split the horizon at control and settlement boundaries."""

        result: list[_HorizonStep] = []
        event = state.event_remaining_s
        settlement = (
            state.contract.settlement_interval_s
            if state.contract is not None
            else self.parameters.control_period_s
        )
        offset = state.settlement_elapsed_s % settlement
        event_elapsed = (
            max(0.0, state.contract.event_s - state.event_remaining_s)
            if state.contract is not None else 0.0
        )
        while event > 1e-9:
            until_boundary = settlement - offset if offset > 1e-9 else settlement
            duration = min(self.parameters.control_period_s, event, until_boundary)
            offset += duration
            event -= duration
            closes = offset >= settlement - 1e-9 or event <= 1e-9
            result.append(_HorizonStep(
                "event", duration, closes, 0.0, event_elapsed,
            ))
            event_elapsed += duration
            if closes:
                offset = 0.0

        recovery = state.deadline_remaining_s - state.event_remaining_s
        recovery_total = (
            max(0.0, state.contract.deadline_s - state.contract.event_s)
            if state.contract is not None else recovery
        )
        recovery_elapsed = max(0.0, recovery_total - recovery)
        while recovery > 1e-9:
            duration = min(self.parameters.control_period_s, recovery)
            result.append(_HorizonStep(
                "recovery", duration, False, recovery_elapsed, 0.0,
            ))
            recovery -= duration
            recovery_elapsed += duration
        return result

    def _fallback(
        self,
        state: ControlState,
        safe: list[ActionEnvelope],
        started: float,
        reason: str,
    ) -> MPCPlan:
        if safe:
            chosen = max(
                safe,
                key=lambda item: (
                    item.batch_tps_lower,
                    -item.power_upper_w,
                    item.action.name == self.baseline_action,
                ),
            )
        else:
            action = next(
                item for item in self.actions if item.name == self.baseline_action
            )
            chosen = ActionEnvelope(
                action, 0.0, math.inf, math.inf, math.inf, 0.0, 0.0, 0.0, False
            )
        duration = min(
            self.parameters.control_period_s,
            max(state.deadline_remaining_s, self.parameters.control_period_s),
        )
        step = PlanStep(
            index=0,
            stage="event" if state.event_remaining_s > 0 else "recovery",
            duration_s=duration,
            action=chosen.action,
            backlog_before_tokens=state.debt_tokens,
            backlog_after_tokens=state.debt_tokens,
            guaranteed_reduction_w=chosen.guaranteed_reduction_w,
            batch_tps_lower=chosen.batch_tps_lower,
            ttft_upper_ms=chosen.ttft_upper_ms,
            tpot_upper_ms=chosen.tpot_upper_ms,
            cohort_before_tokens=state.cohort_tokens,
            cohort_after_tokens=state.cohort_tokens,
            predicted_power_upper_w=chosen.power_upper_w,
        )
        return MPCPlan(
            feasible=False,
            committed_bid_w=0.0,
            objective=-math.inf,
            steps=(step,),
            terminal_backlog_tokens=state.debt_tokens,
            solve_time_ms=(time.perf_counter() - started) * 1000,
            evaluated_actions=len(self.actions),
            pareto_actions=len(safe),
            reason=reason,
            terminal_cohort_tokens=state.cohort_tokens,
        )

    def solve(self, state: ControlState) -> MPCPlan:
        started = time.perf_counter()
        solve_deadline = started + self.parameters.solve_budget_s
        timed_out = False
        all_envelopes = self.envelopes(state)
        safe = [item for item in all_envelopes if item.slo_safe]
        if not safe:
            return self._fallback(
                state, safe, started,
                "baseline prediction is unsafe or no SLO-safe action exists",
            )
        frontier = pareto_prune(safe, state.current_action)
        baseline = next(
            item for item in all_envelopes
            if item.action.name == self.baseline_action
        )
        baseline_tps = (
            float(state.baseline_batch_tps)
            if state.baseline_batch_tps is not None
            else baseline.batch_tps_lower
        )
        horizon = self._durations(state)
        if not horizon:
            return self._fallback(state, safe, started, "deadline has elapsed")

        quantum = self.parameters.debt_quantum_tokens
        maximum_batch_tps = max(
            envelope.batch_tps_lower for envelope in frontier
        )
        future_repayment = [0.0 for _ in horizon]
        future_service = [0.0 for _ in horizon]
        repay = 0.0
        service = 0.0
        for index in range(len(horizon) - 1, -1, -1):
            future_repayment[index] = repay
            future_service[index] = service
            future_duration = horizon[index].duration_s
            repay += max(0.0, maximum_batch_tps - baseline_tps) * future_duration
            service += maximum_batch_tps * future_duration

        def transition_allowed(
            step: _HorizonStep,
            envelope: ActionEnvelope,
            previous_power_w: float | None,
        ) -> bool:
            contract = state.contract
            if contract is None:
                return True
            if previous_power_w is not None and math.isfinite(contract.ramp_limit_w_per_s):
                ramp = abs(envelope.power_upper_w - previous_power_w) / step.duration_s
                if ramp > contract.ramp_limit_w_per_s + 1e-9:
                    return False
            if step.stage != "recovery":
                return True
            limit = contract.recovery_envelope_at(step.recovery_elapsed_s)
            reference = contract.reference_at(contract.event_s + step.recovery_elapsed_s)
            if math.isfinite(reference) and math.isfinite(contract.rebound_limit_w):
                limit = min(limit, reference + contract.rebound_limit_w)
            return envelope.power_upper_w <= limit + 1e-9

        def event_reduction(
            step: _HorizonStep, envelope: ActionEnvelope,
        ) -> float:
            contract = state.contract
            if contract is not None:
                reference = contract.reference_at(step.event_elapsed_s)
                if math.isfinite(reference):
                    return reference - envelope.power_upper_w
            return envelope.guaranteed_reduction_w

        def search(required_bid_w: float) -> _Node | None:
            nonlocal timed_out
            initial_power = state.previous_power_w
            if initial_power is None:
                current = next(
                    (item for item in all_envelopes
                     if item.action.name == state.current_action),
                    baseline,
                )
                initial_power = current.power_upper_w
            initial_key = (
                int(math.ceil(state.debt_tokens / quantum - 1e-12)),
                int(math.ceil(state.cohort_tokens / quantum - 1e-12)),
                state.current_action,
                int(math.ceil(
                    state.replica_dwell_remaining_s
                    / self.parameters.control_period_s
                )),
                round(state.settlement_elapsed_s, 6),
                round(state.settlement_delivered_ws, 3),
            )
            nodes: dict[tuple, _Node] = {
                initial_key: _Node(
                    0.0,
                    state.debt_tokens,
                    state.cohort_tokens,
                    state.replica_dwell_remaining_s,
                    initial_power,
                    state.settlement_elapsed_s,
                    state.settlement_delivered_ws,
                    None,
                    None,
                )
            }
            for step_index, horizon_step in enumerate(horizon):
                if time.perf_counter() > solve_deadline:
                    timed_out = True
                    return None
                stage = horizon_step.stage
                duration = horizon_step.duration_s
                next_nodes: dict[tuple, _Node] = {}
                for key_value, node in nodes.items():
                    previous_name = key_value[2]
                    previous_action = self.actions_by_name.get(previous_name)
                    for envelope in frontier:
                        replica_change = (
                            previous_action is not None
                            and envelope.action.resolved_online_replica_ids()
                            != previous_action.resolved_online_replica_ids()
                        )
                        if replica_change and node.replica_dwell_s > 1e-9:
                            continue
                        if not transition_allowed(
                            horizon_step, envelope, node.previous_power_w,
                        ):
                            continue
                        settlement_elapsed = node.settlement_elapsed_s
                        settlement_delivered = node.settlement_delivered_ws
                        if stage == "event":
                            reduction_w = event_reduction(
                                horizon_step, envelope,
                            )
                            settlement_elapsed += duration
                            settlement_delivered += (
                                reduction_w * duration
                            )
                            if horizon_step.closes_settlement:
                                if (
                                    settlement_delivered + 1e-9
                                    < required_bid_w * settlement_elapsed
                                ):
                                    continue
                                settlement_elapsed = 0.0
                                settlement_delivered = 0.0
                        next_debt = max(
                            0.0,
                            node.debt
                            + (baseline_tps - envelope.batch_tps_lower) * duration,
                        )
                        next_cohort = max(
                            0.0,
                            node.cohort - envelope.batch_tps_lower * duration,
                        )
                        if (
                            next_debt
                            > future_repayment[step_index]
                            + self.parameters.terminal_tolerance_tokens
                            + 1e-9
                        ):
                            continue
                        if (
                            next_cohort
                            > future_service[step_index]
                            + self.parameters.terminal_cohort_tolerance_tokens
                            + 1e-9
                        ):
                            continue
                        switch = float(envelope.action.name != previous_name)
                        risk = max(
                            envelope.ttft_upper_ms / state.ttft_slo_ms,
                            envelope.tpot_upper_ms / state.tpot_slo_ms,
                        )
                        reward = (
                            -self.parameters.recovery_power_weight
                            * envelope.power_upper_w * duration
                            + self.parameters.recovery_service_credit
                            * envelope.batch_tps_lower * duration
                            - self.parameters.debt_penalty * next_debt
                            - self.parameters.slo_risk_penalty * risk
                        )
                        score = (
                            node.score + reward
                            - self.parameters.switch_penalty * switch
                        )
                        next_dwell = (
                            self.parameters.replica_min_dwell_s
                            if replica_change
                            else max(0.0, node.replica_dwell_s - duration)
                        )
                        step_reduction_w = (
                            event_reduction(horizon_step, envelope)
                            if stage == "event"
                            else envelope.guaranteed_reduction_w
                        )
                        plan_step = PlanStep(
                            index=step_index,
                            stage=stage,
                            duration_s=duration,
                            action=envelope.action,
                            backlog_before_tokens=node.debt,
                            backlog_after_tokens=next_debt,
                            guaranteed_reduction_w=step_reduction_w,
                            batch_tps_lower=envelope.batch_tps_lower,
                            ttft_upper_ms=envelope.ttft_upper_ms,
                            tpot_upper_ms=envelope.tpot_upper_ms,
                            cohort_before_tokens=node.cohort,
                            cohort_after_tokens=next_cohort,
                            predicted_power_upper_w=envelope.power_upper_w,
                            settlement_interval_complete=(
                                horizon_step.closes_settlement
                            ),
                        )
                        key = (
                            int(math.ceil(next_debt / quantum - 1e-12)),
                            int(math.ceil(next_cohort / quantum - 1e-12)),
                            envelope.action.name,
                            int(math.ceil(
                                next_dwell / self.parameters.control_period_s
                            )),
                            round(settlement_elapsed, 6),
                            round(settlement_delivered, 3),
                        )
                        incumbent = next_nodes.get(key)
                        if incumbent is None or score > incumbent.score:
                            next_nodes[key] = _Node(
                                score,
                                next_debt,
                                next_cohort,
                                next_dwell,
                                envelope.power_upper_w,
                                settlement_elapsed,
                                settlement_delivered,
                                node,
                                plan_step,
                            )
                if not next_nodes:
                    return None
                if len(next_nodes) > self.parameters.maximum_states_per_step:
                    ranked = sorted(
                        next_nodes.items(),
                        key=lambda item: (
                            item[1].score,
                            -item[1].debt,
                            -item[1].cohort,
                        ),
                        reverse=True,
                    )[:self.parameters.maximum_states_per_step]
                    next_nodes = dict(ranked)
                nodes = next_nodes
            viable = [
                node for node in nodes.values()
                if node.debt <= self.parameters.terminal_tolerance_tokens
                and node.cohort
                <= self.parameters.terminal_cohort_tolerance_tokens
            ]
            return max(viable, key=lambda node: node.score) if viable else None

        if state.event_remaining_s <= 0:
            candidate_bids = [0.0]
        elif state.committed_bid_w is not None:
            candidate_bids = [state.committed_bid_w]
        else:
            event_steps = [step for step in horizon if step.stage == "event"]
            candidate_bids = sorted({
                max(0.0, min(
                    event_reduction(step, envelope)
                    for step in event_steps
                ))
                for envelope in frontier
            })
        best: _Node | None = None
        bid = 0.0
        if state.committed_bid_w is not None or state.event_remaining_s <= 0:
            bid = candidate_bids[0]
            best = search(bid)
        else:
            # Viability is monotone in the minimum event bid.  Binary search
            # finds the exact highest profiled reduction level with O(log |A|)
            # dynamic-program runs instead of one run per action.
            low, high = 0, len(candidate_bids) - 1
            cache: dict[float, _Node | None] = {}
            while low <= high:
                middle = (low + high) // 2
                candidate_bid = candidate_bids[middle]
                candidate = search(candidate_bid)
                cache[candidate_bid] = candidate
                if candidate is not None:
                    bid = candidate_bid
                    best = candidate
                    low = middle + 1
                else:
                    high = middle - 1
        if best is None:
            reason = (
                "solver budget exceeded; returning safe service fallback"
                if timed_out else
                "committed bid has no SLO-safe viable continuation"
                if state.committed_bid_w is not None
                else "no action sequence can repay batch debt before the deadline"
            )
            return self._fallback(state, safe, started, reason)
        return MPCPlan(
            feasible=True,
            committed_bid_w=max(0.0, bid),
            objective=best.score,
            steps=_unwind(best),
            terminal_backlog_tokens=best.debt,
            solve_time_ms=(time.perf_counter() - started) * 1000,
            evaluated_actions=len(all_envelopes),
            pareto_actions=len(frontier),
            reason="optimal risk-calibrated viable sequence on the discretized horizon",
            terminal_cohort_tokens=best.cohort,
        )


def build_action_lattice(spec: Mapping) -> list[HybridAction]:
    """Generate joint actions from independent actuator axes.

    The optimizer, rather than a hand-written policy, decides which combinations
    are useful.  ``baseline`` identifies the normal operating point and receives
    the stable name ``hybrid_full`` for compatibility with existing models.
    """

    configured_sets = spec.get("online_replica_sets")
    explicit_replica_sets = configured_sets is not None
    if configured_sets is None:
        replica_sets = [
            tuple(range(value))
            for value in sorted({int(value) for value in spec["online_replicas"]})
        ]
    else:
        replica_sets = sorted({
            tuple(int(item) for item in values)
            for values in configured_sets
        })
        if not replica_sets or any(not values for values in replica_sets):
            raise ValueError("online_replica_sets cannot contain an empty set")
    concurrencies = sorted({int(value) for value in spec["batch_concurrency"]})
    caps = sorted({float(value) for value in spec["power_cap_w"]})
    baseline = spec.get("baseline", {})
    baseline_ids = (
        tuple(int(item) for item in baseline["online_replica_ids"])
        if "online_replica_ids" in baseline
        else tuple(range(int(baseline.get(
            "online_replicas", max(len(values) for values in replica_sets)
        ))))
    )
    baseline_tuple = (
        baseline_ids,
        int(baseline.get("batch_concurrency", max(concurrencies))),
        float(baseline.get("power_cap_w", max(caps))),
    )
    actions = []
    for replica_ids in replica_sets:
        for batch_concurrency in concurrencies:
            for power_cap_w in caps:
                values = (replica_ids, batch_concurrency, power_cap_w)
                replica_label = (
                    "-".join(str(item) for item in replica_ids)
                    if explicit_replica_sets else str(len(replica_ids))
                )
                name = (
                    "hybrid_full" if values == baseline_tuple
                    else f"mpc_r{replica_label}_c{batch_concurrency}_p{power_cap_w:g}"
                )
                actions.append(HybridAction(
                    name=name,
                    online_replicas=len(replica_ids),
                    batch_concurrency=batch_concurrency,
                    power_cap_w=power_cap_w,
                    online_replica_ids=replica_ids,
                ))
    if not any(action.name == "hybrid_full" for action in actions):
        raise ValueError("baseline is outside the configured action lattice")
    return actions
