from __future__ import annotations

import json
import math
import unittest

from flexbid_hybrid.adaptive import AdaptiveRecoveryController
from flexbid_hybrid.adaptive_model import AdaptiveEnvelopeModel
from pathlib import Path

from flexbid_hybrid.analysis import clipped_samples, integrate_j, percentile
from flexbid_hybrid.clients import load_trace
from flexbid_hybrid.conformal import (
    ActionNormalizedJointCalibrator,
    HybridJointCalibrator,
    finite_sample_quantile,
)
from flexbid_hybrid.contracts import FlexibilityContract
from flexbid_hybrid.modeling import (
    HybridBounds,
    HybridPrediction,
    PairedHybridSurrogate,
)
from flexbid_hybrid.mpc import (
    ActionEnvelope,
    ControlState,
    MPCParameters,
    ViabilityMPC,
    build_action_lattice,
    pareto_prune,
)
from flexbid_hybrid.pilot import select_episodes
from flexbid_hybrid.policy import risk_calibrated_bid
from flexbid_hybrid.runtime_controller import OnlineFeatureEstimator
from flexbid_hybrid.types import HybridAction
from flexbid_hybrid.trajectory_calibration import (
    DeliveryObservation,
    ElectricalDeliveryCalibrator,
    FrozenPolicyCalibrator,
    SlackObservation,
    TrajectorySafetyCalibrator,
)


class ActionTests(unittest.TestCase):
    def test_rejects_zero_online_replicas(self):
        with self.assertRaises(ValueError):
            HybridAction("bad", 0, 0, 400)

    def test_allows_paused_batch(self):
        self.assertEqual(HybridAction("pause", 2, 0, 300).batch_concurrency, 0)

    def test_named_replica_set_is_preserved(self):
        action = HybridAction("named", 2, 0, 300, (1, 3))
        self.assertEqual(action.resolved_online_replica_ids(), (1, 3))
        self.assertEqual(HybridAction.from_dict(action.as_dict()), action)


class AdaptiveRecoveryTests(unittest.TestCase):
    def controller(self):
        return AdaptiveRecoveryController(
            baseline_batch_tps=160.0,
            initial_backlog_tokens=48_000.0,
            deadline_s=1500.0,
            tpot_guard_ms=80.0,
            ttft_guard_ms=4000.0,
            cooldown_s=30.0,
        )

    def test_boosts_when_catchup_is_behind(self):
        decision = self.controller().decide(
            elapsed_s=100.0,
            recovered_tokens=1000.0,
            recent_online_metrics=[],
        )
        self.assertEqual(decision.batch_concurrency, 6)
        self.assertEqual(decision.reason, "deadline catch-up boost")

    def test_tail_breach_enters_cooldown(self):
        controller = self.controller()
        decision = controller.decide(
            elapsed_s=100.0,
            recovered_tokens=1000.0,
            recent_online_metrics=[{"mean_gap_ms": 81.0, "ttft_ms": 100.0}],
        )
        self.assertEqual(decision.batch_concurrency, 4)
        self.assertEqual(decision.reason, "online tail guard cooldown")
        still_cooling = controller.decide(
            elapsed_s=120.0,
            recovered_tokens=2000.0,
            recent_online_metrics=[],
        )
        self.assertEqual(still_cooling.batch_concurrency, 4)

    def test_returns_to_base_when_backlog_is_cleared(self):
        decision = self.controller().decide(
            elapsed_s=500.0,
            recovered_tokens=48_000.0,
            recent_online_metrics=[],
        )
        self.assertEqual(decision.batch_concurrency, 4)
        self.assertEqual(decision.reason, "backlog cleared")


class ViabilityMPCTests(unittest.TestCase):
    class Model:
        values = {
            "hybrid_full": (400.0, 100.0, 10.0, 100.0),
            "pause": (200.0, 100.0, 10.0, 0.0),
            "throttle": (300.0, 100.0, 10.0, 50.0),
            "boost": (420.0, 100.0, 10.0, 200.0),
        }

        def __init__(self, unsafe=()):
            self.unsafe = set(unsafe)

        def predict(self, row):
            power, ttft, tpot, batch = self.values[row["name"]]
            return HybridPrediction(power, ttft, tpot, batch)

        def bounds(self, row, mode):
            prediction = self.predict(row)
            tpot = 200.0 if row["name"] in self.unsafe else prediction.tpot_p99_ms
            return HybridBounds(
                prediction.power_mean_w,
                prediction.power_mean_w,
                prediction.ttft_p95_ms,
                tpot,
                prediction.batch_tokens_per_s,
            )

    def actions(self):
        return [
            HybridAction("hybrid_full", 4, 4, 400),
            HybridAction("pause", 2, 0, 200),
            HybridAction("throttle", 4, 2, 300),
            HybridAction("boost", 4, 6, 400),
        ]

    def state(self, event=10.0, deadline=20.0, committed=None):
        return ControlState(
            source="qwen_bailian",
            event_remaining_s=event,
            deadline_remaining_s=deadline,
            backlog_tokens=0.0,
            current_action="hybrid_full",
            ttft_slo_ms=5000.0,
            tpot_slo_ms=100.0,
            baseline_batch_tps=100.0,
            committed_bid_w=committed,
        )

    def optimizer(self, unsafe=()):
        return ViabilityMPC(
            self.Model(unsafe),
            self.actions(),
            MPCParameters(
                control_period_s=10.0,
                debt_quantum_tokens=100.0,
                terminal_tolerance_tokens=0.0,
                switch_penalty=0.0,
                recovery_power_weight=0.0,
                recovery_service_credit=0.0,
                replica_min_dwell_s=0.0,
            ),
        )

    def test_jointly_plans_pause_and_future_recovery(self):
        plan = self.optimizer().solve(self.state())
        self.assertTrue(plan.feasible)
        self.assertEqual([step.action.name for step in plan.steps], ["pause", "boost"])
        self.assertEqual(plan.committed_bid_w, 200.0)
        self.assertEqual(plan.terminal_backlog_tokens, 0.0)

    def test_short_recovery_selects_less_aggressive_event_action(self):
        plan = self.optimizer().solve(self.state(deadline=15.0))
        self.assertTrue(plan.feasible)
        self.assertEqual(plan.steps[0].action.name, "throttle")
        self.assertEqual(plan.steps[1].action.name, "boost")

    def test_unsafe_boost_prevents_unrecoverable_curtailment(self):
        plan = self.optimizer(unsafe={"boost"}).solve(self.state())
        self.assertTrue(plan.feasible)
        self.assertEqual(plan.steps[0].action.name, "hybrid_full")
        self.assertEqual(plan.committed_bid_w, 0.0)

    def test_external_bid_is_a_hard_runtime_constraint(self):
        plan = self.optimizer().solve(self.state(committed=150.0))
        self.assertTrue(plan.feasible)
        self.assertEqual(plan.steps[0].action.name, "pause")
        self.assertEqual(plan.committed_bid_w, 150.0)

    def test_slow_replica_actuator_respects_minimum_dwell(self):
        state = ControlState(
            source="qwen_bailian",
            event_remaining_s=10.0,
            deadline_remaining_s=15.0,
            backlog_tokens=0.0,
            current_action="hybrid_full",
            ttft_slo_ms=5000.0,
            tpot_slo_ms=100.0,
            baseline_batch_tps=100.0,
            replica_dwell_remaining_s=30.0,
        )
        plan = self.optimizer().solve(state)
        self.assertTrue(plan.feasible)
        self.assertEqual(plan.steps[0].action.name, "throttle")

    def test_action_lattice_is_generated_instead_of_hand_written(self):
        actions = build_action_lattice({
            "online_replicas": [2, 4],
            "batch_concurrency": [0, 4, 6],
            "power_cap_w": [300, 400],
            "baseline": {
                "online_replicas": 4,
                "batch_concurrency": 4,
                "power_cap_w": 400,
            },
        })
        self.assertEqual(len(actions), 12)
        self.assertEqual(sum(a.name == "hybrid_full" for a in actions), 1)

    def test_action_lattice_accepts_named_replica_sets(self):
        actions = build_action_lattice({
            "online_replica_sets": [[0, 2], [1, 3], [0, 1, 2, 3]],
            "batch_concurrency": [0, 4],
            "power_cap_w": [300, 400],
            "baseline": {
                "online_replica_ids": [0, 1, 2, 3],
                "batch_concurrency": 4,
                "power_cap_w": 400,
            },
        })
        self.assertEqual(len(actions), 12)
        self.assertIn((1, 3), {
            action.resolved_online_replica_ids() for action in actions
        })

    def test_pareto_pruning_keeps_current_action(self):
        current = ActionEnvelope(
            HybridAction("current", 4, 2, 400),
            0, 300, 100, 10, 20, 50, 50, True,
        )
        dominant = ActionEnvelope(
            HybridAction("dominant", 4, 3, 400),
            0, 250, 90, 9, 30, 60, 60, True,
        )
        names = {item.action.name for item in pareto_prune([current, dominant], "current")}
        self.assertEqual(names, {"current", "dominant"})

    def test_settlement_constraint_is_interval_average(self):
        state = self.state(event=20.0, deadline=35.0, committed=150.0)
        contract = FlexibilityContract(20.0, 35.0, 20.0)
        plan = self.optimizer().solve(ControlState(
            **{**state.__dict__, "contract": contract}
        ))
        self.assertTrue(plan.feasible)
        event_actions = [
            step.action.name for step in plan.steps if step.stage == "event"
        ]
        self.assertIn("throttle", event_actions)
        self.assertIn("pause", event_actions)

    def test_recovery_envelope_can_reject_an_unrecoverable_offer(self):
        state = self.state(committed=150.0)
        contract = FlexibilityContract(
            10.0, 20.0, 10.0,
            recovery_power_envelope_w=(410.0,),
        )
        plan = self.optimizer().solve(ControlState(
            **{**state.__dict__, "contract": contract}
        ))
        self.assertFalse(plan.feasible)

    def test_ems_reference_is_distinct_from_internal_baseline(self):
        state = self.state()
        contract = FlexibilityContract(
            10.0, 20.0, 10.0,
            reference_power_w=(500.0,),
        )
        plan = self.optimizer().solve(ControlState(
            **{**state.__dict__, "contract": contract}
        ))
        self.assertTrue(plan.feasible)
        self.assertEqual(plan.committed_bid_w, 300.0)

    def test_ramp_limit_is_a_hard_transition_constraint(self):
        state = self.state(committed=150.0)
        contract = FlexibilityContract(
            10.0, 20.0, 10.0,
            ramp_limit_w_per_s=5.0,
        )
        plan = self.optimizer().solve(ControlState(
            **{
                **state.__dict__,
                "contract": contract,
                "previous_power_w": 400.0,
            }
        ))
        self.assertFalse(plan.feasible)

    def test_cohort_and_dr_debt_are_distinct_terminal_constraints(self):
        state = ControlState(
            **{
                **self.state(event=10.0, deadline=20.0).__dict__,
                "cohort_remaining_tokens": 1000.0,
                "dr_debt_tokens": 0.0,
            }
        )
        plan = self.optimizer().solve(state)
        self.assertTrue(plan.feasible)
        self.assertEqual(plan.terminal_cohort_tokens, 0.0)
        self.assertEqual(plan.terminal_backlog_tokens, 0.0)


class RuntimeFeatureTests(unittest.TestCase):
    def test_rolling_gateway_features_feed_surrogate(self):
        estimator = OnlineFeatureEstimator("azure_code", window_s=10.0)
        now = 20_000_000_000
        features = estimator.update({"recent_online_metrics": [
            {
                "sequence": 1,
                "completed_wall_time_ns": 15_000_000_000,
                "prompt_tokens": 100,
                "max_output_tokens": 20,
                "cache_prefix_tokens": 25,
            },
            {
                "sequence": 2,
                "completed_wall_time_ns": 19_000_000_000,
                "prompt_tokens": 300,
                "max_output_tokens": 40,
                "cache_prefix_tokens": 75,
            },
        ]}, now)
        self.assertEqual(features["online_arrivals"], 2.0)
        self.assertEqual(features["prompt_tokens_mean"], 200.0)
        self.assertEqual(features["cache_prefix_fraction"], 0.25)
        self.assertEqual(features["source_azure_code"], 1.0)


class AdaptiveEnvelopeTests(unittest.TestCase):
    class Base:
        def predict(self, row):
            return HybridPrediction(300.0, 100.0, 10.0, 50.0)

        def bounds(self, row, mode):
            return HybridBounds(280.0, 320.0, 120.0, 12.0, 40.0)

    def test_live_residuals_only_widen_frozen_bounds(self):
        model = AdaptiveEnvelopeModel(self.Base())
        model.update(
            {}, observed_power_w=340.0, observed_ttft_ms=150.0,
            observed_tpot_ms=25.0, observed_batch_tps=20.0,
        )
        value = model.bounds({}, "episode")
        self.assertEqual(value.power_lower_w, 240.0)
        self.assertEqual(value.power_upper_w, 360.0)
        self.assertEqual(value.ttft_upper_ms, 170.0)
        self.assertEqual(value.tpot_upper_ms, 27.0)
        self.assertEqual(value.batch_tokens_per_s_lower, 10.0)

    def test_better_observation_does_not_shrink_safety_margin(self):
        model = AdaptiveEnvelopeModel(self.Base())
        model.update({}, observed_power_w=340.0)
        model.update({}, observed_power_w=301.0)
        self.assertEqual(model.snapshot()["power_w"], 40.0)


class PairedSurrogateTests(unittest.TestCase):
    class ConstantRegressor:
        def __init__(self, value):
            self.value = value

        def predict(self, matrix):
            return [self.value for _row in matrix]

    def model(self):
        model = PairedHybridSurrogate()
        model.regressors = {
            "power_mean_w": self.ConstantRegressor(100.0),
            "ttft_p95_ms": self.ConstantRegressor(5.0),
            "tpot_p99_ms": self.ConstantRegressor(2.0),
            "batch_tokens_per_s": self.ConstantRegressor(-50.0),
        }
        calibrator = HybridJointCalibrator(
            0.05,
            scales={
                "power_mean_w": 10.0,
                "ttft_p95_ms": 2.0,
                "tpot_p99_ms": 1.0,
                "batch_tokens_per_s": 5.0,
            },
        )
        calibrator.row_radius = 1.0
        calibrator.episode_radius = 1.0
        calibrator.episode_count = 20
        model.calibrator = calibrator
        return model

    @staticmethod
    def row(name="candidate"):
        return {
            "name": name,
            "source": "qwen_bailian",
            "baseline_power_w": 400.0,
            "baseline_ttft_ms": 100.0,
            "baseline_tpot_ms": 10.0,
            "baseline_batch_tps": 100.0,
        }

    def test_baseline_is_the_measured_control_state(self):
        bounds = self.model().bounds(self.row("hybrid_full"), "episode")
        self.assertEqual(bounds, HybridBounds(400.0, 400.0, 100.0, 10.0, 100.0))

    def test_paired_effect_bounds_are_anchored_to_baseline(self):
        bounds = self.model().bounds(self.row(), "episode")
        self.assertEqual(bounds.power_lower_w, 290.0)
        self.assertEqual(bounds.power_upper_w, 310.0)
        self.assertEqual(bounds.ttft_upper_ms, 107.0)
        self.assertEqual(bounds.tpot_upper_ms, 13.0)
        self.assertEqual(bounds.batch_tokens_per_s_lower, 45.0)


class MeasurementTests(unittest.TestCase):
    def test_boundary_interpolation_and_energy(self):
        values = [(0, 100.0), (10_000_000_000, 200.0), (20_000_000_000, 100.0)]
        clipped = clipped_samples(values, 5_000_000_000, 15_000_000_000)
        self.assertEqual(clipped[0], (5_000_000_000, 150.0))
        self.assertEqual(clipped[-1], (15_000_000_000, 150.0))
        self.assertAlmostEqual(integrate_j(clipped), 1750.0)

    def test_exact_tail(self):
        self.assertEqual(percentile(list(range(1, 101)), 0.95), 95)


class TraceTests(unittest.TestCase):
    def test_arrival_scaling_and_crop(self):
        path = Path("tests/trace_test_runtime.jsonl")
        rows = [
            {"request_id": "a", "arrival_ms": 100, "prompt_tokens": 10,
             "max_output_tokens": 2},
            {"request_id": "b", "arrival_ms": 1000, "prompt_tokens": 10,
             "max_output_tokens": 2},
        ]
        try:
            path.write_text("".join(json.dumps(row) + "\n" for row in rows),
                            encoding="utf-8")
            selected = load_trace(path, 2.0, 1.0)
            self.assertEqual([row["request_id"] for row in selected], ["a"])
            self.assertEqual(selected[0]["arrival_ms"], 200)
        finally:
            path.unlink(missing_ok=True)


class EpisodeSelectionTests(unittest.TestCase):
    def test_split_specific_selections(self):
        root = Path("tests/selection_runtime")
        manifest_dir = root / "data"
        manifest_dir.mkdir(parents=True, exist_ok=True)
        trace = manifest_dir / "trace.jsonl"
        manifest = manifest_dir / "manifest.json"
        try:
            trace.write_text("{}\n", encoding="utf-8")
            manifest.write_text(json.dumps({"episodes": [
                {"source": "source_a", "split": "train", "episode_id": "train-0",
                 "path": "trace.jsonl"},
                {"source": "source_a", "split": "calibration", "episode_id": "cal-0",
                 "path": "trace.jsonl"},
            ]}), encoding="utf-8")
            config = {"workloads": {
                "manifest": "data/manifest.json",
                "episode_selections": [
                    {"source": "source_a", "split": "calibration", "count": 1},
                ],
            }}
            selected = select_episodes(root, config)
            self.assertEqual([row["episode_id"] for row in selected], ["cal-0"])
            self.assertEqual(selected[0]["split"], "calibration")
        finally:
            import shutil
            shutil.rmtree(root, ignore_errors=True)


class ConformalTests(unittest.TestCase):
    def test_exact_finite_sample_gate(self):
        self.assertTrue(math.isinf(finite_sample_quantile(range(18), 0.05)))
        self.assertEqual(finite_sample_quantile(range(19), 0.05), 18)

    def test_episode_score_covers_action_selection(self):
        rows = []
        for episode in range(20):
            for action in range(2):
                actual = 100.0
                predicted = 100.0
                if episode == 19 and action == 1:
                    actual = 110.0
                rows.append({
                    "episode_id": str(episode), "source": "x",
                    "power_mean_w": actual, "pred_power": predicted,
                    "ttft_p95_ms": 10.0, "pred_ttft": 10.0,
                    "tpot_p99_ms": 1.0, "pred_tpot": 1.0,
                    "batch_tokens_per_s": 10.0, "pred_batch": 10.0,
                })
        calibrator = HybridJointCalibrator(
            0.05,
            scales={
                "power_mean_w": 1.0, "ttft_p95_ms": 1.0,
                "tpot_p99_ms": 1.0, "batch_tokens_per_s": 1.0,
            },
        ).fit(rows, {
            "power_mean_w": "pred_power", "ttft_p95_ms": "pred_ttft",
            "tpot_p99_ms": "pred_tpot", "batch_tokens_per_s": "pred_batch",
        })
        self.assertEqual(calibrator.row_radius, 0.0)
        self.assertEqual(calibrator.episode_radius, 10.0)

    def test_action_normalization_preserves_joint_episode_max(self):
        scales = {
            "4:4:300": {
                "power_mean_w": 1.0, "ttft_p95_ms": 1.0,
                "tpot_p99_ms": 1.0, "batch_tokens_per_s": 1.0,
            },
            "2:0:300": {
                "power_mean_w": 100.0, "ttft_p95_ms": 1.0,
                "tpot_p99_ms": 1.0, "batch_tokens_per_s": 1.0,
            },
        }
        rows = []
        for episode in range(20):
            for replicas, concurrency, raw_error in (
                (4, 4, 1.0), (2, 0, 100.0)
            ):
                rows.append({
                    "episode_id": str(episode), "source": "x",
                    "online_replicas": replicas,
                    "batch_concurrency": concurrency,
                    "power_cap_w": 300,
                    "power_mean_w": 100.0,
                    "pred_power": 100.0 + raw_error,
                    "ttft_p95_ms": 10.0, "pred_ttft": 10.0,
                    "tpot_p99_ms": 1.0, "pred_tpot": 1.0,
                    "batch_tokens_per_s": 10.0, "pred_batch": 10.0,
                })
        calibrator = ActionNormalizedJointCalibrator(
            0.05, scales_by_action=scales
        ).fit(rows, {
            "power_mean_w": "pred_power",
            "ttft_p95_ms": "pred_ttft",
            "tpot_p99_ms": "pred_tpot",
            "batch_tokens_per_s": "pred_batch",
        })
        self.assertEqual(calibrator.episode_radius, 1.0)
        self.assertEqual(calibrator.margin(rows[0], "power_mean_w", "episode"), 1.0)
        self.assertEqual(calibrator.margin(rows[1], "power_mean_w", "episode"), 100.0)

    def test_directional_calibration_ignores_conservative_error(self):
        self.assertEqual(
            ActionNormalizedJointCalibrator.directional_error(
                "power_mean_w", actual=110.0, predicted=100.0
            ),
            0.0,
        )
        self.assertEqual(
            ActionNormalizedJointCalibrator.directional_error(
                "tpot_p99_ms", actual=8.0, predicted=10.0
            ),
            0.0,
        )


class FrozenTrajectoryCalibrationTests(unittest.TestCase):
    def test_gate_and_electrical_margin_do_not_select_actions(self):
        slack_rows = [
            SlackObservation(str(index), "tpot", 5.0, 4.0)
            for index in range(20)
        ]
        delivery_rows = [
            DeliveryObservation(str(index), 100.0, 90.0)
            for index in range(20)
        ]
        safety = TrajectorySafetyCalibrator(
            alpha=0.05, scales={"tpot": 1.0}
        ).fit(slack_rows)
        electrical = ElectricalDeliveryCalibrator(
            alpha=0.05, scale_w=10.0
        ).fit(delivery_rows)
        result = FrozenPolicyCalibrator(safety, electrical).calibrate(
            raw_bid_w=100.0,
            predicted_slacks={"tpot": 1.0},
        )
        self.assertTrue(result.accepted)
        self.assertEqual(result.raw_bid_w, 100.0)
        self.assertEqual(result.calibrated_bid_w, 90.0)

    def test_non_electrical_gate_abstains(self):
        rows = [
            SlackObservation(str(index), "deadline", 2.0, 0.0)
            for index in range(20)
        ]
        safety = TrajectorySafetyCalibrator(
            alpha=0.05, scales={"deadline": 1.0}
        ).fit(rows)
        electrical = ElectricalDeliveryCalibrator(
            alpha=0.05, scale_w=10.0
        ).fit([
            DeliveryObservation(str(index), 100.0, 100.0)
            for index in range(20)
        ])
        result = FrozenPolicyCalibrator(safety, electrical).calibrate(
            100.0, {"deadline": 1.0}
        )
        self.assertFalse(result.accepted)
        self.assertEqual(result.calibrated_bid_w, 0.0)


class PolicyTests(unittest.TestCase):
    class Surrogate:
        def predict(self, row):
            power = 300.0 if row["name"] == "hybrid_full" else 200.0
            return HybridPrediction(power, 100.0, 10.0, 0.0)

        def bounds(self, row, mode):
            prediction = self.predict(row)
            radius = 10.0 if mode == "episode" else 0.0
            return HybridBounds(
                prediction.power_mean_w - radius,
                prediction.power_mean_w + radius,
                prediction.ttft_p95_ms,
                prediction.tpot_p99_ms,
                0.0,
            )

    def test_episode_bid_uses_two_power_tails(self):
        rows = [
            {"name": "hybrid_full", "ttft_slo_ms": 5000, "tpot_slo_ms": 100},
            {"name": "pause", "ttft_slo_ms": 5000, "tpot_slo_ms": 100},
        ]
        decision = risk_calibrated_bid(rows, self.Surrogate(), "episode")
        self.assertEqual(decision.action_name, "pause")
        self.assertEqual(decision.committed_reduction_w, 80.0)


if __name__ == "__main__":
    unittest.main()
