#!/usr/bin/env python3
"""Fit the independent gate and electrical margin for a frozen policy.

Input is JSONL with one row per calibration episode::

  {"episode_id": "...", "slacks": {
     "tpot_ms": {"predicted": 20, "realized": 12}},
   "settlements": [{"predicted_reduction_w": 1200,
                    "realized_reduction_w": 1160}]}

Constraint scales are a JSON object frozen on policy-selection data.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flexbid_hybrid.io import atomic_json
from flexbid_hybrid.trajectory_calibration import (
    DeliveryObservation,
    ElectricalDeliveryCalibrator,
    FrozenPolicyCalibrator,
    SlackObservation,
    TrajectorySafetyCalibrator,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=Path, required=True)
    parser.add_argument("--scales", type=Path, required=True)
    parser.add_argument("--electrical-scale-w", type=float, required=True)
    parser.add_argument("--alpha-gate", type=float, default=0.025)
    parser.add_argument("--alpha-electrical", type=float, default=0.025)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    scales = json.loads(args.scales.read_text(encoding="utf-8"))
    slack_rows: list[SlackObservation] = []
    delivery_rows: list[DeliveryObservation] = []
    for line in args.episodes.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        episode = str(row["episode_id"])
        for name, values in row["slacks"].items():
            slack_rows.append(SlackObservation(
                episode,
                str(name),
                float(values["predicted"]),
                float(values["realized"]),
            ))
        for values in row["settlements"]:
            delivery_rows.append(DeliveryObservation(
                episode,
                float(values["predicted_reduction_w"]),
                float(values["realized_reduction_w"]),
            ))

    calibrator = FrozenPolicyCalibrator(
        TrajectorySafetyCalibrator(
            args.alpha_gate, scales,
        ).fit(slack_rows),
        ElectricalDeliveryCalibrator(
            args.alpha_electrical, args.electrical_scale_w,
        ).fit(delivery_rows),
    )
    report = calibrator.as_dict()
    report["episodes"] = len({row.episode_id for row in slack_rows})
    report["alpha_total"] = args.alpha_gate + args.alpha_electrical
    atomic_json(args.output, report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
