#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import socket
import subprocess
import sys
from pathlib import Path

from flexbid_hybrid.config import load_config, resolve
from flexbid_hybrid.io import atomic_json


def command(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(args, text=True, capture_output=True, check=False)


def port_available(port: int) -> bool:
    with socket.socket() as sock:
        try:
            sock.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def finite_number(value: str) -> bool:
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    config = load_config(args.config)
    hardware = config["hardware"]
    query = command([
        "nvidia-smi", "--query-gpu=index,name,memory.total,power.draw,power.limit,"
        "power.default_limit,power.min_limit,power.max_limit,utilization.gpu",
        "--format=csv,noheader,nounits",
    ])
    devices = []
    if query.returncode == 0:
        for line in query.stdout.splitlines():
            fields = [item.strip() for item in line.split(",")]
            if len(fields) == 9:
                devices.append(fields)
    replicas = config["model"]["replicas"]
    flattened = [gpu for replica in replicas for gpu in replica]
    manifest_path = resolve(root, config["workloads"]["manifest"])
    model_path = Path(config["model"]["name"])
    first_port = int(config["runtime"]["first_vllm_port"])
    ports = [int(config["runtime"]["gateway_port"])] + [
        first_port + index for index in range(len(replicas))
    ]
    process_query = command([
        "nvidia-smi", "--query-compute-apps=pid,process_name,used_memory",
        "--format=csv,noheader,nounits",
    ])
    minimum = max((float(row[6]) for row in devices), default=math.inf)
    maximum = min((float(row[7]) for row in devices), default=-math.inf)
    caps = [float(item["power_cap_w"]) for item in config["actions"]]
    checks = {
        "python_310_plus": sys.version_info >= (3, 10),
        "vllm_installed": shutil.which("vllm") is not None,
        "gpu_count": len(devices) == int(hardware["expected_gpu_count"]),
        "gpu_model": bool(devices) and all(re.search(
            hardware["expected_gpu_name_regex"], row[1], re.I
        ) for row in devices),
        "gpu_idle": bool(devices) and all(float(row[8]) == 0 for row in devices),
        "power_telemetry_readable": bool(devices) and all(
            finite_number(row[3]) for row in devices
        ),
        "no_foreign_compute_processes": (
            process_query.returncode == 0 and not process_query.stdout.strip()
        ),
        "replicas_are_disjoint": len(flattened) == len(set(flattened)),
        "replicas_cover_expected_gpus": sorted(flattened) == sorted(hardware["gpu_indices"]),
        "tp2_layout": bool(replicas) and all(len(item) == 2 for item in replicas),
        "model_config_exists": (model_path / "config.json").exists(),
        "manifest_exists": manifest_path.exists(),
        "power_caps_supported": bool(devices) and all(minimum <= cap <= maximum for cap in caps),
        "ports_available": all(port_available(port) for port in ports),
    }
    report = {
        "passed": all(checks.values()), "checks": checks,
        "devices": devices, "replicas": replicas, "ports": ports,
        "model": str(model_path), "manifest": str(manifest_path),
        "power_cap_common_range_w": [minimum, maximum],
        "nvidia_smi_stderr": query.stderr.strip(),
    }
    atomic_json(args.output, report)
    print(json.dumps(report, indent=2))
    if not report["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
