"""Risk-calibrated viability MPC for hybrid online--batch serving.

The old controller selected one action from a hand-written menu.  This module
instead optimizes a *sequence* of joint replica, batch-concurrency, and power-cap
actions over the demand-response event and its recovery horizon.  Only the first
action is applied; the runtime re-solves after observing fresh telemetry.
"""

from __future__ import annotations

import math
import time
from dataclasses import asdict, dataclass, field
from typing import Iterable, Mapping, Protocol

from .modeling import HybridBounds, HybridPrediction
from .types import HybridAction


class PredictiveModel(Protocol):
    def predict(self, row: dict) -> HybridPrediction: ...

    def bounds(self, row: dict, mode: str) -> HybridBounds: ...


@dataclass(frozen=True)
class ControlState:
    """Measured and forecast state at one MPC re-planning instant."""

    source: str
    event_remaining_s: float
    deadline_remaining_s: float
    backlog_tokens: float
    current_action: str
    ttft_slo_ms: float
    tpot_slo_ms: float
    workload_features: Mapping[str, float] = field(default_factory=dict)
    baseline_batch_tps: float | None = None
    committed_bid_w: float | None = None
    replica_dwell_remaining_s: float = 0.0

    def __post_init__(self) -> None:
        if self.event_remaining_s < 0:
            raise ValueError("event_remaining_s cannot be negative")
        if self.deadline_remaining_s < self.event_remaining_s:
            raise ValueError("deadline cannot precede the end of the event")
        if self.backlog_tokens < 0:
            raise ValueError("backlog_tokens cannot be negative")
        if self.committed_bid_w is not None and self.committed_bid_w < 0:
            raise ValueError("committed_bid_w cannot be negative")
        if self.replica_dwell_remaining_s < 0:
            raise ValueError("replica_dwell_remaining_s cannot be negative")


@dataclass(frozen=True)
class MPCParameters:
    control_period_s: float = 10.0
    calibration_mode: str = "episode"
    debt_quantum_tokens: float = 1024.0
    terminal_tolerance_tokens: float = 1024.0
    switch_penalty: float = 25.0
    recovery_power_weight: float = 0.02
    recovery_service_credit: float = 0.001
    maximum_states_per_step: int = 20_000
    replica_min_dwell_s: float = 120.0
    solve_budget_s: float = 10.0

    def __post_init__(self) -> None:
        if self.control_period_s <= 0:
            raise ValueError("control_period_s must be positive")
        if self.debt_quantum_tokens <= 0:
            raise ValueError("debt_quantum_tokens must be positive")
        if self.terminal_tolerance_tokens < 0:
            raise ValueError("terminal_tolerance_tokens cannot be negative")
        if self.maximum_states_per_step <= 0:
            raise ValueError("maximum_states_per_step must be positive")
        if self.replica_min_dwell_s < 0:
            raise ValueError("replica_min_dwell_s cannot be negative")
        if self.solve_budget_s <= 0:
            raise ValueError("solve_budget_s must be positive")


@dataclass(frozen=True)
class ActionEnvelope:
    action: HybridAction
    power_lower_w: float
    power_upper_w: float
    ttft_upper_ms: float
    tpot_upper_ms: float
    batch_tps_lower: float
    guaranteed_reduction_w: float
    expected_reduction_w: float
    slo_safe: bool

    def as_dict(self) -> dict:
        value = asdict(self)
        value["action"] = self.action.as_dict()
        return value


@dataclass(frozen=True)
class PlanStep:
    index: int
    stage: str
    duration_s: float
    action: HybridAction
    backlog_before_tokens: float
    backlog_after_tokens: float
    guaranteed_reduction_w: float
    batch_tps_lower: float
    ttft_upper_ms: float
    tpot_upper_ms: float

    def as_dict(self) -> dict:
        value = asdict(self)
        value["action"] = self.action.as_dict()
        return value


@dataclass(frozen=True)
class MPCPlan:
    feasible: bool
    committed_bid_w: float
    objective: float
    steps: tuple[PlanStep, ...]
    terminal_backlog_tokens: float
    solve_time_ms: float
    evaluated_actions: int
    pareto_actions: int
    reason: str

    @property
    def first_action(self) -> HybridAction:
        if not self.steps:
            raise RuntimeError("plan has no action")
        return self.steps[0].action

    def as_dict(self) -> dict:
        value = asdict(self)
        value["steps"] = [step.as_dict() for step in self.steps]
        return value


@dataclass
class _Node:
    score: float
    backlog: float
    replica_dwell_s: float
    previous: "_Node | None"
    step: PlanStep | None


def _unwind(node: _Node) -> tuple[PlanStep, ...]:
    values = []
    current: _Node | None = node
    while current is not None and current.step is not None:
        values.append(current.step)
        current = current.previous
    values.reverse()
    return tuple(values)


def _row(state: ControlState, action: HybridAction) -> dict:
    return {
        **dict(state.workload_features),
        "source": state.source,
        "online_replicas": action.online_replicas,
        "batch_concurrency": action.batch_concurrency,
        "power_cap_w": action.power_cap_w,
        "ttft_slo_ms": state.ttft_slo_ms,
        "tpot_slo_ms": state.tpot_slo_ms,
        "name": action.name,
    }


def pareto_prune(
    envelopes: Iterable[ActionEnvelope], current_action: str,
) -> list[ActionEnvelope]:
    """Remove actions no better in reduction, service, or SLO headroom.

    Keeping the current action preserves a potentially useful zero-switch-cost
    transition even when its steady-state envelope is dominated.
    """

    values = list(envelopes)
    result: list[ActionEnvelope] = []
    for candidate in values:
        dominated = False
        if candidate.action.name != current_action:
            for other in values:
                if other.action.name == candidate.action.name:
                    continue
                weakly_better = (
                    other.guaranteed_reduction_w
                    >= candidate.guaranteed_reduction_w - 1e-9
                    and other.batch_tps_lower >= candidate.batch_tps_lower - 1e-9
                    and other.ttft_upper_ms <= candidate.ttft_upper_ms + 1e-9
                    and other.tpot_upper_ms <= candidate.tpot_upper_ms + 1e-9
                )
                strictly_better = (
                    other.guaranteed_reduction_w
                    > candidate.guaranteed_reduction_w + 1e-9
                    or other.batch_tps_lower > candidate.batch_tps_lower + 1e-9
                    or other.ttft_upper_ms < candidate.ttft_upper_ms - 1e-9
                    or other.tpot_upper_ms < candidate.tpot_upper_ms - 1e-9
                )
                if weakly_better and strictly_better:
                    dominated = True
                    break
        if not dominated:
            result.append(candidate)
    return sorted(result, key=lambda item: item.action.name)


class ViabilityMPC:
    """Finite-horizon robust controller over a discrete joint action lattice."""

    def __init__(
        self,
        model: PredictiveModel,
        actions: Iterable[HybridAction],
        parameters: MPCParameters | None = None,
        *,
        baseline_action: str = "hybrid_full",
    ):
        self.model = model
        self.actions = tuple(actions)
        self.actions_by_name = {action.name: action for action in self.actions}
        self.parameters = parameters or MPCParameters()
        self.baseline_action = baseline_action
        names = [action.name for action in self.actions]
        if len(names) != len(set(names)):
            raise ValueError("action names must be unique")
        if baseline_action not in names:
            raise ValueError(f"baseline action is missing: {baseline_action}")

    def envelopes(self, state: ControlState) -> list[ActionEnvelope]:
        baseline_action = next(
            action for action in self.actions if action.name == self.baseline_action
        )
        baseline_row = _row(state, baseline_action)
        baseline_prediction = self.model.predict(baseline_row)
        baseline_bounds = self.model.bounds(
            baseline_row, self.parameters.calibration_mode
        )
        baseline_safe = (
            math.isfinite(baseline_bounds.power_lower_w)
            and baseline_bounds.ttft_upper_ms <= state.ttft_slo_ms
            and baseline_bounds.tpot_upper_ms <= state.tpot_slo_ms
        )
        if not baseline_safe:
            return []
        result = []
        for action in self.actions:
            row = _row(state, action)
            supports = getattr(self.model, "supports", None)
            if supports is not None and not supports(row):
                continue
            prediction = self.model.predict(row)
            bounds = self.model.bounds(row, self.parameters.calibration_mode)
            reduction = baseline_bounds.power_lower_w - bounds.power_upper_w
            result.append(ActionEnvelope(
                action=action,
                power_lower_w=bounds.power_lower_w,
                power_upper_w=bounds.power_upper_w,
                ttft_upper_ms=bounds.ttft_upper_ms,
                tpot_upper_ms=bounds.tpot_upper_ms,
                batch_tps_lower=bounds.batch_tokens_per_s_lower,
                guaranteed_reduction_w=reduction,
                expected_reduction_w=(
                    baseline_prediction.power_mean_w - prediction.power_mean_w
                ),
                slo_safe=(
                    math.isfinite(reduction)
                    and bounds.ttft_upper_ms <= state.ttft_slo_ms
                    and bounds.tpot_upper_ms <= state.tpot_slo_ms
                ),
            ))
        return result

    def _durations(self, state: ControlState) -> list[tuple[str, float]]:
        result: list[tuple[str, float]] = []
        event = state.event_remaining_s
        recovery = state.deadline_remaining_s - state.event_remaining_s
        for stage, remaining in (("event", event), ("recovery", recovery)):
            while remaining > 1e-9:
                duration = min(self.parameters.control_period_s, remaining)
                result.append((stage, duration))
                remaining -= duration
        return result

    def _fallback(
        self,
        state: ControlState,
        safe: list[ActionEnvelope],
        started: float,
        reason: str,
    ) -> MPCPlan:
        if safe:
            chosen = max(
                safe,
                key=lambda item: (
                    item.batch_tps_lower,
                    -item.power_upper_w,
                    item.action.name == self.baseline_action,
                ),
            )
        else:
            action = next(
                item for item in self.actions if item.name == self.baseline_action
            )
            chosen = ActionEnvelope(
                action, 0.0, math.inf, math.inf, math.inf, 0.0, 0.0, 0.0, False
            )
        duration = min(
            self.parameters.control_period_s,
            max(state.deadline_remaining_s, self.parameters.control_period_s),
        )
        step = PlanStep(
            0,
            "event" if state.event_remaining_s > 0 else "recovery",
            duration,
            chosen.action,
            state.backlog_tokens,
            state.backlog_tokens,
            chosen.guaranteed_reduction_w,
            chosen.batch_tps_lower,
            chosen.ttft_upper_ms,
            chosen.tpot_upper_ms,
        )
        return MPCPlan(
            False, 0.0, -math.inf, (step,), state.backlog_tokens,
            (time.perf_counter() - started) * 1000,
            len(self.actions), len(safe), reason,
        )

    def solve(self, state: ControlState) -> MPCPlan:
        started = time.perf_counter()
        solve_deadline = started + self.parameters.solve_budget_s
        timed_out = False
        all_envelopes = self.envelopes(state)
        safe = [item for item in all_envelopes if item.slo_safe]
        if not safe:
            return self._fallback(
                state, safe, started,
                "baseline prediction is unsafe or no SLO-safe action exists",
            )
        frontier = pareto_prune(safe, state.current_action)
        baseline = next(
            item for item in all_envelopes
            if item.action.name == self.baseline_action
        )
        baseline_tps = (
            float(state.baseline_batch_tps)
            if state.baseline_batch_tps is not None
            else baseline.batch_tps_lower
        )
        durations = self._durations(state)
        if not durations:
            return self._fallback(state, safe, started, "deadline has elapsed")

        quantum = self.parameters.debt_quantum_tokens
        maximum_batch_tps = max(
            envelope.batch_tps_lower for envelope in frontier
        )
        future_repayment = [0.0 for _ in durations]
        repay = 0.0
        for index in range(len(durations) - 1, -1, -1):
            future_repayment[index] = repay
            _stage, future_duration = durations[index]
            repay += max(0.0, maximum_batch_tps - baseline_tps) * future_duration

        def is_viable(required_bid_w: float) -> bool:
            """Fast reachability pass used while maximizing the safe bid.

            For an identical previous action and dwell state, less batch debt
            dominates more debt for future feasibility.  Keeping only that
            minimum turns bid search into a small O(H|A|^2) reachability pass.
            """

            nonlocal timed_out
            states: dict[tuple[str, int], tuple[float, float]] = {
                (
                    state.current_action,
                    int(math.ceil(
                        state.replica_dwell_remaining_s
                        / self.parameters.control_period_s
                    )),
                ): (state.backlog_tokens, state.replica_dwell_remaining_s)
            }
            for step_index, (stage, duration) in enumerate(durations):
                if time.perf_counter() > solve_deadline:
                    timed_out = True
                    return False
                following: dict[tuple[str, int], tuple[float, float]] = {}
                for (previous_name, _dwell_bucket), (backlog, dwell_s) in states.items():
                    previous_action = self.actions_by_name.get(previous_name)
                    for envelope in frontier:
                        replica_change = (
                            previous_action is not None
                            and envelope.action.online_replicas
                            != previous_action.online_replicas
                        )
                        if replica_change and dwell_s > 1e-9:
                            continue
                        if (
                            stage == "event"
                            and envelope.guaranteed_reduction_w + 1e-9
                            < required_bid_w
                        ):
                            continue
                        next_backlog = max(
                            0.0,
                            backlog
                            + (baseline_tps - envelope.batch_tps_lower) * duration,
                        )
                        if (
                            next_backlog
                            > future_repayment[step_index]
                            + self.parameters.terminal_tolerance_tokens
                            + 1e-9
                        ):
                            continue
                        next_dwell = (
                            self.parameters.replica_min_dwell_s
                            if replica_change else max(0.0, dwell_s - duration)
                        )
                        key = (
                            envelope.action.name,
                            int(math.ceil(
                                next_dwell / self.parameters.control_period_s
                            )),
                        )
                        incumbent = following.get(key)
                        if incumbent is None or next_backlog < incumbent[0]:
                            following[key] = (next_backlog, next_dwell)
                if not following:
                    return False
                states = following
            return any(
                backlog <= self.parameters.terminal_tolerance_tokens
                for backlog, _dwell in states.values()
            )

        def search(required_bid_w: float) -> _Node | None:
            nonlocal timed_out
            initial_key = (
                int(math.ceil(state.backlog_tokens / quantum - 1e-12)),
                state.current_action,
                int(math.ceil(
                    state.replica_dwell_remaining_s
                    / self.parameters.control_period_s
                )),
            )
            nodes: dict[tuple[int, str, int], _Node] = {
                initial_key: _Node(
                    0.0, state.backlog_tokens,
                    state.replica_dwell_remaining_s, None, None,
                )
            }
            for step_index, (stage, duration) in enumerate(durations):
                if time.perf_counter() > solve_deadline:
                    timed_out = True
                    return None
                next_nodes: dict[tuple[int, str, int], _Node] = {}
                for (_bucket, previous_name, _dwell_bucket), node in nodes.items():
                    previous_action = self.actions_by_name.get(previous_name)
                    for envelope in frontier:
                        replica_change = (
                            previous_action is not None
                            and envelope.action.online_replicas
                            != previous_action.online_replicas
                        )
                        if replica_change and node.replica_dwell_s > 1e-9:
                            continue
                        if (
                            stage == "event"
                            and envelope.guaranteed_reduction_w + 1e-9
                            < required_bid_w
                        ):
                            continue
                        next_backlog = max(
                            0.0,
                            node.backlog
                            + (baseline_tps - envelope.batch_tps_lower) * duration,
                        )
                        if (
                            next_backlog
                            > future_repayment[step_index]
                            + self.parameters.terminal_tolerance_tokens
                            + 1e-9
                        ):
                            continue
                        switch = float(envelope.action.name != previous_name)
                        if stage == "event":
                            reward = envelope.guaranteed_reduction_w * duration
                        else:
                            reward = (
                                self.parameters.recovery_service_credit
                                * envelope.batch_tps_lower * duration
                                - self.parameters.recovery_power_weight
                                * envelope.power_upper_w * duration
                            )
                        score = (
                            node.score + reward
                            - self.parameters.switch_penalty * switch
                        )
                        next_dwell = (
                            self.parameters.replica_min_dwell_s
                            if replica_change
                            else max(0.0, node.replica_dwell_s - duration)
                        )
                        plan_step = PlanStep(
                            step_index, stage, duration, envelope.action,
                            node.backlog, next_backlog,
                            envelope.guaranteed_reduction_w,
                            envelope.batch_tps_lower,
                            envelope.ttft_upper_ms,
                            envelope.tpot_upper_ms,
                        )
                        key = (
                            int(math.ceil(next_backlog / quantum - 1e-12)),
                            envelope.action.name,
                            int(math.ceil(
                                next_dwell / self.parameters.control_period_s
                            )),
                        )
                        incumbent = next_nodes.get(key)
                        if incumbent is None or score > incumbent.score:
                            next_nodes[key] = _Node(
                                score, next_backlog, next_dwell,
                                node, plan_step,
                            )
                if not next_nodes:
                    return None
                if len(next_nodes) > self.parameters.maximum_states_per_step:
                    ranked = sorted(
                        next_nodes.items(),
                        key=lambda item: (item[1].score, -item[1].backlog),
                        reverse=True,
                    )[:self.parameters.maximum_states_per_step]
                    next_nodes = dict(ranked)
                nodes = next_nodes
            viable = [
                node for node in nodes.values()
                if node.backlog <= self.parameters.terminal_tolerance_tokens
            ]
            return max(viable, key=lambda node: node.score) if viable else None

        if state.event_remaining_s <= 0:
            candidate_bids = [0.0]
        elif state.committed_bid_w is not None:
            candidate_bids = [state.committed_bid_w]
        else:
            candidate_bids = sorted({
                max(0.0, envelope.guaranteed_reduction_w)
                for envelope in frontier
            })
        best = None
        bid = 0.0
        if state.committed_bid_w is not None or state.event_remaining_s <= 0:
            bid = candidate_bids[0]
            best = search(bid) if is_viable(bid) else None
        else:
            # Viability is monotone in the minimum event bid.  Binary search
            # finds the exact highest profiled reduction level with O(log |A|)
            # dynamic-program runs instead of one run per action.
            low, high = 0, len(candidate_bids) - 1
            while low <= high:
                middle = (low + high) // 2
                candidate_bid = candidate_bids[middle]
                if is_viable(candidate_bid):
                    bid = candidate_bid
                    low = middle + 1
                else:
                    high = middle - 1
            if low > 0:
                best = search(bid)
        if best is None:
            reason = (
                "solver budget exceeded; returning safe service fallback"
                if timed_out else
                "committed bid has no SLO-safe viable continuation"
                if state.committed_bid_w is not None
                else "no action sequence can repay batch debt before the deadline"
            )
            return self._fallback(state, safe, started, reason)
        return MPCPlan(
            True,
            max(0.0, bid),
            best.score,
            _unwind(best),
            best.backlog,
            (time.perf_counter() - started) * 1000,
            len(all_envelopes),
            len(frontier),
            "optimal risk-calibrated viable sequence on the discretized horizon",
        )


def build_action_lattice(spec: Mapping) -> list[HybridAction]:
    """Generate joint actions from independent actuator axes.

    The optimizer, rather than a hand-written policy, decides which combinations
    are useful.  ``baseline`` identifies the normal operating point and receives
    the stable name ``hybrid_full`` for compatibility with existing models.
    """

    replicas = sorted({int(value) for value in spec["online_replicas"]})
    concurrencies = sorted({int(value) for value in spec["batch_concurrency"]})
    caps = sorted({float(value) for value in spec["power_cap_w"]})
    baseline = spec.get("baseline", {})
    baseline_tuple = (
        int(baseline.get("online_replicas", max(replicas))),
        int(baseline.get("batch_concurrency", max(concurrencies))),
        float(baseline.get("power_cap_w", max(caps))),
    )
    actions = []
    for online_replicas in replicas:
        for batch_concurrency in concurrencies:
            for power_cap_w in caps:
                values = (online_replicas, batch_concurrency, power_cap_w)
                name = (
                    "hybrid_full" if values == baseline_tuple
                    else f"mpc_r{online_replicas}_c{batch_concurrency}_p{power_cap_w:g}"
                )
                actions.append(HybridAction(name, *values))
    if not any(action.name == "hybrid_full" for action in actions):
        raise ValueError("baseline is outside the configured action lattice")
    return actions
