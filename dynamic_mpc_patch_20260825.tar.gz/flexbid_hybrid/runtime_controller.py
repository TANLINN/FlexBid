"""Production-facing feedback loop for the viability MPC controller."""

from __future__ import annotations

import json
import math
import time
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean
from typing import Callable, Iterable

from .io import atomic_json
from .mpc import ControlState, MPCPlan, ViabilityMPC
from .pilot import apply_control
from .power import PowerCapManager
from .service import get_json
from .types import HybridAction


@dataclass(frozen=True)
class RuntimeObservation:
    wall_time_ns: int
    elapsed_s: float
    event_remaining_s: float
    deadline_remaining_s: float
    backlog_tokens: float
    completed_online: int
    completed_batch: int
    observed_component_power_w: float | None
    workload_features: dict[str, float]


class OnlineFeatureEstimator:
    """Build the surrogate's workload features from a rolling gateway window."""

    def __init__(
        self, source: str, window_s: float = 60.0,
        projection_s: float | None = None,
    ):
        if window_s <= 0:
            raise ValueError("window_s must be positive")
        self.source = source
        self.window_s = window_s
        self.projection_s = window_s if projection_s is None else projection_s
        if self.projection_s <= 0:
            raise ValueError("projection_s must be positive")
        self.rows: deque[dict] = deque()
        self.last_sequence = 0
        self.latest_rows: list[dict] = []

    def update(self, state: dict, now_ns: int | None = None) -> dict[str, float]:
        now_ns = time.time_ns() if now_ns is None else now_ns
        self.latest_rows = []
        for row in state.get("recent_online_metrics", []):
            sequence = int(row.get("sequence", 0))
            if sequence <= self.last_sequence:
                continue
            self.rows.append(dict(row))
            self.latest_rows.append(dict(row))
            self.last_sequence = max(self.last_sequence, sequence)
        cutoff = now_ns - int(self.window_s * 1e9)
        while self.rows and int(self.rows[0].get("completed_wall_time_ns", 0)) < cutoff:
            self.rows.popleft()
        prompts = [
            float(row["prompt_tokens"]) for row in self.rows
            if row.get("prompt_tokens") is not None
        ]
        outputs = [
            float(row["max_output_tokens"]) for row in self.rows
            if row.get("max_output_tokens") is not None
        ]
        prefixes = [
            float(row.get("cache_prefix_tokens") or 0.0) for row in self.rows
        ]
        count = len(self.rows)
        prompt_sum = sum(prompts)
        scale = self.projection_s / self.window_s
        source_counts: dict[str, int] = {}
        for row in self.rows:
            value = str(row.get("request_source") or "unknown")
            source_counts[value] = source_counts.get(value, 0) + 1

        def source_fraction(name: str) -> float:
            known = sum(
                source_counts.get(value, 0) for value in (
                    "azure_code", "azure_conversation",
                    "qwen_bailian", "tracelab",
                )
            )
            if known:
                return source_counts.get(name, 0) / known
            return float(self.source == name)

        return {
            "source_azure_code": source_fraction("azure_code"),
            "source_azure_conversation": source_fraction("azure_conversation"),
            "source_qwen_bailian": source_fraction("qwen_bailian"),
            "source_tracelab": source_fraction("tracelab"),
            "online_arrivals": float(count) * scale,
            "online_arrival_rate_rps": count / self.window_s,
            "prompt_tokens_sum": prompt_sum * scale,
            "prompt_tokens_mean": mean(prompts) if prompts else 0.0,
            "prompt_tokens_max": max(prompts, default=0.0),
            "output_tokens_sum": sum(outputs) * scale,
            "output_tokens_mean": mean(outputs) if outputs else 0.0,
            "cache_prefix_fraction": (
                0.0 if prompt_sum <= 0 else sum(prefixes) / prompt_sum
            ),
        }


def read_component_power_w(gpu_indices: Iterable[int]) -> float | None:
    """Best-effort instantaneous GPU power for feedback and audit logging."""

    try:
        import pynvml

        pynvml.nvmlInit()
        try:
            values = []
            for index in gpu_indices:
                handle = pynvml.nvmlDeviceGetHandleByIndex(int(index))
                values.append(pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0)
            return sum(values)
        finally:
            pynvml.nvmlShutdown()
    except Exception:
        return None


class DynamicControlLoop:
    """Attach to a live gateway, re-plan, actuate once, and repeat."""

    def __init__(
        self,
        *,
        optimizer: ViabilityMPC,
        actions: Iterable[HybridAction],
        source: str,
        gateway_url: str,
        control_file: Path,
        gpu_indices: Iterable[int],
        replica_count: int,
        online_concurrency: int,
        event_s: float,
        deadline_s: float,
        baseline_batch_tps: float,
        batch_output_tokens: int,
        ttft_slo_ms: float,
        tpot_slo_ms: float,
        log_path: Path,
        state_path: Path,
        feature_window_s: float = 60.0,
        feature_projection_s: float | None = None,
        warmup_s: float = 0.0,
        bid_quantum_w: float = 10.0,
        bid_derating: float = 0.95,
        dry_run: bool = False,
        state_reader: Callable[[str], dict] = get_json,
    ):
        if event_s <= 0 or deadline_s <= event_s:
            raise ValueError("deadline_s must be greater than positive event_s")
        if baseline_batch_tps <= 0:
            raise ValueError("baseline_batch_tps must be positive")
        if batch_output_tokens <= 0:
            raise ValueError("batch_output_tokens must be positive")
        self.optimizer = optimizer
        self.actions = {action.name: action for action in actions}
        self.source = source
        self.gateway_url = gateway_url.rstrip("/")
        self.control_file = control_file
        self.gpu_indices = list(gpu_indices)
        self.replica_count = replica_count
        self.online_concurrency = online_concurrency
        self.event_s = event_s
        self.deadline_s = deadline_s
        self.baseline_batch_tps = baseline_batch_tps
        self.batch_output_tokens = batch_output_tokens
        self.ttft_slo_ms = ttft_slo_ms
        self.tpot_slo_ms = tpot_slo_ms
        self.log_path = log_path
        self.state_path = state_path
        self.bid_quantum_w = bid_quantum_w
        self.bid_derating = bid_derating
        self.warmup_s = warmup_s
        if self.warmup_s < 0:
            raise ValueError("warmup_s cannot be negative")
        self.dry_run = dry_run
        self.state_reader = state_reader
        self.features = OnlineFeatureEstimator(
            source, feature_window_s, feature_projection_s
        )
        self.committed_bid_w: float | None = None
        self.current_action = optimizer.baseline_action
        self.previous_features: dict[str, float] | None = None
        self.previous_elapsed_s = 0.0
        self.previous_completed_batch = 0
        self.last_replica_change_s = -math.inf

    def _commit(self, plan: MPCPlan) -> float:
        if self.committed_bid_w is None:
            raw = max(0.0, plan.committed_bid_w * self.bid_derating)
            self.committed_bid_w = (
                math.floor(raw / self.bid_quantum_w) * self.bid_quantum_w
                if self.bid_quantum_w > 0 else raw
            )
        return self.committed_bid_w

    def _actuate(
        self, action: HybridAction, power: PowerCapManager | None
    ) -> dict:
        previous = self.actions.get(self.current_action)
        if self.dry_run:
            if previous and previous.online_replicas != action.online_replicas:
                self.last_replica_change_s = time.monotonic()
            self.current_action = action.name
            return {"dry_run": True, "action": action.as_dict()}
        caps = None
        if power is not None:
            caps = power.set_all(action.power_cap_w)
        control = apply_control(
            self.control_file,
            action,
            self.replica_count,
            self.online_concurrency,
        )
        self.current_action = action.name
        if previous and previous.online_replicas != action.online_replicas:
            self.last_replica_change_s = time.monotonic()
        return {"dry_run": False, "control": control, "enforced_caps_w": caps}

    def run(self) -> None:
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        power_manager = None if self.dry_run else PowerCapManager(self.gpu_indices)
        try:
            self._actuate(
                self.actions[self.optimizer.baseline_action], power_manager
            )
            warmup_deadline = time.monotonic() + self.warmup_s
            initial = self.state_reader(self.gateway_url + "/flexbid/state")
            while time.monotonic() < warmup_deadline:
                now_ns = time.time_ns()
                initial = self.state_reader(self.gateway_url + "/flexbid/state")
                self.features.update(initial, now_ns)
                time.sleep(min(
                    self.optimizer.parameters.control_period_s,
                    max(0.0, warmup_deadline - time.monotonic()),
                ))
            started_ns = time.time_ns()
            initial_batch = int(initial["completed_batch"])
            with self.log_path.open("a", encoding="utf-8") as stream:
                while True:
                    iteration_ns = time.time_ns()
                    elapsed_s = max(0.0, (iteration_ns - started_ns) / 1e9)
                    if elapsed_s >= self.deadline_s:
                        break
                    gateway = self.state_reader(
                        self.gateway_url + "/flexbid/state"
                    )
                    completed_batch = max(
                        0, int(gateway["completed_batch"]) - initial_batch
                    )
                    actual_batch_tokens = (
                        completed_batch * self.batch_output_tokens
                    )
                    desired_batch_tokens = self.baseline_batch_tps * elapsed_s
                    backlog = max(0.0, desired_batch_tokens - actual_batch_tokens)
                    features = self.features.update(gateway, iteration_ns)
                    observed_power = read_component_power_w(self.gpu_indices)
                    update_model = getattr(self.optimizer.model, "update", None)
                    if (
                        update_model is not None
                        and self.previous_features is not None
                        and elapsed_s > self.previous_elapsed_s
                    ):
                        action = self.actions[self.current_action]
                        model_row = {
                            **self.previous_features,
                            "source": self.source,
                            "online_replicas": action.online_replicas,
                            "batch_concurrency": action.batch_concurrency,
                            "power_cap_w": action.power_cap_w,
                            "name": action.name,
                        }
                        period_s = elapsed_s - self.previous_elapsed_s
                        batch_tps = (
                            max(0, completed_batch - self.previous_completed_batch)
                            * self.batch_output_tokens / period_s
                        )
                        ttfts = [
                            float(row["ttft_ms"])
                            for row in self.features.latest_rows
                            if row.get("ttft_ms") is not None
                        ]
                        tpots = [
                            float(row["mean_gap_ms"])
                            for row in self.features.latest_rows
                            if row.get("mean_gap_ms") is not None
                        ]
                        update_model(
                            model_row,
                            observed_power_w=observed_power,
                            observed_ttft_ms=max(ttfts, default=None),
                            observed_tpot_ms=max(tpots, default=None),
                            observed_batch_tps=batch_tps,
                        )
                    event_remaining = max(0.0, self.event_s - elapsed_s)
                    state = ControlState(
                        source=self.source,
                        event_remaining_s=event_remaining,
                        deadline_remaining_s=max(0.0, self.deadline_s - elapsed_s),
                        backlog_tokens=backlog,
                        current_action=self.current_action,
                        ttft_slo_ms=self.ttft_slo_ms,
                        tpot_slo_ms=self.tpot_slo_ms,
                        workload_features=features,
                        baseline_batch_tps=self.baseline_batch_tps,
                        committed_bid_w=self.committed_bid_w,
                        replica_dwell_remaining_s=max(
                            0.0,
                            self.optimizer.parameters.replica_min_dwell_s
                            - (time.monotonic() - self.last_replica_change_s),
                        ),
                    )
                    plan = self.optimizer.solve(state)
                    bid = self._commit(plan)
                    # Re-solve once with the newly frozen bid so the first
                    # action is guaranteed to satisfy the external commitment.
                    if state.committed_bid_w is None and event_remaining > 0:
                        state = ControlState(
                            **{
                                **asdict(state),
                                "committed_bid_w": bid,
                            }
                        )
                        plan = self.optimizer.solve(state)
                    action = plan.first_action
                    actuation = self._actuate(action, power_manager)
                    observation = RuntimeObservation(
                        iteration_ns,
                        elapsed_s,
                        event_remaining,
                        max(0.0, self.deadline_s - elapsed_s),
                        backlog,
                        int(gateway["completed_online"]),
                        completed_batch,
                        observed_power,
                        features,
                    )
                    record = {
                        "observation": asdict(observation),
                        "committed_bid_w": bid,
                        "plan": plan.as_dict(),
                        "actuation": actuation,
                    }
                    stream.write(json.dumps(record, ensure_ascii=False) + "\n")
                    stream.flush()
                    atomic_json(self.state_path, record)
                    self.previous_features = features
                    self.previous_elapsed_s = elapsed_s
                    self.previous_completed_batch = completed_batch
                    remaining = self.optimizer.parameters.control_period_s - (
                        time.time_ns() - iteration_ns
                    ) / 1e9
                    if remaining > 0:
                        time.sleep(remaining)
        finally:
            baseline = self.actions[self.optimizer.baseline_action]
            try:
                self._actuate(baseline, power_manager)
            finally:
                if power_manager is not None:
                    power_manager.close()
