#!/usr/bin/env python3
"""Dependency-free latency smoke test for the production MPC horizon."""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flexbid_hybrid.modeling import HybridBounds, HybridPrediction
from flexbid_hybrid.mpc import (
    ControlState,
    MPCParameters,
    ViabilityMPC,
    build_action_lattice,
)


class SyntheticEnvelope:
    def predict(self, row: dict) -> HybridPrediction:
        replicas = float(row["online_replicas"])
        concurrency = float(row["batch_concurrency"])
        cap = float(row["power_cap_w"])
        power = 650 + 280 * replicas + 105 * concurrency + 0.6 * replicas * (cap - 300)
        ttft = 450 + 180 * (4 - replicas) + 12 * concurrency
        tpot = 25 + 7 * concurrency + 8 * (4 - replicas)
        batch = 35 * concurrency
        return HybridPrediction(power, ttft, tpot, batch)

    def bounds(self, row: dict, mode: str) -> HybridBounds:
        value = self.predict(row)
        return HybridBounds(
            value.power_mean_w - 20,
            value.power_mean_w + 20,
            value.ttft_p95_ms + 100,
            value.tpot_p99_ms + 5,
            max(0, value.batch_tokens_per_s - 5),
        )


def main() -> None:
    actions = build_action_lattice({
        "online_replicas": [2, 3, 4],
        "batch_concurrency": [0, 1, 2, 4, 5, 6],
        "power_cap_w": [300, 400],
        "baseline": {
            "online_replicas": 4,
            "batch_concurrency": 4,
            "power_cap_w": 400,
        },
    })
    optimizer = ViabilityMPC(
        SyntheticEnvelope(), actions,
        MPCParameters(control_period_s=30, replica_min_dwell_s=120),
    )
    plan = optimizer.solve(ControlState(
        source="mixed",
        event_remaining_s=300,
        deadline_remaining_s=1800,
        backlog_tokens=0,
        current_action="hybrid_full",
        ttft_slo_ms=5000,
        tpot_slo_ms=100,
        baseline_batch_tps=135,
    ))
    print(json.dumps({
        "feasible": plan.feasible,
        "bid_w": plan.committed_bid_w,
        "solve_time_ms": plan.solve_time_ms,
        "horizon_steps": len(plan.steps),
        "input_actions": plan.evaluated_actions,
        "pareto_actions": plan.pareto_actions,
        "first_action": plan.first_action.as_dict(),
        "terminal_backlog_tokens": plan.terminal_backlog_tokens,
    }, indent=2))


if __name__ == "__main__":
    main()
