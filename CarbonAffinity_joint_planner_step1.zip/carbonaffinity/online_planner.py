from __future__ import annotations

import hashlib
import json
import math
import time
from dataclasses import asdict, dataclass
from typing import Any

from .carbon import carbon_grams
from .offline_oracle import (
    ZERO_COST,
    EpochCost,
    OracleEpoch,
    OracleProblem,
    OracleRequest,
    _evaluate_assignment,
)


@dataclass(frozen=True)
class OnlinePlannerSettings:
    horizon_epochs: int = 4
    max_price_iterations: int = 64
    time_budget_ms: float = 20.0
    initial_step_g: float = 0.01
    continuation_mode: str = "trace_horizon"

    def validate(self) -> None:
        if self.horizon_epochs < 0:
            raise ValueError("horizon_epochs must be non-negative")
        if self.max_price_iterations < 1:
            raise ValueError("max_price_iterations must be positive")
        if self.time_budget_ms <= 0.0:
            raise ValueError("time_budget_ms must be positive")
        if self.initial_step_g <= 0.0:
            raise ValueError("initial_step_g must be positive")
        if self.continuation_mode not in {"none", "trace_horizon"}:
            raise ValueError("unknown continuation_mode")


@dataclass(frozen=True)
class OnlinePlannerStep:
    epoch_id: str
    assignments: tuple[tuple[str, str], ...]
    warm_cache_hits: tuple[str, ...]
    cost: EpochCost
    augmented_objective_g: float
    placements_after: tuple[tuple[str, str], ...]
    prices: tuple[tuple[str, float], ...]
    iterations: int
    feasible_candidates: int
    repaired_candidates: int
    planner_time_ms: float
    budget_exhausted: bool


@dataclass(frozen=True)
class OnlinePlannerSolution:
    status: str
    exact: bool
    problem_sha256: str
    settings: OnlinePlannerSettings
    cost: EpochCost
    steps: tuple[OnlinePlannerStep, ...]
    total_planner_time_ms: float
    max_planner_time_ms: float
    budget_exhausted_epochs: int
    total_price_iterations: int

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _migration_edge(problem: OracleProblem, source: str | None, destination: str):
    if source is None or source == destination:
        return None
    return next(
        (
            edge
            for edge in problem.migration_edges
            if edge.source == source and edge.destination == destination
        ),
        None,
    )


def _action_cost(
    problem: OracleProblem,
    epoch: OracleEpoch,
    request: OracleRequest,
    placement: dict[str, str],
    destination: str,
    concurrent: int,
) -> float:
    option = request.option(destination)
    if option is None or not option.in_domain:
        return math.inf
    regions = {region.region_id: region for region in problem.regions}
    region = regions[destination]
    if concurrent < 1 or concurrent > region.capacity:
        return math.inf
    source = placement.get(request.session_id)
    warm = source == destination
    edge = _migration_edge(problem, source, destination)
    migration_delay_ms = edge.delay_ms if edge is not None else 0.0
    ttft_ms = (
        (option.warm_ttft_ms if warm else option.cold_ttft_ms)
        + migration_delay_ms
        + (concurrent - 1) * region.queue_ttft_ms_per_additional_request
        + (concurrent - 1)
        * (
            option.warm_ttft_ms_per_additional_request
            if warm
            else option.cold_ttft_ms_per_additional_request
        )
    )
    tpot_ms = (
        option.tpot_ms
        + (concurrent - 1) * region.tpot_ms_per_additional_request
        + (concurrent - 1)
        * (
            option.warm_tpot_ms_per_additional_request
            if warm
            else option.cold_tpot_ms_per_additional_request
        )
    )
    if ttft_ms > request.ttft_slo_ms or tpot_ms > request.tpot_slo_ms:
        return math.inf
    solo_energy_j = option.warm_energy_j if warm else option.cold_energy_j
    energy_j = solo_energy_j * option.batch_multiplier(
        concurrent, warm, region.batch_multiplier(concurrent)
    )
    carbon = dict(epoch.carbon_lbs_per_mwh)
    value = carbon_grams(energy_j, carbon[destination])
    if edge is not None:
        value += carbon_grams(
            edge.energy_j,
            0.5 * (carbon[source] + carbon[destination]),
        )
    return value


def _continuation_value(
    problem: OracleProblem,
    epoch_index: int,
    request: OracleRequest,
    first_region: str,
    settings: OnlinePlannerSettings,
) -> float:
    if settings.continuation_mode == "none" or settings.horizon_epochs == 0:
        return 0.0
    end = min(len(problem.epochs), epoch_index + 1 + settings.horizon_epochs)
    future = []
    for future_epoch in problem.epochs[epoch_index + 1 : end]:
        match = next(
            (
                item
                for item in future_epoch.requests
                if item.session_id == request.session_id
            ),
            None,
        )
        if match is not None:
            future.append((future_epoch, match))
    if not future:
        return 0.0

    values = {first_region: 0.0}
    region_order = tuple(sorted(region.region_id for region in problem.regions))
    for future_epoch, future_request in future:
        next_values: dict[str, float] = {}
        for source, prefix_cost in values.items():
            placement = {future_request.session_id: source}
            for destination in region_order:
                action = _action_cost(
                    problem,
                    future_epoch,
                    future_request,
                    placement,
                    destination,
                    1,
                )
                if not math.isfinite(action):
                    continue
                candidate = prefix_cost + action
                incumbent = next_values.get(destination)
                if incumbent is None or candidate < incumbent:
                    next_values[destination] = candidate
        if not next_values:
            return math.inf
        values = next_values
    return min(values.values())


def _valid_regions(problem: OracleProblem, request: OracleRequest) -> tuple[str, ...]:
    order = tuple(sorted(region.region_id for region in problem.regions))
    return tuple(
        region
        for region in order
        if (option := request.option(region)) is not None and option.in_domain
    )


def _seed_assignment(
    problem: OracleProblem,
    epoch: OracleEpoch,
    placement: dict[str, str],
    continuation: dict[tuple[str, str], float],
    deadline_ns: int,
) -> tuple[str, ...]:
    capacities = {region.region_id: region.capacity for region in problem.regions}
    counts = {region: 0 for region in capacities}
    assigned: dict[int, str] = {}
    order = sorted(
        range(len(epoch.requests)),
        key=lambda index: (
            len(_valid_regions(problem, epoch.requests[index])),
            epoch.requests[index].request_id,
        ),
    )
    for index in order:
        request = epoch.requests[index]
        choices = []
        for region in _valid_regions(problem, request):
            if counts[region] >= capacities[region]:
                continue
            # Evaluate latency at the region's declared capacity.  Because the
            # latency model is monotone in concurrency, a seed admitted here
            # remains SLO-feasible after the other requests are assigned.
            concurrent = capacities[region]
            immediate = _action_cost(
                problem, epoch, request, placement, region, concurrent
            )
            total = immediate + continuation[(request.request_id, region)]
            if math.isfinite(total):
                choices.append((total, immediate, region))
        if not choices:
            raise RuntimeError(
                f"validated seed has no feasible placement for {request.request_id}"
            )
        region = min(choices)[2]
        assigned[index] = region
        counts[region] += 1
    result = tuple(assigned[index] for index in range(len(epoch.requests)))
    if _evaluate_assignment(problem, epoch, placement, result) is None:
        # A conservative greedy choice may paint itself into a corner. Search
        # only a bounded number of alternatives; never fall back to R**N full
        # enumeration in the latency-sensitive online path.
        best: tuple[float, tuple[str, ...]] | None = None
        search_order = sorted(
            range(len(epoch.requests)),
            key=lambda index: (
                len(_valid_regions(problem, epoch.requests[index])),
                epoch.requests[index].request_id,
            ),
        )
        partial: list[str | None] = [None] * len(epoch.requests)
        search_counts = {region: 0 for region in capacities}
        visited = 0
        max_nodes = 50_000

        def visit(depth: int) -> None:
            nonlocal best, visited
            if visited >= max_nodes or time.perf_counter_ns() >= deadline_ns:
                return
            visited += 1
            if depth == len(search_order):
                candidate = tuple(str(region) for region in partial)
                evaluated = _evaluate_assignment(
                    problem, epoch, placement, candidate
                )
                if evaluated is None:
                    return
                value = evaluated[0].objective_carbon_g + sum(
                    continuation[(request.request_id, region)]
                    for request, region in zip(epoch.requests, candidate)
                )
                key = (value, candidate)
                if best is None or key < best:
                    best = key
                return

            index = search_order[depth]
            request = epoch.requests[index]
            choices = []
            for region in _valid_regions(problem, request):
                if search_counts[region] >= capacities[region]:
                    continue
                action = _action_cost(
                    problem,
                    epoch,
                    request,
                    placement,
                    region,
                    capacities[region],
                )
                total = action + continuation[(request.request_id, region)]
                if math.isfinite(total):
                    choices.append((total, region))
            for _, region in sorted(choices):
                partial[index] = region
                search_counts[region] += 1
                visit(depth + 1)
                search_counts[region] -= 1
                partial[index] = None
                if visited >= max_nodes or time.perf_counter_ns() >= deadline_ns:
                    break

        visit(0)
        if best is None:
            raise RuntimeError(
                f"epoch {epoch.epoch_id} has no feasible seed within "
                f"{max_nodes} bounded search nodes"
            )
        result = best[1]
    return result


def _repair_capacity(
    problem: OracleProblem,
    epoch: OracleEpoch,
    placement: dict[str, str],
    proposed: tuple[str, ...],
    continuation: dict[tuple[str, str], float],
) -> tuple[tuple[str, ...], int] | None:
    capacities = {region.region_id: region.capacity for region in problem.regions}
    assignment = list(proposed)
    repairs = 0
    while True:
        counts = {region: assignment.count(region) for region in capacities}
        overloaded = [region for region in sorted(counts) if counts[region] > capacities[region]]
        if not overloaded:
            break
        source = overloaded[0]
        moves = []
        for index, current in enumerate(assignment):
            if current != source:
                continue
            request = epoch.requests[index]
            source_cost = _action_cost(
                problem, epoch, request, placement, source, counts[source]
            ) + continuation[(request.request_id, source)]
            for destination in _valid_regions(problem, request):
                if destination == source or counts[destination] >= capacities[destination]:
                    continue
                destination_cost = _action_cost(
                    problem,
                    epoch,
                    request,
                    placement,
                    destination,
                    counts[destination] + 1,
                ) + continuation[(request.request_id, destination)]
                if math.isfinite(destination_cost):
                    moves.append(
                        (
                            destination_cost - source_cost,
                            request.request_id,
                            destination,
                            index,
                        )
                    )
        if not moves:
            return None
        _, _, destination, index = min(moves)
        assignment[index] = destination
        repairs += 1
    candidate = tuple(assignment)
    if _evaluate_assignment(problem, epoch, placement, candidate) is None:
        return None
    return candidate, repairs


def _augmented_objective(
    problem: OracleProblem,
    epoch: OracleEpoch,
    placement: dict[str, str],
    assignment: tuple[str, ...],
    continuation: dict[tuple[str, str], float],
) -> tuple[float, tuple[EpochCost, tuple[str, ...]]] | None:
    evaluated = _evaluate_assignment(problem, epoch, placement, assignment)
    if evaluated is None:
        return None
    value = evaluated[0].objective_carbon_g + sum(
        continuation[(request.request_id, region)]
        for request, region in zip(epoch.requests, assignment)
    )
    return value, evaluated


def _local_improve(
    problem: OracleProblem,
    epoch: OracleEpoch,
    placement: dict[str, str],
    assignment: tuple[str, ...],
    continuation: dict[tuple[str, str], float],
    deadline_ns: int,
) -> tuple[tuple[str, ...], tuple[EpochCost, tuple[str, ...]], float]:
    current = assignment
    scored = _augmented_objective(
        problem, epoch, placement, current, continuation
    )
    assert scored is not None
    current_value, current_evaluation = scored
    while time.perf_counter_ns() < deadline_ns:
        best = (current_value, current)
        best_evaluation = current_evaluation
        for index, request in enumerate(epoch.requests):
            for destination in _valid_regions(problem, request):
                if destination == current[index]:
                    continue
                candidate_list = list(current)
                candidate_list[index] = destination
                candidate = tuple(candidate_list)
                scored = _augmented_objective(
                    problem, epoch, placement, candidate, continuation
                )
                if scored is None:
                    continue
                value, evaluated = scored
                if (value, candidate) < best:
                    best = (value, candidate)
                    best_evaluation = evaluated
        if best[1] == current:
            break
        current_value, current = best
        current_evaluation = best_evaluation
    return current, current_evaluation, current_value


def _solve_epoch(
    problem: OracleProblem,
    epoch_index: int,
    placement: dict[str, str],
    settings: OnlinePlannerSettings,
) -> OnlinePlannerStep:
    epoch = problem.epochs[epoch_index]
    started = time.perf_counter_ns()
    deadline = started + int(settings.time_budget_ms * 1e6)
    region_order = tuple(sorted(region.region_id for region in problem.regions))
    capacities = {region.region_id: region.capacity for region in problem.regions}
    continuation = {
        (request.request_id, region): _continuation_value(
            problem, epoch_index, request, region, settings
        )
        for request in epoch.requests
        for region in _valid_regions(problem, request)
    }
    seed = _seed_assignment(problem, epoch, placement, continuation, deadline)
    incumbent, incumbent_evaluation, incumbent_augmented = _local_improve(
        problem,
        epoch,
        placement,
        seed,
        continuation,
        deadline,
    )
    prices = {region: 0.0 for region in region_order}
    previous = seed
    feasible_candidates = 1
    repaired_candidates = 0
    iterations = 0

    for iteration in range(settings.max_price_iterations):
        if time.perf_counter_ns() >= deadline:
            break
        previous_counts = {region: previous.count(region) for region in region_order}
        proposal = []
        for request, current in zip(epoch.requests, previous):
            choices = []
            for destination in _valid_regions(problem, request):
                projected = previous_counts[destination] + (destination != current)
                immediate = _action_cost(
                    problem,
                    epoch,
                    request,
                    placement,
                    destination,
                    max(1, projected),
                )
                total = (
                    immediate
                    + continuation[(request.request_id, destination)]
                    + prices[destination]
                )
                if math.isfinite(total):
                    choices.append((total, destination))
            proposal.append(min(choices)[1] if choices else current)
        proposed = tuple(proposal)
        repaired = _repair_capacity(
            problem, epoch, placement, proposed, continuation
        )
        if repaired is not None:
            candidate, repair_count = repaired
            candidate, evaluated, augmented = _local_improve(
                problem,
                epoch,
                placement,
                candidate,
                continuation,
                deadline,
            )
            feasible_candidates += 1
            repaired_candidates += int(repair_count > 0)
            if (augmented, candidate) < (incumbent_augmented, incumbent):
                incumbent = candidate
                incumbent_evaluation = evaluated
                incumbent_augmented = augmented
            previous = candidate
        else:
            previous = proposed

        counts = {region: proposed.count(region) for region in region_order}
        step = settings.initial_step_g / math.sqrt(iteration + 1.0)
        for region in region_order:
            prices[region] = max(
                0.0,
                prices[region] + step * (counts[region] - capacities[region]),
            )
        iterations = iteration + 1

    elapsed_ms = (time.perf_counter_ns() - started) / 1e6
    after = dict(placement)
    for request, destination in zip(epoch.requests, incumbent):
        after[request.session_id] = destination
    return OnlinePlannerStep(
        epoch_id=epoch.epoch_id,
        assignments=tuple(
            (request.request_id, destination)
            for request, destination in zip(epoch.requests, incumbent)
        ),
        warm_cache_hits=incumbent_evaluation[1],
        cost=incumbent_evaluation[0],
        augmented_objective_g=incumbent_augmented,
        placements_after=tuple(sorted(after.items())),
        prices=tuple(sorted(prices.items())),
        iterations=iterations,
        feasible_candidates=feasible_candidates,
        repaired_candidates=repaired_candidates,
        planner_time_ms=elapsed_ms,
        budget_exhausted=elapsed_ms >= settings.time_budget_ms,
    )


def solve_online(
    problem: OracleProblem,
    settings: OnlinePlannerSettings | None = None,
) -> OnlinePlannerSolution:
    settings = settings or OnlinePlannerSettings()
    settings.validate()
    placement = dict(problem.initial_placements)
    steps = []
    total = ZERO_COST
    for epoch_index in range(len(problem.epochs)):
        step = _solve_epoch(problem, epoch_index, placement, settings)
        steps.append(step)
        total = total.plus(step.cost)
        placement = dict(step.placements_after)
    times = [step.planner_time_ms for step in steps]
    digest = hashlib.sha256(problem.canonical_json().encode("utf-8")).hexdigest()
    return OnlinePlannerSolution(
        status="FEASIBLE",
        exact=False,
        problem_sha256=digest,
        settings=settings,
        cost=total,
        steps=tuple(steps),
        total_planner_time_ms=sum(times),
        max_planner_time_ms=max(times, default=0.0),
        budget_exhausted_epochs=sum(step.budget_exhausted for step in steps),
        total_price_iterations=sum(step.iterations for step in steps),
    )


def solution_json(solution: OnlinePlannerSolution) -> str:
    return json.dumps(solution.to_dict(), indent=2)
