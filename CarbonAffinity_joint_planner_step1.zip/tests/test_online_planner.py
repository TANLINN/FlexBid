from __future__ import annotations

import unittest

from carbonaffinity.offline_oracle import OracleProblem, solve_exact
from carbonaffinity.online_planner import OnlinePlannerSettings, solve_online


def option(cold: float, warm: float, ttft: float = 10.0) -> dict:
    return {
        "cold_energy_j": cold,
        "warm_energy_j": warm,
        "cold_ttft_ms": ttft,
        "warm_ttft_ms": ttft,
        "tpot_ms": 10.0,
    }


class OnlinePlannerTests(unittest.TestCase):
    def test_joint_batch_efficiency_beats_independent_cleanest_choices(self) -> None:
        problem = OracleProblem.from_dict(
            {
                "regions": [
                    {
                        "region_id": "a",
                        "capacity": 2,
                        "batch_energy_multipliers": {"1": 1.0, "2": 0.4},
                    },
                    {"region_id": "b", "capacity": 1},
                ],
                "epochs": [
                    {
                        "epoch_id": "0",
                        "carbon_lbs_per_mwh": {"a": 200, "b": 100},
                        "requests": [
                            {
                                "request_id": "x",
                                "session_id": "sx",
                                "ttft_slo_ms": 100,
                                "tpot_slo_ms": 100,
                                "options": {
                                    "a": option(100, 100),
                                    "b": option(100, 100),
                                },
                            },
                            {
                                "request_id": "y",
                                "session_id": "sy",
                                "ttft_slo_ms": 100,
                                "tpot_slo_ms": 100,
                                "options": {
                                    "a": option(100, 100),
                                    "b": option(100, 100),
                                },
                            },
                        ],
                    }
                ],
            }
        )
        solution = solve_online(
            problem,
            OnlinePlannerSettings(
                horizon_epochs=0,
                max_price_iterations=64,
                time_budget_ms=100,
            ),
        )
        self.assertEqual(dict(solution.steps[0].assignments), {"x": "a", "y": "a"})
        self.assertAlmostEqual(solution.cost.compute_energy_j, 80.0)
        self.assertAlmostEqual(
            solution.cost.objective_carbon_g,
            solve_exact(problem).cost.objective_carbon_g,
        )

    def test_continuation_avoids_terminal_myopia(self) -> None:
        problem = OracleProblem.from_dict(
            {
                "regions": [
                    {"region_id": "a", "capacity": 1},
                    {"region_id": "b", "capacity": 1},
                ],
                "initial_placements": {"s": "a"},
                "epochs": [
                    {
                        "epoch_id": "0",
                        "carbon_lbs_per_mwh": {"a": 400, "b": 150},
                        "requests": [
                            {
                                "request_id": "r0",
                                "session_id": "s",
                                "ttft_slo_ms": 100,
                                "tpot_slo_ms": 100,
                                "options": {
                                    "a": option(100, 100),
                                    "b": option(500, 100),
                                },
                            }
                        ],
                    },
                    {
                        "epoch_id": "1",
                        "carbon_lbs_per_mwh": {"a": 400, "b": 150},
                        "requests": [
                            {
                                "request_id": "r1",
                                "session_id": "s",
                                "ttft_slo_ms": 100,
                                "tpot_slo_ms": 100,
                                "options": {
                                    "a": option(100, 100),
                                    "b": option(500, 100),
                                },
                            }
                        ],
                    },
                    {
                        "epoch_id": "2",
                        "carbon_lbs_per_mwh": {"a": 400, "b": 150},
                        "requests": [
                            {
                                "request_id": "r2",
                                "session_id": "s",
                                "ttft_slo_ms": 100,
                                "tpot_slo_ms": 100,
                                "options": {
                                    "a": option(100, 100),
                                    "b": option(500, 100),
                                },
                            }
                        ],
                    },
                    {
                        "epoch_id": "3",
                        "carbon_lbs_per_mwh": {"a": 400, "b": 150},
                        "requests": [
                            {
                                "request_id": "r3",
                                "session_id": "s",
                                "ttft_slo_ms": 100,
                                "tpot_slo_ms": 100,
                                "options": {
                                    "a": option(100, 100),
                                    "b": option(500, 100),
                                },
                            }
                        ],
                    },
                ],
            }
        )
        myopic = solve_online(
            problem,
            OnlinePlannerSettings(
                horizon_epochs=0,
                max_price_iterations=8,
                time_budget_ms=100,
                continuation_mode="none",
            ),
        )
        horizon = solve_online(
            problem,
            OnlinePlannerSettings(
                horizon_epochs=4,
                max_price_iterations=8,
                time_budget_ms=100,
            ),
        )
        self.assertEqual(dict(myopic.steps[0].assignments)["r0"], "a")
        self.assertEqual(dict(horizon.steps[0].assignments)["r0"], "b")
        self.assertLess(horizon.cost.objective_carbon_g, myopic.cost.objective_carbon_g)

    def test_capacity_and_slo_are_never_violated(self) -> None:
        problem = OracleProblem.from_dict(
            {
                "regions": [
                    {"region_id": "a", "capacity": 1},
                    {"region_id": "b", "capacity": 1},
                ],
                "epochs": [
                    {
                        "epoch_id": "0",
                        "carbon_lbs_per_mwh": {"a": 1, "b": 500},
                        "requests": [
                            {
                                "request_id": request_id,
                                "session_id": session_id,
                                "ttft_slo_ms": 50,
                                "tpot_slo_ms": 50,
                                "options": {
                                    "a": option(10, 10),
                                    "b": option(10, 10),
                                },
                            }
                            for request_id, session_id in (("x", "sx"), ("y", "sy"))
                        ],
                    }
                ],
            }
        )
        solution = solve_online(problem)
        assignments = dict(solution.steps[0].assignments)
        self.assertEqual(set(assignments.values()), {"a", "b"})
        self.assertEqual(solution.status, "FEASIBLE")


if __name__ == "__main__":
    unittest.main()
