from __future__ import annotations

import unittest

from carbonaffinity.offline_oracle import OracleProblem, solve_exact


def option(cold: float, warm: float, ttft: float = 10.0) -> dict:
    return {
        "cold_energy_j": cold,
        "warm_energy_j": warm,
        "cold_ttft_ms": ttft,
        "warm_ttft_ms": ttft,
        "tpot_ms": 10.0,
    }


class OfflineOracleTests(unittest.TestCase):
    def test_horizon_keeps_cached_state_when_cleanest_migration_is_wasteful(self) -> None:
        problem = OracleProblem.from_dict({
            "schema_version": 1,
            "regions": [
                {"region_id": "a", "capacity": 1},
                {"region_id": "b", "capacity": 1},
            ],
            "initial_placements": {"session": "a"},
            "epochs": [
                {
                    "epoch_id": "0",
                    "carbon_lbs_per_mwh": {"a": 400, "b": 100},
                    "requests": [{
                        "request_id": "r0", "session_id": "session",
                        "ttft_slo_ms": 100, "tpot_slo_ms": 100,
                        "options": {"a": option(100, 1), "b": option(100, 1)},
                    }],
                },
                {
                    "epoch_id": "1",
                    "carbon_lbs_per_mwh": {"a": 400, "b": 100},
                    "requests": [{
                        "request_id": "r1", "session_id": "session",
                        "ttft_slo_ms": 100, "tpot_slo_ms": 100,
                        "options": {"a": option(100, 1), "b": option(100, 1)},
                    }],
                },
            ],
        })
        solution = solve_exact(problem)
        self.assertEqual(solution.status, "OPTIMAL")
        self.assertEqual(
            [dict(step.assignments)[f"r{index}"] for index, step in enumerate(solution.steps)],
            ["a", "a"],
        )
        self.assertEqual(solution.cost.migrations, 0)

    def test_joint_capacity_and_batch_curve_couple_assignments(self) -> None:
        problem = OracleProblem.from_dict({
            "regions": [
                {
                    "region_id": "a", "capacity": 2,
                    "batch_energy_multipliers": {"1": 1.0, "2": 0.4},
                },
                {"region_id": "b", "capacity": 1},
            ],
            "epochs": [{
                "epoch_id": "0",
                "carbon_lbs_per_mwh": {"a": 200, "b": 100},
                "requests": [
                    {
                        "request_id": "x", "session_id": "sx",
                        "ttft_slo_ms": 100, "tpot_slo_ms": 100,
                        "options": {"a": option(100, 100), "b": option(100, 100)},
                    },
                    {
                        "request_id": "y", "session_id": "sy",
                        "ttft_slo_ms": 100, "tpot_slo_ms": 100,
                        "options": {"a": option(100, 100), "b": option(100, 100)},
                    },
                ],
            }],
        })
        solution = solve_exact(problem)
        # B is the cleanest, but its capacity is one and A's measured batch
        # efficiency makes jointly assigning both requests to A optimal.
        self.assertEqual(dict(solution.steps[0].assignments), {"x": "a", "y": "a"})
        self.assertAlmostEqual(solution.cost.compute_energy_j, 80.0)

    def test_migration_delay_participates_in_slo_constraint(self) -> None:
        problem = OracleProblem.from_dict({
            "regions": [
                {"region_id": "a", "capacity": 1},
                {"region_id": "b", "capacity": 1},
            ],
            "initial_placements": {"s": "a"},
            "migration": {"a->b": {"energy_j": 0, "delay_ms": 50}},
            "epochs": [{
                "epoch_id": "0",
                "carbon_lbs_per_mwh": {"a": 500, "b": 1},
                "requests": [{
                    "request_id": "r", "session_id": "s",
                    "ttft_slo_ms": 40, "tpot_slo_ms": 100,
                    "options": {"a": option(100, 1, 10), "b": option(100, 1, 10)},
                }],
            }],
        })
        solution = solve_exact(problem)
        self.assertEqual(dict(solution.steps[0].assignments)["r"], "a")

    def test_request_specific_warm_batch_curve_overrides_region_curve(self) -> None:
        warm = option(100, 100)
        warm["warm_batch_energy_multipliers"] = {"1": 1.0, "2": 0.25}
        problem = OracleProblem.from_dict({
            "regions": [
                {"region_id": "a", "capacity": 2},
                {"region_id": "b", "capacity": 2},
            ],
            "initial_placements": {"sx": "a", "sy": "a"},
            "epochs": [{
                "epoch_id": "0",
                "carbon_lbs_per_mwh": {"a": 200, "b": 100},
                "requests": [
                    {"request_id": "x", "session_id": "sx", "ttft_slo_ms": 100,
                     "tpot_slo_ms": 100, "options": {"a": warm, "b": option(100, 100)}},
                    {"request_id": "y", "session_id": "sy", "ttft_slo_ms": 100,
                     "tpot_slo_ms": 100, "options": {"a": warm, "b": option(100, 100)}},
                ],
            }],
        })
        solution = solve_exact(problem)
        self.assertEqual(dict(solution.steps[0].assignments), {"x": "a", "y": "a"})
        self.assertAlmostEqual(solution.cost.compute_energy_j, 50.0)


if __name__ == "__main__":
    unittest.main()
