from __future__ import annotations

import argparse
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Iterable


def quantile(values: Iterable[float], probability: float) -> float | None:
    ordered = sorted(float(value) for value in values if math.isfinite(float(value)))
    if not ordered:
        return None
    position = (len(ordered) - 1) * probability
    left = int(math.floor(position))
    right = int(math.ceil(position))
    if left == right:
        return ordered[left]
    fraction = position - left
    return ordered[left] * (1.0 - fraction) + ordered[right] * fraction


def metrics(rows: list[dict]) -> dict:
    passed = [row for row in rows if row.get("status") == "PASS"]
    gaps = [row["gap_vs_exact_pct"] for row in passed if row.get("gap_vs_exact_pct") is not None]
    times = [row["max_planner_time_ms"] for row in passed]
    exhausted = [row for row in passed if row.get("budget_exhausted_epochs", 0) > 0]
    return {
        "records": len(rows),
        "passed": len(passed),
        "failed": len(rows) - len(passed),
        "exact_comparisons": len(gaps),
        "gap_vs_exact_pct": {
            "median": quantile(gaps, 0.5),
            "q95": quantile(gaps, 0.95),
            "max": max(gaps, default=None),
        },
        "max_planner_time_ms": {
            "median": quantile(times, 0.5),
            "q95": quantile(times, 0.95),
            "max": max(times, default=None),
        },
        "budget_exhaustion_rate": len(exhausted) / len(passed) if passed else None,
        "objective_carbon_g_mean": (
            statistics.fmean(row["objective_carbon_g"] for row in passed)
            if passed
            else None
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    rows = [
        json.loads(line)
        for line in args.input.read_text(encoding="utf-8").splitlines()
        if line.strip() and not json.loads(line).get("case_id", "").endswith("_build")
    ]
    grouped: dict[str, dict[str, list[dict]]] = {
        "continuation_mode": defaultdict(list),
        "regions": defaultdict(list),
        "requests": defaultdict(list),
        "time_budget_ms": defaultdict(list),
    }
    for row in rows:
        for field in grouped:
            grouped[field][str(row[field])].append(row)

    report = {
        "schema_version": 1,
        "overall": metrics(rows),
        "groups": {
            field: {key: metrics(group) for key, group in sorted(values.items())}
            for field, values in grouped.items()
        },
        "interpretation": {
            "none": "deployable myopic joint planner without continuation value",
            "trace_horizon": (
                "controlled upper bound using realized future requests; not a "
                "deployable predictor and not a final-policy result"
            ),
        },
    }
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report["overall"], indent=2))
    print("JOINT_PLANNER_SWEEP_SUMMARY =", args.output.resolve())


if __name__ == "__main__":
    main()
