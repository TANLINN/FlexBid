from __future__ import annotations

import csv
import hashlib
import json
import math
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
SYNTHETIC_START = datetime(2026, 1, 1, tzinfo=timezone.utc)
G_PER_KWH_TO_LB_PER_MWH = 2.2046226218487757
REGION_COLUMNS = (
    "North Scotland",
    "North West England",
    "Yorkshire",
    "South Wales",
    "West Midlands",
    "East England",
    "South England",
    "South East England",
)
REGION_IDS = tuple(f"neso_region_{index:02d}" for index in range(8))
PROFILE_IDS = (
    "local_region_a",
    "local_region_b",
    "high_reuse_a",
    "high_reuse_b",
    "low_reuse_a",
    "low_reuse_b",
    "burst_a",
    "burst_b",
)
RTT_MS = (0.0, 20.0, 40.0, 60.0, 80.0, 100.0, 120.0, 150.0)
UPLINK_MBPS = (1000.0, 900.0, 750.0, 600.0, 500.0, 400.0, 300.0, 250.0)
DOWNLINK_MBPS = UPLINK_MBPS
ENERGY_KWH_PER_GB = (0.005, 0.0075, 0.010, 0.0125, 0.015, 0.020, 0.025, 0.030)
REQUEST_BASE_BYTES = 117.99112248808474
PROMPT_BYTES_PER_TOKEN = 5.46149935470945
RESPONSE_BASE_BYTES = 251.5713600642271
OUTPUT_BYTES_PER_TOKEN = 260.1726561349959
FIRST_RESPONSE_BYTES = 262.1
REPETITIONS = 5


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def finite_sample_quantile(values: list[float], coverage: float) -> float:
    ordered = sorted(values)
    if not ordered:
        raise ValueError("cannot calibrate an empty residual set")
    rank = min(len(ordered) - 1, math.ceil((len(ordered) + 1) * coverage) - 1)
    return ordered[max(0, rank)]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_source() -> tuple[list[datetime], dict[datetime, dict[str, float]]]:
    path = ROOT / "data/raw/regional_carbon_intensity.csv"
    values: dict[datetime, dict[str, float]] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = set(REGION_COLUMNS) - set(reader.fieldnames or ())
        if missing:
            raise RuntimeError(f"NESO source misses columns: {sorted(missing)}")
        for row in reader:
            try:
                timestamp = parse_time(str(row["datetime"]) + "Z")
                values[timestamp] = {
                    column: float(row[column]) for column in REGION_COLUMNS
                }
            except (KeyError, TypeError, ValueError):
                continue
    timestamps = sorted(values)
    if len(timestamps) < 3:
        raise RuntimeError("too few usable NESO rows")
    return timestamps, values


def window_starts() -> list[datetime]:
    manifest = json.loads(
        (ROOT / "results/real_data_preparation_manifest.json").read_text()
    )
    starts = [parse_time(row["source_start_utc"]) for row in manifest["windows"]]
    if len(starts) != 4:
        raise RuntimeError(f"expected four development windows, found {len(starts)}")
    return starts


def build_carbon_rows(
    timestamps: list[datetime],
    values: dict[datetime, dict[str, float]],
    start: datetime,
) -> tuple[list[dict], float]:
    previous = {
        timestamps[index]: values[timestamps[index - 1]]
        for index in range(1, len(timestamps))
    }
    residuals = []
    for timestamp in timestamps:
        if not start - timedelta(days=7) <= timestamp < start:
            continue
        if timestamp not in previous:
            continue
        residuals.append(
            max(
                abs(values[timestamp][column] - previous[timestamp][column])
                for column in REGION_COLUMNS
            )
            * G_PER_KWH_TO_LB_PER_MWH
        )
    q95 = finite_sample_quantile(residuals, 0.95)

    # 60 source hours become 7200 replay seconds under the frozen 30x clock.
    end = start + timedelta(hours=60)
    output: list[dict] = []
    for timestamp in timestamps:
        if not start <= timestamp <= end or timestamp not in previous:
            continue
        synthetic = SYNTHETIC_START + (timestamp - start) / 30.0
        for region_id, column in zip(REGION_IDS, REGION_COLUMNS):
            output.append(
                {
                    "timestamp": synthetic.isoformat().replace("+00:00", "Z"),
                    "region_id": region_id,
                    "forecast_lbs_per_mwh": previous[timestamp][column]
                    * G_PER_KWH_TO_LB_PER_MWH,
                    "historical_lbs_per_mwh": values[timestamp][column]
                    * G_PER_KWH_TO_LB_PER_MWH,
                }
            )
    if len(output) < 16:
        raise RuntimeError(f"insufficient carbon coverage for {start.isoformat()}")
    return output, q95


def region_config(logical_index: int, repetition: int) -> dict:
    gpu = (logical_index + repetition) % 8
    profile_id = PROFILE_IDS[gpu]
    return {
        "id": REGION_IDS[logical_index],
        "api_base": f"http://127.0.0.1:{18000 + gpu}/v1",
        "control_base": "http://127.0.0.1:1",
        "api_key": "EMPTY",
        "model": "Qwen3.5-27B",
        "profile": f"profiles/{profile_id}.json",
        "site_manifest": f"manifests/{profile_id}.json",
        "gpu_count": 1,
        "tensor_parallel_size": 1,
        "admission_concurrency": 8,
        "rtt_ms": RTT_MS[logical_index],
        "network": {
            "enabled": True,
            "inject_delay": True,
            "rtt_ms": RTT_MS[logical_index],
            "uplink_mbps": UPLINK_MBPS[logical_index],
            "downlink_mbps": DOWNLINK_MBPS[logical_index],
            "request_base_bytes": REQUEST_BASE_BYTES,
            "prompt_bytes_per_token": PROMPT_BYTES_PER_TOKEN,
            "response_base_bytes": RESPONSE_BASE_BYTES,
            "output_bytes_per_token": OUTPUT_BYTES_PER_TOKEN,
            "first_response_bytes": FIRST_RESPONSE_BYTES,
            "energy_kwh_per_gb": ENERGY_KWH_PER_GB[logical_index],
            "carbon_g_per_kwh": 400.0,
        },
    }


def main() -> None:
    output_root = ROOT / "results/eight_region_development_inputs"
    output_root.mkdir(parents=True, exist_ok=True)
    (ROOT / "configs").mkdir(parents=True, exist_ok=True)
    (ROOT / "data/carbon").mkdir(parents=True, exist_ok=True)
    timestamps, values = load_source()
    starts = window_starts()
    records = []

    for window, start in enumerate(starts):
        carbon_rows, q95 = build_carbon_rows(timestamps, values, start)
        carbon_path = ROOT / f"data/carbon/neso_eight_region_dev_{window:02d}.csv"
        with carbon_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=(
                    "timestamp",
                    "region_id",
                    "forecast_lbs_per_mwh",
                    "historical_lbs_per_mwh",
                ),
            )
            writer.writeheader()
            writer.writerows(carbon_rows)

        base_path = ROOT / f"configs/real_window_{window:02d}.generated.yaml"
        base = yaml.safe_load(base_path.read_text())
        for repetition in range(REPETITIONS):
            config = deepcopy(base)
            config["experiment"]["name"] = (
                f"eight_region_development_window_{window:02d}_rep_{repetition:02d}"
            )
            config["experiment"]["mode"] = "same_host_eight_region_hardware_in_loop"
            config["regions"] = [
                region_config(index, repetition) for index in range(8)
            ]
            config["carbon"] = {
                "trace": carbon_path.relative_to(ROOT).as_posix(),
                "clock_mode": "trace_relative",
                "trace_start_timestamp": SYNTHETIC_START.isoformat().replace(
                    "+00:00", "Z"
                ),
                "max_age_s": 180,
            }
            config["routing"]["carbon_error_quantile_lbs_per_mwh"] = q95
            # q95 is the maximum residual across all eight regions at a time.
            # Use the conservative generic pairwise conversion in RouterPolicy.
            config["routing"]["carbon_common_error_quantile_lbs_per_mwh"] = 0.0
            config["routing"]["carbon_diff_error_quantile_lbs_per_mwh"] = 0.0
            config["artifact_metadata"] = {
                "evaluation_role": "development_multiregion_scaling",
                "same_host_only": True,
                "region_emulation": "eight real A800 endpoints; synthetic WAN",
                "carbon_source": "eight simultaneous NESO regional series",
                "region_columns": list(REGION_COLUMNS),
                "forecast_method": "30-minute persistence",
                "carbon_risk": "q95 maximum absolute residual across eight regions",
                "gpu_rotation": repetition,
                "rtt_ms": list(RTT_MS),
                "kv_transfer_bytes": 0,
            }
            config_path = ROOT / (
                f"configs/eight_region_dev_w{window:02d}_r{repetition:02d}.generated.yaml"
            )
            config_path.write_text(
                yaml.safe_dump(config, sort_keys=False), encoding="utf-8"
            )
            mapping = [(index + repetition) % 8 for index in range(8)]
            records.append(
                {
                    "window": window,
                    "repetition": repetition,
                    "source_start_utc": start.isoformat(),
                    "config": config_path.relative_to(ROOT).as_posix(),
                    "config_sha256": sha256(config_path),
                    "carbon": carbon_path.relative_to(ROOT).as_posix(),
                    "carbon_sha256": sha256(carbon_path),
                    "logical_region_to_gpu": mapping,
                    "carbon_q95_lbs_per_mwh": q95,
                }
            )

    manifest = {
        "schema_version": 1,
        "status": "FROZEN_BEFORE_GPU_EXECUTION",
        "purpose": "eight-region development scaling experiment",
        "regions": [
            {"id": region_id, "source_column": column}
            for region_id, column in zip(REGION_IDS, REGION_COLUMNS)
        ],
        "network": {
            "rtt_ms": list(RTT_MS),
            "uplink_mbps": list(UPLINK_MBPS),
            "downlink_mbps": list(DOWNLINK_MBPS),
            "energy_kwh_per_gb": list(ENERGY_KWH_PER_GB),
            "byte_model": {
                "request_base_bytes": REQUEST_BASE_BYTES,
                "prompt_bytes_per_token": PROMPT_BYTES_PER_TOKEN,
                "response_base_bytes": RESPONSE_BASE_BYTES,
                "output_bytes_per_token": OUTPUT_BYTES_PER_TOKEN,
                "first_response_bytes": FIRST_RESPONSE_BYTES,
            },
        },
        "policies": [
            "pressure_only",
            "cleanest_now",
            "sticky",
            "carbon_affinity",
        ],
        "repetitions": REPETITIONS,
        "records": records,
    }
    manifest_path = output_root / "FROZEN_INPUT_MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (output_root / "FROZEN_INPUT_MANIFEST.sha256").write_text(
        f"{sha256(manifest_path)}  {manifest_path.relative_to(ROOT).as_posix()}\n",
        encoding="utf-8",
    )
    print("regions =", len(REGION_IDS))
    print("windows =", len(starts))
    print("repetitions =", REPETITIONS)
    print("configs =", len(records))
    print("manifest_sha256 =", sha256(manifest_path))
    print("EIGHT_REGION_DEVELOPMENT_INPUTS_FROZEN")


if __name__ == "__main__":
    main()
