from __future__ import annotations

import argparse
import json
from pathlib import Path

from carbonaffinity.offline_oracle import OracleProblem, solve_exact


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Solve a small frozen multi-region routing instance exactly. "
            "This is a validation oracle, not the production scheduler."
        )
    )
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--max-states", type=int, default=250_000)
    args = parser.parse_args()

    problem = OracleProblem.from_json(args.input)
    solution = solve_exact(problem, max_states=args.max_states)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(solution.to_dict(), indent=2), encoding="utf-8"
    )

    print("status =", solution.status)
    print("exact =", solution.exact)
    print("objective_carbon_g =", f"{solution.cost.objective_carbon_g:.9f}")
    print("compute_carbon_g =", f"{solution.cost.compute_carbon_g:.9f}")
    print("migration_carbon_g =", f"{solution.cost.migration_carbon_g:.9f}")
    print("migrations =", solution.cost.migrations)
    print("explored_transitions =", solution.explored_transitions)
    print("frontier_sizes =", list(solution.frontier_sizes))
    print("problem_sha256 =", solution.problem_sha256)
    print("OFFLINE_ORACLE_COMPLETE =", args.output.resolve())


if __name__ == "__main__":
    main()
