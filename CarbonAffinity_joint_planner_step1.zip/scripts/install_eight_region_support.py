from __future__ import annotations

import json
import py_compile
import shutil
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "carbonaffinity/config.py"
MARKER = ROOT / "results/EIGHT_REGION_SUPPORT_INSTALL_COMPLETE.json"


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one target, found {count}")
    return text.replace(old, new, 1)


def main() -> None:
    original = CONFIG.read_text(encoding="utf-8")
    if "an experiment requires between two and eight regions" in original:
        print("EIGHT_REGION_CONFIG_VALIDATION_ALREADY_INSTALLED")
        return

    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    backup_root = ROOT / f"results/eight_region_support_backup_{stamp}"
    backup_root.mkdir(parents=True, exist_ok=False)
    backup = backup_root / "config.py"
    shutil.copy2(CONFIG, backup)

    try:
        patched = replace_once(
            original,
            '    if len(regions) != 2:\n'
            '        raise ValueError("the main experiment requires exactly two physical regions")\n',
            '    if not 2 <= len(regions) <= 8:\n'
            '        raise ValueError("an experiment requires between two and eight regions")\n',
            "region-count validation",
        )
        patched = replace_once(
            patched,
            '    if len(set(ids)) != 2 or any(not item for item in ids):\n',
            '    if len(set(ids)) != len(ids) or any(not item for item in ids):\n',
            "unique-region validation",
        )
        patched = replace_once(
            patched,
            '        raise ValueError("both regions must declare the same model")\n',
            '        raise ValueError("all regions must declare the same model")\n',
            "model validation wording",
        )
        CONFIG.write_text(patched, encoding="utf-8")
        py_compile.compile(str(CONFIG), doraise=True)

        from carbonaffinity.config import validate_config

        validate_config(
            {
                "regions": [
                    {
                        "id": f"r{index}",
                        "api_base": f"http://127.0.0.1:{18000 + index}/v1",
                        "control_base": "http://127.0.0.1:1",
                        "profile": f"profiles/r{index}.json",
                        "site_manifest": f"manifests/r{index}.json",
                        "model": "Qwen3.5-27B",
                        "gpu_count": 1,
                        "tensor_parallel_size": 1,
                    }
                    for index in range(8)
                ],
                "routing": {"policy": "carbon_affinity"},
            }
        )
    except Exception:
        shutil.copy2(backup, CONFIG)
        raise

    MARKER.parent.mkdir(parents=True, exist_ok=True)
    MARKER.write_text(
        json.dumps(
            {
                "status": "COMPLETE",
                "installed_utc": stamp,
                "backup": str(backup_root.resolve()),
                "region_range": [2, 8],
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print("EIGHT_REGION_SUPPORT_INSTALL_PASS")
    print("BACKUP =", backup_root.resolve())


if __name__ == "__main__":
    main()
