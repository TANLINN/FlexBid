#!/usr/bin/env bash
set -uo pipefail

cd /root/CarbonAffinity || exit 2
source .venv/bin/activate || exit 2

OUTPUT_ROOT="${1:?usage: run_gpu_profile_drift_campaign.sh OUTPUT_ROOT [ROUNDS]}"
ROUNDS="${2:-4}"
MODEL="Qwen3.5-27B"
TOKENIZER="/root/models/Qwen3.5-27B"
REGIONS=(
  local_region_a local_region_b
  high_reuse_a high_reuse_b
  low_reuse_a low_reuse_b
  burst_a burst_b
)

mkdir -p "$OUTPUT_ROOT"
printf '%s\n' "$$" > "$OUTPUT_ROOT/launcher.pid"

if [[ ! -d "$TOKENIZER" ]]; then
  echo "TOKENIZER_NOT_FOUND=$TOKENIZER" | tee "$OUTPUT_ROOT/FATAL"
  exit 2
fi

if pgrep -af \
  'run_local_pair_campaign.py|run_real_campaign.py|measure_batch_energy.py' \
  | grep -v "run_gpu_profile_drift_campaign.sh" \
  > "$OUTPUT_ROOT/conflicting_processes.txt"
then
  echo "CONFLICTING_EXPERIMENT_PROCESS; refusing to overlap" \
    | tee "$OUTPUT_ROOT/FATAL"
  cat "$OUTPUT_ROOT/conflicting_processes.txt"
  exit 3
fi

if ps -eo args= | grep -E \
  '[n]ight_guard.sh|[e]mergency_.*retention' \
  > "$OUTPUT_ROOT/conflicting_retention.txt"
then
  echo "RETENTION_PROCESS_ACTIVE; stop it before calibration" \
    | tee "$OUTPUT_ROOT/FATAL"
  cat "$OUTPUT_ROOT/conflicting_retention.txt"
  exit 3
fi

failures=0
for round in $(seq 0 $((ROUNDS - 1))); do
  ROUND_ROOT="$OUTPUT_ROOT/round_$(printf '%02d' "$round")"
  mkdir -p "$ROUND_ROOT"
  echo "$(date -Is) ROUND_START=$round" | tee -a "$OUTPUT_ROOT/events.log"
  pids=()

  for gpu in $(seq 0 7); do
    region="${REGIONS[$gpu]}"
    output="$ROUND_ROOT/gpu_${gpu}.jsonl"
    marker="$ROUND_ROOT/gpu_${gpu}.complete"
    if [[ -f "$marker" ]]; then
      pids[$gpu]=""
      continue
    fi
    rm -f "$ROUND_ROOT/gpu_${gpu}.failed"

    .venv/bin/python -u scripts/measure_batch_energy.py \
      --region-id "$region" \
      --api-base "http://127.0.0.1:$((18000 + gpu))/v1" \
      --model "$MODEL" \
      --tokenizer "$TOKENIZER" \
      --gpu-index "$gpu" \
      --prompt-tokens 2048 8192 16384 32768 \
      --output-tokens 32 128 512 \
      --concurrency 1 2 4 8 \
      --repeats 2 \
      --settle-s 1.0 \
      --timeout-s 900 \
      --output "$output" \
      --resume \
      > "$ROUND_ROOT/gpu_${gpu}.log" 2>&1 &
    pids[$gpu]="$!"
  done

  for gpu in $(seq 0 7); do
    pid="${pids[$gpu]:-}"
    [[ -n "$pid" ]] || continue
    if wait "$pid"; then
      rm -f "$ROUND_ROOT/gpu_${gpu}.failed"
      touch "$ROUND_ROOT/gpu_${gpu}.complete"
    else
      rc="$?"
      echo "$rc" > "$ROUND_ROOT/gpu_${gpu}.failed"
      failures=$((failures + 1))
    fi
  done

  complete="$(find "$ROUND_ROOT" -name 'gpu_*.complete' -type f | wc -l)"
  failed="$(find "$ROUND_ROOT" -name 'gpu_*.failed' -type f | wc -l)"
  rows="$(find "$ROUND_ROOT" -name 'gpu_*.jsonl' -type f -exec cat {} + 2>/dev/null | wc -l)"
  echo "$(date -Is) ROUND_FINISH=$round complete=$complete failed=$failed rows=$rows" \
    | tee -a "$OUTPUT_ROOT/events.log"

  if [[ "$round" -lt $((ROUNDS - 1)) ]]; then
    sleep 600
  fi
done

if [[ "$failures" -eq 0 ]]; then
  printf '{"status":"COMPLETE","rounds":%s,"completed_s":%s}\n' \
    "$ROUNDS" "$(date +%s)" > "$OUTPUT_ROOT/CAMPAIGN_COMPLETE.json"
  echo "GPU_PROFILE_DRIFT_CAMPAIGN_COMPLETE=$OUTPUT_ROOT"
else
  printf '{"status":"PARTIAL","rounds":%s,"failures":%s,"completed_s":%s}\n' \
    "$ROUNDS" "$failures" "$(date +%s)" \
    > "$OUTPUT_ROOT/CAMPAIGN_PARTIAL.json"
  echo "GPU_PROFILE_DRIFT_CAMPAIGN_PARTIAL=$OUTPUT_ROOT failures=$failures"
  exit 1
fi
