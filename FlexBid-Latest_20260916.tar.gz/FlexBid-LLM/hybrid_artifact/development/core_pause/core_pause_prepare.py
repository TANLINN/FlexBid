"""Prepare saved-source pause measurements without starting services."""
import ast
import json
from pathlib import Path
import shutil
import sys
from core_pause_sources import runner_source, reporter_source, BOUNDARY_REPORT
from core_pause_campaign import plan


def prepare(source, output):
    template = output / 'cell_template'
    template.mkdir()
    # Campaign-level reporting helpers and cell-level execution helpers are both required.
    for parent in (source.parent.parent, source):
        for path in parent.glob('*.py'):
            shutil.copyfile(path, template / path.name)
    for name in ('run_core_boundary_cell.py', 'core_recovery_cell_report.py',
                 'cohort_phase_measurement.py', 'core_boundary_report.py',
                 'conversation_quartile_power.py', 'core_serial_startup.py'):
        if not (template/name).is_file(): raise FileNotFoundError(template/name)
    p = template/'run_core_boundary_cell.py'
    p.write_text(runner_source(p.read_text()), encoding='utf-8')
    p = template/'core_recovery_cell_report.py'
    p.write_text(reporter_source(p.read_text()), encoding='utf-8')
    (template/'core_boundary_cell_report.py').write_text(BOUNDARY_REPORT, encoding='utf-8')
    for path in template.glob('*.py'): ast.parse(path.read_text(encoding='utf-8'), feature_version=(3,10))
    spec = plan(source)
    (output/'EXPERIMENT_PLAN.json').write_text(json.dumps(spec,indent=2),encoding='utf-8')
    report = dict(status='CORE_PAUSE_PREPARED_CPU_ONLY', source=str(source), output=str(output),
        order=spec['order'], measurement_minutes=195, startup_and_drain_extra=True,
        syntax_pass=True, gpu_workload=False, keepalive_stopped=False, installed=False,
        scope='Saved-source preparation only. Six physical measurements remain unstarted.')
    (output/'REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('=== CORE_PAUSE_PREPARATION ===')
    print(json.dumps(report))


if __name__ == '__main__': prepare(*map(Path,sys.argv[1:]))
