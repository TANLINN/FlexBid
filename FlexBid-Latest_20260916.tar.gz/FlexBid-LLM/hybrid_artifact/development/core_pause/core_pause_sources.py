"""Adapt saved fixed-phase collection to an explicitly selected event C."""
import ast


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError('Expected one source location: ' + old[:100])
    return source.replace(old, new)


def runner_source(source):
    changes = [
        ("enabled = m.read_json(output / 'CONDITION.json')['recovery_queue_priority']",
         "condition = m.read_json(output / 'CONDITION.json')\n    enabled = condition['recovery_queue_priority']\n    event_c = int(condition['event_batch_concurrency'])\n    if event_c not in (0, 5):\n        raise ValueError('Expected event C0 or C5')"),
        ('m.select_recovery_action(actions, event_cap, 5)', 'm.select_recovery_action(actions, event_cap, event_c)'),
        ("'event_batch_concurrency': 5, 'recovery_batch_concurrency': 6", "'event_batch_concurrency': event_c, 'recovery_batch_concurrency': 6"),
        ("'batch_admission_offset_s': 150., 'event_batch_concurrency': 5,", "'batch_admission_offset_s': 150., 'event_batch_concurrency': event_c,"),
        ('choices=(300., 350.)', 'choices=(300., 400.)'),
        ("'purpose': 'Matched P300/P350 event comparison with saved C5/C6 service policy'",
         "'purpose': 'Fixed-event admission pause and recovery feasibility comparison'"),
    ]
    for old, new in changes: source = replace_once(source, old, new)
    ast.parse(source, feature_version=(3, 10))
    return source


def reporter_source(source):
    changes = [
        ("enabled = measure.read_json(output / 'CONDITION.json')['recovery_queue_priority']",
         "condition = measure.read_json(output / 'CONDITION.json')\n    enabled = condition['recovery_queue_priority']\n    event_c = int(condition['event_batch_concurrency'])"),
        ("concurrency['event']['maximum_client_batch_inflight'] <= 5", "concurrency['event']['maximum_client_batch_inflight'] <= event_c"),
        ('batch_limits == [1, 5, 6]', 'batch_limits == [1, max(1, event_c), 6]'),
        ("[r['action']['batch_concurrency'] for r in actions] == [0, 5, 6]", "[r['action']['batch_concurrency'] for r in actions] == [0, event_c, 6]"),
        ("[r['control']['batch_paused'] for r in actions] == [True, False, False]", "[r['control']['batch_paused'] for r in actions] == [True, event_c == 0, False]"),
        ("event_receipt = next(row for row in actions if row['phase'] == 'event')", "admission_phase = 'recovery' if event_c == 0 else 'event'\n    event_receipt = next(row for row in actions if row['phase'] == admission_phase)"),
        ("checks['first_batch_dispatch_after_event_control']", "checks['first_batch_dispatch_after_admission_control']"),
        ("for phase in ('event', 'recovery')))", "for phase in (('recovery',) if event_c == 0 else ('event', 'recovery'))))"),
        ("'Conversation 001918; event C5/P300 and recovery C6/P400, uncached512 and twelve online slots.'", "f'Conversation 001918; event C{event_c}/P{event_cap:g}, recovery C6/P400, uncached512 and twelve online slots.'"),
        ("'Both conditions retain the same service configuration; only the existing recovery online-queue-priority control flag differs.'", "'Service rules remain fixed; event power and batch admission are the specified treatments.'"),
        ("'Batch release remains 150 s; newly released C5/C6 workers wait for the corresponding control receipt. Waiting consumes the original 1950 s deadline.'", "'Batch release remains 150 s. Event C0 delays all batch dispatch until the recovery receipt at 450 s; deadline stays 1950 s.'"),
    ]
    for old, new in changes: source = replace_once(source, old, new)
    ast.parse(source, feature_version=(3, 10))
    return source


BOUNDARY_REPORT = '''"""Report fixed pause/recovery conditions with original service metrics."""
from core_recovery_cell_report import analyze_cell as measured, cell_text as measured_text

def analyze_cell(output, config, source, event_cap):
    import json
    c = json.loads((output / 'CONDITION.json').read_text())['event_batch_concurrency']
    result = measured(output, config, source, event_cap)
    result['status'] = 'CORE_PAUSE_CELL_MEASURED'
    result['condition'] = f'event_p{event_cap:g}_c{c}'
    return result

def cell_text(result):
    return measured_text(result).replace('CORE_RECOVERY_CELL_RESULT', 'CORE_PAUSE_CELL_RESULT')
'''
