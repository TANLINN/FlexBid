"""Six fixed-policy measurements in ABC/CBA order."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys


CONDITIONS = {'A': (400, 5), 'B': (300, 5), 'C': (300, 0)}


def write(path, value):
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')


def plan(source):
    protocol = json.loads((source / 'protocol.json').read_text())
    inputs = Path(protocol['input_root'])
    if json.loads((inputs / 'INPUT_SUMMARY.json').read_text())['episode_id'] != 'azure_conversation:azure-001918':
        raise ValueError('Expected saved 001918 workload')
    order = []
    for repeat, names in enumerate(('ABC', 'CBA'), 1):
        for name in names:
            p, c = CONDITIONS[name]
            order.append(dict(cell_name=f'r{repeat:02d}_{name}_p{p}_c{c}', repeat=repeat,
                condition=name, event_cap_w=p, event_batch_concurrency=c, input_root=str(inputs)))
    return dict(order=order, source_run=str(source), identity='azure_conversation:azure-001918',
        cohort_jobs=280, cohort_release_s=150, event_start_s=150, recovery_start_s=450,
        deadline_s=1950, recovery_p=400, recovery_c=6, measurement_minutes=195,
        startup_and_drain_extra=True, automatic_retry=False,
        hypothesis='C0 may reduce event power and interference while increasing recovery work; neither effect is assumed.',
        readiness='Same saved serial startup, idle/cache/state reset and 150-second online warmup. Warmup failures remain reported.')


def run(project, source, prepared, output):
    sys.path[:0] = [str(project), str(project / 'scripts'), str(prepared), str(prepared / 'cell_template')]
    from flexbid_hybrid.service import stop_process
    from core_pause_report import summarize
    spec = plan(source)
    write(output / 'EXPERIMENT_PLAN.json', spec)
    try:
        for item in spec['order']:
            cell = output / 'cells' / item['cell_name']
            (cell / 'logs').mkdir(parents=True, exist_ok=False)
            for path in (prepared / 'cell_template').glob('*.py'):
                shutil.copyfile(path, cell / path.name)
            write(cell / 'CONDITION.json', dict(recovery_queue_priority=True,
                episode_id=spec['identity'], event_batch_concurrency=item['event_batch_concurrency']))
            cmd = [sys.executable, '-B', '-u', str(cell / 'run_core_boundary_cell.py'),
                '--project', str(project), '--source', str(source), '--input-root', item['input_root'],
                '--output', str(cell), '--event-cap', str(item['event_cap_w'])]
            write(output / 'CURRENT_CELL.json', {**item, 'state': 'STARTING'})
            env = dict(os.environ)
            env['PYTHONPATH'] = str(cell) + os.pathsep + env.get('PYTHONPATH', '')
            with (cell / 'logs/launcher.log').open('w') as log:
                process = subprocess.Popen(cmd, cwd=project, env=env, stdout=log,
                    stderr=subprocess.STDOUT, start_new_session=True)
                write(output / 'CURRENT_CELL.json', {**item, 'state': 'RUNNING', 'pid': process.pid})
                try:
                    code = process.wait()
                finally:
                    if process.poll() is None: stop_process(process, timeout_s=180)
            if code: raise RuntimeError(f'{cell.name} exited with {code}; see {cell}/logs/launcher.log')
            summarize(output, spec, complete=False)
            print('MEASURED=' + cell.name, flush=True)
        summarize(output, spec, complete=True)
        write(output / 'CURRENT_CELL.json', {'state': 'COMPLETE', 'completed_cells': 6})
    except BaseException as exc:
        write(output / 'CAMPAIGN_ERROR.json', dict(error_type=type(exc).__name__, error=str(exc), automatic_retry=False))
        summarize(output, spec, complete=False)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for name in ('project', 'source', 'prepared', 'output'): parser.add_argument('--' + name, required=True, type=Path)
    args = parser.parse_args()
    def interrupted(signum, frame): raise KeyboardInterrupt(f'Signal {signum}')
    signal.signal(signal.SIGINT, interrupted); signal.signal(signal.SIGTERM, interrupted)
    run(args.project.resolve(), args.source.resolve(), args.prepared.resolve(), args.output.resolve())
