"""Produce campaign tables from original per-cell outcome and power records."""
import csv
import filecmp
import json
from pathlib import Path


def summarize(output, spec, complete):
    import yaml
    import cohort_phase_measurement as m
    from core_boundary_report import environment
    from conversation_quartile_power import paired_power_comparison
    indexed = {}; cells = []; table = []
    for item in spec['order']:
        cell = output / 'cells' / item['cell_name']
        path = cell / 'REPORT.json'
        if not path.is_file():
            cells.append(dict(cell=cell.name, measured=False)); continue
        r = json.loads(path.read_text()); indexed[(item['repeat'], item['condition'])] = (cell, r)
        protocol = m.read_json(cell / 'protocol.json'); cutoff = int(protocol['start_wall_ns']) + 450_000_000_000
        batch = m.read_rows(cell / 'batch.jsonl')
        inflight = [dict(job_id=j['job_id'], dispatch_age_s=(cutoff-int(j['dispatch_wall_time_ns']))/1e9)
                    for j in batch if j.get('dispatch_wall_time_ns') is not None
                    and int(j['dispatch_wall_time_ns']) <= cutoff
                    and (j.get('completion_wall_time_ns') is None or int(j['completion_wall_time_ns']) > cutoff)]
        record = dict(cell=cell.name, measured=True, condition=item['condition'], repeat=item['repeat'],
            service_deadline=r['service_and_deadline_pass_observed'], failed_checks=r['failed_checks'],
            batch=r['batch'], timing=r['cohort_timing'], phases=r['phases'],
            gpu_power=r['gpu_power'], recovery_entry_inflight=inflight)
        cells.append(record)
        for phase, values in r['phases'].items():
            stage = r['gpu_power']['stages'].get({'event_time_reference':'event','evaluation':'evaluation'}.get(phase,phase), {})
            table.append(dict(cell=cell.name, repeat=item['repeat'], condition=item['condition'], phase=phase,
                event_p=item['event_cap_w'], event_c=item['event_batch_concurrency'],
                ttft_p95_ms=values['ttft_p95_ms'], gap_p99_ms=values['request_mean_stream_gap_p99_ms'],
                service_safe=values['observed_slo_safe'], on_time=r['batch']['jobs_completed_on_time'],
                late=r['batch']['jobs_completed_late'], unfinished=r['batch']['jobs_unfinished_or_failed'],
                deadline_slack_s=r['cohort_timing']['all_job_completion_slack_s'],
                gpu_energy_wh=stage.get('gpu_energy_wh'), mean_gpu_w=stage.get('mean_gpu_w')))
    comparisons = []
    for repeat in (1, 2):
        for ref, treatment in (('A','B'), ('A','C'), ('B','C')):
            if (repeat, ref) not in indexed or (repeat, treatment) not in indexed: continue
            a, ar = indexed[(repeat, ref)]; b, br = indexed[(repeat, treatment)]
            ea, eb = environment(ar['environment']), environment(br['environment'])
            checks = dict(same_recorded_environment=ea==eb and all(v is not None for v in ea.values()),
                same_inputs=all(filecmp.cmp(a/n,b/n,shallow=False) for n in ('online_workload.jsonl','batch_jobs.jsonl')),
                same_configuration=m.normalized_configuration(yaml.safe_load((a/'config.yaml').read_text()))==m.normalized_configuration(yaml.safe_load((b/'config.yaml').read_text())),
                caps_observed=ar['checks']['configured_gpu_caps_matched'] and br['checks']['configured_gpu_caps_matched'])
            power = paired_power_comparison(a,b)
            comparisons.append(dict(repeat=repeat, reference=ref, treatment=treatment, checks=checks,
                comparison_interpretable=all(checks.values()), power=power))
    report = dict(status='CORE_PAUSE_COMPLETE' if complete else 'CORE_PAUSE_PARTIAL',
        measured_cells=len(indexed), planned_cells=6, cells=cells, comparisons=comparisons,
        scope='001918 development workload, ABC/CBA fixed policies. C0 delays all batch dispatch until recovery; it does not preempt inflight work. Warmup retained. No controller benefit or reliability certification.')
    m.write_json(output/'REPORT.json',report)
    if table:
        with (output/'RESULTS.csv').open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    lines=['=== CORE_PAUSE_RESULT ===','STATUS='+report['status'],f'MEASURED_CELLS={len(indexed)}/6']
    for r in cells:
        if not r['measured']:continue
        lines.append('CELL='+json.dumps({k:v for k,v in r.items() if k not in ('phases','gpu_power')}))
        for name,p in r['phases'].items():
            lines.append('PHASE='+json.dumps(dict(cell=r['cell'],phase=name,ttft95_ms=p['ttft_p95_ms'],gap99_ms=p['request_mean_stream_gap_p99_ms'],safe=p['observed_slo_safe'])))
    for v in comparisons:
        lines.append('COMPARISON='+json.dumps(dict(repeat=v['repeat'],reference=v['reference'],treatment=v['treatment'],checks=v['checks'],stages=v['power']['stages'])))
    lines += [report['scope'],'REPORT_JSON='+str(output/'REPORT.json'),'RESULTS_CSV='+str(output/'RESULTS.csv')]
    (output/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return report
