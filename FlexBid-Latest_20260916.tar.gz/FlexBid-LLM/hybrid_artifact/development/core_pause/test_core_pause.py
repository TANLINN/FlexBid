import asyncio
import json
from pathlib import Path
import tempfile
import time
import unittest
import core_deadline_ablation as a
from core_pause_sources import runner_source, reporter_source
from core_pause_campaign import plan
import cohort_phase_measurement as m


def candidate(name, energy, remaining=0, gap=90, complete=True):
    return dict(name=name, complete_prediction=complete,event_energy_wh=energy,
        full_energy_wh=energy+100,remaining_at_deadline=remaining,
        max_predicted_ttft_ms=1000,max_predicted_gap_ms=gap,switches=2,
        point_constraints_satisfied=complete and remaining==0 and gap<=100)


class AblationTests(unittest.TestCase):
    def test_deadline_only_changes_first_action(self):
        cs=[candidate('recovery_c5',10,3),candidate('recovery_c6',20)]
        self.assertEqual(a.first_action(a.choose(cs))['c'],6)
        self.assertEqual(a.first_action(a.choose(cs,True))['c'],5)

    def test_service_and_support_still_excluded(self):
        cs=[candidate('recovery_c5',1,3,gap=110),candidate('recovery_c6',2,complete=False)]
        self.assertIsNone(a.choose(cs,True))

    def test_future_plan_change_not_first_action(self):
        cs=[candidate('p300_event_c5_recovery_c5',1,4),candidate('p300_event_c5_recovery_c6',2)]
        self.assertNotEqual(a.choose(cs),a.choose(cs,True))
        self.assertEqual(a.first_action(a.choose(cs)),a.first_action(a.choose(cs,True)))

    def test_saved_rank_disagreement_fails(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'protocol.json').write_text('{"start_wall_ns":0}')
            c=candidate('recovery_c6',20)
            row=dict(status='CONTROL_SOLUTION',cutoff_wall_ns=0,solution=dict(candidates=[c],best_point_plan=None,status='POINT_PLAN_SELECTED'))
            (p/'control_decisions.jsonl').write_text(json.dumps(row))
            with self.assertRaisesRegex(ValueError,'ranking'): a.analyze(p,p)


class DispatchTests(unittest.IsolatedAsyncioTestCase):
    async def test_pause_holds_entire_cohort_until_recovery_receipt(self):
        start=time.time_ns(); dispatches=[]; results=[]; acknowledged=False
        protocol=dict(start_wall_ns=start,duration_s=5,drain_s=.1,cohort_release_offset_s=.01,
            batch_admission_offset_s=.01,event_batch_concurrency=0,recovery_start_offset_s=.04)
        async def receipt(index):
            nonlocal acknowledged
            self.assertGreaterEqual(time.time_ns()-start,40_000_000)
            await asyncio.sleep(.02)
            acknowledged=True
            return True
        async def request(row,kind):
            self.assertTrue(acknowledged)
            dispatches.append(row['job_id'])
            await asyncio.sleep(0)
            return dict(completion_tokens=1024)
        await m.execute_requests([], [dict(job_id=i) for i in range(280)],protocol,request,
            lambda k,r: results.append(r),before_batch_phase=receipt)
        self.assertEqual(len(set(dispatches)),280)
        self.assertEqual(len(results),280)

    async def test_pause_does_not_extend_deadline(self):
        protocol=dict(start_wall_ns=time.time_ns(),duration_s=.01,drain_s=.1,cohort_release_offset_s=0,
            batch_admission_offset_s=0,event_batch_concurrency=0,recovery_start_offset_s=.03)
        results=[]
        async def request(*args): self.fail('No dispatch after deadline')
        await m.execute_requests([], [dict(job_id=i) for i in range(280)],protocol,request,lambda k,r:results.append(r))
        self.assertEqual(len(results),280)
        self.assertTrue(all(r['job_status']=='not_started_by_deadline' for r in results))


class PreparationTests(unittest.TestCase):
    def test_saved_source_adaptation(self):
        root=Path(__file__).parent
        runner_source((root/'run_core_boundary_cell.py').read_text())
        reporter_source((root/'core_recovery_cell_report.py').read_text())

    def test_balanced_order_and_original_deadline(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            (p/'protocol.json').write_text(json.dumps(dict(input_root=str(p))))
            (p/'INPUT_SUMMARY.json').write_text(json.dumps(dict(episode_id='azure_conversation:azure-001918')))
            s=plan(p)
            self.assertEqual(''.join(i['condition'] for i in s['order']),'ABCCBA')
            self.assertEqual(s['deadline_s'],1950)
            self.assertEqual(s['cohort_release_s'],150)


if __name__=='__main__': unittest.main()
