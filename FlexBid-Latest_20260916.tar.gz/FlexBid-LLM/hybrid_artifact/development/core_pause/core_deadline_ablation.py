"""Remove only the deadline filter from saved candidate rankings."""
import json
import math
from pathlib import Path
import sys


def finite(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def classify(c):
    required = ('event_energy_wh', 'full_energy_wh', 'remaining_at_deadline',
                'max_predicted_ttft_ms', 'max_predicted_gap_ms', 'switches')
    if not c['complete_prediction'] or not all(finite(c.get(k)) for k in required):
        return ['UNSUPPORTED_OR_INCOMPLETE']
    reasons = []
    if c['max_predicted_ttft_ms'] > 5000: reasons.append('TTFT')
    if c['max_predicted_gap_ms'] > 100: reasons.append('GAP')
    if c['remaining_at_deadline'] != 0: reasons.append('DEADLINE')
    return reasons


def choose(candidates, ignore_deadline=False):
    feasible = [c for c in candidates if not [r for r in classify(c)
                                             if not (ignore_deadline and r == 'DEADLINE')]]
    return min(feasible, key=lambda c: (c['event_energy_wh'], c['full_energy_wh'],
                                       c['switches'], c['name'])) if feasible else None


def first_action(c):
    if c is None: return None
    name = c['name']
    if name.startswith('recovery_c'):
        return {'p': 400, 'c': int(name.split('recovery_c')[1])}
    import re
    match = re.fullmatch(r'p(300|350|400)_event_c(5|6)_recovery_c(5|6)', name)
    if not match: raise ValueError('Unknown saved candidate name: ' + name)
    return {'p': int(match[1]), 'c': int(match[2])}


def analyze(source, out):
    protocol = json.loads((source / 'protocol.json').read_text())
    rows = [json.loads(line) for line in (source / 'control_decisions.jsonl').read_text().splitlines() if line.strip()]
    details = []
    for row in rows:
        if row.get('status') != 'CONTROL_SOLUTION': continue
        sol = row['solution']; cs = sol['candidates']
        if len({c['name'] for c in cs}) != len(cs): raise ValueError('Duplicate candidate')
        for c in cs:
            if bool(c['point_constraints_satisfied']) != (not classify(c)):
                raise ValueError('Saved constraint flag differs: ' + c['name'])
        original, relaxed = choose(cs), choose(cs, True)
        if original != sol['best_point_plan']:
            raise ValueError('Original saved ranking mismatch')
        details.append(dict(at_s=(row['cutoff_wall_ns'] - protocol['start_wall_ns']) / 1e9,
            status=sol['status'], original=original['name'] if original else None,
            without_deadline=relaxed['name'] if relaxed else None,
            original_first=first_action(original), without_deadline_first=first_action(relaxed),
            first_action_changed=first_action(original) != first_action(relaxed),
            plan_changed=original != relaxed,
            deadline_only_excluded=[c['name'] for c in cs if classify(c) == ['DEADLINE']],
            candidate_reasons={c['name']: classify(c) for c in cs}))
    if len(details) != 50:
        raise ValueError(f'Expected the saved 50 decisions, found {len(details)}')
    summary = dict(status='CORE_DEADLINE_ABLATION_COMPLETE', source=str(source), decisions=len(details),
        decisions_with_candidates=sum(bool(d['candidate_reasons']) for d in details),
        deadline_only_exclusions=sum(len(d['deadline_only_excluded']) for d in details),
        origins_with_deadline_only_exclusions=sum(bool(d['deadline_only_excluded']) for d in details),
        changed_plans=sum(d['plan_changed'] for d in details),
        changed_first_actions=sum(d['first_action_changed'] for d in details), original_rank_matches=True,
        scope='Saved point candidates only. Service, support and objective unchanged; no refit or actuation. No C0 candidate or alternative physical trajectory is evaluated.')
    (out / 'REPORT.json').write_text(json.dumps({**summary, 'origins': details}, indent=2), encoding='utf-8')
    lines = ['=== CORE_DEADLINE_ABLATION ===', json.dumps(summary)]
    lines += ['ORIGIN=' + json.dumps(d) for d in details if d['deadline_only_excluded'] or d['plan_changed']]
    lines += ['REPORT_JSON=' + str(out / 'REPORT.json')]
    (out / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))


if __name__ == '__main__': analyze(*map(Path, sys.argv[1:]))
