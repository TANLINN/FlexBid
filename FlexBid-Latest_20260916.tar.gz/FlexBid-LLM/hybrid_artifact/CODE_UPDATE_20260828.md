# Dynamic MPC alignment update (2026-08-28)

This update aligns the implementation with the contract-driven, recovery-aware
design in `paper_submission/main.tex` while preserving legacy static-cell and
dynamic-controller inputs.

Implemented:

- immutable facility-to-domain flexibility contracts;
- separate frozen-cohort work and DR-induced service debt;
- settlement-interval delivery checks;
- absolute recovery envelope, rebound, and ramp constraints in viability DP;
- EMS reference power separated from the controller's internal baseline;
- named online-replica sets with count-based backward compatibility;
- independent frozen-trajectory safety gate and electrical offer margin;
- runtime abstention that leaves the normal action in place;
- power-telemetry readability preflight and per-cell config/action hashes.

The old action-wise conformal model remains available for reproducing earlier
experiments.  Paper-compliant runs should fit a frozen policy without calibration
episodes, run it on a calibration split, create a trajectory calibration artifact
with `scripts/fit_trajectory_calibration.py`, and reference that artifact through
`dynamic_controller.trajectory_calibration`.

Still required before confirmatory GPU experiments:

- collect calibration trajectories containing all configured slack fields;
- add a full event--recovery campaign/evaluator around the dynamic controller;
- add conservative per-request remaining-output and explicit drain-completion
  scenarios to the fitted transition model;
- validate on a second model or parallel layout.

