# Post-backup cumulative code rollup

Baseline archive:

`FlexBid-LLM_project_and_all_results_no_model_20260824_011151.tar.gz`

This rollup supersedes the following post-backup patches, in order:

1. `dynamic_mpc_patch_20260825.tar.gz`
2. `paired_delta_mpc_patch_20260827.tar.gz`
3. `action_normalized_cp_patch_20260827.tar.gz`
4. `flexbid_dynamic_mpc_update_20260828.zip`

Do not apply those archives again after installing this rollup.  Patches and
experiments created before the baseline backup are already present in the
restored project/results and are not repeated here.

Install from the restored `hybrid_artifact` directory with:

```bash
unzip -o /root/flexbid_post_backup_rollup_20260828.zip
python -m compileall -q flexbid_hybrid scripts tests
python -m unittest discover -s tests -v
```

Expected result: 35 tests pass.

