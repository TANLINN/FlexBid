# FlexBid-LLM Hybrid Physical Gate

This directory is an independent successor to `paper_artifact`. It tests whether
hybrid online--batch serving exposes enough *physical* five-minute flexibility to
justify building the full risk-calibrated bidder. It does not overwrite the completed
TP8 campaign.

## What it runs

- Qwen3.5-27B on 8xA800 as four TP2 replicas;
- four held-out online episodes (Azure conversation, Azure code, Qwen API, TraceLab);
- continuously backlogged 8K-input/1K-output batch work;
- seven actions: full/half batch, batch pause, 3/2 active online replicas, and two
  last-mile 300 W cap variants;
- exact 300-second GPU NVML plus available CPU/DRAM RAPL measurement windows.

Expected runtime is roughly 2.5--4 hours after model startup (28 cells).

## Install and launch

The existing `paper_artifact/data/adapted` dataset and Qwen3.5-27B model are reused.

```bash
cd /root/workspace/FlexBid-LLM/hybrid_artifact
python -m pip install -e . --no-deps

mkdir -p results/hybrid_physical_gate_a800_qwen35_27b/logs
nohup bash scripts/launch_pilot.sh \
  > results/hybrid_physical_gate_a800_qwen35_27b/logs/launcher.log 2>&1 &
echo $! > results/hybrid_physical_gate_a800_qwen35_27b/launcher.pid
```

If the model lives elsewhere, edit `model.name` and `model.tokenizer` in the YAML.
If the adapted manifest lives elsewhere, edit `workloads.manifest`.

## Monitor and resume

```bash
bash scripts/monitor.sh
tail -f results/hybrid_physical_gate_a800_qwen35_27b/logs/launcher.log
```

The launcher always uses `--resume`; validated cells are never overwritten. Re-run
the same launch command after a recoverable failure.

Final decision files:

- `PHYSICAL_GATE.json`
- `PHYSICAL_GATE.md`
- `cell_summary.csv`
- `episode_oracle.csv`
- `PIPELINE_COMPLETE`

## Deployable dynamic controller

The physical gate and the former `AdaptiveRecoveryController` are retained as
baselines.  The deployable successor is `flexbid_hybrid.mpc.ViabilityMPC`.  It
does not select a fixed action per trace.  Every control period it:

1. reads live gateway queue, request-shape, latency, batch-progress, and power
   telemetry;
2. anchors a paired-effect surrogate to the measured warm-up baseline, then
   evaluates the profiled joint replica/concurrency/power-cap lattice through
   post-selection episode calibration;
3. plans the demand-response and recovery sequence together, rejecting choices
   that cannot repay accumulated batch debt by the deadline;
4. applies only the first action and re-solves from measured state; and
5. widens the frozen risk envelope when live residuals reveal drift.

The production entry point is:

```bash
python scripts/run_dynamic_controller.py \
  --config configs/a800_8gpu_qwen35_27b_dynamic_mpc.yaml \
  --source qwen_bailian
```

It attaches to an already running FlexBid gateway.  Use `--dry-run` to log plans
without modifying routing or GPU power limits.  Before live deployment, refit the
surrogate with the current code so the model records its explicitly profiled action
support.  Unsupported actuator tuples are never extrapolated into live decisions.

GPU-free planning against a recorded dataset is available through:

```bash
python scripts/simulate_dynamic_mpc.py \
  --config configs/a800_8gpu_qwen35_27b_dynamic_mpc.yaml \
  --dataset results/.../hybrid_test_dataset.csv \
  --output results/dynamic_mpc_simulation.json
```

See `DYNAMIC_MPC_DESIGN.md` for the state, objective, safety invariants, and
deployment boundary.
