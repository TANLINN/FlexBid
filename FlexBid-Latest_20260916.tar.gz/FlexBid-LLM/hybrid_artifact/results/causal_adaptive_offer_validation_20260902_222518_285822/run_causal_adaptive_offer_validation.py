#!/usr/bin/env python3
"""Causal per-event offer validation with a strong reserve action."""

from __future__ import annotations

from collections import Counter
import csv
import fcntl
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

import yaml

ROOT = Path("/root/workspace/FlexBid-LLM/hybrid_artifact").resolve()
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from flexbid_hybrid.analysis import percentile
from flexbid_hybrid.config import load_config
from flexbid_hybrid.io import atomic_json, read_jsonl
from flexbid_hybrid.mpc import build_action_lattice
from flexbid_hybrid.pilot import apply_control
from flexbid_hybrid.power import PowerCapManager
from flexbid_hybrid.runtime_controller import OnlineFeatureEstimator
from flexbid_hybrid.service import ServiceGroup, get_json, stop_process
from install_runtime_safety import active_collectors


WARMUP_S = 120.0
LEAD_S = 30.0
EVENT_S = 300.0
RECOVERY_S = 1500.0
DEADLINE_S = EVENT_S + RECOVERY_S
DURATION_S = WARMUP_S + LEAD_S + DEADLINE_S
SETTLEMENT_S = 30.0
POWER_SAMPLE_S = 0.25
STATE_SAMPLE_S = 1.0
RELAX_HOLD_S = 2.0
EVENT_ACTIONS = ("mpc_r4_c2_p400", "mpc_r4_c1_p400", "mpc_r2_c0_p300")
RECOVERY_ACTIONS = ("hybrid_full", "mpc_r4_c5_p400", "mpc_r4_c6_p400")
EVALUATION_SCALE = 16.0
PROBE_BLOCK_S = 5.0
RESERVE_ACTION = "mpc_r2_c0_p300"
SELECTED_TEST_EPISODES = (
    "qwen_bailian:bailian-000022",
    "qwen_bailian:bailian-000019",
)


class GpuPowerReader:
    def __init__(self, indices):
        import pynvml
        self.nvml = pynvml
        pynvml.nvmlInit()
        self.handles = [pynvml.nvmlDeviceGetHandleByIndex(int(i)) for i in indices]

    def read(self) -> float:
        return sum(self.nvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
                   for handle in self.handles)

    def close(self) -> None:
        self.nvml.nvmlShutdown()


def wait_until(wall_ns: int) -> None:
    while True:
        remaining = (wall_ns - time.time_ns()) / 1e9
        if remaining <= 0:
            return
        time.sleep(min(0.2, max(0.005, remaining / 2)))


def wait_process(process: subprocess.Popen, timeout_s: float) -> int:
    try:
        return process.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        stop_process(process)
        return -9


def one(paths, label):
    values = list(paths)
    if len(values) != 1:
        raise RuntimeError(f"expected one {label}, found {len(values)}")
    return values[0]


def load_profiles() -> dict:
    event_root = Path("/root/workspace/FlexBid-LLM/hybrid_artifact/results/event_action_identification_20260901_233826_209326")
    recovery_root = Path("/root/workspace/FlexBid-LLM/hybrid_artifact/results/recovery_action_identification_20260901_215059_209326")
    event_report = json.loads((event_root / "EVENT_ACTION_REPORT.json").read_text(encoding="utf-8"))
    c2_audit = json.loads((recovery_root / "C2_SETTLEMENT_WINDOW_AUDIT.json").read_text(encoding="utf-8"))
    recovery_report = json.loads((recovery_root / "IDENTIFICATION_REPORT.json").read_text(encoding="utf-8"))
    prior_root = Path("/root/workspace/FlexBid-LLM/hybrid_artifact/results/two_timescale_development_20260902_002712_209326")
    prior_report = json.loads((prior_root / "TWO_TIMESCALE_REPORT.json").read_text(encoding="utf-8"))
    prior_audit = json.loads((prior_root / "TWO_TIMESCALE_FAILURE_AUDIT.json").read_text(encoding="utf-8"))
    development_root = Path("/root/workspace/FlexBid-LLM/hybrid_artifact/results/qwen_test_credit_campaign_20260902_171720_285822")
    development_report = json.loads(
        (development_root / "CROSS_TRACE_REPORT.json").read_text(encoding="utf-8")
    )
    development_failure_audit = json.loads(
        (development_root / "cells/qwen_bailian_bailian-000018/SETTLEMENT_FAILURE_AUDIT.json").read_text(encoding="utf-8")
    )
    strong_root = Path("/root/workspace/FlexBid-LLM/hybrid_artifact/results/strong_event_action_identification_20260902_202629_285822")
    strong_report = json.loads(
        (strong_root / "STRONG_EVENT_ACTION_REPORT.json").read_text(encoding="utf-8")
    )
    exact_path = sorted(ROOT.glob("results/exact_offer_frontier_decomposition_*/REPORT.json"))[-1]
    exact = json.loads(exact_path.read_text(encoding="utf-8"))
    predicted = {item["action"]: item for item in exact["envelopes"]}

    event_profiles = {
        item["event_action"]: {
            "reduction_lower_w": float(item["minimum_30s_reduction_w"]),
            "batch_tps_lower": float(predicted[item["event_action"]]["batch_tps_lower"]),
            "observed_slo_safe": bool(item["observed_slo_safe"]),
            "source": str(event_root / "EVENT_ACTION_REPORT.json"),
        }
        for item in event_report["cells"]
    }
    event_profiles["mpc_r4_c2_p400"] = {
        "reduction_lower_w": float(c2_audit["summary"]["minimum_observed_30s_reduction_w"]),
        "batch_tps_lower": float(predicted["mpc_r4_c2_p400"]["batch_tps_lower"]),
        "observed_slo_safe": True,
        "source": str(recovery_root / "C2_SETTLEMENT_WINDOW_AUDIT.json"),
    }

    recovery_observed = {
        "hybrid_full": next(item for item in recovery_report["cells"] if item["treatment"] == "hybrid_full"),
        "mpc_r4_c5_p400": next(item for item in recovery_report["cells"] if item["treatment"] == "mpc_r4_c5_p400"),
        "mpc_r4_c6_p400": next(item for item in recovery_report["cells"] if item["treatment"] == "mpc_r4_c6_p400"),
    }
    recovery_profiles = {}
    for name in RECOVERY_ACTIONS:
        stable = recovery_observed[name]["intervals"]["recovery_stable"]
        recovery_profiles[name] = {
            "batch_tps_lower": float(predicted[name]["batch_tps_lower"]),
            "observed_ttft_p95_ms": float(stable["ttft_p95_ms"]),
            "observed_tpot_p99_ms": float(stable["tpot_p99_ms"]),
            "observed_slo_safe": bool(stable["observed_slo_safe"]),
            "source": str(recovery_root / "IDENTIFICATION_REPORT.json"),
        }
    return {
        "event": event_profiles,
        "recovery": recovery_profiles,
        "exact_input_baseline_tps": float(exact["input_state"]["baseline_batch_tps"]),
        "prior_dynamic_report": prior_report,
        "prior_dynamic_audit": prior_audit,
        "development_cross_trace_report": development_report,
        "development_failure_audit": development_failure_audit,
        "strong_event_action_report": strong_report,
        "sources": {
            "event_report": str(event_root / "EVENT_ACTION_REPORT.json"),
            "c2_audit": str(recovery_root / "C2_SETTLEMENT_WINDOW_AUDIT.json"),
            "recovery_report": str(recovery_root / "IDENTIFICATION_REPORT.json"),
            "exact_frontier": str(exact_path),
            "prior_dynamic_report": str(prior_root / "TWO_TIMESCALE_REPORT.json"),
            "prior_dynamic_audit": str(prior_root / "TWO_TIMESCALE_FAILURE_AUDIT.json"),
            "development_cross_trace_report": str(development_root / "CROSS_TRACE_REPORT.json"),
            "development_failure_audit": str(
                development_root
                / "cells/qwen_bailian_bailian-000018/SETTLEMENT_FAILURE_AUDIT.json"
            ),
            "strong_event_action_report": str(
                strong_root / "STRONG_EVENT_ACTION_REPORT.json"
            ),
        },
    }


def select_offer_from_probe(
    profiles: dict,
    cohort_tokens: float,
    probe_block_reductions_w: list[float],
    derating: float,
    quantum_w: float,
) -> dict:
    maximum_recovery_tps = max(
        value["batch_tps_lower"] for value in profiles["recovery"].values()
        if value["observed_slo_safe"]
    )
    capacity = maximum_recovery_tps * RECOVERY_S
    if capacity + 1e-7 < cohort_tokens:
        raise RuntimeError("the C0 event reserve and measured-safe recovery cannot finish the cohort")
    if not probe_block_reductions_w:
        raise RuntimeError("the causal reserve probe produced no power blocks")
    probe_floor = min(float(value) for value in probe_block_reductions_w)
    prior_windows = profiles["prior_dynamic_report"]["settlement_windows"]
    audit_windows = profiles["prior_dynamic_audit"]["windows"]
    dynamic_meter_disagreement = max(abs(
        float(report_row["delivered_reduction_w"])
        - float(audit_row["controller_integral_average_w"])
    ) for report_row, audit_row in zip(prior_windows, audit_windows))
    failure_meter_disagreement = float(
        profiles["development_failure_audit"]
        ["maximum_absolute_external_vs_controller_difference_w"]
    )
    meter_disagreement = max(dynamic_meter_disagreement, failure_meter_disagreement)
    offerable_floor = max(0.0, probe_floor - meter_disagreement)
    bid = (math.floor(offerable_floor * derating / quantum_w) * quantum_w
           if quantum_w > 0 else offerable_floor * derating)
    if bid <= 0:
        raise RuntimeError("the causal reserve probe does not support a positive offer")
    return {
        "selection": (
            "minimum causal five-second reserve-probe reduction after the predeclared "
            "ten-second actuation interval, minus the established "
            "settlement reconciliation margin, then derating and quantization"
        ),
        "validation_role": (
            "the offer is computed separately before each held-out event without future event data"
        ),
        "derating": derating,
        "quantum_w": quantum_w,
        "reserve_action": RESERVE_ACTION,
        "probe_block_s": PROBE_BLOCK_S,
        "probe_block_reductions_w": probe_block_reductions_w,
        "probe_minimum_reduction_w": probe_floor,
        "dynamic_run_maximum_meter_disagreement_w": dynamic_meter_disagreement,
        "failed_cell_maximum_meter_disagreement_w": failure_meter_disagreement,
        "maximum_prior_meter_disagreement_w": meter_disagreement,
        "offerable_floor_before_derating_w": offerable_floor,
        "candidate_bid_w": bid,
        "tracking_target_w": bid + meter_disagreement,
        "worst_case_capacity_tokens": capacity,
    }


def online_latency(estimator: OnlineFeatureEstimator, gateway_state: dict, now_ns: int) -> dict:
    estimator.update(gateway_state, now_ns)
    rows = list(estimator.rows)
    ttft = [float(row["ttft_ms"]) for row in rows if row.get("ttft_ms") is not None]
    tpot = [float(row["mean_gap_ms"]) for row in rows if row.get("mean_gap_ms") is not None]
    return {
        "requests": len(rows),
        "ttft_p95_ms": percentile(ttft, .95),
        "tpot_p99_ms": percentile(tpot, .99),
    }


def choose_event_action(
    delivered_ws: float,
    remaining_s: float,
    tracking_target_ws: float,
    c2_floor_w: float,
) -> str:
    # Positive historical action floors did not transfer to the dynamic run.
    # Relax only against energy already delivered. C1 receives zero future
    # credit; C2 must additionally cover its observed negative lower bound.
    if delivered_ws + min(0.0, c2_floor_w) * remaining_s >= tracking_target_ws:
        return "mpc_r4_c2_p400"
    if delivered_ws >= tracking_target_ws:
        return "mpc_r4_c1_p400"
    return RESERVE_ACTION


def choose_recovery_action(
    cohort_remaining: float,
    time_remaining_s: float,
    profiles: dict,
    latency: dict,
    ttft_slo: float,
    tpot_slo: float,
) -> tuple[str, str]:
    current_safe = (
        latency["ttft_p95_ms"] is None or latency["tpot_p99_ms"] is None
        or (latency["ttft_p95_ms"] <= ttft_slo and latency["tpot_p99_ms"] <= tpot_slo)
    )
    if not current_safe:
        return "hybrid_full", "recent online latency exceeded the configured SLO"
    for name in RECOVERY_ACTIONS:
        row = profiles[name]
        if row["observed_slo_safe"] and row["batch_tps_lower"] * time_remaining_s + 1e-7 >= cohort_remaining:
            return name, "lowest measured-safe recovery concurrency that can finish the remaining cohort"
    return "mpc_r4_c6_p400", "maximum measured-safe recovery throughput required"


def interpolate(left, right, target):
    if right[0] == left[0]:
        return left[1]
    ratio = (target - left[0]) / (right[0] - left[0])
    return left[1] + ratio * (right[1] - left[1])


def mean_power(points, start, end):
    points = sorted(points)
    if len(points) < 2 or points[0][0] > start or points[-1][0] < end:
        raise RuntimeError("telemetry does not cover a requested interval")
    bs = max(item for item in points if item[0] <= start)
    a_s = min(item for item in points if item[0] >= start)
    be = max(item for item in points if item[0] <= end)
    ae = min(item for item in points if item[0] >= end)
    values = [(start, interpolate(bs, a_s, start))]
    values += [item for item in points if start < item[0] < end]
    values += [(end, interpolate(be, ae, end))]
    values = sorted(dict(values).items())
    energy = sum((b[0] - a[0]) / 1e9 * (a[1] + b[1]) / 2
                 for a, b in zip(values, values[1:]))
    return energy / ((end - start) / 1e9)


def summarize_online(rows, start, end, ttft_slo, tpot_slo):
    selected = [row for row in rows if start <= int(row["dispatch_wall_time_ns"]) < end]
    good = [row for row in selected if row.get("error") is None]
    ttft = [float(row["ttft_ms"]) for row in good if row.get("ttft_ms") is not None]
    tpot = [float(row["mean_tpot_ms"]) for row in good if row.get("mean_tpot_ms") is not None]
    p95 = percentile(ttft, .95)
    p99 = percentile(tpot, .99)
    return {
        "requests": len(selected),
        "errors": len(selected) - len(good),
        "load_shed": sum(row.get("status_code") == 429 for row in selected),
        "ttft_p95_ms": p95,
        "tpot_p99_ms": p99,
        "observed_slo_safe": (
            bool(selected) and len(selected) == len(good) and p95 is not None and p99 is not None
            and p95 <= ttft_slo and p99 <= tpot_slo
        ),
    }


def run_experiment(
    config: dict,
    services: ServiceGroup,
    power: PowerCapManager,
    output: Path,
    profiles: dict,
    episode: dict,
    scale: float,
) -> dict:
    actions = {item.name: item for item in build_action_lattice(
        config["dynamic_controller"]["action_lattice"]
    )}
    baseline = actions["hybrid_full"]
    control_file = Path(config["hardware"]["control_file"])
    replicas = len(config["model"]["replicas"])
    online_concurrency = int(config["runtime"]["online_concurrency"])
    gateway = f"http://127.0.0.1:{config['runtime']['gateway_port']}"
    state_url = gateway + "/flexbid/state"
    trace = Path(episode["path"])
    baseline_tps = profiles["exact_input_baseline_tps"]
    cohort_tokens = baseline_tps * DEADLINE_S
    dynamic = config["dynamic_controller"]
    c2_floor_w = float(profiles["event"]["mpc_r4_c2_p400"]["reduction_lower_w"])

    services.wait_idle()
    services.reset_caches()
    services.reset_state()
    power.set_all(baseline.power_cap_w)
    apply_control(control_file, baseline, replicas, online_concurrency)
    get_json(state_url)

    start_ns = time.time_ns() + 3_000_000_000
    warmup_end_ns = start_ns + int(WARMUP_S * 1e9)
    activation_ns = warmup_end_ns + int(LEAD_S * 1e9)
    event_end_ns = activation_ns + int(EVENT_S * 1e9)
    deadline_ns = event_end_ns + int(RECOVERY_S * 1e9)
    atomic_json(output / "EXPERIMENT_PROTOCOL.json", {
        "status": "CAUSAL_ADAPTIVE_OFFER_PROTOCOL_STARTED",
        "episode": episode,
        "measurement_start_wall_ns": start_ns,
        "warmup_end_wall_ns": warmup_end_ns,
        "activation_wall_ns": activation_ns,
        "event_end_wall_ns": event_end_ns,
        "deadline_wall_ns": deadline_ns,
        "cohort_tokens": cohort_tokens,
        "event_tracker": {
            "power_sample_s": POWER_SAMPLE_S,
            "state_sample_s": STATE_SAMPLE_S,
            "settlement_s": SETTLEMENT_S,
            "actions_by_service_priority": list(EVENT_ACTIONS),
            "reserve_action": RESERVE_ACTION,
            "c1_future_credit_floor_w": 0.0,
            "c2_future_credit_floor_w": min(0.0, c2_floor_w),
            "selection": "relax only after already delivered energy covers the metering margin and remaining-action floor",
        },
        "recovery_controller": {
            "period_s": SETTLEMENT_S,
            "actions_by_concurrency": list(RECOVERY_ACTIONS),
            "selection": "lowest measured-safe concurrency that can finish actual remaining cohort",
        },
        "profile_sources": profiles["sources"],
        "external_commitment": False,
        "automatic_retry": False,
    })

    model = config["model"]
    base = gateway + "/v1"
    max_batch = max(int(value) for value in dynamic["action_lattice"]["batch_concurrency"])
    online_command = [
        sys.executable, str(ROOT / "scripts/replay_online.py"),
        "--trace", str(trace), "--output", str(output / "online.jsonl"),
        "--api-base", base, "--model", model["name"], "--tokenizer", model["tokenizer"],
        "--arrival-scale", str(scale), "--duration-s", str(DURATION_S),
        "--start-wall-ns", str(start_ns), "--source", str(episode["source"]),
    ]
    batch_command = [
        sys.executable, str(ROOT / "scripts/run_batch.py"),
        "--output", str(output / "batch.jsonl"), "--api-base", base,
        "--model", model["name"], "--tokenizer", model["tokenizer"],
        "--prompt-tokens", str(config["workloads"]["batch_prompt_tokens"]),
        "--output-tokens", str(config["workloads"]["batch_output_tokens"]),
        "--concurrency", str(max_batch), "--duration-s", str(DURATION_S),
        "--start-wall-ns", str(start_ns),
    ]

    handles = []
    processes = {}
    telemetry = None
    reader = None
    control_records = []
    baseline_samples = []
    estimator = OnlineFeatureEstimator(episode["source"], 60.0, 180.0)
    current_action = "hybrid_full"
    last_change_ns = 0

    def actuate(action_name: str) -> dict:
        nonlocal current_action, last_change_ns
        action = actions[action_name]
        enforced = power.set_all(action.power_cap_w)
        applied = apply_control(control_file, action, replicas, online_concurrency)
        current_action = action_name
        last_change_ns = time.time_ns()
        return {"control": applied, "enforced_power_caps_w": enforced}

    try:
        for name in ("telemetry", "online", "batch"):
            stdout = (output / "logs" / f"{name}.stdout.log").open("w", encoding="utf-8")
            stderr = (output / "logs" / f"{name}.stderr.log").open("w", encoding="utf-8")
            handles.extend((stdout, stderr))
            if name == "telemetry":
                telemetry = subprocess.Popen([
                    sys.executable, "-m", "flexbid_hybrid.telemetry",
                    "--output", str(output / "components.csv"),
                    "--interval-ms", str(config["hardware"]["telemetry_interval_ms"]),
                ], cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
            else:
                command = online_command if name == "online" else batch_command
                processes[name] = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr,
                                                    start_new_session=True)

        reader = GpuPowerReader(config["hardware"]["gpu_indices"])
        wait_until(start_ns)
        next_sample_ns = start_ns
        while time.time_ns() < warmup_end_ns:
            wait_until(next_sample_ns)
            now = time.time_ns()
            baseline_samples.append((now, reader.read()))
            estimator.update(get_json(state_url), now)
            next_sample_ns += int(POWER_SAMPLE_S * 1e9)
        cutoff = warmup_end_ns - int(30e9)
        tail = [value for stamp, value in baseline_samples if stamp >= cutoff]
        if len(tail) < 20:
            raise RuntimeError(f"insufficient causal warm-up-tail GPU samples: {len(tail)}")
        reference_w = sum(tail) / len(tail)
        probe_transition = actuate(RESERVE_ACTION)
        probe_samples = []
        next_probe_ns = warmup_end_ns
        next_probe_state_ns = warmup_end_ns
        while time.time_ns() < activation_ns:
            wait_until(min(next_probe_ns, activation_ns))
            now = min(time.time_ns(), activation_ns)
            probe_samples.append((now, reader.read()))
            if now >= next_probe_state_ns:
                estimator.update(get_json(state_url), now)
                while next_probe_state_ns <= now:
                    next_probe_state_ns += int(STATE_SAMPLE_S * 1e9)
            next_probe_ns += int(POWER_SAMPLE_S * 1e9)
        probe_block_reductions = []
        for block in range(int(LEAD_S / PROBE_BLOCK_S)):
            left = warmup_end_ns + int(block * PROBE_BLOCK_S * 1e9)
            right = left + int(PROBE_BLOCK_S * 1e9)
            values = [value for stamp, value in probe_samples if left <= stamp < right]
            if len(values) < 10:
                raise RuntimeError(
                    f"insufficient causal reserve-probe samples in block {block}: {len(values)}"
                )
            probe_block_reductions.append(reference_w - sum(values) / len(values))
        offer = select_offer_from_probe(
            profiles,
            cohort_tokens,
            probe_block_reductions[2:],
            float(dynamic.get("bid_derating", .95)),
            float(dynamic.get("bid_quantum_w", 10.0)),
        )
        bid_w = float(offer["candidate_bid_w"])
        tracking_target_w = float(offer["tracking_target_w"])
        probe_latency = online_latency(estimator, get_json(state_url), activation_ns)
        atomic_json(output / "EXPERIMENT_PLAN.json", {
            "status": "CAUSAL_ADAPTIVE_OFFER_CELL_PLANNED",
            "episode": episode,
            "measurement_start_wall_ns": start_ns,
            "warmup_end_wall_ns": warmup_end_ns,
            "activation_wall_ns": activation_ns,
            "event_end_wall_ns": event_end_ns,
            "deadline_wall_ns": deadline_ns,
            "offer": offer,
            "cohort_tokens": cohort_tokens,
            "event_tracker": {
                "power_sample_s": POWER_SAMPLE_S,
                "state_sample_s": STATE_SAMPLE_S,
                "settlement_s": SETTLEMENT_S,
                "actions_by_service_priority": list(EVENT_ACTIONS),
                "tracking_target_w": tracking_target_w,
                "c1_future_credit_floor_w": 0.0,
                "c2_future_credit_floor_w": min(0.0, c2_floor_w),
                "selection": (
                    "start each settlement window with the measured reserve action; relax only "
                    "after already delivered energy covers the target and remaining-action floor"
                ),
            },
            "recovery_controller": {
                "period_s": SETTLEMENT_S,
                "actions_by_concurrency": list(RECOVERY_ACTIONS),
                "selection": (
                    "lowest measured-safe concurrency that can finish the actual remaining cohort"
                ),
            },
            "profile_sources": profiles["sources"],
            "external_commitment": False,
            "automatic_retry": False,
        })
        atomic_json(output / "CAUSAL_OFFER.json", {
            "reference_gpu_w": reference_w,
            "reference_samples": len(tail),
            "probe_action": RESERVE_ACTION,
            "probe_transition": probe_transition,
            "probe_samples": len(probe_samples),
            "all_probe_block_reductions_w": probe_block_reductions,
            "offer_probe_block_reductions_w": probe_block_reductions[2:],
            "probe_latency": probe_latency,
            "local_causal_bid_w": bid_w,
            "offer_selection": offer,
            "accepted_for_local_measurement": True,
            "external_commitment": False,
        })
        activation_state = get_json(state_url)
        activation_batch = int(activation_state["completed_batch"])

        for window in range(10):
            window_start = activation_ns + int(window * SETTLEMENT_S * 1e9)
            window_end = window_start + int(SETTLEMENT_S * 1e9)
            desired = RESERVE_ACTION
            if current_action != desired:
                actuate(desired)
            previous_ns = max(time.time_ns(), window_start)
            previous_power = reader.read()
            delivered_ws = 0.0
            tracking_target_ws = tracking_target_w * SETTLEMENT_S
            next_tick = previous_ns + int(POWER_SAMPLE_S * 1e9)
            next_state_tick = previous_ns + int(STATE_SAMPLE_S * 1e9)
            while time.time_ns() < window_end:
                wait_until(min(next_tick, window_end))
                now = min(time.time_ns(), window_end)
                power = reader.read()
                dt = max(0.0, (now - previous_ns) / 1e9)
                delivered_ws += (reference_w - (previous_power + power) / 2) * dt
                remaining_s = max(0.0, (window_end - now) / 1e9)
                required = (
                    (tracking_target_ws - delivered_ws) / remaining_s
                    if remaining_s > 1e-6 else math.inf
                )
                desired = choose_event_action(
                    delivered_ws, remaining_s, tracking_target_ws, c2_floor_w
                )
                current_index = EVENT_ACTIONS.index(current_action)
                desired_index = EVENT_ACTIONS.index(desired)
                change = False
                if desired_index > current_index:
                    change = True
                elif desired_index < current_index:
                    held_s = (now - last_change_ns) / 1e9
                    change = held_s >= RELAX_HOLD_S
                if change and remaining_s > 0.5:
                    actuate(desired)
                control_records.append({
                    "phase": "event", "window": window,
                    "wall_time_ns": now, "elapsed_in_window_s": SETTLEMENT_S - remaining_s,
                    "observed_gpu_power_w": power, "delivered_so_far_ws": delivered_ws,
                    "committed_bid_w": bid_w, "tracking_target_w": tracking_target_w,
                    "tracking_credit_ws": delivered_ws - tracking_target_ws,
                    "required_future_reduction_w": required, "action": current_action,
                })
                previous_ns, previous_power = now, power
                if now >= next_state_tick:
                    estimator.update(get_json(state_url), now)
                    while next_state_tick <= now:
                        next_state_tick += int(STATE_SAMPLE_S * 1e9)
                next_tick += int(POWER_SAMPLE_S * 1e9)

        recovery_tick = event_end_ns
        while recovery_tick < deadline_ns:
            wait_until(recovery_tick)
            now = time.time_ns()
            gateway_state = get_json(state_url)
            completed = max(0, int(gateway_state["completed_batch"]) - activation_batch)
            completed_tokens = completed * int(config["workloads"]["batch_output_tokens"])
            remaining = max(0.0, cohort_tokens - completed_tokens)
            time_remaining = max(0.0, (deadline_ns - now) / 1e9)
            latency = online_latency(estimator, gateway_state, now)
            selected, reason = choose_recovery_action(
                remaining, time_remaining, profiles["recovery"], latency,
                float(config["slos"]["default"]["ttft_ms"]),
                float(config["slos"]["default"]["tpot_ms"]),
            )
            if current_action != selected:
                actuate(selected)
            control_records.append({
                "phase": "recovery", "wall_time_ns": now,
                "elapsed_recovery_s": (now - event_end_ns) / 1e9,
                "deadline_remaining_s": time_remaining,
                "completed_batch_tokens_since_activation": completed_tokens,
                "cohort_remaining_tokens": remaining,
                "required_average_tps": remaining / time_remaining if time_remaining > 0 else math.inf,
                "recent_latency": latency, "action": current_action, "reason": reason,
            })
            recovery_tick += int(SETTLEMENT_S * 1e9)
        wait_until(deadline_ns)
        online_rc = wait_process(processes["online"], 1200.0)
        batch_rc = wait_process(processes["batch"], 300.0)
    finally:
        for process in processes.values():
            if process.poll() is None:
                stop_process(process)
        if telemetry is not None:
            stop_process(telemetry)
        if reader is not None:
            reader.close()
        power.set_all(baseline.power_cap_w)
        apply_control(control_file, baseline, replicas, online_concurrency)
        for handle in handles:
            handle.close()
    services.wait_idle()
    with (output / "controller.jsonl").open("w", encoding="utf-8") as stream:
        for row in control_records:
            stream.write(json.dumps(row) + "\n")
    return {
        "reference_gpu_w": reference_w,
        "local_causal_bid_w": bid_w,
        "activation_batch_count": activation_batch,
        "online_return_code": online_rc,
        "batch_return_code": batch_rc,
        "control_records": len(control_records),
    }


def analyze(config: dict, output: Path, run_result: dict, profiles: dict) -> dict:
    plan = json.loads((output / "EXPERIMENT_PLAN.json").read_text(encoding="utf-8"))
    online = read_jsonl(output / "online.jsonl")
    batch = read_jsonl(output / "batch.jsonl")
    controls = read_jsonl(output / "controller.jsonl")
    with (output / "components.csv").open(newline="", encoding="utf-8") as stream:
        telemetry = list(csv.DictReader(stream))
    gpu = [(int(row["wall_time_ns"]), float(row["aggregate_gpu_power_w"]))
           for row in telemetry if row.get("aggregate_gpu_power_w") not in (None, "")]
    activation = int(plan["activation_wall_ns"])
    event_end = int(plan["event_end_wall_ns"])
    deadline = int(plan["deadline_wall_ns"])
    reference = float(run_result["reference_gpu_w"])
    bid = float(run_result["local_causal_bid_w"])
    windows = []
    for index in range(10):
        left = activation + int(index * SETTLEMENT_S * 1e9)
        right = left + int(SETTLEMENT_S * 1e9)
        power = mean_power(gpu, left, right)
        reduction = reference - power
        windows.append({
            "window": index, "gpu_power_w": power, "delivered_reduction_w": reduction,
            "committed_local_bid_w": bid, "passed": reduction + 1e-7 >= bid,
        })
    output_tokens = int(config["workloads"]["batch_output_tokens"])
    batch_selected = [row for row in batch
                      if activation <= int(row["completion_wall_time_ns"]) < deadline
                      and row.get("error") is None]
    completed_tokens = sum(float(row.get("completion_tokens") or 0) for row in batch_selected)
    cohort = float(plan["cohort_tokens"])
    ttft_slo = float(config["slos"]["default"]["ttft_ms"])
    tpot_slo = float(config["slos"]["default"]["tpot_ms"])
    event_online = summarize_online(online, activation, event_end, ttft_slo, tpot_slo)
    recovery_online = summarize_online(online, event_end, deadline, ttft_slo, tpot_slo)
    event_counts = Counter(row["action"] for row in controls if row["phase"] == "event")
    recovery_counts = Counter(row["action"] for row in controls if row["phase"] == "recovery")
    event_sequence = [row["action"] for row in controls if row["phase"] == "event"]
    recovery_sequence = [row["action"] for row in controls if row["phase"] == "recovery"]
    transitions = lambda sequence: sum(a != b for a, b in zip(sequence, sequence[1:]))
    checks = {
        "processes_succeeded": run_result["online_return_code"] == 0 and run_result["batch_return_code"] == 0,
        "all_settlement_windows_delivered": all(item["passed"] for item in windows),
        "event_online_slo_safe": event_online["observed_slo_safe"],
        "recovery_online_slo_safe": recovery_online["observed_slo_safe"],
        "cohort_completed_by_deadline": completed_tokens + 1e-7 >= cohort,
    }
    report = {
        "status": (
            "CAUSAL_ADAPTIVE_OFFER_CELL_COMPLETE"
            if all(checks.values()) else "CAUSAL_ADAPTIVE_OFFER_CELL_MEASURED_WITH_FAILURES"
        ),
        "checks": checks,
        "behavior_observed": {
            "dynamic_event_actions": len(event_counts) >= 2,
            "dynamic_recovery_actions": len(recovery_counts) >= 2,
        },
        "local_causal_bid_w": bid,
        "external_commitment": False,
        "reference_gpu_w": reference,
        "settlement_windows": windows,
        "event_action_sample_counts": dict(event_counts),
        "event_action_transitions": transitions(event_sequence),
        "recovery_tick_action_counts": dict(recovery_counts),
        "recovery_action_transitions": transitions(recovery_sequence),
        "event_online": event_online,
        "recovery_online": recovery_online,
        "batch_tokens_completed_activation_to_deadline": completed_tokens,
        "cohort_tokens": cohort,
        "cohort_deficit_tokens": max(0.0, cohort - completed_tokens),
        "offer_selection": plan["offer"],
        "profile_sources": profiles["sources"],
        "limitations": [
            "This cell is one held-out Qwen trace under the predeclared 16x time dilation.",
            "The bid uses only the causal baseline and reserve probe observed before activation.",
            "The event tracker uses quarter-second power feedback; actuation latency is included but not separately calibrated.",
            "Positive future event-action reductions receive no runtime credit before their energy is measured.",
            "No external offer or delivery claim is made.",
        ],
    }
    atomic_json(output / "CAUSAL_ADAPTIVE_CELL_REPORT.json", report)
    atomic_json(output / "COLLECTION_COMPLETE.json", {"status": report["status"]})
    return report


def selected_test_episodes() -> list[dict]:
    manifest_path = ROOT.parent / "paper_artifact/data/adapted/manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    by_id = {row["episode_id"]: row for row in manifest["episodes"]}
    bins = [(0, 120), (120, 150), (150, 450), (450, 950), (950, 1450), (1450, 1950)]
    selected = []
    for episode_id in SELECTED_TEST_EPISODES:
        row = dict(by_id[episode_id])
        path = Path(row["path"])
        if not path.is_absolute():
            path = (manifest_path.parent / path).resolve()
        values = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
                  if line.strip()]
        arrivals = [float(value["arrival_ms"]) * EVALUATION_SCALE / 1000.0 for value in values]
        counts = [sum(left <= value < right for value in arrivals) for left, right in bins]
        if row.get("source") != "qwen_bailian" or row.get("split") != "test" or not all(counts):
            raise RuntimeError(f"selected test trace does not cover every phase: {episode_id}")
        row.update(
            path=str(path),
            evaluation_arrival_scale=EVALUATION_SCALE,
            requests_within_1950s=sum(value < DURATION_S for value in arrivals),
            phase_request_counts=counts,
        )
        selected.append(row)
    return selected


def aggregate_campaign(output: Path, episodes: list[dict], reports: list[dict]) -> dict:
    rows = []
    for episode, report in zip(episodes, reports):
        reductions = [float(item["delivered_reduction_w"]) for item in report["settlement_windows"]]
        rows.append({
            "episode_id": episode["episode_id"],
            "split": episode["split"],
            "path": episode["path"],
            "requests_within_1950s": episode["requests_within_1950s"],
            "phase_request_counts": episode["phase_request_counts"],
            "status": report["status"],
            "checks": report["checks"],
            "behavior_observed": report["behavior_observed"],
            "causal_bid_w": report["local_causal_bid_w"],
            "probe_minimum_reduction_w": report["offer_selection"]["probe_minimum_reduction_w"],
            "minimum_settlement_reduction_w": min(reductions),
            "settlement_windows_passed": sum(item["passed"] for item in report["settlement_windows"]),
            "event_action_transitions": report["event_action_transitions"],
            "recovery_action_transitions": report["recovery_action_transitions"],
            "event_online": report["event_online"],
            "recovery_online": report["recovery_online"],
            "completed_batch_tokens": report["batch_tokens_completed_activation_to_deadline"],
            "cohort_tokens": report["cohort_tokens"],
        })
    checks = {
        "all_processes_succeeded": all(row["checks"]["processes_succeeded"] for row in rows),
        "all_20_settlement_windows_delivered": all(
            row["checks"]["all_settlement_windows_delivered"] for row in rows
        ),
        "all_event_slos_safe": all(row["checks"]["event_online_slo_safe"] for row in rows),
        "all_recovery_slos_safe": all(row["checks"]["recovery_online_slo_safe"] for row in rows),
        "all_cohorts_completed_by_deadline": all(
            row["checks"]["cohort_completed_by_deadline"] for row in rows
        ),
    }
    report = {
        "status": (
            "CAUSAL_ADAPTIVE_OFFER_VALIDATION_COMPLETE"
            if all(checks.values())
            else "CAUSAL_ADAPTIVE_OFFER_VALIDATION_MEASURED_WITH_FAILURES"
        ),
        "checks": checks,
        "causal_bid_by_episode_w": {
            row["episode_id"]: row["causal_bid_w"] for row in rows
        },
        "evaluation_arrival_scale": EVALUATION_SCALE,
        "selection_rule": (
            "two held-out Qwen traces; each offer is computed independently from that "
            "episode's pre-activation causal reserve probe"
        ),
        "selected_episode_ids": list(SELECTED_TEST_EPISODES),
        "cells": rows,
        "external_commitment": False,
        "limitations": [
            "Two held-out traces provide validation evidence, not a statistical delivery guarantee.",
            "Both traces use the same predeclared 16x dilation and the same causal offer rule.",
            "Only the measured pre-event state changes the bid; no parameter is updated between cells.",
            "No external offer or deployment claim is made.",
        ],
    }
    atomic_json(output / "CAUSAL_ADAPTIVE_OFFER_REPORT.json", report)
    atomic_json(output / "COLLECTION_COMPLETE.json", {"status": report["status"]})
    return report


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: runner.py SOURCE_RUN OUTPUT")
    source_run = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    if not source_run.is_dir():
        raise RuntimeError("source run is missing")
    if output.exists():
        allowed = {"logs", "launcher.pid", Path(__file__).name}
        unexpected = sorted(path.name for path in output.iterdir() if path.name not in allowed)
        if unexpected:
            raise RuntimeError("output is not fresh: " + repr(unexpected))
    with (ROOT / "results/causal_adaptive_offer_validation.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        active = active_collectors(ROOT)
        if active:
            raise RuntimeError("another FlexBid workload is active: " + repr(active))
        output.mkdir(parents=True, exist_ok=True)
        (output / "logs").mkdir(exist_ok=True)
        (output / Path(__file__).name).write_text(
            Path(__file__).read_text(encoding="utf-8"), encoding="utf-8"
        )
        (output / "launcher.pid").write_text(str(os.getpid()) + "\n", encoding="utf-8")
        source_config = load_config(source_run / "diagnostic_config.yaml")
        config = dict(source_config)
        config["hardware"] = dict(source_config["hardware"])
        config["paths"] = dict(source_config.get("paths", {}))
        config["hardware"]["control_file"] = str(output / "control.json")
        config["paths"]["results_root"] = str(output)
        config["experiment_name"] = output.name
        (output / "development_config.yaml").write_text(
            yaml.safe_dump(config, sort_keys=False), encoding="utf-8"
        )
        profiles = load_profiles()
        atomic_json(output / "MEASURED_PROFILES.json", profiles)
        episodes = selected_test_episodes()
        atomic_json(output / "CAMPAIGN_PLAN.json", {
            "status": "CAUSAL_ADAPTIVE_OFFER_VALIDATION_PLANNED",
            "offer_policy": (
                "per episode: causal R2/C0/P300 lead probe, minimum five-second reduction, "
                "settlement-margin subtraction, derating, and quantization"
            ),
            "reserve_action": RESERVE_ACTION,
            "evaluation_arrival_scale": EVALUATION_SCALE,
            "selected_episode_ids": list(SELECTED_TEST_EPISODES),
            "episodes": episodes,
            "external_commitment": False,
            "automatic_retry": False,
        })
        try:
            reports = []
            with PowerCapManager(config["hardware"]["gpu_indices"]) as power:
                power.set_all(400.0)
                with ServiceGroup(ROOT, config, output / "service_logs") as services:
                    for episode in episodes:
                        cell = output / "cells" / episode["episode_id"].replace(":", "_")
                        (cell / "logs").mkdir(parents=True, exist_ok=True)
                        run_result = run_experiment(
                            config, services, power, cell, profiles, episode, EVALUATION_SCALE
                        )
                        reports.append(analyze(config, cell, run_result, profiles))
            report = aggregate_campaign(output, episodes, reports)
            print("=== CAUSAL_ADAPTIVE_OFFER_VALIDATION_RESULT ===", flush=True)
            print(json.dumps(report, indent=2), flush=True)
        except BaseException as exc:
            atomic_json(output / "COLLECTION_FAILED.json", {
                "status": "CAUSAL_ADAPTIVE_OFFER_VALIDATION_FAILED",
                "error_type": type(exc).__name__, "error": str(exc),
                "automatic_retry": False,
            })
            raise


if __name__ == "__main__":
    main()
