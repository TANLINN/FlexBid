"""Measure online service and the fixed 280-job cohort with four online admission slots."""
from __future__ import annotations
import csv
import re
from bisect import bisect_right
import argparse
import asyncio
import copy
import filecmp
import importlib.util
import json
import math
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time
EPISODE_ID = 'azure_code:azure-001704'
TEMPLATE_EPISODE_ID = 'azure_code:azure-001768'
WARMUP_S = 150.0
HORIZON_S = 1800.0
DURATION_S = 1950.0
COHORT_JOBS = 280
BATCH_CONCURRENCY = 6
EVENT_BATCH_CONCURRENCY = 5
PROMPT_TOKENS = 8192
OUTPUT_TOKENS = 1024
ARRIVAL_SCALE = 16.0
ADMISSION_S = 150.0
RECOVERY_S = 450.0
DRAIN_S = 900.0
PHASES = {'warmup': (0, 150), 'event_time_reference': (150, 450), 'recovery': (450, 1950), 'recovery_early': (450, 950), 'recovery_middle': (950, 1450), 'recovery_late': (1450, 1950), 'evaluation': (150, 1950), 'warmup_first30': (0, 30), 'warmup_after30': (30, 150)}

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def read_rows(path):
    with Path(path).open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    temporary.replace(path)

def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    position = (len(values) - 1) * q
    left = int(position)
    right = min(left + 1, len(values) - 1)
    return values[left] * (1 - (position - left)) + values[right] * (position - left)

def latency_summary(rows, ttft_slo, tpot_slo):
    good = [r for r in rows if r.get('error') is None]
    ttft = [float(r['ttft_ms']) for r in good if r.get('ttft_ms') is not None]
    tpot = [float(r['mean_tpot_ms']) for r in good if r.get('mean_tpot_ms') is not None]
    missing_ttft = sum((r.get('ttft_ms') is None for r in good))
    missing_tpot = sum((int(r.get('completion_tokens') or 0) > 1 and r.get('mean_tpot_ms') is None for r in good))
    p95, p99 = (quantile(ttft, 0.95), quantile(tpot, 0.99))
    normalized = [float(r['token_normalized_tpot_ms']) for r in good if r.get('token_normalized_tpot_ms') is not None]
    return {'requests': len(rows), 'errors': len(rows) - len(good), 'load_shed': sum((r.get('status_code') == 429 for r in rows)), 'ttft_samples': len(ttft), 'request_mean_stream_gap_samples': len(tpot), 'missing_ttft': missing_ttft, 'missing_mean_stream_gap': missing_tpot, 'ttft_p95_ms': p95, 'request_mean_stream_gap_p99_ms': p99, 'token_normalized_tpot_p99_ms_diagnostic': quantile(normalized, 0.99), 'token_normalized_tpot_samples': len(normalized), 'requests_with_mean_stream_gap_over_slo': sum((x > tpot_slo for x in tpot)), 'observed_slo_safe': bool(rows) and len(rows) == len(good) and (not missing_ttft) and (not missing_tpot) and (p95 is not None) and (p99 is not None) and (p95 <= ttft_slo) and (p99 <= tpot_slo)}

def job_definitions(count=COHORT_JOBS):
    return [{'job_id': f'cohort-{i:06d}', 'prompt_identity': f'cohort:{i:06d}', 'prompt_tokens': PROMPT_TOKENS, 'max_output_tokens': OUTPUT_TOKENS, 'release_offset_s': WARMUP_S, 'deadline_offset_s': DURATION_S} for i in range(count)]

async def measure_completion(client, api_base, model, prompt, output_tokens, kind, source, request_id):
    """Retain the legacy stream-gap metric and record a usage-normalized companion."""
    observations = []
    began = time.perf_counter_ns()
    dispatch = time.time_ns()
    first = last = None
    gaps, tokens, status, error, text_events = ([], 0, None, None, 0)
    payload = {'model': model, 'prompt': prompt, 'max_tokens': int(output_tokens), 'temperature': 0.0, 'ignore_eos': True, 'stream': True, 'stream_options': {'include_usage': True}}
    try:
        async with client.stream('POST', api_base.rstrip('/') + '/completions', json=payload, headers={'X-FlexBid-Class': kind, 'X-FlexBid-Source': source, 'X-FlexBid-Trace-ID': request_id}) as response:
            status = response.status_code
            response.raise_for_status()
            async for line in response.aiter_lines():
                line_read_ns = time.monotonic_ns()
                if not line.startswith('data: '):
                    continue
                data = line[6:]
                if data == '[DONE]':
                    break
                message = json.loads(data)
                usage = message.get('usage')
                if usage:
                    tokens = int(usage.get('completion_tokens') or tokens)
                choices = message.get('choices') or []
                if choices and choices[0].get('text'):
                    now = time.perf_counter_ns()
                    if first is None:
                        first = now
                    if last is not None:
                        gaps.append((now - last) / 1000000.0)
                    last = now
                    text_events += 1
                    observations.append({'sequence': text_events, 'response_id': message.get('id'), 'text_chars': len(choices[0]['text']), 'line_read_ns': line_read_ns, 'parsed_ns': time.monotonic_ns()})
    except Exception as exc:
        error = f'{type(exc).__name__}: {exc}'
    completed = time.perf_counter_ns()
    normalized = (last - first) / 1000000.0 / (tokens - 1) if first is not None and last is not None and (text_events > 1) and (tokens > 1) else None
    return {'dispatch_wall_time_ns': dispatch, 'completion_wall_time_ns': dispatch + completed - began, 'ttft_ms': (first - began) / 1000000.0 if first is not None else None, 'mean_tpot_ms': sum(gaps) / len(gaps) if gaps else None, 'max_tpot_ms': max(gaps) if gaps else None, 'token_normalized_tpot_ms': normalized, 'nonempty_sse_text_events': text_events, 'e2e_ms': (completed - began) / 1000000.0, 'completion_tokens': tokens, 'status_code': status, 'error': error, 'stream_observations': observations}

async def sleep_until(target_mono):
    while True:
        remaining = target_mono - time.perf_counter()
        if remaining <= 0:
            return
        await asyncio.sleep(remaining)

async def execute_requests(online, jobs, protocol, request, emit, concurrency=BATCH_CONCURRENCY):
    """Each job is attempted once; unstarted and late jobs remain in the ledger."""
    start_ns = int(protocol['start_wall_ns'])
    wall_now = time.time_ns()
    start_mono = time.perf_counter() + (start_ns - wall_now) / 1000000000.0
    duration = float(protocol['duration_s'])
    drain_end = start_mono + duration + float(protocol['drain_s'])
    events = {row['request_id']: asyncio.Event() for row in online}
    parent_completion = {}
    next_job = 0

    async def invoke(row, request_class):
        dispatch = time.time_ns()
        try:
            timeout = max(0.001, drain_end - time.perf_counter())
            return await asyncio.wait_for(request(row, request_class), timeout)
        except asyncio.TimeoutError:
            return {'dispatch_wall_time_ns': dispatch, 'completion_wall_time_ns': time.time_ns(), 'completion_tokens': 0, 'error': 'drain_timeout', 'status_code': None, 'ttft_ms': None, 'mean_tpot_ms': None}

    async def online_one(row):
        parent = row.get('parent_request_id')
        if parent in events:
            await events[parent].wait()
        target = start_mono + float(row['arrival_ms']) / 1000.0
        if parent in parent_completion:
            target = max(target, parent_completion[parent] + float(row.get('tool_delay_ms') or 0) / 1000.0)
        await sleep_until(min(target, drain_end))
        if time.perf_counter() >= drain_end:
            metric = {'dispatch_wall_time_ns': None, 'completion_wall_time_ns': None, 'completion_tokens': 0, 'error': 'not_dispatched_before_drain_end', 'status_code': None, 'ttft_ms': None, 'mean_tpot_ms': None}
        else:
            metric = await invoke(row, 'online')
        clean = {k: v for k, v in row.items() if k != 'prompt_token_ids'}
        clean.update(metric)
        clean['scheduled_wall_time_ns'] = start_ns + int(float(row['arrival_ms']) * 1000000.0)
        emit('online', clean)
        parent_completion[row['request_id']] = time.perf_counter()
        events[row['request_id']].set()

    async def batch_worker(worker_index):
        nonlocal next_job
        release_s = float(protocol['cohort_release_offset_s'])
        admission_s = max(release_s, float(protocol['batch_admission_offset_s']))
        if worker_index >= int(protocol['event_batch_concurrency']):
            admission_s = max(admission_s, float(protocol['recovery_start_offset_s']))
        await sleep_until(start_mono + admission_s)
        while next_job < len(jobs):
            if time.perf_counter() >= start_mono + duration:
                break
            row = jobs[next_job]
            next_job += 1
            metric = await invoke(row, 'batch')
            clean = {k: v for k, v in row.items() if k != 'prompt_token_ids'}
            clean.update(metric)
            clean['job_status'] = 'finished_attempt'
            emit('batch', clean)
    await asyncio.gather(*(online_one(row) for row in online), *(batch_worker(index) for index in range(concurrency)))
    for row in jobs[next_job:]:
        clean = {k: v for k, v in row.items() if k != 'prompt_token_ids'}
        clean.update(job_status='not_started_by_deadline', dispatch_wall_time_ns=None, completion_wall_time_ns=None, completion_tokens=0, status_code=None, error=None)
        emit('batch', clean)

def saved_workload(reference):
    online = read_rows(reference / 'online_workload.jsonl')
    jobs = read_rows(reference / 'batch_jobs.jsonl')
    ids = [r['request_id'] for r in online]
    if len(set(ids)) != len(ids):
        raise ValueError('online request IDs are not unique')
    rank = {key: i for i, key in enumerate(ids)}
    for i, row in enumerate(online):
        parent = row.get('parent_request_id')
        if parent in rank and rank[parent] >= i:
            raise ValueError('trace has a forward or cyclic parent dependency')
        if not 0 <= float(row['arrival_ms']) < DURATION_S * 1000:
            raise ValueError('saved online request is outside the experiment horizon')
        if not row['prompt_token_ids']:
            raise ValueError('saved online request has no token array')
    definitions = job_definitions()
    if len(jobs) != len(definitions):
        raise ValueError('saved cohort has a different job count')
    for row, definition in zip(jobs, definitions):
        if any((row.get(k) != v for k, v in definition.items())):
            raise ValueError('saved cohort job differs: ' + definition['job_id'])
        if len(row['prompt_token_ids']) != PROMPT_TOKENS:
            raise ValueError('saved batch prompt length differs')
    return (online, jobs)

def load_helper(source):
    path = source / 'run_chunk2048_priority_c6_recovery_pilot.py'
    spec = importlib.util.spec_from_file_location('saved_priority_pilot', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def select_recovery_action(actions, power_cap_w=400, batch_concurrency=BATCH_CONCURRENCY):
    matches = [action for action in actions if (action.online_replicas, action.batch_concurrency, action.power_cap_w) == (4, batch_concurrency, power_cap_w) and tuple(action.resolved_online_replica_ids()) == (0, 1, 2, 3)]
    if len(matches) != 1:
        raise ValueError(f'expected one configured R4/C{batch_concurrency}/P{power_cap_w} action on replicas 0,1,2,3')
    return matches[0]

class CapSchedule:
    """Apply each current phase once; retain actual actuation boundary times."""

    def __init__(self, start_mono, baseline, event, enact, emit, monotonic=time.monotonic, wall_ns=time.time_ns, recovery=None):
        self.start_mono = start_mono
        self.baseline, self.event = (baseline, event)
        self.recovery = baseline if recovery is None else recovery
        self.enact, self.emit = (enact, emit)
        self.monotonic, self.wall_ns = (monotonic, wall_ns)
        self.phase = None
        self.action = baseline

    def tick(self):
        elapsed = self.monotonic() - self.start_mono
        if elapsed < WARMUP_S:
            phase, desired, boundary = ('warmup', self.baseline, 0.0)
        elif elapsed < RECOVERY_S:
            phase, desired, boundary = ('event', self.event, WARMUP_S)
        else:
            phase, desired, boundary = ('recovery', self.recovery, RECOVERY_S)
        if phase != self.phase:
            began_ns = self.wall_ns()
            receipt = self.enact(desired)
            finished = self.monotonic() - self.start_mono
            self.emit({'phase': phase, 'planned_boundary_s': boundary, 'begin_offset_s': elapsed, 'end_offset_s': finished, 'begin_wall_ns': began_ns, 'end_wall_ns': self.wall_ns(), 'action': desired.as_dict(), **receipt})
            self.phase, self.action = (phase, desired)
        return self.action

    def sleep_duration(self, deadline_mono):
        now = self.monotonic()
        future = [self.start_mono + offset for offset in (WARMUP_S, RECOVERY_S) if self.start_mono + offset > now]
        return max(0.0, min([1.0, deadline_mono - now] + [t - now for t in future]))

def cap_observations(output, gpu_indices, event_power_cap_w):
    rows = read_rows(output / 'power_actions.jsonl')
    expected = [('warmup', 400.0), ('event', event_power_cap_w), ('recovery', 400.0)]
    sequence = [(r['phase'], float(r['action']['power_cap_w'])) for r in rows]
    all_enforced = bool(rows) and all((set(map(int, r['enforced_power_caps_w'])) == set(gpu_indices) and all((abs(float(v) - float(r['action']['power_cap_w'])) <= 0.6 for v in r['enforced_power_caps_w'].values())) for r in rows))
    return {'transitions': rows, 'requested_sequence_observed': sequence == expected, 'all_configured_gpu_caps_matched_at_transitions': all_enforced, 'timing_note': 'Fixed 150/450 s analysis boundaries include actuation delays; no window is shifted.'}

def workload_main(output):
    import httpx
    settings = read_json(output / 'workload.json')
    reference = Path(settings['input_root'])
    online, jobs = saved_workload(reference)
    for filename in ('online_workload.jsonl', 'batch_jobs.jsonl'):
        shutil.copyfile(reference / filename, output / filename)
    write_json(output / 'workload_ready.json', {'online_requests': len(online), 'cohort_jobs': len(jobs), 'cohort_tokens': sum((r['max_output_tokens'] for r in jobs)), 'input_root': str(reference), 'exact_saved_inputs_reused': True})
    timeout = time.monotonic() + 300
    while not (output / 'protocol.json').exists():
        if time.monotonic() > timeout:
            raise TimeoutError('launcher did not provide the experiment start time')
        time.sleep(0.1)
    protocol = read_json(output / 'protocol.json')

    async def run():
        with (output / 'online.jsonl').open('w', encoding='utf-8') as on, (output / 'batch.jsonl').open('w', encoding='utf-8') as ba:

            def emit(kind, row):
                stream = on if kind == 'online' else ba
                stream.write(json.dumps(row) + '\n')
                stream.flush()
            async with httpx.AsyncClient(timeout=None, headers={'Authorization': 'Bearer EMPTY'}, limits=httpx.Limits(max_connections=2048, max_keepalive_connections=256)) as client:

                async def request(row, kind):
                    return await measure_completion(client, settings['api_base'], settings['model'], row['prompt_token_ids'], row['max_output_tokens'], kind, settings['source'] if kind == 'online' else 'batch', row['request_id'] if kind == 'online' else row['job_id'])
                await execute_requests(online, jobs, protocol, request, emit)
    asyncio.run(run())
    write_json(output / 'workload_complete.json', {'status': 'complete'})

def select_phase(rows, left, right):
    return [r for r in rows if left * 1000 <= float(r['arrival_ms']) < right * 1000]

def run_measurement(project, template, input_root, output, event_power_cap_w, reference=None):
    import fcntl
    import yaml
    from flexbid_hybrid.config import load_config
    from flexbid_hybrid.mpc import build_action_lattice
    from flexbid_hybrid.pilot import apply_control
    from flexbid_hybrid.power import PowerCapManager
    from flexbid_hybrid.service import get_json, stop_process
    template_protocol = read_json(template / 'protocol.json')
    template_report = read_json(template / 'REPORT.json')
    if template_report['status'] != 'NO_CURTAILMENT_COHORT_MEASURED':
        raise ValueError('hardware template is not the completed no-curtailment cohort run')
    source = Path(template_protocol['source_run'])
    helper = load_helper(source)
    config = copy.deepcopy(load_config(template / 'config.yaml'))
    if int(config['runtime']['max_num_batched_tokens']) != 2048:
        raise ValueError('source configuration is not the measured chunk2048 configuration')
    if int(config['workloads']['batch_prompt_tokens']) != PROMPT_TOKENS or int(config['workloads']['batch_output_tokens']) != OUTPUT_TOKENS:
        raise ValueError('source batch lengths differ from the specified 8K/1K workload')
    if template_report['episode_id'] != TEMPLATE_EPISODE_ID:
        raise ValueError('hardware-template episode differs')
    saved_workload(input_root)
    workload_info = read_json(input_root / 'INPUT_SUMMARY.json')
    if workload_info['episode_id'] != EPISODE_ID:
        raise ValueError('prepared workload episode differs')
    if reference is not None:
        reference_report = read_json(reference / 'REPORT.json')
        if reference_report['episode_id'] != EPISODE_ID or reference_report['event_power_cap_w'] != 400:
            raise ValueError("power comparison requires the same episode's measured C4/P400 cell")
    config['runtime']['max_num_batched_tokens'] = 1024
    config['runtime']['online_concurrency'] = 4
    config['hardware']['control_file'] = str(output / 'control.json')
    config['runtime']['priority_gateway_module'] = str(output / 'priority_gateway.py')
    config.setdefault('paths', {})['results_root'] = str(output)
    config['experiment_name'] = output.name
    previous = project / 'results' / 'azure704_batch2_p300_repeat_20260907_191251_rnd7pr'
    shutil.copyfile(previous / 'priority_gateway.py', output / 'priority_gateway.py')
    (output / 'config.yaml').write_text(yaml.safe_dump(config, sort_keys=False), encoding='utf-8')
    actions = build_action_lattice(config['dynamic_controller']['action_lattice'])
    action = select_recovery_action(actions, batch_concurrency=EVENT_BATCH_CONCURRENCY)
    event_action = select_recovery_action(actions, event_power_cap_w, EVENT_BATCH_CONCURRENCY)
    recovery_action = select_recovery_action(actions)
    model, runtime = (config['model'], config['runtime'])
    base = f"http://127.0.0.1:{runtime['gateway_port']}"
    write_json(output / 'workload.json', {'model': model['name'], 'api_base': base + '/v1', 'source': workload_info['source'], 'input_root': str(input_root)})
    write_json(output / 'EXPERIMENT_PLAN.json', {'episode_id': EPISODE_ID, 'condition': 'fixed_cohort', 'duration_s': DURATION_S, 'input_root': str(input_root), 'hardware_template_run': str(template), 'gateway_capacity': 'R4; event C5, recovery C6; four online admission slots', 'power_cap_schedule_w': {'warmup': 400, 'event': 300, 'recovery': 400}, 'online_input': 'exact saved token arrays and timestamps; no regeneration or rescaling', 'arrival_time_multiplier': ARRIVAL_SCALE, 'external_commitment': False, 'automatic_retry': False, 'max_num_batched_tokens': 1024, 'comparison_run': '/root/workspace/FlexBid-LLM/hybrid_artifact/results/azure704_batch2_p300_repeat_20260907_191251_rnd7pr', 'gateway_online_concurrency': 4, 'cohort_jobs_planned': 280, 'online_routing': 'first-text eligibility; online requires no online or batch pending-first request, batch requires no online request and fewer than two active batch requests; total/batch/index ranking among eligible replicas'})
    lock_path = project / 'results/chunk2048_priority_c6_recovery_pilot.lock'
    with lock_path.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        active = helper.active_collectors(project)
        if active:
            raise RuntimeError('another FlexBid workload is active: ' + repr(active))
        with PowerCapManager(config['hardware']['gpu_indices']) as power_caps:
            power_caps.set_all(action.power_cap_w)
            apply_control(Path(config['hardware']['control_file']), action, len(model['replicas']), int(runtime['online_concurrency']))
            with helper.PriorityServiceGroup(project, config, output / 'service_logs') as services:
                services.wait_idle()
                services.reset_caches()
                services.reset_state()
                get_json(base + '/flexbid/state')

                def enact(desired):
                    enforced = power_caps.set_all(desired.power_cap_w)
                    control = apply_control(Path(config['hardware']['control_file']), desired, len(model['replicas']), int(runtime['online_concurrency']))
                    return {'enforced_power_caps_w': enforced, 'control': control}
                handles, driver, telemetry = ([], None, None)
                try:
                    handle = (output / 'logs/workload.log').open('w', encoding='utf-8')
                    handles.append(handle)
                    driver = subprocess.Popen([sys.executable, '-B', '-u', str(Path(__file__).resolve()), '--project', str(project), '--output', str(output), '--workload'], cwd=project, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
                    ready_limit = time.monotonic() + 240
                    while not (output / 'workload_ready.json').exists():
                        if driver.poll() is not None:
                            raise RuntimeError('workload preparation failed; see logs/workload.log')
                        if time.monotonic() > ready_limit:
                            raise TimeoutError('workload preparation exceeded 240 seconds')
                        time.sleep(0.2)
                    handle = (output / 'logs/telemetry.log').open('w', encoding='utf-8')
                    handles.append(handle)
                    telemetry = subprocess.Popen([sys.executable, '-B', '-m', 'flexbid_hybrid.telemetry', '--output', str(output / 'components.csv'), '--interval-ms', str(config['hardware']['telemetry_interval_ms'])], cwd=project, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
                    start_ns = time.time_ns() + 3000000000
                    protocol = {'start_wall_ns': start_ns, 'deadline_wall_ns': start_ns + int(DURATION_S * 1000000000.0), 'duration_s': DURATION_S, 'cohort_release_offset_s': 150.0, 'batch_admission_offset_s': 150.0, 'event_batch_concurrency': 5, 'recovery_start_offset_s': RECOVERY_S, 'recovery_batch_concurrency': BATCH_CONCURRENCY, 'drain_s': DRAIN_S, 'source_run': str(source), 'reference_run': str(project / 'results' / 'azure704_batch2_p400_20260907_175653_ogYs10'), 'input_root': str(input_root), 'hardware_template_run': str(template), 'condition': 'fixed_cohort', 'event_power_cap_w': event_power_cap_w, 'power_cap_schedule_w': {'warmup': 400, 'event': event_power_cap_w, 'recovery': 400}, 'cohort_jobs_planned': 280, 'service_comparison_run': str(project / 'results' / 'azure704_batch2_p300_repeat_20260907_191251_rnd7pr')}
                    write_json(output / 'protocol.json', protocol)
                    print('MEASUREMENT_STARTED ' + json.dumps(read_json(output / 'workload_ready.json')), flush=True)
                    deadline_mono = time.monotonic() + (protocol['deadline_wall_ns'] - time.time_ns()) / 1000000000.0
                    with (output / 'gateway_state.jsonl').open('w', encoding='utf-8') as stream, (output / 'power_actions.jsonl').open('w', encoding='utf-8') as cap_stream:

                        def emit_cap(row):
                            cap_stream.write(json.dumps(row) + '\n')
                            cap_stream.flush()
                        schedule = CapSchedule(deadline_mono - DURATION_S, action, event_action, enact, emit_cap, recovery=recovery_action)
                        while time.monotonic() < deadline_mono:
                            if driver.poll() is not None and driver.returncode != 0:
                                raise RuntimeError('workload failed; see logs/workload.log')
                            if telemetry.poll() is not None:
                                raise RuntimeError('telemetry exited before measurement end')
                            if any((p.poll() is not None for p in services.processes)):
                                raise RuntimeError('inference service exited; see service_logs')
                            current_action = schedule.tick()
                            observed = get_json(base + '/flexbid/state')
                            snapshot = {k: observed[k] for k in ('inflight', 'inflight_online', 'inflight_batch', 'online_waiting', 'batch_waiting', 'completed_online', 'completed_batch')}
                            stream.write(json.dumps({'wall_time_ns': time.time_ns(), 'action': current_action.name, **snapshot}) + '\n')
                            stream.flush()
                            time.sleep(schedule.sleep_duration(deadline_mono))
                    print('MEASUREMENT_ENDED; collecting outstanding request outcomes', flush=True)
                    if driver.wait(timeout=DRAIN_S + 30) != 0:
                        raise RuntimeError('workload failed; see logs/workload.log')
                    if not (output / 'workload_complete.json').is_file():
                        raise RuntimeError('workload completion record is missing')
                finally:
                    try:
                        try:
                            restoration = enact(action)
                            write_json(output / 'POWER_CAP_RESTORED.json', restoration)
                        finally:
                            if driver is not None and driver.poll() is None:
                                stop_process(driver)
                    finally:
                        if telemetry is not None and telemetry.poll() is None:
                            stop_process(telemetry)
                        for handle in handles:
                            handle.close()
                services.wait_idle()
    return analyze(output, config)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--template', type=Path)
    parser.add_argument('--input-root', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workload', action='store_true')
    args = parser.parse_args()
    project, output = (args.project.resolve(), args.output.resolve())
    sys.path.insert(0, str(project))
    sys.path.insert(0, str(project / 'scripts'))
    if args.workload:
        workload_main(output)
        return
    if args.template is None or args.input_root is None:
        parser.error('--template and --input-root are required for the launcher')
    if (output / 'REPORT.txt').exists():
        print((output / 'REPORT.txt').read_text(encoding='utf-8'), end='')
        return

    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'received signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        report = run_measurement(project, args.template.resolve(), args.input_root.resolve(), output, 300.0)
        print(format_report(report), end='', flush=True)
    except BaseException as exc:
        write_json(output / 'COLLECTION_FAILED.json', {'status': 'AZURE704_BATCH2_RECOVERY_C6_FAILED', 'error_type': type(exc).__name__, 'error': str(exc), 'automatic_retry': False})
        raise

def cohort_summary(jobs, ledger, protocol):
    by_id = {r['job_id']: r for r in ledger}
    if len(by_id) != len(ledger) or set(by_id) != {r['job_id'] for r in jobs}:
        raise ValueError('batch ledger must contain each planned job exactly once')
    start_ns = int(protocol['start_wall_ns'])
    on_time, late, unfinished, total = ([], [], [], 0)
    for job in jobs:
        row = by_id[job['job_id']]
        finish = row['completion_wall_time_ns']
        begin = row['dispatch_wall_time_ns']
        tokens = int(row.get('completion_tokens') or 0)
        complete = row.get('error') is None and finish is not None and (row.get('status_code') == 200) and (tokens == job['max_output_tokens'])
        release = start_ns + int(job['release_offset_s'] * 1000000000.0)
        deadline = start_ns + int(job['deadline_offset_s'] * 1000000000.0)
        if begin is not None and int(begin) < release:
            raise ValueError('batch job dispatched before release: ' + job['job_id'])
        if complete and begin is not None and (release <= int(begin) <= int(finish) <= deadline):
            on_time.append(job['job_id'])
            total += tokens
        elif complete:
            late.append(job['job_id'])
        else:
            unfinished.append(job['job_id'])
    return {'planned_jobs': len(jobs), 'planned_tokens': sum((j['max_output_tokens'] for j in jobs)), 'jobs_completed_on_time': len(on_time), 'tokens_completed_on_time': total, 'jobs_completed_late': len(late), 'jobs_unfinished_or_failed': len(unfinished), 'late_job_ids': late, 'unfinished_or_failed_job_ids': unfinished, 'all_jobs_completed_by_deadline': len(on_time) == len(jobs)}

def cohort_timing(output):
    protocol = read_json(output / 'protocol.json')
    jobs = read_rows(output / 'batch_jobs.jsonl')
    ledger = read_rows(output / 'batch.jsonl')
    summary = cohort_summary(jobs, ledger, protocol)
    start = int(protocol['start_wall_ns'])
    complete = [r for r in ledger if r.get('status_code') == 200 and r.get('error') is None and (int(r.get('completion_tokens') or 0) == int(r['max_output_tokens'])) and (r.get('completion_wall_time_ns') is not None)]
    dispatch = [int(r['dispatch_wall_time_ns']) for r in ledger if r.get('dispatch_wall_time_ns') is not None]
    finishes = [int(r['completion_wall_time_ns']) for r in complete]
    last = (max(finishes) - start) / 1000000000.0 if finishes else None
    return {'first_batch_dispatch_offset_s': (min(dispatch) - start) / 1000000000.0 if dispatch else None, 'last_completed_job_offset_s': last, 'all_job_completion_slack_s': DURATION_S - last if len(complete) == len(jobs) and last is not None else None, 'jobs_completed_on_time': summary['jobs_completed_on_time'], 'tokens_completed_on_time': summary['tokens_completed_on_time'], 'deadline_token_deficit': summary['planned_tokens'] - summary['tokens_completed_on_time'], 'jobs_completed_by_offset': {str(offset): sum((t <= start + int(offset * 1000000000.0) for t in finishes)) for offset in (450, 950, 1450, 1650, 1950)}, 'batch_dispatches_during_event': sum((start + 150000000000 <= t < start + 450000000000 for t in dispatch))}

def client_batch_phase_counts(ledger, protocol):
    start = int(protocol['start_wall_ns'])
    release = float(protocol['cohort_release_offset_s'])
    recovery = float(protocol['recovery_start_offset_s'])
    duration = float(protocol['duration_s'])
    result = {}
    for phase, left_s, right_s in (('event', release, recovery), ('recovery', recovery, duration)):
        left, right = (start + int(left_s * 1000000000.0), start + int(right_s * 1000000000.0))
        events, dispatches = ([], 0)
        for row in ledger:
            begin = row.get('dispatch_wall_time_ns')
            if begin is None:
                continue
            begin = int(begin)
            finish = row.get('completion_wall_time_ns')
            finish = int(finish) if finish is not None else right
            dispatches += int(left <= begin < right)
            if finish <= left or begin >= right or finish <= begin:
                continue
            events += [(max(left, begin), 1), (min(right, finish), -1)]
        active, maximum = (0, 0)
        for _, delta in sorted(events):
            active += delta
            maximum = max(maximum, active)
        result[phase] = {'maximum_client_batch_inflight': maximum, 'batch_dispatches': dispatches}
    return result

def gpu_series(output):
    start = int(read_json(output / 'protocol.json')['start_wall_ns'])
    rows = []
    with (output / 'components.csv').open(newline='', encoding='utf-8') as stream:
        for row in csv.DictReader(stream):
            value = row.get('aggregate_gpu_power_w')
            if value not in (None, '') and math.isfinite(float(value)):
                rows.append((int(row['wall_time_ns']) - start, float(value)))
    rows.sort()
    if any((b[0] <= a[0] for a, b in zip(rows, rows[1:]))):
        raise ValueError('GPU sample times are not unique and increasing')
    return rows

def power_window(rows, left_s, right_s):
    """Integrate linear segments at exact boundaries; never extrapolate missing edges."""
    left, right = (int(left_s * 1000000000.0), int(right_s * 1000000000.0))
    valid = len(rows) >= 2 and rows[0][0] <= left < right <= rows[-1][0]
    result = {'start_s': left_s, 'end_s': right_s, 'covered': valid}
    if not valid:
        return {**result, 'mean_gpu_w': None, 'gpu_energy_wh': None, 'maximum_sample_gap_s': None}
    times = [r[0] for r in rows]
    index = max(0, bisect_right(times, left) - 1)
    total, maximum_gap = (0.0, 0.0)
    while index + 1 < len(rows) and rows[index][0] < right:
        (ta, va), (tb, vb) = (rows[index], rows[index + 1])
        a, b = (max(ta, left), min(tb, right))
        if b > a:
            pa = va + (vb - va) * (a - ta) / (tb - ta)
            pb = va + (vb - va) * (b - ta) / (tb - ta)
            total += (b - a) / 1000000000.0 * (pa + pb) / 2
            maximum_gap = max(maximum_gap, (tb - ta) / 1000000000.0)
        index += 1
    return {**result, 'mean_gpu_w': total / (right_s - left_s), 'gpu_energy_wh': total / 3600, 'maximum_sample_gap_s': maximum_gap}

def normalized_configuration(config):
    value = copy.deepcopy(config)
    value.pop('experiment_name', None)
    value['hardware'].pop('control_file', None)
    value['runtime'].pop('priority_gateway_module', None)
    value.get('paths', {}).pop('results_root', None)
    return value

def paired_power_comparison(reference, output):
    original, treatment = (gpu_series(reference), gpu_series(output))

    def compare(left, right):
        a, b = (power_window(original, left, right), power_window(treatment, left, right))
        covered = a['covered'] and b['covered']
        return {'reference': a, 'treatment': b, 'paired_reduction_w': a['mean_gpu_w'] - b['mean_gpu_w'] if covered else None, 'energy_saved_wh': a['gpu_energy_wh'] - b['gpu_energy_wh'] if covered else None}
    windows = [dict(window=i, **compare(150 + 30 * i, 180 + 30 * i)) for i in range(10)]
    reductions = [w['paired_reduction_w'] for w in windows]
    covered = all((v is not None for v in reductions))
    stages = {name: compare(left, right) for name, left, right in [('event', 150, 450), ('recovery', 450, 1950), ('full_horizon', 150, 1950)]}
    recovery_delta = stages['recovery']['paired_reduction_w']
    return {'reference_run': str(reference), 'boundary': 'aggregate_gpu_power_w', 'alignment': 'fixed relative 150/450/1950 s boundaries; actuation delays remain included', 'event_30s_windows': windows, 'all_event_windows_covered': covered, 'minimum_paired_window_reduction_w': min(reductions) if covered else None, 'all_paired_event_windows_positive': all((v > 0 for v in reductions)) if covered else None, 'stages': stages, 'recovery_mean_power_above_reference_w': -recovery_delta if recovery_delta is not None else None, 'offered_bid_w': None, 'interpretation': 'One earlier P400 run and one event-P300 run of reused input; run-order variation is not separated from the intervention.'}

def analyze(output, config):
    import yaml
    from stream_trace_tools import analyze_streams
    from stream_context_tools import analyze as analyze_context
    previous = output.parent / 'azure704_batch2_p300_repeat_20260907_191251_rnd7pr'
    old = read_json(previous / 'REPORT.json')
    old_config = yaml.safe_load((previous / 'config.yaml').read_text(encoding='utf-8'))
    old_online = read_rows(previous / 'online.jsonl')
    protocol = read_json(output / 'protocol.json')
    input_root = Path(protocol['input_root'])
    online, jobs = (read_rows(output / 'online.jsonl'), read_rows(output / 'batch_jobs.jsonl'))
    batch_rows = read_rows(output / 'batch.jsonl')
    planned = read_rows(output / 'online_workload.jsonl')
    by_id, planned_by_id = ({r['request_id']: r for r in rows} for rows in (online, planned))
    old_by_id = {r['request_id']: r for r in old_online}
    if len(by_id) != len(online) or set(by_id) != set(planned_by_id) or set(by_id) != set(old_by_id):
        raise ValueError('online ledger differs from the planned request IDs')
    metadata = ('arrival_ms', 'prompt_tokens', 'max_output_tokens', 'parent_request_id', 'tool_delay_ms')
    if any((r.get(k) != planned_by_id[key].get(k) or r.get(k) != old_by_id[key].get(k) for key, r in by_id.items() for k in metadata)):
        raise ValueError('online request metadata differs from the saved workload')
    ttft_slo = float(config['slos']['default']['ttft_ms'])
    gap_slo = float(config['slos']['default']['tpot_ms'])
    phases = {name: {'recovery_c6': latency_summary(select_phase(online, left, right), ttft_slo, gap_slo), 'recovery_c5': latency_summary(select_phase(old_online, left, right), ttft_slo, gap_slo)} for name, (left, right) in PHASES.items()}
    batch = cohort_summary(jobs, batch_rows, protocol)
    timing = cohort_timing(output)
    concurrency = client_batch_phase_counts(batch_rows, protocol)
    attempted = [r for r in batch_rows if r.get('dispatch_wall_time_ns') is not None]
    caps = cap_observations(output, config['hardware']['gpu_indices'], 300.0)
    gateways = read_rows(output / 'stream_gateway.jsonl')
    online_gateways = [r for r in gateways if r['class'] == 'online']
    batch_gateways = [r for r in gateways if r['class'] == 'batch']
    observation = analyze_streams(online, online_gateways, gap_slo)
    observation_ok = not observation['alignment_problems'] and (not observation['duplicate_gateway_ids']) and (not observation['unexpected_gateway_ids']) and (observation['paired_gap_samples'] == phases['evaluation']['recovery_c6']['request_mean_stream_gap_samples'])
    contexts = {'status': 'unavailable: online stream alignment is incomplete'}
    if observation_ok:
        contexts, _ = analyze_context(online, gateways, gap_slo)
    states = read_rows(output / 'gateway_state.jsonl')
    max_online = max((sum(r['inflight_after_selection']['online']) for r in gateways), default=None)
    max_online_per_replica = max((max(r['inflight_after_selection']['online']) for r in gateways), default=None)
    max_combined = max((max((a + b for a, b in zip(r['inflight_after_selection']['online'], r['inflight_after_selection']['batch']))) for r in gateways), default=None)
    online_into_batch = [r['request_id'] for r in online_gateways if r['inflight_after_selection']['batch'][r['replica']] > 0]
    batch_into_online = [r['request_id'] for r in batch_gateways if r['inflight_after_selection']['online'][r['replica']] > 0]
    budgets = {}
    for path in sorted((output / 'service_logs').glob('vllm_replica_*.log')):
        values = re.findall('Chunked prefill is enabled with max_num_batched_tokens=(\\d+)', path.read_text(encoding='utf-8', errors='replace'))
        budgets[path.name] = sorted({int(v) for v in values})
    incomplete = sum((r.get('error') is not None or r.get('status_code') != 200 or int(r.get('completion_tokens') or 0) != int(r['max_output_tokens']) for r in online))
    checks = {'workload_process_succeeded': read_json(output / 'workload_complete.json')['status'] == 'complete', 'same_saved_online_input': filecmp.cmp(output / 'online_workload.jsonl', previous / 'online_workload.jsonl', shallow=False), 'same_saved_batch_input': filecmp.cmp(output / 'batch_jobs.jsonl', input_root / 'batch_jobs.jsonl', shallow=False), 'all_online_request_ids_and_metadata_matched': True, 'all_online_outputs_complete_without_errors': incomplete == 0, 'evaluation_online_slo_safe': phases['evaluation']['recovery_c6']['observed_slo_safe'], 'event_reference_online_slo_safe': phases['event_time_reference']['recovery_c6']['observed_slo_safe'], 'recovery_reference_online_slo_safe': phases['recovery']['recovery_c6']['observed_slo_safe'], 'all_jobs_completed_by_deadline': batch['all_jobs_completed_by_deadline'], 'batch_client_concurrency_within_phase_limits': concurrency['event']['maximum_client_batch_inflight'] <= EVENT_BATCH_CONCURRENCY and concurrency['recovery']['maximum_client_batch_inflight'] <= BATCH_CONCURRENCY, 'power_cap_sequence_observed': caps['requested_sequence_observed'], 'configured_gpu_caps_matched': caps['all_configured_gpu_caps_matched_at_transitions'], 'service_configuration_matches_control': normalized_configuration(config) == normalized_configuration(old_config), 'chunk1024_observed_in_all_replica_logs': len(budgets) == len(config['model']['replicas']) and all((v == [1024] for v in budgets.values())), 'four_online_slots_observed_at_admissions': max_online is not None and max_online <= 4, 'online_stream_alignment_complete': observation_ok, 'cross_process_clock_order_observed': observation['negative_forward_to_client_time_events'] == 0, 'batch_gateway_ids_match_attempted_jobs': len(batch_gateways) == len(attempted) and {r['request_id'] for r in batch_gateways} == {r['job_id'] for r in attempted}}
    power = gpu_series(output)
    result = {'status': 'AZURE704_BATCH2_RECOVERY_C6_MEASURED', 'episode_id': EPISODE_ID, 'comparison_run': str(previous), 'input_root': str(input_root), 'checks': checks, 'joint_pass_observed': all(checks.values()), 'post_warmup_online_slo_safe': all((phases[p]['recovery_c6']['observed_slo_safe'] for p in ('event_time_reference', 'recovery', 'evaluation'))), 'online_requests': len(online), 'online_incomplete_or_error_count': incomplete, 'phase_request_assignment': 'scheduled arrivals; delayed dispatches and errors retained', 'arrival_time_multiplier': ARRIVAL_SCALE, 'slos': {'ttft_p95_ms': ttft_slo, 'request_mean_stream_gap_p99_ms': gap_slo}, 'phases': phases, 'batch': batch, 'cohort_timing': timing, 'batch_attempts': len(attempted), 'client_batch_phase_counts': concurrency, 'batch_service': {'jobs': len(jobs), 'release_s': 150, 'deadline_s': 1950, 'event_concurrency': EVENT_BATCH_CONCURRENCY, 'recovery_concurrency': BATCH_CONCURRENCY, 'prompt_tokens_per_job': 8192, 'output_tokens_per_job': 1024}, 'observed_engine_token_budgets': budgets, 'admission': {'configured_online_concurrency': int(config['runtime']['online_concurrency']), 'maximum_online_after_selection': max_online, 'maximum_online_per_replica_after_selection': max_online_per_replica, 'maximum_combined_requests_per_replica_after_selection': max_combined, 'maximum_sampled_online_waiting': max((r['online_waiting'] for r in states), default=None), 'online_admissions_into_batch_occupied_replica': len(online_into_batch), 'batch_admissions_into_online_occupied_replica': len(batch_into_online), 'online_into_batch_request_ids': online_into_batch, 'batch_into_online_job_ids': batch_into_online, 'occupancy_scope': 'Admission counts and observed first-text intervals; batch decode remains allowed alongside online service.'}, 'online_dispatches_at_or_after_horizon': sum((r.get('dispatch_wall_time_ns') is not None and int(r['dispatch_wall_time_ns']) >= int(protocol['deadline_wall_ns']) for r in online)), 'gpu_power': {'boundary': 'aggregate_gpu_power_w', 'evaluation': power_window(power, 150, 1950)}, 'stream_observation': observation, 'upstream_interval_context': contexts, 'external_commitment': False, 'limitations': ['One development intervention on reused input after two recorded C5 runs; not independent validation or a safety probability.', 'First-text isolation, batch maximum two per replica and caps 400/300/400 W at 0/150/450 s are unchanged. Only recovery global batch concurrency changes from five to six at 450 s; event concurrency remains five.', 'The SLO is p99 of per-request mean nonempty SSE-text gaps, not per-token gap p99.', 'Queue waiting stays in client TTFT; phase assignment uses scheduled arrivals and retains delayed dispatches.', 'Warmup and phase summaries are retained; overlapping summaries are not independent samples.', 'Batch enters online-free replicas with fewer than two active batch requests; online requires neither an online request nor a batch request waiting for first text. Eligible replicas retain the total/batch/index ranking.', 'Observed admission and stream intervals are not engine prefill execution timestamps.', 'Batch jobs finishing after 1950 s or not started remain failures against the original deadline.', 'Caps are 400/300/400 W per GPU at 0/150/450 s. Paired power differences are retrospective measurements, not an offered wattage or delivery guarantee.']}
    result['cohort_comparison'] = {'recovery_c5': {'batch': old['batch'], 'cohort_timing': old['cohort_timing']}, 'recovery_c6': {'batch': batch, 'cohort_timing': timing}}
    result['admission']['maximum_batch_after_selection'] = max((sum(r['inflight_after_selection']['batch']) for r in gateways), default=None)
    result['control_batch_limits'] = [r['control']['batch_concurrency'] for r in read_rows(output / 'power_actions.jsonl')]
    result['checks']['phase_control_updates_recorded'] = result['control_batch_limits'] == [EVENT_BATCH_CONCURRENCY, EVENT_BATCH_CONCURRENCY, BATCH_CONCURRENCY]
    result['checks']['batch_input_matches_control'] = filecmp.cmp(output / 'batch_jobs.jsonl', previous / 'batch_jobs.jsonl', shallow=False)
    result['joint_pass_observed'] = all(result['checks'].values())
    from first_text_admission_tools import routing_summary, observed_first_text_overlap
    from replica_batch_limit_tools import occupancy_summary
    control = read_json(output / 'control.json')
    result['routing'] = routing_summary(gateways, control['online_replica_ids'], control['batch_replica_ids'])
    routing = result['routing']
    result['checks']['online_placement_matches_first_text_eligibility'] = routing['online_records'] == len(online) and routing['online_rule_matches'] == len(online)
    result['checks']['batch_placement_matches_online_free_eligibility'] = routing['batch_records'] == len(attempted) and routing['batch_rule_matches'] == len(attempted)
    result['checks']['one_online_per_replica_observed_at_admissions'] = bool(routing['online_records']) and routing['maximum_online_per_replica_after_selection'] <= 1
    result['joint_pass_observed'] = all(result['checks'].values())
    import ast
    result['checks']['gateway_program_matches_recorded_c5'] = ast.dump(ast.parse((output / 'priority_gateway.py').read_text(encoding='utf-8'))) == ast.dump(ast.parse((previous / 'priority_gateway.py').read_text(encoding='utf-8')))
    result['first_text_isolation'] = observed_first_text_overlap(gateways)
    result['checks']['no_online_admission_during_batch_pending_first'] = routing['online_admissions_while_batch_pending_first'] == 0
    result['checks']['no_batch_admission_during_online_service'] = routing['batch_admissions_while_online_present'] == 0
    result['checks']['observed_first_text_intervals_disjoint'] = result['first_text_isolation']['overlap_pairs'] == 0 and result['first_text_isolation']['online_intervals'] == len(online) and (result['first_text_isolation']['batch_first_text_intervals'] == len(attempted))
    result['batch_occupancy'] = {'recovery_c5': occupancy_summary(read_rows(previous / 'stream_gateway.jsonl'), read_rows(previous / 'gateway_state.jsonl')), 'recovery_c6': occupancy_summary(gateways, states)}
    occupied = result['batch_occupancy']['recovery_c6']
    result['admission']['configured_maximum_batch_per_replica'] = 2
    result['checks']['batch_per_replica_at_most_two_observed'] = occupied['maximum_batch_per_replica_at_admissions'] is not None and occupied['maximum_batch_per_replica_at_admissions'] <= 2 and (occupied['maximum_batch_per_replica_at_snapshots'] is not None) and (occupied['maximum_batch_per_replica_at_snapshots'] <= 2)
    result['service_and_deadline_pass_observed'] = all(result['checks'].values())
    result['power_cap_observations'] = caps
    result['event_power_cap_w'] = 300.0
    reference_run = output.parent / 'azure704_batch2_p400_20260907_175653_ogYs10'
    reference_report = read_json(reference_run / 'REPORT.json')
    result['reference_service_and_deadline_pass_observed'] = reference_report['service_and_deadline_pass_observed']
    result['paired_power'] = paired_power_comparison(output.parent / 'azure704_batch2_p400_20260907_175653_ogYs10', output)
    result['joint_pass_observed'] = result['service_and_deadline_pass_observed'] and result['paired_power']['all_paired_event_windows_positive'] is True
    result['joint_pass_observed'] = result['joint_pass_observed'] and result['reference_service_and_deadline_pass_observed']
    result['paired_power']['treatment_run'] = str(output)
    result['paired_power']['interpretation'] = 'Saved P400/C5 minus event-P300/C5 with C6 recovery on identical inputs. Event admission settings match; recovery and full-horizon differences also include the concurrency intervention. This is a retrospective comparison.'
    first_run = output.parent / 'azure704_replica_batch2_20260907_164313_dZYsne'
    first_report = read_json(first_run / 'REPORT.json')

    def recovery_row(report, run_path, label, recovery_concurrency):
        return {'run': str(run_path), 'event_concurrency': EVENT_BATCH_CONCURRENCY, 'recovery_concurrency': recovery_concurrency, 'service_and_deadline_pass_observed': report['service_and_deadline_pass_observed'], 'batch': report['batch'], 'cohort_timing': report['cohort_timing'], 'phases': {phase: values[label] for phase, values in report['phases'].items()}, 'online_dispatches_at_or_after_horizon': report['online_dispatches_at_or_after_horizon']}
    result['recovery_comparison'] = {'c5_first': recovery_row(first_report, first_run, 'replica_batch2', 5), 'c5_repeat': recovery_row(old, previous, 'p300_repeat', 5), 'c6_recovery': recovery_row(result, output, 'recovery_c6', BATCH_CONCURRENCY)}
    result['client_batch_limits'] = {'event': EVENT_BATCH_CONCURRENCY, 'recovery': BATCH_CONCURRENCY}
    result['joint_pass_definition'] = 'this C5-event/C6-recovery run and the recorded P400/C5 reference meet original aggregate service and cohort-deadline criteria; all ten observed event power differences are positive'
    result['diagnostic_phase_slo_safe'] = {p: phases[p]['recovery_c6']['observed_slo_safe'] for p in ('recovery_early', 'recovery_middle', 'recovery_late')}
    result['limitations'].append('The cohort is first released at 150 s after online-only warmup; this does not test activation with pre-existing batch requests in flight.')
    result['limitations'].append('First text is an observed proxy boundary, not an engine prefill-completion signal. Added placement waiting remains in client TTFT and the original batch deadline.')
    result['limitations'].append('The saved P400 reference uses C5 throughout. Its event policy matches this run before recovery; full-horizon differences combine the event power cap and recovery concurrency interventions. Fixed run order remains a confound.')
    result['limitations'].append('The fixed 150-1950 s energy comparison excludes later completions. If either cohort is incomplete at the deadline, it is not an equal-completed-work energy comparison.')
    write_json(output / 'REPORT.json', result)
    (output / 'REPORT.txt').write_text(format_report(result), encoding='utf-8')
    write_json(output / 'COLLECTION_COMPLETE.json', {'status': result['status']})
    return result

def format_report(report):

    def f(value):
        return 'NA' if value is None else f'{value:.3f}'
    lines = ['=== AZURE704_BATCH2_RECOVERY_C6_RESULT ===', 'STATUS=' + report['status'], 'COMPARISON_RUN=' + report['comparison_run'], 'JOINT_PASS_OBSERVED=' + str(report['joint_pass_observed']), 'CHECKS=' + json.dumps(report['checks']), 'ONLINE_REQUESTS=' + str(report['online_requests']), 'POST_WARMUP_SLO_SAFE=' + str(report['post_warmup_online_slo_safe']), 'ENGINE_TOKEN_BUDGETS=' + json.dumps(report['observed_engine_token_budgets']), 'phase condition requests gap_samples gap_p99_ms TTFT_p95_ms tails errors safe']
    fields = ('requests', 'request_mean_stream_gap_samples', 'request_mean_stream_gap_p99_ms', 'ttft_p95_ms', 'requests_with_mean_stream_gap_over_slo', 'errors')
    for phase, data in report['phases'].items():
        for key in ('recovery_c5', 'recovery_c6'):
            lines.append(phase + ' ' + key + ' ' + ' '.join((f(data[key][field]) for field in fields)) + ' ' + str(data[key]['observed_slo_safe']))
    for key in ('batch', 'cohort_timing', 'client_batch_phase_counts', 'gpu_power'):
        lines.append(key.upper() + '=' + json.dumps(report[key]))
    lines.append('BATCH_ATTEMPTS=' + str(report['batch_attempts']))
    lines.append('ADMISSION=' + json.dumps({k: v for k, v in report['admission'].items() if not k.endswith('_ids')}))
    lines.append('DISPATCHES_AT_OR_AFTER_HORIZON=' + str(report['online_dispatches_at_or_after_horizon']))
    lines.append('UPSTREAM_INTERVAL_GROUPS=' + json.dumps(report['upstream_interval_context'].get('groups', report['upstream_interval_context'])))
    for key in ('client_tail_requests', 'client_tails_already_above_threshold_at_upstream_read', 'post_stream_parse_ms'):
        lines.append(key + '=' + json.dumps(report['stream_observation'][key]))
    lines.append('CONTROL_BATCH_LIMITS=' + json.dumps(report['control_batch_limits']))
    comparison = {}
    for label, item in report['cohort_comparison'].items():
        comparison[label] = {k: item['batch'][k] for k in ('jobs_completed_on_time', 'tokens_completed_on_time', 'jobs_completed_late', 'jobs_unfinished_or_failed')}
        comparison[label]['deadline_token_deficit'] = item['cohort_timing']['deadline_token_deficit']
    lines.append('COHORT_COMPARISON=' + json.dumps(comparison))
    lines.append('ROUTING=' + json.dumps(report['routing']))
    lines.append('SERVICE_AND_DEADLINE_PASS_OBSERVED=' + str(report['service_and_deadline_pass_observed']))
    lines.append('JOINT_PASS_DEFINITION=' + report['joint_pass_definition'])
    lines.append('DIAGNOSTIC_PHASE_SLO_SAFE=' + json.dumps(report['diagnostic_phase_slo_safe']))
    lines.append('POWER_CAP_OBSERVATIONS=' + json.dumps(report['power_cap_observations']))
    pair = report['paired_power']
    lines.append('PAIRED_EVENT_WINDOWS=' + json.dumps([{'window': r['window'], 'paired_reduction_w': r['paired_reduction_w'], 'reference_covered': r['reference']['covered'], 'treatment_covered': r['treatment']['covered'], 'maximum_sample_gap_s': {'reference': r['reference']['maximum_sample_gap_s'], 'treatment': r['treatment']['maximum_sample_gap_s']}} for r in pair['event_30s_windows']]))
    lines.append('PAIRED_POWER_SUMMARY=' + json.dumps({k: v for k, v in pair.items() if k != 'event_30s_windows'}))
    lines.append('FIRST_TEXT_ISOLATION=' + json.dumps(report['first_text_isolation']))
    lines.append('BATCH_OCCUPANCY=' + json.dumps(report['batch_occupancy']))
    lines.append('REFERENCE_SERVICE_AND_DEADLINE_PASS_OBSERVED=' + str(report['reference_service_and_deadline_pass_observed']))
    lines.append('CLIENT_BATCH_LIMITS=' + json.dumps(report['client_batch_limits']))
    rows = {}
    for label, row in report['recovery_comparison'].items():
        rows[label] = {'run': row['run'], 'event_concurrency': row['event_concurrency'], 'recovery_concurrency': row['recovery_concurrency'], 'service_and_deadline_pass_observed': row['service_and_deadline_pass_observed'], 'batch': row['batch'], 'cohort_timing': row['cohort_timing'], 'phase_latency': {p: {k: row['phases'][p][k] for k in ('ttft_p95_ms', 'request_mean_stream_gap_p99_ms', 'observed_slo_safe')} for p in ('event_time_reference', 'recovery', 'evaluation', 'recovery_middle')}, 'online_dispatches_at_or_after_horizon': row['online_dispatches_at_or_after_horizon']}
    lines.append('RECOVERY_COMPARISON=' + json.dumps(rows))
    lines.extend(report['limitations'])
    return '\n'.join(lines) + '\n'
if __name__ == '__main__':
    main()
