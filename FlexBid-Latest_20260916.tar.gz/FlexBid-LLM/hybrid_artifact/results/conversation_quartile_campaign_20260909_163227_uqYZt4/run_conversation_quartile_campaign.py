"""Run both prespecified same-policy power pairs once, in balanced order."""
import argparse
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import cohort_phase_measurement as m
from conversation_quartile_report import campaign_report

ORDER = (('001710', 400), ('001710', 300), ('001918', 300), ('001918', 400))
HELPERS = ('first_text_admission_tools.py', 'stream_trace_tools.py', 'stream_context_tools.py',
           'replica_batch_limit_tools.py', 'online_queue_priority_tools.py',
           'analyze_c6_ttft_decomposition.py', 'cohort_phase_dispatch.py', 'cohort_phase_measurement.py')
PROGRAMS = ('run_conversation_quartile_cell.py', 'conversation_quartile_cell.py')


def run_campaign(args):
    from flexbid_hybrid.service import stop_process
    output = args.output
    order = []
    for episode, cap in ORDER:
        inputs = args.input_root / ('azure_conversation_azure-' + episode)
        info = m.read_json(inputs / 'INPUT_SUMMARY.json')
        if info['episode_id'] != 'azure_conversation:azure-' + episode:
            raise ValueError('Prepared input identity differs: ' + str(inputs))
        order.append({'cell_name': 'azure' + episode + '_p' + str(cap),
                      'episode_id': info['episode_id'], 'event_cap_w': cap,
                      'input_root': str(inputs), 'online_requests': info['online_requests']})
    plan = {'status': 'PLANNED', 'order': order, 'policy_source_run': str(args.source),
            'duration_s_per_cell': 1950, 'fixed_workload_s_total': 7800,
            'cohort_jobs_per_cell': 280, 'batch_release_s': 150, 'batch_deadline_s': 1950,
            'event_batch_concurrency': 5, 'recovery_batch_concurrency': 6,
            'automatic_retry': False, 'external_commitment': False,
            'selection': 'Both remaining Conversation quartile candidates; no outcome-based replacement.'}
    m.write_json(output / 'EXPERIMENT_PLAN.json', plan)
    print('EXPERIMENT_ORDER=' + ','.join(r['cell_name'] for r in order), flush=True)
    for index, item in enumerate(order):
        cell = output / 'cells' / item['cell_name']
        (cell / 'logs').mkdir(parents=True)
        for name in HELPERS + PROGRAMS:
            shutil.copyfile(output / name, cell / name)
        began = time.time_ns()
        current = {**item, 'index': index, 'output': str(cell), 'state': 'STARTING', 'started_wall_ns': began}
        m.write_json(output / 'CURRENT_CELL.json', current)
        print('STARTING_CELL=' + item['cell_name'], flush=True)
        command = [sys.executable, '-B', '-u', str(cell / 'run_conversation_quartile_cell.py'),
                   '--project', str(args.project), '--source', str(args.source),
                   '--input-root', item['input_root'], '--output', str(cell),
                   '--event-cap', str(item['event_cap_w'])]
        env = dict(os.environ)
        env['PYTHONPATH'] = str(cell) + os.pathsep + env.get('PYTHONPATH', '')
        with (cell / 'logs/launcher.log').open('w', encoding='utf-8') as log:
            process = subprocess.Popen(command, cwd=args.project, env=env, stdout=log,
                                       stderr=subprocess.STDOUT, start_new_session=True)
            (cell / 'launcher.pid').write_text(str(process.pid) + '\n', encoding='utf-8')
            m.write_json(output / 'CURRENT_CELL.json', {**current, 'state': 'RUNNING', 'pid': process.pid})
            try:
                code = process.wait()
            finally:
                if process.poll() is None:
                    stop_process(process, timeout_s=180)
        m.write_json(cell / 'CELL_TIMING.json', {'started_wall_ns': began,
                     'finished_wall_ns': time.time_ns(), 'return_code': code})
        if code != 0:
            raise RuntimeError(f'{item["cell_name"]} exited with code {code}; see {cell / "logs/launcher.log"}')
        record = m.read_json(cell / 'REPORT.json')
        m.write_json(output / 'CURRENT_CELL.json', {**current, 'state': 'MEASURED', 'pid': process.pid})
        print('CELL_MEASURED=' + item['cell_name'] + ' SERVICE_AND_DEADLINE_PASS='
              + str(record['service_and_deadline_pass_observed']), flush=True)
    m.write_json(output / 'CURRENT_CELL.json', {'state': 'SUMMARIZING', 'completed_cells': len(order)})
    try:
        campaign_report(output, plan)
    except Exception as exc:
        m.write_json(output / 'ANALYSIS_FAILED.json', {'error_type': type(exc).__name__,
                     'error': str(exc), 'all_four_cells_measured': True, 'automatic_retry': False})
        raise
    print('CAMPAIGN_REPORT=' + str(output / 'REPORT.txt'), flush=True)


def main():
    parser = argparse.ArgumentParser()
    for name in ('project', 'source', 'input-root', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    for name in ('project', 'source', 'input_root', 'output'):
        setattr(args, name, getattr(args, name).resolve())
    sys.path.insert(0, str(args.project))
    sys.path.insert(0, str(args.project / 'scripts'))

    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'received signal {signum}')
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    try:
        run_campaign(args)
    except BaseException as exc:
        if not (args.output / 'ANALYSIS_FAILED.json').is_file():
            m.write_json(args.output / 'COLLECTION_FAILED.json', {'status': 'CONVERSATION_QUARTILE_CAMPAIGN_INTERRUPTED',
                         'error_type': type(exc).__name__, 'error': str(exc), 'automatic_retry': False})
        raise


if __name__ == '__main__':
    main()
