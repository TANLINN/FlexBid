"""Report all four cells and match power comparisons within each workload."""
import filecmp
import json
from pathlib import Path

import yaml
import cohort_phase_measurement as m
from conversation_quartile_cell import DISPLAY_PHASES, PROGRAMS
from conversation_quartile_power import paired_power_comparison

TIMING_FIELDS = ('duration_s', 'drain_s', 'cohort_release_offset_s', 'batch_admission_offset_s',
                 'event_batch_concurrency', 'recovery_batch_concurrency', 'recovery_start_offset_s')


def campaign_report(output, plan):
    output = Path(output)
    records = {item['cell_name']: m.read_json(output / 'cells' / item['cell_name'] / 'REPORT.json')
               for item in plan['order']}
    pairs = {}
    helpers = PROGRAMS + ('cohort_phase_measurement.py', 'cohort_phase_dispatch.py')
    for episode in dict.fromkeys(item['episode_id'] for item in plan['order']):
        items = {item['event_cap_w']: item for item in plan['order'] if item['episode_id'] == episode}
        paths = {cap: output / 'cells' / items[cap]['cell_name'] for cap in (400, 300)}
        rs = {cap: records[items[cap]['cell_name']] for cap in (400, 300)}
        protocols = {cap: m.read_json(paths[cap] / 'protocol.json') for cap in paths}
        configs = {cap: yaml.safe_load((paths[cap] / 'config.yaml').read_text(encoding='utf-8')) for cap in paths}
        checks = {
            'both_reports_match_selected_episode': all(row['episode_id'] == episode for row in rs.values()),
            'same_relative_timeline': all(protocols[400][k] == protocols[300][k] for k in TIMING_FIELDS),
            'same_service_configuration': m.normalized_configuration(configs[400]) == m.normalized_configuration(configs[300]),
            'same_gateway_helpers_and_request_execution': all(filecmp.cmp(paths[400] / name, paths[300] / name, shallow=False) for name in helpers),
            'same_saved_inputs': all(filecmp.cmp(paths[400] / name, paths[300] / name, shallow=False)
                                    for name in ('online_workload.jsonl', 'batch_jobs.jsonl')),
            'requested_cap_difference_observed': all(
                [(row['phase'], float(row['action']['power_cap_w'])) for row in rs[cap]['power_cap_observations']['transitions']]
                == [('warmup', 400.), ('event', float(cap)), ('recovery', 400.)]
                and rs[cap]['checks']['configured_gpu_caps_matched'] for cap in (400, 300)),
        }
        power = paired_power_comparison(paths[400], paths[300])
        interpretable = all(checks.values())
        service = all(row['service_and_deadline_pass_observed'] for row in rs.values())
        joint = (service and power['all_paired_event_windows_positive']) if interpretable else None
        pairs[episode] = {'checks': checks, 'comparison_interpretable': interpretable,
            'joint_pass_observed': joint,
            'all_main_phases_and_deadline_pass_both_conditions': all(row['all_main_phases_and_deadline_pass_observed'] for row in rs.values()),
            'all_recovery_subphases_and_deadline_pass_both_conditions': all(row['all_recovery_subphases_and_deadline_pass_observed'] for row in rs.values()),
            'paired_power': power}
    result = {'status': 'CONVERSATION_QUARTILE_CAMPAIGN_MEASURED', 'run': str(output), 'plan': plan,
              'cells': records, 'pairs': pairs, 'external_commitment': False, 'offered_bid_w': None,
              'limitations': [
                  'Two selected workloads from the same Conversation source; prior experimental use is unconfirmed.',
                  'Every planned condition is retained. One run per workload and cap does not establish reliability or significance.',
                  'Each P300 run is compared only with the matching workload P400; startup and run-order variation remain.',
                  'Aggregate service pass does not imply every warmup or recovery subsegment passes; all subsegments remain reported.',
                  'The SLO uses p99 across per-request mean nonempty SSE-text gaps, not individual token gaps.',
                  'Fixed 150/450/1950 s boundaries include control delays. Cohorts first enter at 150 s, with no pre-existing batch load.',
                  'Length-matched token workloads retain their saved arrivals and dependencies; original prompt semantics are not evaluated.',
                  'This measures fixed-policy operating behavior, not an adaptive offer or statistical delivery guarantee.'
              ]}
    lines = ['=== CONVERSATION_QUARTILE_CAMPAIGN_RESULT ===', 'STATUS=' + result['status'],
             'RUN=' + str(output), 'ORDER=' + json.dumps(plan['order'], ensure_ascii=False)]
    for item in plan['order']:
        row = records[item['cell_name']]
        lines.append('CELL_RESULT=' + json.dumps({'cell': item['cell_name'], 'episode_id': row['episode_id'],
            'event_cap_w': item['event_cap_w'], 'run': row['run'],
            'online_requests': row['online_requests'], 'online_incomplete_or_error_count': row['online_incomplete_or_error_count'],
            'failed_checks': row['failed_checks'], 'service_and_deadline_pass': row['service_and_deadline_pass_observed'],
            'all_main_phases_and_deadline_pass': row['all_main_phases_and_deadline_pass_observed'],
            'all_recovery_subphases_and_deadline_pass': row['all_recovery_subphases_and_deadline_pass_observed'],
            'batch': row['batch'], 'cohort_timing': row['cohort_timing'], 'gpu_power': row['gpu_power'],
            'batch_phase_dispatch': row['batch_phase_dispatch']}, ensure_ascii=False))
        lines.append('phase cell requests TTFT_p95_ms mean_gap_p99_ms TTFT_tails gap_tails errors safe')
        for phase in DISPLAY_PHASES:
            p = row['phases'][phase]
            lines.append(' '.join(map(str, (phase, item['cell_name'], p['requests'], p['ttft_p95_ms'],
                p['request_mean_stream_gap_p99_ms'], p['requests_with_ttft_over_slo'],
                p['requests_with_mean_stream_gap_over_slo'], p['errors'], p['observed_slo_safe']))))
    for episode, pair in pairs.items():
        lines.append('PAIR_RESULT=' + json.dumps({'episode_id': episode, **{k: v for k, v in pair.items() if k != 'paired_power'}}, ensure_ascii=False))
        power = pair['paired_power']
        for window in power['event_30s_windows']:
            lines.append('PAIRED_EVENT_WINDOW=' + json.dumps({'episode_id': episode, **window}))
        lines.append('PAIRED_POWER_SUMMARY=' + json.dumps({'episode_id': episode, **{k: v for k, v in power.items() if k != 'event_30s_windows'}}))
    lines.extend(result['limitations'])
    m.write_json(output / 'REPORT.json', result)
    (output / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return result
