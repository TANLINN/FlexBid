"""Receipt-visible decision observation without an actuator."""
import time
from core_visible_state import build_state
from core_plan_comparison import rank


def decision_state(jobs, dispatches, results, snapshots, power, cutoff_ns, deadline_ns,
                   group, actions=()):
    state=build_state(jobs,dispatches,results,snapshots,power,cutoff_ns,deadline_ns)
    state['group']=group
    visible_actions=[r for r in actions if r['receipt_wall_time_ns']<=cutoff_ns and r['end_wall_ns']<=cutoff_ns]
    if visible_actions:
        latest=max(visible_actions,key=lambda r:r['end_wall_ns'])
        state.update(x_p_w=latest['action']['power_cap_w'],x_c=latest['action']['batch_concurrency'])
    return state


def score_state(state, cutoff_ns, deadline_ns, score_candidates):
    record={'cutoff_wall_ns':cutoff_ns,'state':state,'actuation_performed':False}
    if cutoff_ns>=deadline_ns:
        return {**record,'status':'DEADLINE_REACHED','best_point_plan':None}
    if state['all_jobs_complete_on_time']:
        return {**record,'status':'COHORT_COMPLETE','best_point_plan':None}
    begin=time.perf_counter()
    candidates=score_candidates(dict(state),cutoff_ns)
    ordered=rank(candidates)
    return {**record,'status':'SHADOW_POINT_CHOICE' if ordered else 'SHADOW_NO_POINT_FEASIBLE_PLAN',
            'evaluation_seconds':time.perf_counter()-begin,'candidates':candidates,
            'best_point_plan':ordered[0] if ordered else None}


def observe(jobs, dispatches, results, snapshots, power, cutoff_ns, deadline_ns,
            group, score_candidates, actions=()):
    state=decision_state(jobs,dispatches,results,snapshots,power,cutoff_ns,deadline_ns,group,actions)
    return score_state(state,cutoff_ns,deadline_ns,score_candidates)

