"""Bind fitted response models to the receipt-visible shadow observer."""
from core_plan_trajectory import evaluate_plan
from core_plan_comparison import summarize


def schedules(second):
    if second>=450:
        return [(f'recovery_c{c}',[{'start_s':second,'phase':'recovery','p_w':400,'c':c}]) for c in (5,6)]
    return [(f'p{p}_event_c{ec}_recovery_c{rc}',[
        {'start_s':second,'phase':'event','p_w':p,'c':ec},
        {'start_s':450,'phase':'recovery','p_w':400,'c':rc}])
        for p in (300,350,400) for ec in (5,6) for rc in (5,6)]


class ShadowScorer:
    def __init__(self, transitions, responses, idle_transitions, idle_responses, start_ns, deadline_ns):
        if deadline_ns-start_ns!=1950*1_000_000_000:
            raise ValueError('Expected the existing 1950-second protocol')
        self.models=(transitions,responses,idle_transitions,idle_responses)
        self.start_ns=start_ns

    def __call__(self,state,cutoff_ns):
        return list(self.iter_candidates(state,cutoff_ns))

    def iter_candidates(self,state,cutoff_ns):
        elapsed=cutoff_ns-self.start_ns
        if elapsed % (30*1_000_000_000) or elapsed<150*1_000_000_000 or elapsed>=1950*1_000_000_000:
            raise ValueError('Use a planned 30-second cutoff inside the evaluation horizon')
        second=elapsed//1_000_000_000
        current=(state['x_p_w'],state['x_c'])
        tm,rm,itm,irm=self.models
        for name,schedule in schedules(second):
            plan=evaluate_plan(tm,rm,state,int(second),schedule,exhausted_transitions=itm,exhausted_responses=irm)
            yield summarize(name,plan,current)

