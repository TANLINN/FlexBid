"""Check scorer adapter against archived candidate predictions."""
import json
import math
from pathlib import Path
import sys
from core_response_model import load_windows,fit_models
from core_recovery_rollout import fit
from evaluate_core_event_rollout import fit_event_transitions
from evaluate_core_complete_energy import fit_post_cohort
from evaluate_core_response_model import annotate_service_labels
from core_shadow_scorer import ShadowScorer


def evaluate(dataset,reference,output):
    old=json.loads((reference/'REPORT.json').read_text(encoding='utf-8'))
    metadata=json.loads((dataset/'REPORT.json').read_text(encoding='utf-8'))
    source=Path(old['source'])
    protocol=json.loads((source/'protocol.json').read_text(encoding='utf-8'))
    identity=json.loads((source/'REPORT.json').read_text(encoding='utf-8'))['episode_id']
    state=dict(old['plans'][0]['records'][0]['state'])
    state['x_p_w'],state['x_c']=old['initial_action']
    allowed={r['run'] for r in metadata['runs'] if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    training=[r for r in load_windows(dataset/'action_windows.csv') if r['run'] in allowed and r['group']==state['group'] and r['episode_id']!=identity]
    annotate_service_labels(training)
    itm,irm,_=fit_post_cohort(training)
    scorer=ShadowScorer({**fit_event_transitions(training),**fit(training)},fit_models(training),itm,irm,
                        int(protocol['start_wall_ns']),int(protocol['deadline_wall_ns']))
    actual=scorer(state,int(protocol['start_wall_ns'])+int(old['origin_s'])*1_000_000_000)
    expected={r['name']:r for r in old['candidates'] if r['name']!='measured_schedule'}
    if {r['name'] for r in actual}!=set(expected):raise ValueError('Candidate names differ')
    checked=0
    for row in actual:
        prior=expected[row['name']]
        for key in ('complete_prediction','point_constraints_satisfied','outside_training_range','missing_features','completion_slot_end_s','switches'):
            if row[key]!=prior[key]:raise ValueError(f'Candidate mismatch: {row["name"]} {key}')
            checked+=1
        for key in ('event_energy_wh','full_energy_wh','remaining_at_deadline','max_predicted_ttft_ms','max_predicted_gap_ms'):
            a,b=row[key],prior[key]
            if (a is None)!=(b is None) or (a is not None and not math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-7)):
                raise ValueError(f'Numeric mismatch: {row["name"]} {key}')
            checked+=1
    result={'status':'CORE_SHADOW_SCORER_VALIDATED','candidates':len(actual),'checked_fields':checked,
            'reference':str(reference),'held_identity':identity,'gpu_workload':False,'installed':False,'actuation':False,
            'scope':'Saved-model scoring parity and synthetic receipt-visibility tests; not live collection or full MPC.'}
    output.mkdir(parents=True,exist_ok=True)
    (output/'REPORT.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('=== CORE_SHADOW_SCORER ===');print(json.dumps(result));print('REPORT_JSON='+str(output/'REPORT.json'))


if __name__=='__main__':evaluate(*map(Path,sys.argv[1:]))
