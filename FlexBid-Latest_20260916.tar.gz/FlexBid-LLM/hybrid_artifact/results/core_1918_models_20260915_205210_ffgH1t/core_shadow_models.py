"""Load pre-fitted models for a shadow observation run."""
import json
from pathlib import Path

from core_shadow_scorer import ShadowScorer


def load_scorer(path, start_ns, deadline_ns):
    value = json.loads(Path(path).read_text(encoding='utf-8'))
    transitions = {tuple(row['key']): row['targets'] for row in value['transitions']}
    idle = {tuple(row['key']): row['targets'] for row in value['idle_transitions']}
    return ShadowScorer(transitions, value['responses'], idle, value['idle_responses'],
                        start_ns, deadline_ns)
