"""Serial shadow observations at fixed experiment boundaries."""
import asyncio
from copy import deepcopy
import time

from core_shadow_feed import ShadowFeed


async def run_shadow(feed, start_ns, emit, stop, clock=time.time_ns,
                     sleep=asyncio.sleep):
    for second in range(150, 1950, 30):
        if stop.is_set():
            return
        cutoff = start_ns + second * 1_000_000_000
        while clock() < cutoff:
            if stop.is_set():
                return
            await sleep(min(.1, (cutoff-clock())/1e9))
        if stop.is_set():
            return
        began = clock()
        if began >= cutoff + 30_000_000_000:
            emit({'status': 'SHADOW_SLOT_SKIPPED', 'cutoff_wall_ns': cutoff,
                  'scoring_started_wall_ns': began, 'actuation_performed': False})
            continue
        # Copy on the collector thread; scoring never reads changing buffers.
        frozen = ShadowFeed(feed.jobs, feed.deadline_ns, feed.group, feed.scorer,
                            clock=lambda: began)
        frozen.records = deepcopy(feed.records)
        record = await asyncio.to_thread(frozen.decision, cutoff)
        finished = clock()
        emit({**record, 'scoring_started_wall_ns': began,
              'scoring_finished_wall_ns': finished,
              'late_for_next_slot': finished >= cutoff+30_000_000_000})
        if record['status'] in ('COHORT_COMPLETE', 'DEADLINE_REACHED'):
            return
