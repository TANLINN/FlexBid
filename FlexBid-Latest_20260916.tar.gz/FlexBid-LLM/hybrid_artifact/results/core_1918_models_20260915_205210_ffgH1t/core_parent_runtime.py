"""Parent-owned power and gateway operations for a running experiment."""
import time
from core_parent_control import ParentControl


class ParentRuntime:
    def __init__(self, output, power_manager, select_action, write_gateway, read_gateway,
                 emit_action, start_ns, initial_p=400, initial_c=0):
        self.manager=power_manager;self.select=select_action
        self.write=write_gateway;self.read=read_gateway;self.emit=emit_action
        self.start=start_ns;self.p=initial_p;self.c=initial_c
        self.server=ParentControl(output,self.power,self.gateway)

    def power(self,p):
        if p not in (300,350,400):raise ValueError('Unsupported power')
        began=time.time_ns()
        caps=self.manager.set_all(p)
        self.p=p
        self.emit({'phase':'event' if began-self.start<450*10**9 else 'recovery',
                   'operation':'power','begin_wall_ns':began,'end_wall_ns':time.time_ns(),
                   'action':self.select(self.p,self.c).as_dict(),
                   'enforced_power_caps_w':caps})
        return caps

    def gateway(self,c,priority):
        if c not in (5,6):raise ValueError('Unsupported concurrency')
        phase='event' if time.time_ns()-self.start<450*10**9 else 'recovery'
        if priority != (phase=='recovery' and c==6):raise ValueError('Queue priority differs from phase')
        began=time.time_ns()
        expected=self.write(self.select(self.p,c),priority)
        keys=('online_replica_ids','batch_replica_ids','batch_paused','online_concurrency',
              'batch_concurrency','defer_batch_for_online_queue')
        limit=time.monotonic()+2
        while True:
            actual=self.read()
            if all(actual.get(k)==expected[k] for k in keys):break
            if time.monotonic()>=limit:raise TimeoutError('Gateway refresh not acknowledged')
            time.sleep(.01)
        self.c=c
        self.emit({'phase':phase,'operation':'gateway','begin_wall_ns':began,
                   'end_wall_ns':time.time_ns(),'action':self.select(self.p,c).as_dict(),'control':expected})
        return actual

    def tick(self):return self.server.poll()
    def close(self):self.server.close()

