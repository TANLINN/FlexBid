import unittest
from core_candidate_solver import CandidateSolver

NS=10**9

class FakeScorer:
    def iter_candidates(self, state, cutoff):
        for c, energy in ((5,20),(6,10)):
            yield dict(name=f'recovery_c{c}',point_constraints_satisfied=state.get('feasible',True),
                       event_energy_wh=0,full_energy_wh=energy,switches=0)

class SolverTests(unittest.TestCase):
    def solve(self,state=None,**kwargs):
        return CandidateSolver(FakeScorer(),0,1950*NS,**kwargs).solve(
            state or {'all_jobs_complete_on_time':False},450*NS)
    def test_first_action_and_complete_search(self):
        r=self.solve()
        self.assertEqual(r['first_action'],dict(start_s=450,phase='recovery',p_w=400,c=6))
        self.assertEqual(len(r['candidates']),2)
        self.assertFalse(r['actuation_performed'])
    def test_no_feasible_action(self):
        self.assertIsNone(self.solve({'all_jobs_complete_on_time':False,'feasible':False})['first_action'])
    def test_expired_partial_search_has_no_action(self):
        times=iter([0,0,11,11])
        r=self.solve(clock=lambda:next(times))
        self.assertEqual(r['status'],'SOLVE_BUDGET_EXCEEDED')
        self.assertIsNone(r['first_action'])
    def test_completed_and_deadline(self):
        self.assertEqual(self.solve({'all_jobs_complete_on_time':True})['status'],'COHORT_COMPLETE')
        r=CandidateSolver(FakeScorer(),0,1950*NS).solve({},1950*NS)
        self.assertEqual(r['status'],'DEADLINE_REACHED')

if __name__=='__main__': unittest.main()

