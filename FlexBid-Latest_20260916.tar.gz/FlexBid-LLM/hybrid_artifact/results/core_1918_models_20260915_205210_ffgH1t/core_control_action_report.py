"""Match controller selections to recorded first-action acknowledgements."""
from collections import Counter


def summarize(rows):
    solutions={};applications={};issues=[];failed=[]
    for row in rows:
        status=row.get('status')
        if status in ('CONTROL_SOLUTION','CONTROL_APPLICATION'):
            index=solutions if status=='CONTROL_SOLUTION' else applications
            key=row['cutoff_wall_ns']
            if key in index:issues.append({'cutoff_wall_ns':key,'issue':'duplicate '+status})
            index[key]=row
        if status=='ACTION_FAILED':failed.append(row)
    counts=Counter(r['solution']['status'] for r in solutions.values())
    acknowledged=0;unapplied=[]
    for cutoff,row in solutions.items():
        chosen=row['solution']
        applied=applications.get(cutoff)
        if chosen['status']!='POINT_PLAN_SELECTED':
            if applied is not None:issues.append({'cutoff_wall_ns':cutoff,'issue':'application without selected plan'})
            continue
        if applied is None:
            unapplied.append(cutoff);continue
        result=applied['result']
        if result['status']!='ACTION_ACKNOWLEDGED':
            issues.append({'cutoff_wall_ns':cutoff,'issue':'application not acknowledged'});continue
        if result.get('action')!=chosen['first_action']:
            issues.append({'cutoff_wall_ns':cutoff,'issue':'applied action differs from selected first action'});continue
        if not cutoff<=result['wall_ns']<cutoff+30*10**9:
            issues.append({'cutoff_wall_ns':cutoff,'issue':'acknowledgement outside slot'});continue
        acknowledged+=1
    for cutoff in applications.keys()-solutions.keys():
        issues.append({'cutoff_wall_ns':cutoff,'issue':'application without decision'})
    return {'decisions':len(solutions),'solution_statuses':dict(counts),
            'acknowledged_selections':acknowledged,'selected_without_application':unapplied,
            'action_failures':failed,'record_issues':issues,
            'controller_records_consistent':bool(solutions) and not issues and not failed and not unapplied,
            'scope':'Controller records only; parent cap read-backs and receipt-visible states require separate verification.'}

