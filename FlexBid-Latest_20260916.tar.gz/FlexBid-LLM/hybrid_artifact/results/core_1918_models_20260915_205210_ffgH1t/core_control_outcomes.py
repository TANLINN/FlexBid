"""Original request, whole-job and power metrics independent of action schedule."""
import json
from pathlib import Path


def evaluate(output, measure, config):
    output=Path(output)
    protocol=measure.read_json(output/'protocol.json')
    online=measure.read_rows(output/'online.jsonl')
    jobs=measure.read_rows(output/'batch_jobs.jsonl')
    batch=measure.cohort_summary(jobs,measure.read_rows(output/'batch.jsonl'),protocol)
    ttft=float(config['slos']['default']['ttft_ms'])
    gap=float(config['slos']['default']['tpot_ms'])
    phases={}
    for name,(left,right) in measure.PHASES.items():
        selected=measure.select_phase(online,left,right)
        phases[name]=measure.latency_summary(selected,ttft,gap)
        phases[name]['requests_with_ttft_over_slo']=sum(r.get('ttft_ms') is not None and float(r['ttft_ms'])>ttft for r in selected)
    power=measure.gpu_series(output)
    stages={name:measure.power_window(power,left,right) for name,left,right in
            [('event',150,450),('recovery',450,1950),('evaluation',150,1950)]}
    planned=measure.read_rows(output/'online_workload.jsonl')
    indexed={r['request_id']:r for r in online}
    expected={r['request_id']:r for r in planned}
    metadata=('arrival_ms','prompt_tokens','max_output_tokens','parent_request_id','tool_delay_ms')
    matched=len(indexed)==len(online) and len(expected)==len(planned) and set(indexed)==set(expected)
    matched=matched and all(r.get(k)==expected[key].get(k) for key,r in indexed.items() for k in metadata)
    complete=matched and all(r.get('error') is None and r.get('status_code')==200 and r.get('completion_tokens')==r['max_output_tokens'] for r in online)
    return {'status':'CORE_CONTROL_OUTCOMES_EXTRACTED','run':str(output),'phases':phases,'batch':batch,
            'gpu_power':{'boundary':'aggregate_gpu_power_w','stages':stages},
            'online_metadata_matched':matched,'online_outputs_complete':complete,
            'service_metrics_and_deadline_pass':complete and batch['all_jobs_completed_by_deadline'] and all(phases[p]['observed_slo_safe'] for p in ('evaluation','event_time_reference','recovery')),
            'scope':'Outcome metrics only. Action execution, service configuration and receipt audit are separate; not a full joint-pass report.'}


def compare_saved(output,measure,config):
    report=evaluate(output,measure,config)
    saved=measure.read_json(Path(output)/'REPORT.json')
    differences=[]
    for key in ('phases','batch','gpu_power'):
        if report[key]!=saved[key]:differences.append(key)
    return report, differences

