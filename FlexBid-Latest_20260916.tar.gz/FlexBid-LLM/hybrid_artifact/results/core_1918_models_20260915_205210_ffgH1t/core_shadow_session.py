"""Coordinate request execution, file telemetry and shadow observations."""
import asyncio

from core_shadow_loop import run_shadow
from core_shadow_telemetry import TelemetryFiles


async def run_session(feed, start_ns, output, workload, emit_decision, interval=.1, *, controller=None):
    """Workload is an async factory already bound to the feed callbacks."""
    if interval <= 0:
        raise ValueError('Telemetry interval must be positive')
    reader = TelemetryFiles(output, feed)
    reader.poll()
    stop = asyncio.Event()

    async def requests():
        try:
            return await workload()
        finally:
            stop.set()

    async def telemetry():
        while not stop.is_set():
            reader.poll()
            try:
                await asyncio.wait_for(stop.wait(), interval)
            except asyncio.TimeoutError:
                pass
        reader.poll()

    control = (run_shadow(feed, start_ns, emit_decision, stop, clock=feed.clock)
               if controller is None else controller(stop))
    tasks = [asyncio.create_task(requests()), asyncio.create_task(telemetry()),
             asyncio.create_task(control)]
    try:
        done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
        for task in tasks:
            if task in done:
                task.result()
        return tasks[0].result()
    finally:
        stop.set()
        for task in tasks[:2]:
            if not task.done():
                task.cancel()
        # A running thread cannot be cancelled; let its snapshot scoring finish.
        await asyncio.gather(*tasks, return_exceptions=True)

