"""Evaluate an explicit P/C schedule with point-model state recursion."""
from core_recovery_rollout import advance
from core_response_model import predict


def evaluate_plan(transitions, responses, origin, start_s, schedule, deadline_s=1950,
                  exhausted_transitions=None, exhausted_responses=None):
    if start_s >= deadline_s or (deadline_s-start_s) % 30:
        raise ValueError('Plan must cover complete 30-second slots')
    if not schedule or schedule[0]['start_s'] > start_s:
        raise ValueError('Schedule does not cover the origin')
    if any(b['start_s'] <= a['start_s'] for a, b in zip(schedule, schedule[1:])):
        raise ValueError('Schedule boundaries must be increasing')
    if any(start_s < a['start_s'] < deadline_s and (a['start_s']-start_s) % 30 for a in schedule):
        raise ValueError('Action boundary falls inside a prediction slot')
    current = dict(origin)
    records = []
    finish = start_s if current['x_remaining_jobs'] == 0 else None
    status = 'POINT_PLAN_EVALUATED'
    for second in range(start_s, deadline_s, 30):
        action = next(a for a in reversed(schedule) if a['start_s'] <= second)
        current = {**current, 'phase': action['phase'], 'x_p_w': action['p_w'], 'x_c': action['c']}
        is_exhausted = current['x_remaining_jobs'] == 0
        if is_exhausted and (exhausted_transitions is None or exhausted_responses is None):
            # Training labels exclude demand-exhausted windows; zero batch demand is not zero GPU power.
            status = 'COHORT_PREDICTED_COMPLETE_RESPONSE_UNSUPPORTED_AFTER_EXHAUSTION'
            break
        if is_exhausted:
            current = {**current, 'x_batch_active_gateway': 0., 'x_batch_waiting': 0.,
                       'x_oldest_batch_dispatch_age_s': None}
            if len(records) >= 2:
                current['x_recent60_completed_jobs'] = sum(r['completed_in_step'] for r in records[-2:])
        response = predict(exhausted_responses if is_exhausted else responses, current)
        nxt = advance(exhausted_transitions if is_exhausted else transitions, current)
        if nxt is None:
            status = 'NO_TRAINING_TRANSITION'
            break
        records.append({'start_s': second, 'end_s': second+30,
                        'action': dict(action), 'state': current, 'response': response,
                        'regime': 'post_cohort' if is_exhausted else 'active_batch',
                        'completed_in_step': current['x_remaining_jobs']-nxt['x_remaining_jobs'],
                        'remaining_jobs_end': nxt['x_remaining_jobs']})
        current = nxt
        if current['x_remaining_jobs'] == 0 and finish is None:
            finish = second+30
    full = len(records) == (deadline_s-start_s)//30
    covered_power = all(r['response']['values'].get('y_mean_gpu_w') is not None for r in records)
    predicted_energy = sum(r['response']['values']['y_mean_gpu_w']*30/3600 for r in records) if covered_power else None
    return {'status': status, 'records': records, 'predicted_completion_slot_end_s': finish,
            'predicted_remaining_at_deadline': current['x_remaining_jobs'] if full or finish is not None else None,
            'response_end_s': records[-1]['end_s'] if records else start_s,
            'predicted_energy_over_response_prefix_wh': predicted_energy,
            'predicted_full_horizon_energy_wh': predicted_energy if full else None}
