import asyncio
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from core_batch_control import change_concurrency, publish_limit, write_json


class ControlTests(unittest.IsolatedAsyncioTestCase):
    async def test_separate_process_applies_changes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            worker = '''import asyncio, sys
from pathlib import Path
from core_dynamic_batch import BatchAdmission
from core_batch_control import follow_control
async def main():
    root=Path(sys.argv[1])
    stop=asyncio.Event()
    async def finish():
        while not (root/'stop').exists():
            await asyncio.sleep(.01)
        stop.set()
    await asyncio.gather(follow_control(BatchAdmission(0),root/'control',root/'ack',stop),finish())
asyncio.run(main())
'''
            process = subprocess.Popen([sys.executable, '-B', '-c', worker, directory],
                                       cwd=Path(__file__).resolve().parent,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                for sequence, limit in enumerate([5, 6, 2, 0, 5]):
                    await publish_limit(root/'control', root/'ack', sequence, limit, timeout=5)
                (root/'stop').touch()
                stdout, stderr = await asyncio.to_thread(process.communicate, timeout=5)
                self.assertEqual(process.returncode, 0, stderr.decode())
            finally:
                if process.poll() is None:
                    process.kill()
                    process.communicate()

    async def test_stale_ack_does_not_succeed(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            write_json(root/'ack', {'sequence': 1, 'batch_concurrency': 5})
            with self.assertRaises(asyncio.TimeoutError):
                await publish_limit(root/'control',root/'ack',2,5,timeout=.03)

    async def test_order_and_failure_propagation(self):
        calls=[]
        async def client(c): calls.append(('client',c))
        async def gateway(c): calls.append(('gateway',c))
        await change_concurrency(5,6,client,gateway)
        await change_concurrency(6,0,client,gateway)
        self.assertEqual(calls,[('gateway',6),('client',6),('client',0),('gateway',0)])
        calls.clear()
        async def failed_client(c): raise asyncio.TimeoutError()
        with self.assertRaises(asyncio.TimeoutError):
            await change_concurrency(6,5,failed_client,gateway)
        self.assertEqual(calls,[])


if __name__ == '__main__':
    unittest.main()

