import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from core_control_report import build


class ReportTests(unittest.TestCase):
    def test_outcome_success_does_not_certify_missing_execution(self):
        with tempfile.TemporaryDirectory() as d:
            with patch('core_control_report.evaluate',return_value={'service_metrics_and_deadline_pass':True}):
                result=build(d,None,{})
            self.assertIsNone(result['full_joint_pass'])
            self.assertIsNone(result['controller'])
            self.assertFalse(result['collection_complete'])
    def test_failure_is_retained_with_completion_markers(self):
        with tempfile.TemporaryDirectory() as d:
            for n in ('CONTROL_COMPLETE.json','workload_complete.json','control_decisions.jsonl'):(Path(d)/n).touch()
            with patch('core_control_report.evaluate',return_value={'service_metrics_and_deadline_pass':False}):
                result=build(d,SimpleNamespace(read_rows=lambda p:[]),{})
            self.assertTrue(result['collection_complete'])
            self.assertFalse(result['service_metrics_and_deadline_pass'])
            self.assertFalse(result['controller']['controller_records_consistent'])

if __name__=='__main__':unittest.main()

