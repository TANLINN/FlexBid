import asyncio
import tempfile
import unittest
from pathlib import Path

from core_actuation_bindings import ActuationBindings
from core_first_action import FirstActionExecutor
from core_batch_control import follow_control
from core_dynamic_batch import BatchAdmission


class BindingTests(unittest.IsolatedAsyncioTestCase):
    async def test_power_gateway_client_receipts(self):
        with tempfile.TemporaryDirectory() as d:
            stop=asyncio.Event();admission=BatchAdmission(0);saved={};powers=[]
            class Power:
                def set_all(self,p):
                    powers.append(p);return {i:p-.5 for i in range(8)}
            def write(action,priority):
                saved.update(online_replica_ids=[0,1,2,3],batch_replica_ids=[0,1,2,3],
                             batch_paused=False,online_concurrency=12,batch_concurrency=action[1],
                             defer_batch_for_online_queue=priority)
                return dict(saved)
            b=ActuationBindings(Path(d),Power(),lambda p,c:(p,c),write,lambda:dict(saved))
            follower=asyncio.create_task(follow_control(admission,Path(d)/'batch_control.json',Path(d)/'batch_ack.json',stop))
            try:
                ex=FirstActionExecutor(400,0,b.client,b.gateway,b.power,lambda r:None,clock=lambda:0)
                result=await ex.apply({'status':'POINT_PLAN_SELECTED','first_action':{'p_w':300,'c':5,'phase':'event'}},100)
                self.assertEqual(result['status'],'ACTION_ACKNOWLEDGED')
                self.assertEqual(admission.limit,5);self.assertEqual(powers,[300])
                self.assertEqual(b.sequence,1)
            finally:
                stop.set();await follower

    async def test_stale_gateway_feedback_is_not_ack(self):
        desired=dict(online_replica_ids=[0],batch_replica_ids=[0],batch_paused=False,
                     online_concurrency=12,batch_concurrency=6,defer_batch_for_online_queue=True)
        b=ActuationBindings(Path('.'),None,lambda p,c:None,lambda a,q:desired,
                            lambda:{**desired,'batch_concurrency':5},gateway_timeout=.02)
        with self.assertRaises(asyncio.TimeoutError):await b.gateway(6,True)

if __name__=='__main__':unittest.main()

