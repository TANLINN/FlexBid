"""Held-identity response fits for recorded post-cohort windows."""
from collections import defaultdict
import json
from pathlib import Path
import sys
from core_response_model import load_windows, action_key, fit_selected, predict, finite
from evaluate_core_response_model import annotate_service_labels

TARGETS=('y_mean_gpu_w','y_ttft_p95_ms','y_gap_p99_ms')


def exhausted(row):
    return (row['phase']=='recovery' and row['segment_action_constant']
            and all(finite(row.get(k)) and row[k]==0 for k in (
                'x_remaining_jobs','x_batch_inflight_client','x_batch_active_gateway','x_batch_waiting')))


def label_ok(row,target):
    if not finite(row.get(target)):return False
    if target=='y_mean_gpu_w':return row['y_power_covered']
    return row.get('service_labels_cross_transition') is False and row.get(
        'y_ttft_samples' if target=='y_ttft_p95_ms' else 'y_gap_samples',0)>0


def evaluate(dataset,output):
    metadata=json.loads((dataset/'REPORT.json').read_text())
    allowed={r['run'] for r in metadata['runs'] if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    all_rows=[r for r in load_windows(dataset/'action_windows.csv') if r['run'] in allowed]
    annotate_service_labels(all_rows)
    selected=[r for r in all_rows if exhausted(r)]
    records=[]
    for identity in sorted({r['episode_id'] for r in all_rows}):
        groups=defaultdict(list)
        for r in selected:
            if r['episode_id']!=identity:groups[action_key(r)].append(r)
        models=[{'key':list(key),'targets':{t:fit_selected([r for r in values if label_ok(r,t)],t) for t in TARGETS}}
                for key,values in groups.items()]
        for row in selected:
            if row['episode_id']!=identity:continue
            prediction=predict(models,row)
            records.append({'run':row['run'],'episode_id':identity,'start_s':row['start_s'],
                'action':list(action_key(row)), 'prediction':prediction,
                'observed':{t:row[t] if label_ok(row,t) else None for t in TARGETS}})
    summaries=[]
    for identity,key in sorted({(r['episode_id'],tuple(r['action'])) for r in records}):
        subset=[r for r in records if r['episode_id']==identity and tuple(r['action'])==key]
        metrics={}
        for target in TARGETS:
            errors=[r['prediction']['values'][target]-r['observed'][target] for r in subset
                    if target in r['prediction']['values'] and r['observed'][target] is not None]
            metrics[target]={'scored':len(errors),'unscored':len(subset)-len(errors),
                'mae':sum(abs(e) for e in errors)/len(errors) if errors else None,
                'bias':sum(errors)/len(errors) if errors else None}
        service=[r for r in subset if all(r['observed'][t] is not None and t in r['prediction']['values'] for t in TARGETS[1:])]
        violations=sum(r['observed'][TARGETS[1]]>5000 or r['observed'][TARGETS[2]]>100 for r in service)
        false_safe=sum((r['observed'][TARGETS[1]]>5000 or r['observed'][TARGETS[2]]>100) and
                       r['prediction']['values'][TARGETS[1]]<=5000 and r['prediction']['values'][TARGETS[2]]<=100 for r in service)
        summaries.append({'identity':identity,'action':list(key),'windows':len(subset),'runs':len({r['run'] for r in subset}),
                          'metrics':metrics,'service_scored':len(service),'violations':violations,'false_safe':false_safe})
    notes=[
        'Post-cohort eligibility requires zero remaining jobs, zero client batch in flight, zero gateway batch active and waiting, and constant recovery action.',
        'Configured C5/C6 remain distinct action keys; no unsupported C0 label or zero-power assumption is introduced.',
        'Same ridge=1, features and identity/run weighting as the existing response fits. All repeats of the evaluation identity are held out.',
        'This separate response model uses post-cohort rows previously excluded from active-batch fitting; it does not modify active-batch labels.',
        'These are one-step responses at observed states, not post-exhaustion state trajectories or complete-horizon energy validation.',
        'Sparse or missing action/identity coverage remains unscored; zero observed violations cannot establish failure-detection ability.',
        'No GPU, retry, active installation or keepalive change.']
    result={'status':'CORE_EXHAUSTED_RESPONSE_EVALUATED','dataset':str(dataset),'total_rows':len(all_rows),
            'post_cohort_rows':len(selected),'groups':summaries,'notes':notes}
    output.mkdir(parents=True,exist_ok=True)
    (output/'REPORT.json').write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    (output/'records.jsonl').write_text(''.join(json.dumps(r,allow_nan=False)+'\n' for r in records),encoding='utf-8')
    lines=['=== CORE_EXHAUSTED_RESPONSE ===','STATUS='+result['status'],'POST_COHORT_ROWS='+str(len(selected))]
    lines+=['GROUP='+json.dumps(r) for r in summaries]+notes+['REPORT_JSON='+str(output/'REPORT.json')]
    (output/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8');print('\n'.join(lines))


if __name__=='__main__':evaluate(*map(Path,sys.argv[1:]))
