"""Read appended measurement files without issuing telemetry queries."""
import csv
import io
import json
import math
from pathlib import Path


class AppendedLines:
    def __init__(self, path):
        self.path = Path(path)
        self.offset = 0
        self.pending = b''

    def read(self):
        try:
            with self.path.open('rb') as stream:
                if stream.seek(0, 2) < self.offset:
                    raise ValueError('Measurement file was truncated: '+str(self.path))
                stream.seek(self.offset)
                chunk = stream.read()
                self.offset = stream.tell()
        except FileNotFoundError:
            if self.offset:
                raise
            return []
        parts = (self.pending+chunk).split(b'\n')
        self.pending = parts.pop()
        return [part.decode('utf-8').rstrip('\r') for part in parts if part.strip()]


class TelemetryFiles:
    def __init__(self, output, feed):
        self.feed = feed
        self.sources = {kind: AppendedLines(Path(output)/name) for kind, name in (
            ('snapshots', 'gateway_state.jsonl'), ('actions', 'power_actions.jsonl'),
            ('power', 'components.csv'))}
        self.header = None

    def poll(self):
        counts = {}
        for kind, reader in self.sources.items():
            counts[kind] = 0
            for line in reader.read():
                if kind == 'power':
                    cells = next(csv.reader(io.StringIO(line)))
                    if self.header is None:
                        if not {'wall_time_ns', 'aggregate_gpu_power_w'} <= set(cells):
                            raise ValueError('Missing GPU power columns')
                        self.header = cells
                        continue
                    if len(cells) != len(self.header):
                        raise ValueError('Incomplete power CSV record')
                    raw = dict(zip(self.header, cells))
                    value = float(raw['aggregate_gpu_power_w']) if raw['aggregate_gpu_power_w'] else None
                    row = {'wall_time_ns': int(raw['wall_time_ns']),
                           'gpu_w': value if value is not None and math.isfinite(value) else None}
                else:
                    row = json.loads(line)
                self.feed.receive(kind, row)
                counts[kind] += 1
        return counts
