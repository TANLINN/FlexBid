"""Observe the saved fixed-policy request executor without changing its phases."""
import json
import time

from core_shadow_feed import ShadowFeed
from core_shadow_models import load_scorer
from core_shadow_session import run_session


def run_workload(measure, output):
    document = json.loads((output/'SHADOW_MODELS.json').read_text(encoding='utf-8'))
    original = measure.execute_requests

    async def execute(online, jobs, protocol, request, emit, *args, **kwargs):
        scorer = load_scorer(output/'SHADOW_MODELS.json', int(protocol['start_wall_ns']),
                             int(protocol['deadline_wall_ns']))
        with (output/'shadow_receipts.jsonl').open('w',encoding='utf-8') as receipts, \
             (output/'shadow_decisions.jsonl').open('w',encoding='utf-8') as decisions:
            class RecordedFeed(ShadowFeed):
                def receive(self, kind, row):
                    super().receive(kind,row)
                    receipts.write(json.dumps({'kind':kind,'record':self.records[kind][-1]})+'\n')
                    receipts.flush()
            feed = RecordedFeed(jobs,int(protocol['deadline_wall_ns']),document['group'],scorer)
            async def observed_request(row,kind):
                feed.dispatch(kind,row,time.time_ns())
                return await request(row,kind)
            def observed_result(kind,row):
                feed.result(kind,row)
                emit(kind,row)
            def decision(row):
                decisions.write(json.dumps(row)+'\n')
                decisions.flush()
            async def workload():
                return await original(online,jobs,protocol,observed_request,observed_result,*args,**kwargs)
            await run_session(feed,int(protocol['start_wall_ns']),output,workload,decision)
            measure.write_json(output/'SHADOW_COMPLETE.json',{
                'status':'SHADOW_OBSERVATION_COMPLETE','held_identity':document['held_identity'],
                'received_counts':{k:len(v) for k,v in feed.records.items()},'model_actuation':False})
    measure.execute_requests = execute
    try:
        measure.workload_main(output)
    finally:
        measure.execute_requests = original
