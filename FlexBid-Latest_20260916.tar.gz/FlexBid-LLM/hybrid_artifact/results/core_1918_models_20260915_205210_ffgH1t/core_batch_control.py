"""File-based batch admission updates with client application acknowledgements."""
import asyncio
import json
import os
from pathlib import Path

from core_dynamic_batch import BatchAdmission


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value), encoding='utf-8')
    os.replace(temporary, path)


async def follow_control(admission, control, acknowledgement, stop, interval=0.02):
    """One controller writer; acknowledgement confirms client limit, not gateway state."""
    previous = None
    while not stop.is_set():
        try:
            value = json.loads(Path(control).read_text(encoding='utf-8'))
        except FileNotFoundError:
            value = None
        if value is not None and value != previous:
            limit = BatchAdmission.validate(value['batch_concurrency'])
            await admission.resize(limit)
            write_json(acknowledgement, value)
            previous = value
        try:
            await asyncio.wait_for(stop.wait(), interval)
        except asyncio.TimeoutError:
            pass


async def publish_limit(control, acknowledgement, sequence, limit, timeout=2.0):
    """Single outstanding update; sequence distinguishes repeated limits."""
    value = {'sequence': sequence, 'batch_concurrency': BatchAdmission.validate(limit)}
    write_json(control, value)

    async def wait_applied():
        while True:
            try:
                if json.loads(Path(acknowledgement).read_text(encoding='utf-8')) == value:
                    return
            except FileNotFoundError:
                pass
            await asyncio.sleep(0.01)
    await asyncio.wait_for(wait_applied(), timeout)


async def change_concurrency(current, desired, publish_client, publish_gateway):
    """Order updates without cancelling already admitted requests.

    Gateway publication is not an acknowledgement of gateway refresh. A timeout
    propagates and must stop the controller; it must not silently retry a change.
    """
    BatchAdmission.validate(current)
    BatchAdmission.validate(desired)
    if desired < current:
        await publish_client(desired)
        await publish_gateway(desired)
    elif desired > current:
        await publish_gateway(desired)
        await publish_client(desired)

