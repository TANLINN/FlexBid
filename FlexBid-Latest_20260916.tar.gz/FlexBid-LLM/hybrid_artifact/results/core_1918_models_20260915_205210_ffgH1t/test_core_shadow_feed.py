import unittest

from core_shadow_feed import ShadowFeed


class FeedTests(unittest.TestCase):
    def setUp(self):
        self.now = 100
        self.feed = ShadowFeed([{'job_id': 'a', 'max_output_tokens': 2}], 1000,
                               'G1', lambda state, cutoff: [], lambda: self.now)

    def test_collector_receipt_excludes_delayed_result(self):
        self.feed.dispatch('batch', {'job_id': 'a'}, 90)
        self.now = 200
        self.feed.result('batch', {'job_id': 'a', 'receipt_wall_time_ns': 110,
                                  'completion_wall_time_ns': 105, 'status_code': 200,
                                  'completion_tokens': 2, 'error': None})
        earlier = self.feed.decision(150)
        self.assertEqual(earlier['state']['x_remaining_jobs'], 1)
        self.assertEqual(earlier['state']['x_batch_inflight_client'], 1)
        self.assertEqual(self.feed.decision(200)['status'], 'COHORT_COMPLETE')
        self.assertEqual(self.feed.records['results'][0]['producer_receipt_wall_time_ns'], 110)

    def test_snapshots_and_actions_are_copied_and_receipt_limited(self):
        row = {'wall_time_ns': 90, 'inflight_online': [1], 'online_waiting': 2}
        self.feed.receive('snapshots', row)
        row['inflight_online'][0] = 999
        self.feed.receive('actions', {'end_wall_ns': 90, 'action': {'power_cap_w': 400, 'batch_concurrency': 5}})
        self.now = 200
        self.feed.receive('actions', {'end_wall_ns': 140, 'receipt_wall_time_ns': 145,
                                     'action': {'power_cap_w': 300, 'batch_concurrency': 6}})
        state = self.feed.decision(150)['state']
        self.assertEqual(state['x_online_active'], 1)
        self.assertEqual(state['x_p_w'], 400)
        self.assertEqual(self.feed.decision(200)['state']['x_c'], 6)

    def test_incomplete_and_future_cutoffs(self):
        self.feed.result('batch', {'job_id': 'a', 'completion_wall_time_ns': 90,
                                  'status_code': 200, 'completion_tokens': 1})
        self.assertEqual(self.feed.decision(100)['state']['x_remaining_jobs'], 1)
        with self.assertRaises(ValueError):
            self.feed.decision(101)


if __name__ == '__main__':
    unittest.main()
