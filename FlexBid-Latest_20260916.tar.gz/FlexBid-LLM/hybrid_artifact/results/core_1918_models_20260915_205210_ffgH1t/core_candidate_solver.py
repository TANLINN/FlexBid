"""Exact selection over the existing phase-constant point-plan family."""
import math
import time

from core_plan_comparison import rank
from core_shadow_scorer import schedules


class CandidateSolver:
    def __init__(self, scorer, start_ns, deadline_ns, budget_s=10., clock=time.perf_counter):
        if not math.isfinite(budget_s) or budget_s <= 0:
            raise ValueError('Positive finite solve budget required')
        if deadline_ns-start_ns != 1950*10**9:
            raise ValueError('Expected 1950-second protocol')
        self.scorer, self.start, self.deadline = scorer, start_ns, deadline_ns
        self.budget, self.clock = budget_s, clock

    def solve(self, state, cutoff_ns):
        began = self.clock()
        result = {'status': None, 'first_action': None, 'best_point_plan': None,
                  'candidates': [], 'actuation_performed': False,
                  'scope': 'Phase-constant candidate family; point constraints only'}
        def finish(status):
            result.update(status=status, solve_seconds=self.clock()-began)
            return result
        if cutoff_ns >= self.deadline:
            return finish('DEADLINE_REACHED')
        if state['all_jobs_complete_on_time']:
            return finish('COHORT_COMPLETE')
        elapsed = cutoff_ns-self.start
        if elapsed < 150*10**9 or elapsed % (30*10**9):
            raise ValueError('Expected evaluation slot boundary')
        family = dict(schedules(elapsed//10**9))
        iterator = iter(self.scorer.iter_candidates(dict(state), cutoff_ns))
        # A running candidate is not interrupted; expired solves emit no action.
        for _ in family:
            if self.clock()-began >= self.budget:
                return finish('SOLVE_BUDGET_EXCEEDED')
            candidate = next(iterator)
            if candidate['name'] not in family or any(c['name']==candidate['name'] for c in result['candidates']):
                raise ValueError('Unexpected or duplicate candidate')
            result['candidates'].append(candidate)
        if next(iterator, None) is not None:
            raise ValueError('Extra candidate')
        if self.clock()-began >= self.budget:
            return finish('SOLVE_BUDGET_EXCEEDED')
        ordered = rank(result['candidates'])
        if not ordered:
            return finish('NO_POINT_FEASIBLE_PLAN')
        chosen = ordered[0]
        result.update(best_point_plan=chosen, first_action=dict(family[chosen['name']][0]))
        return finish('POINT_PLAN_SELECTED')

