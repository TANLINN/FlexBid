"""Use serial startup and separate replica caches with the saved uncached service."""
import inspect
import json

from mamba_prefix_tools import uncached_start_source
from replica_startup_tools import prepared_start_source


def uncached_service_class(base, output):
    source = prepared_start_source(uncached_start_source(inspect.getsource(base.start)))
    path = output / 'service_start.py.txt'
    path.write_text(source, encoding='utf-8')
    namespace = dict(base.start.__globals__)
    exec(compile(source, str(path), 'exec'), namespace)
    start = namespace['start']

    class SerialUncachedServiceGroup(base):
        def start(self):
            start(self)
            (output / 'SERVICE_COMMANDS.json').write_text(
                json.dumps([list(p.args) for p in self.processes], indent=2) + '\n', encoding='utf-8')

    return SerialUncachedServiceGroup
