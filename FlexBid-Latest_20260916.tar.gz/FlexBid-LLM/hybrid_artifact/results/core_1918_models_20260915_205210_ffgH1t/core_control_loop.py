"""Receipt-visible, serial plan selection and first-action application."""
import asyncio
import time

from core_shadow_decision import decision_state


async def run_control(feed, start_ns, solver, executor, emit, stop,
                      clock=time.time_ns, sleep=asyncio.sleep, first_second=150):
    if first_second < 150 or first_second >= 1950 or first_second % 30:
        raise ValueError('Expected an evaluation slot')
    for second in range(first_second,1950,30):
        cutoff=start_ns+second*10**9
        while clock()<cutoff and not stop.is_set():
            await sleep(min(.1,(cutoff-clock())/1e9))
        if stop.is_set():return
        if clock()>=cutoff+30*10**9:
            emit({'status':'CONTROL_SLOT_SKIPPED','cutoff_wall_ns':cutoff})
            continue
        records=feed.records
        state=decision_state(feed.jobs,records['dispatches'],records['results'],
                             records['snapshots'],records['power'],cutoff,
                             feed.deadline_ns,feed.group,records['actions'])
        solution=await asyncio.to_thread(solver.solve,state,cutoff)
        emit({'status':'CONTROL_SOLUTION','cutoff_wall_ns':cutoff,
              'state':state,'solution':solution})
        if stop.is_set():return
        if solution['status'] in ('COHORT_COMPLETE','DEADLINE_REACHED'):return
        if solution['status']!='POINT_PLAN_SELECTED':
            # The caller must perform existing service cleanup, not assume safety.
            raise RuntimeError('No executable point plan: '+solution['status'])
        result=await executor.apply(solution,min(cutoff+30*10**9,feed.deadline_ns),stopped=stop.is_set)
        emit({'status':'CONTROL_APPLICATION','cutoff_wall_ns':cutoff,'result':result})
        if result['status']!='ACTION_ACKNOWLEDGED':
            raise RuntimeError('Action not acknowledged: '+result['status'])

