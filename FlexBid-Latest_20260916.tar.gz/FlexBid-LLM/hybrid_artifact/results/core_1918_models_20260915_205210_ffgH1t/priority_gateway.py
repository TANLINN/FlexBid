"""Priority-aware gateway for online and interruptible batch inference."""
from __future__ import annotations
from stream_trace_tools import StreamObservation
from first_text_admission_tools import FirstTextDetector
import asyncio
import json
import os
import time
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path
import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import Response, StreamingResponse
CONTROL_FILE = Path(os.environ.get('FLEXBID_HYBRID_CONTROL_FILE', '/tmp/flexbid-hybrid-control.json'))
UPSTREAMS = [item.rstrip('/') for item in os.environ.get('FLEXBID_HYBRID_UPSTREAMS', 'http://127.0.0.1:18100').split(',') if item.strip()]
DEFAULT_ONLINE_CONCURRENCY = int(os.environ.get('FLEXBID_ONLINE_CONCURRENCY', '32'))
MAX_ONLINE_QUEUE = int(os.environ.get('FLEXBID_MAX_ONLINE_QUEUE', '512'))

class AdjustableGate:

    def __init__(self, limit: int):
        self.limit = limit
        self.active = 0
        self.waiting = 0
        self.condition = asyncio.Condition()
        self.placement_notify = None

    async def acquire(self) -> None:
        placement_slot_granted = False
        try:
            async with self.condition:
                self.waiting += 1
                try:
                    while self.active >= self.limit:
                        await self.condition.wait()
                    self.active += 1
                    placement_slot_granted = True
                finally:
                    self.waiting -= 1
        finally:
            try:
                if self.placement_notify is not None:
                    await self.placement_notify()
            except BaseException:
                if placement_slot_granted:
                    async with self.condition:
                        self.active -= 1
                        self.condition.notify_all()
                raise

    async def release(self) -> None:
        try:
            async with self.condition:
                self.active = max(0, self.active - 1)
                self.condition.notify_all()
        finally:
            if self.placement_notify is not None:
                await self.placement_notify()

    async def resize(self, limit: int) -> None:
        try:
            if limit <= 0:
                raise ValueError('gate limit must be positive')
            async with self.condition:
                self.limit = limit
                self.condition.notify_all()
        finally:
            if self.placement_notify is not None:
                await self.placement_notify()

class State:

    def __init__(self):
        self.online_gate = AdjustableGate(DEFAULT_ONLINE_CONCURRENCY)
        self.batch_gate = AdjustableGate(1)
        self.online_replica_ids = list(range(len(UPSTREAMS)))
        self.batch_replica_ids = list(range(len(UPSTREAMS)))
        self.batch_paused = True
        self.inflight = [0 for _ in UPSTREAMS]
        self.inflight_online = [0 for _ in UPSTREAMS]
        self.inflight_batch = [0 for _ in UPSTREAMS]
        self.completed_online = 0
        self.completed_batch = 0
        self.last_mtime = -1
        self.lock = asyncio.Lock()
        self.metrics = deque(maxlen=2048)
        self.client = httpx.AsyncClient(timeout=None, limits=httpx.Limits(max_connections=2048, max_keepalive_connections=0))
        self.placement_condition = asyncio.Condition(self.lock)
        self.placement_waiting = {'online': 0, 'batch': 0}
        self.batch_first_tokens = {}
        self.defer_batch_for_online_queue = False
        self.admission_context = {}
        self.online_gate.placement_notify = self.notify_placement

    async def refresh(self) -> None:
        try:
            stat = CONTROL_FILE.stat()
            if stat.st_mtime_ns == self.last_mtime:
                return
            value = json.loads(CONTROL_FILE.read_text(encoding='utf-8'))
            online = [int(item) for item in value['online_replica_ids']]
            batch = [int(item) for item in value.get('batch_replica_ids', online)]
            if not online or min(online + batch, default=0) < 0:
                raise ValueError('invalid replica set')
            if max(online + batch, default=0) >= len(UPSTREAMS):
                raise ValueError('replica ID exceeds upstream count')
            self.online_replica_ids = online
            self.batch_replica_ids = batch
            self.batch_paused = bool(value.get('batch_paused', False))
            self.defer_batch_for_online_queue = bool(value.get('defer_batch_for_online_queue', False))
            await self.online_gate.resize(int(value.get('online_concurrency', DEFAULT_ONLINE_CONCURRENCY)))
            await self.batch_gate.resize(max(1, int(value.get('batch_concurrency', 1))))
            self.last_mtime = stat.st_mtime_ns
        except FileNotFoundError:
            return

    async def choose(self, request_class: str, ticket) -> int:
        placement_started_ns = time.monotonic_ns()
        deferred_for_online = False
        async with self.placement_condition:
            self.placement_waiting[request_class] += 1
            try:
                while True:
                    allowed = self.online_replica_ids if request_class == 'online' else self.batch_replica_ids
                    ready = [i for i in allowed if (self.inflight_online[i] < 3 if request_class == 'online' else self.inflight_online[i] == 0) and (request_class == 'batch' or i not in self.batch_first_tokens.values()) if request_class != 'batch' or self.inflight_batch[i] < 2]
                    queued_online = self.queued_online_count()
                    if request_class == 'batch' and self.defer_batch_for_online_queue and (queued_online > 0):
                        deferred_for_online = True
                        ready = []
                    if ready:
                        if request_class == 'online':
                            index = min(ready, key=lambda i: (self.inflight_online[i], self.inflight[i], self.inflight_batch[i], i))
                        else:
                            index = min(ready, key=lambda i: (self.inflight[i], self.inflight_batch[i], i))
                        self.inflight[index] += 1
                        if request_class == 'online':
                            self.inflight_online[index] += 1
                        else:
                            self.inflight_batch[index] += 1
                            self.batch_first_tokens[ticket] = index
                        self.admission_context[ticket] = {'enabled': self.defer_batch_for_online_queue, 'queued_online_at_selection': queued_online, 'deferred_for_online': deferred_for_online, 'placement_wait_ms': (time.monotonic_ns() - placement_started_ns) / 1000000.0, 'selection_wall_time_ns': time.time_ns()}
                        return index
                    await self.placement_condition.wait()
            finally:
                self.placement_waiting[request_class] -= 1
                self.placement_condition.notify_all()

    def pending_first_counts(self):
        return [sum((i == index for i in self.batch_first_tokens.values())) for index in range(len(self.inflight))]

    async def first_text(self, ticket):
        async with self.placement_condition:
            self.batch_first_tokens.pop(ticket, None)
            self.placement_condition.notify_all()

    async def finish(self, index: int, request_class: str, metric: dict, ticket=None) -> None:
        async with self.lock:
            self.inflight[index] = max(0, self.inflight[index] - 1)
            if request_class == 'online':
                self.inflight_online[index] = max(0, self.inflight_online[index] - 1)
                self.completed_online += 1
                sequence = self.completed_online
            else:
                self.inflight_batch[index] = max(0, self.inflight_batch[index] - 1)
                self.completed_batch += 1
                sequence = self.completed_batch
            self.metrics.append({'class': request_class, 'sequence': sequence, 'completed_wall_time_ns': time.time_ns(), **metric})
            self.batch_first_tokens.pop(ticket, None)
            self.placement_condition.notify_all()
            self.admission_context.pop(ticket, None)

    def queued_online_count(self):
        return self.online_gate.waiting + max(0, self.placement_waiting['online'], self.online_gate.active - sum(self.inflight_online))

    async def notify_placement(self):
        async with self.placement_condition:
            self.placement_condition.notify_all()
state = State()

@asynccontextmanager
async def lifespan(_app: FastAPI):
    if not UPSTREAMS:
        raise RuntimeError('FLEXBID_HYBRID_UPSTREAMS is empty')
    yield
    await state.client.aclose()
app = FastAPI(lifespan=lifespan)

@app.get('/health')
async def health():
    return {'status': 'ok', 'upstreams': UPSTREAMS}

@app.get('/flexbid/state')
async def flexbid_state():
    await state.refresh()
    recent_online = [value for value in state.metrics if value.get('class') == 'online'][-256:]
    return {'online_replica_ids': state.online_replica_ids, 'batch_replica_ids': state.batch_replica_ids, 'batch_paused': state.batch_paused, 'inflight': state.inflight, 'inflight_online': state.inflight_online, 'inflight_batch': state.inflight_batch, 'online_waiting': state.online_gate.waiting + state.placement_waiting['online'], 'batch_waiting': state.batch_gate.waiting + state.placement_waiting['batch'], 'completed_online': state.completed_online, 'completed_batch': state.completed_batch, 'recent_online_metrics': recent_online, 'batch_pending_first': state.pending_first_counts(), 'placement_waiting': dict(state.placement_waiting), 'online_concurrency': state.online_gate.limit, 'batch_concurrency': state.batch_gate.limit, 'defer_batch_for_online_queue': state.defer_batch_for_online_queue}

@app.post('/flexbid/reset')
async def flexbid_reset():
    """Reset per-trajectory metrics after the gateway drains."""
    await state.refresh()
    if sum(state.inflight):
        raise RuntimeError('gateway must be idle before resetting experiment state')
    state.completed_online = 0
    state.completed_batch = 0
    state.metrics.clear()
    return {'status': 'reset'}

def _request_class(request: Request) -> str:
    value = request.headers.get('x-flexbid-class', 'online').lower()
    return value if value in {'online', 'batch'} else 'online'

@app.api_route('/v1/{path:path}', methods=['GET', 'POST'])
async def proxy(path: str, request: Request):
    await state.refresh()
    request_class = _request_class(request)
    request_source = request.headers.get('x-flexbid-source', 'unknown').lower()
    gate = state.online_gate if request_class == 'online' else state.batch_gate
    if request_class == 'batch' and state.batch_paused:
        raise HTTPException(status_code=503, detail='batch work paused for demand response')
    if request_class == 'online' and gate.waiting >= MAX_ONLINE_QUEUE:
        raise HTTPException(status_code=429, detail='online queue safety limit')
    await gate.acquire()
    ticket = object()
    try:
        index = await state.choose(request_class, ticket)
    except BaseException:
        await gate.release()
        raise
    stream_admitted_ns = time.monotonic_ns()
    stream_selected_counts = {'online': list(state.inflight_online), 'batch': list(state.inflight_batch), 'batch_pending_first': state.pending_first_counts(), 'online_queue_priority': state.admission_context.pop(ticket)}
    try:
        body = await request.body()
    except BaseException:
        try:
            await state.finish(index, request_class, {'error': 'request-body'}, ticket=ticket)
        finally:
            try:
                await gate.release()
            finally:
                raise
    try:
        request_metadata = {}
        try:
            parsed = json.loads(body)
            assigned_priority = 0 if request_class == 'online' else 10
            parsed['priority'] = assigned_priority
            body = json.dumps(parsed).encode()
            prompt = parsed.get('prompt')
            if isinstance(prompt, list):
                if prompt and isinstance(prompt[0], list):
                    prompt_tokens = len(prompt[0])
                else:
                    prompt_tokens = len(prompt)
            elif isinstance(prompt, str):
                prompt_tokens = max(1, len(prompt) // 4)
            else:
                prompt_tokens = None
            request_metadata = {'prompt_tokens': prompt_tokens, 'max_output_tokens': parsed.get('max_tokens'), 'cache_prefix_tokens': parsed.get('cache_prefix_tokens', 0), 'request_source': request_source}
        except (json.JSONDecodeError, AttributeError, TypeError):
            pass
        headers = {key: value for (key, value) in request.headers.items() if key.lower() not in {'host', 'content-length', 'connection', 'x-flexbid-class'}}
        started = time.perf_counter()
        upstream_request = state.client.build_request(request.method, f'{UPSTREAMS[index]}/v1/{path}', content=body, headers=headers, params=request.query_params)
        response = await state.client.send(upstream_request, stream=True)
    except BaseException:
        try:
            await state.finish(index, request_class, {'error': 'connect'}, ticket=ticket)
        finally:
            try:
                await gate.release()
            finally:
                raise
    content_type = response.headers.get('content-type', '')
    if 'text/event-stream' not in content_type:
        try:
            payload = await response.aread()
            return Response(payload, status_code=response.status_code, media_type=content_type or 'application/octet-stream')
        finally:
            try:
                await response.aclose()
            finally:
                try:
                    await state.finish(index, request_class, {'status': response.status_code, 'e2e_ms': (time.perf_counter() - started) * 1000, **request_metadata}, ticket=ticket)
                finally:
                    await gate.release()

    async def stream():
        first_text_detector = FirstTextDetector()
        observation = StreamObservation(request.headers.get('x-flexbid-trace-id'), index, request_class, stream_admitted_ns, stream_selected_counts)
        first = None
        previous = None
        gaps = []
        try:
            async for chunk in response.aiter_bytes():
                observation.receive(chunk)
                if request_class == 'batch' and first_text_detector.feed(chunk):
                    await state.first_text(ticket)
                now = time.perf_counter()
                if first is None:
                    first = now
                if previous is not None:
                    gaps.append((now - previous) * 1000)
                previous = now
                observation.forwarding()
                yield chunk
        finally:
            try:
                await response.aclose()
            finally:
                try:
                    await state.finish(index, request_class, {'status': response.status_code, 'ttft_ms': None if first is None else (first - started) * 1000, 'mean_gap_ms': sum(gaps) / len(gaps) if gaps else None, 'e2e_ms': (time.perf_counter() - started) * 1000, **request_metadata}, ticket=ticket)
                finally:
                    try:
                        await gate.release()
                    finally:
                        observation.finish()
    return StreamingResponse(stream(), status_code=response.status_code, media_type=content_type)
