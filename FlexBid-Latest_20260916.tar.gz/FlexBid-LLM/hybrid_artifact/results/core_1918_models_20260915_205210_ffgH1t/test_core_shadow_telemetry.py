import json
from pathlib import Path
import tempfile
import unittest

from core_shadow_feed import ShadowFeed
from core_shadow_telemetry import TelemetryFiles


class TelemetryTests(unittest.TestCase):
    def test_partial_appends_and_collector_visibility(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            now = [200]
            feed = ShadowFeed([{'job_id':'a','max_output_tokens':2}],1000,'G1',lambda s,t:[],lambda:now[0])
            reader = TelemetryFiles(root, feed)
            self.assertEqual(sum(reader.poll().values()),0)
            (root/'components.csv').write_bytes(b'wall_time_ns,aggregate_gpu_power_w\n100,12')
            self.assertEqual(reader.poll()['power'],0)
            with (root/'components.csv').open('ab') as stream:
                stream.write(b'34\n')
            (root/'gateway_state.jsonl').write_text(json.dumps({'wall_time_ns':100,'inflight_online':[2]})+'\n')
            (root/'power_actions.jsonl').write_text(json.dumps({'end_wall_ns':100,'action':{'power_cap_w':300,'batch_concurrency':5}})+'\n')
            self.assertEqual(reader.poll(),{'snapshots':1,'actions':1,'power':1})
            self.assertIsNone(feed.decision(150)['state']['x_last_gpu_w'])
            state = feed.decision(200)['state']
            self.assertEqual((state['x_last_gpu_w'],state['x_online_active'],state['x_p_w']),(1234,2,300))
            self.assertEqual(sum(reader.poll().values()),0)

    def test_missing_power_is_not_zero(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'components.csv').write_text('wall_time_ns,aggregate_gpu_power_w\n100,\n101,nan\n')
            feed = ShadowFeed([],1000,'G1',None,lambda:200)
            TelemetryFiles(root,feed).poll()
            self.assertEqual([r['gpu_w'] for r in feed.records['power']],[None,None])

    def test_truncation_stops_reading(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            file = root/'components.csv'
            file.write_text('wall_time_ns,aggregate_gpu_power_w\n100,1\n')
            reader = TelemetryFiles(root,ShadowFeed([],1000,'G1',None,lambda:200))
            reader.poll()
            file.write_text('')
            with self.assertRaisesRegex(ValueError,'truncated'):
                reader.poll()


if __name__ == '__main__':
    unittest.main()
