import asyncio
import json
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import core_control_workload as module
from core_parent_runtime import ParentRuntime


class WorkloadTests(unittest.TestCase):
    def test_saved_entry_dynamic_admission_and_parent_receipts(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d);(out/'SHADOW_MODELS.json').write_text('{"group":"G1"}')
            start=time.time_ns()-450*10**9
            protocol=dict(start_wall_ns=start,deadline_wall_ns=start+1950*10**9,duration_s=1950,
                          drain_s=1,cohort_release_offset_s=150,batch_admission_offset_s=150)
            jobs=[dict(job_id='a',max_output_tokens=2)]
            results=[];control={}
            class Power:
                def set_all(self,p):return {i:p for i in range(8)}
            class Action:
                def __init__(self,p,c):self.p=p;self.c=c
                def as_dict(self):return dict(power_cap_w=self.p,batch_concurrency=self.c)
            def write(action,priority):
                control.update(online_replica_ids=[0,1,2,3],batch_replica_ids=[0,1,2,3],
                               batch_paused=False,online_concurrency=12,batch_concurrency=action.c,
                               defer_batch_for_online_queue=priority)
                return dict(control)
            runtime=ParentRuntime(out,Power(),Action,write,lambda:dict(control),lambda r:None,start)
            async def legacy(online,batch,protocol,request,emit,concurrency):
                self.assertEqual(batch,[])
                emit('online',await request({'request_id':'online'},'online'))
            async def request(row,kind):
                return {**row,'completion_tokens':2,'status_code':200,'error':None,
                        'dispatch_wall_time_ns':time.time_ns(),'completion_wall_time_ns':time.time_ns()}
            async def controller(feed,start,solver,executor,emit,stop):
                await executor.apply({'status':'POINT_PLAN_SELECTED','first_action':dict(p_w=400,c=6,phase='recovery')},time.time_ns()+5*10**9,stopped=stop.is_set)
                await stop.wait()
            measure=SimpleNamespace(execute_requests=legacy,write_json=lambda p,v:p.write_text(json.dumps(v)))
            def main(output):
                async def run():
                    stopped=asyncio.Event()
                    async def poll():
                        while not stopped.is_set():runtime.tick();await asyncio.sleep(.001)
                    task=asyncio.create_task(poll())
                    try:
                        await asyncio.wait_for(measure.execute_requests([],jobs,protocol,request,lambda k,r:results.append((k,r))),3)
                    finally:
                        stopped.set();await task;runtime.close()
                asyncio.run(run())
            measure.workload_main=main
            with patch.object(module,'load_scorer',return_value=None),patch.object(module,'run_control',controller):
                module.run_workload(measure,out)
            self.assertIs(measure.execute_requests,legacy)
            self.assertEqual([k for k,r in results].count('batch'),1)
            complete=json.loads((out/'CONTROL_COMPLETE.json').read_text())
            self.assertEqual(complete['received_counts']['dispatches'],2)
            self.assertEqual(complete['received_counts']['results'],2)

    def test_original_executor_restored_after_entry_failure(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d);(out/'SHADOW_MODELS.json').write_text('{"group":"G1"}')
            original=object()
            def fail(out):raise RuntimeError('entry failure')
            measure=SimpleNamespace(execute_requests=original,workload_main=fail)
            with self.assertRaisesRegex(RuntimeError,'entry failure'):module.run_workload(measure,out)
            self.assertIs(measure.execute_requests,original)

if __name__=='__main__':unittest.main()

