import json
import sys
from pathlib import Path
from core_shadow_models import load_scorer
from core_candidate_solver import CandidateSolver
source,out=map(Path,sys.argv[1:])
p=json.loads((source/'protocol.json').read_text())
start,end=int(p['start_wall_ns']),int(p['deadline_wall_ns'])
solver=CandidateSolver(load_scorer(source/'SHADOW_MODELS.json',start,end),start,end,budget_s=10)
rows=[];mismatches=[]
for line in (source/'shadow_decisions.jsonl').read_text().splitlines():
 d=json.loads(line)
 r=solver.solve(d['state'],d['cutoff_wall_ns'])
 before=d.get('best_point_plan');after=r['best_point_plan']
 same=before==after and d.get('candidates',[])==r['candidates']
 if not same: mismatches.append({'at_s':(d['cutoff_wall_ns']-start)/1e9,'status':r['status']})
 rows.append({'at_s':(d['cutoff_wall_ns']-start)/1e9,**r})
(out/'decisions.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
report={'status':'CORE_CANDIDATE_SOLVER_CPU_EVALUATED','origins':len(rows),
 'mismatches':mismatches,'maximum_solve_seconds':max(r['solve_seconds'] for r in rows),
 'selected':sum(r['status']=='POINT_PLAN_SELECTED' for r in rows),
 'budget_exceeded':sum(r['status']=='SOLVE_BUDGET_EXCEEDED' for r in rows),
 'gpu_workload':False,'actuation':False,'installed':False,
 'scope':'Exact search over existing phase-constant candidates, not arbitrary slot sequences or calibrated safety.'}
(out/'REPORT.json').write_text(json.dumps(report,indent=2))
print('=== CORE_CANDIDATE_SOLVER_CPU ===')
print(json.dumps(report))
print('REPORT_JSON='+str(out/'REPORT.json'))

