"""Single outstanding control request to the power-owning parent process."""
import asyncio
import json
import time
from pathlib import Path

from core_batch_control import write_json


class ParentClient:
    def __init__(self, output, clock=time.time_ns):
        self.output=Path(output);self.clock=clock;self.sequence=0
        self.lock=asyncio.Lock();self.failed=False

    async def request(self, operation, arguments, expires_ns):
        async with self.lock:
            if self.failed:raise RuntimeError('Parent control previously failed')
            if operation not in ('power','gateway'):raise ValueError('Unknown operation')
            if self.clock()>=expires_ns:raise TimeoutError('Control request expired')
            self.sequence+=1
            value={'sequence':self.sequence,'operation':operation,'arguments':arguments,'expires_ns':expires_ns}
            write_json(self.output/'parent_request.json',value)
            try:
                while self.clock()<expires_ns:
                    try:r=json.loads((self.output/'parent_ack.json').read_text())
                    except FileNotFoundError:r=None
                    if r is not None and r['sequence']==self.sequence:
                        if r['status']!='APPLIED':raise RuntimeError(r.get('error','Parent operation failed'))
                        return r['result']
                    await asyncio.sleep(.01)
                raise TimeoutError('Parent acknowledgement missing')
            except BaseException:
                self.failed=True
                raise


class ParentControl:
    def __init__(self, output, power, gateway, clock=time.time_ns):
        self.output=Path(output);self.handlers={'power':power,'gateway':gateway}
        self.clock=clock;self.sequence=0;self.closed=False

    def close(self):
        self.closed=True

    def poll(self):
        if self.closed:return
        try:r=json.loads((self.output/'parent_request.json').read_text())
        except FileNotFoundError:return
        if r['sequence']==self.sequence:return
        try:
            if r['sequence']!=self.sequence+1:raise ValueError('Control sequence mismatch')
            if self.clock()>=r['expires_ns']:raise TimeoutError('Control request expired before application')
            handler=self.handlers[r['operation']]
            began=self.clock()
            result=handler(**r['arguments'])
            ended=self.clock()
            if ended>=r['expires_ns']:raise TimeoutError('Operation finished after request expiry')
            ack={'sequence':r['sequence'],'status':'APPLIED','result':result,'begin_wall_ns':began,'end_wall_ns':ended}
        except BaseException as exc:
            self.closed=True
            write_json(self.output/'parent_ack.json',{'sequence':r['sequence'],'status':'FAILED',
                       'error':str(exc),'error_type':type(exc).__name__})
            raise
        self.sequence=r['sequence']
        write_json(self.output/'parent_ack.json',ack)
        return ack

