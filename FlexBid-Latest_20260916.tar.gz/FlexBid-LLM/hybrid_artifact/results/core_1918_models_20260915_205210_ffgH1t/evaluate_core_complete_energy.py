"""Complete saved schedule trajectories with post-cohort response dynamics."""
from collections import defaultdict
import json
from pathlib import Path
import sys
from core_response_dataset import NS, read_json, rows, signature, window, power_rows, integrate
from core_response_model import FEATURES, action_key, load_windows, fit_models, fit_selected
from core_recovery_rollout import fit, NEXT_FEATURES, COUNT
from evaluate_core_event_rollout import fit_event_transitions
from evaluate_core_exhausted_response import exhausted, label_ok, TARGETS
from evaluate_core_response_model import annotate_service_labels
from core_plan_trajectory import evaluate_plan
from evaluate_core_full_plan import SCHEDULE


def fit_post_cohort(training):
    selected=[r for r in training if exhausted(r)]
    index={(r['run'],r['start_s']):r for r in selected}
    response_groups=defaultdict(list)
    transition_groups=defaultdict(list)
    for r in selected:
        response_groups[action_key(r)].append(r)
        nxt=index.get((r['run'],r['start_s']+30))
        if nxt is not None and action_key(nxt)==action_key(r):
            transition_groups[action_key(r)].append({**r,**{'next_'+f:nxt.get(f) for f in NEXT_FEATURES}})
    responses=[{'key':list(key),'targets':{t:fit_selected([r for r in group if label_ok(r,t)],t) for t in TARGETS}}
               for key,group in response_groups.items()]
    transitions={}
    for key,group in transition_groups.items():
        # Empty cohort has zero completions; constant zero fit preserves the shared advance interface.
        entry={COUNT:fit_selected([{**r,COUNT:0.} for r in group],COUNT)}
        for feature in NEXT_FEATURES:
            target='next_'+feature
            if feature=='x_oldest_batch_dispatch_age_s':
                entry[target]=fit_selected([{**r,target:0.} for r in group],target)
            else:
                entry[target]=fit_selected([r for r in group if r.get(target) is not None],target)
        transitions[key]=entry
    return transitions,responses,{'response_rows':len(selected),'transition_rows':sum(map(len,transition_groups.values()))}


def evaluate(dataset,source,previous,output):
    metadata=read_json(dataset/'REPORT.json'); saved=read_json(source/'REPORT.json')
    identity=saved['episode_id']; groups=set(); actual_signature=signature(source)[:2]
    for r in metadata['runs']:
        if r['group'] not in groups and signature(Path(r['run']))[:2]==actual_signature:groups.add(r['group'])
    if len(groups)!=1:raise ValueError('Cannot uniquely match saved environment/admission group')
    group=next(iter(groups))
    allowed={r['run'] for r in metadata['runs'] if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    training=[r for r in load_windows(dataset/'action_windows.csv') if r['run'] in allowed and r['group']==group and r['episode_id']!=identity]
    annotate_service_labels(training)
    active_transitions={**fit_event_transitions(training),**fit(training)}
    active_responses=fit_models(training)
    idle_transitions,idle_responses,coverage=fit_post_cohort(training)
    old=read_json(previous/'REPORT.json')
    start=int(read_json(source/'protocol.json')['start_wall_ns'])
    online,batch=rows(source/'online.jsonl'),rows(source/'batch.jsonl')
    states,actions=rows(source/'gateway_state.jsonl'),rows(source/'power_actions.jsonl')
    jobs=rows(source/'batch_jobs.jsonl'); power=power_rows(source/'components.csv')
    plans=[]
    for origin in (240,450):
        raw=window(start+origin*NS,start+(origin+30)*NS,online,batch,len(jobs),states,actions,power)
        state={f:raw.get(f) for f in FEATURES};state['group']=group
        plan=evaluate_plan(active_transitions,active_responses,state,origin,SCHEDULE,
                           exhausted_transitions=idle_transitions,exhausted_responses=idle_responses)
        prior=next(r for r in old['plans'] if r['origin_s']==origin)
        if plan['predicted_completion_slot_end_s']!=prior['predicted_completion_slot_end_s']:
            raise ValueError('Active-batch completion forecast changed')
        if len(plan['records']) < len(prior['records']):
            raise ValueError('Active-batch trajectory truncated')
        for new,ref in zip(plan['records'],prior['records']):
            if abs(new['remaining_jobs_end']-ref['remaining_jobs_end'])>1e-8:
                raise ValueError('Active-batch trajectory differs')
        measured_mean,maxgap=integrate(power,start+origin*NS,start+1950*NS)
        observed_energy=None if measured_mean is None else measured_mean*(1950-origin)/3600
        prediction=plan['predicted_full_horizon_energy_wh']
        regime=[]
        for name in ('active_batch','post_cohort'):
            rr=[r for r in plan['records'] if r['regime']==name]
            if not rr:continue
            left,right=rr[0]['start_s'],rr[-1]['end_s']
            mean,_=integrate(power,start+left*NS,start+right*NS)
            estimates=[r['response']['values'].get('y_mean_gpu_w') for r in rr]
            regime.append({'regime':name,'start_s':left,'end_s':right,
                'predicted_energy_wh':sum(estimates)*30/3600 if all(v is not None for v in estimates) else None,
                'measured_energy_wh':None if mean is None else mean*(right-left)/3600})
        service_scored=sum(all(r['response']['values'].get(t) is not None for t in TARGETS[1:]) for r in plan['records'])
        plans.append({'origin_s':origin,**plan,'measured_full_horizon_energy_wh':observed_energy,
            'energy_error_wh':None if prediction is None or observed_energy is None else prediction-observed_energy,
            'power_max_sample_gap_s':maxgap,'service_prediction_windows':service_scored,'regime_energy':regime})
    notes=[
        'Held-identity active-batch fits unchanged; post-cohort response and next-state fits use only earlier fully exhausted training windows.',
        'No measured state after the origin enters predictions. Batch completion forecast must match the prior saved plan.',
        'At predicted completion batch active/waiting become zero and oldest batch age becomes unavailable; online state carries forward and then follows post-cohort regressions.',
        'The active-to-empty transition is a state-consistency approximation, not a measured engine shutdown or trained switching transient.',
        'Regime energy is aligned to predicted completion time in both prediction and measurement; it does not imply actual batch completion at that boundary.',
        'The completion-containing 30-second slot still uses the active-batch response model. Service predictions are short-window points, not full-phase quantiles.',
        'Unsupported post-cohort models leave complete energy missing; no zero-power substitution. No solver or optimized sequence is evaluated.',
        'CPU only: no GPU, retry, active model installation or keepalive change.']
    report={'status':'CORE_COMPLETE_ENERGY_EVALUATED','source':str(source),'post_cohort_training':coverage,'plans':plans,'notes':notes}
    output.mkdir(parents=True,exist_ok=True)
    (output/'REPORT.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    lines=['=== CORE_COMPLETE_ENERGY ===','STATUS='+report['status'],'POST_COHORT_TRAINING='+json.dumps(coverage)]
    lines+=['PLAN='+json.dumps({k:v for k,v in p.items() if k!='records'}) for p in plans]+notes+['REPORT_JSON='+str(output/'REPORT.json')]
    (output/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8');print('\n'.join(lines))


if __name__=='__main__':evaluate(*map(Path,sys.argv[1:]))
