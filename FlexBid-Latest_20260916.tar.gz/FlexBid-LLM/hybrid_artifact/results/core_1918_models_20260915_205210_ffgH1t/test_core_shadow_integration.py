import asyncio
from pathlib import Path
import tempfile
import time
import unittest

from core_batch_control import publish_limit
from core_dynamic_batch import BatchAdmission
from core_shadow_feed import ShadowFeed, execute_shadow_requests
from test_core_request_adapter import legacy


class IntegrationTests(unittest.IsolatedAsyncioTestCase):
    async def test_saved_online_replay_batch_control_and_shadow_receipts(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            start = time.time_ns()
            jobs = [{'job_id': str(i), 'max_output_tokens': 2} for i in range(3)]
            online = [{'request_id': 'parent', 'arrival_ms': 0, 'prompt_tokens': 10},
                      {'request_id': 'child', 'parent_request_id': 'parent',
                       'arrival_ms': 0, 'tool_delay_ms': 20, 'prompt_tokens': 20}]
            protocol = dict(start_wall_ns=start, duration_s=3, drain_s=1,
                            cohort_release_offset_s=0, batch_admission_offset_s=0)
            feed = ShadowFeed(jobs, start+3_000_000_000, 'G1', lambda state, cutoff: [])
            released = asyncio.Event()
            batch_started = asyncio.Event()
            rows = []
            began = {}

            async def request(row, kind):
                stamp = time.time_ns()
                if kind == 'batch':
                    batch_started.set()
                    await released.wait()
                else:
                    began[row['request_id']] = stamp
                return dict(dispatch_wall_time_ns=stamp, completion_wall_time_ns=time.time_ns(),
                            status_code=200, error=None, completion_tokens=2,
                            ttft_ms=1., mean_tpot_ms=2.)

            task = asyncio.create_task(execute_shadow_requests(
                feed, legacy(), online, jobs, protocol, request,
                lambda kind, row: rows.append((kind, row)), BatchAdmission(0),
                root/'control', root/'ack'))
            try:
                await publish_limit(root/'control', root/'ack', 1, 1)
                await asyncio.wait_for(batch_started.wait(), 1)
                record = feed.decision(time.time_ns())
                self.assertEqual(record['state']['x_remaining_jobs'], 3)
                self.assertEqual(record['state']['x_batch_inflight_client'], 1)
                self.assertFalse(record['actuation_performed'])
                released.set()
                await asyncio.wait_for(task, 2)
            finally:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            self.assertGreaterEqual(began['child']-began['parent'], 19_000_000)
            self.assertEqual(len(rows), 5)
            self.assertEqual(len(feed.records['dispatches']), 5)
            self.assertEqual(len(feed.records['results']), 5)
            self.assertEqual(feed.decision(time.time_ns())['status'], 'COHORT_COMPLETE')
            self.assertTrue(all(r['receipt_wall_time_ns'] >= r['completion_wall_time_ns']
                                for r in feed.records['results']))


if __name__ == '__main__':
    unittest.main()
