"""Batch point-prediction correction from available, completed window residuals."""
from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class WindowFeedback:
    window_start_s: float
    window_end_s: float
    available_at_s: float
    original_prediction: float
    actual_completions: float


class BatchFeedback:
    """A segment identifies one run's uninterrupted phase/action interval."""

    def __init__(self):
        self.windows = {}

    def observe(self, segment, feedback: WindowFeedback):
        values = vars(feedback).values()
        if not all(math.isfinite(v) for v in values):
            raise ValueError('Feedback fields must be finite')
        if not feedback.window_start_s < feedback.window_end_s <= feedback.available_at_s:
            raise ValueError('A complete window cannot be available before its end')
        if min(feedback.original_prediction, feedback.actual_completions) < 0:
            raise ValueError('Completions and original prediction must be nonnegative')
        windows = self.windows.setdefault(segment, {})
        if feedback.window_start_s in windows:
            raise ValueError('Duplicate feedback window in segment')
        windows[feedback.window_start_s] = feedback

    def predict(self, segment, decision_s, original_prediction, remaining_jobs):
        if original_prediction is None:
            return {'prediction': None, 'offset': None, 'feedback_windows': 0,
                    'latest_feedback_available_s': None, 'status': 'NO_BASE_PREDICTION'}
        if not all(math.isfinite(v) for v in (decision_s, original_prediction, remaining_jobs)):
            raise ValueError('Prediction inputs must be finite')
        if min(original_prediction, remaining_jobs) < 0:
            raise ValueError('Prediction and remaining jobs must be nonnegative')
        history = [f for f in self.windows.get(segment, {}).values()
                   if f.window_end_s <= decision_s and f.available_at_s <= decision_s]
        # Always use residuals of the original model, not of the corrected model.
        offset = (math.fsum(f.actual_completions - f.original_prediction for f in history)
                  / len(history)) if history else 0.0
        return {'prediction': min(remaining_jobs, max(0.0, original_prediction + offset)),
                'offset': offset, 'feedback_windows': len(history),
                'latest_feedback_available_s': max((f.available_at_s for f in history), default=None),
                'status': 'FEEDBACK_APPLIED' if history else 'ORIGINAL_NO_HISTORY'}
