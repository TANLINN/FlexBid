"""Prepare held-identity shadow models before service startup."""
import json
import math
from pathlib import Path
import sys

from core_response_model import load_windows, fit_models
from core_recovery_rollout import fit
from evaluate_core_event_rollout import fit_event_transitions
from evaluate_core_complete_energy import fit_post_cohort
from evaluate_core_response_model import annotate_service_labels
from core_shadow_models import load_scorer


def prepare(dataset, reference, source, output):
    read = lambda path: json.loads(path.read_text(encoding='utf-8'))
    old = read(reference/'REPORT.json')
    meta = read(dataset/'REPORT.json')
    protocol = read(source/'protocol.json')
    source_report = read(source/'REPORT.json')
    identity = source_report['episode_id']
    if identity != 'azure_conversation:azure-001710':
        raise ValueError('Expected the selected 001710 shadow workload')
    state = dict(old['plans'][0]['records'][0]['state'])
    reference_source = Path(old['source'])
    if read(reference_source/'REPORT.json')['episode_id'] != identity:
        raise ValueError('Scoring reference identity differs')
    state['x_p_w'], state['x_c'] = old['initial_action']
    group = state['group']
    allowed = {r['run'] for r in meta['runs'] if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    all_rows = load_windows(dataset/'action_windows.csv')
    if not any(r['run']==str(source) and r['group']==group for r in all_rows):
        raise ValueError('Selected source is absent from the saved compatibility group')
    rows = [r for r in all_rows if r['run'] in allowed and r['group']==group and r['episode_id']!=identity]
    if not rows:
        raise ValueError('No held-identity training rows')
    annotate_service_labels(rows)
    idle, idle_responses, idle_counts = fit_post_cohort(rows)
    transitions = {**fit_event_transitions(rows), **fit(rows)}
    document = {'held_identity': identity, 'group': group,
                'training_identities': sorted({r['episode_id'] for r in rows}),
                'training_runs': sorted({r['run'] for r in rows}),
                'transitions': [{'key':list(k),'targets':v} for k,v in transitions.items()],
                'responses': fit_models(rows),
                'idle_transitions': [{'key':list(k),'targets':v} for k,v in idle.items()],
                'idle_responses': idle_responses, 'idle_training':idle_counts}
    output.mkdir(parents=True, exist_ok=True)
    model_path = output/'SHADOW_MODELS.json'
    model_path.write_text(json.dumps(document,indent=2),encoding='utf-8')
    old_protocol = read(reference_source/'protocol.json')
    scorer = load_scorer(model_path,int(old_protocol['start_wall_ns']),int(old_protocol['deadline_wall_ns']))
    actual = scorer(state,int(old_protocol['start_wall_ns'])+int(old['origin_s'])*1_000_000_000)
    expected = {r['name']:r for r in old['candidates'] if r['name']!='measured_schedule'}
    if {r['name'] for r in actual} != set(expected):
        raise ValueError('Reloaded candidate names differ')
    checked = 0
    for row in actual:
        prior = expected[row['name']]
        for key in ('complete_prediction','point_constraints_satisfied','outside_training_range',
                    'missing_features','completion_slot_end_s','switches'):
            if row[key] != prior[key]:
                raise ValueError('Reloaded candidate differs: '+row['name']+' '+key)
            checked += 1
        for key in ('event_energy_wh','full_energy_wh','remaining_at_deadline','max_predicted_ttft_ms','max_predicted_gap_ms'):
            a,b = row[key],prior[key]
            if (a is None)!=(b is None) or (a is not None and not math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-7)):
                raise ValueError('Reloaded value differs: '+row['name']+' '+key)
            checked += 1
    plan = {'episode_id':identity,'source_run':str(source),'input_root':protocol['input_root'],
            'model_file':str(model_path),'group':group,'duration_s':1950,
            'cohort_release_s':150,'deadline_s':1950,'planned_batch_jobs':280,
            'schedule':[{'at_s':0,'p_w':400,'c':0},{'at_s':150,'p_w':300,'c':5},{'at_s':450,'p_w':400,'c':6}],
            'decision_role':'shadow only; recommendations never actuate',
            'batch_phase_release':'Retain existing phase-control receipt before batch dispatch',
            'model_fit_timing':'CPU preparation before service startup; no fitting in measurement',
            'startup':'Retain serial replicas and separate compilation caches',
            'measurement_minutes':32.5,'additional_time':'Engine startup, compilation and request drain',
            'gpu_workload_started':False,'launcher_prepared':False,'keepalive_stopped':False}
    (output/'SHADOW_RUN_PLAN.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
    report = {'status':'CORE_SHADOW_MODELS_PREPARED_CPU_ONLY','held_identity':identity,
              'training_identities':document['training_identities'],'training_runs':len(document['training_runs']),
              'reloaded_candidates':len(actual),'checked_fields':checked,'model_file':str(model_path),
              'plan_file':str(output/'SHADOW_RUN_PLAN.json'),'launcher_prepared':False,
              'gpu_workload':False,'installed':False,'keepalive_stopped':False}
    (output/'REPORT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('=== CORE_SHADOW_MODELS_PREPARATION ===')
    print(json.dumps(report))
    print('REPORT_JSON='+str(output/'REPORT.json'))


if __name__ == '__main__':
    prepare(*map(Path,sys.argv[1:]))
