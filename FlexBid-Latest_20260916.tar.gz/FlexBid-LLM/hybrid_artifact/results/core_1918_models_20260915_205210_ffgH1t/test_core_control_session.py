import asyncio
import tempfile
import unittest

from core_shadow_feed import ShadowFeed
from core_shadow_session import run_session
from core_first_action import FirstActionExecutor


class ControlSessionTests(unittest.IsolatedAsyncioTestCase):
    async def test_controller_failure_cancels_requests(self):
        with tempfile.TemporaryDirectory() as out:
            cancelled=asyncio.Event();started=asyncio.Event()
            async def workload():
                started.set()
                try:await asyncio.sleep(10)
                finally:cancelled.set()
            async def control(stop):
                await started.wait()
                raise RuntimeError('application failed')
            feed=ShadowFeed([],1950*10**9,'G1',None)
            with self.assertRaisesRegex(RuntimeError,'application failed'):
                await run_session(feed,0,out,workload,lambda r:None,controller=control)
            self.assertTrue(cancelled.is_set())

    async def test_session_waits_for_inprogress_control_before_return(self):
        with tempfile.TemporaryDirectory() as out:
            entered=asyncio.Event();finished=[]
            async def workload():await entered.wait()
            async def control(stop):
                entered.set();await stop.wait()
                await asyncio.sleep(.01);finished.append(True)
            feed=ShadowFeed([],1950*10**9,'G1',None)
            await run_session(feed,0,out,workload,lambda r:None,controller=control)
            self.assertEqual(finished,[True])

    async def test_stop_during_power_prevents_admission_writes(self):
        stop=asyncio.Event();calls=[]
        async def power(p):
            calls.append('power');stop.set()
            return {str(i):p for i in range(8)}
        async def client(c):calls.append('client')
        async def gateway(c,q):calls.append('gateway')
        ex=FirstActionExecutor(300,5,client,gateway,power,lambda r:None,clock=lambda:0)
        with self.assertRaisesRegex(RuntimeError,'Session stopped'):
            await ex.apply({'status':'POINT_PLAN_SELECTED','first_action':{'p_w':400,'c':6,'phase':'recovery'}},100,stopped=stop.is_set)
        self.assertEqual(calls,['power'])

if __name__=='__main__':unittest.main()

