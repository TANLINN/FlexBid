import asyncio
import tempfile
import time
import unittest
from pathlib import Path
from core_parent_runtime import ParentRuntime
from core_remote_bindings import RemoteBindings
from core_first_action import FirstActionExecutor
from core_batch_control import follow_control
from core_dynamic_batch import BatchAdmission


class RuntimeTests(unittest.IsolatedAsyncioTestCase):
    async def test_complete_action_through_parent_and_client_receipts(self):
        with tempfile.TemporaryDirectory() as directory:
            output=Path(directory);calls=[];control={};records=[]
            class Power:
                def set_all(self,p):calls.append(('power',p));return {i:p for i in range(8)}
            class Action:
                def __init__(self,p,c):self.p=p;self.c=c
                def as_dict(self):return dict(power_cap_w=self.p,batch_concurrency=self.c)
            def write(action,priority):
                calls.append(('gateway',action.c))
                control.update(online_replica_ids=[0,1,2,3],batch_replica_ids=[0,1,2,3],
                               batch_paused=False,online_concurrency=12,batch_concurrency=action.c,
                               defer_batch_for_online_queue=priority)
                return dict(control)
            runtime=ParentRuntime(output,Power(),Action,write,lambda:dict(control),records.append,
                                  time.time_ns()-450*10**9,initial_p=300,initial_c=5)
            stop=asyncio.Event();admission=BatchAdmission(5)
            async def parent():
                while not stop.is_set():runtime.tick();await asyncio.sleep(.001)
            tasks=[asyncio.create_task(parent()),asyncio.create_task(follow_control(admission,output/'batch_control.json',output/'batch_ack.json',stop))]
            binding=RemoteBindings(output);binding.begin_slot(time.time_ns()+5*10**9)
            ex=FirstActionExecutor(300,5,binding.client,binding.gateway,binding.power,lambda r:None)
            try:
                result=await asyncio.wait_for(ex.apply({'status':'POINT_PLAN_SELECTED','first_action':dict(p_w=400,c=6,phase='recovery')},binding.slot_end_ns),3)
                self.assertEqual(result['status'],'ACTION_ACKNOWLEDGED')
                self.assertEqual(calls,[('power',400),('gateway',6)])
                self.assertEqual(admission.limit,6)
                self.assertEqual([r['operation'] for r in records],['power','gateway'])
            finally:
                stop.set();await asyncio.gather(*tasks);runtime.close()

if __name__=='__main__':unittest.main()

