"""Evaluate a saved predetermined schedule through the batch deadline."""
import json
from pathlib import Path
import sys
from core_response_dataset import NS, read_json, rows, signature, window, power_rows, successful
from core_response_model import FEATURES, load_windows, fit_models
from core_recovery_rollout import fit
from evaluate_core_event_rollout import fit_event_transitions
from evaluate_core_response_model import annotate_service_labels
from core_plan_trajectory import evaluate_plan

SCHEDULE = [
    {'start_s':240, 'phase':'event', 'p_w':300, 'c':5},
    {'start_s':330, 'phase':'event', 'p_w':400, 'c':5},
    {'start_s':450, 'phase':'recovery', 'p_w':400, 'c':6}]


def evaluate(dataset, source, output):
    metadata = read_json(dataset/'REPORT.json')
    saved = read_json(source/'REPORT.json')
    identity = saved['episode_id']
    compatible = set()
    actual_signature = signature(source)[:2]
    for r in metadata['runs']:
        if r['group'] not in compatible and signature(Path(r['run']))[:2] == actual_signature:
            compatible.add(r['group'])
    if len(compatible) != 1:
        raise ValueError('Cannot uniquely match saved environment/admission group')
    group = next(iter(compatible))
    allowed = {r['run'] for r in metadata['runs'] if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    training = [r for r in load_windows(dataset/'action_windows.csv') if r['run'] in allowed and r['group']==group and r['episode_id']!=identity]
    annotate_service_labels(training)
    transition = {**fit_event_transitions(training), **fit(training)}
    response = fit_models(training)
    protocol = read_json(source/'protocol.json')
    start = int(protocol['start_wall_ns'])
    online,batch = rows(source/'online.jsonl'),rows(source/'batch.jsonl')
    jobs = rows(source/'batch_jobs.jsonl')
    states,actions = rows(source/'gateway_state.jsonl'),rows(source/'power_actions.jsonl')
    power = power_rows(source/'components.csv')
    # Verify that the supplied prospective schedule belongs to this measured run.
    for planned in SCHEDULE:
        matched = [r for r in actions if abs((int(r['begin_wall_ns'])-start)/NS-planned['start_s'])<1]
        if len(matched)!=1 or float(matched[0]['action']['power_cap_w'])!=planned['p_w'] or int(matched[0]['action']['batch_concurrency'])!=planned['c']:
            raise ValueError('Saved action receipt does not match the supplied schedule')
    complete = [r for r in batch if successful(r)]
    def remaining(second):
        return len(jobs)-sum(int(r['completion_wall_time_ns'])<=start+second*NS for r in complete)
    results=[]
    for origin in (240,450):
        raw = window(start+origin*NS,start+(origin+30)*NS,online,batch,len(jobs),states,actions,power)
        state = {key:raw.get(key) for key in FEATURES}
        state['group']=group
        plan=evaluate_plan(transition,response,state,origin,SCHEDULE)
        comparisons=[]
        for at in (450,750,1050,1350,1650,1950):
            if at<=origin:continue
            record=next((r for r in plan['records'] if r['end_s']==at),None)
            estimate=record['remaining_jobs_end'] if record else (0 if plan['predicted_completion_slot_end_s'] is not None and at>=plan['predicted_completion_slot_end_s'] else None)
            comparisons.append({'at_s':at,'predicted_remaining_jobs':estimate,'observed_remaining_jobs':remaining(at)})
        results.append({'origin_s':origin,**plan,'comparison':comparisons})
    actual_finish = max((int(r['completion_wall_time_ns'])-start)/NS for r in complete) if len(complete)==len(jobs) else None
    notes=[
        'Original 001710 identity is fully held out. No hyperparameter change or new run enters training.',
        'Each origin reads only its saved state; all later measurements supply labels only. The schedule was predetermined, not inferred from adaptive decisions.',
        'Origin 450 refreshes state from the same physical run; it does not measure a different controller trajectory.',
        'Constant-action next-state fits are composed across P and phase boundaries. This is an unvalidated switching approximation, not a fitted transition-cost model.',
        'Completion forecasts are continuous job approximations resolved to 30-second slot ends, not exact whole-job completion timestamps.',
        'Response and transition count fits retain their original differing sample eligibility; remaining jobs follow the transition fit only.',
        'After predicted cohort exhaustion batch demand is zero, but online-only power and service are unsupported; full-horizon energy remains missing.',
        'No optimization, guarantee, live receipt-time validation, GPU workload, retry or keepalive change.']
    report={'status':'CORE_FULL_PLAN_EVALUATED','training_identities':sorted({r['episode_id'] for r in training}),
            'actual_complete_job_finish_s':actual_finish,'plans':results,'notes':notes}
    output.mkdir(parents=True,exist_ok=True)
    (output/'REPORT.json').write_text(json.dumps(report,indent=2,allow_nan=False),encoding='utf-8')
    lines=['=== CORE_FULL_PLAN ===','STATUS='+report['status'],'ACTUAL_COMPLETE_JOB_FINISH_S='+str(actual_finish)]
    for plan in results:lines.append('PLAN='+json.dumps({k:v for k,v in plan.items() if k!='records'}))
    lines+=notes+['REPORT_JSON='+str(output/'REPORT.json')]
    (output/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines))


if __name__=='__main__':evaluate(*map(Path,sys.argv[1:]))
