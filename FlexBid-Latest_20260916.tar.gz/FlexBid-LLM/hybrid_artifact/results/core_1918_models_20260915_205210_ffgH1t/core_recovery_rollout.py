"""Fixed-action recovery rollout using learned next-state features."""
from collections import defaultdict
import json
from pathlib import Path
import sys

import numpy as np
from core_response_model import FEATURES, action_key, base_eligible, design, finite, fit_one, load_windows

NEXT_FEATURES = tuple(k for k in FEATURES if k != 'x_remaining_jobs')
COUNT = 'y_completed_jobs_next30'


def transitions(rows):
    index = {(r['run'], r['start_s']): r for r in rows}
    result = []
    for row in rows:
        nxt = index.get((row['run'], row['start_s'] + 30))
        if (row['phase'] != 'recovery' or not base_eligible(row) or nxt is None
                or action_key(row) != action_key(nxt)):
            continue
        result.append({**row, **{'next_' + k: nxt.get(k) for k in NEXT_FEATURES}})
    return result


def fit(rows):
    groups = defaultdict(list)
    for row in transitions(rows):
        groups[action_key(row)].append(row)
    return {k: {target: fit_one(v, target) for target in (COUNT,) + tuple('next_' + f for f in NEXT_FEATURES)}
            for k, v in groups.items()}


def advance(models, state):
    entry = models.get(action_key(state))
    if entry is None or any(value is None for value in entry.values()):
        return None
    result = {k: state.get(k) for k in FEATURES}
    for key in ('group', 'phase', 'x_p_w', 'x_c'):
        result[key] = state[key]
    values = {target: max(0., float((design([state], m['features']) @ np.asarray(m['coefficients']))[0]))
              for target, m in entry.items()}
    remaining = state['x_remaining_jobs']
    result['x_remaining_jobs'] = max(0., remaining - min(remaining, values[COUNT]))
    for feature in NEXT_FEATURES:
        result[feature] = values['next_' + feature]
    return result


def rollout(models, state, steps=10):
    # Later measured states and outcomes are intentionally absent from this interface.
    predicted = []
    current = state
    for _ in range(steps):
        current = advance(models, current)
        if current is None:
            return None
        predicted.append(current)
    return predicted


def stats(errors):
    if not errors:
        return {'n': 0, 'mae_jobs': None, 'bias_completed_jobs': None, 'maximum_overprediction_jobs': None}
    values = np.asarray(errors)
    return {'n': len(errors), 'mae_jobs': float(np.abs(values).mean()),
            'bias_completed_jobs': float(values.mean()),
            'maximum_overprediction_jobs': float(max(0, values.max()))}


def evaluate(rows, output):
    index = {(r['run'], r['start_s']): r for r in rows}
    records = []
    for identity in sorted({r['episode_id'] for r in rows}):
        models = fit([r for r in rows if r['episode_id'] != identity])
        for row in rows:
            if row['episode_id'] != identity or row['phase'] != 'recovery' or not finite(row['x_remaining_jobs']) or row['x_remaining_jobs'] <= 0:
                continue
            future = [index.get((row['run'], row['start_s'] + 30*i)) for i in range(11)]
            # Future records determine evaluation eligibility and labels, never rollout inputs.
            if any(x is None or action_key(x) != action_key(row) for x in future):
                continue
            if not all(x['segment_action_constant'] for x in future[:-1]):
                continue
            predicted = rollout(models, row)
            for step in (1, 5, 10):
                actual = row['x_remaining_jobs'] - future[step]['x_remaining_jobs']
                estimate = None if predicted is None else row['x_remaining_jobs'] - predicted[step-1]['x_remaining_jobs']
                records.append({'run':row['run'],'episode_id':identity,'c':row['x_c'],'start_s':row['start_s'],
                                'horizon_s':step*30,'remaining_start':row['x_remaining_jobs'],
                                'actual_completed':actual,'predicted_completed':estimate,
                                'actual_remaining_end':future[step]['x_remaining_jobs'],
                                'error':None if estimate is None else estimate-actual})
    groups=[]
    for identity,c in sorted({(r['episode_id'],r['c']) for r in records}):
        for duration in (30,150,300):
            selected=[r for r in records if (r['episode_id'],r['c'],r['horizon_s'])==(identity,c,duration)]
            groups.append({'episode_id':identity,'c':c,'horizon_s':duration,'eligible':len(selected),
                           'unpredicted':sum(r['error'] is None for r in selected),
                           'all':stats([r['error'] for r in selected if r['error'] is not None]),
                           'nonexhausted':stats([r['error'] for r in selected if r['error'] is not None and r['actual_remaining_end']>0])})
    notes=['Development state-transition fit: original 12 features and ridge=1; no parameter search.',
           'Batch counts update remaining jobs; eleven next-state feature regressions supply subsequent inputs. No measured future state is injected.',
           'Whole-identity holdout includes all repeats. Future rows select fixed-action evaluation intervals and supply labels only.',
           'Nonnegative continuous states and remaining-work clipping are numerical approximations, not a job-level simulator.',
           'No action switch, service certification, prospective deadline guarantee or active controller change is evaluated.',
           'Only complete 300-second saved-state spans are scored; no synthetic state at 1950 seconds is invented.',
           'Three reused identities and overlapping spans remain dependent development data; startup/cache differences remain.',
           'No GPU query, workload, retry or keepalive change.']
    report={'status':'CORE_FIXED_ACTION_ROLLOUT_EVALUATED','groups':groups,'notes':notes}
    output.mkdir(parents=True,exist_ok=True)
    with (output/'rollout_records.jsonl').open('w',encoding='utf-8') as stream:
        for row in records:stream.write(json.dumps(row)+'\n')
    (output/'REPORT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    lines=['=== CORE_FIXED_ACTION_ROLLOUT ===','STATUS='+report['status']]+['GROUP='+json.dumps(g) for g in groups]+notes+['REPORT_JSON='+str(output/'REPORT.json')]
    (output/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8');print('\n'.join(lines))
    return report


if __name__=='__main__':
    dataset,output=map(Path,sys.argv[1:])
    metadata=json.loads((dataset/'REPORT.json').read_text())
    allowed={r['run'] for r in metadata['runs'] if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    evaluate([r for r in load_windows(dataset/'action_windows.csv') if r['run'] in allowed],output)
