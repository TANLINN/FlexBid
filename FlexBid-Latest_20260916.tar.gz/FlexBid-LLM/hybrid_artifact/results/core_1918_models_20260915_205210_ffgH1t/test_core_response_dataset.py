import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import core_response_dataset as dataset
from core_response_dataset import NS, integrate, window


def request(dispatch, finish, *, tokens=1024, error=None, prompt=8192):
    return {'dispatch_wall_time_ns': dispatch * NS, 'completion_wall_time_ns': finish * NS,
            'status_code': 200, 'error': error, 'completion_tokens': tokens,
            'max_output_tokens': 1024, 'prompt_tokens': prompt,
            'ttft_ms': 1200., 'mean_tpot_ms': 22.}


class DatasetTests(unittest.TestCase):
    def extract(self, online=(), batch=(), actions=None, power=None, jobs=280):
        if actions is None:
            actions = [{'begin_wall_ns': 0, 'end_wall_ns': NS,
                        'action': {'power_cap_w': 300, 'batch_concurrency': 5}}]
        states = [{'wall_time_ns': 179 * NS, 'inflight_online': [1, 0, 1, 0],
                   'inflight_batch': [1, 1, 1, 1], 'online_waiting': 2, 'batch_waiting': 1},
                  {'wall_time_ns': 181 * NS, 'inflight_online': [99] * 4}]
        return window(180 * NS, 210 * NS, list(online), list(batch), jobs, states, actions,
                      power if power is not None else [(179 * NS, 1000.), (211 * NS, 1000.)])

    def test_future_results_do_not_change_inputs(self):
        old = request(160, 170)
        waiting = request(175, 190)
        a = self.extract([old, waiting], [old, waiting])
        future = request(181, 230, prompt=999999)
        waiting_changed = {**waiting, 'completion_wall_time_ns': 250 * NS,
                           'mean_tpot_ms': 90000., 'error': 'future failure'}
        b = self.extract([old, waiting_changed, future], [old, waiting_changed, future])
        self.assertEqual({k: v for k, v in a.items() if k.startswith('x_')},
                         {k: v for k, v in b.items() if k.startswith('x_')})
        self.assertEqual(a['x_batch_inflight_client'], 1)
        self.assertEqual(a['y_completed_jobs_next30'], 1)
        self.assertEqual(b['y_completed_jobs_next30'], 0)

    def test_failed_partial_and_late_completions(self):
        sample = self.extract(batch=[request(150, 175, tokens=1023), request(151, 176, error='bad'),
                                     request(152, 210), request(153, 211)])
        self.assertEqual(sample['x_completed_jobs'], 0)
        self.assertEqual(sample['x_remaining_jobs'], 280)
        self.assertEqual(sample['y_completed_jobs_next30'], 1)
        empty = self.extract(online=[], batch=[request(1, 2)], jobs=1)
        self.assertFalse(empty['segment_has_remaining_demand'])
        self.assertIsNone(empty['y_gap_p99_ms'])

    def test_actuation_delay_remains_in_transition_window(self):
        acts = [{'begin_wall_ns': 0, 'end_wall_ns': NS, 'action': {'power_cap_w': 400, 'batch_concurrency': 5}},
                {'begin_wall_ns': 180 * NS, 'end_wall_ns': 180 * NS + 100000000,
                 'action': {'power_cap_w': 300, 'batch_concurrency': 5}}]
        sample = self.extract(actions=acts)
        self.assertEqual(sample['x_p_w'], 400)
        self.assertFalse(sample['segment_action_constant'])
        self.assertEqual(sample['segment_transition_count'], 1)

    def test_power_integrates_edges_without_future_state(self):
        series = [(179 * NS, 100.), (211 * NS, 420.)]
        mean, gap = integrate(series, 180 * NS, 210 * NS)
        self.assertEqual(mean, 260.)
        self.assertEqual(gap, 32.)
        self.assertEqual(integrate(series, 178 * NS, 210 * NS), (None, None))
        sample = self.extract(power=series)
        self.assertEqual(sample['x_last_gpu_w'], 100.)
        self.assertEqual(sample['x_power_sample_age_s'], 1.)

    def test_saved_files_to_dataset_preserves_failed_service(self):
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp)
            cell = project / 'results' / dataset.CAMPAIGN / 'cells' / 'sample'
            cell.mkdir(parents=True)
            def save(name, value):
                (cell / name).write_text(json.dumps(value), encoding='utf-8')
            def ledger(name, value):
                (cell / name).write_text(''.join(json.dumps(r) + '\n' for r in value), encoding='utf-8')
            save('protocol.json', {'start_wall_ns': 0, 'deadline_wall_ns': 1950 * NS, 'cohort_release_offset_s': 150})
            save('REPORT.json', {'episode_id': 'fixture', 'service_and_deadline_pass_observed': False})
            save('ENVIRONMENT.json', {'gpu_inventory': {'returncode': 0, 'stdout': '0, A800, 80 GiB, driver, 400'}})
            (cell / 'config.yaml').write_text('hardware:\n  gpu_indices: [0]\nmodel: {}\nruntime: {}\n', encoding='utf-8')
            for name in ('priority_gateway.py', 'first_text_admission_tools.py', 'replica_batch_limit_tools.py', 'online_queue_priority_tools.py'):
                (cell / name).write_text('# saved source\n', encoding='utf-8')
            jobs = [{'job_id': str(i), 'max_output_tokens': 1024} for i in range(280)]
            ledger('batch_jobs.jsonl', jobs)
            batch = [{**j, 'dispatch_wall_time_ns': None, 'completion_wall_time_ns': None,
                      'status_code': None, 'completion_tokens': 0} for j in jobs]
            batch[0].update(request(155, 200))
            ledger('batch.jsonl', batch)
            ledger('online.jsonl', [{'request_id': 'o', **request(180, 212)}])
            ledger('gateway_state.jsonl', [{'wall_time_ns': 179 * NS, 'inflight_online': [1], 'inflight_batch': [1]}])
            ledger('power_actions.jsonl', [{'phase': 'event', 'begin_wall_ns': 150 * NS,
                    'end_wall_ns': 150 * NS + 100000000, 'action': {'power_cap_w': 300, 'batch_concurrency': 5},
                    'enforced_power_caps_w': {'0': 300}}])
            (cell / 'components.csv').write_text(f'wall_time_ns,aggregate_gpu_power_w\n0,1000\n{1951 * NS},1000\n', encoding='utf-8')
            out = project / 'out'
            with patch.object(dataset, 'EXTRA_RUNS', ()), patch('sys.argv', ['extract', '--project', str(project), '--output', str(out)]), contextlib.redirect_stdout(io.StringIO()):
                dataset.main()
            report = json.loads((out / 'REPORT.json').read_text(encoding='utf-8'))
            self.assertEqual(report['status'], 'CORE_RESPONSE_DATASET_EXTRACTED')
            self.assertEqual(report['windows'], 60)
            self.assertEqual(report['runs'][0]['on_time_jobs'], 1)
            self.assertIs(report['runs'][0]['saved_service_deadline_pass'], False)
            self.assertTrue((out / 'action_windows.csv').is_file())


if __name__ == '__main__':
    unittest.main()
