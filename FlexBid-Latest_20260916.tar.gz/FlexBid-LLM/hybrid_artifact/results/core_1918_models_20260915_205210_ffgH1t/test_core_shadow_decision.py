import unittest
from core_shadow_decision import observe


class ShadowTests(unittest.TestCase):
    def setUp(self):
        self.jobs=[{'job_id':'a','max_output_tokens':1024}]
        self.result={'job_id':'a','class':'batch','receipt_wall_time_ns':200,
                     'completion_wall_time_ns':100,'status_code':200,'error':None,'completion_tokens':1024}

    def run_observer(self,cutoff,scorer,results=None):
        return observe(self.jobs,[],results or [],[],[],cutoff,1000,'G1',scorer)

    def test_late_receipt_not_visible_and_new_feedback_changes_state(self):
        seen=[]
        def score(state,cutoff):
            seen.append(state['x_remaining_jobs']);return []
        first=self.run_observer(150,score,[self.result])
        second=self.run_observer(200,score,[self.result])
        self.assertEqual(seen,[1])
        self.assertEqual(first['status'],'SHADOW_NO_POINT_FEASIBLE_PLAN')
        self.assertEqual(second['status'],'COHORT_COMPLETE')
        self.assertFalse(first['actuation_performed'])

    def test_incomplete_output_does_not_complete_job(self):
        row={**self.result,'completion_tokens':1000}
        record=self.run_observer(250,lambda s,t:[],[row])
        self.assertEqual(record['state']['x_remaining_jobs'],1)

    def test_ranking_uses_supplied_current_state_without_actuation(self):
        def score(state,cutoff):
            self.assertEqual(cutoff,150)
            state['x_remaining_jobs']=999
            return [{'name':'c6','point_constraints_satisfied':True,'event_energy_wh':0,
                     'full_energy_wh':100,'switches':1}]
        result=self.run_observer(150,score)
        self.assertEqual(result['state']['x_remaining_jobs'],1)
        self.assertEqual(result['best_point_plan']['name'],'c6')
        self.assertFalse(result['actuation_performed'])

    def test_deadline_does_not_score(self):
        def unexpected(*args):raise AssertionError('must not score after deadline')
        self.assertEqual(self.run_observer(1000,unexpected)['status'],'DEADLINE_REACHED')


if __name__=='__main__':unittest.main()
