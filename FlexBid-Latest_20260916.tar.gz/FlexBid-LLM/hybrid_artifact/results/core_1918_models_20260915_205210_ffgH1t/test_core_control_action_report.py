import unittest
from core_control_action_report import summarize


class ActionReportTests(unittest.TestCase):
    def rows(self):
        a=dict(p_w=300,c=5,phase='event',start_s=150)
        return [{'status':'CONTROL_SOLUTION','cutoff_wall_ns':150*10**9,
                 'solution':{'status':'POINT_PLAN_SELECTED','first_action':a}},
                {'status':'CONTROL_APPLICATION','cutoff_wall_ns':150*10**9,
                 'result':{'status':'ACTION_ACKNOWLEDGED','action':dict(a),'wall_ns':151*10**9}}]
    def test_matching(self):
        r=summarize(self.rows());self.assertTrue(r['controller_records_consistent']);self.assertEqual(r['acknowledged_selections'],1)
    def test_selection_alone_is_not_execution(self):
        r=summarize(self.rows()[:1]);self.assertFalse(r['controller_records_consistent']);self.assertEqual(r['acknowledged_selections'],0)
    def test_wrong_action_and_late_ack(self):
        rows=self.rows();rows[1]['result']['action']['c']=6
        self.assertFalse(summarize(rows)['controller_records_consistent'])
        rows=self.rows();rows[1]['result']['wall_ns']=180*10**9
        self.assertFalse(summarize(rows)['controller_records_consistent'])
    def test_empty_or_failed_not_pass(self):
        self.assertFalse(summarize([])['controller_records_consistent'])
        self.assertFalse(summarize(self.rows()+[{'status':'ACTION_FAILED'}])['controller_records_consistent'])

if __name__=='__main__':unittest.main()

