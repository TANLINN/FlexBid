"""Extract timestamp-limited state and future labels from saved core runs."""
from __future__ import annotations

import argparse
from bisect import bisect_right
from collections import defaultdict
import csv
import json
import math
from pathlib import Path

NS = 1_000_000_000
CAMPAIGN = 'core_day_20260914_004803_OloTpA'
EXTRA_RUNS = (
    'core_recovery_pair_20260913_153538_g5oQsc/cells/queue_on',
    'core_cap_p400_20260913_165806_Ep6Wlc',
    'core_cap_confirmation_20260913_184507_S47i98/cells/p400',
    'core_cap_confirmation_20260913_184507_S47i98/cells/event_p300',
    'core_recovery_c5_20260913_204045_9oDcAT',
    'core_cap_p350_20260913_214939_jKQ4UQ',
    'core_conversation1710_20260913_224932_4gxDkM/cells/p400',
    'core_conversation1710_20260913_224932_4gxDkM/cells/event_p300',
)


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def rows(path):
    result = []
    with path.open(encoding='utf-8') as stream:
        for number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                for name in ('prompt_token_ids', 'stream_observations'):
                    row.pop(name, None)
                result.append(row)
            except (ValueError, AttributeError) as exc:
                raise ValueError(f'{path}:{number}: {exc}') from exc
    return result


def quantile(values, q):
    values = sorted(float(v) for v in values if v is not None and math.isfinite(float(v)))
    if not values:
        return None
    at = (len(values) - 1) * q
    lo = int(at)
    return values[lo] + (values[min(lo + 1, len(values) - 1)] - values[lo]) * (at - lo)


def successful(row):
    return (row.get('status_code') == 200 and row.get('error') is None
            and row.get('completion_wall_time_ns') is not None
            and row.get('completion_tokens') == row.get('max_output_tokens')
            and row.get('max_output_tokens') is not None)


def before(row, field, cutoff):
    return row.get(field) is not None and int(row[field]) <= cutoff


def integrate(series, left, right):
    if len(series) < 2 or series[0][0] > left or series[-1][0] < right:
        return None, None
    index = max(0, bisect_right([v[0] for v in series], left) - 1)
    energy, max_gap = 0., 0.
    while index + 1 < len(series) and series[index][0] < right:
        ta, va = series[index]
        tb, vb = series[index + 1]
        a, b = max(ta, left), min(tb, right)
        if b > a:
            pa = va + (vb - va) * (a - ta) / (tb - ta)
            pb = va + (vb - va) * (b - ta) / (tb - ta)
            energy += (pa + pb) * .5 * (b - a)
            max_gap = max(max_gap, (tb - ta) / NS)
        index += 1
    return energy / (right - left), max_gap


def power_rows(path):
    result = []
    with path.open(encoding='utf-8', newline='') as stream:
        for row in csv.DictReader(stream):
            value = row['aggregate_gpu_power_w']
            if value and math.isfinite(float(value)):
                result.append((int(row['wall_time_ns']), float(value)))
    result.sort()
    if any(b[0] <= a[0] for a, b in zip(result, result[1:])):
        raise ValueError('GPU telemetry has duplicate/nonincreasing sample times')
    return result


def window(left, right, online, batch, planned_jobs, states, actions, power):
    completed = [r for r in batch if before(r, 'completion_wall_time_ns', left) and successful(r)]
    in_flight = [r for r in batch if before(r, 'dispatch_wall_time_ns', left)
                 and not before(r, 'completion_wall_time_ns', left)]
    past_online = [r for r in online if before(r, 'completion_wall_time_ns', left)]
    recent_online = [r for r in past_online if int(r['completion_wall_time_ns']) > left - 60 * NS]
    arrivals = [r for r in online if before(r, 'dispatch_wall_time_ns', left)
                and int(r['dispatch_wall_time_ns']) > left - 60 * NS]
    snapshots = [r for r in states if int(r['wall_time_ns']) <= left]
    state = max(snapshots, key=lambda r: int(r['wall_time_ns'])) if snapshots else {}
    previous = [r for r in actions if int(r['end_wall_ns']) <= left]
    action_row = max(previous, key=lambda r: int(r['end_wall_ns'])) if previous else {}
    action = action_row.get('action', {})
    transitions = [r for r in actions if int(r['begin_wall_ns']) < right and int(r['end_wall_ns']) > left]
    completed_next = [r for r in batch if successful(r) and left < int(r['completion_wall_time_ns']) <= right]
    dispatched_next = [r for r in online if r.get('dispatch_wall_time_ns') is not None
                       and left <= int(r['dispatch_wall_time_ns']) < right]
    mean_power, gap = integrate(power, left, right)
    past_power = [r for r in power if r[0] <= left]
    valid_ttft = [r.get('ttft_ms') for r in dispatched_next if successful(r)]
    valid_stream = [r.get('mean_tpot_ms') for r in dispatched_next if successful(r)]
    active_online = state.get('inflight_online')
    active_batch = state.get('inflight_batch')
    mean_prompt = sum(float(r['prompt_tokens']) for r in arrivals) / len(arrivals) if arrivals else None
    return {
        'x_p_w': action.get('power_cap_w'), 'x_c': action.get('batch_concurrency'),
        'x_action_age_s': (left - int(action_row['end_wall_ns'])) / NS if action_row else None,
        'x_snapshot_age_s': (left - int(state['wall_time_ns'])) / NS if state else None,
        'x_online_active': sum(active_online) if active_online is not None else None,
        'x_batch_active_gateway': sum(active_batch) if active_batch is not None else None,
        'x_online_waiting': state.get('online_waiting'), 'x_batch_waiting': state.get('batch_waiting'),
        'x_completed_jobs': len(completed), 'x_remaining_jobs': planned_jobs - len(completed),
        'x_batch_inflight_client': len(in_flight),
        'x_oldest_batch_dispatch_age_s': max(((left - int(r['dispatch_wall_time_ns'])) / NS for r in in_flight), default=None),
        'x_recent60_completed_jobs': sum(int(r['completion_wall_time_ns']) > left - 60 * NS for r in completed),
        'x_recent60_online_dispatches': len(arrivals), 'x_recent60_prompt_mean': mean_prompt,
        'x_recent60_online_results': len(recent_online),
        'x_recent60_ttft_p95_ms': quantile([r.get('ttft_ms') for r in recent_online], .95),
        'x_recent60_gap_p99_ms': quantile([r.get('mean_tpot_ms') for r in recent_online], .99),
        'x_last_gpu_w': past_power[-1][1] if past_power else None,
        'x_power_sample_age_s': (left - past_power[-1][0]) / NS if past_power else None,
        'y_completed_jobs_next30': len(completed_next), 'y_mean_gpu_w': mean_power,
        'y_power_covered': mean_power is not None, 'y_power_max_gap_s': gap,
        'y_online_dispatched': len(dispatched_next),
        'y_online_error_or_incomplete': sum(not successful(r) for r in dispatched_next),
        'y_ttft_samples': sum(v is not None for v in valid_ttft),
        'y_gap_samples': sum(v is not None for v in valid_stream),
        'y_ttft_p95_ms': quantile(valid_ttft, .95), 'y_gap_p99_ms': quantile(valid_stream, .99),
        'y_gap_over100': sum(v is not None and v > 100 for v in valid_stream),
        'y_online_finishes_after_window': sum(r.get('completion_wall_time_ns') is not None
                                            and int(r['completion_wall_time_ns']) > right for r in dispatched_next),
        'segment_action_constant': bool(action_row) and not transitions,
        'segment_transition_count': len(transitions),
        'segment_has_remaining_demand': len(completed) < planned_jobs,
    }


def signature(root):
    import yaml
    env = read_json(root / 'ENVIRONMENT.json')
    config = yaml.safe_load((root / 'config.yaml').read_text(encoding='utf-8'))
    inventory = env.get('gpu_inventory', {})
    gpu_fields = []
    if inventory.get('returncode') == 0:
        for row in csv.reader(inventory.get('stdout', '').splitlines()):
            if len(row) >= 4:
                gpu_fields.append([part.strip() for part in row[1:4]])
    runtime = dict(config.get('runtime', {}))
    runtime.pop('priority_gateway_module', None)
    # Equality of saved content groups compatible software; no source is imported.
    program_names = ('priority_gateway.py', 'first_text_admission_tools.py',
                     'replica_batch_limit_tools.py', 'online_queue_priority_tools.py')
    programs = {name: (root / name).read_text(encoding='utf-8') for name in program_names}
    value = {'gpu_models_memory_drivers': gpu_fields, 'python': env.get('python'),
             'torch_cuda': env.get('torch_cuda'), 'packages': env.get('packages'),
             'model': config.get('model'), 'runtime': runtime}
    if not gpu_fields:
        value['unknown_environment_run'] = str(root)
    return value, programs, config


def extract(root):
    protocol = read_json(root / 'protocol.json')
    report = read_json(root / 'REPORT.json')
    start = int(protocol['start_wall_ns'])
    if (int(protocol['deadline_wall_ns']) - start != 1950 * NS
            or float(protocol['cohort_release_offset_s']) != 150):
        raise ValueError('Saved run does not use the current 150/1950-second cohort timeline')
    online, batch = rows(root / 'online.jsonl'), rows(root / 'batch.jsonl')
    jobs = rows(root / 'batch_jobs.jsonl')
    job_ids = {r['job_id'] for r in jobs}
    if len(jobs) != 280 or len(job_ids) != len(jobs):
        raise ValueError('Expected 280 unique planned cohort jobs')
    ledger_ids = [r['job_id'] for r in batch]
    if len(set(ledger_ids)) != len(ledger_ids) or set(ledger_ids) != job_ids:
        raise ValueError('Batch ledger does not include each planned job exactly once')
    online_ids = [r['request_id'] for r in online]
    if len(online_ids) != len(set(online_ids)):
        raise ValueError('Online ledger contains duplicate request IDs')
    states, actions = rows(root / 'gateway_state.jsonl'), rows(root / 'power_actions.jsonl')
    power = power_rows(root / 'components.csv')
    data = []
    for second in range(150, 1950, 30):
        data.append({'run': str(root), 'episode_id': report['episode_id'],
                     'start_s': second, 'phase': 'event' if second < 450 else 'recovery',
                     **window(start + second * NS, start + (second + 30) * NS,
                              online, batch, len(jobs), states, actions, power)})
    caps_match = all(r.get('enforced_power_caps_w') and all(
        float(v) == float(r['action']['power_cap_w']) for v in r['enforced_power_caps_w'].values()) for r in actions)
    summary = {'run': str(root), 'episode_id': report['episode_id'], 'windows': len(data),
               'saved_service_deadline_pass': report.get('service_and_deadline_pass_observed'),
               'on_time_jobs': sum(successful(r) and int(r['completion_wall_time_ns']) <= start + 1950 * NS for r in batch),
               'caps_match_saved_receipts': bool(actions) and caps_match,
               'conditions': read_json(root / 'CONDITION.json') if (root / 'CONDITION.json').is_file() else None,
               'actions': [{'phase': r['phase'], 'action': r['action'], 'control': r.get('control')} for r in actions]}
    return data, summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    base, output = args.project / 'results', args.output
    roots = sorted((base / CAMPAIGN / 'cells').glob('*/REPORT.json'))
    candidates = list(dict.fromkeys([p.parent for p in roots] + [base / name for name in EXTRA_RUNS]))
    data, summaries, errors, groups = [], [], [], []
    for root in candidates:
        try:
            identity, programs, config = signature(root)
            key = (identity, programs)
            group = next((i for i, g in enumerate(groups) if g['key'] == key), None)
            if group is None:
                group = len(groups)
                groups.append({'key': key, 'identity': identity})
            values, summary = extract(root)
            expected_gpus = {str(v) for v in config['hardware']['gpu_indices']}
            receipts = rows(root / 'power_actions.jsonl')
            summary['all_gpu_receipts_present'] = all(set(r.get('enforced_power_caps_w', {})) == expected_gpus for r in receipts)
            summary['group'] = f'G{group + 1}'
            for row in values:
                row['group'] = summary['group']
            data.extend(values)
            summaries.append(summary)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            errors.append({'run': str(root), 'error': f'{type(exc).__name__}: {exc}'})
    output.mkdir(parents=True, exist_ok=True)
    if data:
        with (output / 'action_windows.csv').open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(data)
    counts = defaultdict(lambda: {'runs': set(), 'identities': set(), 'windows': 0, 'demand_windows': 0, 'max_gap_samples': 0})
    for row in data:
        if row['segment_action_constant']:
            c = counts[(row['group'], row['phase'], row['x_p_w'], row['x_c'])]
            c['runs'].add(row['run']); c['identities'].add(row['episode_id'])
            c['windows'] += 1
            c['demand_windows'] += row['segment_has_remaining_demand']
            c['max_gap_samples'] = max(c['max_gap_samples'], row['y_gap_samples'])
    coverage = [{'group': k[0], 'phase': k[1], 'p_w': k[2], 'c': k[3],
                 **{name: len(v) if isinstance(v, set) else v for name, v in value.items()}}
                for k, value in sorted(counts.items())]
    report = {'status': 'CORE_RESPONSE_DATASET_EXTRACTED' if not errors else 'CORE_RESPONSE_DATASET_PARTIAL',
              'candidate_runs': len(candidates), 'extracted_runs': len(summaries),
              'identities': len({r['episode_id'] for r in summaries}), 'windows': len(data),
              'compatibility_groups': [{'id': f'G{i + 1}', **g['identity']} for i, g in enumerate(groups)],
              'coverage': coverage, 'runs': summaries, 'read_errors': errors,
              'notes': [
                  'Saved data only; no GPU queries, workload, retry, source edit, cache deletion or keepalive stop.',
                  'Features use dispatch/completion timestamps and preceding gateway snapshots; ledger receipt times are not recorded. Live visibility requires integration.',
                  'Labels use subsequent power/completions and completed outcomes of requests dispatched in the window, including finishes after that window.',
                  'Short-window p99 labels are not phase SLO certification; counts, sparse samples, transitions and exhausted cohorts remain present.',
                  'P/C coverage is observational and phase-confounded. Rows of the same workload identity must not be split across training and validation.',
                  'Compatibility groups compare saved GPU/software/configuration and admission source; they do not establish identical physical servers or model weights.',
                  'No model was fitted or certified; missing runs and keys are reported rather than replaced with zero.'
              ]}
    (output / 'REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    lines = ['=== CORE_RESPONSE_DATASET ===', 'STATUS=' + report['status'],
             f'RUNS={len(summaries)}/{len(candidates)} IDENTITIES={report["identities"]} WINDOWS={len(data)} GROUPS={len(groups)}']
    for c in coverage:
        lines.append('COVERAGE=' + json.dumps(c, ensure_ascii=False))
    for r in summaries:
        lines.append('RUN=' + json.dumps({k: r[k] for k in ('run', 'episode_id', 'group', 'on_time_jobs', 'saved_service_deadline_pass', 'caps_match_saved_receipts', 'all_gpu_receipts_present')}, ensure_ascii=False))
    lines += ['READ_ERRORS=' + json.dumps(errors, ensure_ascii=False), *report['notes'],
              'DATASET_CSV=' + str(output / 'action_windows.csv'), 'REPORT_JSON=' + str(output / 'REPORT.json')]
    (output / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
