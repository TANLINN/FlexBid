"""Prepare a standalone controlled collection entry from the saved runner."""
import ast
import json
import shutil
import sys
from pathlib import Path


def transform(source):
    tree=ast.parse(source)
    counts={'schedule':0,'workload':0,'gateway':0,'cleanup':0,'report':0}
    class Rewrite(ast.NodeTransformer):
        def visit_FunctionDef(self,node):
            if node.name=='workload':
                node.body=ast.parse('from core_control_workload import run_workload\nrun_workload(m,output)').body
                counts['workload']+=1;return node
            return self.generic_visit(node)
        def visit_Assign(self,node):
            if any(isinstance(t,ast.Name) and t.id=='schedule' for t in node.targets):
                counts['schedule']+=1
                return ast.parse('''from core_parent_runtime import ParentRuntime
def write_selected(desired, priority):
    return apply_recovery_control(Path(config['hardware']['control_file']), desired, len(config['model']['replicas']), 12, priority)
schedule = ParentRuntime(output, power_caps, lambda p,c: m.select_recovery_action(actions,p,c), write_selected, lambda: get_json(base+'/flexbid/state'), emit_cap, start)
emit_cap({'phase':'warmup','end_wall_ns':time.time_ns(),'action':action.as_dict()})''').body
            return self.generic_visit(node)
        def visit_Expr(self,node):
            value=ast.unparse(node)
            if value=="shutil.copyfile(source / 'priority_gateway.py', output / 'priority_gateway.py')":
                counts['gateway']+=1
                return ast.parse("from core_gateway_feedback import patched_source\n(output/'priority_gateway.py').write_text(patched_source((source/'priority_gateway.py').read_text(encoding='utf-8')),encoding='utf-8')").body
            if value.startswith("m.write_json(output / 'POWER_CAP_RESTORED.json'"):
                counts['cleanup']+=1
                return ast.parse("if 'schedule' in locals():\n    schedule.close()\n").body+[node]
            return self.generic_visit(node)
        def visit_Call(self,node):
            if ast.unparse(node.func)=='schedule.sleep_duration':
                return ast.Call(func=ast.Name(id='min',ctx=ast.Load()),args=[ast.Constant(1.),ast.Call(func=ast.Name(id='max',ctx=ast.Load()),args=[ast.Constant(0.),ast.parse('end-time.monotonic()',mode='eval').body],keywords=[])],keywords=[])
            return self.generic_visit(node)
        def visit_Try(self,node):
            if any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='analyze_cell' for item in node.body for n in ast.walk(item)):
                counts['report']+=1
                node.body=ast.parse("from core_control_report import write_report\nwrite_report(output,m,config)").body
                return node
            return self.generic_visit(node)
    tree=Rewrite().visit(tree)
    if any(v!=1 for v in counts.values()):raise ValueError('Unexpected saved runner structure: '+repr(counts))
    # Fixed-policy descriptors must not label adaptive actions as a fixed schedule.
    class Metadata(ast.NodeTransformer):
        def visit_Dict(self,node):
            self.generic_visit(node)
            # Protocol concurrency defaults are still required by the saved reader;
            # actual execution is supplied by the dynamic adapter and receipts.
            for i,k in enumerate(node.keys):
                if isinstance(k,ast.Constant) and k.value=='purpose':node.values[i]=ast.Constant('Finite-candidate rolling control collection')
                if isinstance(k,ast.Constant) and k.value=='condition':node.values[i]=ast.Constant('finite_candidate_control')
                if isinstance(k,ast.Constant) and k.value=='power_cap_sequence_w_per_gpu':node.values[i]=ast.Constant(None)
            return node
    tree=Metadata().visit(tree)
    return ast.unparse(ast.fix_missing_locations(tree))+'\n',counts


def prepare(source,modules,output):
    cell=output/'cell';cell.mkdir(exist_ok=False)
    (cell/'logs').mkdir()
    for p in source.glob('*.py'):shutil.copyfile(p,cell/p.name)
    for p in modules.glob('*.py'):shutil.copyfile(p,cell/p.name)
    for name in ('SHADOW_MODELS.json','CONDITION.json'):
        shutil.copyfile(source/name,cell/name)
    code,counts=transform((source/'run_core_shadow.py').read_text(encoding='utf-8'))
    (cell/'run_core_control.py').write_text(code,encoding='utf-8')
    for p in cell.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'),feature_version=(3,10))
    report={'status':'CORE_CONTROL_RUNNER_PREPARED_CPU_ONLY','cell':str(cell),'changes':counts,
            'gpu_workload':False,'installed':False,'launcher_executed':False,
            'collection_report':'Original outcome metrics plus controller records; full joint pass remains unverified',
            'scope':'Prepared source; full simulated hardware-launcher execution remains pending.'}
    (output/'REPORT.json').write_text(json.dumps(report,indent=2))
    print('=== CORE_CONTROL_RUNNER_PREPARATION ===');print(json.dumps(report))
    print('REPORT_JSON='+str(output/'REPORT.json'))

if __name__=='__main__':prepare(*map(Path,sys.argv[1:]))

