"""Report either cap condition using the existing service and cohort accounting."""
from core_recovery_cell_report import analyze_cell as measured, cell_text as measured_text


def analyze_cell(output, config, source, event_cap):
    result = measured(output, config, source, event_cap)
    result['status'] = 'CORE_DAY_CELL_MEASURED'
    result['condition'] = 'p400' if event_cap == 400 else 'event_p300'
    result['limitations'][0] = f'{result["episode_id"]}; event C5/P{event_cap:g}, recovery C6/P400; uncached512 and twelve online slots.'
    result['limitations'][1] = 'Recovery online-queue priority and all admission rules remain identical in both cap conditions.'
    return result


def cell_text(result):
    return measured_text(result).replace('=== CORE_RECOVERY_CELL_RESULT ===', '=== CORE_DAY_CELL_RESULT ===')
