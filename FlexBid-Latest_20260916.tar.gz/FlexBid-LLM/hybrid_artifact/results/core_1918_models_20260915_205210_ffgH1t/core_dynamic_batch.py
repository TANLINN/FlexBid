"""Resizable batch admission and complete-job accounting."""
import asyncio
import time


class BatchAdmission:
    def __init__(self, limit):
        self.active = 0
        self.condition = asyncio.Condition()
        self.limit = self.validate(limit)

    @staticmethod
    def validate(limit):
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 0:
            raise ValueError('Batch concurrency must be a nonnegative integer')
        return limit

    async def resize(self, limit):
        limit = self.validate(limit)
        async with self.condition:
            self.limit = limit
            self.condition.notify_all()

    async def acquire(self, deadline):
        async with self.condition:
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                if self.active < self.limit:
                    self.active += 1
                    return True
                try:
                    await asyncio.wait_for(self.condition.wait(), remaining)
                except asyncio.TimeoutError:
                    return False

    async def release(self):
        async with self.condition:
            if self.active <= 0:
                raise RuntimeError('Batch admission release without acquisition')
            self.active -= 1
            self.condition.notify_all()


def cohort_state(jobs, records, deadline_wall_ns, visible_wall_ns):
    expected = {r['job_id']:r for r in jobs}
    if len(expected) != len(jobs):
        raise ValueError('Duplicate job ID')
    received = {}
    seen = set()
    for row in records:
        if row['job_id'] not in expected or row['job_id'] in seen:
            raise ValueError('Unknown or duplicate result ID')
        seen.add(row['job_id'])
        if row['receipt_wall_time_ns'] <= visible_wall_ns:
            received[row['job_id']] = row
    on_time, late, failed = [], [], []
    for key,row in received.items():
        finish = row.get('completion_wall_time_ns')
        full = (row.get('error') is None and row.get('status_code') == 200
                and row.get('completion_tokens') == expected[key]['max_output_tokens'] and finish is not None)
        (on_time if full and finish <= deadline_wall_ns else late if full else failed).append(key)
    return {'planned_jobs':len(jobs),'complete_on_time':len(on_time),
            'complete_late':len(late),'failed_or_unstarted':len(failed),
            'no_visible_result':len(jobs)-len(received),
            'remaining_for_deadline':len(jobs)-len(on_time),
            'all_jobs_complete_on_time':len(on_time)==len(jobs)}


async def execute_batch(jobs, admission, release_mono, deadline_mono, drain_mono, request, emit):
    """Request callback returns the existing per-job metric dictionary."""
    ids=[r['job_id'] for r in jobs]
    if len(set(ids)) != len(ids):
        raise ValueError('Duplicate job ID')
    if not release_mono <= deadline_mono <= drain_mono:
        raise ValueError('Invalid batch timeline')
    tasks=[]
    next_job=0

    def record(row, metric, status):
        clean={k:v for k,v in row.items() if k!='prompt_token_ids'}
        clean.update(metric)
        clean['job_id']=row['job_id']
        clean['job_status']=status
        clean['receipt_wall_time_ns']=time.time_ns()
        emit(clean)

    async def invoke(row):
        dispatch=time.time_ns()
        try:
            if time.monotonic() >= deadline_mono:
                record(row,{'dispatch_wall_time_ns':None,'completion_wall_time_ns':None,
                            'completion_tokens':0,'status_code':None,'error':None},'not_started_by_deadline')
                return
            remaining=drain_mono-time.monotonic()
            if remaining <= 0:
                raise asyncio.TimeoutError()
            metric=await asyncio.wait_for(request(row),remaining)
            record(row,metric,'finished_attempt')
        except asyncio.TimeoutError:
            record(row,{'dispatch_wall_time_ns':dispatch,'completion_wall_time_ns':time.time_ns(),
                        'completion_tokens':0,'status_code':None,'error':'drain_timeout'},'finished_attempt')
        finally:
            await admission.release()

    try:
        await asyncio.sleep(max(0.,release_mono-time.monotonic()))
        while next_job<len(jobs) and await admission.acquire(deadline_mono):
            row=jobs[next_job]
            next_job+=1
            tasks.append(asyncio.create_task(invoke(row)))
            await asyncio.sleep(0)
        await asyncio.gather(*tasks)
        for row in jobs[next_job:]:
            record(row,{'dispatch_wall_time_ns':None,'completion_wall_time_ns':None,
                        'completion_tokens':0,'status_code':None,'error':None},'not_started_by_deadline')
    finally:
        for task in tasks:
            if not task.done():task.cancel()
        await asyncio.gather(*tasks,return_exceptions=True)

