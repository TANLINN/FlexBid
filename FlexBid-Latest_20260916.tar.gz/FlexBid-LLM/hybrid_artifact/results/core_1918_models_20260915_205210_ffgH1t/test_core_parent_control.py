import asyncio
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from core_batch_control import write_json
from core_parent_control import ParentClient,ParentControl


class ParentTests(unittest.IsolatedAsyncioTestCase):
    async def test_request_from_separate_process_and_single_application(self):
        with tempfile.TemporaryDirectory() as d:
            calls=[]
            def power(p):calls.append(p);return {'pid':os.getpid(),'p':p}
            parent=ParentControl(d,power,lambda:None)
            script="import asyncio,sys,time,json;from core_parent_control import ParentClient;print(json.dumps(asyncio.run(ParentClient(sys.argv[1]).request('power',{'p':300},time.time_ns()+5_000_000_000))))"
            child=subprocess.Popen([sys.executable,'-B','-c',script,d],cwd=Path(__file__).resolve().parent,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            try:
                until=time.monotonic()+6
                while child.poll() is None and time.monotonic()<until:
                    parent.poll();await asyncio.sleep(.01)
                out,err=await asyncio.to_thread(child.communicate,timeout=1)
                self.assertEqual(child.returncode,0,err.decode())
                self.assertEqual(json.loads(out)['pid'],os.getpid())
                parent.poll();self.assertEqual(calls,[300])
            finally:
                if child.poll() is None:child.kill();child.communicate()

    async def test_expired_request_never_executes(self):
        with tempfile.TemporaryDirectory() as d:
            write_json(Path(d)/'parent_request.json',dict(sequence=1,operation='power',arguments={},expires_ns=5))
            parent=ParentControl(d,lambda:self.fail('Unexpected operation'),lambda:None,clock=lambda:5)
            with self.assertRaises(TimeoutError):parent.poll()
            self.assertTrue(parent.closed)

    async def test_closed_parent_and_stale_ack(self):
        with tempfile.TemporaryDirectory() as d:
            parent=ParentControl(d,lambda:self.fail('Unexpected operation'),lambda:None)
            parent.close();parent.poll()
            write_json(Path(d)/'parent_ack.json',dict(sequence=0,status='APPLIED',result={}))
            client=ParentClient(d)
            with self.assertRaises(TimeoutError):
                await client.request('power',{'p':300},time.time_ns()+30_000_000)
            self.assertTrue(client.failed)

if __name__=='__main__':unittest.main()

