import contextlib
import csv
import io
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np

import core_response_model as model
from evaluate_core_response_model import NS, cross_transition, evaluate
from analyze_core_response_errors import analyze
from evaluate_core_batch_feedback import evaluate as evaluate_feedback


def sample(identity, run, start=180, p=300, power=2000):
    return {
        'episode_id': identity, 'run': run, 'group': 'G1', 'phase': 'event',
        'start_s': start, 'x_p_w': p, 'x_c': 5,
        'segment_action_constant': True, 'segment_has_remaining_demand': True,
        'y_power_covered': True, 'service_labels_cross_transition': False,
        'x_online_active': 4., 'x_remaining_jobs': 280., 'x_last_gpu_w': power,
        'x_recent60_prompt_mean': None,
        'y_mean_gpu_w': power + 10, 'y_completed_jobs_next30': 5.,
        'y_ttft_p95_ms': 1200., 'y_gap_p99_ms': 25.,
        'y_online_error_or_incomplete': 0, 'y_ttft_samples': 1, 'y_gap_samples': 1,
        'y_online_dispatched': 1,
    }


class ModelTests(unittest.TestCase):
    def test_repeated_identity_is_held_out_as_a_whole(self):
        rows = [sample('A', 'a1'), sample('A', 'a2', power=2100),
                sample('B', 'b1', power=2300), sample('C', 'c1', power=2400)]
        records, folds = model.validate_identities(rows)
        a = next(f for f in folds if f['held_out_identity'] == 'A')
        self.assertEqual(a['training_runs'], ['b1', 'c1'])
        self.assertEqual(a['test_runs'], ['a1', 'a2'])
        altered = [{**r, 'y_mean_gpu_w': 999999} if r['episode_id'] == 'A' else r for r in rows]
        second, _ = model.validate_identities(altered)
        self.assertEqual([r['pred_y_mean_gpu_w'] for r in records if r['episode_id'] == 'A'],
                         [r['pred_y_mean_gpu_w'] for r in second if r['episode_id'] == 'A'])
        fit = model.fit_models([r for r in rows if r['episode_id'] != 'A'])
        features = fit[0]['targets']['y_mean_gpu_w']['features']
        self.assertEqual(next(f['mean'] for f in features if f['name'] == 'x_last_gpu_w'), 2350.)
        self.assertNotIn('episode_id', model.FEATURES)

    def test_single_identity_action_stays_unpredicted(self):
        rows = [sample('A', 'a', p=350), sample('B', 'b'), sample('C', 'c')]
        records, _ = model.validate_identities(rows)
        held = next(r for r in records if r['episode_id'] == 'A')
        self.assertEqual(held['prediction_status'], 'NO_TRAINING_ACTION')
        self.assertIsNone(held['pred_y_mean_gpu_w'])
        self.assertEqual(model.summarize([held], 'y_mean_gpu_w')['unpredicted_windows'], 1)
        self.assertEqual(model.service_confusion([held])['unscored'], 1)

    def test_weights_balance_identities_and_runs(self):
        rows = [sample('A', 'a1', start=s) for s in (180, 210, 240)]
        rows += [sample('A', 'a2'), sample('B', 'b1')]
        weights = model.sample_weights(rows)
        self.assertAlmostEqual(weights[:3].sum(), .25)
        self.assertAlmostEqual(weights[3], .25)
        self.assertAlmostEqual(weights[4], .5)
        fitted = model.fit_one(rows, 'y_mean_gpu_w')
        doubled = model.fit_one(rows + rows, 'y_mean_gpu_w')
        np.testing.assert_allclose(fitted['coefficients'], doubled['coefficients'])

    def test_error_direction_and_extrapolation_are_retained(self):
        record = {'episode_id': 'A'}
        for target in model.TARGETS:
            record.update({target: 10., 'pred_' + target: 7., 'score_' + target: True,
                           'outside_' + target: 1})
        self.assertEqual(model.summarize([record], 'y_mean_gpu_w')['optimistic_error_p95'], 3.)
        self.assertEqual(model.summarize([record], 'y_completed_jobs_next30')['optimistic_error_p95'], 0.)
        record['pred_y_completed_jobs_next30'] = 13.
        self.assertEqual(model.summarize([record], 'y_completed_jobs_next30')['optimistic_error_p95'], 3.)
        self.assertEqual(model.summarize([record], 'y_mean_gpu_w')['outside_training_range_windows'], 1)

    def test_transition_attribution_does_not_remove_power_or_batch_labels(self):
        request = {'dispatch_wall_time_ns': 449 * NS, 'completion_wall_time_ns': 452 * NS}
        self.assertTrue(cross_transition([request], [450 * NS]))
        self.assertFalse(cross_transition([{**request, 'completion_wall_time_ns': 450 * NS}], [450 * NS]))
        self.assertTrue(cross_transition([{**request, 'completion_wall_time_ns': None}], [450 * NS]))
        row = {**sample('A', 'a'), 'service_labels_cross_transition': True}
        self.assertFalse(model.eligible(row, 'y_gap_p99_ms'))
        self.assertTrue(model.eligible(row, 'y_mean_gpu_w'))
        self.assertTrue(model.eligible(row, 'y_completed_jobs_next30'))
        self.assertEqual(row['y_gap_p99_ms'], 25.)

    def test_saved_files_to_reports_and_callable_model(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            data, output = root / 'data', root / 'output'
            data.mkdir()
            output.mkdir()
            windows, runs = [], []
            for index, identity in enumerate(('A', 'B', 'C')):
                cell = root / identity
                cell.mkdir()
                (cell / 'protocol.json').write_text(json.dumps({'start_wall_ns': 0, 'deadline_wall_ns': 1950 * NS}))
                (cell / 'power_actions.jsonl').write_text(json.dumps({'begin_wall_ns': 150 * NS}) + '\n')
                ledger = [{'dispatch_wall_time_ns': t * NS, 'completion_wall_time_ns': (t + 2) * NS} for t in (181, 211)]
                (cell / 'online.jsonl').write_text(''.join(json.dumps(r) + '\n' for r in ledger))
                runs.append({'run': str(cell), 'episode_id': identity, 'on_time_jobs': 271 if index == 0 else 280,
                             'saved_service_deadline_pass': index != 0,
                             'caps_match_saved_receipts': True, 'all_gpu_receipts_present': True})
                for t in (180, 210):
                    row = sample(identity, str(cell), start=t, power=2000 + index * 100)
                    row.pop('service_labels_cross_transition')
                    if index == 0:
                        row['y_gap_p99_ms'] = 140.
                    windows.append(row)
            with (data / 'action_windows.csv').open('w', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=list(windows[0]))
                writer.writeheader()
                writer.writerows(windows)
            (data / 'REPORT.json').write_text(json.dumps({'windows': len(windows), 'runs': runs}))
            with contextlib.redirect_stdout(io.StringIO()):
                report = evaluate(data, output)
            self.assertEqual(report['status'], 'CORE_RESPONSE_MODEL_DIAGNOSTIC_COMPLETE')
            self.assertEqual(len(report['folds']), 3)
            self.assertEqual(report['counts']['all'], 6)
            self.assertEqual(len(report['saved_failed_runs']), 1)
            failure = report['saved_failed_runs'][0]['service_window_confusion']
            self.assertEqual(failure['false_safe'], 2)
            self.assertEqual(failure['observed_threshold_violations'], 2)
            document = json.loads((output / 'MODEL.json').read_text(encoding='utf-8'))
            point = model.predict(document['models'], windows[0])
            self.assertEqual(set(point['values']), set(model.TARGETS))
            self.assertFalse(document['active_controller_changed'])
            self.assertTrue((output / 'held_out_predictions.csv').is_file())
            self.assertTrue((output / 'REPORT.txt').is_file())
            with contextlib.redirect_stdout(io.StringIO()):
                diagnostic = analyze(output, root / 'errors')
            self.assertEqual(diagnostic['range_count_mismatches'], [])
            self.assertTrue(diagnostic['false_safe_count_matches_saved_report'])
            self.assertEqual(len(diagnostic['false_safe_windows']), 2)
            with contextlib.redirect_stdout(io.StringIO()):
                feedback = evaluate_feedback(output, root / 'feedback')
            self.assertEqual(feedback['status'], 'CORE_BATCH_FEEDBACK_DIAGNOSTIC_COMPLETE')
            self.assertEqual(feedback['rows'], 6)
            self.assertEqual(feedback['rows_using_feedback'], 3)
            self.assertEqual(feedback['original_service_false_safe_windows_unchanged'], 2)
            self.assertEqual(feedback['identity_equal_metrics']['feedback']['identities'], 3)
            self.assertTrue((root / 'feedback' / 'REPORT.txt').is_file())
            with (root / 'feedback' / 'feedback_predictions.csv').open() as stream:
                records = list(csv.DictReader(stream))
            self.assertEqual(len(records), 6)
            self.assertEqual(sum(int(r['feedback_windows']) for r in records), 3)


if __name__ == '__main__':
    unittest.main()
