import asyncio
import json
from pathlib import Path
import tempfile
import unittest

from core_shadow_feed import ShadowFeed
from core_shadow_session import run_session

NS = 1_000_000_000


class SessionTests(unittest.IsolatedAsyncioTestCase):
    async def test_telemetry_is_available_to_scoring_and_workload_drains(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'components.csv').write_text('wall_time_ns,aggregate_gpu_power_w\n149000000000,2300\n')
            (root/'power_actions.jsonl').write_text(json.dumps({'end_wall_ns':149*NS,'action':{'power_cap_w':300,'batch_concurrency':5}})+'\n')
            observed = asyncio.Event()
            records = []
            def score(state, cutoff):
                self.assertEqual(state['x_last_gpu_w'],2300)
                self.assertEqual(state['x_p_w'],300)
                return []
            feed = ShadowFeed([{'job_id':'a','max_output_tokens':2}],1950*NS,'G1',score,lambda:150*NS)
            def emit(row):
                records.append(row)
                observed.set()
            async def workload():
                await observed.wait()
                feed.result('batch',{'job_id':'a','completion_wall_time_ns':150*NS,
                                     'status_code':200,'completion_tokens':2})
                return 'requests finished'
            result = await asyncio.wait_for(run_session(feed,0,root,workload,emit),2)
            self.assertEqual(result,'requests finished')
            self.assertEqual(len(records),1)
            self.assertFalse(records[0]['actuation_performed'])
            self.assertEqual(feed.decision(150*NS)['status'],'COHORT_COMPLETE')

    async def test_telemetry_failure_cancels_workload(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            cancelled = asyncio.Event()
            feed = ShadowFeed([],1950*NS,'G1',lambda s,t:[],lambda:0)
            async def workload():
                (root/'gateway_state.jsonl').write_text('not json\n')
                try:
                    await asyncio.sleep(10)
                finally:
                    cancelled.set()
            with self.assertRaises(json.JSONDecodeError):
                await asyncio.wait_for(run_session(feed,0,root,workload,lambda r:None,.001),2)
            self.assertTrue(cancelled.is_set())

    async def test_scoring_failure_cancels_workload(self):
        with tempfile.TemporaryDirectory() as directory:
            cancelled = asyncio.Event()
            def score(*args):
                raise RuntimeError('scoring failed')
            feed = ShadowFeed([{'job_id':'a','max_output_tokens':2}],1950*NS,'G1',score,lambda:150*NS)
            async def workload():
                try:
                    await asyncio.sleep(10)
                finally:
                    cancelled.set()
            with self.assertRaisesRegex(RuntimeError,'scoring failed'):
                await asyncio.wait_for(run_session(feed,0,directory,workload,lambda r:None),2)
            self.assertTrue(cancelled.is_set())


if __name__ == '__main__':
    unittest.main()

