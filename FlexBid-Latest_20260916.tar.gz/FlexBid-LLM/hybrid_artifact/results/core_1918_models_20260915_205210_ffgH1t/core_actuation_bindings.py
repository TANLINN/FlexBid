"""Bind acknowledged callbacks to existing batch, gateway and power controls."""
import asyncio

from core_batch_control import publish_limit
from core_gateway_feedback import wait_gateway


class ActuationBindings:
    def __init__(self, output, power_manager, select_action, write_gateway,
                 read_gateway, initial_p=400, client_timeout=2., gateway_timeout=2.):
        self.output=output
        self.power_manager=power_manager
        self.select_action=select_action
        self.write_gateway=write_gateway
        self.read_gateway=read_gateway
        self.p=initial_p
        self.sequence=0
        self.client_timeout=client_timeout
        self.gateway_timeout=gateway_timeout

    async def client(self,c):
        self.sequence+=1
        await publish_limit(self.output/'batch_control.json',self.output/'batch_ack.json',
                            self.sequence,c,timeout=self.client_timeout)

    async def gateway(self,c,priority):
        action=self.select_action(self.p,c)
        # Existing writer returns its complete control document.
        expected=await asyncio.to_thread(self.write_gateway,action,priority)
        if (expected['defer_batch_for_online_queue']!=priority
                or expected['batch_concurrency']!=max(1,c)
                or expected['batch_paused']!=(c==0)):
            raise ValueError('Gateway document differs from selected admission action')
        async def read():
            return await asyncio.to_thread(self.read_gateway)
        return await wait_gateway(read,expected,timeout=self.gateway_timeout)

    async def power(self,p):
        # The parent retains ownership of PowerCapManager and its restoration.
        values=await asyncio.to_thread(self.power_manager.set_all,p)
        self.p=p
        return {str(index):value for index,value in values.items()}

