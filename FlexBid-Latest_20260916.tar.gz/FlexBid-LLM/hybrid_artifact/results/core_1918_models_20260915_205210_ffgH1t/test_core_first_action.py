import unittest

from core_first_action import FirstActionExecutor


def solution(p=400,c=6,phase='recovery'):
    return {'status':'POINT_PLAN_SELECTED','first_action':{'p_w':p,'c':c,'phase':phase,'start_s':450}}


class ActionTests(unittest.IsolatedAsyncioTestCase):
    def make(self,p=300,c=5,fail=None,caps=None,clock=lambda:0):
        self.calls=[];self.records=[]
        async def client(c):
            self.calls.append(('client',c))
            if fail=='client':raise TimeoutError('client ACK missing')
        async def gateway(c,priority):
            self.calls.append(('gateway',c,priority))
            if fail=='gateway':raise TimeoutError('gateway ACK missing')
        async def power(p):
            self.calls.append(('power',p))
            return {str(i):p for i in range(8)} if caps is None else caps
        return FirstActionExecutor(p,c,client,gateway,power,self.records.append,clock)

    async def test_increase_after_power_and_gateway_ack(self):
        ex=self.make()
        await ex.apply(solution(),100)
        self.assertEqual(self.calls,[('power',400),('gateway',6,True),('client',6)])
        self.assertEqual((ex.p,ex.c),(400,6))

    async def test_decrease_before_power(self):
        ex=self.make(400,6)
        await ex.apply(solution(300,5,'event'),100)
        self.assertEqual(self.calls,[('client',5),('gateway',5,False),('power',300)])

    async def test_same_c_still_refreshes_phase_priority(self):
        ex=self.make(400,6)
        await ex.apply(solution(),100)
        self.assertEqual(self.calls,[('gateway',6,True)])

    async def test_missing_gateway_ack_stops_before_client(self):
        ex=self.make(fail='gateway')
        with self.assertRaises(TimeoutError):await ex.apply(solution(),100)
        self.assertNotIn(('client',6),self.calls)
        with self.assertRaises(RuntimeError):await ex.apply(solution(),100)
        self.assertEqual(len(self.calls),2)

    async def test_bad_power_receipt_stops_before_admission(self):
        ex=self.make(caps={'0':400})
        with self.assertRaises(RuntimeError):await ex.apply(solution(),100)
        self.assertEqual(self.calls,[('power',400)])

    async def test_no_solution_and_expired_do_not_actuate(self):
        ex=self.make(clock=lambda:100)
        self.assertEqual((await ex.apply(solution(),100))['status'],'ACTION_EXPIRED')
        self.assertEqual((await ex.apply({'status':'NO_POINT_FEASIBLE_PLAN'},200))['status'],'NO_ACTION')
        self.assertEqual(self.calls,[])

    async def test_partial_action_expiry_is_failure(self):
        counter=iter([0,0,0,0,0,100,100])
        ex=self.make(clock=lambda:next(counter,100))
        with self.assertRaises(TimeoutError):await ex.apply(solution(),100)
        self.assertTrue(ex.failed)
        self.assertNotIn(('client',6),self.calls)

    async def test_stop_after_final_ack_is_success(self):
        stopped=[False];calls=[]
        async def client(c):
            calls.append('client');stopped[0]=True
        async def gateway(c,priority):calls.append('gateway')
        async def power(p):return {str(i):p for i in range(8)}
        ex=FirstActionExecutor(400,5,client,gateway,power,lambda r:None,clock=lambda:0)
        r=await ex.apply(solution(),100,stopped=lambda:stopped[0])
        self.assertEqual(r['status'],'ACTION_ACKNOWLEDGED')
        self.assertEqual(calls,['gateway','client'])
        self.assertFalse(ex.failed)

    async def test_stop_does_not_hide_final_callback_failure(self):
        stopped=[False]
        async def client(c):
            stopped[0]=True;raise TimeoutError('missing final ACK')
        async def gateway(c,priority):pass
        async def power(p):return {str(i):p for i in range(8)}
        ex=FirstActionExecutor(400,5,client,gateway,power,lambda r:None,clock=lambda:0)
        with self.assertRaisesRegex(TimeoutError,'missing final ACK'):
            await ex.apply(solution(),100,stopped=lambda:stopped[0])
        self.assertTrue(ex.failed)

if __name__=='__main__':unittest.main()

