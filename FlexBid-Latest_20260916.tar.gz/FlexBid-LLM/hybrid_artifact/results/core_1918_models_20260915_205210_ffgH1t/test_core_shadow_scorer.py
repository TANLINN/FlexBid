import unittest
from core_shadow_scorer import ShadowScorer
from core_shadow_decision import observe
from core_response_model import FEATURES

NS=1_000_000_000


def model(value):
    return {'features':[],'coefficients':[value],'training_identities':['synthetic']}


def models():
    tm={};rm=[]
    for c in (5,6):
        key=('G1','recovery',400.,c)
        tm[key]={'y_completed_jobs_next30':model(1),**{'next_'+f:model(0) for f in FEATURES if f!='x_remaining_jobs'}}
        rm.append({'key':list(key),'targets':{'y_mean_gpu_w':model(1200 if c==5 else 1100),
            'y_ttft_p95_ms':model(500),'y_gap_p99_ms':model(20)}})
    return tm,rm


class ScorerTests(unittest.TestCase):
    def test_real_prediction_path_and_visible_action(self):
        tm,rm=models();scorer=ShadowScorer(tm,rm,tm,rm,0,1950*NS)
        jobs=[{'job_id':'a','max_output_tokens':1024}]
        actions=[{'receipt_wall_time_ns':449*NS,'end_wall_ns':449*NS,
                  'action':{'power_cap_w':400,'batch_concurrency':5}},
                 {'receipt_wall_time_ns':451*NS,'end_wall_ns':450*NS,
                  'action':{'power_cap_w':300,'batch_concurrency':6}}]
        record=observe(jobs,[],[],[],[],450*NS,1950*NS,'G1',scorer,actions)
        self.assertEqual(record['state']['x_p_w'],400)
        self.assertEqual(record['state']['x_c'],5)
        self.assertEqual(record['best_point_plan']['name'],'recovery_c6')
        self.assertEqual(len(record['candidates']),2)
        self.assertFalse(record['actuation_performed'])

    def test_unknown_event_models_do_not_become_feasible(self):
        tm,rm=models();score=ShadowScorer(tm,rm,tm,rm,0,1950*NS)
        state={f:0. for f in FEATURES};state.update(group='G1',x_p_w=400,x_c=5,x_remaining_jobs=1)
        candidates=score(state,240*NS)
        self.assertEqual(len(candidates),12)
        self.assertTrue(all(not c['complete_prediction'] for c in candidates))

    def test_missing_action_and_unaligned_cutoff(self):
        tm,rm=models();score=ShadowScorer(tm,rm,tm,rm,0,1950*NS)
        with self.assertRaises(KeyError):score({},450*NS)
        with self.assertRaises(ValueError):score({},450*NS+1)


if __name__=='__main__':unittest.main()
