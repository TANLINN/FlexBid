"""Collect measured outcomes and controller records without inferring certification."""
import json
from pathlib import Path
from core_control_outcomes import evaluate
from core_control_action_report import summarize


def build(output,measure,config):
    output=Path(output)
    result=evaluate(output,measure,config)
    path=output/'control_decisions.jsonl'
    result['controller']=summarize(measure.read_rows(path)) if path.is_file() else None
    result['status']='CORE_CONTROL_COLLECTION_REPORTED'
    result['collection_complete']=(output/'CONTROL_COMPLETE.json').is_file() and (output/'workload_complete.json').is_file()
    result['full_joint_pass']=None
    result['pending_verification']=['parent action/read-back correspondence','service configuration and admission rules','receipt-visible prediction reconstruction']
    return result


def write_report(output,measure,config):
    output=Path(output)
    result=build(output,measure,config)
    measure.write_json(output/'REPORT.json',result)
    lines=['=== CORE_CONTROL_COLLECTION ===','STATUS='+result['status'],
           'COLLECTION_COMPLETE='+str(result['collection_complete']),
           'SERVICE_METRICS_AND_DEADLINE_PASS='+str(result['service_metrics_and_deadline_pass']),
           'BATCH='+json.dumps(result['batch']), 'CONTROLLER='+json.dumps(result['controller']),
           'FULL_JOINT_PASS=unverified','PENDING='+json.dumps(result['pending_verification']),
           'phase TTFT_p95_ms mean_text_gap_p99_ms safe']
    for name,p in result['phases'].items():
        lines.append(f"{name} {p['ttft_p95_ms']} {p['request_mean_stream_gap_p99_ms']} {p['observed_slo_safe']}")
    lines.append('GPU_POWER='+json.dumps(result['gpu_power']))
    text='\n'.join(lines)+'\n'
    (output/'REPORT.txt').write_text(text,encoding='utf-8')
    print(text,end='',flush=True)
    return result

