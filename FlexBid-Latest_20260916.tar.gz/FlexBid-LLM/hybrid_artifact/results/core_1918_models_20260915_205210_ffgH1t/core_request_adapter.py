"""Run the existing online replay alongside dynamically admitted batch jobs."""
import asyncio
import time

from core_batch_control import follow_control
from core_dynamic_batch import execute_batch


async def execute_requests(legacy_execute, online, jobs, protocol, request, emit,
                           admission, control, acknowledgement, observe_dispatch=None):
    start = time.monotonic() + (int(protocol['start_wall_ns']) - time.time_ns()) / 1e9
    deadline = start + float(protocol['duration_s'])
    release = start + max(float(protocol['cohort_release_offset_s']),
                          float(protocol['batch_admission_offset_s']))
    drain = deadline + float(protocol['drain_s'])
    stop = asyncio.Event()

    def online_emit(kind, row):
        emit(kind, {**row, 'receipt_wall_time_ns': time.time_ns()})

    async def observed_request(row, kind):
        if observe_dispatch is not None:
            observe_dispatch(kind, row, time.time_ns())
        return await request(row, kind)

    async def batch_request(row):
        return await observed_request(row, 'batch')

    async def workload():
        tasks = [asyncio.create_task(legacy_execute(
            online, [], protocol, observed_request, online_emit, concurrency=0)),
            asyncio.create_task(execute_batch(
                jobs, admission, release, deadline, drain, batch_request,
                lambda row: emit('batch', row)))]
        try:
            await asyncio.gather(*tasks)
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

    work = asyncio.create_task(workload())
    follower = asyncio.create_task(follow_control(admission, control, acknowledgement, stop))
    try:
        done, _ = await asyncio.wait([work, follower], return_when=asyncio.FIRST_COMPLETED)
        if follower in done:
            await follower
            raise RuntimeError('Batch control follower exited before workload')
        await work
        stop.set()
        await follower
    finally:
        for task in [work, follower]:
            if not task.done():
                task.cancel()
        await asyncio.gather(work, follower, return_exceptions=True)
