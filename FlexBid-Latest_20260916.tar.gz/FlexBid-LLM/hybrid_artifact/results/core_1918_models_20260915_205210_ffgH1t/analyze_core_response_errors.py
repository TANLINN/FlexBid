"""Describe saved held-out errors and training ranges without refitting."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
import math
from pathlib import Path

POWER = 'y_mean_gpu_w'
BATCH = 'y_completed_jobs_next30'
TTFT = 'y_ttft_p95_ms'
GAP = 'y_gap_p99_ms'


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def number(value):
    if value is None or value == '':
        return None
    result = float(value)
    return result if math.isfinite(result) else None


def boolean(value):
    if value in (True, 'True'):
        return True
    if value in (False, 'False'):
        return False
    raise ValueError('Missing or invalid saved boolean: ' + repr(value))


def row_key(row):
    return row['run'], float(row['start_s'])


def action_key(row):
    return row['group'], row['phase'], number(row['x_p_w']), number(row['x_c'])


def join_records(windows, predictions):
    by_key = {row_key(r): r for r in windows}
    if len(by_key) != len(windows):
        raise ValueError('Duplicate dataset run/window keys')
    joined, seen = [], set()
    for prediction in predictions:
        key = row_key(prediction)
        if key in seen:
            raise ValueError('Duplicate prediction run/window key: ' + repr(key))
        seen.add(key)
        original = by_key[key]
        if original['episode_id'] != prediction['episode_id'] or action_key(original) != action_key(prediction):
            raise ValueError('Dataset/prediction identity or action mismatch: ' + repr(key))
        for target in (POWER, BATCH, TTFT, GAP):
            if number(original[target]) != number(prediction[target]):
                raise ValueError('Dataset/prediction label mismatch: ' + repr(key) + ' ' + target)
        joined.append({**original, **prediction})
    return joined


def scored(row, target):
    return boolean(row['score_' + target]) and number(row.get('pred_' + target)) is not None


class TrainingRanges:
    def __init__(self, records, features):
        self.records, self.features, self.cache = records, features, {}

    def for_row(self, row, target):
        key = (row['episode_id'], action_key(row), target)
        if key not in self.cache:
            # Training-label eligibility is independent of whether that row's own fold had a model.
            training = [r for r in self.records if r['episode_id'] != row['episode_id']
                        and action_key(r) == action_key(row) and boolean(r['score_' + target])]
            ranges = {}
            for name in self.features:
                values = [number(r.get(name)) for r in training]
                values = [v for v in values if v is not None]
                if values:
                    ranges[name] = (min(values), max(values))
            self.cache[key] = ranges
        return self.cache[key]

    def outside(self, row, target):
        result = []
        for name, (lower, upper) in self.for_row(row, target).items():
            value = number(row.get(name))
            if value is not None and not lower <= value <= upper:
                result.append({'feature': name, 'value': value, 'training_min': lower, 'training_max': upper})
        return result


def errors(rows, target):
    pairs = [(number(r['pred_' + target]), number(r[target])) for r in rows if scored(r, target)]
    if not pairs:
        return {'windows': 0, 'mae': None, 'bias_pred_minus_actual': None}
    residuals = [p - y for p, y in pairs]
    return {'windows': len(pairs), 'mae': sum(abs(e) for e in residuals) / len(pairs),
            'bias_pred_minus_actual': sum(residuals) / len(pairs)}


def batch_path_summary(rows):
    eligible = [r for r in rows if boolean(r['score_' + BATCH])]
    matched = [r for r in eligible if number(r.get('pred_' + BATCH)) is not None]
    actual = sum(number(r[BATCH]) for r in matched) if matched else None
    predicted = sum(number(r['pred_' + BATCH]) for r in matched) if matched else None
    return {'eligible_windows': len(eligible), 'predicted_windows': len(matched),
            'unpredicted_windows': len(eligible) - len(matched),
            'actual_completions_same_windows': actual, 'predicted_completions_same_windows': predicted,
            'sum_pred_minus_actual': predicted - actual if matched else None,
            'scope': 'Saved-state one-step errors on scored windows; not a rollout or deadline forecast'}


def compact(row):
    values = {name: row.get(name) for name in ('run', 'episode_id', 'phase')}
    for name in ('start_s', 'x_p_w', 'x_c', 'y_gap_samples', 'y_ttft_samples',
                 'y_online_error_or_incomplete', POWER, BATCH, TTFT, GAP,
                 'pred_' + POWER, 'pred_' + BATCH, 'pred_' + TTFT, 'pred_' + GAP):
        values[name] = number(row.get(name))
    return values


def analyze(model_root, output):
    model = read_json(model_root / 'MODEL.json')
    saved = read_json(model_root / 'REPORT.json')
    data_path = Path(saved['dataset'])
    source = read_json(data_path.parent / 'REPORT.json')
    windows = read_csv(data_path)
    predictions = read_csv(model_root / 'held_out_predictions.csv')
    joined = join_records(windows, predictions)
    if len(windows) != source['windows'] or len(joined) != saved['counts']['constant_demand']:
        raise ValueError('Saved report and CSV row counts differ')
    ranges = TrainingRanges(joined, model['features'])
    range_checks, fold_reports = [], []
    for identity in sorted({r['episode_id'] for r in joined}):
        selected = [r for r in joined if r['episode_id'] == identity]
        power_rows = [r for r in selected if scored(r, POWER)]
        outside_by_key = {row_key(r): ranges.outside(r, POWER) for r in power_rows}
        counts = Counter(d['feature'] for details in outside_by_key.values() for d in details)
        for row in selected:
            for target in (POWER, BATCH, TTFT, GAP):
                if scored(row, target):
                    calculated = len(ranges.outside(row, target))
                    recorded = int(row['outside_' + target])
                    if calculated != recorded:
                        range_checks.append({'run': row['run'], 'start_s': number(row['start_s']),
                                             'target': target, 'recorded': recorded, 'calculated': calculated})
        inside = [r for r in power_rows if not outside_by_key[row_key(r)]]
        outside = [r for r in power_rows if outside_by_key[row_key(r)]]
        fold_reports.append({'held_out_identity': identity, 'power_predicted_windows': len(power_rows),
                             'windows_with_any_feature_outside_range': len(outside),
                             'outside_feature_counts': dict(counts.most_common()),
                             'power_inside': errors(inside, POWER), 'power_outside': errors(outside, POWER),
                             'batch_inside_power_feature_range': errors(inside, BATCH),
                             'batch_outside_power_feature_range': errors(outside, BATCH)})
    false_safe = []
    for row in joined:
        if not scored(row, TTFT) or not scored(row, GAP):
            continue
        predicted_safe = number(row['pred_' + TTFT]) <= 5000 and number(row['pred_' + GAP]) <= 100
        actual_safe = number(row[TTFT]) <= 5000 and number(row[GAP]) <= 100 and number(row['y_online_error_or_incomplete']) == 0
        if predicted_safe and not actual_safe:
            names = [*model['features'], 'x_snapshot_age_s', 'x_power_sample_age_s', 'x_action_age_s']
            neighbors = sorted([r for r in joined if r['run'] == row['run']
                                and abs(number(r['start_s']) - number(row['start_s'])) <= 60],
                               key=lambda r: number(r['start_s']))
            false_safe.append({'window': compact(row), 'state': {k: number(row.get(k)) for k in names},
                               'gap_model_outside_features': ranges.outside(row, GAP),
                               'neighbor_scored_windows': [compact(r) for r in neighbors]})
    batch_reports = []
    run_info = {r['run']: r for r in source['runs']}
    for run in sorted({r['run'] for r in joined}):
        selected = [r for r in joined if r['run'] == run and r['phase'] == 'recovery']
        batch_reports.append({'run': run, 'episode_id': run_info[run]['episode_id'],
                              'saved_on_time_jobs': run_info[run]['on_time_jobs'],
                              'saved_service_deadline_pass': run_info[run]['saved_service_deadline_pass'],
                              **batch_path_summary(selected)})
    expected_false_safe = sum(f['service_window_confusion']['false_safe'] for f in saved['folds'])
    report = {'status': 'CORE_RESPONSE_ERROR_ANALYSIS_COMPLETE', 'model_root': str(model_root),
              'range_count_mismatches': range_checks, 'folds': fold_reports,
              'false_safe_count_matches_saved_report': len(false_safe) == expected_false_safe,
              'false_safe_windows': false_safe, 'recorded_recovery_path_errors': batch_reports,
              'notes': [
                  'Existing CSV, predictions and reports only; no refit, GPU query, workload, retry or keepalive stop.',
                  'Ranges come only from other identities with eligible labels for the same action and target.',
                  'One feature outside its training min/max does not imply an incorrect prediction or a causal explanation.',
                  'Recovery sums compare matching scored windows under recorded states; changing-action and exhausted windows are not silently filled.',
                  'No full-cohort deadline or hypothetical action sequence is predicted. No error percentile is converted into a safety margin.'
              ]}
    output.mkdir(parents=True, exist_ok=True)
    (output / 'REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    def line(name, value):
        return name + '=' + json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    lines = ['=== CORE_RESPONSE_ERROR_ANALYSIS ===', 'STATUS=' + report['status'],
             line('RANGE_COUNT_MISMATCHES', len(range_checks)),
             line('FALSE_SAFE_COUNT_MATCHES', report['false_safe_count_matches_saved_report'])]
    lines += [line('FOLD_RANGE', f) for f in fold_reports]
    lines.append(line('FALSE_SAFE_COUNT', len(false_safe)))
    for item in false_safe[:5]:
        lines += [line('FALSE_SAFE_WINDOW', item['window']), line('STATE', item['state']),
                  line('GAP_RANGE_EXCEEDANCES', item['gap_model_outside_features'])]
        lines += [line('NEIGHBOR', r) for r in item['neighbor_scored_windows']]
    for item in batch_reports:
        display = {k: v for k, v in item.items() if k != 'scope'}
        try:
            display['run'] = str(Path(item['run']).relative_to(model_root.parent))
        except ValueError:
            pass
        lines.append(line('RECOVERY_PATH', display))
    lines += report['notes'] + ['REPORT_JSON=' + str(output / 'REPORT.json')]
    (output / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    analyze(args.model_root, args.output)
