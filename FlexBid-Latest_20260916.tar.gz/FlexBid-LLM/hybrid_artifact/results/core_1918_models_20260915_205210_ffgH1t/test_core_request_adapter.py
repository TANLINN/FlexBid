import asyncio
import importlib.util
import os
import tempfile
import time
import unittest
from pathlib import Path

from core_batch_control import publish_limit, write_json
from core_dynamic_batch import BatchAdmission, cohort_state
from core_request_adapter import execute_requests


def legacy():
    path = Path(os.environ.get('CORE_COHORT_SOURCE', Path(__file__).with_name('cohort_phase_measurement.py')))
    spec = importlib.util.spec_from_file_location('saved_cohort', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.execute_requests


class AdapterTests(unittest.IsolatedAsyncioTestCase):
    async def test_online_dependencies_and_controlled_batch(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            now = time.time_ns()
            protocol = dict(start_wall_ns=now, duration_s=2, drain_s=1,
                            cohort_release_offset_s=0, batch_admission_offset_s=0,
                            event_batch_concurrency=5, recovery_start_offset_s=1)
            online = [dict(request_id='parent', arrival_ms=0),
                      dict(request_id='child', parent_request_id='parent', arrival_ms=0, tool_delay_ms=20)]
            jobs = [dict(job_id=str(i), max_output_tokens=1024) for i in range(4)]
            observed, started, rows, dispatches = {}, [], [], []
            released = [asyncio.Event() for _ in jobs]
            async def request(row, kind):
                began = time.time_ns()
                if kind == 'batch':
                    started.append(row['job_id'])
                    await released[int(row['job_id'])].wait()
                else:
                    observed[row['request_id']] = time.monotonic()
                return dict(dispatch_wall_time_ns=began, completion_wall_time_ns=time.time_ns(),
                            status_code=200, error=None, completion_tokens=1024)
            admission = BatchAdmission(0)
            task = asyncio.create_task(execute_requests(legacy(), online, jobs, protocol, request,
                     lambda kind,row: rows.append((kind,row)), admission, root/'control', root/'ack',
                     observe_dispatch=lambda kind,row,stamp: dispatches.append((kind,stamp))))
            async def count(n):
                async def wait():
                    while len(started) < n:
                        await asyncio.sleep(.001)
                await asyncio.wait_for(wait(), 1)
            try:
                await publish_limit(root/'control',root/'ack',1,2)
                await count(2)
                await publish_limit(root/'control',root/'ack',2,1)
                released[0].set()
                await asyncio.sleep(.03)
                self.assertEqual(len(started),2)
                released[1].set()
                await count(3)
                await publish_limit(root/'control',root/'ack',3,2)
                await count(4)
                released[2].set(); released[3].set()
                await asyncio.wait_for(task, 2)
            finally:
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)
            self.assertGreaterEqual(observed['child']-observed['parent'], .019)
            self.assertEqual(len(rows),6)
            self.assertEqual(len(dispatches),6)
            self.assertEqual(sum(kind=='batch' for kind,_ in dispatches),4)
            self.assertTrue(all('receipt_wall_time_ns' in row for _,row in rows))
            state=cohort_state(jobs,[row for kind,row in rows if kind=='batch'],now+2_000_000_000,time.time_ns())
            self.assertTrue(state['all_jobs_complete_on_time'])

    async def test_invalid_control_stops_workload(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            write_json(root/'control',{'sequence':1,'batch_concurrency':-1})
            cancelled=asyncio.Event()
            async def online(*args,**kwargs):
                try: await asyncio.sleep(10)
                finally: cancelled.set()
            async def request(*args): self.fail('Unexpected batch request')
            protocol=dict(start_wall_ns=time.time_ns(),duration_s=10,drain_s=1,
                          cohort_release_offset_s=0,batch_admission_offset_s=0)
            with self.assertRaises(ValueError):
                await execute_requests(online,[],[],protocol,request,lambda *args:None,
                                       BatchAdmission(0),root/'control',root/'ack')
            self.assertTrue(cancelled.is_set())


if __name__ == '__main__': unittest.main()
