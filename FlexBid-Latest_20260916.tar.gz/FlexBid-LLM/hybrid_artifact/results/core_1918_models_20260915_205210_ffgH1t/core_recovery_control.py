"""Set the existing recovery priority flag in one atomic control write."""
def apply_recovery_control(path, action, replicas, online_concurrency, enabled):
    from flexbid_hybrid.io import atomic_json
    value = {'action': action.as_dict(), 'online_replica_ids': list(action.resolved_online_replica_ids()), 'batch_replica_ids': list(range(replicas)), 'batch_paused': action.batch_concurrency == 0, 'online_concurrency': online_concurrency, 'batch_concurrency': max(1, action.batch_concurrency), 'defer_batch_for_online_queue': enabled and action.batch_concurrency == 6}
    atomic_json(path, value)
    return value
