"""Decision-time features from received dispatch, result and telemetry records."""
import math


def quantile(values, q):
    values = sorted(float(v) for v in values if v is not None and math.isfinite(float(v)))
    if not values:
        return None
    position = (len(values)-1)*q
    left = int(position)
    return values[left] + (values[min(left+1,len(values)-1)]-values[left])*(position-left)


def build_state(jobs, dispatches, results, snapshots, power, cutoff_ns, deadline_ns):
    expected = {r['job_id']: r for r in jobs}
    if len(expected) != len(jobs):
        raise ValueError('Duplicate planned job')
    def visible(rows):
        return [r for r in rows if r['receipt_wall_time_ns'] <= cutoff_ns]
    dispatched = visible(dispatches)
    received = visible(results)
    batch = {r['job_id']: r for r in received if r['class']=='batch'}
    if len(batch) != sum(r['class']=='batch' for r in received) or not set(batch)<=set(expected):
        raise ValueError('Unknown or duplicate batch result')
    attempts = {r['job_id']:r for r in dispatched if r['class']=='batch'}
    if len(attempts) != sum(r['class']=='batch' for r in dispatched) or not set(attempts)<=set(expected):
        raise ValueError('Unknown or duplicate batch dispatch')
    def complete(r):
        return (r.get('error') is None and r.get('status_code')==200
                and r.get('completion_tokens')==expected[r['job_id']]['max_output_tokens']
                and r.get('completion_wall_time_ns') is not None
                and r['completion_wall_time_ns']<=min(cutoff_ns,deadline_ns))
    done = [r for r in batch.values() if complete(r)]
    active = [r for key,r in attempts.items() if key not in batch]
    recent_start=cutoff_ns-60_000_000_000
    arrivals=[r for r in dispatched if r['class']=='online' and recent_start<r['dispatch_wall_time_ns']<=cutoff_ns]
    recent=[r for r in received if r['class']=='online' and r.get('completion_wall_time_ns') is not None
            and recent_start<r['completion_wall_time_ns']<=cutoff_ns]
    def latest(rows):
        candidates=[r for r in visible(rows) if r['wall_time_ns']<=cutoff_ns]
        return max(candidates,key=lambda r:r['wall_time_ns']) if candidates else {}
    snapshot=latest(snapshots); sample=latest(power)
    prompts=[r.get('prompt_tokens') for r in arrivals]
    return {
        'x_online_active':sum(snapshot['inflight_online']) if 'inflight_online' in snapshot else None,
        'x_batch_active_gateway':sum(snapshot['inflight_batch']) if 'inflight_batch' in snapshot else None,
        'x_online_waiting':snapshot.get('online_waiting'),'x_batch_waiting':snapshot.get('batch_waiting'),
        'x_remaining_jobs':len(jobs)-len(done),'x_completed_jobs':len(done),
        'x_batch_inflight_client':len(active),
        'x_oldest_batch_dispatch_age_s':max(((cutoff_ns-r['dispatch_wall_time_ns'])/1e9 for r in active),default=None),
        'x_recent60_completed_jobs':sum(r['completion_wall_time_ns']>recent_start for r in done),
        'x_recent60_online_dispatches':len(arrivals),
        'x_recent60_prompt_mean':sum(prompts)/len(prompts) if prompts and all(v is not None for v in prompts) else None,
        'x_recent60_ttft_p95_ms':quantile([r.get('ttft_ms') for r in recent],.95),
        'x_recent60_gap_p99_ms':quantile([r.get('mean_tpot_ms') for r in recent],.99),
        'x_last_gpu_w':sample.get('gpu_w'),
        'x_snapshot_age_s':(cutoff_ns-snapshot['wall_time_ns'])/1e9 if snapshot else None,
        'x_power_sample_age_s':(cutoff_ns-sample['wall_time_ns'])/1e9 if sample else None,
        'unstarted_jobs':len(set(expected)-set(attempts)-set(batch)),
        'unsuccessful_or_late_results':len(batch)-len(done),
        'all_jobs_complete_on_time':len(done)==len(jobs),
    }
