"""Prepare serial replica startup with per-replica compilation cache directories."""

import ast
import textwrap


def prepared_start_source(source):
    tree = ast.parse(textwrap.dedent(source), feature_version=(3, 10))
    functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'start']
    if len(functions) != 1:
        raise ValueError('Expected one saved start function')
    function = functions[0]
    loops = [node for node in function.body if isinstance(node, ast.For)
             and isinstance(node.target, ast.Tuple)
             and any(isinstance(item, ast.Name) and item.id == 'replica_index' for item in node.target.elts)]
    if len(loops) != 1:
        raise ValueError('Expected the replica_index startup loop')
    loop = loops[0]
    launches = [node for node in loop.body if isinstance(node, ast.Expr)
                and isinstance(node.value, ast.Call)
                and ast.unparse(node.value.func) == 'self.processes.append'
                and any(isinstance(item, ast.Call) and ast.unparse(item.func) == 'subprocess.Popen'
                        for item in node.value.args)]
    if len(launches) != 1:
        raise ValueError('Expected one owned Popen per replica iteration')
    launch = launches[0]
    location = loop.body.index(launch)
    setup = ast.parse('''
replica_cache = self.logs.parent / 'compile_cache' / ('replica_' + str(replica_index))
for cache_key, cache_name in (
    ('VLLM_CACHE_ROOT', 'vllm'),
    ('TORCHINDUCTOR_CACHE_DIR', 'inductor'),
    ('TRITON_CACHE_DIR', 'triton'),
):
    cache_path = replica_cache / cache_name
    cache_path.mkdir(parents=True, exist_ok=True)
    env[cache_key] = str(cache_path)
''').body
    wait = ast.parse('''
wait_http(f'http://127.0.0.1:{port}/health', self.processes, float(runtime['startup_timeout_s']))
''').body
    loop.body[location:location + 1] = setup + [launch] + wait
    return ast.unparse(ast.fix_missing_locations(tree)) + '\n'
