"""Apply a selected P/C action through acknowledged control callbacks."""
import time
import math

from core_batch_control import change_concurrency


class FirstActionExecutor:
    def __init__(self, current_p, current_c, publish_client, publish_gateway,
                 apply_power, emit, clock=time.time_ns):
        self.p, self.c = current_p, current_c
        self.client, self.gateway, self.power = publish_client, publish_gateway, apply_power
        self.emit, self.clock = emit, clock
        self.failed = False

    async def apply(self, solution, slot_end_ns, stopped=lambda:False):
        """Callbacks return only after application; errors require caller shutdown.

        Gateway callback receives (C, queue_priority), including unchanged C.
        Power callback returns the read-back cap for each of eight GPUs.
        Existing requests are never cancelled when admission decreases.
        """
        if self.failed:
            raise RuntimeError('Previous application failed; actual control state is uncertain')
        if stopped():
            return {'status':'ACTION_STOPPED'}
        if solution['status'] != 'POINT_PLAN_SELECTED':
            return {'status':'NO_ACTION','reason':solution['status']}
        action = solution['first_action']
        p, c, phase = action['p_w'], action['c'], action['phase']
        if (phase not in {'event','recovery'} or c not in (5,6)
                or p not in (300,350,400) or (phase=='recovery' and p!=400)):
            raise ValueError('Action outside the existing P/C family')
        if self.clock() >= slot_end_ns:
            return {'status':'ACTION_EXPIRED'}
        priority = phase == 'recovery' and c == 6

        async def step(name, callback, *args):
            if stopped():
                raise RuntimeError('Session stopped during application')
            if self.clock() >= slot_end_ns:
                raise TimeoutError('Action slot expired during application')
            self.emit({'stage':name,'status':'BEGIN','wall_ns':self.clock(),'action':dict(action)})
            result = await callback(*args)
            self.emit({'stage':name,'status':'ACK','wall_ns':self.clock(),'action':dict(action)})
            return result

        async def client(limit):
            return await step('client',self.client,limit)

        async def gateway(limit):
            return await step('gateway',self.gateway,limit,priority)

        async def power():
            caps = await step('power',self.power,p)
            if (not isinstance(caps,dict) or set(caps)!=set(map(str,range(8)))
                    or any(not isinstance(value,(int,float)) or not math.isfinite(value)
                           or abs(value-p)>0.6 for value in caps.values())):
                raise RuntimeError('GPU cap read-back differs from requested power')
            self.emit({'stage':'power_readback','status':'VERIFIED','caps':caps,'wall_ns':self.clock()})

        try:
            # Restrict admission before reducing power; grant new capacity last.
            if c < self.c:
                await change_concurrency(self.c,c,client,gateway)
            if p != self.p:
                await power()
            if c > self.c:
                await change_concurrency(self.c,c,client,gateway)
            elif c == self.c:
                await gateway(c)
            if self.clock() >= slot_end_ns:
                raise TimeoutError('Application completed after action slot')
            self.p, self.c = p,c
            record={'status':'ACTION_ACKNOWLEDGED','action':dict(action),
                    'queue_priority':priority,'wall_ns':self.clock()}
            self.emit(record)
            return record
        except BaseException as exc:
            self.failed = True
            self.emit({'status':'ACTION_FAILED','action':dict(action),
                       'error_type':type(exc).__name__,'error':str(exc),'wall_ns':self.clock()})
            raise

