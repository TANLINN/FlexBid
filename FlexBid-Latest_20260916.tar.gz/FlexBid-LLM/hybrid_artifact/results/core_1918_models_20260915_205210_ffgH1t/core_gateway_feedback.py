"""Expose gateway admission settings and wait for their application."""
import ast
import asyncio
import copy


FIELDS = {
    'online_concurrency': 'state.online_gate.limit',
    'batch_concurrency': 'state.batch_gate.limit',
    'defer_batch_for_online_queue': 'state.defer_batch_for_online_queue',
}


def patched_source(source):
    tree = ast.parse(source)
    function, = [n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'flexbid_state']
    returned, = [n.value for n in function.body if isinstance(n, ast.Return)]
    if not isinstance(returned, ast.Dict):
        raise ValueError('Expected gateway state dictionary')
    keys = [k.value for k in returned.keys if isinstance(k, ast.Constant)]
    if any(k in keys for k in FIELDS):
        raise ValueError('Gateway feedback fields already present')
    changed = copy.deepcopy(returned)
    for key, expression in FIELDS.items():
        changed.keys.append(ast.Constant(key))
        changed.values.append(ast.parse(expression, mode='eval').body)
    lines = source.encode('utf-8').splitlines(keepends=True)
    begin = sum(map(len, lines[:returned.lineno-1])) + returned.col_offset
    end = sum(map(len, lines[:returned.end_lineno-1])) + returned.end_col_offset
    output = (source.encode('utf-8')[:begin] + ast.unparse(changed).encode('utf-8') + source.encode('utf-8')[end:]).decode('utf-8')
    ast.parse(output)
    return output


async def wait_gateway(read_state, expected, timeout=2.0):
    """Caller publishes through the existing control writer before waiting."""
    keys = ['online_replica_ids', 'batch_replica_ids', 'batch_paused', *FIELDS]
    wanted = {key: expected[key] for key in keys}
    async def wait():
        while True:
            state = await read_state()
            if all(key in state and state[key] == value for key,value in wanted.items()):
                return state
            await asyncio.sleep(.01)
    return await asyncio.wait_for(wait(), timeout)

