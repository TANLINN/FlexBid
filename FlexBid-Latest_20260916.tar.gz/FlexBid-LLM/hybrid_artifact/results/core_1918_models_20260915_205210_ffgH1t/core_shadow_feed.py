"""Collector-side receipts for the shadow decision interface."""
from copy import deepcopy
import time

from core_shadow_decision import observe


async def execute_shadow_requests(feed, legacy_execute, online, jobs, protocol,
                                  request, emit, admission, control, acknowledgement):
    """Keep workload output and shadow receipts on the same request callbacks."""
    from core_request_adapter import execute_requests

    def received(kind, row):
        feed.result(kind, row)
        emit(kind, row)

    await execute_requests(legacy_execute, online, jobs, protocol, request, received,
                           admission, control, acknowledgement,
                           observe_dispatch=feed.dispatch)


class ShadowFeed:
    """Callbacks run on the collector's event-loop thread."""

    def __init__(self, jobs, deadline_ns, group, scorer, clock=time.time_ns):
        self.jobs = deepcopy(jobs)
        self.deadline_ns = deadline_ns
        self.group = group
        self.scorer = scorer
        self.clock = clock
        self.records = {kind: [] for kind in ('dispatches', 'results', 'snapshots', 'power', 'actions')}

    def receive(self, kind, row):
        received = self.clock()
        value = deepcopy(row)
        # A producer timestamp is not the collector's receipt time.
        if 'receipt_wall_time_ns' in value:
            value['producer_receipt_wall_time_ns'] = value['receipt_wall_time_ns']
        value['receipt_wall_time_ns'] = received
        self.records[kind].append(value)

    def dispatch(self, kind, row, dispatch_ns):
        value = {key: row[key] for key in ('job_id', 'request_id', 'prompt_tokens') if key in row}
        value.update({'class': kind, 'dispatch_wall_time_ns': dispatch_ns})
        self.receive('dispatches', value)

    def result(self, kind, row):
        self.receive('results', {**row, 'class': kind})

    def decision(self, cutoff_ns):
        if cutoff_ns > self.clock():
            raise ValueError('Decision cutoff has not arrived')
        return observe(self.jobs, self.records['dispatches'], self.records['results'],
                       self.records['snapshots'], self.records['power'], cutoff_ns,
                       self.deadline_ns, self.group, self.scorer, self.records['actions'])
