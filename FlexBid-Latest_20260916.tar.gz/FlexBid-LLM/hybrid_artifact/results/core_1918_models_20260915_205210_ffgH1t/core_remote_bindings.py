"""Controller callbacks whose hardware operations run in the parent."""
import time
from core_batch_control import publish_limit
from core_parent_control import ParentClient


class RemoteBindings:
    def __init__(self,output):
        self.output=output;self.parent=ParentClient(output);self.sequence=0
        self.slot_end_ns=0

    def begin_slot(self,slot_end_ns):self.slot_end_ns=slot_end_ns

    async def client(self,c):
        self.sequence+=1
        remaining=(self.slot_end_ns-time.time_ns())/1e9
        if remaining<=0:raise TimeoutError('Client update slot expired')
        await publish_limit(self.output/'batch_control.json',self.output/'batch_ack.json',
                            self.sequence,c,timeout=min(2.,remaining))

    async def power(self,p):
        values=await self.parent.request('power',{'p':p},self.slot_end_ns)
        return {str(i):v for i,v in values.items()}

    async def gateway(self,c,priority):
        return await self.parent.request('gateway',{'c':c,'priority':priority},self.slot_end_ns)

