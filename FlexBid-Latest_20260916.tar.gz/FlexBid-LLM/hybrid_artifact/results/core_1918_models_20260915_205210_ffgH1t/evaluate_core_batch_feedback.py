"""Evaluate sequential residual correction on saved held-identity-out predictions."""
from __future__ import annotations

import argparse
from collections import defaultdict
import csv
import json
from pathlib import Path

from analyze_core_response_errors import (
    BATCH, action_key, boolean, join_records, number, read_csv, read_json, row_key,
)
from core_batch_feedback import BatchFeedback, WindowFeedback


def replay(windows, predictions):
    joined = {row_key(r): r for r in join_records(windows, predictions)}
    by_run = defaultdict(list)
    for row in windows:
        by_run[row['run']].append(row)
    records = []
    for run, rows in sorted(by_run.items()):
        feedback = BatchFeedback()
        previous_end, previous_action, segment_number = None, None, 0
        for row in sorted(rows, key=lambda r: number(r['start_s'])):
            start = number(row['start_s'])
            action = action_key(row)
            constant = boolean(row['segment_action_constant'])
            if start != previous_end or action != previous_action or not constant:
                segment_number += 1
            segment = (run, segment_number, action)
            previous_end = start + 30.0
            previous_action = action if constant else None
            saved = joined.get(row_key(row))
            if saved is None:
                continue
            base = number(saved.get('pred_' + BATCH))
            point = feedback.predict(segment, start, base, number(row['x_remaining_jobs']))
            record = {**saved, 'feedback_segment': segment_number,
                      'pred_batch_feedback': point['prediction'],
                      'feedback_offset': point['offset'],
                      'feedback_windows': point['feedback_windows'],
                      'latest_feedback_available_s': point['latest_feedback_available_s'],
                      'feedback_status': point['status']}
            records.append(record)
            if constant and boolean(saved['score_' + BATCH]) and base is not None:
                # Receipt timestamps are absent in the source; this is an explicit offline assumption.
                feedback.observe(segment, WindowFeedback(start, start + 30.0, start + 30.0,
                                                         base, number(saved[BATCH])))
    return records


def error_summary(rows, prediction_key):
    matched = [r for r in rows if boolean(r['score_' + BATCH])
               and number(r.get(prediction_key)) is not None]
    if not matched:
        return {'windows': 0, 'mae_jobs': None, 'bias_pred_minus_actual': None,
                'maximum_overprediction_jobs': None, 'sum_pred_minus_actual': None}
    errors = [number(r[prediction_key]) - number(r[BATCH]) for r in matched]
    return {'windows': len(matched), 'mae_jobs': sum(abs(v) for v in errors) / len(errors),
            'bias_pred_minus_actual': sum(errors) / len(errors),
            'maximum_overprediction_jobs': max(0.0, max(errors)),
            'sum_pred_minus_actual': sum(errors)}


def comparison(rows):
    original = error_summary(rows, 'pred_' + BATCH)
    corrected = error_summary(rows, 'pred_batch_feedback')
    eligible = sum(boolean(r['score_' + BATCH]) for r in rows)
    return {'eligible_windows': eligible, 'unpredicted_windows': eligible - original['windows'],
            'original': original, 'feedback': corrected,
            'mae_change_feedback_minus_original': (corrected['mae_jobs'] - original['mae_jobs'])
            if original['windows'] else None}


def evaluate(model_root, output):
    saved = read_json(model_root / 'REPORT.json')
    dataset = Path(saved['dataset'])
    source = read_json(dataset.parent / 'REPORT.json')
    windows = read_csv(dataset)
    predictions = read_csv(model_root / 'held_out_predictions.csv')
    records = replay(windows, predictions)
    if len(windows) != source['windows'] or len(records) != saved['counts']['constant_demand']:
        raise ValueError('Dataset/prediction counts differ from the saved reports')
    by_identity, by_identity_phase, by_recovery = defaultdict(list), defaultdict(list), defaultdict(list)
    for row in records:
        by_identity[row['episode_id']].append(row)
        by_identity_phase[(row['episode_id'], row['phase'])].append(row)
        if row['phase'] == 'recovery':
            by_recovery[row['run']].append(row)
    identity_reports = [{'episode_id': identity, **comparison(rows)}
                        for identity, rows in sorted(by_identity.items())]
    phase_reports = [{'episode_id': identity, 'phase': phase, **comparison(rows)}
                     for (identity, phase), rows in sorted(by_identity_phase.items())]
    run_info = {r['run']: r for r in source['runs']}
    recovery_reports = [{'run': run, 'episode_id': run_info[run]['episode_id'],
                         'saved_on_time_jobs': run_info[run]['on_time_jobs'],
                         'saved_service_deadline_pass': run_info[run]['saved_service_deadline_pass'],
                         **comparison(rows)} for run, rows in sorted(by_recovery.items())]
    means = {}
    for label in ('original', 'feedback'):
        scored = [r[label] for r in identity_reports if r[label]['windows']]
        means[label] = {'identities': len(scored),
                        'identity_mean_mae_jobs': sum(r['mae_jobs'] for r in scored) / len(scored) if scored else None,
                        'identity_mean_bias': sum(r['bias_pred_minus_actual'] for r in scored) / len(scored) if scored else None}
    false_safe = sum(f['service_window_confusion']['false_safe'] for f in saved['folds'])
    report = {
        'status': 'CORE_BATCH_FEEDBACK_DIAGNOSTIC_COMPLETE',
        'input_kind': 'COMPLETION_CLOCK_FEEDBACK_DIAGNOSTIC',
        'model_root': str(model_root), 'dataset': str(dataset),
        'rows': len(records), 'identity_equal_metrics': means,
        'identities': identity_reports, 'identity_phases': phase_reports, 'recovery_runs': recovery_reports,
        'original_service_false_safe_windows_unchanged': false_safe,
        'rows_using_feedback': sum(r['feedback_status'] == 'FEEDBACK_APPLIED' for r in records),
        'notes': [
            'Original held-identity-out predictions are reused; no base-model refit or active-controller change.',
            'Correction is the mean of prior actual-minus-original-prediction residuals in the same run and uninterrupted phase/action segment.',
            'Predictions precede observing their own labels; only windows ending by the decision cutoff enter feedback.',
            'Source ledger receipt times are absent. Replay assumes full batch-window feedback is available at window end; live visibility is not verified.',
            'New runs, action/phase changes, transition windows and missing time intervals reset segment history.',
            'First predictions use the original model; unsupported actions remain unpredicted. Power and service predictions are unchanged.',
            'Reported sums and errors use the same scored windows, including first windows. Transition and exhausted windows remain outside original prediction scoring.',
            'Every step uses its recorded state. This is not a recursive rollout, action-switch evaluation or full-cohort deadline forecast.',
            'The correction structure was selected after inspecting these identities. Results are development evidence, not untouched validation.',
            'CPU saved-file analysis only; no GPU query, workload, retry, source overwrite or keepalive stop.',
        ],
    }
    output.mkdir(parents=True, exist_ok=True)
    (output / 'REPORT.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    csv_path = output / 'feedback_predictions.csv'
    if records:
        fields = list(dict.fromkeys(k for row in records for k in row))
        with csv_path.open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(records)
    def line(key, value):
        return key + '=' + json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
    lines = ['=== CORE_BATCH_FEEDBACK_DIAGNOSTIC ===', 'STATUS=' + report['status'],
             'INPUT_KIND=' + report['input_kind'], line('IDENTITY_EQUAL_METRICS', means),
             line('ROWS_USING_FEEDBACK', report['rows_using_feedback']),
             line('SERVICE_FALSE_SAFE_UNCHANGED', false_safe)]
    lines += [line('IDENTITY_PHASE', r) for r in phase_reports]
    for r in recovery_reports:
        display = {k: v for k, v in r.items() if k not in ('original', 'feedback')}
        try:
            display['run'] = str(Path(r['run']).relative_to(model_root.parent))
        except ValueError:
            pass
        display.update({'original_error_sum': r['original']['sum_pred_minus_actual'],
                        'feedback_error_sum': r['feedback']['sum_pred_minus_actual']})
        lines.append(line('RECOVERY_RUN', display))
    lines += report['notes'] + ['PREDICTIONS_CSV=' + str(csv_path), 'REPORT_JSON=' + str(output / 'REPORT.json')]
    (output / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--model-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    evaluate(args.model_root, args.output)
