import asyncio
import threading
import unittest

from core_shadow_feed import ShadowFeed
from core_shadow_loop import run_shadow

NS = 1_000_000_000


class LoopTests(unittest.IsolatedAsyncioTestCase):
    async def test_scoring_does_not_block_receipts_or_change_frozen_state(self):
        now = [150*NS]
        entered = threading.Event()
        release = threading.Event()
        stop = asyncio.Event()
        seen = []
        output = []
        def score(state, cutoff):
            entered.set()
            if not release.wait(2):
                raise RuntimeError('Test scorer timed out')
            seen.append(state['x_remaining_jobs'])
            return []
        feed = ShadowFeed([{'job_id':'a','max_output_tokens':2}],1950*NS,'G1',score,lambda:now[0])
        def emit(row):
            output.append(row)
            stop.set()
        task = asyncio.create_task(run_shadow(feed,0,emit,stop,lambda:now[0]))
        try:
            async def wait_entered():
                while not entered.is_set():
                    await asyncio.sleep(.001)
            await asyncio.wait_for(wait_entered(),1)
            now[0] += NS
            feed.result('batch',{'job_id':'a','completion_wall_time_ns':150*NS,
                                'status_code':200,'completion_tokens':2})
            release.set()
            await asyncio.wait_for(task,2)
        finally:
            release.set()
            await task
        self.assertEqual(seen,[1])
        self.assertEqual(len(feed.records['results']),1)
        self.assertEqual(output[0]['cutoff_wall_ns'],150*NS)
        self.assertFalse(output[0]['actuation_performed'])

    async def test_missed_slots_are_not_replayed_as_timely_decisions(self):
        now = 211*NS
        stop = asyncio.Event()
        rows = []
        feed = ShadowFeed([{'job_id':'a','max_output_tokens':2}],1950*NS,'G1',lambda s,t:[],lambda:now)
        def emit(row):
            rows.append(row)
            if row['status'] != 'SHADOW_SLOT_SKIPPED':
                stop.set()
        await run_shadow(feed,0,emit,stop,lambda:now)
        self.assertEqual([r['cutoff_wall_ns']//NS for r in rows],[150,180,210])
        self.assertEqual([r['status'] for r in rows[:2]],['SHADOW_SLOT_SKIPPED']*2)

    async def test_scorer_failure_propagates(self):
        def score(*args):
            raise ValueError('missing action receipt')
        feed = ShadowFeed([{'job_id':'a','max_output_tokens':2}],1950*NS,'G1',score,lambda:150*NS)
        with self.assertRaisesRegex(ValueError,'missing action receipt'):
            await run_shadow(feed,0,lambda r:self.fail('Unexpected decision'),asyncio.Event(),lambda:150*NS)


if __name__ == '__main__':
    unittest.main()
