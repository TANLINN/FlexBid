"""Diagnostic ranking of explicit schedules; no actuator or runtime policy."""
import math


def finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value)


def summarize(name, plan, initial_action, deadline_s=1950):
    records=plan['records']
    required=('y_mean_gpu_w','y_ttft_p95_ms','y_gap_p99_ms')
    complete=(plan['response_end_s']==deadline_s and bool(records)
              and finite(plan['predicted_full_horizon_energy_wh'])
              and finite(plan['predicted_remaining_at_deadline'])
              and all(all(finite(r['response']['values'].get(t)) for t in required) for r in records))
    outside=sorted({f for r in records for detail in r['response'].get('details',{}).values()
                    for f in detail.get('outside_training_range',[])})
    missing=sorted({f for r in records for detail in r['response'].get('details',{}).values()
                    for f in detail.get('missing_features',[])})
    previous=initial_action;switches=0
    for r in records:
        action=(r['action']['p_w'],r['action']['c'])
        switches+=action!=previous;previous=action
    event=[r for r in records if r['start_s']<450]
    event_wh=sum(r['response']['values']['y_mean_gpu_w']*30/3600 for r in event) if complete else None
    ttft=max(r['response']['values']['y_ttft_p95_ms'] for r in records) if complete else None
    gap=max(r['response']['values']['y_gap_p99_ms'] for r in records) if complete else None
    feasible=complete and plan['predicted_remaining_at_deadline']==0 and ttft<=5000 and gap<=100
    return {'name':name,'trajectory_status':plan['status'],'complete_prediction':complete,
            'point_constraints_satisfied':feasible,'outside_training_range':outside,'missing_features':missing,
            'event_energy_wh':event_wh,'full_energy_wh':plan['predicted_full_horizon_energy_wh'],
            'completion_slot_end_s':plan['predicted_completion_slot_end_s'],
            'remaining_at_deadline':plan['predicted_remaining_at_deadline'],
            'max_predicted_ttft_ms':ttft,'max_predicted_gap_ms':gap,
            'minimum_gap_headroom_ms':100-gap if gap is not None else None,'switches':switches}


def rank(summaries):
    # This orders point predictions, without turning them into certified service outcomes.
    candidates=[s for s in summaries if s['point_constraints_satisfied']]
    return sorted(candidates,key=lambda s:(s['event_energy_wh'],s['full_energy_wh'],s['switches'],s['name']))
