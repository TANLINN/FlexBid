import asyncio
import threading
import unittest

from core_candidate_solver import CandidateSolver
from core_control_loop import run_control
from core_first_action import FirstActionExecutor
from core_shadow_feed import ShadowFeed

NS=10**9

class ControlLoopTests(unittest.IsolatedAsyncioTestCase):
    async def test_next_decision_uses_new_received_completion(self):
        now=[450*NS];stop=asyncio.Event();seen=[];applied=[]
        feed=ShadowFeed([{'job_id':x,'max_output_tokens':2} for x in ('a','b')],1950*NS,'G1',None,lambda:now[0])
        feed.receive('actions',{'end_wall_ns':449*NS,'action':{'power_cap_w':400,'batch_concurrency':5}})
        class Scorer:
            def iter_candidates(self,state,cutoff):
                remaining=state['x_remaining_jobs'];seen.append((remaining,state['x_c']))
                for c in (5,6):
                    yield {'name':f'recovery_c{c}','point_constraints_satisfied':True,
                           'event_energy_wh':0,'full_energy_wh':0 if c==(6 if remaining==2 else 5) else 1,'switches':0}
        async def client(c):pass
        async def gateway(c,priority):pass
        async def power(p):return {str(i):p for i in range(8)}
        executor=FirstActionExecutor(400,5,client,gateway,power,lambda r:None,lambda:now[0])
        def emit(r):
            if r['status']=='CONTROL_APPLICATION':
                applied.append(r['result']['action']['c'])
                if len(applied)==1:
                    now[0]+=NS
                    feed.receive('actions',{'end_wall_ns':now[0],'action':{'power_cap_w':400,'batch_concurrency':6}})
                    feed.result('batch',{'job_id':'a','completion_wall_time_ns':now[0],
                                        'status_code':200,'completion_tokens':2})
                    now[0]=480*NS
                else:stop.set()
        await run_control(feed,0,CandidateSolver(Scorer(),0,1950*NS),executor,emit,stop,
                          clock=lambda:now[0],first_second=450)
        self.assertEqual(seen,[(2,5),(1,6)]);self.assertEqual(applied,[6,5])

    async def test_stop_during_solve_never_executes(self):
        stop=asyncio.Event();entered=threading.Event();release=threading.Event()
        feed=ShadowFeed([],1950*NS,'G1',None)
        class Solver:
            def solve(self,*args):
                entered.set()
                if not release.wait(2):raise TimeoutError()
                return {'status':'POINT_PLAN_SELECTED'}
        class Executor:
            async def apply(self,*args):raise AssertionError('Unexpected action')
        task=asyncio.create_task(run_control(feed,0,Solver(),Executor(),lambda r:None,stop,clock=lambda:450*NS,first_second=450))
        try:
            while not entered.is_set():await asyncio.sleep(.001)
            stop.set();release.set();await task
        finally:release.set();await task

    async def test_infeasible_stops_without_actuation(self):
        feed=ShadowFeed([],1950*NS,'G1',None)
        class Solver:
            def solve(self,*args):return {'status':'NO_POINT_FEASIBLE_PLAN'}
        class Executor:
            async def apply(self,*args):raise AssertionError('Unexpected action')
        with self.assertRaisesRegex(RuntimeError,'NO_POINT_FEASIBLE_PLAN'):
            await run_control(feed,0,Solver(),Executor(),lambda r:None,asyncio.Event(),clock=lambda:450*NS,first_second=450)

if __name__=='__main__':unittest.main()

