"""Prepare an identity-held-out model package with the existing fit settings."""
import json,sys
from pathlib import Path
from core_response_model import load_windows,fit_models
from core_recovery_rollout import fit
from evaluate_core_event_rollout import fit_event_transitions
from evaluate_core_complete_energy import fit_post_cohort
from evaluate_core_response_model import annotate_service_labels
from core_shadow_scorer import ShadowScorer
from core_shadow_models import load_scorer
from core_plan_comparison import rank

def main(dataset,source,out):
    identity='azure_conversation:azure-001918'
    meta=json.loads((dataset/'REPORT.json').read_text());allrows=load_windows(dataset/'action_windows.csv')
    reference=[r for r in allrows if r['run']==str(source)]
    if not reference or any(r['episode_id']!=identity for r in reference):raise ValueError('Source identity missing or inconsistent')
    groups={r['group'] for r in reference}
    if len(groups)!=1:raise ValueError('Source spans compatibility groups')
    group=next(iter(groups));allowed={r['run'] for r in meta['runs'] if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    rows=[r for r in allrows if r['group']==group and r['run'] in allowed and r['episode_id']!=identity]
    if not rows:raise ValueError('No training rows')
    annotate_service_labels(rows)
    idle,idle_responses,idle_counts=fit_post_cohort(rows)
    transitions={**fit_event_transitions(rows),**fit(rows)};responses=fit_models(rows)
    document={'held_identity':identity,'group':group,'training_identities':sorted({r['episode_id'] for r in rows}),'training_runs':sorted({r['run'] for r in rows}),'transitions':[{'key':list(k),'targets':v} for k,v in transitions.items()],'responses':responses,'idle_transitions':[{'key':list(k),'targets':v} for k,v in idle.items()],'idle_responses':idle_responses,'idle_training':idle_counts}
    model=out/'SHADOW_MODELS.json';model.write_text(json.dumps(document,indent=2))
    protocol=json.loads((source/'protocol.json').read_text());start=int(protocol['start_wall_ns']);end=int(protocol['deadline_wall_ns'])
    # Earliest saved event window, chosen without looking at its outcomes.
    probe=min((r for r in reference if r['phase']=='event' and r['start_s']>=150),key=lambda r:r['start_s'])
    state={k:v for k,v in probe.items() if k.startswith('x_') or k in ('group','phase')}
    cutoff=start+int(probe['start_s'])*10**9
    direct=ShadowScorer(transitions,responses,idle,idle_responses,start,end)(state,cutoff)
    reloaded=load_scorer(model,start,end)(state,cutoff)
    if json.dumps(direct,sort_keys=True)!=json.dumps(reloaded,sort_keys=True):raise ValueError('Reloaded scoring differs')
    ordered=rank(reloaded)
    report={'status':'CORE_1918_MODELS_PREPARED_CPU_ONLY','held_identity':identity,'training_identities':document['training_identities'],'training_runs':len(document['training_runs']),'training_rows':len(rows),'held_identity_excluded':all(r['episode_id']!=identity for r in rows),'reload_scoring_match':True,'probe_origin_s':probe['start_s'],'probe_choice':ordered[0]['name'] if ordered else None,'probe_candidates':[{k:r.get(k) for k in ('name','trajectory_status','point_constraints_satisfied','full_energy_wh','remaining_at_deadline','max_predicted_gap_ms')} for r in reloaded],'model_file':str(model),'gpu_workload':False,'installed':False,'scope':'Same model functions, features and ridge setting; a different identity-held-out fit, not a claim of pristine holdout. Probe uses an earlier saved state without live receipt visibility. Unsupported actions remain unavailable; no active model replacement or launcher execution.'}
    (out/'REPORT.json').write_text(json.dumps(report,indent=2))
    print('=== CORE_1918_MODELS_PREPARATION ===');print(json.dumps(report));print('REPORT_JSON='+str(out/'REPORT.json'))
if __name__=='__main__':main(*map(Path,sys.argv[1:]))

