"""Fit and evaluate saved-data response models without loading GPU libraries."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
import time

import numpy as np

from core_response_model import (FEATURES, TARGETS, RIDGE, base_eligible, fit_models,
                                 load_windows, summarize, service_confusion, validate_identities)

NS = 1_000_000_000


def json_read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def json_write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def cross_transition(requests, transition_ns):
    """Future outcomes affect attribution labels only, never input features."""
    for row in requests:
        dispatch = row.get('dispatch_wall_time_ns')
        finish = row.get('completion_wall_time_ns')
        if dispatch is None:
            continue
        if finish is None:
            return True
        if any(int(dispatch) < boundary < int(finish) for boundary in transition_ns):
            return True
    return False


def annotate_service_labels(windows):
    by_run = defaultdict(list)
    for row in windows:
        by_run[row['run']].append(row)
    info = []
    for run, values in sorted(by_run.items()):
        root = Path(run)
        protocol = json_read(root / 'protocol.json')
        start = int(protocol['start_wall_ns'])
        transitions = [int(protocol['deadline_wall_ns'])]
        with (root / 'power_actions.jsonl').open(encoding='utf-8') as stream:
            transitions.extend(int(json.loads(line)['begin_wall_ns']) for line in stream if line.strip())
        buckets = defaultdict(list)
        with (root / 'online.jsonl').open(encoding='utf-8') as stream:
            for line in stream:
                if not line.strip():
                    continue
                row = json.loads(line)
                dispatch = row.get('dispatch_wall_time_ns')
                if dispatch is not None:
                    elapsed = (int(dispatch) - start) // NS
                    if 150 <= elapsed < 1950:
                        left_s = 150 + ((elapsed - 150) // 30) * 30
                        buckets[left_s].append({key: row.get(key) for key in ('dispatch_wall_time_ns', 'completion_wall_time_ns')})
        affected = 0
        for row in values:
            selected = buckets[int(row['start_s'])]
            if len(selected) != int(row['y_online_dispatched']):
                raise ValueError(f'Saved CSV/request membership mismatch: {run}, t={row["start_s"]}')
            row['service_labels_cross_transition'] = cross_transition(selected, transitions)
            affected += row['service_labels_cross_transition']
        info.append({'run': run, 'service_windows_crossing_later_control_change': affected})
    return info


def write_predictions(path, records):
    if records:
        with path.open('w', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(records[0]))
            writer.writeheader()
            writer.writerows(records)


def evaluate(input_root, output):
    started = time.perf_counter()
    dataset = json_read(input_root / 'REPORT.json')
    windows = load_windows(input_root / 'action_windows.csv')
    if len(windows) != dataset['windows']:
        raise ValueError('CSV row count differs from its saved extraction report')
    run_info = {r['run']: r for r in dataset['runs']}
    missing = sorted({r['run'] for r in windows} - run_info.keys())
    if missing:
        raise ValueError('Dataset has no source-run records for: ' + repr(missing))
    attribution = annotate_service_labels(windows)
    run_errors = [r['run'] for r in dataset['runs'] if not (
        r.get('caps_match_saved_receipts') is True and r.get('all_gpu_receipts_present') is True)]
    # Invalid action receipts cannot supply supervised action labels.
    usable = [r for r in windows if r['run'] not in run_errors]
    predictions, folds = validate_identities(usable)
    action_metrics = []
    by_action = defaultdict(list)
    for row in predictions:
        by_action[(row['group'], row['phase'], row['x_p_w'], row['x_c'])].append(row)
    for key, values in sorted(by_action.items()):
        action_metrics.append({'group': key[0], 'phase': key[1], 'p_w': key[2], 'c': key[3],
                               'targets': {target: summarize(values, target) for target in TARGETS},
                               'service_window_confusion': service_confusion(values)})
    fold_metrics = []
    for fold in folds:
        values = [r for r in predictions if r['episode_id'] == fold['held_out_identity']]
        fold_metrics.append({**fold, 'targets': {target: summarize(values, target) for target in TARGETS},
                             'service_window_confusion': service_confusion(values)})
    source_failure_results = []
    for run, info in sorted(run_info.items()):
        if info.get('saved_service_deadline_pass') is False:
            values = [r for r in predictions if r['run'] == run]
            source_failure_results.append({'run': run, 'on_time_jobs': info['on_time_jobs'],
                                           'saved_service_deadline_pass': False,
                                           'service_window_confusion': service_confusion(values),
                                           'batch_one_step': summarize(values, 'y_completed_jobs_next30'),
                                           'note': 'No whole-run pass/deadline prediction is made from window quantiles or one-step counts.'})
    models = fit_models(usable)
    model_document = {'status': 'STEADY_ACTION_POINT_MODELS_FOR_OFFLINE_DIAGNOSTICS',
                      'dataset': str(input_root / 'action_windows.csv'), 'features': list(FEATURES),
                      'targets': list(TARGETS), 'ridge': RIDGE, 'models': models,
                      'active_controller_changed': False, 'closed_loop_validated': False,
                      'forecast_scope': 'One 30-second window under the observed constant action and nonempty cohort',
                      'usage': 'core_response_model.predict(document["models"], state_row); group, phase and candidate x_p_w/x_c identify the action. Missing actions return NO_TRAINING_ACTION.',
                      'limitations': 'Point predictions are not safety bounds. Held-out evaluation uses separate fold models; these all-data fits are not independently validated models.'}
    counts = Counter()
    for row in windows:
        counts['all'] += 1
        counts['constant_action'] += row['segment_action_constant']
        counts['constant_demand'] += base_eligible(row)
        counts['constant_exhausted'] += row['segment_action_constant'] and not row['segment_has_remaining_demand']
        counts['cross_transition_service_labels'] += row['service_labels_cross_transition']
        counts['constant_demand_service_attribution_excluded'] += base_eligible(row) and row['service_labels_cross_transition']
    gaps = [r['y_gap_samples'] for r in usable if base_eligible(r) and not r['service_labels_cross_transition']]
    action_support = []
    for model in models:
        example = model['targets']['y_completed_jobs_next30']
        if example is None:
            continue
        key = model['key']
        test_values = by_action[tuple(key)]
        action_support.append({'key': key, 'training_identities_all_data': example['training_identities'],
                               'training_runs_all_data': len(example['training_runs']),
                               'held_out_identities_with_batch_predictions': sorted({r['episode_id'] for r in test_values if r.get('pred_y_completed_jobs_next30') is not None})})
    report = {'status': 'CORE_RESPONSE_MODEL_DIAGNOSTIC_COMPLETE',
              'dataset': str(input_root / 'action_windows.csv'), 'counts': dict(counts),
              'workload_identities': sorted({r['episode_id'] for r in windows}),
              'model_form': 'Separate action/phase/group weighted ridge regressions; fixed lambda=1, training-only feature means/scales and missing-value indicators; no hyperparameter search',
              'sample_weighting': 'Equal workload identity, then equal physical run, then equal window mass within each target/action fit',
              'validation': 'Leave one whole workload identity out, including all its repeated runs; remaining identities train that fold',
              'numpy_version': np.__version__, 'folds': fold_metrics, 'action_metrics': action_metrics,
              'action_support': action_support, 'saved_failed_runs': source_failure_results,
              'attribution': attribution, 'runs_excluded_due_to_cap_receipts': run_errors,
              'service_label_gap_sample_count': {'min': min(gaps) if gaps else None,
                                                 'median': float(np.median(gaps)) if gaps else None,
                                                 'max': max(gaps) if gaps else None},
              'notes': [
                  'CPU only: no GPU query, workload, retry, keepalive stop, original source/model/config edit or deployment.',
                  'These are retrospective tests on three reused identities, not untouched prospective validation.',
                  'All original rows remain in the input CSV. Changing-action and exhausted windows are listed separately from steady nonempty-cohort fits.',
                  'Service labels whose requests span a later control change are not attributed to one action; the entire affected service window is unscored, not selectively shortened.',
                  'Power/latency optimism is actual minus prediction; batch optimism is prediction minus actual. Positive-error p95 is descriptive, not a calibrated bound.',
                  'A no-training-action result is unpredicted, not a correct safe outcome. Extrapolated predictions remain in error statistics.',
                  'Sparse window p99 and its confusion table are not whole-phase SLO certification. Window quantiles cannot be averaged into a phase quantile.',
                  'Each one-step prediction is conditioned on its recorded state; no hypothetical action switch, recursive rollout or full-cohort deadline is validated.',
                  'Per-action identity and held-out prediction coverage are listed in action_support; a fitted all-data model alone does not establish held-out support.',
                  'Final all-data point models are saved separately for diagnostics. They do not replace the active model and provide no statistical safety guarantee.'
              ], 'elapsed_s': time.perf_counter() - started}
    json_write(output / 'MODEL.json', model_document)
    json_write(output / 'REPORT.json', report)
    write_predictions(output / 'held_out_predictions.csv', predictions)
    lines = ['=== CORE_RESPONSE_MODEL_DIAGNOSTIC ===', 'STATUS=' + report['status'],
             'COUNTS=' + json.dumps(report['counts']),
             'IDENTITIES=' + json.dumps(report['workload_identities']),
             'VALIDATION=' + report['validation']]
    compact = ('predicted_windows', 'unpredicted_windows', 'mae', 'bias_pred_minus_actual',
               'optimistic_error_p95', 'maximum_optimistic_error', 'outside_training_range_windows')
    for fold in fold_metrics:
        lines.append('FOLD=' + json.dumps({'held_out': fold['held_out_identity'], 'train': fold['training_identities'], 'test_windows': fold['test_windows']}))
        for target, metric in fold['targets'].items():
            lines.append('ERROR=' + json.dumps({'target': target, **{k: metric.get(k) for k in compact}}))
        lines.append('WINDOW_SERVICE=' + json.dumps(fold['service_window_confusion']))
    for item in action_metrics:
        lines.append('ACTION=' + json.dumps({**{k: item[k] for k in ('group', 'phase', 'p_w', 'c')},
                    'errors': {t: {k: v.get(k) for k in ('predicted_windows', 'unpredicted_windows', 'identity_macro_mae', 'optimistic_error_p95')}
                               for t, v in item['targets'].items()}}))
    for item in action_support:
        lines.append('SUPPORT=' + json.dumps(item))
    for item in source_failure_results:
        lines.append('SAVED_FAILURE=' + json.dumps(item))
    lines += ['EXCLUDED_CAP_RECEIPT_RUNS=' + json.dumps(run_errors),
              'GAP_LABEL_SAMPLES=' + json.dumps(report['service_label_gap_sample_count']),
              *report['notes'], 'ELAPSED_S=' + str(round(report['elapsed_s'], 3)),
              'MODEL_JSON=' + str(output / 'MODEL.json'),
              'PREDICTIONS_CSV=' + str(output / 'held_out_predictions.csv'),
              'REPORT_JSON=' + str(output / 'REPORT.json')]
    (output / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    evaluate(args.input_root, args.output)


if __name__ == '__main__':
    main()
