"""Run saved online requests with dynamic batch admission and parent control."""
import json
from core_shadow_feed import ShadowFeed
from core_shadow_models import load_scorer
from core_shadow_session import run_session
from core_candidate_solver import CandidateSolver
from core_control_loop import run_control
from core_dynamic_batch import BatchAdmission
from core_batch_control import write_json
from core_request_adapter import execute_requests
from core_remote_bindings import RemoteBindings
from core_first_action import FirstActionExecutor


def run_workload(measure,output):
    document=json.loads((output/'SHADOW_MODELS.json').read_text())
    original=measure.execute_requests
    async def execute(online,jobs,protocol,request,emit,*args,**kwargs):
        start,end=int(protocol['start_wall_ns']),int(protocol['deadline_wall_ns'])
        scorer=load_scorer(output/'SHADOW_MODELS.json',start,end)
        with (output/'control_receipts.jsonl').open('w') as receipts, (output/'control_decisions.jsonl').open('w') as decisions:
            class Feed(ShadowFeed):
                def receive(self,kind,row):
                    super().receive(kind,row)
                    receipts.write(json.dumps({'kind':kind,'record':self.records[kind][-1]})+'\n');receipts.flush()
            feed=Feed(jobs,end,document['group'],scorer)
            def record(row):decisions.write(json.dumps(row)+'\n');decisions.flush()
            def result(kind,row):feed.result(kind,row);emit(kind,row)
            admission=BatchAdmission(0)
            write_json(output/'batch_control.json',{'sequence':0,'batch_concurrency':0})
            bindings=RemoteBindings(output)
            executor=FirstActionExecutor(400,0,bindings.client,bindings.gateway,bindings.power,record)
            class BoundExecutor:
                async def apply(self,solution,slot_end_ns,**kw):
                    bindings.begin_slot(slot_end_ns)
                    return await executor.apply(solution,slot_end_ns,**kw)
            async def controller(stop):
                await run_control(feed,start,CandidateSolver(scorer,start,end),BoundExecutor(),record,stop)
            async def workload():
                return await execute_requests(original,online,jobs,protocol,request,result,admission,
                                              output/'batch_control.json',output/'batch_ack.json',
                                              observe_dispatch=feed.dispatch)
            await run_session(feed,start,output,workload,record,controller=controller)
            measure.write_json(output/'CONTROL_COMPLETE.json',{'status':'CONTROL_WORKLOAD_COMPLETE',
                               'received_counts':{k:len(v) for k,v in feed.records.items()}})
    measure.execute_requests=execute
    try:measure.workload_main(output)
    finally:measure.execute_requests=original

