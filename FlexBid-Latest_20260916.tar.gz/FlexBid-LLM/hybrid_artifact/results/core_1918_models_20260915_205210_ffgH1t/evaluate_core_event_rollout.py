"""Held-identity event state trajectories following saved power switches."""
from collections import defaultdict
import json
from pathlib import Path
import sys

from core_response_dataset import NS, read_json, rows, signature, window, power_rows
from core_response_model import (FEATURES, TARGETS, action_key, base_eligible,
                                 fit_one, fit_models, load_windows, predict)
from core_recovery_rollout import NEXT_FEATURES, COUNT, advance
from evaluate_core_response_model import annotate_service_labels


def fit_event_transitions(training):
    index = {(r['run'], r['start_s']): r for r in training}
    groups = defaultdict(list)
    for row in training:
        nxt = index.get((row['run'], row['start_s'] + 30))
        if (row['phase'] != 'event' or not base_eligible(row) or nxt is None
                or action_key(row) != action_key(nxt)):
            continue
        groups[action_key(row)].append({**row, **{
            'next_' + feature: nxt.get(feature) for feature in NEXT_FEATURES}})
    return {key: {target: fit_one(values, target)
                  for target in (COUNT,) + tuple('next_' + f for f in NEXT_FEATURES)}
            for key, values in groups.items()}


def trajectory(transitions, responses, origin, steps=3):
    current = dict(origin)
    result = []
    for step in range(steps):
        response = predict(responses, current)
        nxt = advance(transitions, current)
        if nxt is None:
            return result, 'NO_TRAINING_TRANSITION'
        result.append({'step': step + 1, 'state': current, 'response': response,
                       'next_state': nxt,
                       'completed_in_step': current['x_remaining_jobs'] - nxt['x_remaining_jobs']})
        current = nxt
    return result, 'POINT_TRAJECTORY_ONLY'


def evaluate(dataset, source, output):
    metadata = read_json(dataset / 'REPORT.json')
    saved = read_json(source / 'REPORT.json')
    identity = saved['episode_id']
    actual_signature = signature(source)[:2]
    compatible = set()
    for item in metadata['runs']:
        if item['group'] not in compatible and signature(Path(item['run']))[:2] == actual_signature:
            compatible.add(item['group'])
    if len(compatible) != 1:
        raise ValueError('Cannot uniquely match saved environment/admission group')
    group = next(iter(compatible))
    allowed = {r['run'] for r in metadata['runs']
               if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    training = [r for r in load_windows(dataset / 'action_windows.csv')
                if r['run'] in allowed and r['group'] == group and r['episode_id'] != identity]
    annotate_service_labels(training)
    transitions, responses = fit_event_transitions(training), fit_models(training)
    start = int(read_json(source / 'protocol.json')['start_wall_ns'])
    online, batch = rows(source / 'online.jsonl'), rows(source / 'batch.jsonl')
    jobs = rows(source / 'batch_jobs.jsonl')
    states, actions = rows(source / 'gateway_state.jsonl'), rows(source / 'power_actions.jsonl')
    power = power_rows(source / 'components.csv')
    records = []
    for origin_s, cap in ((240, 300), (330, 400)):
        initial = window(start + origin_s * NS, start + (origin_s + 30) * NS,
                         online, batch, len(jobs), states, actions, power)
        state = {key: initial.get(key) for key in FEATURES}
        state.update(group=group, phase='event', x_p_w=cap, x_c=5)
        path, status = trajectory(transitions, responses, state)
        cumulative = 0
        for entry in path:
            left_s = origin_s + 30 * (entry['step'] - 1)
            actual = window(start + left_s * NS, start + (left_s + 30) * NS,
                            online, batch, len(jobs), states, actions, power)
            cumulative += actual[COUNT]
            values = entry['response']['values']
            records.append({
                'origin_s': origin_s, 'window_start_s': left_s, 'p_w': cap, 'status': status,
                'observed': {key: actual[key] for key in TARGETS},
                'response_prediction': entry['response'],
                'response_error': {key: values[key] - actual[key] for key in TARGETS
                                   if key in values and actual[key] is not None},
                'transition_completed_in_step': entry['completed_in_step'],
                'predicted_cumulative_completed': state['x_remaining_jobs'] - entry['next_state']['x_remaining_jobs'],
                'observed_cumulative_completed': cumulative,
                'ttft_samples': actual['y_ttft_samples'], 'gap_samples': actual['y_gap_samples'],
                'power_covered': actual['y_power_covered'],
                'predicted_state': entry['state']})
        if not path:
            records.append({'origin_s': origin_s, 'p_w': cap, 'status': status})
    notes = [
        'All 001710 repeats and the measured switch run are excluded from training; original features and ridge=1 are retained.',
        'The existing recovery transition regression form is fitted to constant-action event transitions; this is an event-model extension.',
        'Only origin state is supplied to each trajectory; later measured states and outcomes supply labels only.',
        'Response and transition completion regressions retain their different training eligibility; both outputs are reported.',
        'The first window includes actuation delay. Third windows end at 330 or 420 seconds; later power changes are outside each trajectory.',
        'Service outcomes include requests dispatched in the window even if they finish later; these are not phase SLO guarantees.',
        'Two paths on one reused identity are development evidence, not independent safety trials or controller performance.',
        'No GPU, retry, active model replacement or keepalive change.']
    report = {'status': 'CORE_EVENT_ROLLOUT_EVALUATED', 'source': str(source),
              'training_identities': sorted({r['episode_id'] for r in training}),
              'records': records, 'notes': notes}
    output.mkdir(parents=True, exist_ok=True)
    (output / 'REPORT.json').write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
    lines = ['=== CORE_EVENT_ROLLOUT ===', 'STATUS=' + report['status'],
             'TRAINING_IDENTITIES=' + json.dumps(report['training_identities'])]
    for record in records:
        compact = {k: v for k, v in record.items() if k not in ('predicted_state', 'response_prediction')}
        compact['predicted_response'] = record.get('response_prediction', {}).get('values', {})
        lines.append('WINDOW=' + json.dumps(compact))
    lines += notes + ['REPORT_JSON=' + str(output / 'REPORT.json')]
    (output / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))


if __name__ == '__main__':
    evaluate(*map(Path, sys.argv[1:]))
