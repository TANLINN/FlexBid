"""Prefer replicas with fewer online requests while preserving batch placement."""
import ast
from pathlib import Path


def apply_online_spread(path):
    path = Path(path)
    tree = ast.parse(path.read_text(encoding='utf-8'))
    state = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'State')
    choose = next(n for n in state.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'choose')
    assignments = [(parent, i, n) for parent in ast.walk(choose) if hasattr(parent, 'body') and isinstance(parent.body, list)
                   for i, n in enumerate(parent.body) if isinstance(n, ast.Assign)
                   and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name) and n.targets[0].id == 'index']
    expected = ast.parse('index = min(allowed, key=lambda item: (self.inflight[item], self.inflight_batch[item], item))').body[0]
    if len(assignments) != 1 or ast.dump(assignments[0][2]) != ast.dump(expected):
        raise ValueError('Saved State.choose does not contain the expected original placement rule')
    parent, index, original = assignments[0]
    replacement = ast.parse("""if request_class == 'online':
    index = min(allowed, key=lambda item: (self.inflight_online[item], self.inflight[item], self.inflight_batch[item], item))
else:
    index = min(allowed, key=lambda item: (self.inflight[item], self.inflight_batch[item], item))
""").body[0]
    replacement.orelse[0] = original
    parent.body[index] = replacement
    ast.fix_missing_locations(tree)
    code = ast.unparse(tree) + '\n'
    ast.parse(code, feature_version=(3, 10))
    path.write_text(code, encoding='utf-8')


def routing_summary(records, online_replicas, batch_replicas):
    result = {'online_records': 0, 'batch_records': 0, 'online_rule_matches': 0, 'batch_rule_matches': 0,
              'online_mismatches_first8': [], 'batch_mismatches_first8': [],
              'online_choices_different_from_old_rule_at_same_snapshot': 0,
              'maximum_online_per_replica_after_selection': 0}
    for row in records:
        kind = row['class']
        if kind not in ('online', 'batch'):
            continue
        chosen = int(row['replica'])
        online = list(map(int, row['inflight_after_selection']['online']))
        batch = list(map(int, row['inflight_after_selection']['batch']))
        result['maximum_online_per_replica_after_selection'] = max(result['maximum_online_per_replica_after_selection'], max(online))
        (online if kind == 'online' else batch)[chosen] -= 1
        allowed = online_replicas if kind == 'online' else batch_replicas
        if min(online + batch) < 0 or chosen not in allowed:
            raise ValueError('Invalid saved replica counts: ' + row['request_id'])
        original = lambda i: (online[i] + batch[i], batch[i], i)
        expected = min(allowed, key=(lambda i: (online[i], *original(i))) if kind == 'online' else original)
        result[kind + '_records'] += 1
        result[kind + '_rule_matches'] += int(chosen == expected)
        if chosen != expected and len(result[kind + '_mismatches_first8']) < 8:
            result[kind + '_mismatches_first8'].append({'request_id': row['request_id'], 'actual': chosen, 'expected': expected})
        if kind == 'online':
            result['online_choices_different_from_old_rule_at_same_snapshot'] += int(chosen != min(allowed, key=original))
    return result
