"""Isolate online service from batch admission-to-first-text intervals."""
import ast
import json
from pathlib import Path


class FirstTextDetector:
    def __init__(self):
        self.pending = b''
        self.seen = False

    def feed(self, chunk):
        if self.seen:
            return False
        self.pending += chunk
        while b'\n' in self.pending:
            line, self.pending = self.pending.split(b'\n', 1)
            line = line.rstrip(b'\r')
            if not line.startswith(b'data: ') or line[6:] == b'[DONE]':
                continue
            try:
                value = json.loads(line[6:])
                choices = value.get('choices') or []
                text = choices[0].get('text') if choices else None
            except (ValueError, TypeError, AttributeError, IndexError):
                continue
            if text:
                self.seen = True
                self.pending = b''
                return True
        return False


def isolated_gateway_source(source):
    tree = ast.parse(source)
    state = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'State')
    methods = {n.name: n for n in state.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
    init = methods['__init__']
    init.body += ast.parse('''
self.placement_condition = asyncio.Condition(self.lock)
self.placement_waiting = {'online': 0, 'batch': 0}
self.batch_first_tokens = {}
''').body
    replacement = ast.parse('''
async def choose(self, request_class: str, ticket) -> int:
    async with self.placement_condition:
        self.placement_waiting[request_class] += 1
        try:
            while True:
                allowed = self.online_replica_ids if request_class == 'online' else self.batch_replica_ids
                ready = [i for i in allowed if self.inflight_online[i] == 0 and
                         (request_class == 'batch' or i not in self.batch_first_tokens.values())]
                if ready:
                    index = min(ready, key=lambda i: (self.inflight[i], self.inflight_batch[i], i))
                    self.inflight[index] += 1
                    if request_class == 'online':
                        self.inflight_online[index] += 1
                    else:
                        self.inflight_batch[index] += 1
                        self.batch_first_tokens[ticket] = index
                    return index
                await self.placement_condition.wait()
        finally:
            self.placement_waiting[request_class] -= 1

def pending_first_counts(self):
    return [sum(i == index for i in self.batch_first_tokens.values()) for index in range(len(self.inflight))]

async def first_text(self, ticket):
    async with self.placement_condition:
        self.batch_first_tokens.pop(ticket, None)
        self.placement_condition.notify_all()
''').body
    state.body[state.body.index(methods['choose']):state.body.index(methods['choose'])+1] = replacement
    finish = methods['finish']
    finish.args.args.append(ast.arg(arg='ticket'))
    finish.args.defaults.append(ast.Constant(None))
    locked = next(n for n in finish.body if isinstance(n,ast.AsyncWith))
    locked.body += ast.parse('''
self.batch_first_tokens.pop(ticket, None)
self.placement_condition.notify_all()
''').body
    proxy = next(n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name == 'proxy')
    choice = next(i for i,n in enumerate(proxy.body) if isinstance(n,ast.Assign) and
                  any(isinstance(t,ast.Name) and t.id == 'index' for t in n.targets))
    proxy.body[choice:choice+1] = ast.parse('''
ticket = object()
try:
    index = await state.choose(request_class, ticket)
except BaseException:
    await gate.release()
    raise
''').body
    counts = next(n.value for n in proxy.body if isinstance(n,ast.Assign) and
                  any(isinstance(t,ast.Name) and t.id == 'stream_selected_counts' for t in n.targets))
    counts.keys.append(ast.Constant('batch_pending_first'))
    counts.values.append(ast.parse('state.pending_first_counts()',mode='eval').body)
    for node in ast.walk(proxy):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr == 'finish' and isinstance(node.func.value,ast.Name) and node.func.value.id == 'state':
            node.keywords.append(ast.keyword(arg='ticket',value=ast.Name(id='ticket',ctx=ast.Load())))
    # Waiting for placement makes cancellation during request preparation relevant.
    first_body = next(i for i,n in enumerate(proxy.body) if isinstance(n,ast.Assign) and
                      any(isinstance(t,ast.Name) and t.id == 'body' for t in n.targets))
    send_index = next(i for i,n in enumerate(proxy.body) if isinstance(n,ast.Try) and any(
        isinstance(s,ast.Assign) and any(isinstance(t,ast.Name) and t.id == 'response' for t in s.targets) for s in n.body))
    send = proxy.body[send_index]
    send.body = proxy.body[first_body:send_index] + send.body
    proxy.body[first_body:send_index] = []
    stream = next(n for n in proxy.body if isinstance(n,ast.AsyncFunctionDef) and n.name == 'stream')
    stream.body.insert(0,ast.parse('first_text_detector = FirstTextDetector()').body[0])
    loop = next(n for n in ast.walk(stream) if isinstance(n,ast.AsyncFor))
    receive = next(i for i,n in enumerate(loop.body) if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call)
                   and isinstance(n.value.func,ast.Attribute) and n.value.func.attr == 'receive')
    loop.body[receive+1:receive+1] = ast.parse('''
if request_class == 'batch' and first_text_detector.feed(chunk):
    await state.first_text(ticket)
''').body
    cleanup = next(n for n in stream.body if isinstance(n,ast.Try) and n.finalbody)
    def always(statements):
        if len(statements) <= 1:
            return statements
        return [ast.Try(body=[statements[0]],handlers=[],orelse=[],finalbody=always(statements[1:]))]
    cleanup.finalbody = always(cleanup.finalbody)
    send.handlers[0].body = always(send.handlers[0].body)
    nonstream = next(n for n in proxy.body if isinstance(n,ast.If) and isinstance(n.test,ast.Compare)
                     and isinstance(n.test.left,ast.Constant) and n.test.left.value == 'text/event-stream')
    original = nonstream.body
    nonstream.body = [ast.Try(body=[original[0],original[-1]],handlers=[],orelse=[],finalbody=always(original[1:-1]))]
    endpoint = next(n for n in tree.body if isinstance(n,ast.AsyncFunctionDef) and n.name == 'flexbid_state')
    result = next(n.value for n in endpoint.body if isinstance(n,ast.Return))
    for i,key in enumerate(result.keys):
        if isinstance(key,ast.Constant) and key.value in ('online_waiting','batch_waiting'):
            kind = key.value.split('_')[0]
            result.values[i] = ast.parse("state."+kind+"_gate.waiting + state.placement_waiting["+repr(kind)+"]",mode='eval').body
    result.keys += [ast.Constant('batch_pending_first'),ast.Constant('placement_waiting')]
    result.values += [ast.parse('state.pending_first_counts()',mode='eval').body,ast.parse('dict(state.placement_waiting)',mode='eval').body]
    tree.body.insert(next(i for i,n in enumerate(tree.body) if isinstance(n,ast.Import)),
                     ast.parse('from first_text_admission_tools import FirstTextDetector').body[0])
    ast.fix_missing_locations(tree)
    code = ast.unparse(tree)+'\n'
    ast.parse(code,feature_version=(3,10))
    return code


def apply_first_text_isolation(path):
    path = Path(path)
    path.write_text(isolated_gateway_source(path.read_text(encoding='utf-8')),encoding='utf-8')


def routing_summary(records, online_replicas, batch_replicas):
    result = {'online_records':0,'batch_records':0,'online_rule_matches':0,'batch_rule_matches':0,
              'online_mismatches_first8':[],'batch_mismatches_first8':[],
              'maximum_online_per_replica_after_selection':0,
              'online_admissions_while_batch_pending_first':0,'batch_admissions_while_online_present':0}
    for row in records:
        kind, chosen = row['class'], int(row['replica'])
        online = list(map(int,row['inflight_after_selection']['online']))
        batch = list(map(int,row['inflight_after_selection']['batch']))
        pending = list(map(int,row['inflight_after_selection']['batch_pending_first']))
        result['maximum_online_per_replica_after_selection'] = max(result['maximum_online_per_replica_after_selection'],max(online))
        if kind == 'online':
            result['online_admissions_while_batch_pending_first'] += int(pending[chosen] > 0)
            online[chosen] -= 1
        else:
            result['batch_admissions_while_online_present'] += int(online[chosen] > 0)
            batch[chosen] -= 1
            pending[chosen] -= 1
        if min(online+batch+pending) < 0:
            raise ValueError('Invalid recorded admission counts: '+row['request_id'])
        allowed = online_replicas if kind == 'online' else batch_replicas
        ready = [i for i in allowed if online[i] == 0 and (kind == 'batch' or pending[i] == 0)]
        expected = min(ready,key=lambda i:(online[i]+batch[i],batch[i],i)) if ready else None
        result[kind+'_records'] += 1
        result[kind+'_rule_matches'] += int(chosen == expected)
        if chosen != expected and len(result[kind+'_mismatches_first8']) < 8:
            result[kind+'_mismatches_first8'].append({'request_id':row['request_id'],'actual':chosen,'expected':expected})
    return result


def observed_first_text_overlap(records):
    online = [r for r in records if r['class'] == 'online' and r['events']]
    batch = [r for r in records if r['class'] == 'batch' and r['events']]
    pairs = []
    for b in batch:
        left, right = int(b['admitted_mono_ns']), int(b['events'][0]['upstream_read_ns'])
        for o in online:
            if o['replica'] != b['replica']:
                continue
            a, z = int(o['admitted_mono_ns']), int(o['events'][-1]['upstream_read_ns'])
            if max(a,left) < min(z,right):
                pairs.append({'online_id':o['request_id'],'batch_id':b['request_id'],
                              'overlap_ms':(min(z,right)-max(a,left))/1e6})
    return {'online_intervals':len(online),'batch_first_text_intervals':len(batch),
            'overlap_pairs':len(pairs),'overlap_examples_first8':pairs[:8],
            'scope':'Online admission to last observed text versus batch admission to first observed text on the same replica; not engine execution intervals.'}
