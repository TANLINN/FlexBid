"""Compare online-only service with the saved same-trace P400 mixed workload."""
from collections import Counter
import filecmp
import json
from pathlib import Path
import re

import cohort_phase_measurement as m
from conversation_quartile_cell import routing_summary


def matched_phase(before, after, phase, ttft_slo, gap_slo):
    left, right = m.PHASES[phase]
    a = {r['request_id']: r for r in m.select_phase(before, left, right)}
    b = {r['request_id']: r for r in m.select_phase(after, left, right)}
    if a.keys() != b.keys():
        raise ValueError('Saved phase request IDs differ: ' + phase)
    counts = {}
    for field, threshold in (('ttft_ms', ttft_slo), ('mean_tpot_ms', gap_slo)):
        value = Counter()
        for key in a:
            x, y = a[key], b[key]
            if any(r.get('error') is not None or r.get('status_code') != 200 or r.get(field) is None for r in (x, y)):
                category = 'without_two_valid_values'
            else:
                old, new = x[field] > threshold, y[field] > threshold
                category = 'both_above' if old and new else 'only_mixed_above' if old else 'only_online_only_above' if new else 'neither_above'
            value[category] += 1
        counts[field] = {k: value[k] for k in ('both_above', 'only_mixed_above', 'only_online_only_above', 'neither_above', 'without_two_valid_values')}
    return {'phase': phase, 'matched_requests': len(a), 'counts': counts}


def analyze_cell(output, config, source, event_cap):
    import yaml
    from stream_trace_tools import analyze_streams
    from analyze_c6_ttft_decomposition import request_timing, phase_summary
    protocol, settings = m.read_json(output / 'protocol.json'), m.read_json(output / 'workload.json')
    previous = m.read_json(source / 'REPORT.json')
    planned = m.read_rows(output / 'online_workload.jsonl')
    actual, old = m.read_rows(output / 'online.jsonl'), m.read_rows(source / 'online.jsonl')
    gates, states = m.read_rows(output / 'stream_gateway.jsonl'), m.read_rows(output / 'gateway_state.jsonl')
    actions = m.read_rows(output / 'power_actions.jsonl')
    indices = [{r['request_id']: r for r in rows} for rows in (planned, actual, old)]
    ids = all(len(index) == len(rows) for index, rows in zip(indices, (planned, actual, old))) and indices[0].keys() == indices[1].keys() == indices[2].keys()
    metadata = ('arrival_ms', 'prompt_tokens', 'max_output_tokens', 'parent_request_id', 'tool_delay_ms')
    matches = ids and all(all(indices[0][key].get(k) == index[key].get(k) for k in metadata) for index in indices[1:] for key in indices[0])
    complete = sum(r.get('error') is None and r.get('status_code') == 200 and r.get('completion_tokens') == r['max_output_tokens'] for r in actual)
    slo = config['slos']['default']
    ttft_slo, gap_slo = float(slo['ttft_ms']), float(slo['tpot_ms'])
    def phases_for(rows):
        phases = {}
        for p, (left, right) in m.PHASES.items():
            values = m.select_phase(rows, left, right)
            phases[p] = m.latency_summary(values, ttft_slo, gap_slo)
            phases[p]['requests_with_ttft_over_slo'] = sum(r.get('ttft_ms') is not None and r['ttft_ms'] > ttft_slo for r in values)
        return phases
    phases, recorded = phases_for(actual), phases_for(old)
    online_gates = [r for r in gates if r['class'] == 'online']
    observation = analyze_streams(actual, online_gates, gap_slo)
    control = m.read_json(output / 'control.json')
    routing = routing_summary(gates, control['online_replica_ids'], control['batch_replica_ids'])
    caps = m.cap_observations(output, config['hardware']['gpu_indices'], 400)
    source_config = yaml.safe_load((source / 'config.yaml').read_text(encoding='utf-8'))
    budgets, lengths = {}, {}
    for path in sorted((output / 'service_logs').glob('vllm_replica_*.log')):
        text = path.read_text(encoding='utf-8', errors='replace')
        budgets[path.name] = sorted({int(v) for v in re.findall(r'Chunked prefill is enabled with max_num_batched_tokens=(\d+)', text)})
        lengths[path.name] = sorted({int(v.replace(',', '')) for v in re.findall(r'Using max model len ([\d,]+)', text)})
    programs = ('priority_gateway.py', 'stream_trace_tools.py', 'first_text_admission_tools.py',
                'replica_batch_limit_tools.py', 'online_queue_priority_tools.py', 'cohort_phase_measurement.py')
    complete_marker = m.read_json(output / 'workload_complete.json')
    max_online = max((sum(r['inflight_after_selection']['online']) for r in gates), default=None)
    checks = {
        'workload_process_succeeded': complete_marker['status'] == 'complete',
        'same_saved_online_input': filecmp.cmp(output / 'online_workload.jsonl', source / 'online_workload.jsonl', shallow=False),
        'same_episode': settings['episode_id'] == previous['episode_id'] == 'azure_conversation:azure-001918',
        'all_online_ids_and_metadata_match': matches,
        'all_online_outputs_complete_without_errors': complete == len(planned) == len(actual),
        'zero_batch_submissions': complete_marker['batch_jobs_submitted'] == 0 and not (output / 'batch.jsonl').exists(),
        'zero_observed_batch_activity': not any(r['class'] == 'batch' for r in gates) and bool(states)
            and all(sum(r['inflight_batch']) == 0 and r['completed_batch'] == 0 for r in states),
        'batch_paused_in_all_phase_controls': bool(actions) and all(r['control']['batch_paused'] and r['action']['batch_concurrency'] == 0 for r in actions),
        'online_capacity_unchanged': config['runtime']['online_concurrency'] == 8 and max_online is not None and max_online <= 8
            and all(r['control']['online_concurrency'] == 8 for r in actions) and routing['maximum_online_per_replica_after_selection'] <= 2,
        'online_placement_rule_observed': routing['online_records'] == len(actual) and routing['online_rule_matches'] == len(actual),
        'gateway_and_shared_helpers_unchanged': all(filecmp.cmp(output / name, source / name, shallow=False) for name in programs),
        'same_service_configuration': m.normalized_configuration(config) == m.normalized_configuration(source_config),
        'same_slos': previous['slos'] == {'ttft_p95_ms': ttft_slo, 'request_mean_stream_gap_p99_ms': gap_slo},
        'same_fixed_horizon': protocol['duration_s'] == m.read_json(source / 'protocol.json')['duration_s'] == 1950,
        'stream_alignment_complete': not observation['alignment_problems'] and not observation['duplicate_gateway_ids']
            and not observation['unexpected_gateway_ids'] and observation['paired_gap_samples'] == phases['evaluation']['request_mean_stream_gap_samples'],
        'cross_process_clock_order_observed': observation['negative_forward_to_client_time_events'] == 0,
        'chunk1024_observed': len(budgets) == 4 and all(v == [1024] for v in budgets.values()),
        'context_length_observed': len(lengths) == 4 and all(v == [int(config['model']['max_model_len'])] for v in lengths.values()),
        'p400_caps_observed': caps['requested_sequence_observed'] and caps['all_configured_gpu_caps_matched_at_transitions'],
    }
    mapped = {r['request_id']: r for r in online_gates}
    timings = [request_timing(r, mapped.get(r['request_id'])) for r in actual]
    comparison = {p: matched_phase(old, actual, p, ttft_slo, gap_slo) for p in ('warmup', 'recovery_middle', 'evaluation')} if matches else {'status': '待确认：请求未完整匹配'}
    return {'status': 'CONVERSATION1918_ONLINE_ONLY_MEASURED', 'episode_id': settings['episode_id'],
        'run': str(output), 'reference_mixed_run': str(source), 'checks': checks, 'failed_checks': [k for k, v in checks.items() if not v],
        'evaluation_service_pass': all(checks.values()) and phases['evaluation']['observed_slo_safe'],
        'all_main_phases_service_pass': all(checks.values()) and all(phases[p]['observed_slo_safe'] for p in ('warmup', 'event_time_reference', 'recovery_early', 'recovery_middle', 'recovery_late')),
        'phases': phases, 'reference_phases': recorded, 'slos': {'ttft_p95_ms': ttft_slo, 'request_mean_stream_gap_p99_ms': gap_slo},
        'online_requests': len(actual), 'online_complete': complete, 'batch_jobs_submitted': 0,
        'batch_deadline_evaluated': False, 'offered_bid_w': None, 'external_commitment': False,
        'routing': routing, 'matched_phases': comparison, 'stream_observation': observation,
        'ttft_decomposition': {p: phase_summary(timings, states, int(protocol['start_wall_ns']), *bounds, ttft_slo) for p, bounds in m.PHASES.items()},
        'engine_token_budgets': budgets, 'power_cap_observations': caps, 'input_context': m.read_json(output / 'INPUT_CONTEXT.json'),
        'gpu_power': m.power_window(m.gpu_series(output), 150, 1950),
        'reference_batch_outcomes': previous['batch'],
        'online_dispatches_at_or_after_horizon': sum(r.get('dispatch_wall_time_ns') is not None and r['dispatch_wall_time_ns'] >= protocol['deadline_wall_ns'] for r in actual),
        'limitations': [
            'One online-only run compared with the earlier P400 mixed-cohort condition. Run-order and execution variation remain.',
            'Online input, eight slots, placement, priorities, chunk1024 and P400 are retained; no batch jobs are submitted.',
            'The saved 280-job cohort is unchanged. This run cannot establish its deadline feasibility, recovery or DR delivery.',
            'The original 1950-second horizon, scheduled-arrival phase assignment, output lengths and SLO thresholds are retained.',
            'Gap p99 is across per-request mean nonempty SSE-text gaps, not individual token gaps.',
            'Pre-admission TTFT includes transport and admission waiting; it is not an engine execution measurement.',
        ]}


def cell_text(result):
    lines = ['=== CONVERSATION1918_ONLINE_ONLY_RESULT ===', 'STATUS=' + result['status'],
             'REFERENCE_MIXED_RUN=' + result['reference_mixed_run'],
             'EVALUATION_SERVICE_PASS=' + str(result['evaluation_service_pass']),
             'ALL_MAIN_PHASES_SERVICE_PASS=' + str(result['all_main_phases_service_pass']),
             'FAILED_CHECKS=' + json.dumps(result['failed_checks']),
             'phase condition requests TTFT_p95_ms gap_p99_ms TTFT_tails gap_tails errors safe']
    for phase in m.PHASES:
        for label, phases in (('mixed_p400', result['reference_phases']), ('online_only', result['phases'])):
            r = phases[phase]
            lines.append(' '.join(map(str, (phase, label, r['requests'], r['ttft_p95_ms'], r['request_mean_stream_gap_p99_ms'],
                r['requests_with_ttft_over_slo'], r['requests_with_mean_stream_gap_over_slo'], r['errors'], r['observed_slo_safe']))))
    for key in ('checks', 'online_requests', 'online_complete', 'batch_jobs_submitted', 'routing', 'matched_phases',
                'engine_token_budgets', 'input_context', 'gpu_power', 'online_dispatches_at_or_after_horizon'):
        lines.append(key.upper() + '=' + json.dumps(result[key], ensure_ascii=False))
    for phase in ('warmup', 'recovery_early', 'recovery_middle', 'recovery_late'):
        r = result['ttft_decomposition'][phase]
        lines.append('TTFT_CONTEXT=' + json.dumps({'phase': phase, 'ttft_tail_requests': r['ttft_tail_requests'],
            'tail_decomposition': r['ttft_over_slo'], 'gateway_snapshots': r['gateway_snapshots']}))
    lines += result['limitations']
    return '\n'.join(lines) + '\n'
