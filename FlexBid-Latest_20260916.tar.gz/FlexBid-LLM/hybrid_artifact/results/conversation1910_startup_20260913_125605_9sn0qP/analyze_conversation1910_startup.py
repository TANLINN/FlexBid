"""Read saved startup logs, warmup request timings and original cohort outcomes."""
import argparse
from collections import Counter
import csv
import filecmp
import json
import math
from pathlib import Path
import re

from analyze_c6_ttft_decomposition import (read_json, read_rows, unique_index, request_timing,
                                          phase_summary, describe, finite)

NS = 10**9
PHASES = {'warmup': (0, 150), 'warmup_first30': (0, 30), 'warmup_after30': (30, 150),
          **{f'warmup_{left}_{left+30}': (left, left+30) for left in (30, 60, 90, 120)},
          'event_time_reference': (150, 450), 'recovery': (450, 1950)}
META = ('arrival_ms', 'prompt_tokens', 'max_output_tokens', 'parent_request_id', 'tool_delay_ms')


def close(a, b):
    return a is None and b is None or a is not None and b is not None and math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-6)


def batch_outcome(root, protocol):
    plan = unique_index(read_rows(root / 'batch_jobs.jsonl'), 'job_id', 'planned batch')
    ledger = unique_index(read_rows(root / 'batch.jsonl'), 'job_id', 'batch results')
    if set(ledger) - set(plan):
        raise ValueError('Unplanned batch results: ' + str(root))
    start, end = int(protocol['start_wall_ns']), int(protocol['deadline_wall_ns'])
    details = []
    for key, definition in plan.items():
        row = ledger.get(key)
        dispatch = row.get('dispatch_wall_time_ns') if row else None
        finish = row.get('completion_wall_time_ns') if row else None
        complete = bool(row) and row.get('error') is None and row.get('status_code') == 200 and row.get('completion_tokens') == definition['max_output_tokens'] and dispatch is not None and finish is not None and int(dispatch) <= int(finish)
        if complete:
            category = 'completed_on_time' if int(finish) <= end else 'completed_late'
        elif row is None:
            category = 'missing_result'
        elif dispatch is None:
            category = 'not_started_by_deadline' if row.get('job_status') == 'not_started_by_deadline' else 'undispatched_other_record'
        else:
            category = 'dispatched_unsuccessful_or_incomplete'
        details.append({'job_id': key, 'category': category,
                        'dispatch_s': (int(dispatch)-start)/NS if dispatch is not None else None,
                        'successful_completion_s': (int(finish)-start)/NS if complete else None})
    counts = Counter(r['category'] for r in details)
    finished = [r['successful_completion_s'] for r in details if r['successful_completion_s'] is not None]
    full = max(finished) if finished and len(finished) == len(plan) else None
    return {'planned_jobs': len(plan), 'categories': dict(counts),
            'jobs_completed_on_time': counts['completed_on_time'], 'jobs_completed_late': counts['completed_late'],
            'jobs_unfinished_or_failed': len(plan)-len(finished),
            'all_job_finish_s': full, 'last_successful_subset_finish_s': max(finished, default=None),
            'completed_at': {str(t): sum(f <= t for f in finished) for t in (150,450,950,1450,1650,1950)},
            'deadline_failures': [r for r in details if r['category'] != 'completed_on_time']}


def boundary(rows, states, start, cutoff):
    end = start + int(cutoff*NS)
    selected = [r for r in rows if float(r['arrival_ms']) < min(cutoff,150)*1000]
    counts = Counter()
    pending = []
    for row in selected:
        dispatch, finish = row.get('dispatch_wall_time_ns'), row.get('completion_wall_time_ns')
        if finish is not None and int(finish) <= end:
            category = 'result_recorded_by_cutoff'
        elif dispatch is None or int(dispatch) > end:
            category = 'not_dispatched_by_cutoff'
        else:
            category = 'dispatched_without_result_by_cutoff'
        counts[category] += 1
        if category != 'result_recorded_by_cutoff':
            pending.append(row['request_id'])
    before = [r for r in states if int(r['wall_time_ns']) <= end]
    latest = max(before, key=lambda r:int(r['wall_time_ns'])) if before else None
    return {'cutoff_s': cutoff, 'warmup_scheduled_requests_before_cutoff': len(selected),
            'outcomes': dict(counts), 'pending_ids': pending,
            'latest_snapshot': {k: latest.get(k) for k in ('wall_time_ns','online_waiting','batch_waiting','inflight_online','inflight_batch')} if latest else None,
            'snapshot_age_s': (end-int(latest['wall_time_ns']))/NS if latest else None}


def saved_log_excerpt(path):
    if not path.is_file():
        return {'status': 'MISSING', 'path': str(path)}
    pattern = re.compile(r'compil|cuda graph|cudagraph|warm.?up|profil|cache|load.*model|model.*load|initializ|ready|error|traceback|warning|startup|MEASUREMENT_STARTED|MEASUREMENT_ENDED', re.I)
    found, lines = [], 0
    with path.open(encoding='utf-8', errors='replace') as stream:
        for lines, text in enumerate(stream, 1):
            if pattern.search(text):
                found.append({'line': lines, 'text': text.rstrip()[:1600]})
    selected = found if len(found) <= 50 else found[:25] + found[-25:]
    return {'status': 'READ', 'path': str(path), 'total_lines': lines, 'matching_lines': len(found),
            'omitted_matches': len(found)-len(selected), 'excerpts': selected}


def analyze_run(root):
    report, protocol = read_json(root/'REPORT.json'), read_json(root/'protocol.json')
    start, end = int(protocol['start_wall_ns']), int(protocol['deadline_wall_ns'])
    online = read_rows(root/'online.jsonl')
    planned = unique_index(read_rows(root/'online_workload.jsonl'), 'request_id', 'online input')
    index = unique_index(online, 'request_id', 'online results')
    gates = unique_index([r for r in read_rows(root/'stream_gateway.jsonl') if r['class'] == 'online'], 'request_id', 'online gateway')
    states = read_rows(root/'gateway_state.jsonl')
    threshold = float(report['slos']['ttft_p95_ms'])
    records = [request_timing(row, gates.get(row['request_id'])) for row in online]
    for record in records:
        row = index[record['request_id']]
        for field in ('dispatch_wall_time_ns','completion_wall_time_ns'):
            stamp = row.get(field)
            record[field.replace('_wall_time_ns','_s')] = (int(stamp)-start)/NS if stamp is not None else None
    phases = {name:phase_summary(records,states,start,left,right,threshold) for name,(left,right) in PHASES.items()}
    checks = {'same_online_ids_and_metadata': set(index)==set(planned) and all(all(row.get(k)==planned[key].get(k) for k in META) for key,row in index.items()),
              'online_count_matches': len(online)==report['online_requests'],
              'duration_matches': end-start==1950*NS,
              'original_ttft_threshold': threshold==5000,
              'original_gap_threshold': report['slos']['request_mean_stream_gap_p99_ms']==100}
    for name in ('warmup','warmup_first30','warmup_after30','event_time_reference','recovery'):
        saved, actual = report['phases'][name], phases[name]
        checks[name+'_requests_match'] = saved['requests']==actual['requests']
        checks[name+'_ttft_matches'] = close(saved['ttft_p95_ms'],actual['ttft_p95_ms'])
        checks[name+'_ttft_tails_match'] = saved['requests_with_ttft_over_slo']==actual['ttft_tail_requests']
    cohort = batch_outcome(root,protocol)
    for k in ('planned_jobs','jobs_completed_on_time','jobs_completed_late','jobs_unfinished_or_failed'):
        checks['batch_'+k] = cohort[k]==report['batch'][k]
    for t,count in report['cohort_timing']['jobs_completed_by_offset'].items():
        checks['completed_'+t] = cohort['completed_at'][t]==count
    checks['full_cohort_slack_matches'] = close(None if cohort['all_job_finish_s'] is None else 1950-cohort['all_job_finish_s'], report['cohort_timing']['all_job_completion_slack_s'])
    warm = [r for r in records if float(r['arrival_ms']) < 150000]
    completed = [r['completion_s'] for r in warm if r['completion_s'] is not None]
    logs = [root/'service_logs'/f'vllm_replica_{i}.log' for i in range(4)] + [root/'service_logs/gateway.log',root/'logs/launcher.log']
    return {'root': str(root), 'environment': report['environment'], 'protocol': protocol,
            'checks': checks, 'all_saved_counts_match': all(checks.values()),
            'online_timing_available': sum(r['timing_status']=='AVAILABLE' for r in records),
            'online_timing_unavailable': dict(Counter(r.get('timing_reason') for r in records if r['timing_status']!='AVAILABLE')),
            'maximum_component_sum_error_ms': max((abs(r['component_sum_error_ms']) for r in records if r['timing_status']=='AVAILABLE'),default=None),
            'phases': phases, 'boundaries': [boundary(online,states,start,t) for t in (30,60,90,120,145,150,180,210)],
            'last_warmup_result_offset_s': max(completed,default=None),
            'warmup_request_results_after_150': sum(t>150 for t in completed),
            'cohort': cohort, 'saved_logs': [saved_log_excerpt(path) for path in logs]}, warm


def analyze(p400, p300):
    runs, records = {}, {}
    for label, path in (('p400',p400),('event_p300',p300)):
        runs[label], records[label] = analyze_run(path)
    indexed = {label:unique_index(rows,'request_id',label) for label,rows in records.items()}
    all_ids = sorted(set.union(*(set(rows) for rows in indexed.values())))
    pairs = []
    fields = ('ttft_ms','pre_admission_estimate_ms','admission_to_upstream_first_ms','forward_to_client_first_estimate_ms','scheduled_to_dispatch_ms','dispatch_s','completion_s')
    for key in all_ids:
        a,b = (indexed[label].get(key) for label in ('p400','event_p300'))
        metadata_match = a is not None and b is not None and all(a[k]==b[k] for k in META)
        pair = {'request_id':key,'metadata_match':metadata_match}
        for label,row in (('p400',a),('event_p300',b)):
            pair.update({label+'_'+k:row.get(k) if row else None for k in (*fields,'timing_status')})
        for field in fields:
            x,y = pair['p400_'+field],pair['event_p300_'+field]
            pair['delta_'+field] = x-y if metadata_match and x is not None and y is not None else None
        pairs.append(pair)
    return {'status':'CONVERSATION1910_STARTUP_ANALYSIS_COMPLETE', 'runs':runs,
            'same_saved_inputs': all(filecmp.cmp(p400/name,p300/name,shallow=False) for name in ('online_workload.jsonl','batch_jobs.jsonl')),
            'all_saved_counts_match': all(r['all_saved_counts_match'] for r in runs.values()),
            'same_environment_record':runs['p400']['environment']==runs['event_p300']['environment'],
            'warmup_matches': {'requests':len(pairs),'metadata_matching':sum(r['metadata_match'] for r in pairs),
                'p400_minus_p300':{field:describe([finite(r['delta_'+field]) for r in pairs]) for field in fields}},
            'matched_warmup_requests':pairs, 'gpu_workload_run':False,
            'limitations':[
                'Saved records only; no GPU query, workload, retry, parameter change or source overwrite.',
                'The two runs have different GPU models and drivers. Warmup is online-only P400 in both; its differences cannot be caused by the later event cap.',
                'TTFT decomposition uses the original client clock bracket. Before-admission includes request preparation, transport, class-slot and placement waiting; upstream-first delay is not engine-only time.',
                'Scheduled-to-dispatch lag is separate from recorded TTFT and can include parent/tool dependencies. Scheduled phase membership and original SLO boundaries are retained.',
                'Boundary summaries reconstruct results received by the cutoff and the last available gateway snapshot, with snapshot age; they are not a live policy replay.',
                'Log excerpts retain line numbers and omitted-match counts. A compilation/cache message alone does not establish the cause or duration of a particular request delay.',
                'Late, missing and unstarted jobs remain deadline failures; neither successful-subset end time is treated as full-cohort completion.',
                'This analysis does not estimate a counterfactual deadline, isolate a cap effect or add a P300 forecast-validation sample.']}


def format_report(result):
    lines = ['=== CONVERSATION1910_STARTUP_ANALYSIS ===','STATUS='+result['status']]
    for key in ('same_saved_inputs','all_saved_counts_match','same_environment_record','warmup_matches'):
        lines.append(key.upper()+'='+json.dumps(result[key]))
    for label,run in result['runs'].items():
        lines.append('RUN='+json.dumps({'condition':label,**{k:v for k,v in run.items() if k not in ('phases','saved_logs','boundaries')}}))
        for phase,row in run['phases'].items():
            tail = row['ttft_over_slo']
            lines.append('PHASE='+json.dumps({'condition':label,'phase':phase,
                **{k:row[k] for k in ('requests','unsuccessful_requests','missing_ttft','ttft_p95_ms','ttft_tail_requests','scheduled_to_dispatch_ms')},
                'timed_tail_requests':tail['timed_requests'], 'tail_timing_unavailable':tail['timing_unavailable'],
                'tail_pre_admission_majority':tail['pre_admission_lower_bound_exceeds_half_ttft'],
                'tail_upstream_first_majority':tail['admission_to_upstream_exceeds_half_ttft'],
                'tail_components_ms':{k:tail['components'][k] for k in ('pre_admission_estimate_ms','admission_to_upstream_first_ms','forward_to_client_first_estimate_ms')},
                'gateway_snapshots':row['gateway_snapshots']}))
        for row in run['boundaries']:
            lines.append('BOUNDARY='+json.dumps({'condition':label,**{k:v for k,v in row.items() if k!='pending_ids'},'pending_ids_first8':row['pending_ids'][:8]}))
        for row in run['saved_logs']:
            lines.append('SAVED_LOG='+json.dumps({'condition':label,**row}))
    lines.extend(result['limitations'])
    return '\n'.join(lines)+'\n'


def main():
    parser = argparse.ArgumentParser()
    for name in ('p400','p300','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    args = parser.parse_args()
    result = analyze(args.p400,args.p300)
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'REPORT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    with (args.output/'matched_warmup_requests.csv').open('w',encoding='utf-8',newline='') as stream:
        rows = result['matched_warmup_requests']
        if rows:
            writer = csv.DictWriter(stream,fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    text = format_report(result)
    (args.output/'REPORT.txt').write_text(text,encoding='utf-8')
    print(text,end='')
    return 0 if result['all_saved_counts_match'] and result['same_saved_inputs'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
