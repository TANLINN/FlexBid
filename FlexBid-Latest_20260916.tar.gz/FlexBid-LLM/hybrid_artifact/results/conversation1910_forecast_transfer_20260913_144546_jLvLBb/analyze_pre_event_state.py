"""Compare timestamp-limited online state across saved development and validation runs."""
import argparse
import json
import math
from pathlib import Path
from statistics import mean

NS = 1_000_000_000
CUTOFF = 145
LEFT = 85


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_rows(path):
    rows = []
    with path.open(encoding='utf-8') as stream:
        for number, line in enumerate(stream, 1):
            if line.strip():
                try:
                    row = json.loads(line)
                except ValueError as exc:
                    raise ValueError(f'{path}:{number}: {exc}') from exc
                row.pop('stream_observations', None)
                row.pop('prompt_token_ids', None)
                rows.append(row)
    return rows


def indexed(rows):
    result = {row['request_id']: row for row in rows}
    if len(result) != len(rows):
        raise ValueError('Duplicate request_id')
    return result


def stats(values):
    values = sorted(float(v) for v in values if v is not None)
    if any(not math.isfinite(v) for v in values):
        raise ValueError('Nonfinite descriptor')
    if not values:
        return {'n': 0, 'mean': None, 'min': None, 'p95': None, 'max': None}
    rank = .95 * (len(values) - 1)
    low, high = math.floor(rank), math.ceil(rank)
    return {'n': len(values), 'mean': mean(values), 'min': values[0],
            'p95': values[low] + (values[high] - values[low]) * (rank - low), 'max': values[-1]}


def prefix(definitions, ledger, states, start):
    online = indexed(ledger)
    indexed(definitions)
    cutoff = start + CUTOFF * NS
    due = [d for d in definitions if 0 <= d['arrival_ms'] < CUTOFF * 1000]
    recent = [d for d in due if d['arrival_ms'] >= LEFT * 1000]
    pending = []
    for definition in due:
        row = online[definition['request_id']]
        dispatch, ended = row.get('dispatch_wall_time_ns'), row.get('completion_wall_time_ns')
        if ended is not None and int(ended) <= cutoff:
            if dispatch is None or int(dispatch) > int(ended):
                raise ValueError('Completed prefix result has inconsistent dispatch time')
            continue
        dispatched = dispatch is not None and int(dispatch) <= cutoff
        pending.append({'request_id': definition['request_id'],
                        'scheduled_offset_s': definition['arrival_ms'] / 1000,
                        'original_prompt_tokens': definition['prompt_tokens'],
                        'original_output_quota_tokens': definition['max_output_tokens'],
                        'scheduled_age_s': CUTOFF - definition['arrival_ms'] / 1000,
                        'dispatched_by_cutoff': dispatched,
                        'dispatch_age_s': (cutoff - int(dispatch)) / NS if dispatched else None})
    pending.sort(key=lambda r: (-r['scheduled_age_s'], str(r['request_id'])))
    observations = sorted((s for s in states if start <= int(s['wall_time_ns']) <= cutoff),
                          key=lambda s: int(s['wall_time_ns']))
    recent_states = [s for s in observations if int(s['wall_time_ns']) >= start + LEFT * NS]
    latest = observations[-1] if observations else None
    times = [int(s['wall_time_ns']) for s in recent_states]
    gateway = {'recent_samples': len(recent_states),
               'latest_sample_age_s': (cutoff - int(latest['wall_time_ns'])) / NS if latest else None,
               'recent_maximum_sample_gap_s': max(((b-a)/NS for a, b in zip(times, times[1:])), default=None),
               'latest_online_by_replica': list(latest['inflight_online']) if latest else None,
               'latest_online_waiting': latest['online_waiting'] if latest else None,
               'recent_online_active': stats(sum(s['inflight_online']) for s in recent_states),
               'recent_online_waiting': stats(s['online_waiting'] for s in recent_states)}
    return {'cutoff_s': CUTOFF, 'recent_interval_s': [LEFT, CUTOFF],
            'scheduled_before_cutoff': len(due), 'recent_requests': len(recent),
            'recent_requests_per_s': len(recent) / (CUTOFF-LEFT),
            'recent_prompt_tokens_per_s': sum(d['prompt_tokens'] for d in recent) / (CUTOFF-LEFT),
            'recent_output_quota_tokens_per_s': sum(d['max_output_tokens'] for d in recent) / (CUTOFF-LEFT),
            'pending_count': len(pending),
            'pending_not_dispatched': sum(not p['dispatched_by_cutoff'] for p in pending),
            'pending_original_output_quota_sum': sum(p['original_output_quota_tokens'] for p in pending),
            'pending_original_output_quota': stats(p['original_output_quota_tokens'] for p in pending),
            'pending_scheduled_age_s': stats(p['scheduled_age_s'] for p in pending),
            'pending_dispatch_age_s': stats(p['dispatch_age_s'] for p in pending),
            'pending_requests': pending, 'gateway': gateway}


def analyze_run(item, role):
    run = Path(item['run'])
    report, protocol = read_json(run / 'REPORT.json'), read_json(run / 'protocol.json')
    if report['episode_id'] != item['episode_id']:
        raise ValueError('Saved episode_id does not match analysis manifest')
    definitions = read_rows(run / 'online_workload.jsonl')
    ledger = read_rows(run / 'online.jsonl')
    outcomes = indexed(ledger)
    if set(indexed(definitions)) != set(outcomes):
        raise ValueError('Saved input and result request IDs differ')
    for definition in definitions:
        if any(definition[k] != outcomes[definition['request_id']][k]
               for k in ('arrival_ms', 'prompt_tokens', 'max_output_tokens')):
            raise ValueError('Saved request metadata differ')
    p = prefix(definitions, ledger, read_rows(run / 'gateway_state.jsonl'), int(protocol['start_wall_ns']))
    if role == 'development':
        old = item['pre_event_features']
        previous_count = old['cumulative']['without_ended_result_at_cutoff']
        previous_prompt = old['recent']['requested_prompt_tokens_per_s']
        previous_output = old['recent']['requested_output_quota_tokens_per_s']
    else:
        old = item['pre_event_reconstruction']
        previous_count = old['prefix']['online_at_cutoff']['not_ended']
        previous_prompt = old['recent']['scheduled']['prompt_tokens_per_s']
        previous_output = old['recent']['scheduled']['output_quota_tokens_per_s']
    comparisons = {'pending_count_matches_previous': p['pending_count'] == previous_count,
                   'recent_prompt_rate_matches_previous': math.isclose(p['recent_prompt_tokens_per_s'], previous_prompt),
                   'recent_output_rate_matches_previous': math.isclose(p['recent_output_quota_tokens_per_s'], previous_output)}
    timing, batch = report['cohort_timing'], report['batch']
    event_jobs = timing['jobs_completed_by_offset']['450']
    finish = timing['last_completed_job_offset_s'] if batch['jobs_unfinished_or_failed'] == 0 else None
    return {'episode_id': item['episode_id'], 'run': str(run), 'role': role, 'status': 'READ_COMPLETE',
            'pre_event_state': p, 'previous_analysis_comparisons': comparisons,
            'all_compared_values_match': all(comparisons.values()),
            'later_outcomes_not_features': {
                'event_completed_jobs': event_jobs, 'cohort_finish_s': finish,
                'recovery_jobs_per_min': (batch['planned_jobs']-event_jobs)*60/(finish-450)
                    if finish is not None and finish > 450 else None,
                'batch': batch, 'service_and_deadline_pass_observed': report['service_and_deadline_pass_observed'],
                'failed_service_phases': [name for name, phase in report['phases'].items()
                                          if phase['observed_slo_safe'] is False]}}


def descriptors(row):
    p, later = row['pre_event_state'], row['later_outcomes_not_features']
    return {**{k: p[k] for k in ('recent_prompt_tokens_per_s', 'recent_output_quota_tokens_per_s',
                                'pending_count', 'pending_not_dispatched', 'pending_original_output_quota_sum')},
            'pending_scheduled_age_max_s': p['pending_scheduled_age_s']['max'],
            'pending_dispatch_age_max_s': p['pending_dispatch_age_s']['max'],
            'recent_online_active_sample_mean': p['gateway']['recent_online_active']['mean'],
            'recent_online_waiting_sample_mean': p['gateway']['recent_online_waiting']['mean'],
            'latest_online_active': sum(p['gateway']['latest_online_by_replica'])
                if p['gateway']['latest_online_by_replica'] is not None else None,
            'latest_online_waiting': p['gateway']['latest_online_waiting'],
            **{k: later[k] for k in ('event_completed_jobs', 'cohort_finish_s', 'recovery_jobs_per_min')}}


def summarize(rows):
    groups = {}
    for row in rows:
        groups.setdefault((row['role'], row['episode_id']), []).append(row)
    summary = []
    for (role, episode), cases in groups.items():
        usable = [r for r in cases if r['status'] == 'READ_COMPLETE']
        values = [descriptors(r) for r in usable]
        summary.append({'role': role, 'episode_id': episode, 'selected_runs': len(cases),
                        'read_runs': len(usable), 'error_runs': len(cases)-len(usable),
                        'comparison_mismatch_runs': sum(not r['all_compared_values_match'] for r in usable),
                        'snapshot_missing_runs': sum(not r['pre_event_state']['gateway']['recent_samples'] for r in usable),
                        'within_episode_run_descriptors': {key: stats(v[key] for v in values)
                                                         for key in values[0]} if values else {}})
    return summary


def analyze(development_report, validation_report):
    rows, sources, seen = [], [], set()
    for role, path in (('development', development_report), ('validation', validation_report)):
        try:
            items = read_json(path)['runs']
            if not isinstance(items, list) or not items:
                raise ValueError('Source analysis has no run list')
            sources.append({'role': role, 'path': str(path), 'status': 'READ_COMPLETE', 'selected_runs': len(items)})
        except (OSError, ValueError, KeyError, TypeError) as exc:
            sources.append({'role': role, 'path': str(path), 'status': 'INPUT_ERROR', 'error': str(exc)})
            continue
        for item in items:
            try:
                key = str(Path(item['run']).resolve())
                if key in seen:
                    raise ValueError('Duplicate run in source analyses')
                seen.add(key)
                rows.append(analyze_run(item, role))
            except (OSError, ValueError, TypeError, KeyError) as exc:
                rows.append({'role': role, 'episode_id': item.get('episode_id'), 'run': item.get('run'),
                             'status': 'INPUT_ERROR', 'error': f'{type(exc).__name__}: {exc}'})
    complete = (bool(rows) and all(s['status'] == 'READ_COMPLETE' for s in sources)
                and all(r['status'] == 'READ_COMPLETE' and r['all_compared_values_match']
                        and r['pre_event_state']['gateway']['recent_samples'] > 0 for r in rows))
    return {'status': 'PRE_EVENT_STATE_COMPARISON_COMPLETE' if complete else 'PRE_EVENT_STATE_COMPARISON_PARTIAL',
            'source_analyses': sources, 'selected_runs': len(rows),
            'workload_episode_count': len({r['episode_id'] for r in rows}),
            'runs': rows, 'episodes': summarize(rows), 'gpu_workload_run': False, 'models_refitted': False,
            'semantics': [
                'State cutoff is 145 s; scheduled metadata use arrivals in [0,145) and [85,145). Only dispatch, completion and snapshot timestamps at or before the cutoff determine state.',
                'An unfinished request contributes its ORIGINAL output quota, not remaining output tokens. Neither future completion tokens nor final latency enters pre-event state.',
                'Scheduled age includes all delay since arrival. Dispatch age includes transport, gateway waiting and engine service; neither identifies remaining work.',
                'Pending client requests and gateway waiting/active snapshots measure different stages and times. Their counts are not interchangeable.',
                'Gateway averages are snapshot means. Latest sample age, sampling gaps and per-replica counts remain reported.',
                'Original physical runs remain separate; within-episode ranges describe repeats, not independent workload samples. Missing inputs remain explicit.',
                'Later outcomes are separately labelled descriptive targets. These offline state reconstructions were not additional inputs to the recorded prospective predictions.',
                'No predictor or feature-selection rule is fitted. Reusing validation outcomes to choose a revised predictor would require subsequent evaluation on other workloads.',
            ]}


def report_text(result):
    lines = ['=== PRE_EVENT_STATE_COMPARISON ===', 'STATUS=' + result['status'],
             'SELECTED_RUNS=' + str(result['selected_runs']), 'WORKLOAD_EPISODES=' + str(result['workload_episode_count'])]
    lines.extend('SOURCE=' + json.dumps(s, ensure_ascii=False) for s in result['source_analyses'])
    lines.extend('CASE=' + json.dumps(r, ensure_ascii=False) for r in result['runs'])
    lines.append('role episode runs prompt_tok_s output_quota_tok_s pending original_pending_quota age_max_s online_active_mean event_jobs recovery_jobs_min')
    keys = ('recent_prompt_tokens_per_s', 'recent_output_quota_tokens_per_s', 'pending_count',
            'pending_original_output_quota_sum', 'pending_scheduled_age_max_s', 'recent_online_active_sample_mean',
            'event_completed_jobs', 'recovery_jobs_per_min')
    for row in result['episodes']:
        d = row['within_episode_run_descriptors']
        vals = [d.get(k, {}).get('mean') for k in keys]
        lines.append(f"{row['role']} {row['episode_id']} {row['read_runs']}/{row['selected_runs']} " +
                     ' '.join('NA' if v is None else f'{v:.3f}' for v in vals))
        lines.append('EPISODE=' + json.dumps(row, ensure_ascii=False))
    lines.extend(result['semantics'])
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--development-report', type=Path, required=True)
    parser.add_argument('--validation-report', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.development_report, args.validation_report)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'REPORT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    text = report_text(result)
    (args.output / 'REPORT.txt').write_text(text, encoding='utf-8')
    print(text, end='')
    return 0 if result['status'] == 'PRE_EVENT_STATE_COMPARISON_COMPLETE' else 2


if __name__ == '__main__':
    raise SystemExit(main())
