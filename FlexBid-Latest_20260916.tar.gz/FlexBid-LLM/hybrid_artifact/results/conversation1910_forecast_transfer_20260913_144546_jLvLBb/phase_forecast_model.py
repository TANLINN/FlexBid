"""Point forecasts with separate event and recovery feature sets."""
import copy
import math

METHODS = ('prompt_load_refit', 'event_state_recovery_load')


def models_from_fits(load, state):
    if load['status'] != 'FITTED' or state['status'] != 'FITTED':
        raise ValueError('Both phase fits must be available')
    if [r['episode_id'] for r in load['training_episodes']] != [r['episode_id'] for r in state['training_episodes']]:
        raise ValueError('Phase fits use different training episodes')
    reference = copy.deepcopy(load)
    reference['method'] = METHODS[0]
    candidate = copy.deepcopy(state)
    candidate['method'] = METHODS[1]
    candidate['coefficients']['recovery_jobs_per_min'] = copy.deepcopy(load['coefficients']['recovery_jobs_per_min'])
    candidate['phase_fits'] = {'event_jobs': 'prompt_and_pending_quota', 'recovery_jobs_per_min': 'prompt_load_linear'}
    statistic_keys = ('rank', 'columns', 'residual_degrees_of_freedom', 'standardized_design_condition_number')
    candidate['phase_fit_statistics'] = {
        'event_jobs': {k: state[k] for k in statistic_keys},
        'recovery_jobs_per_min': {k: load[k] for k in statistic_keys},
    }
    for k in statistic_keys:
        candidate.pop(k, None)
    return [reference, candidate]


def features_from_state(state):
    if state['cutoff_s'] != 145 or state['recent_interval_s'] != [85, 145]:
        raise ValueError('Unexpected state cutoff')
    values = {'prompt_tokens_per_s': float(state['recent_prompt_tokens_per_s']),
              'pending_original_output_quota': float(state['pending_original_output_quota_sum'])}
    if any(not math.isfinite(v) or v < 0 for v in values.values()):
        raise ValueError('Unavailable or invalid recorded feature')
    return values


def predict(model, features):
    targets = {k: c['intercept'] + sum(slope * features[name] for name, slope in c['slopes'].items())
               for k, c in model['coefficients'].items()}
    event, rate = targets['event_jobs'], targets['recovery_jobs_per_min']
    result = {'method': model['method'], 'features': features,
              'predicted_event_jobs': event, 'predicted_recovery_jobs_per_min': rate,
              'outside_marginal_training_ranges': [k for k, (lo, hi) in model['training_feature_ranges'].items()
                                                   if not lo <= features[k] <= hi]}
    if not all(math.isfinite(v) for v in targets.values()) or not 0 <= event < 280 or rate <= 0:
        return {**result, 'status': 'UNSUPPORTED_POINT_PREDICTION', 'predicted_finish_s': None}
    finish = 450 + (280 - event) * 60 / rate
    return {**result, 'status': 'POINT_PREDICTION', 'predicted_finish_s': finish, 'predicted_slack_s': 1950 - finish}
