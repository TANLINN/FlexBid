"""Replay existing point predictors on timestamp-limited saved P300 states."""
import argparse
import filecmp
import json
from pathlib import Path

from analyze_pre_event_state import read_json, read_rows, indexed, prefix
from analyze_load_conditioned_forecast import predict as load_predict
from phase_forecast_model import features_from_state, predict as phase_predict


def predictions(models, features):
    rows = []
    for family, model_list in models.items():
        for model in model_list:
            value = (load_predict(model, features['prompt_tokens_per_s']) | {'method': model['method']}
                     if family == 'original_three' else phase_predict(model, features))
            rows.append({'family': family, **value})
    return rows


def score(prediction, batch, event_jobs, last_success_s):
    complete = batch['jobs_unfinished_or_failed'] == 0 and batch['jobs_completed_on_time'] + batch['jobs_completed_late'] == batch['planned_jobs']
    actual_finish = last_success_s if complete else None
    finish = prediction.get('predicted_finish_s')
    deadline_met = batch['jobs_completed_on_time'] == batch['planned_jobs']
    return {**prediction, 'actual_event_jobs': event_jobs,
            'event_job_error': prediction['predicted_event_jobs'] - event_jobs,
            'actual_full_cohort_finish_s': actual_finish,
            'finish_error_s': finish - actual_finish if finish is not None and actual_finish is not None else None,
            'observed_deadline_met': deadline_met,
            'optimistic_deadline_miss': finish <= 1950 and not deadline_met if finish is not None else None}


def read_case(root, models):
    report, protocol = read_json(root/'REPORT.json'), read_json(root/'protocol.json')
    definitions, ledger = read_rows(root/'online_workload.jsonl'), read_rows(root/'online.jsonl')
    plans, results = indexed(definitions), indexed(ledger)
    if set(plans) != set(results):
        raise ValueError('Saved online input/result identities differ: '+str(root))
    keys = ('arrival_ms','prompt_tokens','max_output_tokens','parent_request_id','tool_delay_ms')
    if any(any(plans[key].get(k)!=row.get(k) for k in keys) for key,row in results.items()):
        raise ValueError('Saved online input/result metadata differ: '+str(root))
    state = prefix(definitions, ledger, read_rows(root/'gateway_state.jsonl'), int(protocol['start_wall_ns']))
    features = features_from_state(state)
    batch, timing = report['batch'], report['cohort_timing']
    event_jobs = timing['jobs_completed_by_offset']['450']
    # The original predictors describe C5/P300 event and C6/P400 recovery only.
    observed_caps = [(r['phase'], float(r['action']['power_cap_w'])) for r in report['power_cap_observations']['transitions']]
    checks = {'episode_matches': report['episode_id']=='azure_conversation:azure-001910',
              'fixed_1950_second_horizon': int(protocol['deadline_wall_ns'])-int(protocol['start_wall_ns'])==1950*10**9,
              'p300_policy': observed_caps==[('warmup',400.),('event',300.),('recovery',400.)],
              'c5_event_c6_recovery': protocol['event_batch_concurrency']==5 and protocol['recovery_batch_concurrency']==6,
              'original_release_recovery_boundaries': protocol['cohort_release_offset_s']==150 and protocol['recovery_start_offset_s']==450,
              'all_280_planned_jobs_count': batch['planned_jobs']==280 and sum(batch[k] for k in ('jobs_completed_on_time','jobs_completed_late','jobs_unfinished_or_failed'))==280}
    forecasts = predictions(models,features)
    return {'run':str(root), 'environment':report['environment'], 'checks':checks,
            'state_kind':'FINAL_LOG_TIMESTAMP_CUTOFF_RECONSTRUCTION', 'state':state,'features':features,
            'outcomes':{'batch':batch,'completed_at':timing['jobs_completed_by_offset'],
                        'service_and_deadline_pass_observed':report['service_and_deadline_pass_observed'],
                        'failed_service_phases':[k for k,v in report['phases'].items() if not v['observed_slo_safe']],
                        'recovery_completions_by_deadline':batch['jobs_completed_on_time']-event_jobs},
            'replayed_predictions':[score(p,batch,event_jobs,timing['last_completed_job_offset_s']) for p in forecasts]}


def analyze(source, target):
    models = {label:read_json(source/name)['models'] for label,name in
              (('original_three','FORECAST_MODELS.json'),('eight_identity','PHASE_FORECAST_MODELS.json'))}
    source_records = {label:read_json(source/name) for label,name in
              (('original_three','PRE_EVENT_FORECAST.json'),('eight_identity','PRE_EVENT_PHASE_FORECAST.json'))}
    source_receipts = {label:read_json(source/name) for label,name in
              (('original_three','FORECAST_WRITE_RECEIPT.json'),('eight_identity','PHASE_FORECAST_WRITE_RECEIPT.json'))}
    source_state = read_json(source/'PRE_EVENT_STATE.json')
    cases = {label:read_case(root,models) for label,root in (('source_p300',source),('target_p300',target))}
    source_checks = {}
    for family, record in source_records.items():
        source_checks[family+'_parameters_match_original_record'] = record['models']==models[family]
        original_features = ({'prompt_tokens_per_s':record['feature']['requested_prompt_tokens_per_s']}
                             if family=='original_three' else record['features'])
        recalculated = predictions({family:models[family]},original_features)
        source_checks[family+'_recorded_predictions_reproduce'] = record['predictions']==[
            {k:v for k,v in row.items() if k!='family'} for row in recalculated]
        source_checks[family+'_feature_values_match_timestamp_reconstruction'] = all(
            cases['source_p300']['features'][k]==value for k,value in original_features.items())
    source_checks['recorded_state_features_match_timestamp_reconstruction'] = features_from_state(source_state['state'])==cases['source_p300']['features']
    common = ('online_workload.jsonl','batch_jobs.jsonl','priority_gateway.py','cohort_phase_measurement.py',
              'cohort_phase_dispatch.py','first_text_admission_tools.py','replica_batch_limit_tools.py','online_queue_priority_tools.py','mamba_prefix_tools.py')
    file_comparisons = {name:filecmp.cmp(source/name,target/name,shallow=False) for name in common}
    complete = all(source_checks.values()) and all(file_comparisons.values()) and all(all(c['checks'].values()) for c in cases.values())
    return {'status':'CONVERSATION1910_FORECAST_TRANSFER_COMPLETE' if complete else 'CONVERSATION1910_FORECAST_TRANSFER_MISMATCH',
            'source_checks':source_checks,'same_input_and_policy_files':file_comparisons,'cases':cases,
            'models':models,'original_forecast_records':source_records,'original_forecast_receipts':source_receipts,
            'target_original_forecast_files_present':{name:(target/name).is_file() for name in ('PRE_EVENT_FORECAST.json','PRE_EVENT_PHASE_FORECAST.json')},
            'gpu_workload_run':False,'models_refitted':False,'new_prospective_validation_samples':0,
            'limitations':[
                'Target predictions are computed after seeing the completed run; they are not additional prospective measurements.',
                'Only scheduled metadata and timestamp comparisons at or before 145 s form the reconstructed state. File visibility to a live observer at that moment is not established.',
                'Pending original output quota is not remaining work. Later latency and generated-token totals do not enter prediction features.',
                'The same saved model coefficients are applied without refitting or threshold changes. Original source records and receipts remain separate.',
                'Both cases use event C5/P300 and recovery C6/P400; the P400 control is not a prediction target.',
                'Incomplete cohorts have no observed full-cohort endpoint or finish error. Recovery completions by the deadline are descriptive counts, not a capacity bound.',
                'One reused workload across environments does not establish cross-hardware accuracy, service safety or a delivery guarantee.']}


def report_text(result):
    def fmt(value):
        return 'NA' if value is None else f'{value:.3f}'
    lines = ['=== CONVERSATION1910_FORECAST_TRANSFER ===','STATUS='+result['status'],
             'SOURCE_CHECKS='+json.dumps(result['source_checks'],separators=(',',':')),
             'FILE_COMPARISONS='+json.dumps(result['same_input_and_policy_files'],separators=(',',':'))]
    for label,case in result['cases'].items():
        state = case['state']
        lines.append('CASE='+label+' '+case['run'])
        lines.append('CHECKS='+json.dumps(case['checks'],separators=(',',':')))
        lines.append('PREFIX='+json.dumps({'features':case['features'],'pending_count':state['pending_count'],
            'pending_ids_first8':[p['request_id'] for p in state['pending_requests'][:8]],
            'gateway_waiting':state['gateway']['latest_online_waiting'],'snapshot_age_s':state['gateway']['latest_sample_age_s']},separators=(',',':')))
        outcome = case['outcomes']
        lines.append('OUTCOME='+json.dumps({k:v for k,v in outcome.items() if k!='batch'},separators=(',',':')))
        lines.append('BATCH='+json.dumps({k:outcome['batch'][k] for k in ('planned_jobs','jobs_completed_on_time','jobs_completed_late','jobs_unfinished_or_failed')},separators=(',',':')))
        lines.append('family method event_jobs recovery_jobs_min predicted_finish_s slack_s optimistic_miss finish_error_s')
        for p in case['replayed_predictions']:
            lines.append(' '.join((p['family'],p['method'],fmt(p['predicted_event_jobs']),fmt(p['predicted_recovery_jobs_per_min']),
                fmt(p['predicted_finish_s']),fmt(p.get('predicted_slack_s')),str(p['optimistic_deadline_miss']),fmt(p['finish_error_s']))))
    lines.append('SOURCE_WRITE_OFFSETS='+json.dumps({k:v.get('write_finished_offset_s') for k,v in result['original_forecast_receipts'].items()}))
    lines.append('TARGET_ORIGINAL_FORECAST_FILES='+json.dumps(result['target_original_forecast_files_present']))
    lines.extend(result['limitations'])
    return '\n'.join(lines)+'\n'


def main():
    parser = argparse.ArgumentParser()
    for name in ('source','target','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    args = parser.parse_args()
    result = analyze(args.source,args.target)
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'REPORT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    text = report_text(result)
    (args.output/'REPORT.txt').write_text(text,encoding='utf-8')
    print(text,end='')
    return 0 if result['status']=='CONVERSATION1910_FORECAST_TRANSFER_COMPLETE' else 2


if __name__=='__main__':
    raise SystemExit(main())
