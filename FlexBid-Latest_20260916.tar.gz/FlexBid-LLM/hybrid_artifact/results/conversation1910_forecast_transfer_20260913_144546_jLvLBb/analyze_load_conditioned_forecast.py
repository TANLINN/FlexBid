"""Development comparison of mean and prompt-load-conditioned phase forecasts."""
import argparse
import csv
import json
import math
from pathlib import Path
from statistics import mean

FEATURE = 'requested_prompt_tokens_per_s'
METHODS = ('phase_mean', 'prompt_load_linear')
JOBS, RECOVERY_S, DEADLINE_S = 280, 450.0, 1950.0


def prefix_x(row):
    prefix = row['pre_event_features']
    if prefix['cutoff_s'] != 145 or prefix['recent']['interval_s'] != [85, 145]:
        raise ValueError('Expected the saved 85-145 s feature window')
    x = float(prefix['recent'][FEATURE])
    if not math.isfinite(x) or x < 0:
        raise ValueError('Invalid requested prompt-token rate')
    return x


def fit(rows, held_out, method):
    if method not in METHODS:
        raise ValueError('Unknown comparison method')
    train = [r for r in rows if r['episode_id'] != held_out]
    groups = []
    for episode in sorted({r['episode_id'] for r in train}):
        repeated = [r for r in train if r['episode_id'] == episode]
        if any(r['status'] != 'READ_COMPLETE' or
               r['later_outcomes_not_forecast_inputs']['recovery_jobs_per_min'] is None for r in repeated):
            raise ValueError('Incomplete training outcomes; complete-case filtering is not used')
        groups.append({
            'episode_id': episode, 'runs': [r['run'] for r in repeated],
            'x': mean(prefix_x(r) for r in repeated),
            'event_rate': mean(r['later_outcomes_not_forecast_inputs']['event_completed_jobs'] / 5 for r in repeated),
            'recovery_rate': mean(r['later_outcomes_not_forecast_inputs']['recovery_jobs_per_min'] for r in repeated),
        })
    if len(groups) < 2:
        raise ValueError('At least two other workload episodes are required')
    x_bar = mean(g['x'] for g in groups)
    spread = sum((g['x'] - x_bar) ** 2 for g in groups)
    if method == 'prompt_load_linear' and spread == 0:
        raise ValueError('Training workload feature has no variation')
    coefficients = {}
    for key in ('event_rate', 'recovery_rate'):
        y_bar = mean(g[key] for g in groups)
        slope = (sum((g['x'] - x_bar) * (g[key] - y_bar) for g in groups) / spread
                 if method == 'prompt_load_linear' else 0.0)
        coefficients[key] = {'intercept': y_bar - slope * x_bar, 'slope': slope}
    return {'method': method, 'training_episodes': groups, 'coefficients': coefficients,
            'training_x_min': min(g['x'] for g in groups),
            'training_x_max': max(g['x'] for g in groups),
            'training_workload_levels': len({g['x'] for g in groups}),
            'linear_residual_degrees_of_freedom_at_episode_level': len(groups) - 2
                if method == 'prompt_load_linear' else None}


def predict(model, x):
    rates = {key: values['intercept'] + values['slope'] * x
             for key, values in model['coefficients'].items()}
    event_jobs = rates['event_rate'] * 5
    prediction = {'x': x, 'predicted_event_jobs': event_jobs,
                  'predicted_recovery_jobs_per_min': rates['recovery_rate'],
                  'outside_training_x_range': not model['training_x_min'] <= x <= model['training_x_max']}
    if (not all(math.isfinite(v) for v in rates.values())
            or not 0 <= event_jobs < JOBS or rates['recovery_rate'] <= 0):
        return {**prediction, 'status': 'UNSUPPORTED_POINT_PREDICTION', 'predicted_finish_s': None}
    finish = RECOVERY_S + (JOBS - event_jobs) * 60 / rates['recovery_rate']
    return {**prediction, 'status': 'POINT_PREDICTION', 'predicted_finish_s': finish,
            'predicted_slack_s': DEADLINE_S - finish}


def score(prediction, observed):
    actual = observed['cohort_finish_s']
    result = {**prediction, 'actual_finish_s': actual,
              'actual_event_jobs': observed['event_completed_jobs'],
              'actual_recovery_jobs_per_min': observed['recovery_jobs_per_min'],
              'observed_batch': observed['batch']}
    if prediction['status'] != 'POINT_PREDICTION' or actual is None:
        return result
    # This decomposition uses outcomes after prediction and is not a second forecast.
    conditional_finish = RECOVERY_S + (JOBS - observed['event_completed_jobs']) * 60 / prediction['predicted_recovery_jobs_per_min']
    event_part = prediction['predicted_finish_s'] - conditional_finish
    recovery_part = conditional_finish - actual
    return {**result, 'status': 'SCORED', 'finish_error_s': prediction['predicted_finish_s'] - actual,
            'event_job_error': prediction['predicted_event_jobs'] - observed['event_completed_jobs'],
            'recovery_rate_error': prediction['predicted_recovery_jobs_per_min'] - observed['recovery_jobs_per_min'],
            'posthoc_event_progress_component_s': event_part,
            'posthoc_recovery_rate_component_s': recovery_part,
            'opposite_sign_error_components': event_part * recovery_part < 0}


def analyze(rows):
    if len({r['run'] for r in rows}) != len(rows) or any(r['status'] != 'READ_COMPLETE' for r in rows):
        raise ValueError('Expected distinct complete input records')
    output = []
    for method in METHODS:
        folds = []
        for episode in sorted({r['episode_id'] for r in rows}):
            model = fit(rows, episode, method)
            tests = []
            for row in (r for r in rows if r['episode_id'] == episode):
                prediction = predict(model, prefix_x(row))
                tests.append({'run': row['run'], **score(prediction, row['later_outcomes_not_forecast_inputs'])})
            fold = {'held_out_episode': episode, 'model': model, 'tests': tests}
            if all(t['status'] == 'SCORED' for t in tests):
                fold.update(mean_absolute_finish_error_s=mean(abs(t['finish_error_s']) for t in tests),
                            mean_signed_finish_error_s=mean(t['finish_error_s'] for t in tests),
                            mean_absolute_event_job_error=mean(abs(t['event_job_error']) for t in tests),
                            mean_absolute_recovery_rate_error=mean(abs(t['recovery_rate_error']) for t in tests),
                            mean_posthoc_event_progress_component_s=mean(t['posthoc_event_progress_component_s'] for t in tests),
                            mean_posthoc_recovery_rate_component_s=mean(t['posthoc_recovery_rate_component_s'] for t in tests))
            folds.append(fold)
        complete = all('mean_absolute_finish_error_s' in f for f in folds)
        output.append({'method': method, 'folds': folds,
                       'episode_weighted_mean_absolute_finish_error_s': mean(f['mean_absolute_finish_error_s'] for f in folds) if complete else None,
                       'episode_weighted_mean_absolute_event_job_error': mean(f['mean_absolute_event_job_error'] for f in folds) if complete else None,
                       'maximum_optimistic_finish_error_s': max(0, max(-t['finish_error_s'] for f in folds for t in f['tests'])) if complete else None})
    return {'status': 'LOAD_CONDITIONED_FORECAST_ANALYSIS_COMPLETE', 'run_count': len(rows),
            'episode_count': len({r['episode_id'] for r in rows}), 'comparison': output,
            'method': {
                'feature': '85-145 s scheduled requested prompt tokens / 60 s',
                'candidate': 'Separate affine event and recovery rate functions of one prompt-load feature; no parameter or feature grid search.',
                'training': 'Exclude all runs of the held-out episode; fit across equally weighted training-episode means.',
                'prediction': 'Known 280-job cohort and fixed 150/450/1950 s schedule; each test run supplies only its own pre-event feature.',
                'units': 'Prompt tokens/s is requested replay input, not measured GPU work. Rates are whole-job completions/min.',
            },
            'limitations': [
                'Exploratory feature choice after inspecting these development outcomes. Leave-one-episode-out refitting does not make this independent validation.',
                'Only three distinct workload profiles; each linear fold fits two parameters to two training workload levels, with zero residual degrees of freedom.',
                'The lowest and highest load profiles are extrapolations when held out. Prediction intervals or safe capacity bounds are not established.',
                'Signed event and recovery errors may offset. A small final completion error is not evidence of accurate phase predictions.',
                'Nine observed on-time cohorts do not test admission rejection, online-SLO prediction, or infeasible workload detection.',
                'The method does not quantify unobserved future load changes and is not validated for the 300 s in-flight activation protocol.',
                'Pre-event observations are reconstructed offline; no live reading, offer rule, model deployment or GPU measurement is performed.',
            ]}


def save(output, result):
    output.mkdir(parents=True, exist_ok=True)
    (output / 'REPORT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    columns = ['method', 'episode_id', 'run', 'status', 'x', 'outside_training_x_range',
               'predicted_finish_s', 'actual_finish_s', 'finish_error_s', 'event_job_error',
               'recovery_rate_error', 'posthoc_event_progress_component_s', 'posthoc_recovery_rate_component_s']
    with (output / 'predictions.csv').open('w', encoding='utf-8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        for method in result['comparison']:
            for fold in method['folds']:
                for test in fold['tests']:
                    writer.writerow({'method': method['method'], 'episode_id': fold['held_out_episode'], **test})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8'))
    result = analyze(data['runs'])
    result['source'] = str(args.input)
    result['source_server_output'] = data.get('server_output')
    save(args.output, result)
    print('STATUS=' + result['status'])
    for model in result['comparison']:
        print(json.dumps({k: v for k, v in model.items() if k != 'folds'}))
        for fold in model['folds']:
            print(json.dumps({k: v for k, v in fold.items() if k not in ('model', 'tests')}))
    print('REPORT_JSON=' + str(args.output / 'REPORT.json'))


if __name__ == '__main__':
    main()
