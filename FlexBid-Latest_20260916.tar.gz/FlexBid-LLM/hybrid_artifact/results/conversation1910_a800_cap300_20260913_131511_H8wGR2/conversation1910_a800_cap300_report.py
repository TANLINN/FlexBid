"""Report the event-P300 measurement against the saved 001910 P400 control."""
import csv
import filecmp
import io
import json

import cohort_phase_measurement as m
from conversation1910_p400_report import TIMING_FIELDS, completion_summary
from conversation_quartile_power import paired_power_comparison
from mamba512_cohort_report import analyze_cell as measured_cell, DISPLAY_PHASES, PROGRAMS


def environment_summary(value):
    inventory = value.get('gpu_inventory', {})
    rows = list(csv.reader(io.StringIO(inventory.get('stdout', ''))))
    gpu_rows = [[s.strip() for s in row[:4]] for row in rows if len(row) >= 4]
    return {'gpu_index_model_memory_driver': gpu_rows if inventory.get('returncode') == 0 and gpu_rows else None,
            'python': value.get('python'), 'packages': value.get('packages'), 'torch_cuda': value.get('torch_cuda'),
            'platform': value.get('platform'), 'migration_record_directory': value.get('migration_record_directory')}


def compare(output, config, source, current):
    import yaml
    previous = m.read_json(source / 'REPORT.json')
    protocols = [m.read_json(p / 'protocol.json') for p in (output, source)]
    previous_config = yaml.safe_load((source / 'config.yaml').read_text(encoding='utf-8'))
    helpers = PROGRAMS + ('cohort_phase_measurement.py', 'cohort_phase_dispatch.py', 'mamba_prefix_tools.py')
    checks = {
        'same_episode': current['episode_id'] == previous['episode_id'] == 'azure_conversation:azure-001910',
        'same_relative_timeline': all(protocols[0][k] == protocols[1][k] for k in TIMING_FIELDS),
        'same_service_configuration': m.normalized_configuration(config) == m.normalized_configuration(previous_config),
        'same_gateway_helpers_and_request_execution': all(filecmp.cmp(output / name, source / name, shallow=False) for name in helpers),
        'same_saved_inputs': all(filecmp.cmp(output / name, source / name, shallow=False) for name in ('online_workload.jsonl', 'batch_jobs.jsonl')),
        'requested_cap_difference_observed': all(
            [(r['phase'], float(r['action']['power_cap_w'])) for r in row['power_cap_observations']['transitions']]
            == [('warmup', 400.), ('event', cap), ('recovery', 400.)]
            and row['checks']['configured_gpu_caps_matched'] for row, cap in ((current, 300.), (previous, 400.))),
    }
    fields = ('run', 'episode_id', 'online_requests', 'online_incomplete_or_error_count', 'phases',
              'checks', 'failed_checks', 'batch', 'cohort_timing', 'gpu_power',
              'service_and_deadline_pass_observed', 'all_main_phases_and_deadline_pass_observed',
              'all_recovery_subphases_and_deadline_pass_observed', 'environment')
    records = {'p400': previous, 'event_p300': current}
    environments = {label: environment_summary(row['environment']) for label, row in records.items()}
    environment_fields = {key: environments['p400'][key] is not None and environments['event_p300'][key] is not None
                          and environments['p400'][key] == environments['event_p300'][key] for key in environments['p400']}
    outcomes = {label: completion_summary(row) for label, row in records.items()}
    a, b = (outcomes[label]['all_job_finish_s'] for label in ('p400', 'event_p300'))
    return {'p400_run': str(source), 'p300_run': str(output), 'checks': checks,
            'same_workload_and_policy_except_cap': all(checks.values()),
            'recorded_environment_fields_match': environment_fields, 'environments': environments,
            'conditions': {label: {key: row[key] for key in fields} for label, row in records.items()},
            'cohort_outcomes': outcomes, 'p300_minus_p400_all_job_finish_s': b - a if a is not None and b is not None else None,
            'paired_power': paired_power_comparison(source, output),
            'limitations': [
                'One saved P400 run and one later P300 run; matching recorded hardware/software fields does not establish physical-device identity or remove run-order variation.',
                'The original 280-job deadline and all service phases are retained. Warmup failure is not removed after observing its timing.',
                'Full-cohort completion remains unknown when any planned job is unfinished; a successful-subset endpoint is reported separately.',
                'Fixed-horizon power differences may include different completed work; they are not equal-work energy efficiency or an offered wattage.',
                'This fixed-policy development comparison does not validate a forecast, adaptive offer, or cross-hardware algorithm advantage.']}


def analyze_cell(output, config, policy_run, event_cap):
    result = measured_cell(output, config, policy_run, event_cap)
    result['status'] = 'CONVERSATION1910_A800_CAP300_MEASURED'
    result['limitations'][0] = 'Conversation 001910: event C5/P300 and recovery C6/P400, with the saved P400 control.'
    result['limitations'][1] = 'The current environment is recorded; compare it with the saved control before interpreting a within-environment effect.'
    m.write_json(output / 'P300_CELL_REPORT.json', result)
    try:
        pair = compare(output, config, policy_run, result)
        m.write_json(output / 'PAIR_REPORT.json', pair)
        result['power_comparison'] = pair
    except Exception as exc:
        error = {'error_type': type(exc).__name__, 'error': str(exc), 'raw_measurement_completed': True}
        m.write_json(output / 'PAIR_ANALYSIS_FAILED.json', error)
        result['pair_analysis_error'] = error
    return result


def cell_text(result):
    def fmt(x):
        return 'NA' if x is None else f'{x:.3f}'
    lines = ['=== CONVERSATION1910_A800_CAP300_RESULT ===', 'STATUS=' + result['status'],
             'FAILED_CHECKS=' + json.dumps(result['failed_checks']),
             'SERVICE_AND_DEADLINE_PASS=' + str(result['service_and_deadline_pass_observed'])]
    pair = result.get('power_comparison')
    records = pair['conditions'] if pair else {'event_p300': result}
    for label, row in records.items():
        lines.append('RUN=' + label + ' ' + row['run'])
        lines.append('ONLINE=' + json.dumps({'requests': row['online_requests'], 'errors_or_incomplete': row['online_incomplete_or_error_count']}))
        lines.append('COHORT=' + json.dumps(completion_summary(row), separators=(',', ':')))
        lines.append('COMPLETED_AT=' + json.dumps(row['cohort_timing']['jobs_completed_by_offset'], separators=(',', ':')))
        lines.append('phase requests TTFT_p95_ms mean_stream_gap_p99_ms errors safe')
        for name in DISPLAY_PHASES:
            p = row['phases'][name]
            lines.append(' '.join((name, str(p['requests']), fmt(p['ttft_p95_ms']), fmt(p['request_mean_stream_gap_p99_ms']), str(p['errors']), str(p['observed_slo_safe']))))
    if pair:
        lines.append('PAIR_CHECKS=' + json.dumps(pair['checks'], separators=(',', ':')))
        lines.append('ENVIRONMENT_FIELDS_MATCH=' + json.dumps(pair['recorded_environment_fields_match'], separators=(',', ':')))
        for label, env in pair['environments'].items():
            lines.append('ENVIRONMENT=' + label + ' ' + json.dumps(env, separators=(',', ':')))
        power = pair['paired_power']
        lines.append('window P400_minus_P300_W covered')
        for row in power['event_30s_windows']:
            lines.append(f"{row['window']} {fmt(row['paired_reduction_w'])} {row['reference']['covered'] and row['treatment']['covered']}")
        lines.append('POWER=' + json.dumps({'minimum_window_reduction_w': power['minimum_paired_window_reduction_w'],
            'all_windows_positive': power['all_paired_event_windows_positive'],
            'stages': {label: {k: row[k] for k in ('paired_reduction_w', 'energy_saved_wh')} for label, row in power['stages'].items()}}, separators=(',', ':')))
        lines.extend(pair['limitations'])
    else:
        lines.append('PAIR_ANALYSIS_ERROR=' + json.dumps(result.get('pair_analysis_error')))
    lines.append('Full measurements, environment records and window details are retained in REPORT.json and PAIR_REPORT.json when available.')
    return '\n'.join(lines) + '\n'
