"""Compare the measured 001910 P400 control with its saved event-P300 run."""
import filecmp
import json

import cohort_phase_measurement as m
from conversation_quartile_power import paired_power_comparison
from mamba512_cohort_report import analyze_cell as measured_cell, cell_text as measured_text, PROGRAMS

TIMING_FIELDS = ('duration_s', 'drain_s', 'cohort_release_offset_s', 'batch_admission_offset_s',
                'event_batch_concurrency', 'recovery_batch_concurrency', 'recovery_start_offset_s')


def completion_summary(record):
    batch, timing = record['batch'], record['cohort_timing']
    completed = batch['jobs_completed_on_time'] + batch['jobs_completed_late']
    full_finish = timing['last_completed_job_offset_s'] if completed == batch['planned_jobs'] else None
    return {'planned_jobs': batch['planned_jobs'], 'jobs_completed_on_time': batch['jobs_completed_on_time'],
            'jobs_completed_late': batch['jobs_completed_late'],
            'jobs_unfinished_or_failed': batch['jobs_unfinished_or_failed'],
            'all_job_finish_s': full_finish,
            'all_job_completion_slack_s': 1950 - full_finish if full_finish is not None else None,
            'last_observed_success_s': timing['last_completed_job_offset_s']}


def compare(output, config, source, current):
    import yaml
    previous = m.read_json(source / 'REPORT.json')
    protocols = [m.read_json(p / 'protocol.json') for p in (output, source)]
    source_config = yaml.safe_load((source / 'config.yaml').read_text(encoding='utf-8'))
    helpers = PROGRAMS + ('cohort_phase_measurement.py', 'cohort_phase_dispatch.py', 'mamba_prefix_tools.py')
    checks = {
        'same_episode': current['episode_id'] == previous['episode_id'] == 'azure_conversation:azure-001910',
        'same_relative_timeline': all(protocols[0][k] == protocols[1][k] for k in TIMING_FIELDS),
        'same_service_configuration': m.normalized_configuration(config) == m.normalized_configuration(source_config),
        'same_gateway_helpers_and_request_execution': all(filecmp.cmp(output / name, source / name, shallow=False) for name in helpers),
        'same_saved_inputs': all(filecmp.cmp(output / name, source / name, shallow=False)
                                 for name in ('online_workload.jsonl', 'batch_jobs.jsonl')),
        'requested_cap_difference_observed': all(
            [(r['phase'], float(r['action']['power_cap_w'])) for r in row['power_cap_observations']['transitions']]
            == [('warmup', 400.), ('event', cap), ('recovery', 400.)]
            and row['checks']['configured_gpu_caps_matched'] for row, cap in ((current, 400.), (previous, 300.))),
    }
    power = paired_power_comparison(output, source)
    fields = ('run', 'episode_id', 'online_requests', 'online_incomplete_or_error_count', 'phases',
              'checks', 'failed_checks', 'batch', 'cohort_timing', 'gpu_power',
              'service_and_deadline_pass_observed', 'all_main_phases_and_deadline_pass_observed',
              'all_recovery_subphases_and_deadline_pass_observed', 'environment')
    completions = {name: completion_summary(row) for name, row in (('p400', current), ('event_p300', previous))}
    a, b = (completions[name]['all_job_finish_s'] for name in ('p400', 'event_p300'))
    return {'episode_id': current['episode_id'], 'p400_run': str(output), 'p300_run': str(source),
            'checks': checks, 'comparison_interpretable': all(checks.values()),
            'conditions': {name: {k: r[k] for k in fields} for name, r in (('p400', current), ('event_p300', previous))},
            'cohort_outcomes': completions,
            'p300_minus_p400_all_job_finish_s': b - a if a is not None and b is not None else None,
            'paired_power': power,
            'limitations': [
                '001910 was selected after its event-P300 run completed 260 of 280 jobs on time, with six late and fourteen not started; this is targeted development evidence.',
                'One saved P300 run and one later P400 control do not separate cap effects from run-order, host or execution variation. Both environment records are retained.',
                'The complete 280-job cohort and original 1950-second deadline remain unchanged; late, missing and failed jobs are retained.',
                'Last successful completion is not an all-job finish if any planned job failed or is missing; interpret it together with cohort counts.',
                'Fixed-horizon energy may include different completed work. Power differences alone do not establish equal-work efficiency or joint delivery.',
                'Warmup and recovery subphase failures remain visible even when aggregate service passes.',
                'This fixed-policy control does not evaluate a forecast, adaptive offer or capacity guarantee.']}


def analyze_cell(output, config, policy_run, event_cap):
    result = measured_cell(output, config, policy_run, event_cap)
    result['status'] = 'CONVERSATION1910_P400_MEASURED'
    result['limitations'][0] = 'Conversation 001910: uncached chunk512, twelve online slots, C5 event and C6 recovery, P400 throughout.'
    result['limitations'][1] = 'The comparison reuses the saved event-P300 run of the same workload; environment and run-order variation remain.'
    # Save the completed measurement independently of paired-analysis availability.
    m.write_json(output / 'P400_CELL_REPORT.json', result)
    try:
        pair = compare(output, config, policy_run, result)
        m.write_json(output / 'PAIR_REPORT.json', pair)
        result['p400_comparison'] = pair
    except Exception as exc:
        error = {'error_type': type(exc).__name__, 'error': str(exc), 'raw_measurement_completed': True}
        m.write_json(output / 'PAIR_ANALYSIS_FAILED.json', error)
        result['pair_analysis_error'] = error
    return result


def cell_text(result):
    text = measured_text(result).replace('=== MAMBA512_COHORT_RESULT ===', '=== CONVERSATION1910_P400_RESULT ===')
    if 'pair_analysis_error' in result:
        return text + 'PAIR_ANALYSIS_ERROR=' + json.dumps(result['pair_analysis_error']) + '\n'
    pair = result['p400_comparison']
    lines = ['=== CONVERSATION1910_POWER_PAIR ===', 'PAIR_CHECKS=' + json.dumps(pair['checks']),
             'COMPARISON_INTERPRETABLE=' + str(pair['comparison_interpretable'])]
    for name, row in pair['conditions'].items():
        lines.append('CONDITION_RESULT=' + json.dumps({'condition': name, **row}, ensure_ascii=False))
    lines.append('COHORT_OUTCOMES=' + json.dumps(pair['cohort_outcomes']))
    lines.append('P300_MINUS_P400_ALL_JOB_FINISH_S=' + json.dumps(pair['p300_minus_p400_all_job_finish_s']))
    for row in pair['paired_power']['event_30s_windows']:
        lines.append('PAIRED_EVENT_WINDOW=' + json.dumps(row))
    lines.append('PAIRED_POWER_SUMMARY=' + json.dumps({k: v for k, v in pair['paired_power'].items() if k != 'event_30s_windows'}))
    lines.extend(pair['limitations'])
    return text + '\n'.join(lines) + '\n'
