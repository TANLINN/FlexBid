"""Bound batch occupancy while retaining first-text admission isolation."""
import ast
from collections import Counter
from pathlib import Path


def limited_gateway_source(source):
    tree = ast.parse(source)
    state = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'State')
    choose = next(node for node in state.body if isinstance(node, ast.AsyncFunctionDef) and node.name == 'choose')
    assignments = [node for node in ast.walk(choose) if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == 'ready' for target in node.targets)]
    if len(assignments) != 1 or not isinstance(assignments[0].value, ast.ListComp):
        raise ValueError('Expected the saved first-text gateway ready-replica comprehension')
    generators = assignments[0].value.generators
    if len(generators) != 1 or not isinstance(generators[0].target, ast.Name):
        raise ValueError('Expected one replica variable in the ready-replica comprehension')
    variable = generators[0].target.id
    condition = ast.parse("request_class != 'batch' or self.inflight_batch[" + variable + "] < 2", mode='eval').body
    generators[0].ifs.append(condition)
    ast.fix_missing_locations(tree)
    code = ast.unparse(tree) + '\n'
    ast.parse(code, feature_version=(3, 10))
    return code


def apply_replica_batch_limit(path):
    path = Path(path)
    path.write_text(limited_gateway_source(path.read_text(encoding='utf-8')), encoding='utf-8')


def occupancy_summary(records, states):
    batch = [row for row in records if row['class'] == 'batch']
    admissions = Counter(int(row['inflight_after_selection']['batch'][int(row['replica'])]) for row in batch)
    state_counts = [list(map(int, row['inflight_batch'])) for row in states]
    admission_maximum = max((max(row['inflight_after_selection']['batch']) for row in records), default=None)
    state_maximum = max((max(counts) for counts in state_counts), default=None)
    return {
        'batch_admissions': len(batch),
        'selected_replica_batch_counts_after_admission': dict(sorted(admissions.items())),
        'maximum_batch_per_replica_at_admissions': admission_maximum,
        'maximum_batch_per_replica_at_snapshots': state_maximum,
        'batch_admissions_over_two': sum(count for occupied, count in admissions.items() if occupied > 2),
        'snapshots': len(states),
        'snapshots_with_batch_three_or_more_on_one_replica': sum(max(counts) >= 3 for counts in state_counts),
        'active_batch_replicas_at_snapshots': dict(sorted(Counter(sum(count > 0 for count in counts) for counts in state_counts).items())),
        'maximum_sampled_batch_waiting': max((row['batch_waiting'] for row in states), default=None),
        'maximum_sampled_online_waiting': max((row['online_waiting'] for row in states), default=None),
        'scope': 'Gateway occupancy at admissions and periodic snapshots; not engine execution or exact occupancy durations.'
    }
