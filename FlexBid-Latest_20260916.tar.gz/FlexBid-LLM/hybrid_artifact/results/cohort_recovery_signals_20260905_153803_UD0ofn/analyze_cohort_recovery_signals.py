"""Analyze recorded request pairs and pre-dispatch state without running workloads."""
from __future__ import annotations

import argparse
from bisect import bisect_left
import csv
import json
import math
from pathlib import Path


RUNS = {
    "reference_c4": "no_curtailment_cohort_20260905_111513_P3RcIv",
    "recovery_c4": "pause_recover_cohort_20260905_135452_JkUvyg",
    "recovery_c5": "c5_recovery_cohort_20260905_144747_k4MroY",
}
RECOVERY_START_MS = 450_000
END_MS = 1_950_000


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_rows(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    position = (len(values) - 1) * q
    left = int(position)
    fraction = position - left
    return values[left] * (1 - fraction) + values[min(left + 1, len(values) - 1)] * fraction


def latency(row):
    value = row.get("mean_tpot_ms")
    return float(value) if row.get("error") is None and value is not None else None


def active_before(rows, stamp, exclude=None):
    return [row for row in rows
            if row.get("request_id", row.get("job_id")) != exclude
            and row.get("dispatch_wall_time_ns") is not None
            and int(row["dispatch_wall_time_ns"]) < stamp
            and (row.get("completion_wall_time_ns") is None
                 or int(row["completion_wall_time_ns"]) >= stamp)]


def state_before(online, batch, states, state_times, stamp, exclude=None):
    """Features use only starts, completions and snapshots preceding this decision."""
    active_online = active_before(online, stamp, exclude)
    active_batch = active_before(batch, stamp)
    ages = [(stamp - int(row["dispatch_wall_time_ns"])) / 1e9 for row in active_batch]
    prompts = [int(row["prompt_tokens"]) for row in active_online]
    previous = bisect_left(state_times, stamp) - 1
    snapshot = states[previous] if previous >= 0 else None
    features = {
        "client_online_inflight_before": len(active_online),
        "client_batch_inflight_before": len(active_batch),
        "known_active_online_prompt_max": max(prompts, default=0),
        "known_active_online_prompt_sum": sum(prompts),
        "oldest_inflight_batch_age_s": max(ages, default=None),
        "youngest_inflight_batch_age_s": min(ages, default=None),
        "batch_starts_in_previous_5s": sum(
            row.get("dispatch_wall_time_ns") is not None
            and stamp - 5_000_000_000 <= int(row["dispatch_wall_time_ns"]) < stamp
            for row in batch),
        "snapshot_age_s": (stamp - int(snapshot["wall_time_ns"])) / 1e9 if snapshot else None,
        "gateway_online_inflight": sum(snapshot["inflight_online"]) if snapshot else None,
        "gateway_batch_inflight": sum(snapshot["inflight_batch"]) if snapshot else None,
        "gateway_online_waiting": int(snapshot["online_waiting"]) if snapshot else None,
        "replicas_with_multiple_batch": sum(int(x) >= 2 for x in snapshot["inflight_batch"])
        if snapshot else None,
    }
    return features


def load_run(folder):
    protocol, report = read_json(folder / "protocol.json"), read_json(folder / "REPORT.json")
    online, batch = read_rows(folder / "online.jsonl"), read_rows(folder / "batch.jsonl")
    states = sorted(read_rows(folder / "gateway_state.jsonl"), key=lambda row: int(row["wall_time_ns"]))
    times = [int(row["wall_time_ns"]) for row in states]
    if len({row["request_id"] for row in online}) != len(online):
        raise ValueError(f"duplicate online request IDs: {folder}")
    recovery = [row for row in online if RECOVERY_START_MS <= float(row["arrival_ms"]) < END_MS]
    scores = [latency(row) for row in recovery if latency(row) is not None]
    slo = float(report["slos"]["request_mean_stream_gap_p99_ms"])
    replay = {"requests": len(recovery), "request_mean_stream_gap_samples": len(scores),
              "request_mean_stream_gap_p99_ms": quantile(scores, .99),
              "requests_with_mean_stream_gap_over_slo": sum(value > slo for value in scores)}
    saved = report["online_recovery_reference"]
    for key, value in replay.items():
        if value is None or not math.isclose(float(value), float(saved[key]), rel_tol=1e-10, abs_tol=1e-6):
            raise ValueError(f"saved recovery report differs for {folder.name}: {key}: {value} vs {saved[key]}")
    return {"folder": folder, "protocol": protocol, "online": online, "batch": batch,
            "states": states, "state_times": times, "recovery": recovery,
            "slo_ms": slo, "replay": replay}


def prompt_bin(value):
    if value <= 2048:
        return "0-2048"
    if value <= 8192:
        return "2049-8192"
    return "8193+"


def online_records(data, name):
    results = []
    for row in data["recovery"]:
        stamp = row.get("dispatch_wall_time_ns")
        value = latency(row)
        result = {
            "run": name, "request_id": row["request_id"],
            "arrival_s": float(row["arrival_ms"]) / 1000,
            "prompt_tokens": int(row["prompt_tokens"]), "max_output_tokens": int(row["max_output_tokens"]),
            "parent_request_id": row.get("parent_request_id"), "tool_delay_ms": row.get("tool_delay_ms"),
            "request_mean_gap_ms": value, "ttft_ms": row.get("ttft_ms"),
            "tail_over_slo": value > data["slo_ms"] if value is not None else None,
        }
        if stamp is not None:
            result.update(state_before(data["online"], data["batch"], data["states"],
                                       data["state_times"], int(stamp), row["request_id"]))
        results.append(result)
    return results


def batch_records(data, name):
    """Keep future outcome labels separate from features available at batch admission."""
    result = []
    start = int(data["protocol"]["start_wall_ns"])
    for row in data["batch"]:
        stamp = row.get("dispatch_wall_time_ns")
        if stamp is None or not start + 450_000_000_000 <= int(stamp) < start + 1_950_000_000_000:
            continue
        stamp = int(stamp)
        active = active_before(data["online"], stamp)
        following = [item for item in data["online"] if item.get("dispatch_wall_time_ns") is not None
                     and stamp <= int(item["dispatch_wall_time_ns"]) < stamp + 30_000_000_000]
        active_tail = sum(latency(item) is not None and latency(item) > data["slo_ms"] for item in active)
        future_tail = sum(latency(item) is not None and latency(item) > data["slo_ms"] for item in following)
        end = row.get("completion_wall_time_ns")
        result.append({"run": name, "job_id": row["job_id"], "dispatch_offset_s": (stamp - start) / 1e9,
                       **state_before(data["online"], data["batch"], data["states"], data["state_times"], stamp),
                       "label_active_online_later_over_slo": active_tail,
                       "label_next_30s_online_requests": len(following),
                       "label_next_30s_tail_requests": future_tail,
                       "label_followup_coverage_s": min(30.0, (start + END_MS * 1_000_000 - stamp) / 1e9),
                       "label_batch_duration_s": (int(end) - stamp) / 1e9 if end is not None else None})
    return result


def strata(records, key, label="tail_over_slo"):
    groups = {}
    for row in records:
        value = prompt_bin(row["prompt_tokens"]) if key == "prompt_bin" else row.get(key)
        if row.get(label) is not None:
            groups.setdefault(str(value), []).append(row)
    return [{"group": value, "n": len(rows),
             "positive_labels": sum(bool(row[label]) for row in rows),
             "positive_fraction": sum(bool(row[label]) for row in rows) / len(rows)}
            for value, rows in sorted(groups.items())]


def write_csv(path, rows):
    columns = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def analyze(project, output):
    loaded = {name: load_run(project / "results" / folder) for name, folder in RUNS.items()}
    online = {name: online_records(data, name) for name, data in loaded.items()}
    batch = {name: batch_records(data, name) for name, data in loaded.items()}
    maps = {name: {row["request_id"]: row for row in rows} for name, rows in online.items()}
    id_sets = {name: set(rows) for name, rows in maps.items()}
    common = set.intersection(*id_sets.values())
    tail_ids = {name: {row["request_id"] for row in rows if row["tail_over_slo"]} for name, rows in online.items()}
    matched = []
    mismatched = []
    for rid in sorted(common):
        rows = {name: mapping[rid] for name, mapping in maps.items()}
        metadata = ("arrival_s", "prompt_tokens", "max_output_tokens", "parent_request_id", "tool_delay_ms")
        if any(rows[name][key] != rows["reference_c4"][key] for name in rows for key in metadata):
            mismatched.append(rid)
        entry = {"request_id": rid, **{key: rows["reference_c4"][key] for key in metadata}}
        for name, row in rows.items():
            for key, value in row.items():
                if key not in ("run", "request_id", *metadata):
                    entry[name + "_" + key] = value
        matched.append(entry)
    c5_tail = [row for row in online["recovery_c5"] if row["tail_over_slo"]]
    tail_details = []
    for row in sorted(c5_tail, key=lambda value: -value["request_mean_gap_ms"]):
        rid = row["request_id"]
        tail_details.append({
            "request_id": rid, "arrival_s": row["arrival_s"], "prompt_tokens": row["prompt_tokens"],
            "max_output_tokens": row["max_output_tokens"],
            "gap_ms_by_run": {name: mapping[rid]["request_mean_gap_ms"] if rid in mapping else None
                              for name, mapping in maps.items()},
            "before_c5_online_dispatch": {key: row.get(key) for key in (
                "client_online_inflight_before", "client_batch_inflight_before", "oldest_inflight_batch_age_s",
                "youngest_inflight_batch_age_s", "batch_starts_in_previous_5s", "snapshot_age_s",
                "gateway_online_waiting", "replicas_with_multiple_batch")},
        })
    report = {
        "status": "COHORT_RECOVERY_SIGNALS_ANALYZED", "gpu_workload_run": False,
        "source_runs": {name: str(data["folder"]) for name, data in loaded.items()},
        "replayed_recovery_metrics": {name: data["replay"] for name, data in loaded.items()},
        "slo_ms_by_run": {name: data["slo_ms"] for name, data in loaded.items()},
        "matched_request_count": len(common),
        "unmatched_requests_by_run": {name: len(ids - common) for name, ids in id_sets.items()},
        "matched_metadata_difference_count": len(mismatched),
        "tail_request_overlap": {
            "counts": {name: len(ids) for name, ids in tail_ids.items()},
            "c5_tail_also_reference_tail": len(tail_ids["recovery_c5"] & tail_ids["reference_c4"]),
            "c5_tail_also_c4_recovery_tail": len(tail_ids["recovery_c5"] & tail_ids["recovery_c4"]),
            "c5_tail_below_or_equal_slo_in_both_other_runs": sum(
                row["request_id"] in common and all(
                    maps[name][row["request_id"]]["request_mean_gap_ms"] is not None
                    and maps[name][row["request_id"]]["request_mean_gap_ms"] <= loaded[name]["slo_ms"]
                    for name in ("reference_c4", "recovery_c4")) for row in c5_tail),
        },
        "online_request_strata": {
            name: {key: strata(rows, key) for key in
                   ("prompt_bin", "client_online_inflight_before", "batch_starts_in_previous_5s")}
            for name, rows in online.items()},
        "batch_admission_strata": {
            name: {key: strata([row for row in rows if row["label_followup_coverage_s"] == 30.0],
                               key, "label_next_30s_tail_requests") for key in
                   ("client_online_inflight_before", "gateway_online_waiting")}
            for name, rows in batch.items()},
        "batch_admissions_without_full_30s_followup": {
            name: sum(row["label_followup_coverage_s"] < 30.0 for row in rows) for name, rows in batch.items()},
        "c5_tail_requests": tail_details,
        "limitations": [
            "Associations on reused development data are not causal effects or independent validation.",
            "Online-dispatch features are not necessarily known at earlier batch admission.",
            "Batch labels use future outcomes for retrospective analysis only; their 30 s windows overlap.",
            "Admissions within 30 s of workload end are retained in CSV but excluded from follow-up strata.",
            "Client in-flight ages do not identify GPU prefill/decode phases or remaining execution time.",
            "Gateway snapshots precede dispatch but may be stale; snapshot age is recorded.",
            "No counterfactual dynamic-policy performance is estimated from the static traces.",
        ],
    }
    write_csv(output / "MATCHED_REQUESTS.csv", matched)
    write_csv(output / "BATCH_ADMISSIONS.csv", [row for rows in batch.values() for row in rows])
    (output / "REPORT.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    lines = ["=== COHORT_RECOVERY_SIGNALS ==="]
    compact = {key: report[key] for key in ("status", "gpu_workload_run", "matched_request_count",
                                           "unmatched_requests_by_run", "matched_metadata_difference_count",
                                           "slo_ms_by_run", "tail_request_overlap")}
    lines.append(json.dumps(compact, ensure_ascii=False))
    for name in loaded:
        lines += ["=== " + name + " ===", json.dumps(report["replayed_recovery_metrics"][name])]
        for key, groups in report["online_request_strata"][name].items():
            lines.append(json.dumps({"online_group": key, "groups": groups}))
        for key, groups in report["batch_admission_strata"][name].items():
            lines.append(json.dumps({"batch_group": key, "outcome": "at least one tail request dispatched in following 30 s",
                                     "groups": groups}))
        lines.append(json.dumps({"batch_admissions_without_full_30s_followup":
                                 report["batch_admissions_without_full_30s_followup"][name]}))
    lines.append("=== C5_TAIL_REQUESTS ===")
    lines += [json.dumps(row, ensure_ascii=False) for row in tail_details[:50]]
    lines.append(json.dumps({"tail_rows_printed": min(50, len(tail_details)), "tail_rows_total": len(tail_details)}))
    lines.append("=== LIMITATIONS ===")
    lines += report["limitations"]
    lines.append("REPORT_JSON=" + str(output / "REPORT.json"))
    text = "\n".join(lines) + "\n"
    (output / "REPORT.txt").write_text(text, encoding="utf-8")
    return text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    try:
        print(analyze(args.project, args.output), end="")
    except Exception as exc:
        message = {"status": "ANALYSIS_ERROR", "error_type": type(exc).__name__, "error": str(exc)}
        (args.output / "REPORT.txt").write_text(json.dumps(message, ensure_ascii=False) + "\n", encoding="utf-8")
        raise


if __name__ == "__main__":
    main()
