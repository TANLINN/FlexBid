"""Action-specific one-step point models for saved-data diagnostics."""
from __future__ import annotations

from collections import Counter, defaultdict
import csv
import math

import numpy as np

FEATURES = (
    'x_online_active', 'x_online_waiting', 'x_batch_active_gateway', 'x_batch_waiting',
    'x_remaining_jobs', 'x_oldest_batch_dispatch_age_s', 'x_recent60_completed_jobs',
    'x_recent60_online_dispatches', 'x_recent60_prompt_mean', 'x_recent60_ttft_p95_ms',
    'x_recent60_gap_p99_ms', 'x_last_gpu_w',
)
TARGETS = ('y_mean_gpu_w', 'y_completed_jobs_next30', 'y_ttft_p95_ms', 'y_gap_p99_ms')
SERVICE_TARGETS = TARGETS[2:]
TEXT = {'run', 'episode_id', 'phase', 'group'}
BOOL = {'segment_action_constant', 'segment_has_remaining_demand', 'y_power_covered'}
RIDGE = 1.0


def finite(value):
    return value is not None and math.isfinite(float(value))


def load_windows(path):
    values = []
    with path.open(encoding='utf-8-sig', newline='') as stream:
        for row in csv.DictReader(stream):
            out = {}
            for k, v in row.items():
                if k in TEXT:
                    out[k] = v
                elif k in BOOL:
                    if v not in ('True', 'False'):
                        raise ValueError(f'Invalid boolean in {k}: {v!r}')
                    out[k] = v == 'True'
                else:
                    out[k] = float(v) if v else None
            values.append(out)
    seen = {(r['run'], r['start_s']) for r in values}
    if len(seen) != len(values):
        raise ValueError('Duplicate run/window keys')
    return values


def action_key(row):
    return (row['group'], row['phase'], float(row['x_p_w']), int(row['x_c']))


def base_eligible(row):
    return (row['segment_action_constant'] and row['segment_has_remaining_demand']
            and finite(row.get('x_p_w')) and finite(row.get('x_c')))


def eligible(row, target):
    if not base_eligible(row) or not finite(row.get(target)):
        return False
    if target == 'y_mean_gpu_w' and not row['y_power_covered']:
        return False
    if target in SERVICE_TARGETS:
        if row.get('service_labels_cross_transition') is not False:
            return False
        count = row['y_ttft_samples'] if target == 'y_ttft_p95_ms' else row['y_gap_samples']
        if not count or count <= 0:
            return False
    return True


def sample_weights(rows):
    """Equal identity mass, then equal run mass, then equal window mass."""
    count = Counter((r['episode_id'], r['run']) for r in rows)
    runs = defaultdict(set)
    for identity, run in count:
        runs[identity].add(run)
    return np.array([1 / (len(runs) * len(runs[r['episode_id']]) * count[(r['episode_id'], r['run'])]) for r in rows])


def design(rows, preprocessing):
    columns = [np.ones(len(rows))]
    for feature in preprocessing:
        raw = np.array([float(r[feature['name']]) if finite(r.get(feature['name'])) else np.nan for r in rows])
        missing = np.isnan(raw)
        filled = np.where(missing, feature['mean'], raw)
        columns.extend([(filled - feature['mean']) / feature['scale'], missing.astype(float)])
    return np.column_stack(columns)


def fit_one(rows, target):
    selected = [r for r in rows if eligible(r, target)]
    if not selected:
        return None
    weights = sample_weights(selected)
    preprocessing = []
    for name in FEATURES:
        valid = np.array([finite(r.get(name)) for r in selected])
        if not valid.any():
            continue
        numbers = np.array([float(r[name]) for r, yes in zip(selected, valid) if yes])
        w = weights[valid] / weights[valid].sum()
        mean = float(np.sum(w * numbers))
        scale = float(np.sqrt(np.sum(w * (numbers - mean) ** 2)))
        preprocessing.append({'name': name, 'mean': mean, 'scale': scale if scale > 1e-10 else 1.,
                              'min': float(numbers.min()), 'max': float(numbers.max())})
    matrix = design(selected, preprocessing)
    y = np.array([r[target] for r in selected])
    penalty = np.eye(matrix.shape[1]) * RIDGE
    penalty[0, 0] = 0.
    coefficients = np.linalg.solve(matrix.T @ (weights[:, None] * matrix) + penalty,
                                   matrix.T @ (weights * y))
    return {'target': target, 'features': preprocessing, 'coefficients': coefficients.tolist(),
            'training_identities': sorted({r['episode_id'] for r in selected}),
            'training_runs': sorted({r['run'] for r in selected}), 'training_rows': len(selected),
            'ridge': RIDGE}


def fit_models(rows):
    groups = defaultdict(list)
    for row in rows:
        if base_eligible(row):
            groups[action_key(row)].append(row)
    result = []
    for key, values in sorted(groups.items()):
        result.append({'key': list(key), 'targets': {target: fit_one(values, target) for target in TARGETS}})
    return result


def predict(models, row):
    key = action_key(row)
    selected = next((m for m in models if tuple(m['key']) == key), None)
    if selected is None:
        return {'status': 'NO_TRAINING_ACTION', 'values': {}, 'details': {}}
    values, details = {}, {}
    for target, model in selected['targets'].items():
        if model is None:
            details[target] = {'status': 'NO_TRAINING_LABELS'}
            continue
        point = max(0., float((design([row], model['features']) @ np.array(model['coefficients']))[0]))
        if target == 'y_completed_jobs_next30' and finite(row.get('x_remaining_jobs')):
            point = min(point, max(0., float(row['x_remaining_jobs'])))
        values[target] = point
        details[target] = {'status': 'POINT_PREDICTION',
                           'outside_training_range': [f['name'] for f in model['features'] if finite(row.get(f['name']))
                            and not f['min'] <= float(row[f['name']]) <= f['max']],
                           'missing_features': [f['name'] for f in model['features'] if not finite(row.get(f['name']))],
                           'training_identities': model['training_identities']}
    return {'status': 'POINT_PREDICTIONS_ONLY', 'values': values, 'details': details}


def validate_identities(rows):
    records, folds = [], []
    for identity in sorted({r['episode_id'] for r in rows}):
        training = [r for r in rows if r['episode_id'] != identity]
        test = [r for r in rows if r['episode_id'] == identity and base_eligible(r)]
        models = fit_models(training)
        folds.append({'held_out_identity': identity,
                      'training_identities': sorted({r['episode_id'] for r in training}),
                      'training_runs': sorted({r['run'] for r in training}),
                      'test_runs': sorted({r['run'] for r in test}), 'test_windows': len(test)})
        for row in test:
            prediction = predict(models, row)
            record = {k: row[k] for k in ('run', 'episode_id', 'group', 'phase', 'start_s', 'x_p_w', 'x_c')}
            record['prediction_status'] = prediction['status']
            record['y_online_error_or_incomplete'] = row['y_online_error_or_incomplete']
            record['service_labels_cross_transition'] = row.get('service_labels_cross_transition')
            record['y_gap_samples'] = row['y_gap_samples']
            record['y_ttft_samples'] = row['y_ttft_samples']
            for target in TARGETS:
                record[target] = row.get(target)
                record['pred_' + target] = prediction['values'].get(target)
                record['score_' + target] = eligible(row, target)
                detail = prediction['details'].get(target, {})
                record['outside_' + target] = len(detail.get('outside_training_range', []))
            records.append(record)
    return records, folds


def summarize(records, target):
    candidates = [r for r in records if r['score_' + target]]
    scored = [r for r in candidates if finite(r.get('pred_' + target))]
    if not scored:
        return {'eligible_windows': len(candidates), 'predicted_windows': 0,
                'unpredicted_windows': len(candidates), 'mae': None, 'optimistic_error_p95': None}
    errors = np.array([r['pred_' + target] - r[target] for r in scored])
    optimism = errors if target == 'y_completed_jobs_next30' else -errors
    identity_mae = {i: float(np.mean([abs(r['pred_' + target] - r[target]) for r in scored if r['episode_id'] == i]))
                    for i in sorted({r['episode_id'] for r in scored})}
    return {'eligible_windows': len(candidates), 'predicted_windows': len(scored),
            'unpredicted_windows': len(candidates) - len(scored),
            'mae': float(np.mean(np.abs(errors))), 'bias_pred_minus_actual': float(np.mean(errors)),
            'identity_macro_mae': float(np.mean(list(identity_mae.values()))),
            'optimistic_error_p95': float(np.quantile(np.maximum(optimism, 0.), .95)),
            'maximum_optimistic_error': float(max(0., optimism.max())),
            'outside_training_range_windows': sum(r['outside_' + target] > 0 for r in scored),
            'interpretation': 'Descriptive errors of dependent windows, not confidence bounds'}


def service_confusion(records):
    counts = Counter()
    for r in records:
        if not all(r['score_' + t] and finite(r.get('pred_' + t)) for t in SERVICE_TARGETS):
            counts['unscored'] += 1
            continue
        actual_safe = (r['y_ttft_p95_ms'] <= 5000 and r['y_gap_p99_ms'] <= 100
                       and r['y_online_error_or_incomplete'] == 0)
        predicted_safe = r['pred_y_ttft_p95_ms'] <= 5000 and r['pred_y_gap_p99_ms'] <= 100
        counts['scored'] += 1
        counts['observed_threshold_violations'] += not actual_safe
        counts['predicted_within_thresholds'] += predicted_safe
        counts['false_safe'] += predicted_safe and not actual_safe
        counts['false_alarm'] += not predicted_safe and actual_safe
    return {k: counts[k] for k in ('scored', 'unscored', 'observed_threshold_violations',
                                  'predicted_within_thresholds', 'false_safe', 'false_alarm')}

