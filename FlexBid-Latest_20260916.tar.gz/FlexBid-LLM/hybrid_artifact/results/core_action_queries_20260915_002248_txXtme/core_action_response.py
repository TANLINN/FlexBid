"""Query action-specific 30-second point predictions from a known state."""
from core_response_model import FEATURES, predict


def response(models, state, power_w, concurrency, duration_s=30):
    if duration_s != 30:
        raise ValueError('This model supports 30-second predictions only')
    query = {key: state.get(key) for key in FEATURES}
    query.update(group=state['group'], phase=state['phase'], x_p_w=power_w, x_c=concurrency)
    result = predict(models, query)
    result.update(action={'power_w_per_gpu': power_w, 'batch_concurrency': concurrency},
                  duration_s=duration_s,
                  differs_from_recorded_action=(state['x_p_w'], state['x_c']) != (power_w, concurrency),
                  switching_effect_validated=False,
                  deadline_feasibility=None)
    return result

