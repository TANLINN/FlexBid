"""Exercise action queries on held-identity saved states without executing actions."""
import json
from collections import Counter, defaultdict
from pathlib import Path
import sys

from core_response_model import load_windows, fit_models, TARGETS
from evaluate_core_response_model import annotate_service_labels
from core_action_response import response


def main(dataset, output):
    rows = load_windows(dataset / 'action_windows.csv')
    saved = json.loads((dataset / 'REPORT.json').read_text())
    usable = {r['run'] for r in saved['runs'] if r['caps_match_saved_receipts'] and r['all_gpu_receipts_present']}
    rows = [r for r in rows if r['run'] in usable]
    annotate_service_labels(rows)
    counts = defaultdict(Counter)
    with (output / 'queries.jsonl').open('w', encoding='utf-8') as stream:
        for identity in sorted({r['episode_id'] for r in rows}):
            models = fit_models([r for r in rows if r['episode_id'] != identity])
            for state in rows:
                if state['episode_id'] != identity or state['x_remaining_jobs'] is None or state['x_remaining_jobs'] <= 0:
                    continue
                # Query selection uses start-state demand, not future outcomes or action constancy.
                actions = [(p, c) for p in (300, 350, 400) for c in (5, 6)] if state['phase']=='event' else [(400,5),(400,6)]
                for p,c in actions:
                    result = response(models, state, p, c)
                    counter = counts[(identity, state['phase'],p,c)]
                    counter['queries'] += 1
                    counter[result['status']] += 1
                    counter['all_targets_present'] += all(t in result['values'] for t in TARGETS)
                    counter['outside_training_range'] += any(v.get('outside_training_range') for v in result['details'].values())
                    counter['missing_features'] += any(v.get('missing_features') for v in result['details'].values())
                    counter['different_action'] += result['differs_from_recorded_action']
                    assert all(identity not in v.get('training_identities',[]) for v in result['details'].values())
                    stream.write(json.dumps({'run':state['run'],'episode_id':identity,'start_s':state['start_s'],**result},ensure_ascii=False)+'\n')
    groups=[{'episode_id':k[0],'phase':k[1],'power_w':k[2],'c':k[3],**v} for k,v in sorted(counts.items())]
    report={'status':'CORE_ACTION_QUERY_INTERFACE_EXERCISED','dataset':str(dataset),'groups':groups,
            'notes':['Queries use only saved start-state features; no future state is used for action ranking or execution.',
                     'No action is selected or executed. Alternate-action outputs have no measured counterfactual label.',
                     'Whole identities are excluded from fitting. Training parameters are unchanged.',
                     'Missing actions, extrapolation and missing features are reported; no empirical safety margin is added.',
                     'Only 30-second point responses are supported. Switching, state rollout and deadline feasibility remain unvalidated.',
                     'No GPU query, workload, retry, keepalive change or active model replacement.']}
    (output/'REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lines=['=== CORE_ACTION_QUERY_INTERFACE ===','STATUS='+report['status']]+['GROUP='+json.dumps(g) for g in groups]+report['notes']+['REPORT_JSON='+str(output/'REPORT.json')]
    (output/'REPORT.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8');print('\n'.join(lines))


if __name__=='__main__':
    main(Path(sys.argv[1]),Path(sys.argv[2]))

