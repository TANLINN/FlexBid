"""Prepare the two remaining Conversation quartile workloads on CPU."""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys

CASES = (
    ('azure_conversation:azure-001710', [190, 43, 550, 788, 829, 915]),
    ('azure_conversation:azure-001918', [264, 65, 711, 1261, 1254, 1085]),
)
PHASE_BINS = ((0, 120), (120, 150), (150, 450), (450, 950), (950, 1450), (1450, 1950))
ARRIVAL_SCALE = 16.0
DURATION_S = 1950.0


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


def prepare(project, policy_run, output, materializer_factory=None):
    import yaml
    from flexbid_hybrid.clients import PromptMaterializer, load_trace

    project, policy_run, output = Path(project), Path(policy_run), Path(output)
    config_path = policy_run / 'config.yaml'
    config = yaml.safe_load(config_path.read_text(encoding='utf-8'))
    protocol = read_json(policy_run / 'protocol.json')
    batch_root = Path(protocol['input_root'])
    if not batch_root.is_absolute():
        batch_root = project / batch_root
    batch_path = batch_root / 'batch_jobs.jsonl'
    batch_bytes = batch_path.read_bytes()
    measurement_path = policy_run / 'cohort_phase_measurement.py'
    spec = importlib.util.spec_from_file_location('saved_cohort_input_validator', measurement_path)
    measured = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(measured)
    manifest_path = project.parent / 'paper_artifact/data/adapted/manifest.json'
    episodes = read_json(manifest_path)['episodes']
    tokenizer_name = config['model']['tokenizer']
    materializer = (materializer_factory or PromptMaterializer)(tokenizer_name)
    context_limit = int(config['model']['max_model_len'])
    summaries = []
    for episode_id, expected_counts in CASES:
        matches = [row for row in episodes if row['episode_id'] == episode_id]
        if len(matches) != 1:
            raise ValueError(f'Expected one manifest entry for {episode_id}; found {len(matches)}')
        episode = matches[0]
        if episode['source'] != 'azure_conversation' or episode['split'] != 'test':
            raise ValueError('Manifest source/split differs from the selected inventory: ' + episode_id)
        trace = Path(episode['path'])
        if not trace.is_absolute():
            trace = manifest_path.parent / trace
        rows = [dict(row) for row in load_trace(trace, ARRIVAL_SCALE, DURATION_S)
                if 0 <= float(row['arrival_ms']) < DURATION_S * 1000]
        for row in rows:
            row['prompt_token_ids'] = materializer.online_tokens(row)
            if len(row['prompt_token_ids']) != int(row['prompt_tokens']):
                raise ValueError('Materialized prompt length differs: ' + str(row['request_id']))
        case_root = output / episode_id.replace(':', '_')
        case_root.mkdir()
        with (case_root / 'online_workload.jsonl').open('x', encoding='utf-8') as stream:
            for row in rows:
                stream.write(json.dumps(row, ensure_ascii=False) + '\n')
        with (case_root / 'batch_jobs.jsonl').open('xb') as stream:
            stream.write(batch_bytes)
        online, jobs = measured.saved_workload(case_root)
        counts = [sum(left * 1000 <= float(row['arrival_ms']) < right * 1000 for row in online)
                  for left, right in PHASE_BINS]
        online_context = max(int(row['prompt_tokens']) + int(row['max_output_tokens']) for row in online)
        batch_context = max(int(row['prompt_tokens']) + int(row['max_output_tokens']) for row in jobs)
        info = {
            'episode_id': episode_id, 'source': episode['source'], 'manifest_split': episode['split'],
            'trace': str(trace.resolve()), 'manifest': str(manifest_path), 'input_root': str(case_root),
            'policy_source_run': str(policy_run), 'configuration_source': str(config_path),
            'arrival_time_multiplier': ARRIVAL_SCALE, 'duration_s': DURATION_S,
            'online_requests': len(online), 'phase_bins_s': PHASE_BINS, 'phase_request_counts': counts,
            'previous_inventory_phase_request_counts': expected_counts,
            'matches_previous_inventory': counts == expected_counts,
            'batch_jobs': len(jobs), 'batch_tokens': sum(int(row['max_output_tokens']) for row in jobs),
            'batch_input_source': str(batch_path),
            'batch_input_identical': (case_root / 'batch_jobs.jsonl').read_bytes() == batch_bytes,
            'batch_release_s': measured.WARMUP_S, 'batch_deadline_s': measured.DURATION_S,
            'maximum_online_prompt_plus_output_tokens': online_context,
            'maximum_batch_prompt_plus_output_tokens': batch_context,
            'configured_max_model_len': context_limit,
            'all_inputs_fit_context': max(online_context, batch_context) <= context_limit,
            'tokenizer': tokenizer_name,
            'materializer_source': str(Path(sys.modules[PromptMaterializer.__module__].__file__).resolve()),
            'input_validator_source': str(measurement_path),
            'selection': 'Both remaining Conversation request-count quartile candidates from the existing inventory, ordered by quartile.',
            'input_semantics': 'Existing length-matched token materialization; not a replay of original prompt semantics.',
            'evidence_scope': 'Input preparation only. Prior experimental use is unconfirmed; not a pristine holdout claim.',
            'gpu_workload_run': False,
        }
        write_json(case_root / 'INPUT_SUMMARY.json', info)
        summaries.append(info)
    result = {'status': 'INPUTS_PREPARED', 'policy_source_run': str(policy_run),
              'cases': summaries, 'gpu_workload_run': False}
    write_json(output / 'INPUT_SUMMARY.json', result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--policy-run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.project.resolve()))
    result = prepare(args.project.resolve(), args.policy_run.resolve(), args.output.resolve())
    print('=== CONVERSATION_QUARTILE_INPUTS ===')
    print('STATUS=' + result['status'])
    print('POLICY_SOURCE_RUN=' + result['policy_source_run'])
    for info in result['cases']:
        fields = ('episode_id', 'input_root', 'trace', 'online_requests', 'phase_request_counts',
                  'matches_previous_inventory', 'batch_jobs', 'batch_tokens', 'batch_input_identical',
                  'batch_release_s', 'batch_deadline_s', 'arrival_time_multiplier',
                  'maximum_online_prompt_plus_output_tokens', 'maximum_batch_prompt_plus_output_tokens',
                  'configured_max_model_len', 'all_inputs_fit_context')
        print('CASE=' + json.dumps({k: info[k] for k in fields}, ensure_ascii=False))
    print('GPU_WORKLOAD_RUN=false')
    print('Token arrays preserve the existing length-based workload protocol; original prompt semantics are not evaluated.')
    print('Preparation is not a service, deadline or power result. Prior experimental use remains unconfirmed.')


if __name__ == '__main__':
    main()
