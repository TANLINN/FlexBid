"""Measure the saved Conversation 001918 online workload with twelve admission slots and no batch submissions."""
import argparse
import asyncio
import copy
import json
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import cohort_phase_measurement as m
from online_capacity12_tools import gateway_source
from conversation1918_online12_report import analyze_cell, cell_text


def workload(output):
    import httpx
    settings = m.read_json(output / 'workload.json')
    shutil.copyfile(Path(settings['input_root']) / 'online_workload.jsonl', output / 'online_workload.jsonl')
    online = m.read_rows(output / 'online_workload.jsonl')
    m.write_json(output / 'workload_ready.json', {'online_requests': len(online), 'batch_jobs_submitted': 0})
    limit = time.monotonic() + 300
    while not (output / 'protocol.json').is_file():
        if time.monotonic() > limit:
            raise TimeoutError('Launcher did not provide the workload start time')
        time.sleep(.1)
    protocol = m.read_json(output / 'protocol.json')
    async def run():
        with (output / 'online.jsonl').open('w', encoding='utf-8') as stream:
            def emit(kind, row):
                if kind != 'online':
                    raise RuntimeError('Unexpected batch request in online capacity probe')
                stream.write(json.dumps(row) + '\n')
                stream.flush()
            async with httpx.AsyncClient(timeout=None, headers={'Authorization': 'Bearer EMPTY'},
                         limits=httpx.Limits(max_connections=2048, max_keepalive_connections=256)) as client:
                async def request(row, kind):
                    return await m.measure_completion(client, settings['api_base'], settings['model'],
                        row['prompt_token_ids'], row['max_output_tokens'], kind, settings['source'], row['request_id'])
                await m.execute_requests(online, [], protocol, request, emit, concurrency=0)
    asyncio.run(run())
    m.write_json(output / 'workload_complete.json', {'status': 'complete', 'batch_jobs_submitted': 0})


def run_measurement(project, source, inputs, output, event_cap):
    import fcntl
    import yaml
    from flexbid_hybrid.config import load_config
    from flexbid_hybrid.mpc import build_action_lattice
    from flexbid_hybrid.power import PowerCapManager
    from flexbid_hybrid.service import get_json, stop_process
    from online_queue_priority_tools import apply_recovery_control as apply_control
    saved = m.read_json(source / 'protocol.json')
    online, jobs = m.saved_workload(inputs)
    info = m.read_json(inputs / 'INPUT_SUMMARY.json')
    if info['episode_id'] != 'azure_conversation:azure-001918':
        raise ValueError('Source is not the selected Azure Conversation workload')
    config = copy.deepcopy(load_config(source / 'config.yaml'))
    if config['runtime']['max_num_batched_tokens'] != 1024 or config['runtime']['online_concurrency'] != 8:
        raise ValueError('Source service is not the measured chunk1024/eight-slot setting')
    maximum = max(int(r['prompt_tokens']) + int(r['max_output_tokens']) for r in online)
    batch_maximum = max(int(r['prompt_tokens']) + int(r['max_output_tokens']) for r in jobs)
    if max(maximum, batch_maximum) > int(config['model']['max_model_len']):
        raise ValueError('Saved input exceeds configured model context')
    m.write_json(output / 'INPUT_CONTEXT.json', {'maximum_online_prompt_plus_output_tokens': maximum,
                 'maximum_batch_prompt_plus_output_tokens': batch_maximum,
                 'configured_model_max_model_len': int(config['model']['max_model_len']), 'all_requests_fit': True})
    config['runtime']['online_concurrency'] = 12
    config['runtime']['priority_gateway_module'] = str(output / 'priority_gateway.py')
    config['hardware']['control_file'] = str(output / 'control.json')
    config.setdefault('paths', {})['results_root'] = str(output)
    config['experiment_name'] = output.name
    (output / 'priority_gateway.py').write_text(gateway_source((source / 'priority_gateway.py').read_text(encoding='utf-8')), encoding='utf-8')
    (output / 'config.yaml').write_text(yaml.safe_dump(config, sort_keys=False), encoding='utf-8')
    helper = m.load_helper(Path(saved['source_run']))
    actions = build_action_lattice(config['dynamic_controller']['action_lattice'])
    action = m.select_recovery_action(actions, 400, 0)
    event_action = m.select_recovery_action(actions, 400, 0)
    recovery_action = m.select_recovery_action(actions, 400, 0)
    base = f"http://127.0.0.1:{config['runtime']['gateway_port']}"
    m.write_json(output / 'workload.json', {'model': config['model']['name'], 'api_base': base + '/v1',
                  'source': info['source'], 'episode_id': info['episode_id'], 'input_root': str(inputs)})
    m.write_json(output / 'EXPERIMENT_PLAN.json', {'episode_id': info['episode_id'], 'source_run': str(source),
                  'input_root': str(inputs), 'duration_s': 1950, 'online_requests': len(online),
                  'online_slots': 12, 'online_per_replica': 3, 'max_num_batched_tokens': 1024,
                  'batch_jobs_submitted': 0, 'batch_deadline_evaluated': False, 'reference_batch_release_s': 150, 'reference_batch_deadline_s': 1950,
                  'batch_submission': 'No batch requests; source cohort remains unchanged',
                  'event_batch_concurrency': 0, 'recovery_batch_concurrency': 0,
                  'recovery_online_queue_priority': False,
                  'power_cap_sequence_w_per_gpu': [400, 400, 400], 'automatic_retry': False,
                  'purpose': 'Online-only capacity comparison: eight slots/two per replica versus twelve slots/three per replica'})
    lock_path = project / 'results/chunk2048_priority_c6_recovery_pilot.lock'
    with lock_path.open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        active = helper.active_collectors(project)
        if active:
            raise RuntimeError('Another FlexBid workload is active: ' + repr(active))
        gpu = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name', '--format=csv,noheader,nounits'],
                             text=True, capture_output=True, timeout=20)
        if gpu.returncode != 0 or gpu.stdout.strip():
            raise RuntimeError('GPU idle state unavailable or other compute processes present: ' + gpu.stdout + gpu.stderr)
        with PowerCapManager(config['hardware']['gpu_indices']) as power_caps:
            power_caps.set_all(400)
            apply_control(Path(config['hardware']['control_file']), action, len(config['model']['replicas']), 12)
            with helper.PriorityServiceGroup(project, config, output / 'service_logs') as services:
                services.wait_idle()
                services.reset_caches()
                services.reset_state()
                get_json(base + '/flexbid/state')
                def enact(desired):
                    caps = power_caps.set_all(desired.power_cap_w)
                    control = apply_control(Path(config['hardware']['control_file']), desired, len(config['model']['replicas']), 12)
                    return {'enforced_power_caps_w': caps, 'control': control}
                handles, driver, telemetry = [], None, None
                try:
                    log = (output / 'logs/workload.log').open('w', encoding='utf-8')
                    handles.append(log)
                    driver = subprocess.Popen([sys.executable, '-B', '-u', str(Path(__file__).resolve()),
                            '--project', str(project), '--source', str(source), '--input-root', str(inputs),
                            '--event-cap', str(event_cap), '--output', str(output), '--workload'],
                            cwd=project, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                    limit = time.monotonic() + 240
                    while not (output / 'workload_ready.json').is_file():
                        if driver.poll() is not None:
                            raise RuntimeError('Workload preparation failed; see logs/workload.log')
                        if time.monotonic() > limit:
                            raise TimeoutError('Workload preparation exceeded 240 seconds')
                        time.sleep(.2)
                    log = (output / 'logs/telemetry.log').open('w', encoding='utf-8')
                    handles.append(log)
                    telemetry = subprocess.Popen([sys.executable, '-B', '-m', 'flexbid_hybrid.telemetry',
                            '--output', str(output / 'components.csv'), '--interval-ms', str(config['hardware']['telemetry_interval_ms'])],
                            cwd=project, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                    start = time.time_ns() + 3_000_000_000
                    protocol = {'start_wall_ns': start, 'deadline_wall_ns': start + 1950_000_000_000,
                            'duration_s': 1950., 'drain_s': m.DRAIN_S, 'cohort_release_offset_s': 150.,
                            'batch_admission_offset_s': 150., 'event_batch_concurrency': 0,
                            'recovery_batch_concurrency': 0, 'recovery_start_offset_s': 450.,
                            'input_root': str(inputs), 'source_run': saved['source_run'],
                            'hardware_template_run': str(source), 'batch_jobs_submitted': 0, 'batch_deadline_evaluated': False,
                            'condition': 'online12_p400', 'power_cap_sequence_w_per_gpu': [400, 400, 400],
                            'recovery_admission_policy': 'Batch admission remains paused'}
                    m.write_json(output / 'protocol.json', protocol)
                    print('MEASUREMENT_STARTED ' + json.dumps(m.read_json(output / 'workload_ready.json')), flush=True)
                    end = time.monotonic() + (protocol['deadline_wall_ns'] - time.time_ns()) / 1e9
                    with (output / 'gateway_state.jsonl').open('w', encoding='utf-8') as stream, (output / 'power_actions.jsonl').open('w', encoding='utf-8') as powers:
                        def emit_cap(row):
                            powers.write(json.dumps(row) + '\n')
                            powers.flush()
                        schedule = m.CapSchedule(end - 1950, action, event_action, enact, emit_cap, recovery=recovery_action)
                        while time.monotonic() < end:
                            if driver.poll() is not None and driver.returncode != 0:
                                raise RuntimeError('Workload exited with error; see logs/workload.log')
                            if telemetry.poll() is not None or any(p.poll() is not None for p in services.processes):
                                raise RuntimeError('Telemetry or service exited early; see logs')
                            schedule.tick()
                            value = get_json(base + '/flexbid/state')
                            snapshot = {k: value[k] for k in ('inflight', 'inflight_online', 'inflight_batch', 'online_waiting', 'batch_waiting', 'completed_online', 'completed_batch')}
                            stream.write(json.dumps({'wall_time_ns': time.time_ns(), **snapshot}) + '\n')
                            stream.flush()
                            time.sleep(schedule.sleep_duration(end))
                    print('MEASUREMENT_ENDED; draining outstanding requests', flush=True)
                    if driver.wait(timeout=m.DRAIN_S + 30) != 0 or not (output / 'workload_complete.json').is_file():
                        raise RuntimeError('Workload completion missing or unsuccessful')
                finally:
                    try:
                        try:
                            m.write_json(output / 'POWER_CAP_RESTORED.json', enact(action))
                        finally:
                            if driver is not None and driver.poll() is None:
                                stop_process(driver)
                    finally:
                        if telemetry is not None and telemetry.poll() is None:
                            stop_process(telemetry)
                        for handle in handles:
                            handle.close()
                services.wait_idle()
    return config


def main():
    parser = argparse.ArgumentParser()
    for name in ('project', 'source', 'input-root', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--event-cap', type=float, choices=(400.,), required=True)
    parser.add_argument('--workload', action='store_true')
    args = parser.parse_args()
    project, source, output = args.project.resolve(), args.source.resolve(), args.output.resolve()
    sys.path.insert(0, str(project))
    sys.path.insert(0, str(project / 'scripts'))
    if args.workload:
        workload(output)
        return
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'received signal {signum}')
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    try:
        m.record_environment(output)
        config = run_measurement(project, source, args.input_root.resolve(), output, args.event_cap)
    except BaseException as exc:
        m.write_json(output / 'COLLECTION_FAILED.json', {'status': 'CONVERSATION1918_ONLINE12_FAILED',
                       'error_type': type(exc).__name__, 'error': str(exc), 'automatic_retry': False})
        raise
    try:
        result = analyze_cell(output, config, source, args.event_cap)
        m.write_json(output / 'REPORT.json', result)
        (output / 'REPORT.txt').write_text(cell_text(result), encoding='utf-8')
        print((output / 'REPORT.txt').read_text(encoding='utf-8'), end='', flush=True)
    except Exception as exc:
        m.write_json(output / 'ANALYSIS_FAILED.json', {'error_type': type(exc).__name__, 'error': str(exc), 'raw_measurement_completed': True})
        raise


if __name__ == '__main__':
    main()
