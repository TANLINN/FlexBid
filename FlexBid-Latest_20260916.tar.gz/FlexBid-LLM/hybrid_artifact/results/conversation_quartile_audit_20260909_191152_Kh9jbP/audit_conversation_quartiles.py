"""Inspect saved stream tails and fixed-cohort deadline failures."""
import argparse
from collections import Counter
import importlib.util
import json
import math
from pathlib import Path
import sys

from quartile_stream_audit import request_records, p99_boundary

PHASES = {'warmup': (0, 150), 'event_time_reference': (150, 450),
          'recovery': (450, 1950), 'recovery_early': (450, 950),
          'recovery_middle': (950, 1450), 'recovery_late': (1450, 1950),
          'evaluation': (150, 1950), 'warmup_first30': (0, 30),
          'warmup_after30': (30, 150)}
CELLS = ('azure001710_p400', 'azure001710_p300', 'azure001918_p300', 'azure001918_p400')
META = ('arrival_ms', 'prompt_tokens', 'max_output_tokens', 'parent_request_id', 'tool_delay_ms')


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_rows(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def indexed(rows, field):
    result = {r[field]: r for r in rows}
    if len(result) != len(rows):
        raise ValueError('Duplicate ' + field)
    return result


def load_helper(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def same_number(a, b):
    if a is None or b is None:
        return a is None and b is None
    return math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-6)


def select(rows, phase):
    left, right = PHASES[phase]
    return [r for r in rows if left * 1000 <= float(r['arrival_ms']) < right * 1000]


def match_metric(before, after, phase, metric, threshold):
    old, new = indexed(select(before, phase), 'request_id'), indexed(select(after, phase), 'request_id')
    if old.keys() != new.keys():
        raise ValueError('Paired phase request IDs differ: ' + phase)
    counts, tails = Counter(), []
    for key, a in old.items():
        b = new[key]
        if any(a.get(k) != b.get(k) for k in META):
            raise ValueError('Paired metadata differ: ' + key)
        if any(r.get('error') is not None or r.get('status_code') != 200 or r.get(metric) is None for r in (a, b)):
            counts['without_two_valid_values'] += 1
            continue
        x, y = a[metric] > threshold, b[metric] > threshold
        category = 'both_above' if x and y else 'only_p400_above' if x else 'only_p300_above' if y else 'neither_above'
        counts[category] += 1
        if x or y:
            tails.append({'request_id': key, 'category': category, 'p400': a, 'p300': b})
    return {'phase': phase, 'metric': metric, 'threshold_ms': threshold, 'matched_requests': len(old),
            'counts': {k: counts[k] for k in ('both_above', 'only_p400_above', 'only_p300_above',
                                           'neither_above', 'without_two_valid_values')},
            'tail_pairs': sorted(tails, key=lambda r: (r['p400']['arrival_ms'], r['request_id']))}


def batch_details(jobs, ledger, gateways, start_ns, describe):
    planned, actual = indexed(jobs, 'job_id'), indexed(ledger, 'job_id')
    if planned.keys() != actual.keys():
        raise ValueError('Batch ledger does not account for every planned job')
    categories, details, admission_rows = Counter(), [], []
    mapped = indexed([r for r in gateways if r['class'] == 'batch'], 'request_id')
    for key, job in planned.items():
        r = actual[key]
        begin, end = r.get('dispatch_wall_time_ns'), r.get('completion_wall_time_ns')
        release_ns = start_ns + round(float(job['release_offset_s']) * 1e9)
        deadline_ns = start_ns + round(float(job['deadline_offset_s']) * 1e9)
        complete = (r.get('error') is None and r.get('status_code') == 200
                    and int(r.get('completion_tokens') or 0) == int(job['max_output_tokens']) and end is not None)
        if begin is not None and (int(begin) < release_ns or end is not None and int(end) < int(begin)):
            raise ValueError('Invalid batch timing: ' + key)
        if complete and begin is not None:
            category = 'on_time' if int(end) <= deadline_ns else 'late_complete'
        elif begin is None and r.get('job_status') == 'not_started_by_deadline' and end is None:
            category = 'not_started_by_deadline'
        elif begin is None:
            category = 'undispatched_other_or_unknown'
        elif r.get('error') is not None or r.get('status_code') != 200:
            category = 'attempted_error_or_non200'
        else:
            category = 'attempted_incomplete'
        categories[category] += 1
        detail = {'job_id': key, 'category': category, 'job_status': r.get('job_status'),
                  'dispatch_s': None if begin is None else (int(begin)-start_ns)/1e9,
                  'completion_s': None if end is None else (int(end)-start_ns)/1e9,
                  'completion_tokens': r.get('completion_tokens'), 'status_code': r.get('status_code'),
                  'error': r.get('error'), 'gateway_record_present': key in mapped}
        if category != 'on_time':
            details.append(detail)
        g = mapped.get(key)
        if g is None:
            continue
        context = g.get('inflight_after_selection', {}).get('online_queue_priority')
        if context is None:
            admission_rows.append({'job_id': key, 'available': False})
            continue
        first = g['events'][0]['upstream_read_ns'] if g['events'] else None
        selected_ns = int(context['selection_wall_time_ns'])
        admission_rows.append({'job_id': key, 'available': True, 'replica': g['replica'],
            'selection_s': (selected_ns-start_ns)/1e9, 'policy_enabled': context['enabled'],
            'deferred_for_online': context['deferred_for_online'],
            'queued_online_at_selection': context['queued_online_at_selection'],
            'placement_wait_ms': context['placement_wait_ms'],
            'dispatch_to_selection_ms': None if begin is None else (selected_ns-int(begin))/1e6,
            'admission_to_first_text_ms': None if first is None else (int(first)-int(g['admitted_mono_ns']))/1e6})
    grouped = {}
    for phase in ('event_time_reference', 'recovery', 'recovery_early', 'recovery_middle', 'recovery_late'):
        left, right = PHASES[phase]
        rows = [r for r in admission_rows if r['available'] and left <= r['selection_s'] < right]
        grouped[phase] = {'admissions': len(rows), 'policy_enabled': sum(r['policy_enabled'] for r in rows),
            'previously_deferred_for_online': sum(r['deferred_for_online'] for r in rows),
            'admitted_while_online_queued': sum(r['queued_online_at_selection'] > 0 for r in rows),
            'by_replica': dict(Counter(str(r['replica']) for r in rows)),
            **{k: describe([r[k] for r in rows]) for k in
               ('placement_wait_ms', 'dispatch_to_selection_ms', 'admission_to_first_text_ms')}}
    expected_attempts = {key for key, r in actual.items() if r.get('dispatch_wall_time_ns') is not None}
    return {'categories': {k: categories[k] for k in ('on_time', 'late_complete', 'not_started_by_deadline',
            'undispatched_other_or_unknown', 'attempted_error_or_non200', 'attempted_incomplete')},
            'unsuccessful_deadline_jobs': details, 'admissions_by_selection_phase': grouped,
            'missing_admission_contexts': sum(not r['available'] for r in admission_rows),
            'attempted_jobs_without_gateway_record': sorted(expected_attempts-mapped.keys()),
            'unexpected_gateway_batch_ids': sorted(mapped.keys()-expected_attempts),
            'wait_scope': 'Placement wait includes eligibility and online-queue deferral; it is not time exclusively caused by queue priority.'}


def analyze(source):
    measure = load_helper(source / 'cohort_phase_measurement.py', 'quartile_saved_measure')
    timing = load_helper(source / 'analyze_c6_ttft_decomposition.py', 'quartile_saved_timing')
    result = {'status': 'CONVERSATION_QUARTILE_FAILURE_AUDIT_COMPLETE', 'source_run': str(source),
              'gpu_workload_run': False, 'cells': {}, 'pairs': {}, 'warnings': []}
    records, thresholds, metadata = {}, {}, {}
    for name in CELLS:
        folder = source / 'cells' / name
        saved, protocol = read_json(folder / 'REPORT.json'), read_json(folder / 'protocol.json')
        online, gateways = read_rows(folder / 'online.jsonl'), read_rows(folder / 'stream_gateway.jsonl')
        indexed(online, 'request_id')
        metadata[name] = {r['request_id']: [r.get(k) for k in META] for r in online}
        thresholds[name] = saved['slos']
        gap_slo, ttft_slo = float(saved['slos']['request_mean_stream_gap_p99_ms']), float(saved['slos']['ttft_p95_ms'])
        start_ns = int(protocol['start_wall_ns'])
        phases, mismatches = {}, []
        for phase in PHASES:
            rows = select(online, phase)
            p = measure.latency_summary(rows, ttft_slo, gap_slo)
            p['requests_with_ttft_over_slo'] = sum(r.get('ttft_ms') is not None and r['ttft_ms'] > ttft_slo for r in rows)
            phases[phase] = p
            for field in ('requests', 'errors', 'ttft_samples', 'request_mean_stream_gap_samples', 'ttft_p95_ms',
                          'request_mean_stream_gap_p99_ms', 'requests_with_mean_stream_gap_over_slo',
                          'requests_with_ttft_over_slo', 'observed_slo_safe'):
                if not same_number(p[field], saved['phases'][phase][field]):
                    mismatches.append(phase + '/' + field)
        jobs, ledger = read_rows(folder / 'batch_jobs.jsonl'), read_rows(folder / 'batch.jsonl')
        batch_summary = measure.cohort_summary(jobs, ledger, protocol)
        if batch_summary != saved['batch']:
            mismatches.append('batch_summary')
        details = batch_details(jobs, ledger, gateways, start_ns, timing.describe)
        if (details['categories']['on_time'] != batch_summary['jobs_completed_on_time'] or
                details['categories']['late_complete'] != batch_summary['jobs_completed_late']):
            mismatches.append('batch_classification')
        actual_recovery_safe = all(phases[p]['observed_slo_safe'] for p in ('recovery_early', 'recovery_middle', 'recovery_late'))
        cell = {'source_cell': str(folder), 'failed_checks': saved['failed_checks'],
                'summary_mismatches': mismatches, 'phases': phases, 'batch': batch_summary,
                'batch_detail': details, 'cohort_timing': saved['cohort_timing'],
                'recovery_subphases_service_pass': actual_recovery_safe,
                'recovery_subphases_and_deadline_only_pass': actual_recovery_safe and batch_summary['all_jobs_completed_by_deadline'],
                'saved_all_recovery_subphases_and_deadline_pass': saved['all_recovery_subphases_and_deadline_pass_observed'],
                'saved_flag_scope': 'The saved combined flag also requires the global service/measurement checks, including the event phase.',
                'saved_queue_priority_policy': saved['queue_priority_policy']}
        if '001710' in name:
            records[name] = request_records(online, gateways, start_ns, gap_slo)
            by_id = indexed(online, 'request_id')
            for r in records[name]:
                r.update({k: by_id[r['request_id']].get(k) for k in META})
            event = select(records[name], 'event_time_reference')
            cell['event_p99_boundary'] = p99_boundary(event, gap_slo)
            cell['event_upstream_context'] = {
                'client_tail_requests': sum(r['gap_ms'] is not None and r['gap_ms'] > gap_slo for r in event),
                'client_tails_with_upstream_mean_above_slo': sum(r['gap_ms'] is not None and r['gap_ms'] > gap_slo
                    and r['upstream_mean_gap_ms'] is not None and r['upstream_mean_gap_ms'] > gap_slo for r in event),
                'long_gap_context': dict(sum((Counter(r['long_gap_context']) for r in event), Counter()))}
        else:
            mapped = indexed([r for r in gateways if r['class'] == 'online'], 'request_id')
            records[name] = [timing.request_timing(r, mapped.get(r['request_id'])) for r in online]
            states = read_rows(folder / 'gateway_state.jsonl')
            cell['ttft_context'] = {p: timing.phase_summary(records[name], states, start_ns, *PHASES[p], ttft_slo)
                                    for p in ('warmup', 'recovery_early', 'recovery_middle', 'recovery_late')}
        if mismatches:
            result['warnings'].append(name + ': ' + ', '.join(mismatches))
        result['cells'][name] = cell
    for episode, phase, metric, slo in (('001710', 'event_time_reference', 'gap_ms', 'request_mean_stream_gap_p99_ms'),
                                       ('001918', 'recovery_middle', 'ttft_ms', 'ttft_p95_ms')):
        a, b = 'azure' + episode + '_p400', 'azure' + episode + '_p300'
        if metadata[a] != metadata[b] or thresholds[a] != thresholds[b]:
            raise ValueError('Pair metadata or SLO differ for ' + episode)
        result['pairs'][episode] = match_metric(records[a], records[b], phase, metric, float(thresholds[a][slo]))
    result['all_reported_summaries_match'] = not result['warnings']
    if result['warnings']:
        result['status'] = 'CONVERSATION_QUARTILE_FAILURE_AUDIT_NEEDS_INSPECTION'
    result['limitations'] = [
        'Only saved records are analyzed. No GPU workload, retry or runtime policy change.',
        'The 001710 comparison concerns event stream gaps; the 001918 comparison concerns fixed-cohort and recovery TTFT failures.',
        'Pending-first overlap is observed at the gateway and does not identify engine prefill execution or establish causality.',
        'Queue snapshots are sampled; placement wait includes several admission conditions. Unavailable timing remains unavailable.',
        'P400 failure describes this policy and workload, not physical infeasibility under every possible scheduler.',
        'Warmup uses P400 in both conditions. Recovery also uses P400, but event histories and execution variation differ.',
        'All original requests, 280 jobs, scheduled-arrival phases, SLO thresholds and deadlines are retained.',
        'The 001918 cohorts have unequal incomplete work at 1950 s; fixed-window energy differences are not equal-work efficiency.',
    ]
    return result


def compact_timing(row):
    result = {k: row[k] for k in ('requests', 'ttft_p95_ms', 'ttft_tail_requests', 'gateway_snapshots')}
    result['tail_decomposition'] = row['ttft_over_slo']
    return result


def format_report(result):
    lines = ['=== CONVERSATION_QUARTILE_FAILURE_AUDIT ===', 'STATUS=' + result['status'],
             'SOURCE_RUN=' + result['source_run'], 'ALL_SUMMARIES_MATCH=' + str(result['all_reported_summaries_match'])]
    def emit(label, value):
        lines.append(label + '=' + json.dumps(value, ensure_ascii=False, separators=(',', ':')))
    for name, cell in result['cells'].items():
        emit('CELL', {'cell': name, 'failed_checks': cell['failed_checks'], 'summary_mismatches': cell['summary_mismatches'],
            'recovery_subphases_service_pass': cell['recovery_subphases_service_pass'],
            'recovery_subphases_and_deadline_only_pass': cell['recovery_subphases_and_deadline_only_pass'],
            'saved_combined_flag': cell['saved_all_recovery_subphases_and_deadline_pass']})
        if 'event_p99_boundary' in cell:
            emit('EVENT_P99_BOUNDARY', {'cell': name, **cell['event_p99_boundary']})
            emit('EVENT_UPSTREAM_CONTEXT', {'cell': name, **cell['event_upstream_context']})
        else:
            detail = cell['batch_detail']
            emit('BATCH_STATUS', {'cell': name, **{k: v for k, v in detail.items() if k != 'unsuccessful_deadline_jobs'},
                                  'cohort_timing': cell['cohort_timing']})
            for row in detail['unsuccessful_deadline_jobs']:
                emit('DEADLINE_JOB', {'cell': name, **row})
            for phase, row in cell['ttft_context'].items():
                emit('TTFT_CONTEXT', {'cell': name, 'phase': phase, **compact_timing(row)})
    for episode, pair in result['pairs'].items():
        emit('MATCHED', {'episode': episode, **{k: v for k, v in pair.items() if k != 'tail_pairs'}})
        if episode == '001710':
            for row in pair['tail_pairs']:
                emit('EVENT_TAIL_PAIR', row)
    emit('WARNINGS', result['warnings'])
    lines += result['limitations']
    lines.append('Full matched request details are retained in REPORT.json.')
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    try:
        result = analyze(args.source)
        text = format_report(result)
        code = 0
    except Exception as exc:
        result = {'status': 'CONVERSATION_QUARTILE_FAILURE_AUDIT_ERROR', 'gpu_workload_run': False,
                  'error_type': type(exc).__name__, 'error': str(exc)}
        text = json.dumps(result, ensure_ascii=False) + '\n'
        code = 1
    (args.output / 'REPORT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    (args.output / 'REPORT.txt').write_text(text, encoding='utf-8')
    print('REPORT_TXT=' + str(args.output / 'REPORT.txt'))
    print(text, end='')
    return code


if __name__ == '__main__':
    sys.exit(main())
