"""Reconstruct saved event-stream intervals and percentile endpoints."""
from bisect import bisect_right
from collections import Counter, defaultdict

def request_records(online, gateways, start_ns, threshold):
    mapped = {r['request_id']: r for r in gateways}
    if len(mapped) != len(gateways):
        raise ValueError('Duplicate saved gateway request IDs')
    if {r['request_id'] for r in online} != {r['request_id'] for r in gateways if r['class'] == 'online'}:
        raise ValueError('Saved online and gateway IDs differ')
    pending = defaultdict(lambda: [[], []])
    for row in gateways:
        if not row['events']:
            continue
        began, first = int(row['admitted_mono_ns']), int(row['events'][0]['upstream_read_ns'])
        if first < began:
            raise ValueError('First-text timestamp precedes admission: ' + row['request_id'])
        interval = pending[(int(row['replica']), row['class'])]
        interval[0].append(began)
        interval[1].append(first)
    for starts, ends in pending.values():
        starts.sort()
        ends.sort()
    output = []
    for row in online:
        record = mapped[row['request_id']]
        replica = int(record['replica'])
        events, client = record['events'], row.get('stream_observations', [])
        if record['parse_errors'] or len(events) != len(client) or any(
                a['sequence'] != b['sequence'] or a['response_id'] != b['response_id'] or a['text_chars'] != b['text_chars']
                for a, b in zip(events, client)):
            raise ValueError('Saved stream alignment differs: ' + row['request_id'])
        gaps, counts = [], Counter()
        for a, b in zip(events, events[1:]):
            left, right = int(a['upstream_read_ns']), int(b['upstream_read_ns'])
            if right < left:
                raise ValueError('Nonmonotonic saved stream: ' + row['request_id'])
            gap = (right-left) / 1e6
            gaps.append(gap)
            if gap <= threshold:
                continue
            active = {}
            midpoint = (left+right)//2
            for kind in ('online', 'batch'):
                starts, ends = pending[(replica, kind)]
                active[kind] = bisect_right(starts, midpoint)-bisect_right(ends, midpoint)
                if active[kind] < 0:
                    raise ValueError('Negative pending-first count')
            category = 'both' if active['online'] and active['batch'] else 'online_only' if active['online'] else 'batch_only' if active['batch'] else 'neither'
            counts['long_gaps'] += 1
            counts[category] += 1
            counts['batch_pending_1'] += int(active['batch'] == 1)
            counts['batch_pending_2plus'] += int(active['batch'] >= 2)
        dispatch = row.get('dispatch_wall_time_ns')
        output.append({'request_id': row['request_id'], 'arrival_ms': float(row['arrival_ms']),
            'dispatch_offset_s': (int(dispatch)-start_ns)/1e9 if dispatch is not None else None,
            'prompt_tokens': row['prompt_tokens'], 'completion_tokens': row.get('completion_tokens'),
            'max_output_tokens': row['max_output_tokens'], 'error': row.get('error'), 'status_code': row.get('status_code'),
            'ttft_ms': row.get('ttft_ms'), 'gap_ms': row.get('mean_tpot_ms'),
            'upstream_mean_gap_ms': sum(gaps)/len(gaps) if gaps else None,
            'upstream_max_gap_ms': max(gaps) if gaps else None,
            'replica': replica, 'online_after_selection': record['inflight_after_selection']['online'][replica],
            'batch_after_selection': record['inflight_after_selection']['batch'][replica],
            'long_gap_context': dict(counts)})
    return output

def p99_boundary(rows, threshold):
    ordered = sorted((r for r in rows if r['error'] is None and r['status_code'] == 200
                      and r['gap_ms'] is not None), key=lambda r: (r['gap_ms'], r['request_id']))
    if not ordered:
        return {'samples': 0, 'p99_ms': None}
    position = (len(ordered) - 1) * .99
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    weight = position - lower
    a, b = ordered[lower], ordered[upper]
    return {'samples': len(ordered), 'tail_requests': sum(r['gap_ms'] > threshold for r in ordered),
            'lower_order_1based': lower + 1, 'upper_order_1based': upper + 1,
            'upper_weight': weight, 'lower_request': a, 'upper_request': b,
            'p99_ms': a['gap_ms'] + weight * (b['gap_ms'] - a['gap_ms']),
            'definition': 'Existing linear interpolation across per-request mean gaps; not a per-token percentile'}
