"""Compare matched event-window labels and existing model predictions."""
import json,sys
from pathlib import Path
from core_response_model import load_windows,predict,eligible
from evaluate_core_response_model import annotate_service_labels
from core_plan_trajectory import evaluate_plan

def recorded_event_action(run):
    actions=[json.loads(line) for line in (Path(run)/'power_actions.jsonl').read_text().splitlines() if line.strip()]
    values={(r['action']['power_cap_w'],r['action']['batch_concurrency']) for r in actions if r.get('phase')=='event'}
    if len(values)!=1:raise ValueError('Expected one recorded fixed event action: '+str(run))
    power,concurrency=next(iter(values))
    if power not in (300,350,400) or concurrency!=5:raise ValueError('Unsupported recorded event action: '+str(values))
    return power,concurrency

def main(dataset,model,out):
    doc=json.loads(model.read_text());identity='azure_conversation:azure-001918'
    if doc['held_identity']!=identity or identity in doc['training_identities']:raise ValueError('Identity exclusion differs')
    rows=load_windows(dataset/'action_windows.csv');annotate_service_labels(rows)
    test=[r for r in rows if r['episode_id']==identity and r['group']==doc['group'] and r['phase']=='event']
    tm={tuple(r['key']):r['targets'] for r in doc['transitions']};im={tuple(r['key']):r['targets'] for r in doc['idle_transitions']}
    details=[];summaries=[]
    for run in sorted({r['run'] for r in test}):
        windows=sorted([r for r in test if r['run']==run],key=lambda r:r['start_s'])
        origin=next(r for r in windows if r['start_s']==150)
        event_p,event_c=recorded_event_action(run)
        state={k:v for k,v in origin.items() if k.startswith('x_') or k in ('group','phase')}
        plan=evaluate_plan(tm,doc['responses'],state,150,[{'start_s':150,'phase':'event','p_w':event_p,'c':event_c}],deadline_s=450,exhausted_transitions=im,exhausted_responses=doc['idle_responses'])
        rollout={r['start_s']:r for r in plan['records']}
        current=[]
        for r in windows:
            predicted=predict(doc['responses'],r);one=predicted['values'].get('y_gap_p99_ms');rec=rollout.get(r['start_s']);multi=rec['response']['values'].get('y_gap_p99_ms') if rec else None
            value={'run':run,'start_s':r['start_s'],'power_cap_w':r['x_p_w'],'observed_gap_p99_ms':r['y_gap_p99_ms'],'samples':r['y_gap_samples'],'eligible_under_existing_rules':eligible(r,'y_gap_p99_ms'),'service_labels_cross_transition':r.get('service_labels_cross_transition'),'single_step_gap_p99_ms':one,'rollout_gap_p99_ms':multi,'single_step_minus_observed_ms':one-r['y_gap_p99_ms'] if one is not None and r['y_gap_p99_ms'] is not None else None,'rollout_minus_single_step_ms':multi-one if multi is not None and one is not None else None,'single_step_outside_features':predicted['details'].get('y_gap_p99_ms',{}).get('outside_training_range',[])}
            current.append(value);details.append(value)
        scored=[r for r in current if r['eligible_under_existing_rules'] and r['single_step_minus_observed_ms'] is not None]
        summaries.append({'run':run,'event_p_w':event_p,'origin_observed_p_w':origin['x_p_w'],'origin_observed_c':origin['x_c'],'windows':len(current),'scored':len(scored),'single_step_bias_ms':sum(r['single_step_minus_observed_ms'] for r in scored)/len(scored) if scored else None,'observed_window_violations':sum(r['observed_gap_p99_ms']>100 for r in scored),'single_step_missed_gap_violations':sum(r['observed_gap_p99_ms']>100 and r['single_step_gap_p99_ms']<=100 for r in scored),'rollout_status':plan['status']})
    report={'status':'CORE_1918_MATCHED_SERVICE_ERROR_COMPLETE','runs':summaries,'scope':'Same 30-second target comparisons. Rollout action comes from the recorded fixed event schedule, not the action visible just before its boundary. Origin state is unchanged; this retrospective schedule input is not a live receipt claim. Observed-state predictions are diagnostic, not future states available at 150 seconds. Rollout minus single-step isolates a prediction-path difference, not a causal engine attribution. Existing eligibility retained, including unscored transition windows. No refit or margin selection.'}
    (out/'REPORT.json').write_text(json.dumps({**report,'windows':details},indent=2))
    print('=== CORE_1918_MATCHED_SERVICE_ERROR ===');print(json.dumps(report))
    for r in details:
        if 'r01_001918_p300' in r['run']:print('FAILURE_WINDOW='+json.dumps(r))
    print('REPORT_JSON='+str(out/'REPORT.json'))
if __name__=='__main__':main(*map(Path,sys.argv[1:]))

