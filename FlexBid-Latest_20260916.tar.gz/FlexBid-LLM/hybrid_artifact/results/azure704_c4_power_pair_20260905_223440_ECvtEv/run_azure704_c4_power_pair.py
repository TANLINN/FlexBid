#!/usr/bin/env python3
"""Compare C4 power policies on the selected higher-load Azure Code episode."""
from __future__ import annotations

import argparse
import asyncio
from bisect import bisect_right
import copy
import csv
import importlib.util
import json
import math
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time


EPISODE_ID = "azure_code:azure-001704"
TEMPLATE_EPISODE_ID = "azure_code:azure-001768"
WARMUP_S = 150.0
HORIZON_S = 1800.0
DURATION_S = WARMUP_S + HORIZON_S
COHORT_JOBS = 280
BATCH_CONCURRENCY = 4
EVENT_BATCH_CONCURRENCY = 4
EVENT_POWER_CAP_W = 300.0
PROMPT_TOKENS = 8192
OUTPUT_TOKENS = 1024
ARRIVAL_SCALE = 16.0
ADMISSION_S = 150.0
RECOVERY_S = 450.0
DRAIN_S = 900.0
SOURCE_REPORT = "CHUNK2048_PRIORITY_C6_RECOVERY_FEASIBILITY_REPORT.json"


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_rows(path):
    with Path(path).open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False,
                                    allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    position = (len(values) - 1) * q
    left = int(position)
    right = min(left + 1, len(values) - 1)
    return values[left] * (1 - (position - left)) + values[right] * (position - left)


def latency_summary(rows, ttft_slo, tpot_slo):
    good = [r for r in rows if r.get("error") is None]
    ttft = [float(r["ttft_ms"]) for r in good if r.get("ttft_ms") is not None]
    tpot = [float(r["mean_tpot_ms"]) for r in good if r.get("mean_tpot_ms") is not None]
    missing_ttft = sum(r.get("ttft_ms") is None for r in good)
    missing_tpot = sum(int(r.get("completion_tokens") or 0) > 1
                       and r.get("mean_tpot_ms") is None for r in good)
    p95, p99 = quantile(ttft, .95), quantile(tpot, .99)
    normalized = [float(r["token_normalized_tpot_ms"]) for r in good
                  if r.get("token_normalized_tpot_ms") is not None]
    return {
        "requests": len(rows), "errors": len(rows) - len(good),
        "load_shed": sum(r.get("status_code") == 429 for r in rows),
        "ttft_samples": len(ttft), "request_mean_stream_gap_samples": len(tpot),
        "missing_ttft": missing_ttft, "missing_mean_stream_gap": missing_tpot,
        "ttft_p95_ms": p95, "request_mean_stream_gap_p99_ms": p99,
        "token_normalized_tpot_p99_ms_diagnostic": quantile(normalized, .99),
        "token_normalized_tpot_samples": len(normalized),
        "requests_with_mean_stream_gap_over_slo": sum(x > tpot_slo for x in tpot),
        "observed_slo_safe": bool(rows) and len(rows) == len(good)
        and not missing_ttft and not missing_tpot and p95 is not None
        and p99 is not None and p95 <= ttft_slo and p99 <= tpot_slo,
    }


def reconcile_source(source):
    """Exercise the saved-data interface before using it for a longer run."""
    saved = read_json(source / SOURCE_REPORT)
    protocol = read_json(source / "cell/PRIORITY_RECOVERY_PROTOCOL.json")
    start, end = int(protocol["recovery_wall_ns"]), int(protocol["end_wall_ns"])
    rows = [r for r in read_rows(source / "cell/online.jsonl")
            if start <= int(r["dispatch_wall_time_ns"]) < end]
    result = latency_summary(rows, 2000.0, 100.0)
    batches = [r for r in read_rows(source / "cell/batch.jsonl")
               if start <= int(r["completion_wall_time_ns"]) < end
               and r.get("error") is None]
    actual = {
        "requests": len(rows),
        "ttft_p95_ms": result["ttft_p95_ms"],
        "tpot_p99_ms": result["request_mean_stream_gap_p99_ms"],
        "batch_tokens": sum(int(r.get("completion_tokens") or 0) for r in batches),
    }
    expected = {k: saved["recovery_online"][k] for k in
                ("requests", "ttft_p95_ms", "tpot_p99_ms")}
    expected["batch_tokens"] = saved["recovery_batch_tokens"]
    differences = {k: {"replayed": actual[k], "saved": expected[k]}
                   for k in expected if actual[k] is None or not math.isclose(
                       float(actual[k]), float(expected[k]), rel_tol=1e-10, abs_tol=1e-6)}
    if differences:
        raise ValueError("saved-report replay differs: " + json.dumps(differences))
    return actual


def job_definitions(count=COHORT_JOBS):
    return [{"job_id": f"cohort-{i:06d}", "prompt_identity": f"cohort:{i:06d}",
             "prompt_tokens": PROMPT_TOKENS, "max_output_tokens": OUTPUT_TOKENS,
             "release_offset_s": WARMUP_S, "deadline_offset_s": DURATION_S}
            for i in range(count)]


async def measure_completion(client, api_base, model, prompt, output_tokens, kind, source):
    """Retain the legacy stream-gap metric and record a usage-normalized companion."""
    began = time.perf_counter_ns()
    dispatch = time.time_ns()
    first = last = None
    gaps, tokens, status, error, text_events = [], 0, None, None, 0
    payload = {"model": model, "prompt": prompt, "max_tokens": int(output_tokens),
               "temperature": 0.0, "ignore_eos": True, "stream": True,
               "stream_options": {"include_usage": True}}
    try:
        async with client.stream("POST", api_base.rstrip("/") + "/completions", json=payload,
                                 headers={"X-FlexBid-Class": kind, "X-FlexBid-Source": source}) as response:
            status = response.status_code
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data = line[6:]
                if data == "[DONE]":
                    break
                message = json.loads(data)
                usage = message.get("usage")
                if usage:
                    tokens = int(usage.get("completion_tokens") or tokens)
                choices = message.get("choices") or []
                if choices and choices[0].get("text"):
                    now = time.perf_counter_ns()
                    if first is None:
                        first = now
                    if last is not None:
                        gaps.append((now - last) / 1e6)
                    last = now
                    text_events += 1
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    completed = time.perf_counter_ns()
    normalized = (last - first) / 1e6 / (tokens - 1) \
        if first is not None and last is not None and text_events > 1 and tokens > 1 else None
    return {"dispatch_wall_time_ns": dispatch,
            "completion_wall_time_ns": dispatch + completed - began,
            "ttft_ms": (first - began) / 1e6 if first is not None else None,
            "mean_tpot_ms": sum(gaps) / len(gaps) if gaps else None,
            "max_tpot_ms": max(gaps) if gaps else None,
            "token_normalized_tpot_ms": normalized, "nonempty_sse_text_events": text_events,
            "e2e_ms": (completed - began) / 1e6, "completion_tokens": tokens,
            "status_code": status, "error": error}


async def sleep_until(target_mono):
    while True:
        remaining = target_mono - time.perf_counter()
        if remaining <= 0:
            return
        await asyncio.sleep(remaining)


async def execute_requests(online, jobs, protocol, request, emit,
                           concurrency=BATCH_CONCURRENCY):
    """Each job is attempted once; unstarted and late jobs remain in the ledger."""
    start_ns = int(protocol["start_wall_ns"])
    wall_now = time.time_ns()
    start_mono = time.perf_counter() + (start_ns - wall_now) / 1e9
    duration = float(protocol["duration_s"])
    drain_end = start_mono + duration + float(protocol["drain_s"])
    events = {row["request_id"]: asyncio.Event() for row in online}
    parent_completion = {}
    next_job = 0

    async def invoke(row, request_class):
        dispatch = time.time_ns()
        try:
            timeout = max(.001, drain_end - time.perf_counter())
            return await asyncio.wait_for(request(row, request_class), timeout)
        except asyncio.TimeoutError:
            return {"dispatch_wall_time_ns": dispatch,
                    "completion_wall_time_ns": time.time_ns(), "completion_tokens": 0,
                    "error": "drain_timeout", "status_code": None,
                    "ttft_ms": None, "mean_tpot_ms": None}

    async def online_one(row):
        parent = row.get("parent_request_id")
        if parent in events:
            await events[parent].wait()
        target = start_mono + float(row["arrival_ms"]) / 1000.0
        if parent in parent_completion:
            target = max(target, parent_completion[parent]
                         + float(row.get("tool_delay_ms") or 0) / 1000.0)
        await sleep_until(min(target, drain_end))
        if time.perf_counter() >= drain_end:
            metric = {"dispatch_wall_time_ns": None, "completion_wall_time_ns": None,
                      "completion_tokens": 0, "error": "not_dispatched_before_drain_end",
                      "status_code": None, "ttft_ms": None, "mean_tpot_ms": None}
        else:
            metric = await invoke(row, "online")
        clean = {k: v for k, v in row.items() if k != "prompt_token_ids"}
        clean.update(metric)
        clean["scheduled_wall_time_ns"] = start_ns + int(float(row["arrival_ms"]) * 1e6)
        emit("online", clean)
        parent_completion[row["request_id"]] = time.perf_counter()
        events[row["request_id"]].set()

    async def batch_worker(worker_index):
        nonlocal next_job
        release_s = float(protocol["cohort_release_offset_s"])
        admission_s = max(release_s, float(protocol["batch_admission_offset_s"]))
        if worker_index >= int(protocol["event_batch_concurrency"]):
            admission_s = max(admission_s, float(protocol["recovery_start_offset_s"]))
        await sleep_until(start_mono + admission_s)
        while next_job < len(jobs):
            if time.perf_counter() >= start_mono + duration:
                break
            row = jobs[next_job]
            next_job += 1
            metric = await invoke(row, "batch")
            clean = {k: v for k, v in row.items() if k != "prompt_token_ids"}
            clean.update(metric)
            clean["job_status"] = "finished_attempt"
            emit("batch", clean)

    await asyncio.gather(*(online_one(row) for row in online),
                         *(batch_worker(index) for index in range(concurrency)))
    for row in jobs[next_job:]:
        clean = {k: v for k, v in row.items() if k != "prompt_token_ids"}
        clean.update(job_status="not_started_by_deadline", dispatch_wall_time_ns=None,
                     completion_wall_time_ns=None, completion_tokens=0,
                     status_code=None, error=None)
        emit("batch", clean)


def workload_main(output):
    import httpx

    settings = read_json(output / "workload.json")
    reference = Path(settings["input_root"])
    online, jobs = saved_workload(reference)
    for filename in ("online_workload.jsonl", "batch_jobs.jsonl"):
        shutil.copyfile(reference / filename, output / filename)
    write_json(output / "workload_ready.json", {
        "online_requests": len(online), "cohort_jobs": len(jobs),
        "cohort_tokens": sum(r["max_output_tokens"] for r in jobs),
        "input_root": str(reference), "exact_saved_inputs_reused": True,
    })
    timeout = time.monotonic() + 300
    while not (output / "protocol.json").exists():
        if time.monotonic() > timeout:
            raise TimeoutError("launcher did not provide the experiment start time")
        time.sleep(.1)
    protocol = read_json(output / "protocol.json")

    async def run():
        with (output / "online.jsonl").open("w", encoding="utf-8") as on, \
                (output / "batch.jsonl").open("w", encoding="utf-8") as ba:
            def emit(kind, row):
                stream = on if kind == "online" else ba
                stream.write(json.dumps(row) + "\n")
                stream.flush()
            async with httpx.AsyncClient(
                timeout=None, headers={"Authorization": "Bearer EMPTY"},
                limits=httpx.Limits(max_connections=2048, max_keepalive_connections=256),
            ) as client:
                async def request(row, kind):
                    return await measure_completion(
                        client, settings["api_base"], settings["model"],
                        row["prompt_token_ids"], row["max_output_tokens"], kind,
                        settings["source"] if kind == "online" else "batch")
                await execute_requests(online, jobs, protocol, request, emit)
    asyncio.run(run())
    write_json(output / "workload_complete.json", {"status": "complete"})


def saved_workload(reference):
    online = read_rows(reference / "online_workload.jsonl")
    jobs = read_rows(reference / "batch_jobs.jsonl")
    ids = [r["request_id"] for r in online]
    if len(set(ids)) != len(ids):
        raise ValueError("online request IDs are not unique")
    rank = {key: i for i, key in enumerate(ids)}
    for i, row in enumerate(online):
        parent = row.get("parent_request_id")
        if parent in rank and rank[parent] >= i:
            raise ValueError("trace has a forward or cyclic parent dependency")
        if not 0 <= float(row["arrival_ms"]) < DURATION_S * 1000:
            raise ValueError("saved online request is outside the experiment horizon")
        if not row["prompt_token_ids"]:
            raise ValueError("saved online request has no token array")
    definitions = job_definitions()
    if len(jobs) != len(definitions):
        raise ValueError("saved cohort has a different job count")
    for row, definition in zip(jobs, definitions):
        if any(row.get(k) != v for k, v in definition.items()):
            raise ValueError("saved cohort job differs: " + definition["job_id"])
        if len(row["prompt_token_ids"]) != PROMPT_TOKENS:
            raise ValueError("saved batch prompt length differs")
    return online, jobs


def cohort_summary(jobs, ledger, protocol):
    by_id = {r["job_id"]: r for r in ledger}
    if len(by_id) != len(ledger) or set(by_id) != {r["job_id"] for r in jobs}:
        raise ValueError("batch ledger must contain each planned job exactly once")
    start_ns = int(protocol["start_wall_ns"])
    on_time, late, unfinished, total = [], [], [], 0
    for job in jobs:
        row = by_id[job["job_id"]]
        finish = row["completion_wall_time_ns"]
        begin = row["dispatch_wall_time_ns"]
        tokens = int(row.get("completion_tokens") or 0)
        complete = row.get("error") is None and finish is not None \
            and row.get("status_code") == 200 and tokens == job["max_output_tokens"]
        release = start_ns + int(job["release_offset_s"] * 1e9)
        deadline = start_ns + int(job["deadline_offset_s"] * 1e9)
        if begin is not None and int(begin) < release:
            raise ValueError("batch job dispatched before release: " + job["job_id"])
        if complete and begin is not None and release <= int(begin) <= int(finish) <= deadline:
            on_time.append(job["job_id"])
            total += tokens
        elif complete:
            late.append(job["job_id"])
        else:
            unfinished.append(job["job_id"])
    return {"planned_jobs": len(jobs), "planned_tokens": sum(j["max_output_tokens"] for j in jobs),
            "jobs_completed_on_time": len(on_time), "tokens_completed_on_time": total,
            "jobs_completed_late": len(late), "jobs_unfinished_or_failed": len(unfinished),
            "late_job_ids": late, "unfinished_or_failed_job_ids": unfinished,
            "all_jobs_completed_by_deadline": len(on_time) == len(jobs)}


def cohort_timing(output):
    protocol = read_json(output / "protocol.json")
    jobs = read_rows(output / "batch_jobs.jsonl")
    ledger = read_rows(output / "batch.jsonl")
    summary = cohort_summary(jobs, ledger, protocol)
    start = int(protocol["start_wall_ns"])
    complete = [r for r in ledger if r.get("status_code") == 200
                and r.get("error") is None
                and int(r.get("completion_tokens") or 0) == int(r["max_output_tokens"])
                and r.get("completion_wall_time_ns") is not None]
    dispatch = [int(r["dispatch_wall_time_ns"]) for r in ledger
                if r.get("dispatch_wall_time_ns") is not None]
    finishes = [int(r["completion_wall_time_ns"]) for r in complete]
    last = (max(finishes) - start) / 1e9 if finishes else None
    return {
        "first_batch_dispatch_offset_s": (min(dispatch) - start) / 1e9 if dispatch else None,
        "last_completed_job_offset_s": last,
        "all_job_completion_slack_s": DURATION_S - last
        if len(complete) == len(jobs) and last is not None else None,
        "jobs_completed_on_time": summary["jobs_completed_on_time"],
        "tokens_completed_on_time": summary["tokens_completed_on_time"],
        "deadline_token_deficit": summary["planned_tokens"] - summary["tokens_completed_on_time"],
        "jobs_completed_by_offset": {
            str(offset): sum(t <= start + int(offset * 1e9) for t in finishes)
            for offset in (450, 950, 1450, 1650, 1950)},
        "batch_dispatches_during_event": sum(start + 150_000_000_000 <= t
                                             < start + 450_000_000_000 for t in dispatch),
    }


def gpu_series(output):
    start = int(read_json(output / "protocol.json")["start_wall_ns"])
    rows = []
    with (output / "components.csv").open(newline="", encoding="utf-8") as stream:
        for row in csv.DictReader(stream):
            value = row.get("aggregate_gpu_power_w")
            if value not in (None, "") and math.isfinite(float(value)):
                rows.append((int(row["wall_time_ns"]) - start, float(value)))
    rows.sort()
    if any(b[0] <= a[0] for a, b in zip(rows, rows[1:])):
        raise ValueError("GPU sample times are not unique and increasing")
    return rows


def power_window(rows, left_s, right_s):
    """Integrate linear segments at exact boundaries; never extrapolate missing edges."""
    left, right = int(left_s * 1e9), int(right_s * 1e9)
    valid = len(rows) >= 2 and rows[0][0] <= left < right <= rows[-1][0]
    result = {"start_s": left_s, "end_s": right_s, "covered": valid}
    if not valid:
        return {**result, "mean_gpu_w": None, "gpu_energy_wh": None,
                "maximum_sample_gap_s": None}
    times = [r[0] for r in rows]
    index = max(0, bisect_right(times, left) - 1)
    total, maximum_gap = 0.0, 0.0
    while index + 1 < len(rows) and rows[index][0] < right:
        (ta, va), (tb, vb) = rows[index], rows[index + 1]
        a, b = max(ta, left), min(tb, right)
        if b > a:
            pa = va + (vb - va) * (a - ta) / (tb - ta)
            pb = va + (vb - va) * (b - ta) / (tb - ta)
            total += (b - a) / 1e9 * (pa + pb) / 2
            maximum_gap = max(maximum_gap, (tb - ta) / 1e9)
        index += 1
    return {**result, "mean_gpu_w": total / (right_s - left_s),
            "gpu_energy_wh": total / 3600, "maximum_sample_gap_s": maximum_gap}


def paired_comparison(reference, output):
    original, treatment = gpu_series(reference), gpu_series(output)
    windows = []
    for index in range(10):
        left, right = 150 + index * 30, 180 + index * 30
        a, b = power_window(original, left, right), power_window(treatment, left, right)
        windows.append({"window": index, "reference": a, "treatment": b,
                        "paired_reduction_w": a["mean_gpu_w"] - b["mean_gpu_w"]
                        if a["covered"] and b["covered"] else None})
    stages = {}
    for name, left, right in (("event", 150, 450), ("recovery", 450, 1950),
                               ("full_horizon", 150, 1950)):
        a, b = power_window(original, left, right), power_window(treatment, left, right)
        stages[name] = {"reference": a, "treatment": b,
                       "energy_saved_wh": a["gpu_energy_wh"] - b["gpu_energy_wh"]
                       if a["covered"] and b["covered"] else None}
    differences = [r["paired_reduction_w"] for r in windows]
    all_covered = all(v is not None for v in differences)
    old_report = read_json(reference / "REPORT.json")
    return {
        "reference_run": str(reference), "power_boundary": "aggregate_gpu_power_w",
        "comparison": "no-curtailment C4 and event power capping with the same saved workload, aligned by relative time",
        "event_30s_windows": windows,
        "all_event_windows_covered": all_covered,
        "minimum_paired_window_reduction_w": min(differences) if all_covered else None,
        "all_paired_event_windows_positive": all(v > 0 for v in differences)
        if all_covered else None,
        "stages": stages,
        "reference_cohort": cohort_timing(reference),
        "treatment_cohort": cohort_timing(output),
        "reference_online_evaluation": old_report["online_evaluation"],
        "reference_online_recovery": old_report["online_recovery_reference"],
        "offered_bid_w": None,
        "interpretation": "Retrospective paired GPU power differences; no prospective offer or delivery guarantee.",
    }


def client_batch_phase_counts(ledger, protocol):
    start = int(protocol["start_wall_ns"])
    release = float(protocol["cohort_release_offset_s"])
    recovery = float(protocol["recovery_start_offset_s"])
    duration = float(protocol["duration_s"])
    result = {}
    for phase, left_s, right_s in (("event", release, recovery), ("recovery", recovery, duration)):
        left, right = start + int(left_s * 1e9), start + int(right_s * 1e9)
        events, dispatches = [], 0
        for row in ledger:
            begin = row.get("dispatch_wall_time_ns")
            if begin is None:
                continue
            begin = int(begin)
            finish = row.get("completion_wall_time_ns")
            finish = int(finish) if finish is not None else right
            dispatches += int(left <= begin < right)
            if finish <= left or begin >= right or finish <= begin:
                continue
            events += [(max(left, begin), 1), (min(right, finish), -1)]
        active, maximum = 0, 0
        for _, delta in sorted(events):
            active += delta
            maximum = max(maximum, active)
        result[phase] = {"maximum_client_batch_inflight": maximum, "batch_dispatches": dispatches}
    return result


def analyze(output, config):
    protocol = read_json(output / "protocol.json")
    online = read_rows(output / "online.jsonl")
    planned_online = read_rows(output / "online_workload.jsonl")
    if len({r["request_id"] for r in online}) != len(online) or \
            {r["request_id"] for r in online} != {r["request_id"] for r in planned_online}:
        raise ValueError("online ledger does not match planned requests")
    batch = cohort_summary(read_rows(output / "batch_jobs.jsonl"),
                           read_rows(output / "batch.jsonl"), protocol)
    slo = config["slos"]["default"]
    ttft_slo, tpot_slo = float(slo["ttft_ms"]), float(slo["tpot_ms"])
    start_ns, deadline_ns = int(protocol["start_wall_ns"]), int(protocol["deadline_wall_ns"])
    phases = [("warmup", 0, 150), ("event_time_reference", 150, 450),
              ("recovery_early", 450, 950), ("recovery_middle", 950, 1450),
              ("recovery_late", 1450, 1950)]
    summaries = {}
    for name, left, right in phases:
        rows = [r for r in online if left * 1000 <= float(r["arrival_ms"]) < right * 1000]
        summaries[name] = latency_summary(rows, ttft_slo, tpot_slo)
    evaluation = [r for r in online if float(r["arrival_ms"]) >= WARMUP_S * 1000]
    overall = latency_summary(evaluation, ttft_slo, tpot_slo)
    recovery = latency_summary([r for r in online if float(r["arrival_ms"]) >= 450_000],
                               ttft_slo, tpot_slo)
    invalid_outputs = sum(r.get("error") is None and
                          int(r.get("completion_tokens") or 0) != int(r["max_output_tokens"])
                          for r in evaluation)
    late_dispatches = sum(r.get("dispatch_wall_time_ns") is not None and
                          int(r["dispatch_wall_time_ns"]) >= deadline_ns for r in online)
    interval_power = []
    with (output / "components.csv").open(newline="", encoding="utf-8") as stream:
        for r in csv.DictReader(stream):
            stamp = int(r["wall_time_ns"])
            value = r.get("aggregate_gpu_power_w")
            if start_ns + int(WARMUP_S * 1e9) <= stamp <= deadline_ns \
                    and value not in (None, "") and math.isfinite(float(value)):
                interval_power.append((stamp, float(value)))
    interval_power.sort()
    integral = sum((b[0] - a[0]) / 1e9 * (a[1] + b[1]) / 2
                   for a, b in zip(interval_power, interval_power[1:]))
    span = (interval_power[-1][0] - interval_power[0][0]) / 1e9 if len(interval_power) > 1 else 0
    max_gap = max(((b[0] - a[0]) / 1e9 for a, b in
                   zip(interval_power, interval_power[1:])), default=None)
    states = read_rows(output / "gateway_state.jsonl")
    checks = {
        "workload_process_succeeded": True,
        "all_jobs_completed_by_deadline": batch["all_jobs_completed_by_deadline"],
        "evaluation_online_slo_safe": overall["observed_slo_safe"],
        "event_reference_online_slo_safe": summaries["event_time_reference"]["observed_slo_safe"],
        "recovery_reference_online_slo_safe": recovery["observed_slo_safe"],
        "evaluation_output_lengths_complete": invalid_outputs == 0,
    }
    timing = cohort_timing(output)
    concurrency = client_batch_phase_counts(read_rows(output / "batch.jsonl"), protocol)
    checks["event_client_concurrency_within_limit"] = concurrency["event"]["maximum_client_batch_inflight"] <= EVENT_BATCH_CONCURRENCY
    checks["recovery_client_concurrency_within_limit"] = concurrency["recovery"]["maximum_client_batch_inflight"] <= BATCH_CONCURRENCY
    service_and_deadline_pass = all(checks.values())
    pairs = {"same_episode_c4": paired_comparison(Path(protocol["reference_run"]), output)} \
        if protocol["reference_run"] else {}
    cap_audit = cap_observations(output, config["hardware"]["gpu_indices"], protocol["event_power_cap_w"])
    checks["power_cap_sequence_observed"] = cap_audit["requested_sequence_observed"]
    checks["configured_gpu_caps_matched"] = cap_audit["all_configured_gpu_caps_matched_at_transitions"]
    if pairs:
        checks["all_event_windows_positive_against_same_episode_c4"] = all(
            pair["all_paired_event_windows_positive"] is True for pair in pairs.values())
    report = {
        "status": "AZURE704_C4_COHORT_MEASURED",
        "condition": protocol["condition"],
        "event_power_cap_w": protocol["event_power_cap_w"],
        "joint_pass_observed": all(checks.values()), "checks": checks,
        "service_and_deadline_pass_observed": service_and_deadline_pass,
        "episode_id": EPISODE_ID, "source_run": protocol["source_run"],
        "phase_request_assignment": "scheduled arrivals; delayed dispatches are retained",
        "arrival_time_multiplier": ARRIVAL_SCALE,
        "gateway_capacity": f"R4/C4; P{protocol['event_power_cap_w']:g} event, P400 warmup/recovery", "max_num_batched_tokens": 2048,
        "power_cap_observations": cap_audit,
        "batch_admission": "four client workers from 150 s until all jobs finish or the 1950 s deadline",
        "client_batch_concurrency_schedule": [
            {"start_s": ADMISSION_S, "end_s": RECOVERY_S, "limit": EVENT_BATCH_CONCURRENCY},
            {"start_s": RECOVERY_S, "end_s": DURATION_S, "limit": BATCH_CONCURRENCY}],
        "client_batch_phase_counts": concurrency,
        "online_priority": 0, "batch_priority": 10,
        "timeline_s": {"online_warmup": WARMUP_S, "cohort_service_horizon": HORIZON_S},
        "latency_measurement": "existing client's per-request mean nonempty SSE-text gap",
        "slos": {"ttft_p95_ms": ttft_slo, "request_mean_stream_gap_p99_ms": tpot_slo},
        "online_evaluation": overall, "online_recovery_reference": recovery,
        "online_by_scheduled_phase": summaries,
        "online_dispatches_at_or_after_deadline": late_dispatches,
        "evaluation_incomplete_output_lengths": invalid_outputs,
        "batch": batch,
        "gpu_power": {"boundary": "aggregate_gpu_power_w", "samples": len(interval_power),
                      "observed_span_s": span, "maximum_sample_gap_s": max_gap,
                      "mean_w_over_observed_span": integral / span if span else None,
                      "energy_wh_over_observed_span": integral / 3600 if span else None},
        "gateway_state_samples": len(states),
        "maximum_inflight_online": max((sum(r["inflight_online"]) for r in states), default=None),
        "maximum_inflight_batch": max((sum(r["inflight_batch"]) for r in states), default=None),
        "cohort_timing": timing,
        "paired_comparisons": pairs,
        "external_commitment": False,
        "interpretation": "One cell on a different development workload; fixed task quality, service thresholds and cohort deadline.",
    }
    write_json(output / "REPORT.json", report)
    write_json(output / "COLLECTION_COMPLETE.json", {"status": report["status"]})
    return report


def load_helper(source):
    path = source / "run_chunk2048_priority_c6_recovery_pilot.py"
    spec = importlib.util.spec_from_file_location("saved_priority_pilot", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def select_recovery_action(actions, power_cap_w=400):
    matches = [action for action in actions
               if (action.online_replicas, action.batch_concurrency, action.power_cap_w)
               == (4, BATCH_CONCURRENCY, power_cap_w)
               and tuple(action.resolved_online_replica_ids()) == (0, 1, 2, 3)]
    if len(matches) != 1:
        raise ValueError(f"expected one configured R4/C4/P{power_cap_w} action on replicas 0,1,2,3")
    return matches[0]


class CapSchedule:
    """Apply each current phase once; retain actual actuation boundary times."""

    def __init__(self, start_mono, baseline, event, enact, emit,
                 monotonic=time.monotonic, wall_ns=time.time_ns):
        self.start_mono = start_mono
        self.baseline, self.event = baseline, event
        self.enact, self.emit = enact, emit
        self.monotonic, self.wall_ns = monotonic, wall_ns
        self.phase = None
        self.action = baseline

    def tick(self):
        elapsed = self.monotonic() - self.start_mono
        if elapsed < WARMUP_S:
            phase, desired, boundary = "warmup", self.baseline, 0.0
        elif elapsed < RECOVERY_S:
            phase, desired, boundary = "event", self.event, WARMUP_S
        else:
            phase, desired, boundary = "recovery", self.baseline, RECOVERY_S
        if phase != self.phase:
            began_ns = self.wall_ns()
            receipt = self.enact(desired)
            finished = self.monotonic() - self.start_mono
            self.emit({"phase": phase, "planned_boundary_s": boundary,
                       "begin_offset_s": elapsed, "end_offset_s": finished,
                       "begin_wall_ns": began_ns, "end_wall_ns": self.wall_ns(),
                       "action": desired.as_dict(), **receipt})
            self.phase, self.action = phase, desired
        return self.action

    def sleep_duration(self, deadline_mono):
        now = self.monotonic()
        future = [self.start_mono + offset for offset in (WARMUP_S, RECOVERY_S)
                  if self.start_mono + offset > now]
        return max(0.0, min([1.0, deadline_mono - now] + [t - now for t in future]))


def cap_observations(output, gpu_indices, event_power_cap_w):
    rows = read_rows(output / "power_actions.jsonl")
    expected = [("warmup", 400.0), ("event", event_power_cap_w), ("recovery", 400.0)]
    sequence = [(r["phase"], float(r["action"]["power_cap_w"])) for r in rows]
    all_enforced = bool(rows) and all(
        set(map(int, r["enforced_power_caps_w"])) == set(gpu_indices)
        and all(abs(float(v) - float(r["action"]["power_cap_w"])) <= .6
                for v in r["enforced_power_caps_w"].values()) for r in rows)
    return {"transitions": rows, "requested_sequence_observed": sequence == expected,
            "all_configured_gpu_caps_matched_at_transitions": all_enforced,
            "timing_note": "Fixed 150/450 s analysis boundaries include actuation delays; no window is shifted."}


def run_measurement(project, template, input_root, output, event_power_cap_w, reference=None):
    import fcntl
    import yaml
    from flexbid_hybrid.config import load_config
    from flexbid_hybrid.mpc import build_action_lattice
    from flexbid_hybrid.pilot import apply_control
    from flexbid_hybrid.power import PowerCapManager
    from flexbid_hybrid.service import get_json, stop_process

    template_protocol = read_json(template / "protocol.json")
    template_report = read_json(template / "REPORT.json")
    if template_report["status"] != "NO_CURTAILMENT_COHORT_MEASURED":
        raise ValueError("hardware template is not the completed no-curtailment cohort run")
    source = Path(template_protocol["source_run"])
    helper = load_helper(source)
    config = copy.deepcopy(load_config(template / "config.yaml"))
    if int(config["runtime"]["max_num_batched_tokens"]) != 2048:
        raise ValueError("source configuration is not the measured chunk2048 configuration")
    if int(config["workloads"]["batch_prompt_tokens"]) != PROMPT_TOKENS or \
            int(config["workloads"]["batch_output_tokens"]) != OUTPUT_TOKENS:
        raise ValueError("source batch lengths differ from the specified 8K/1K workload")
    if template_report["episode_id"] != TEMPLATE_EPISODE_ID:
        raise ValueError("hardware-template episode differs")
    saved_workload(input_root)
    workload_info = read_json(input_root / "INPUT_SUMMARY.json")
    if workload_info["episode_id"] != EPISODE_ID:
        raise ValueError("prepared workload episode differs")
    if reference is not None:
        reference_report = read_json(reference / "REPORT.json")
        if reference_report["episode_id"] != EPISODE_ID or reference_report["event_power_cap_w"] != 400:
            raise ValueError("power comparison requires the same episode's measured C4/P400 cell")
    config["hardware"]["control_file"] = str(output / "control.json")
    config["runtime"]["priority_gateway_module"] = str(output / "priority_gateway.py")
    config.setdefault("paths", {})["results_root"] = str(output)
    config["experiment_name"] = output.name
    shutil.copyfile(template / "priority_gateway.py", output / "priority_gateway.py")
    (output / "config.yaml").write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")
    actions = build_action_lattice(config["dynamic_controller"]["action_lattice"])
    action = select_recovery_action(actions)
    event_action = select_recovery_action(actions, event_power_cap_w)
    model, runtime = config["model"], config["runtime"]
    base = f"http://127.0.0.1:{runtime['gateway_port']}"
    write_json(output / "workload.json", {
        "model": model["name"], "api_base": base + "/v1",
        "source": workload_info["source"], "input_root": str(input_root),
    })
    write_json(output / "EXPERIMENT_PLAN.json", {
        "episode_id": EPISODE_ID, "gateway_capacity": "R4/C4", "cohort_jobs": COHORT_JOBS,
        "power_cap_schedule_w": {"warmup": 400, "event": event_power_cap_w, "recovery": 400},
        "input_root": str(input_root), "hardware_template_run": str(template),
        "cohort_tokens": COHORT_JOBS * OUTPUT_TOKENS,
        "release_offset_s": WARMUP_S, "deadline_offset_s": DURATION_S,
        "batch_admission_offset_s": ADMISSION_S,
        "event_batch_concurrency": EVENT_BATCH_CONCURRENCY,
        "recovery_batch_concurrency": BATCH_CONCURRENCY,
        "recovery_start_offset_s": RECOVERY_S,
        "arrival_time_multiplier": ARRIVAL_SCALE, "reference_run": str(reference) if reference else None,
        "workload_inputs": "exact saved online and batch token arrays; no regeneration or rescaling",
        "external_commitment": False, "automatic_retry": False,
    })
    lock_path = project / "results/chunk2048_priority_c6_recovery_pilot.lock"
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        active = helper.active_collectors(project)
        if active:
            raise RuntimeError("another FlexBid workload is active: " + repr(active))
        with PowerCapManager(config["hardware"]["gpu_indices"]) as power_caps:
            power_caps.set_all(action.power_cap_w)
            apply_control(Path(config["hardware"]["control_file"]), action,
                          len(model["replicas"]), int(runtime["online_concurrency"]))
            with helper.PriorityServiceGroup(project, config, output / "service_logs") as services:
                services.wait_idle()
                services.reset_caches()
                services.reset_state()
                get_json(base + "/flexbid/state")

                def enact(desired):
                    enforced = power_caps.set_all(desired.power_cap_w)
                    control = apply_control(Path(config["hardware"]["control_file"]), desired,
                                            len(model["replicas"]), int(runtime["online_concurrency"]))
                    return {"enforced_power_caps_w": enforced, "control": control}

                handles, driver, telemetry = [], None, None
                try:
                    handle = (output / "logs/workload.log").open("w", encoding="utf-8")
                    handles.append(handle)
                    driver = subprocess.Popen([
                        sys.executable, "-B", "-u", str(Path(__file__).resolve()),
                        "--project", str(project), "--output", str(output), "--workload",
                    ], cwd=project, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
                    ready_limit = time.monotonic() + 240
                    while not (output / "workload_ready.json").exists():
                        if driver.poll() is not None:
                            raise RuntimeError("workload preparation failed; see logs/workload.log")
                        if time.monotonic() > ready_limit:
                            raise TimeoutError("workload preparation exceeded 240 seconds")
                        time.sleep(.2)
                    handle = (output / "logs/telemetry.log").open("w", encoding="utf-8")
                    handles.append(handle)
                    telemetry = subprocess.Popen([
                        sys.executable, "-B", "-m", "flexbid_hybrid.telemetry", "--output",
                        str(output / "components.csv"), "--interval-ms",
                        str(config["hardware"]["telemetry_interval_ms"]),
                    ], cwd=project, stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
                    start_ns = time.time_ns() + 3_000_000_000
                    protocol = {
                        "start_wall_ns": start_ns, "deadline_wall_ns": start_ns + int(DURATION_S * 1e9),
                        "duration_s": DURATION_S, "cohort_release_offset_s": WARMUP_S,
                        "batch_admission_offset_s": ADMISSION_S,
                        "event_batch_concurrency": EVENT_BATCH_CONCURRENCY,
                        "recovery_start_offset_s": RECOVERY_S,
                        "recovery_batch_concurrency": BATCH_CONCURRENCY,
                        "drain_s": DRAIN_S, "source_run": str(source), "reference_run": str(reference) if reference else None,
                        "input_root": str(input_root), "hardware_template_run": str(template),
                        "condition": "c4_p400" if event_power_cap_w == 400 else "c4_event_p300",
                        "event_power_cap_w": event_power_cap_w,
                        "power_cap_schedule_w": {"warmup": 400, "event": event_power_cap_w, "recovery": 400},
                    }
                    write_json(output / "protocol.json", protocol)
                    print("MEASUREMENT_STARTED " + json.dumps(read_json(output / "workload_ready.json")), flush=True)
                    deadline_mono = time.monotonic() + (protocol["deadline_wall_ns"] - time.time_ns()) / 1e9
                    with (output / "gateway_state.jsonl").open("w", encoding="utf-8") as stream, \
                            (output / "power_actions.jsonl").open("w", encoding="utf-8") as cap_stream:
                        def emit_cap(row):
                            cap_stream.write(json.dumps(row) + "\n")
                            cap_stream.flush()
                        schedule = CapSchedule(deadline_mono - DURATION_S, action, event_action, enact, emit_cap)
                        while time.monotonic() < deadline_mono:
                            if driver.poll() is not None and driver.returncode != 0:
                                raise RuntimeError("workload failed; see logs/workload.log")
                            if telemetry.poll() is not None:
                                raise RuntimeError("telemetry exited before measurement end")
                            if any(p.poll() is not None for p in services.processes):
                                raise RuntimeError("inference service exited; see service_logs")
                            current_action = schedule.tick()
                            observed = get_json(base + "/flexbid/state")
                            snapshot = {k: observed[k] for k in (
                                "inflight", "inflight_online", "inflight_batch", "online_waiting",
                                "batch_waiting", "completed_online", "completed_batch")}
                            stream.write(json.dumps({"wall_time_ns": time.time_ns(),
                                                     "action": current_action.name, **snapshot}) + "\n")
                            stream.flush()
                            time.sleep(schedule.sleep_duration(deadline_mono))
                    print("MEASUREMENT_ENDED; collecting outstanding request outcomes", flush=True)
                    if driver.wait(timeout=DRAIN_S + 30) != 0:
                        raise RuntimeError("workload failed; see logs/workload.log")
                    if not (output / "workload_complete.json").is_file():
                        raise RuntimeError("workload completion record is missing")
                finally:
                    try:
                        try:
                            restoration = enact(action)
                            write_json(output / "POWER_CAP_RESTORED.json", restoration)
                        finally:
                            if driver is not None and driver.poll() is None:
                                stop_process(driver)
                    finally:
                        if telemetry is not None and telemetry.poll() is None:
                            stop_process(telemetry)
                        for handle in handles:
                            handle.close()
                services.wait_idle()
    return analyze(output, config)


def prepare_inputs(project, template, input_root, materializer_factory=None):
    from flexbid_hybrid.clients import PromptMaterializer, load_trace
    from flexbid_hybrid.config import load_config

    manifest_path = project.parent / "paper_artifact/data/adapted/manifest.json"
    manifest = read_json(manifest_path)
    matches = [row for row in manifest["episodes"] if row["episode_id"] == EPISODE_ID]
    if len(matches) != 1:
        raise ValueError("expected one manifest episode: " + EPISODE_ID)
    episode = matches[0]
    if episode["source"] != "azure_code" or episode["split"] != "test":
        raise ValueError("selected manifest source or split differs")
    trace = Path(episode["path"])
    if not trace.is_absolute():
        trace = (manifest_path.parent / trace).resolve()
    config = load_config(template / "config.yaml")
    factory = materializer_factory or PromptMaterializer
    materializer = factory(config["model"]["tokenizer"])
    online = [row for row in load_trace(trace, ARRIVAL_SCALE, DURATION_S)
              if float(row["arrival_ms"]) < DURATION_S * 1000]
    for row in online:
        row["prompt_token_ids"] = materializer.online_tokens(row)
    input_root.mkdir()
    with (input_root / "online_workload.jsonl").open("w", encoding="utf-8") as stream:
        for row in online:
            stream.write(json.dumps(row) + "\n")
    shutil.copyfile(template / "batch_jobs.jsonl", input_root / "batch_jobs.jsonl")
    online, jobs = saved_workload(input_root)
    bins = [(0, 120), (120, 150), (150, 450), (450, 950), (950, 1450), (1450, 1950)]
    info = {
        "episode_id": EPISODE_ID, "source": episode["source"], "manifest_split": episode["split"],
        "trace": str(trace), "arrival_time_multiplier": ARRIVAL_SCALE,
        "online_requests": len(online), "phase_bins_s": bins,
        "phase_request_counts": [sum(left * 1000 <= float(r["arrival_ms"]) < right * 1000
                                    for r in online) for left, right in bins],
        "batch_jobs": len(jobs), "batch_tokens": sum(r["max_output_tokens"] for r in jobs),
        "batch_input_source": str(template / "batch_jobs.jsonl"),
        "selection": "Previously screened source-median Azure Code episode, chosen before this pair's outcomes.",
        "evidence_scope": "Different workload under the finite-cohort protocol; this episode was used by an older development policy.",
    }
    write_json(input_root / "INPUT_SUMMARY.json", info)
    print("INPUTS_READY=" + json.dumps(info), flush=True)
    return info


def summarize_cell(report):
    event = report["online_by_scheduled_phase"]["event_time_reference"]
    recovery = report["online_recovery_reference"]
    return {
        "condition": report["condition"], "event_power_cap_w": report["event_power_cap_w"],
        "joint_pass_observed": report["joint_pass_observed"],
        "service_and_deadline_pass_observed": report["service_and_deadline_pass_observed"],
        "checks": report["checks"],
        "event_online": event, "recovery_online": recovery,
        "evaluation_online": report["online_evaluation"],
        "batch": report["batch"], "cohort_timing": report["cohort_timing"],
        "client_batch_phase_counts": report["client_batch_phase_counts"],
        "power_cap_sequence_observed": report["power_cap_observations"]["requested_sequence_observed"],
        "cap_transition_offsets_s": [{k: r[k] for k in ("phase", "begin_offset_s", "end_offset_s")}
                                     for r in report["power_cap_observations"]["transitions"]],
    }


def complete_pair(output, info, reference, treatment):
    import filecmp

    folders = {"c4_p400": output / "cells/c4_p400", "c4_event_p300": output / "cells/c4_event_p300"}
    same_inputs = {name: filecmp.cmp(folders["c4_p400"] / name, folders["c4_event_p300"] / name, shallow=False)
                   for name in ("online_workload.jsonl", "batch_jobs.jsonl")}
    pair = treatment["paired_comparisons"]["same_episode_c4"]
    stages = {}
    for name, data in pair["stages"].items():
        stages[name] = {"reference_mean_gpu_w": data["reference"]["mean_gpu_w"],
                        "treatment_mean_gpu_w": data["treatment"]["mean_gpu_w"],
                        "reference_minus_treatment_energy_wh": data["energy_saved_wh"],
                        "reference_covered": data["reference"]["covered"],
                        "treatment_covered": data["treatment"]["covered"],
                        "maximum_sample_gap_s": {key: data[key]["maximum_sample_gap_s"]
                                                  for key in ("reference", "treatment")}}
    result = {
        "status": "AZURE704_C4_POWER_PAIR_MEASURED", "input_summary": info,
        "run_order": ["c4_p400", "c4_event_p300"], "same_saved_inputs": same_inputs,
        "reference_service_and_deadline_pass_observed": reference["service_and_deadline_pass_observed"],
        "treatment_service_and_deadline_pass_observed": treatment["service_and_deadline_pass_observed"],
        "paired_joint_pass_observed": all(same_inputs.values()) and reference["joint_pass_observed"]
                                       and treatment["joint_pass_observed"],
        "cells": {name: {"path": str(folders[name]), **summarize_cell(report)}
                  for name, report in (("c4_p400", reference), ("c4_event_p300", treatment))},
        "power_comparison": {
            "boundary": "aggregate_gpu_power_w",
            "all_event_windows_covered": pair["all_event_windows_covered"],
            "all_event_windows_positive": pair["all_paired_event_windows_positive"],
            "minimum_window_reduction_w": pair["minimum_paired_window_reduction_w"],
            "window_reductions_w": [r["paired_reduction_w"] for r in pair["event_30s_windows"]],
            "stages": stages},
        "external_commitment": False,
        "limitations": ["One fixed-order pair on a previously used development episode.",
                        "If C4/P400 already fails service or deadline, the workload cannot be treated as initially feasible.",
                        "Paired power differences are retrospective, not a prospective offer or statistical guarantee."],
    }
    write_json(output / "REPORT.json", result)
    write_json(output / "COLLECTION_COMPLETE.json", {"status": result["status"]})
    return result


def run_pair(project, template, output):
    input_root = output / "inputs"
    info = prepare_inputs(project, template, input_root)
    write_json(output / "EXPERIMENT_PLAN.json", {
        "episode_id": EPISODE_ID, "hardware_template_run": str(template),
        "run_order": ["c4_p400", "c4_event_p300"], "input_root": str(input_root),
        "event_power_caps_w": [400, 300], "reference_and_recovery_power_cap_w": 400,
        "cohort_jobs": COHORT_JOBS, "release_offset_s": WARMUP_S, "deadline_offset_s": DURATION_S,
        "arrival_time_multiplier": ARRIVAL_SCALE, "batch_concurrency": BATCH_CONCURRENCY,
        "automatic_retry": False, "outcome_based_parameter_updates": False,
    })
    reference = output / "cells/c4_p400"
    treatment = output / "cells/c4_event_p300"
    results = []
    for folder, cap, comparison in ((reference, 400.0, None), (treatment, 300.0, reference)):
        (folder / "logs").mkdir(parents=True)
        print(f"CELL_START={folder.name} EVENT_CAP_W={cap}", flush=True)
        result = run_measurement(project, template, input_root, folder, cap, comparison)
        results.append(result)
        print("CELL_MEASURED=" + json.dumps(summarize_cell(result)), flush=True)
    return complete_pair(output, info, *results)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--template", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workload", action="store_true")
    args = parser.parse_args()
    project, output = args.project.resolve(), args.output.resolve()
    sys.path.insert(0, str(project))
    sys.path.insert(0, str(project / "scripts"))
    if args.workload:
        workload_main(output)
        return
    if args.template is None:
        parser.error("--template is required for the launcher")
    if (output / "REPORT.json").exists():
        print(json.dumps(read_json(output / "REPORT.json"), indent=2))
        return
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f"received signal {signum}")
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        report = run_pair(project, args.template.resolve(), output)
        print("=== AZURE704_C4_POWER_PAIR_RESULT ===", flush=True)
        print(json.dumps(report, indent=2), flush=True)
    except BaseException as exc:
        write_json(output / "COLLECTION_FAILED.json", {
            "status": "AZURE704_C4_POWER_PAIR_FAILED", "error_type": type(exc).__name__,
            "error": str(exc), "automatic_retry": False,
        })
        raise


if __name__ == "__main__":
    main()
