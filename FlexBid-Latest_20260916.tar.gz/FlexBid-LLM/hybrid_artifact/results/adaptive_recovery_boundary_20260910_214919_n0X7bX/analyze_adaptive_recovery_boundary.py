"""Inspect the first recovery decision divergence without replaying later treatment data."""
import argparse
import json
from pathlib import Path

NS = 10**9


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_rows(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def state_at(observations, cutoff_ns, deadline_ns, total, history_ns):
    complete = [r for r in observations if r['complete']
                and r['received_wall_ns'] <= cutoff_ns and r['completion_wall_ns'] <= cutoff_ns]
    recent = [r for r in complete if cutoff_ns - history_ns < r['completion_wall_ns'] <= cutoff_ns]
    remaining, seconds_left = total - len(complete), (deadline_ns - cutoff_ns) / NS
    # This is the same integer comparison as the recorded rule, not an epsilon test.
    balance = len(recent) * (deadline_ns - cutoff_ns) - remaining * history_ns
    decision = ('DEADLINE' if cutoff_ns >= deadline_ns else 'COHORT_COMPLETE' if remaining == 0
                else 'BOOST_C6' if balance < 0 else 'KEEP_C5')
    return {'completed_jobs': len(complete), 'remaining_jobs': remaining,
            'recent_completed_jobs': len(recent), 'recent_jobs_per_min': 60 * len(recent) * NS / history_ns,
            'required_jobs_per_min': 60 * remaining / seconds_left if seconds_left > 0 else None,
            'integer_rate_balance_job_ns': balance,
            'extrapolated_job_balance': balance / history_ns if cutoff_ns < deadline_ns else None,
            'decision': decision,
            'completed_ids': sorted(r['job_id'] for r in complete), 'recent_ids': sorted(r['job_id'] for r in recent)}


def audit_prefix(protocol, rule, jobs, observations, decisions):
    start, deadline = int(protocol['start_wall_ns']), int(protocol['deadline_wall_ns'])
    history_ns = round(float(rule['history_s']) * NS)
    if history_ns <= 0:
        raise ValueError('history must be positive')
    if len({r['job_id'] for r in observations}) != len(observations):
        raise ValueError('duplicate observation IDs')
    first_eligible_ns = start + round(float(protocol['recovery_start_offset_s']) * NS) + history_ns
    rows, stop = [], 'END_OF_RECORDED_DECISIONS'
    for original in decisions:
        actual_ns = int(original['decision_wall_ns'])
        planned_ns = start + round(float(original['planned_decision_offset_s']) * NS)
        if not first_eligible_ns <= planned_ns <= actual_ns:
            raise ValueError('decision time precedes full history or its planned time')
        actual = state_at(observations, actual_ns, deadline, len(jobs), history_ns)
        planned = state_at(observations, planned_ns, deadline, len(jobs), history_ns)
        same_members = all(actual[k] == planned[k] for k in ('completed_ids', 'recent_ids'))
        fixed_counts_balance = (actual['recent_completed_jobs'] * (deadline - planned_ns)
                                - actual['remaining_jobs'] * history_ns)
        divergence = actual['decision'] != planned['decision']
        row = {'planned_s': (planned_ns - start) / NS, 'actual_s': (actual_ns - start) / NS,
               'execution_lateness_us': (actual_ns - planned_ns) / 1000,
               'recorded_decision': original['decision'],
               'recorded_counts_and_decision_match': all(actual[k] == original[k]
                   for k in ('completed_jobs', 'remaining_jobs', 'recent_completed_jobs', 'decision')),
               'same_completed_and_window_membership': same_members,
               'planned_time_balance_with_actual_counts_job_ns': fixed_counts_balance,
               'classification': ('EXACT_PLANNED_TIE_CROSSED_BY_CLOCK_DELAY'
                    if same_members and fixed_counts_balance == 0 and actual['decision'] == 'BOOST_C6'
                    else 'WINDOW_OR_OBSERVATION_MEMBERSHIP_CHANGED' if not same_members
                    else 'SAME_MEMBERSHIP_DIFFERENT_TIME' if divergence else 'NO_DECISION_DIVERGENCE'),
               'actual_time_evaluation': {k: v for k, v in actual.items() if not k.endswith('_ids')},
               'planned_cutoff_diagnostic': {k: v for k, v in planned.items() if not k.endswith('_ids')},
               'completed_membership_symmetric_difference': sorted(set(actual['completed_ids']) ^ set(planned['completed_ids'])),
               'recent_membership_symmetric_difference': sorted(set(actual['recent_ids']) ^ set(planned['recent_ids']))}
        rows.append(row)
        if divergence:
            stop = 'FIRST_DECISION_DIVERGENCE; later observed data cannot establish the alternative trajectory'
            break
        if original['decision'] in ('BOOST_C6', 'COHORT_COMPLETE', 'DEADLINE'):
            stop = 'RECORDED_TERMINAL_DECISION'
            break
    return {'decisions_checked': rows, 'prefix_stop': stop,
            'later_recorded_decisions_not_evaluated': len(decisions) - len(rows),
            'all_checked_records_match': bool(rows) and all(r['recorded_counts_and_decision_match'] for r in rows)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = args.source
    protocol = read_json(source / 'protocol.json')
    report = read_json(source / 'REPORT.json')
    result = audit_prefix(protocol, protocol['adaptive_recovery_rule'], read_rows(source / 'batch_jobs.jsonl'),
                          read_rows(source / 'recovery_observations.jsonl'), read_rows(source / 'recovery_decisions.jsonl'))
    result.update(status='ADAPTIVE_RECOVERY_BOUNDARY_ANALYSIS_COMPLETE', source_run=str(source), gpu_workload_run=False,
                  runtime_policy_changed=False, actual_deadline_or_settlement_windows_changed=False)
    result['measured_conditions'] = []
    for label, value in [*report['fixed_policy_references'].items(), ('adaptive', report)]:
        if 'batch' not in value:
            result['measured_conditions'].append({'condition': label, 'status': 'REFERENCE_UNAVAILABLE'})
            continue
        result['measured_conditions'].append({'condition': label, 'run': value['run'],
            'on_time_jobs': value['batch']['jobs_completed_on_time'],
            'deadline_slack_s': value['cohort_timing']['all_job_completion_slack_s'],
            'evaluation_gpu_energy_wh': value['gpu_power']['stages']['evaluation']['gpu_energy_wh'],
            'service_and_deadline_pass': value['service_and_deadline_pass_observed']})
    result['limitations'] = [
        'The measured service and deadline outcomes remain unchanged. A sensitive trigger does not invalidate the physical measurements.',
        'The original rule already compares integer products. An exact tie can change when actual remaining time is slightly shorter; this is not necessarily floating-point error.',
        'Planned-cutoff diagnostics use only completions received by that cutoff. No observation from later C6 service is used to predict continued C5 performance.',
        'This report does not implement a revised controller, predict its switch time or deadline, or establish an advantage over fixed C6.',
        'Energy values describe separate physical runs over the same 150-1950 s interval; run variation remains.'
    ]
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'REPORT.json').write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    lines = ['=== ADAPTIVE_RECOVERY_BOUNDARY_ANALYSIS ===', 'STATUS=' + result['status'],
             'SOURCE=' + str(source), 'ALL_CHECKED_RECORDS_MATCH=' + str(result['all_checked_records_match'])]
    lines += ['DECISION_BOUNDARY=' + json.dumps(row) for row in result['decisions_checked']]
    lines += ['PREFIX_STOP=' + result['prefix_stop']]
    lines += ['MEASURED_CONDITION=' + json.dumps(row) for row in result['measured_conditions']]
    lines += result['limitations']
    (args.output / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
