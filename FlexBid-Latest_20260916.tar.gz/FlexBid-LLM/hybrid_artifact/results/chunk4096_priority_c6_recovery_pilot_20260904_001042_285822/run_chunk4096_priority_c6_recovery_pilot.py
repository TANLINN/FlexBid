#!/usr/bin/env python3
"""Measure priority-scheduled C6 recovery on one Azure Code development trace."""

from __future__ import annotations

import csv
import fcntl
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import yaml

ROOT = Path("/root/workspace/FlexBid-LLM/hybrid_artifact").resolve()
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from flexbid_hybrid.config import load_config
from flexbid_hybrid.io import atomic_json, read_jsonl
from flexbid_hybrid.mpc import build_action_lattice
from flexbid_hybrid.pilot import apply_control
from flexbid_hybrid.power import PowerCapManager
from flexbid_hybrid.service import (
    ServiceGroup,
    get_json,
    post_json,
    stop_process,
    wait_http,
)
from install_runtime_safety import active_collectors


BASELINE_S = 120.0
LEAD_S = 30.0
EVENT_S = 300.0
RECOVERY_S = 300.0
DURATION_S = BASELINE_S + LEAD_S + EVENT_S + RECOVERY_S
STATE_SAMPLE_S = 1.0
EVALUATION_SCALE = 16.0
ONLINE_PRIORITY = 0
BATCH_PRIORITY = 10
EVENT_ACTION = "mpc_r4_c0_p400"
RECOVERY_ACTION = "mpc_r4_c6_p400"
REQUIRED_RECOVERY_TPS = 286720.0 / 1500.0
EPISODE_ID = "azure_code:azure-001768"


def wait_until(wall_ns: int) -> None:
    while True:
        remaining = (wall_ns - time.time_ns()) / 1e9
        if remaining <= 0:
            return
        time.sleep(min(0.2, max(0.005, remaining / 2)))


def wait_process(process: subprocess.Popen, timeout_s: float) -> int:
    try:
        return process.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        stop_process(process)
        return -9


def percentile(values: list[float], q: float):
    if not values:
        return None
    values = sorted(values)
    position = (len(values) - 1) * q
    left = int(position)
    right = min(left + 1, len(values) - 1)
    fraction = position - left
    return values[left] * (1 - fraction) + values[right] * fraction


def summarize_online(rows: list[dict], start: int, end: int,
                     ttft_slo: float, tpot_slo: float) -> dict:
    selected = [row for row in rows if start <= int(row["dispatch_wall_time_ns"]) < end]
    good = [row for row in selected if row.get("error") is None]
    ttft = [float(row["ttft_ms"]) for row in good if row.get("ttft_ms") is not None]
    tpot = [float(row["mean_tpot_ms"]) for row in good
            if row.get("mean_tpot_ms") is not None]
    p95 = percentile(ttft, 0.95)
    p99 = percentile(tpot, 0.99)
    safe = (
        bool(selected) and len(selected) == len(good) and p95 is not None and p99 is not None
        and p95 <= ttft_slo and p99 <= tpot_slo
    )
    return {
        "requests": len(selected),
        "errors": len(selected) - len(good),
        "load_shed": sum(row.get("status_code") == 429 for row in selected),
        "ttft_p95_ms": p95,
        "tpot_p99_ms": p99,
        "observed_slo_safe": safe,
    }


def load_episode() -> dict:
    manifest_path = ROOT.parent / "paper_artifact/data/adapted/manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    row = dict(next(item for item in manifest["episodes"]
                    if item["episode_id"] == EPISODE_ID))
    path = Path(row["path"])
    if not path.is_absolute():
        path = (manifest_path.parent / path).resolve()
    values = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
              if line.strip()]
    arrivals = [float(value["arrival_ms"]) * EVALUATION_SCALE / 1000.0
                for value in values]
    bins = [(0, 120), (120, 150), (150, 450), (450, 750)]
    counts = [sum(left <= value < right for value in arrivals) for left, right in bins]
    if row.get("split") != "test" or not all(counts):
        raise RuntimeError("selected trace does not cover every pilot phase")
    row.update(
        path=str(path),
        evaluation_arrival_scale=EVALUATION_SCALE,
        requests_within_750s=sum(value < DURATION_S for value in arrivals),
        phase_request_counts=counts,
    )
    return row


def write_priority_gateway(path: Path) -> None:
    source = (ROOT / "flexbid_hybrid/gateway.py").read_text(encoding="utf-8")
    needle = '        parsed = json.loads(body)\n        prompt = parsed.get("prompt")'
    replacement = (
        '        parsed = json.loads(body)\n'
        '        assigned_priority = 0 if request_class == "online" else 10\n'
        '        parsed["priority"] = assigned_priority\n'
        '        body = json.dumps(parsed).encode()\n'
        '        prompt = parsed.get("prompt")'
    )
    if source.count(needle) != 1:
        raise RuntimeError("temporary priority gateway patch point not found exactly once")
    path.write_text(source.replace(needle, replacement), encoding="utf-8")


class PriorityServiceGroup(ServiceGroup):
    def start(self) -> None:
        model = self.config["model"]
        runtime = self.config["runtime"]
        first_port = int(runtime["first_vllm_port"])
        ports = []
        self.logs.mkdir(parents=True, exist_ok=True)
        for replica_index, gpu_group in enumerate(model["replicas"]):
            port = first_port + replica_index
            ports.append(port)
            env = os.environ.copy()
            env["CUDA_VISIBLE_DEVICES"] = ",".join(map(str, gpu_group))
            env["VLLM_SERVER_DEV_MODE"] = "1"
            command = [
                "vllm", "serve", model["name"], "--host", "127.0.0.1",
                "--port", str(port), "--tensor-parallel-size", str(len(gpu_group)),
                "--max-model-len", str(model["max_model_len"]),
                "--gpu-memory-utilization", str(model["gpu_memory_utilization"]),
                "--max-num-seqs", str(runtime["max_num_seqs"]),
                "--max-num-batched-tokens", str(runtime["max_num_batched_tokens"]),
                "--scheduling-policy", "priority",
                "--enable-chunked-prefill", "--enable-prefix-caching",
            ]
            if model.get("language_model_only"):
                command.append("--language-model-only")
            handle = (self.logs / f"vllm_replica_{replica_index}.log").open(
                "a", encoding="utf-8"
            )
            self.handles.append(handle)
            self.processes.append(subprocess.Popen(
                command, stdout=handle, stderr=subprocess.STDOUT,
                env=env, start_new_session=True,
            ))
        for port in ports:
            wait_http(
                f"http://127.0.0.1:{port}/health",
                self.processes,
                float(runtime["startup_timeout_s"]),
            )
            post_json(f"http://127.0.0.1:{port}/v1/completions", {
                "model": model["name"], "prompt": [1, 2, 3], "max_tokens": 8,
                "temperature": 0, "ignore_eos": True, "priority": ONLINE_PRIORITY,
            })
            post_json(f"http://127.0.0.1:{port}/reset_prefix_cache")

        gateway_module = Path(runtime["priority_gateway_module"]).resolve()
        env = os.environ.copy()
        env["PYTHONPATH"] = (
            str(gateway_module.parent) + os.pathsep + str(self.root)
            + os.pathsep + env.get("PYTHONPATH", "")
        )
        env["FLEXBID_HYBRID_CONTROL_FILE"] = self.config["hardware"]["control_file"]
        env["FLEXBID_HYBRID_UPSTREAMS"] = ",".join(
            f"http://127.0.0.1:{port}" for port in ports
        )
        env["FLEXBID_ONLINE_CONCURRENCY"] = str(runtime["online_concurrency"])
        env["FLEXBID_MAX_ONLINE_QUEUE"] = str(runtime["max_online_queue"])
        handle = (self.logs / "gateway.log").open("a", encoding="utf-8")
        self.handles.append(handle)
        self.processes.append(subprocess.Popen([
            sys.executable, "-m", "uvicorn", f"{gateway_module.stem}:app",
            "--host", "127.0.0.1", "--port", str(runtime["gateway_port"]),
        ], cwd=gateway_module.parent, stdout=handle, stderr=subprocess.STDOUT,
           env=env, start_new_session=True))
        wait_http(
            f"http://127.0.0.1:{runtime['gateway_port']}/health",
            self.processes,
            120,
        )


def run_pilot(config: dict, services: PriorityServiceGroup,
              power: PowerCapManager, output: Path, episode: dict) -> dict:
    actions = {item.name: item for item in build_action_lattice(
        config["dynamic_controller"]["action_lattice"]
    )}
    baseline = actions["hybrid_full"]
    event_action = actions[EVENT_ACTION]
    recovery_action = actions[RECOVERY_ACTION]
    control_file = Path(config["hardware"]["control_file"])
    replicas = len(config["model"]["replicas"])
    online_concurrency = int(config["runtime"]["online_concurrency"])
    gateway = f"http://127.0.0.1:{config['runtime']['gateway_port']}"
    state_url = gateway + "/flexbid/state"

    services.wait_idle()
    services.reset_caches()
    services.reset_state()
    power.set_all(baseline.power_cap_w)
    baseline_control = apply_control(control_file, baseline, replicas, online_concurrency)
    get_json(state_url)

    start_ns = time.time_ns() + 3_000_000_000
    event_action_ns = start_ns + int(BASELINE_S * 1e9)
    activation_ns = event_action_ns + int(LEAD_S * 1e9)
    recovery_ns = activation_ns + int(EVENT_S * 1e9)
    end_ns = recovery_ns + int(RECOVERY_S * 1e9)
    atomic_json(output / "PRIORITY_RECOVERY_PROTOCOL.json", {
        "status": "CHUNK4096_PRIORITY_C6_RECOVERY_PILOT_STARTED",
        "episode": episode,
        "start_wall_ns": start_ns,
        "event_action_wall_ns": event_action_ns,
        "activation_wall_ns": activation_ns,
        "recovery_wall_ns": recovery_ns,
        "end_wall_ns": end_ns,
        "cohort_context": {"tokens": 286720.0, "recovery_s": 1500.0},
        "baseline_control": baseline_control,
        "event_action": EVENT_ACTION,
        "recovery_action": RECOVERY_ACTION,
        "online_priority": ONLINE_PRIORITY,
        "batch_priority": BATCH_PRIORITY,
        "required_recovery_tps": REQUIRED_RECOVERY_TPS,
        "external_commitment": False,
    })

    model = config["model"]
    base = gateway + "/v1"
    max_batch = max(int(value) for value in
                    config["dynamic_controller"]["action_lattice"]["batch_concurrency"])
    online_command = [
        sys.executable, str(ROOT / "scripts/replay_online.py"),
        "--trace", episode["path"], "--output", str(output / "online.jsonl"),
        "--api-base", base, "--model", model["name"], "--tokenizer", model["tokenizer"],
        "--arrival-scale", str(EVALUATION_SCALE), "--duration-s", str(DURATION_S),
        "--start-wall-ns", str(start_ns), "--source", str(episode["source"]),
    ]
    batch_command = [
        sys.executable, str(ROOT / "scripts/run_batch.py"),
        "--output", str(output / "batch.jsonl"), "--api-base", base,
        "--model", model["name"], "--tokenizer", model["tokenizer"],
        "--prompt-tokens", str(config["workloads"]["batch_prompt_tokens"]),
        "--output-tokens", str(config["workloads"]["batch_output_tokens"]),
        "--concurrency", str(max_batch), "--duration-s", str(DURATION_S),
        "--start-wall-ns", str(start_ns),
    ]

    handles = []
    processes = {}
    telemetry = None
    states = []
    current_action = baseline.name

    def actuate(action) -> dict:
        nonlocal current_action
        enforced = power.set_all(action.power_cap_w)
        applied = apply_control(control_file, action, replicas, online_concurrency)
        current_action = action.name
        return {"control": applied, "enforced_power_caps_w": enforced}

    event_transition = None
    recovery_transition = None
    try:
        for name in ("telemetry", "online", "batch"):
            stdout = (output / "logs" / f"{name}.stdout.log").open("w", encoding="utf-8")
            stderr = (output / "logs" / f"{name}.stderr.log").open("w", encoding="utf-8")
            handles.extend((stdout, stderr))
            if name == "telemetry":
                telemetry = subprocess.Popen([
                    sys.executable, "-m", "flexbid_hybrid.telemetry",
                    "--output", str(output / "components.csv"),
                    "--interval-ms", str(config["hardware"]["telemetry_interval_ms"]),
                ], cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
            else:
                command = online_command if name == "online" else batch_command
                processes[name] = subprocess.Popen(
                    command, cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True
                )

        event_applied = False
        recovery_applied = False
        next_state_ns = start_ns
        while time.time_ns() < end_ns:
            targets = [next_state_ns, end_ns]
            if not event_applied:
                targets.append(event_action_ns)
            if not recovery_applied:
                targets.append(recovery_ns)
            wait_until(min(targets))
            now = time.time_ns()
            if not event_applied and now >= event_action_ns:
                event_transition = actuate(event_action)
                event_applied = True
            if not recovery_applied and now >= recovery_ns:
                recovery_transition = actuate(recovery_action)
                recovery_applied = True
            if now >= next_state_ns and now < end_ns:
                observed = get_json(state_url)
                states.append({
                    "wall_time_ns": now,
                    "action": current_action,
                    "inflight": observed["inflight"],
                    "inflight_online": observed["inflight_online"],
                    "inflight_batch": observed["inflight_batch"],
                    "online_waiting": observed["online_waiting"],
                    "batch_waiting": observed["batch_waiting"],
                    "completed_online": observed["completed_online"],
                    "completed_batch": observed["completed_batch"],
                })
                while next_state_ns <= now:
                    next_state_ns += int(STATE_SAMPLE_S * 1e9)
        online_rc = wait_process(processes["online"], 1200.0)
        batch_rc = wait_process(processes["batch"], 300.0)
    finally:
        for process in processes.values():
            if process.poll() is None:
                stop_process(process)
        if telemetry is not None:
            stop_process(telemetry)
        power.set_all(baseline.power_cap_w)
        apply_control(control_file, baseline, replicas, online_concurrency)
        for handle in handles:
            handle.close()
    services.wait_idle()
    with (output / "gateway_state.jsonl").open("w", encoding="utf-8") as stream:
        for row in states:
            stream.write(json.dumps(row) + "\n")
    return {
        "start_wall_ns": start_ns,
        "activation_wall_ns": activation_ns,
        "recovery_wall_ns": recovery_ns,
        "end_wall_ns": end_ns,
        "event_transition": event_transition,
        "recovery_transition": recovery_transition,
        "online_return_code": online_rc,
        "batch_return_code": batch_rc,
    }


def analyze(config: dict, output: Path, run: dict, episode: dict) -> dict:
    online = read_jsonl(output / "online.jsonl")
    batch = read_jsonl(output / "batch.jsonl")
    states = read_jsonl(output / "gateway_state.jsonl")
    ttft_slo = float(config["slos"]["default"]["ttft_ms"])
    tpot_slo = float(config["slos"]["default"]["tpot_ms"])
    event_online = summarize_online(
        online, run["activation_wall_ns"], run["recovery_wall_ns"], ttft_slo, tpot_slo
    )
    recovery_online = summarize_online(
        online, run["recovery_wall_ns"], run["end_wall_ns"], ttft_slo, tpot_slo
    )
    recovery_batch = [row for row in batch
                      if run["recovery_wall_ns"] <= int(row["completion_wall_time_ns"])
                      < run["end_wall_ns"] and row.get("error") is None]
    batch_tokens = sum(float(row.get("completion_tokens") or 0) for row in recovery_batch)
    batch_tps = batch_tokens / RECOVERY_S
    recovery_states = [row for row in states
                       if run["recovery_wall_ns"] <= int(row["wall_time_ns"])
                       < run["end_wall_ns"]]
    with (output / "components.csv").open(newline="", encoding="utf-8") as stream:
        telemetry = list(csv.DictReader(stream))
    recovery_power = [float(row["aggregate_gpu_power_w"]) for row in telemetry
                      if row.get("aggregate_gpu_power_w") not in (None, "")
                      and run["recovery_wall_ns"] <= int(row["wall_time_ns"])
                      < run["end_wall_ns"]]
    checks = {
        "processes_succeeded": run["online_return_code"] == 0 and run["batch_return_code"] == 0,
        "event_online_slo_safe": event_online["observed_slo_safe"],
        "recovery_online_slo_safe": recovery_online["observed_slo_safe"],
        "recovery_batch_tps_meets_required": batch_tps + 1e-7 >= REQUIRED_RECOVERY_TPS,
    }
    report = {
        "status": (
            "CHUNK4096_PRIORITY_C6_RECOVERY_PILOT_COMPLETE"
            if all(checks.values())
            else "CHUNK4096_PRIORITY_C6_RECOVERY_PILOT_MEASURED_WITH_FAILURES"
        ),
        "checks": checks,
        "episode": episode,
        "priority_policy": {
            "vllm_scheduling_policy": "priority",
            "online_priority": ONLINE_PRIORITY,
            "batch_priority": BATCH_PRIORITY,
            "lower_value_runs_first": True,
            "max_num_batched_tokens": int(config["runtime"]["max_num_batched_tokens"]),
            "chunked_prefill": True,
        },
        "event_action": EVENT_ACTION,
        "recovery_action": RECOVERY_ACTION,
        "event_online": event_online,
        "recovery_online": recovery_online,
        "recovery_batch_jobs": len(recovery_batch),
        "recovery_batch_tokens": batch_tokens,
        "recovery_batch_tokens_per_s": batch_tps,
        "required_recovery_tokens_per_s": REQUIRED_RECOVERY_TPS,
        "recovery_batch_tps_margin": batch_tps - REQUIRED_RECOVERY_TPS,
        "recovery_gateway_state_samples": len(recovery_states),
        "maximum_recovery_inflight_online": max(
            (sum(row["inflight_online"]) for row in recovery_states), default=None
        ),
        "maximum_recovery_inflight_batch": max(
            (sum(row["inflight_batch"]) for row in recovery_states), default=None
        ),
        "maximum_recovery_batch_inflight_by_replica": (
            [
                max(int(row["inflight_batch"][index]) for row in recovery_states)
                for index in range(len(recovery_states[0]["inflight_batch"]))
            ] if recovery_states else []
        ),
        "maximum_recovery_online_inflight_by_replica": (
            [
                max(int(row["inflight_online"][index]) for row in recovery_states)
                for index in range(len(recovery_states[0]["inflight_online"]))
            ] if recovery_states else []
        ),
        "maximum_recovery_online_waiting": max(
            (int(row["online_waiting"]) for row in recovery_states), default=None
        ),
        "maximum_recovery_batch_waiting": max(
            (int(row["batch_waiting"]) for row in recovery_states), default=None
        ),
        "mean_recovery_gpu_power_w": (
            sum(recovery_power) / len(recovery_power) if recovery_power else None
        ),
        "executed_bid_w": 0.0,
        "external_commitment": False,
        "limitations": [
            "One reused Azure Code development trace and one 300-second recovery segment.",
            "This pilot tests whether a smaller chunked-prefill budget makes all-replica priority C6 jointly feasible.",
            "No project source, active model artifact, or persistent configuration is changed.",
        ],
    }
    atomic_json(output / "CHUNK4096_PRIORITY_C6_RECOVERY_FEASIBILITY_REPORT.json", report)
    atomic_json(output / "COLLECTION_COMPLETE.json", {"status": report["status"]})
    return report


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: runner.py SOURCE_RUN OUTPUT")
    source_run = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    if not source_run.is_dir():
        raise RuntimeError("source run is missing")
    if output.exists():
        allowed = {"logs", "launcher.pid", Path(__file__).name}
        unexpected = sorted(path.name for path in output.iterdir() if path.name not in allowed)
        if unexpected:
            raise RuntimeError("output is not fresh: " + repr(unexpected))

    from vllm.entrypoints.openai.completion.protocol import CompletionRequest
    if "priority" not in CompletionRequest.model_fields:
        raise RuntimeError("installed completion protocol does not expose request priority")

    with (ROOT / "results/chunk4096_priority_c6_recovery_pilot.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        active = active_collectors(ROOT)
        if active:
            raise RuntimeError("another FlexBid workload is active: " + repr(active))
        output.mkdir(parents=True, exist_ok=True)
        (output / "logs").mkdir(exist_ok=True)
        (output / Path(__file__).name).write_text(
            Path(__file__).read_text(encoding="utf-8"), encoding="utf-8"
        )
        (output / "launcher.pid").write_text(str(os.getpid()) + "\n", encoding="utf-8")
        priority_gateway = output / "priority_gateway.py"
        write_priority_gateway(priority_gateway)

        source_config = load_config(source_run / "diagnostic_config.yaml")
        config = dict(source_config)
        config["hardware"] = dict(source_config["hardware"])
        config["runtime"] = dict(source_config["runtime"])
        config["runtime"]["max_num_batched_tokens"] = 4096
        config["paths"] = dict(source_config.get("paths", {}))
        config["hardware"]["control_file"] = str(output / "control.json")
        config["runtime"]["priority_gateway_module"] = str(priority_gateway)
        config["paths"]["results_root"] = str(output)
        config["experiment_name"] = output.name
        (output / "pilot_config.yaml").write_text(
            yaml.safe_dump(config, sort_keys=False), encoding="utf-8"
        )
        episode = load_episode()
        atomic_json(output / "EXPERIMENT_PLAN.json", {
            "status": "CHUNK4096_PRIORITY_C6_RECOVERY_PILOT_PLANNED",
            "episode": episode,
            "timeline_s": {
                "baseline": BASELINE_S,
                "lead": LEAD_S,
                "event": EVENT_S,
                "recovery": RECOVERY_S,
            },
            "event_action": EVENT_ACTION,
            "recovery_action": RECOVERY_ACTION,
            "online_priority": ONLINE_PRIORITY,
            "batch_priority": BATCH_PRIORITY,
            "max_num_batched_tokens": 4096,
            "chunked_prefill": True,
            "required_recovery_tps": REQUIRED_RECOVERY_TPS,
            "executed_bid_w": 0.0,
            "external_commitment": False,
            "automatic_retry": False,
        })
        try:
            with PowerCapManager(config["hardware"]["gpu_indices"]) as power:
                power.set_all(400.0)
                with PriorityServiceGroup(ROOT, config, output / "service_logs") as services:
                    cell = output / "cell"
                    (cell / "logs").mkdir(parents=True, exist_ok=True)
                    run = run_pilot(config, services, power, cell, episode)
                    report = analyze(config, cell, run, episode)
            atomic_json(output / "CHUNK4096_PRIORITY_C6_RECOVERY_FEASIBILITY_REPORT.json", report)
            atomic_json(output / "COLLECTION_COMPLETE.json", {"status": report["status"]})
            print("=== CHUNK4096_PRIORITY_C6_RECOVERY_FEASIBILITY_RESULT ===", flush=True)
            print(json.dumps(report, indent=2), flush=True)
        except BaseException as exc:
            atomic_json(output / "COLLECTION_FAILED.json", {
                "status": "CHUNK4096_PRIORITY_C6_RECOVERY_PILOT_FAILED",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "automatic_retry": False,
            })
            raise


if __name__ == "__main__":
    main()
