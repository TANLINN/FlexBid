"""Evaluate existing held-identity models on two saved failure trajectories."""
import json,sys
from pathlib import Path
from core_response_model import load_windows
from core_shadow_models import load_scorer
from core_plan_comparison import rank

def main(dataset,models,out):
    root=Path('/root/workspace/FlexBid-LLM/hybrid_artifact/results')
    cases=[('event_service_failure',root/'core_day_20260914_004803_OloTpA/cells/r01_001918_p300',6),('c5_deadline_failure',root/'core_recovery_c5_20260913_204045_9oDcAT',5)]
    doc=json.loads(models.read_text())
    if doc['held_identity']!='azure_conversation:azure-001918' or doc['held_identity'] in doc['training_identities']:raise ValueError('Identity exclusion differs')
    rows=load_windows(dataset/'action_windows.csv');results=[]
    for name,run,c in cases:
        p=json.loads((run/'protocol.json').read_text());saved=json.loads((run/'REPORT.json').read_text())
        scorer=load_scorer(models,int(p['start_wall_ns']),int(p['deadline_wall_ns']))
        origins=[]
        for t in (150,450,750,1050,1350,1650):
            matches=[r for r in rows if r['run']==str(run) and r['start_s']==t]
            if len(matches)!=1:raise ValueError('Missing or duplicate saved origin '+str((run,t)))
            r=matches[0]
            if r['group']!=doc['group']:raise ValueError('Compatibility group differs')
            state={k:v for k,v in r.items() if k.startswith('x_') or k in ('group','phase')}
            candidates=scorer(state,int(p['start_wall_ns'])+t*10**9);ordered=rank(candidates)
            matched_name=f'p300_event_c5_recovery_c{c}' if t<450 else f'recovery_c{c}'
            matched=next(v for v in candidates if v['name']==matched_name)
            batch=saved['batch'];deficit=280-batch['jobs_completed_on_time']
            origins.append({'at_s':t,'choice':ordered[0]['name'] if ordered else None,'remaining_jobs':r['x_remaining_jobs'],'recorded_continuation_candidate':matched_name,'continuation_point_feasible':matched['point_constraints_satisfied'],'continuation_predicted_deadline_remaining':matched['remaining_at_deadline'],'actual_deadline_deficit':deficit,'continuation_false_deadline_pass':matched['remaining_at_deadline']==0 and deficit>0 if matched['complete_prediction'] else None,'continuation_max_predicted_gap_ms':matched['max_predicted_gap_ms'],'candidates':candidates})
        results.append({'case':name,'source':str(run),'on_time':saved['batch']['jobs_completed_on_time'],'event_slo_safe':saved['phases']['event_time_reference']['observed_slo_safe'],'event_gap_p99_ms':saved['phases']['event_time_reference']['request_mean_stream_gap_p99_ms'],'origins':origins})
    report={'status':'CORE_1918_FAILURE_REPLAY_COMPLETE','held_identity':doc['held_identity'],'cases':results,'scope':'Two outcome-selected development failures, not independent validation. Each origin follows saved fixed-policy states; later origins are not counterfactual states after a model action. Short-window maximum predicted p99 is not a predicted aggregate phase quantile. Saved dispatch/completion visibility is not live receipt visibility. No refit, GPU or policy change.'}
    (out/'REPORT.json').write_text(json.dumps(report,indent=2))
    print('=== CORE_1918_FAILURE_REPLAY ===');print('STATUS='+report['status'])
    for case in results:
        print('CASE='+json.dumps({k:v for k,v in case.items() if k!='origins'}))
        for r in case['origins']:print('ORIGIN='+json.dumps({k:v for k,v in r.items() if k!='candidates'}))
    print(report['scope']);print('REPORT_JSON='+str(out/'REPORT.json'))
if __name__=='__main__':main(*map(Path,sys.argv[1:]))

