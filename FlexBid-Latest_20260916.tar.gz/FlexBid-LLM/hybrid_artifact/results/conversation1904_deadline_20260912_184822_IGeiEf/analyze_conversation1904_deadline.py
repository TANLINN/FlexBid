"""Read paired 001904 batch timing and retain all deadline outcomes."""
import argparse
import csv
import filecmp
import json
import math
from pathlib import Path

NS = 10**9
METRICS = ('dispatch_s', 'completion_s', 'post_dispatch_s', 'ttft_ms', 'placement_wait_ms', 'admission_to_first_text_ms')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def records(path, key, request_class=None):
    result = {}
    with path.open(encoding='utf-8') as stream:
        for line in stream:
            if not line.strip():
                continue
            row = json.loads(line)
            if request_class is not None and row.get('class') != request_class:
                continue
            if row[key] in result:
                raise ValueError('Duplicate identity in ' + str(path))
            result[row[key]] = row
    return result


def describe(values):
    v = sorted(x for x in values if x is not None and math.isfinite(x))
    def q(p):
        if not v:
            return None
        i = (len(v)-1)*p
        left = int(i)
        return v[left] + (v[min(left+1,len(v)-1)]-v[left])*(i-left)
    return {'n':len(v), 'mean':sum(v)/len(v) if v else None, 'p50':q(.5), 'p95':q(.95), 'max':max(v) if v else None}


def load_run(root, cap):
    protocol, report = read(root/'protocol.json'), read(root/'REPORT.json')
    expected = {'duration_s':1950, 'cohort_release_offset_s':150, 'recovery_start_offset_s':450,
                'event_batch_concurrency':5, 'recovery_batch_concurrency':6,
                'power_cap_sequence_w_per_gpu':[400,cap,400]}
    if report['episode_id'] != 'azure_conversation:azure-001904' or any(protocol.get(k)!=v for k,v in expected.items()):
        raise ValueError('Run identity or fixed schedule differs: '+str(root))
    start = int(protocol['start_wall_ns'])
    if int(protocol['deadline_wall_ns']) != start + 1950*NS:
        raise ValueError('Deadline differs: '+str(root))
    plan, ledger = records(root/'batch_jobs.jsonl','job_id'), records(root/'batch.jsonl','job_id')
    if set(ledger)-set(plan):
        raise ValueError('Unplanned job in batch ledger')
    gateways = records(root/'stream_gateway.jsonl','request_id','batch')
    jobs = {}
    for key, job in plan.items():
        row, gate = ledger.get(key, {}), gateways.get(key, {})
        for k in ('release_offset_s','deadline_offset_s','max_output_tokens'):
            if row and row[k] != job[k]:
                raise ValueError('Result metadata differs: '+key)
        if (job['release_offset_s'],job['deadline_offset_s'],job['max_output_tokens']) != (150,1950,1024):
            raise ValueError('Cohort schedule or output quota differs: '+key)
        def offset(field):
            return None if row.get(field) is None else int(row[field])-start
        dispatched, ended = offset('dispatch_wall_time_ns'), offset('completion_wall_time_ns')
        good = bool(row) and row.get('error') is None and row.get('status_code')==200 and row.get('completion_tokens')==job['max_output_tokens'] and dispatched is not None and ended is not None and dispatched<=ended
        if dispatched is not None and dispatched < 150*NS:
            raise ValueError('Dispatch precedes saved release: '+key)
        context = gate.get('inflight_after_selection',{}).get('online_queue_priority',{})
        events = gate.get('events',[])
        first_ms = None
        if events and gate.get('admitted_mono_ns') is not None:
            duration = int(events[0]['upstream_read_ns'])-int(gate['admitted_mono_ns'])
            if duration>=0:
                first_ms = duration/1e6
        jobs[key] = {'job_id':key, 'record_present':bool(row), 'gateway_present':bool(gate),
                     'complete':good, 'on_time':good and ended<=1950*NS,
                     'late':good and ended>1950*NS,
                     'completion_offset_ns':ended if good else None,
                     'dispatch_offset_ns':dispatched,
                     'dispatch_s':dispatched/NS if dispatched is not None else None,
                     'completion_s':ended/NS if good else None,
                     'post_dispatch_s':(ended-dispatched)/NS if good else None,
                     'ttft_ms':row.get('ttft_ms'), 'placement_wait_ms':context.get('placement_wait_ms'),
                     'admission_to_first_text_ms':first_ms, 'replica':gate.get('replica'),
                     'deferred_for_online':context.get('deferred_for_online')}
    ends = [r['completion_s'] for r in jobs.values() if r['complete']]
    finish = max(ends) if len(ends)==len(jobs) and ends else None
    outcome = {'planned_jobs':len(jobs), 'jobs_completed_on_time':sum(r['on_time'] for r in jobs.values()),
               'jobs_completed_late':sum(r['late'] for r in jobs.values()),
               'jobs_unfinished_or_failed':sum(not r['complete'] for r in jobs.values()),
               'all_job_finish_s':finish, 'slack_s':1950-finish if finish is not None else None,
               'late_job_ids':[k for k,r in jobs.items() if r['late']],
               'unfinished_or_failed_job_ids':[k for k,r in jobs.items() if not r['complete']]}
    saved = report['batch']
    checks = {k:outcome[k]==saved[k] for k in ('planned_jobs','jobs_completed_on_time','jobs_completed_late','jobs_unfinished_or_failed','late_job_ids','unfinished_or_failed_job_ids')}
    if finish is not None:
        checks['all_job_finish_matches_report'] = math.isclose(finish,report['cohort_timing']['last_completed_job_offset_s'],abs_tol=1e-7)
    for t,n in report['cohort_timing']['jobs_completed_by_offset'].items():
        checks['completed_at_'+str(t)] = sum(r['complete'] and r['completion_offset_ns']<=round(float(t)*NS) for r in jobs.values())==n
    return {'root':str(root), 'outcome':outcome, 'checks':checks, 'jobs':jobs}


def snapshot(run, t):
    rows = list(run['jobs'].values())
    done = [r['job_id'] for r in rows if r['complete'] and r['completion_offset_ns']<=t*NS]
    unfinished = [r for r in rows if r['job_id'] not in done]
    return {'at_s':t,'completed':len(done),'remaining':len(unfinished),
            'not_dispatched':sum(r['dispatch_offset_ns'] is None or r['dispatch_offset_ns']>t*NS for r in unfinished),
            'dispatched_unfinished_job_ids':[r['job_id'] for r in unfinished if r['dispatch_offset_ns'] is not None and r['dispatch_offset_ns']<=t*NS],
            'completed_job_ids':done}


def analyze(p400, p300):
    a,b = load_run(p400,400), load_run(p300,300)
    same = all(filecmp.cmp(p400/n,p300/n,shallow=False) for n in ('online_workload.jsonl','batch_jobs.jsonl'))
    common = sorted(set(a['jobs']) & set(b['jobs']))
    matched = []
    for k in common:
        x,y = a['jobs'][k],b['jobs'][k]
        row = {'job_id':k,'p400_complete':x['complete'],'p300_complete':y['complete'],
               'p400_late':x['late'],'p300_late':y['late'],
               'both_dispatched_in_recovery':all(z['dispatch_s'] is not None and z['dispatch_s']>=450 for z in (x,y))}
        for m in METRICS:
            row['p400_'+m],row['p300_'+m] = x[m],y[m]
            row['delta_'+m] = x[m]-y[m] if x[m] is not None and y[m] is not None else None
        row['completion_decomposition_error_s'] = row['delta_completion_s']-row['delta_dispatch_s']-row['delta_post_dispatch_s'] if x['complete'] and y['complete'] else None
        matched.append(row)
    groups = {}
    for label, values in (('all_matched_jobs',matched),('both_dispatched_in_recovery',[r for r in matched if r['both_dispatched_in_recovery']]),('p400_late_jobs',[r for r in matched if r['p400_late']])):
        groups[label] = {'jobs':len(values),**{m:describe(r['delta_'+m] for r in values) for m in METRICS}}
    times = sorted(set(range(450,1951,30)) | {950,1450,1650})
    timeline = []
    for t in times:
        x,y = snapshot(a,t),snapshot(b,t)
        timeline.append({'at_s':t,'p400_completed':x['completed'],'p300_completed':y['completed'],
                         'completed_p400_minus_p300':x['completed']-y['completed'],
                         'p400_not_dispatched':x['not_dispatched'],'p300_not_dispatched':y['not_dispatched'],
                         'p400_dispatched_unfinished':len(x['dispatched_unfinished_job_ids']),
                         'p300_dispatched_unfinished':len(y['dispatched_unfinished_job_ids'])})
    entry = {'p400':snapshot(a,450),'p300':snapshot(b,450)}
    entry['completed_membership_symmetric_difference'] = sorted(set(entry['p400']['completed_job_ids']) ^ set(entry['p300']['completed_job_ids']))
    for v in (entry['p400'],entry['p300']):
        v.pop('completed_job_ids')
        rows = (a if v is entry['p400'] else b)['jobs']
        v['dispatched_unfinished_jobs'] = [{'job_id':k,'dispatch_s':rows[k]['dispatch_s'],
                                          'elapsed_since_dispatch_s':450-rows[k]['dispatch_s']}
                                         for k in v['dispatched_unfinished_job_ids']]
    tail_ids = sorted({k for r in (a,b) for k,v in r['jobs'].items() if v['late'] or not v['complete']})
    tail = {k:{label:r['jobs'].get(k) for label,r in (('p400',a),('p300',b))} for k in tail_ids}
    identities_match = set(a['jobs'])==set(b['jobs'])
    return {'status':'CONVERSATION1904_DEADLINE_ANALYSIS_COMPLETE',
            'same_saved_inputs':same,'same_job_identities':identities_match,
            'runs':{label:{k:v for k,v in r.items() if k!='jobs'} for label,r in (('p400',a),('p300',b))},
            'all_saved_counts_match':all(all(r['checks'].values()) for r in (a,b)),
            'recovery_entry':entry,'matched_delta_p400_minus_p300':groups,
            'late_or_unfinished_jobs':tail,'timeline':timeline,'matched_jobs':matched,
            'maximum_absolute_decomposition_error_s':max((abs(r['completion_decomposition_error_s']) for r in matched if r['completion_decomposition_error_s'] is not None),default=None),
            'unmatched_job_ids':{'p400':sorted(set(a['jobs'])-set(b['jobs'])),'p300':sorted(set(b['jobs'])-set(a['jobs']))},
            'limitations':[
                'All planned jobs remain in outcome counts; absent and failed results have no fabricated successful finish.',
                'P400 minus P300 is the timing-difference direction. Quantiles of dispatch and post-dispatch differences need not add.',
                'Placement waiting is only part of client post-dispatch time. Admission-to-first-text is an observed gateway interval, not engine execution time.',
                'Recovery-entry membership uses completion timestamps at or before 450 s. It records elapsed client time, not remaining work or engine progress.',
                'Snapshots do not prove when a live controller received results. No future outcome controls a decision.',
                'Both recovery policies are fixed C6. The two runs differ in event cap and execution history; this decomposition does not establish a causal cap effect.',
                'The complete cohort deadline remains 1950 s. Late work is retained and no threshold, model or policy is changed.'],
            'gpu_workload_run':False}


def main():
    parser = argparse.ArgumentParser()
    for name in ('p400','p300','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    args = parser.parse_args()
    r = analyze(args.p400,args.p300)
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'REPORT.json').write_text(json.dumps(r,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    for name, rows in (('matched_jobs.csv',r['matched_jobs']),('recovery_timeline.csv',r['timeline'])):
        if rows:
            with (args.output/name).open('w',newline='',encoding='utf-8') as f:
                writer = csv.DictWriter(f,fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
    lines = ['=== CONVERSATION1904_DEADLINE_ANALYSIS ===','STATUS='+r['status']]
    for k in ('same_saved_inputs','same_job_identities','all_saved_counts_match','runs','recovery_entry','matched_delta_p400_minus_p300','late_or_unfinished_jobs','maximum_absolute_decomposition_error_s','unmatched_job_ids'):
        lines.append(k.upper()+'='+json.dumps(r[k],ensure_ascii=False))
    lines.extend('TIMELINE='+json.dumps(row) for row in r['timeline'])
    lines.extend(r['limitations'])
    text = '\n'.join(lines)+'\n'
    (args.output/'REPORT.txt').write_text(text,encoding='utf-8')
    print(text,end='')
    return 0 if r['all_saved_counts_match'] and r['same_saved_inputs'] and r['same_job_identities'] else 2


if __name__=='__main__':
    raise SystemExit(main())
