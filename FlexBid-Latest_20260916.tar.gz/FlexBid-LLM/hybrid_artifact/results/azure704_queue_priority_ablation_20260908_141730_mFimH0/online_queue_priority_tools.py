"""Defer new recovery batch admissions while online requests await placement."""
import ast
from pathlib import Path


def apply_recovery_control(path, action, replicas, online_concurrency):
    from flexbid_hybrid.io import atomic_json
    value = {'action': action.as_dict(), 'online_replica_ids': list(action.resolved_online_replica_ids()),
             'batch_replica_ids': list(range(replicas)), 'batch_paused': action.batch_concurrency == 0,
             'online_concurrency': online_concurrency, 'batch_concurrency': max(1, action.batch_concurrency),
             'defer_batch_for_online_queue': action.batch_concurrency == 6}
    atomic_json(path, value)
    return value


def priority_gateway_source(source):
    tree = ast.parse(source)
    state = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'State')
    methods = {n.name: n for n in state.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    if 'queued_online_count' in methods:
        raise ValueError('Queue-priority transformation is already present')
    gate = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'AdjustableGate')
    for method in gate.body:
        if isinstance(method, ast.FunctionDef) and method.name == '__init__':
            method.body += ast.parse('self.placement_notify = None').body
        if isinstance(method, ast.AsyncFunctionDef) and method.name in ('acquire', 'release', 'resize'):
            notify = ast.parse('''
if self.placement_notify is not None:
    await self.placement_notify()
''').body
            original = method.body
            if method.name == 'acquire':
                granted = next(n for n in ast.walk(method) if isinstance(n, ast.AugAssign)
                               and ast.unparse(n.target) == 'self.active')
                parent = next(n for n in ast.walk(method) if hasattr(n, 'body') and granted in n.body)
                parent.body.insert(parent.body.index(granted) + 1, ast.parse('placement_slot_granted = True').body[0])
                notify = [ast.Try(body=notify, handlers=ast.parse('''
try:
    pass
except BaseException:
    if placement_slot_granted:
        async with self.condition:
            self.active -= 1
            self.condition.notify_all()
    raise
''').body[0].handlers, orelse=[], finalbody=[])]
                method.body = ast.parse('placement_slot_granted = False').body
            else:
                method.body = []
            method.body.append(ast.Try(body=original, handlers=[], orelse=[], finalbody=notify))
    methods['__init__'].body += ast.parse('''
self.defer_batch_for_online_queue = False
self.admission_context = {}
self.online_gate.placement_notify = self.notify_placement
''').body
    state.body += ast.parse('''
def queued_online_count(self):
    # Include online requests between acquiring a class slot and choosing a replica.
    return self.online_gate.waiting + max(0, self.placement_waiting['online'], self.online_gate.active - sum(self.inflight_online))

async def notify_placement(self):
    async with self.placement_condition:
        self.placement_condition.notify_all()
''').body
    refresh = methods['refresh']
    location = [(parent.body, i) for parent in ast.walk(refresh) if isinstance(parent, (ast.Try, ast.AsyncWith))
                for i, n in enumerate(parent.body) if isinstance(n, ast.Assign)
                and any(ast.unparse(t) == 'self.batch_paused' for t in n.targets)]
    if len(location) != 1:
        raise ValueError('Expected one saved batch_paused update')
    body, position = location[0]
    body[position + 1:position + 1] = ast.parse("self.defer_batch_for_online_queue = bool(value.get('defer_batch_for_online_queue', False))").body
    choose = methods['choose']
    choose.body[:0] = ast.parse('placement_started_ns = time.monotonic_ns()\ndeferred_for_online = False').body
    loop = next(n for n in ast.walk(choose) if isinstance(n, ast.While))
    ready = next(i for i, n in enumerate(loop.body) if isinstance(n, ast.Assign) and any(ast.unparse(t) == 'ready' for t in n.targets))
    loop.body[ready + 1:ready + 1] = ast.parse('''
queued_online = self.queued_online_count()
if request_class == 'batch' and self.defer_batch_for_online_queue and queued_online > 0:
    deferred_for_online = True
    ready = []
''').body
    selected = next(n for n in loop.body if isinstance(n, ast.If) and ast.unparse(n.test) == 'ready')
    ret = next(i for i, n in enumerate(selected.body) if isinstance(n, ast.Return))
    selected.body[ret:ret] = ast.parse('''
self.admission_context[ticket] = {
    'enabled': self.defer_batch_for_online_queue, 'queued_online_at_selection': queued_online,
    'deferred_for_online': deferred_for_online, 'placement_wait_ms': (time.monotonic_ns() - placement_started_ns) / 1e6,
    'selection_wall_time_ns': time.time_ns()
}
''').body
    cleanup = next(n for n in ast.walk(choose) if isinstance(n, ast.Try) and n.finalbody)
    cleanup.finalbody += ast.parse('self.placement_condition.notify_all()').body
    finish_lock = next(n for n in methods['finish'].body if isinstance(n, ast.AsyncWith))
    finish_lock.body += ast.parse('self.admission_context.pop(ticket, None)').body
    proxy = next(n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'proxy')
    counts = next(n.value for n in proxy.body if isinstance(n, ast.Assign) and any(ast.unparse(t) == 'stream_selected_counts' for t in n.targets))
    counts.keys.append(ast.Constant('online_queue_priority'))
    counts.values.append(ast.parse('state.admission_context.pop(ticket)', mode='eval').body)
    ast.fix_missing_locations(tree)
    result = ast.unparse(tree) + '\n'
    ast.parse(result, feature_version=(3, 10))
    return result


def apply_online_queue_priority(path):
    path = Path(path)
    path.write_text(priority_gateway_source(path.read_text(encoding='utf-8')), encoding='utf-8')


def policy_summary(gateways, actions, protocol):
    contexts = [(r, r['inflight_after_selection'].get('online_queue_priority')) for r in gateways]
    missing = [r['request_id'] for r, c in contexts if c is None]
    present = [(r, c) for r, c in contexts if c is not None]
    batch = [(r, c) for r, c in present if r['class'] == 'batch']
    violations = [r['request_id'] for r, c in batch if c['enabled'] and c['queued_online_at_selection'] > 0]
    boundary = int(protocol['start_wall_ns']) + int(protocol['recovery_start_offset_s'] * 1e9)
    early = [r['request_id'] for r, c in present if c['enabled'] and c['selection_wall_time_ns'] < boundary]
    enabled = [(r, c) for r, c in batch if c['enabled']]
    flags = [r['control'].get('defer_batch_for_online_queue') for r in actions]
    return {'control_phase_flags': flags, 'expected_phase_flags_observed': flags == [False, False, True],
            'admission_records': len(gateways), 'missing_context_count': len(missing), 'missing_context_first8': missing[:8],
            'batch_admissions_with_policy_enabled': len(enabled),
            'batch_requests_deferred_for_online': sum(c['deferred_for_online'] for _, c in batch),
            'maximum_deferred_batch_placement_wait_ms': max((c['placement_wait_ms'] for _, c in batch if c['deferred_for_online']), default=None),
            'batch_admissions_while_online_queued': len(violations), 'violation_ids_first8': violations[:8],
            'policy_enabled_before_recovery': len(early), 'early_ids_first8': early[:8],
            'scope': 'Placement observations; existing batch requests are not interrupted. Class-slot waiting precedes placement_wait_ms.'}

