"""Decompose saved client TTFT around gateway admission and first text."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path

RUNS = {
    'p300_first': 'azure704_recovery_c6_new_server_20260907_224037_KX5OeV',
    'p400': 'azure704_recovery_c6_p400_pair_20260907_234943_hHd69y',
    'p300_repeat': 'azure704_c6_p300_repeat_20260908_005557_dlFA0O',
}
PHASES = {'warmup': (0, 150), 'event_time_reference': (150, 450), 'recovery': (450, 1950),
          'recovery_early': (450, 950), 'recovery_middle': (950, 1450), 'recovery_late': (1450, 1950),
          'evaluation': (150, 1950), 'warmup_first30': (0, 30), 'warmup_after30': (30, 150)}


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_rows(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def finite(value):
    if value is None:
        return None
    value = float(value)
    return value if math.isfinite(value) else None


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    pos = (len(values) - 1) * q
    i = int(pos)
    return values[i] + (pos - i) * (values[min(i + 1, len(values) - 1)] - values[i])


def describe(values):
    values = [v for v in values if v is not None]
    return {'samples': len(values), 'mean': sum(values) / len(values) if values else None,
            'p50': quantile(values, .5), 'p95': quantile(values, .95), 'max': max(values) if values else None}


def unique_index(rows, key, description):
    result = {r[key]: r for r in rows}
    if len(result) != len(rows):
        raise ValueError('Duplicate ' + description + ' IDs')
    return result


def request_timing(row, gateway):
    record = {key: row.get(key) for key in ('request_id', 'arrival_ms', 'prompt_tokens', 'max_output_tokens',
                                          'parent_request_id', 'tool_delay_ms', 'error', 'status_code')}
    record['ttft_ms'] = finite(row.get('ttft_ms'))
    record['gap_ms'] = finite(row.get('mean_tpot_ms'))
    record['timing_status'] = 'UNAVAILABLE'
    record['replica'] = gateway.get('replica') if gateway else None
    dispatch, scheduled = row.get('dispatch_wall_time_ns'), row.get('scheduled_wall_time_ns')
    record['scheduled_to_dispatch_ms'] = (int(dispatch) - int(scheduled)) / 1e6 if dispatch is not None and scheduled is not None else None
    if row.get('error') is not None or row.get('status_code') != 200 or record['ttft_ms'] is None:
        record['timing_reason'] = 'request unsuccessful or missing TTFT'
        return record
    if gateway is None:
        record['timing_reason'] = 'missing gateway observation'
        return record
    try:
        before, after = gateway['events'], row['stream_observations']
        if gateway['parse_errors'] or not before or len(before) != len(after) or len(after) != int(row['nonempty_sse_text_events']):
            raise ValueError('stream count or parser mismatch')
        for a, b in zip(before, after):
            if any(a[k] != b[k] for k in ('sequence', 'response_id', 'text_chars')):
                raise ValueError('stream event identity mismatch')
        admitted = int(gateway['admitted_mono_ns'])
        upstream, forward = int(before[0]['upstream_read_ns']), int(before[0]['forward_ns'])
        line, parsed = int(after[0]['line_read_ns']), int(after[0]['parsed_ns'])
        if not admitted <= upstream <= forward <= line <= parsed:
            raise ValueError('first-text timestamp order mismatch')
        ttft = record['ttft_ms']
        # The existing client samples its TTFT endpoint between line_read_ns and parsed_ns.
        pre_low = ttft - (parsed - admitted) / 1e6
        pre_high = ttft - (line - admitted) / 1e6
        if pre_high < 0:
            raise ValueError('admission-to-client interval exceeds recorded TTFT')
        pre_estimate = (pre_low + pre_high) / 2
        wait_upstream = (upstream - admitted) / 1e6
        gateway_forward = (forward - upstream) / 1e6
        forward_client = ((line - forward) + (parsed - forward)) / 2e6
        record.update(timing_status='AVAILABLE', pre_admission_estimate_ms=pre_estimate,
                      pre_admission_lower_ms=pre_low, pre_admission_upper_ms=pre_high,
                      admission_to_upstream_first_ms=wait_upstream, upstream_to_forward_ms=gateway_forward,
                      forward_to_client_first_estimate_ms=forward_client,
                      first_sample_bracket_ms=(parsed - line) / 1e6,
                      component_sum_error_ms=pre_estimate + wait_upstream + gateway_forward + forward_client - ttft)
    except (KeyError, ValueError, TypeError, IndexError) as exc:
        record['timing_reason'] = str(exc)
    return record


def decomposition_group(rows, threshold):
    timed = [r for r in rows if r['timing_status'] == 'AVAILABLE']
    keys = ('ttft_ms', 'pre_admission_estimate_ms', 'admission_to_upstream_first_ms',
            'upstream_to_forward_ms', 'forward_to_client_first_estimate_ms', 'first_sample_bracket_ms',
            'scheduled_to_dispatch_ms', 'prompt_tokens', 'max_output_tokens')
    return {'requests': len(rows), 'timed_requests': len(timed),
            'timing_unavailable': dict(Counter(r.get('timing_reason') for r in rows if r['timing_status'] != 'AVAILABLE')),
            'pre_admission_lower_bound_exceeds_half_ttft': sum(r['pre_admission_lower_ms'] > r['ttft_ms'] / 2 for r in timed),
            'admission_to_upstream_exceeds_half_ttft': sum(r['admission_to_upstream_first_ms'] > r['ttft_ms'] / 2 for r in timed),
            'pre_admission_lower_bound_over_slo': sum(r['pre_admission_lower_ms'] > threshold for r in timed),
            'admission_to_upstream_over_slo': sum(r['admission_to_upstream_first_ms'] > threshold for r in timed),
            'estimated_pre_admission_below_zero': sum(r['pre_admission_estimate_ms'] < 0 for r in timed),
            'components': {key: describe([finite(r.get(key)) for r in timed]) for key in keys}}


def phase_summary(records, states, start_ns, left, right, threshold):
    selected = [r for r in records if left * 1000 <= float(r['arrival_ms']) < right * 1000]
    good = [r for r in selected if r['error'] is None and r['status_code'] == 200]
    ttft = [r['ttft_ms'] for r in good if r['ttft_ms'] is not None]
    tails = [r for r in good if r['ttft_ms'] is not None and r['ttft_ms'] > threshold]
    snapshot = [r for r in states if left * 1e9 <= int(r['wall_time_ns']) - start_ns < right * 1e9]
    p95 = quantile(ttft, .95)
    return {'requests': len(selected), 'unsuccessful_requests': len(selected) - len(good),
            'missing_ttft': len(good) - len(ttft), 'ttft_p95_ms': p95, 'ttft_tail_requests': len(tails),
            'ttft_p95_within_threshold': p95 is not None and p95 <= threshold,
            'scheduled_to_dispatch_ms': describe([r['scheduled_to_dispatch_ms'] for r in selected]),
            'requests_with_parent': sum(r['parent_request_id'] is not None for r in selected),
            'all_requests': decomposition_group(selected, threshold),
            'ttft_over_slo': decomposition_group(tails, threshold),
            'gateway_snapshots': {'samples': len(snapshot),
                                  'online_waiting': describe([finite(r.get('online_waiting')) for r in snapshot]),
                                  'online_active': describe([sum(r['inflight_online']) for r in snapshot]),
                                  'batch_active': describe([sum(r['inflight_batch']) for r in snapshot])}}


def analyze_run(folder):
    protocol, report = read_json(folder / 'protocol.json'), read_json(folder / 'REPORT.json')
    online = read_rows(folder / 'online.jsonl')
    gateways = [r for r in read_rows(folder / 'stream_gateway.jsonl') if r['class'] == 'online']
    states = read_rows(folder / 'gateway_state.jsonl')
    index = unique_index(gateways, 'request_id', 'online gateway')
    unique_index(online, 'request_id', 'online ledger')
    records = [request_timing(r, index.get(r['request_id'])) for r in online]
    threshold = float(report['slos']['ttft_p95_ms'])
    phases = {p: phase_summary(records, states, int(protocol['start_wall_ns']), left, right, threshold)
              for p, (left, right) in PHASES.items()}
    own_label = {'p300_first': 'new_server', 'p400': 'p400', 'p300_repeat': 'p300_repeat'}
    label = next(k for k, name in RUNS.items() if name == folder.name)
    comparisons = {}
    for phase, summary in phases.items():
        saved = report['phases'][phase][own_label[label]]
        actual, recorded = summary['ttft_p95_ms'], saved['ttft_p95_ms']
        comparisons[phase] = {'requests_match': summary['requests'] == saved['requests'],
                              'ttft_absolute_difference_ms': abs(actual - recorded) if actual is not None and recorded is not None else None,
                              'ttft_matches': actual is None and recorded is None or actual is not None and recorded is not None and math.isclose(actual, recorded, rel_tol=1e-12, abs_tol=1e-8)}
    failed = [r for r in records if r['timing_status'] != 'AVAILABLE']
    stats = {'run': str(folder), 'threshold_ms': threshold, 'online_requests': len(online),
             'timed_requests': len(records) - len(failed), 'unavailable_examples_first8': failed[:8],
             'unexpected_online_gateway_ids': sorted(set(index) - {r['request_id'] for r in records})[:8],
             'saved_report_comparisons': comparisons, 'all_saved_phase_summaries_match': all(r['requests_match'] and r['ttft_matches'] for r in comparisons.values()),
             'maximum_component_sum_error_ms': max((abs(r['component_sum_error_ms']) for r in records if r['timing_status'] == 'AVAILABLE'), default=None),
             'phases': phases}
    return stats, records


def matched_middle(records_by_run, thresholds):
    mapped = {label: unique_index(records, 'request_id', label) for label, records in records_by_run.items()}
    ids = set.intersection(*(set(index) for index in mapped.values()))
    metadata = ('arrival_ms', 'prompt_tokens', 'max_output_tokens', 'parent_request_id', 'tool_delay_ms')
    matching = [key for key in ids if all(all(index[key].get(k) == mapped['p400'][key].get(k) for k in metadata) for index in mapped.values())]
    selected = [key for key in matching if 950000 <= float(mapped['p400'][key]['arrival_ms']) < 1450000]
    successful = [key for key in selected if all(index[key]['error'] is None and index[key]['status_code'] == 200 and index[key]['ttft_ms'] is not None for index in mapped.values())]
    patterns = Counter(''.join('1' if mapped[label][key]['ttft_ms'] > thresholds[label] else '0' for label in RUNS) for key in successful)
    worst = sorted(successful, key=lambda key: (-max(mapped[label][key]['ttft_ms'] for label in RUNS), str(key)))[:10]
    detail_keys = ('ttft_ms', 'pre_admission_estimate_ms', 'admission_to_upstream_first_ms',
                   'forward_to_client_first_estimate_ms', 'first_sample_bracket_ms', 'scheduled_to_dispatch_ms', 'replica', 'timing_status')
    return {'label_order': list(RUNS), 'pattern_meaning': '1 means that request TTFT exceeds the original threshold; not a phase p95 verdict',
            'shared_request_ids': len(ids), 'metadata_matching_ids': len(matching),
            'missing_ids_by_run': {label: len(set.union(*(set(i) for i in mapped.values())) - set(index)) for label, index in mapped.items()},
            'middle_matching_ids': len(selected), 'middle_successful_with_ttft_in_all_three': len(successful),
            'ttft_tail_patterns': dict(sorted(patterns.items())),
            'top10_by_maximum_ttft': [{'request_id': key, 'arrival_ms': mapped['p400'][key]['arrival_ms'],
                                     'prompt_tokens': mapped['p400'][key]['prompt_tokens'],
                                     'conditions': {label: {k: mapped[label][key].get(k) for k in detail_keys} for label in RUNS}}
                                    for key in worst]}


def format_report(report):
    def n(value):
        return 'NA' if value is None else f'{value:.3f}'
    lines = ['=== C6_TTFT_DECOMPOSITION ===', 'STATUS=' + report['status'],
             'CPU_ONLY: saved records; no GPU workload, parameter change or retry.',
             'Timing columns are milliseconds; before-admission is an estimate, not pure gateway queue time.',
             'phase condition requests TTFT_p95 tails timed_tails pre_admission_p50 upstream_first_p50 client_forward_p50 pre_majority upstream_majority']
    for phase in ('warmup', 'event_time_reference', 'recovery', 'recovery_middle', 'evaluation'):
        for label, run in report['runs'].items():
            row = run['phases'][phase]
            tail = row['ttft_over_slo']
            c = tail['components']
            lines.append(' '.join([phase, label, str(row['requests']), n(row['ttft_p95_ms']), str(row['ttft_tail_requests']),
                                   str(tail['timed_requests']), n(c['pre_admission_estimate_ms']['p50']),
                                   n(c['admission_to_upstream_first_ms']['p50']), n(c['forward_to_client_first_estimate_ms']['p50']),
                                   str(tail['pre_admission_lower_bound_exceeds_half_ttft']), str(tail['admission_to_upstream_exceeds_half_ttft'])]))
    for label, run in report['runs'].items():
        lines.append('RUN_QUALITY=' + json.dumps({'condition': label, **{k: run[k] for k in ('run', 'online_requests', 'timed_requests', 'all_saved_phase_summaries_match', 'maximum_component_sum_error_ms', 'unavailable_examples_first8', 'unexpected_online_gateway_ids')}}))
        middle = run['phases']['recovery_middle']
        lines.append('MIDDLE_CONTEXT=' + json.dumps({'condition': label, 'gateway_snapshots': middle['gateway_snapshots'],
                                                    'scheduled_to_dispatch_ms': middle['scheduled_to_dispatch_ms'], 'requests_with_parent': middle['requests_with_parent'],
                                                    'tail_components': middle['ttft_over_slo']}))
    match = report['matched_middle']
    lines.append('MATCHED_MIDDLE=' + json.dumps({k: v for k, v in match.items() if k != 'top10_by_maximum_ttft'}))
    for row in match['top10_by_maximum_ttft']:
        lines.append('MATCHED_REQUEST=' + json.dumps(row))
    lines.extend(report['limitations'])
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    try:
        runs, data = {}, {}
        for label, name in RUNS.items():
            runs[label], data[label] = analyze_run(args.project / 'results' / name)
        match = matched_middle(data, {k: v['threshold_ms'] for k, v in runs.items()})
        complete = (all(r['timed_requests'] == r['online_requests'] and r['all_saved_phase_summaries_match'] and not r['unexpected_online_gateway_ids'] for r in runs.values())
                    and not any(match['missing_ids_by_run'].values()) and match['metadata_matching_ids'] == match['shared_request_ids'])
        report = {'status': 'COMPLETE' if complete else 'PARTIAL_TIMING_OR_REPORT_MISMATCH', 'gpu_workload_run': False,
                  'runs': runs, 'matched_middle': match,
                  'limitations': [
                      'Before-admission spans client request preparation, HTTP transit, gateway admission slots and placement waiting. These parts were not timestamped separately.',
                      'Admission-to-first-upstream-text includes gateway preparation, upstream transport, engine waiting/execution and stream observation. It is not an engine prefill duration.',
                      'The saved client TTFT sample lies between its first line-read and parsed timestamps. The midpoint estimates split TTFT; first_sample_bracket_ms records their uncertainty.',
                      'Cross-process monotonic timestamp order and stream identities are checked. This does not provide an independent clock calibration.',
                      'Scheduled-to-dispatch lag is separate from the original TTFT and may include parent/tool dependencies. Neither the original SLO nor phase assignment changes.',
                      'Tail groups contain requests whose TTFT exceeds 5000 ms; the original requirement remains p95, not zero tail requests. Independent component quantiles must not be added.',
                      'Gateway snapshots summarize each wall-time phase, not the queue faced by each matched request. They do not prove a causal bottleneck.',
                      'Three runs reuse the same trace. This analysis does not measure a changed controller, a new GPU run or cross-trace generalization.'
                  ]}
        write_json(args.output / 'REPORT.json', report)
        text = format_report(report)
        (args.output / 'REPORT.txt').write_text(text, encoding='utf-8')
        with (args.output / 'REQUEST_TIMINGS.jsonl').open('w', encoding='utf-8') as stream:
            for label, records in data.items():
                for row in records:
                    stream.write(json.dumps({'condition': label, **row}, ensure_ascii=False, allow_nan=False) + '\n')
        print(text, end='')
        print('REPORT_TXT=' + str(args.output / 'REPORT.txt'))
    except Exception as exc:
        error = {'status': 'ERROR', 'error_type': type(exc).__name__, 'error': str(exc)}
        write_json(args.output / 'ERROR.json', error)
        print(json.dumps(error))
        raise SystemExit(1)


if __name__ == '__main__':
    main()

