"""Compare saved P400 recovery request latencies and sampled admission conditions."""
import argparse
from collections import Counter
import csv
import filecmp
import json
from pathlib import Path

from analyze_conversation1904_deadline import read, records, describe, load_run, snapshot, NS
from analyze_c6_ttft_decomposition import request_timing

STAGES = {'event': (150, 450), 'recovery_early': (450, 950),
          'recovery_middle': (950, 1450), 'recovery_late': (1450, 1950)}
COMPONENTS = ('pre_admission_s', 'admission_to_first_text_s', 'upstream_to_forward_s',
              'forward_to_client_first_s', 'client_first_text_to_completion_s')
OTHER = ('dispatch_s', 'completion_s', 'post_dispatch_s', 'placement_wait_s')


def enrich(run):
    root = Path(run['root'])
    ledger = records(root / 'batch.jsonl', 'job_id')
    gateways = records(root / 'stream_gateway.jsonl', 'request_id', 'batch')
    for key, job in run['jobs'].items():
        row, gate = ledger.get(key, {}), gateways.get(key)
        timing = request_timing({**row, 'request_id': key}, gate)
        job['timing_status'] = timing['timing_status']
        job['timing_reason'] = timing.get('timing_reason')
        for field in COMPONENTS:
            job[field] = None
        job['placement_wait_s'] = None if job['placement_wait_ms'] is None else job['placement_wait_ms'] / 1000
        job['pre_admission_lower_s'] = job['pre_admission_upper_s'] = None
        job['duration_decomposition_error_s'] = None
        if job['complete'] and timing['timing_status'] == 'AVAILABLE':
            for field, source in (
                ('pre_admission_s', 'pre_admission_estimate_ms'),
                ('admission_to_first_text_s', 'admission_to_upstream_first_ms'),
                ('upstream_to_forward_s', 'upstream_to_forward_ms'),
                ('forward_to_client_first_s', 'forward_to_client_first_estimate_ms'),
                ('pre_admission_lower_s', 'pre_admission_lower_ms'),
                ('pre_admission_upper_s', 'pre_admission_upper_ms')):
                job[field] = timing[source] / 1000
            job['client_first_text_to_completion_s'] = job['post_dispatch_s'] - job['ttft_ms'] / 1000
            job['duration_decomposition_error_s'] = job['post_dispatch_s'] - sum(job[k] for k in COMPONENTS)
    return run


def sampled_conditions(root, protocol):
    rows = []
    with (root / 'gateway_state.jsonl').open(encoding='utf-8') as stream:
        for line in stream:
            if line.strip():
                rows.append(json.loads(line))
    result = {}
    for phase, (left, right) in STAGES.items():
        selected = [r for r in rows if left * NS <= int(r['wall_time_ns']) - int(protocol['start_wall_ns']) < right * NS]
        waiting = [r for r in selected if r['batch_waiting'] > 0]
        categories = Counter()
        for row in waiting:
            online, batch = row['inflight_online'], row['inflight_batch']
            eligible = any(o == 0 and b < 2 for o, b in zip(online, batch))
            queue = row['online_waiting'] > 0
            categories[('online_queue_positive' if queue else 'online_queue_zero') +
                       ('_with_count_eligible_replica' if eligible else '_without_count_eligible_replica')] += 1
        result[phase] = {
            'samples': len(selected), 'batch_waiting_samples': len(waiting),
            'waiting_sample_categories': dict(categories),
            'online_waiting': describe(r['online_waiting'] for r in selected),
            'batch_waiting': describe(r['batch_waiting'] for r in selected),
            'admitted_batch': describe(sum(r['inflight_batch']) for r in selected),
            'maximum_sample_gap_s': max(((int(b['wall_time_ns']) - int(a['wall_time_ns'])) / NS
                                         for a, b in zip(selected, selected[1:])), default=None)}
    return result


def latency_group(jobs):
    rows = list(jobs)
    timed = [r for r in rows if r['complete'] and r['timing_status'] == 'AVAILABLE']
    return {'jobs': len(rows), 'completed_jobs': sum(r['complete'] for r in rows),
            'timed_completed_jobs': len(timed),
            'timing_unavailable': dict(Counter(r.get('timing_reason') or 'unsuccessful completion' for r in rows
                                              if not r['complete'] or r['timing_status'] != 'AVAILABLE')),
            'exclusive_duration_components_s': {k: describe(r[k] for r in timed) for k in COMPONENTS},
            'placement_wait_s_included_in_pre_admission': describe(r['placement_wait_s'] for r in rows),
            'timed_jobs_post_dispatch_s': describe(r['post_dispatch_s'] for r in timed),
            'maximum_component_sum_error_s': max((abs(r['duration_decomposition_error_s']) for r in timed), default=None)}


def analyze(c6, c5):
    runs = {'c6_from_release': enrich(load_run(c6, 400, 6)), 'c5_event': enrich(load_run(c5, 400, 5))}
    common = sorted(set.intersection(*(set(r['jobs']) for r in runs.values())))
    pair = []
    for key in common:
        a, b = [r['jobs'][key] for r in runs.values()]
        row = {'job_id': key, 'both_dispatched_in_recovery': all(r['dispatch_s'] is not None and 450 <= r['dispatch_s'] < 1950 for r in (a, b)),
               'c6_late': a['late'], 'c5_late': b['late']}
        for field in COMPONENTS + OTHER:
            row['c6_' + field], row['c5_' + field] = a[field], b[field]
            row['delta_' + field] = a[field] - b[field] if a[field] is not None and b[field] is not None else None
        pair.append(row)
    grouped = {}
    for label, selected in (('all_matched_jobs', pair),
                            ('both_dispatched_in_recovery', [r for r in pair if r['both_dispatched_in_recovery']]),
                            ('late_in_either_run', [r for r in pair if r['c6_late'] or r['c5_late']])):
        timed = [r for r in selected if all(r['delta_' + k] is not None for k in COMPONENTS)]
        grouped[label] = {'jobs': len(selected), 'both_component_timings_available': len(timed),
                          'deltas_c6_minus_c5_event_s': {k: describe(r['delta_' + k] for r in timed) for k in COMPONENTS + OTHER}}
    details = {}
    for label, run in runs.items():
        root = Path(run['root'])
        protocol, report = read(root / 'protocol.json'), read(root / 'REPORT.json')
        by_dispatch = {phase: latency_group(r for r in run['jobs'].values()
                                           if r['dispatch_s'] is not None and left <= r['dispatch_s'] < right)
                       for phase, (left, right) in STAGES.items()}
        details[label] = {'root': run['root'], 'outcome': run['outcome'], 'checks': run['checks'],
                          'phase_latency_by_client_dispatch': by_dispatch,
                          'all_jobs_latency': latency_group(run['jobs'].values()),
                          'sampled_admission_conditions': sampled_conditions(root, protocol),
                          'reported_queue_priority': report.get('queue_priority_policy'),
                          'reported_service_checks': report['checks']}
    timeline = []
    for t in sorted(set(range(450, 1951, 30)) | {950, 1450}):
        states = {label: snapshot(run, t) for label, run in runs.items()}
        timeline.append({'at_s': t, **{label + '_' + key: state[key] for label, state in states.items()
                                      for key in ('completed', 'not_dispatched')},
                         'c6_completion_lead': states['c6_from_release']['completed'] - states['c5_event']['completed']})
    late_ids = sorted({k for run in runs.values() for k, row in run['jobs'].items() if row['late'] or not row['complete']})
    return {'status': 'CONVERSATION1904_RECOVERY_SERVICE_ANALYSIS_COMPLETE',
            'same_saved_inputs': all(filecmp.cmp(c6 / name, c5 / name, shallow=False) for name in ('batch_jobs.jsonl', 'online_workload.jsonl')),
            'same_job_identities': all(set(r['jobs']) == set(common) for r in runs.values()),
            'all_saved_counts_match': all(all(r['checks'].values()) for r in runs.values()),
            'runs': details, 'matched_latency': grouped, 'timeline': timeline, 'matched_jobs': pair,
            'job_timings': [{'condition': label, **row} for label, run in runs.items() for row in run['jobs'].values()],
            'late_or_unfinished_jobs': {key: {label: run['jobs'].get(key) for label, run in runs.items()} for key in late_ids},
            'gpu_workload_run': False,
            'limitations': [
                'Original 280-job outcomes and 1950 s cutoff are retained, including missing or late results.',
                'Latency groups use client dispatch intervals [left,right); later successful finishes remain in those groups. Completion snapshots include finishes at their cutoff.',
                'Pre-admission is estimated between the existing client line-read/parsed timestamp bracket. Placement waiting is a subset, not an extra additive component.',
                'Matched duration-difference summaries use jobs with both complete decompositions; all jobs and available raw timing differences remain in the CSV and outcome counts.',
                'Gateway first-text and later client duration do not isolate engine prefill or decode execution. Different request latencies overlap and are not a critical-path decomposition.',
                'Sample categories record simultaneous counts only. Count eligibility uses zero online requests and fewer than two batch requests on a replica; it does not establish a missed scheduling opportunity.',
                'Online waiting and batch waiting are gateway snapshots, not continuous observations or an exact per-job reason for blocking.',
                'Two P400 runs have different event concurrency and recovery-entry states. Descriptive differences do not establish a causal concurrency effect or counterfactual deadline.',
                'No GPU query, new workload, controller change, retry or offer is performed.']}


def main():
    parser = argparse.ArgumentParser()
    for field in ('c6', 'c5', 'output'):
        parser.add_argument('--' + field, type=Path, required=True)
    args = parser.parse_args()
    result = analyze(args.c6, args.c5)
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'REPORT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    for name, rows in (('matched_jobs.csv', result['matched_jobs']), ('job_timings.csv', result['job_timings']), ('timeline.csv', result['timeline'])):
        if rows:
            with (args.output / name).open('w', encoding='utf-8', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
    lines = ['=== CONVERSATION1904_RECOVERY_SERVICE_ANALYSIS ===', 'STATUS=' + result['status']]
    for field in ('same_saved_inputs', 'same_job_identities', 'all_saved_counts_match', 'runs', 'matched_latency', 'late_or_unfinished_jobs'):
        lines.append(field.upper() + '=' + json.dumps(result[field], ensure_ascii=False))
    lines.extend('TIMELINE=' + json.dumps(row) for row in result['timeline'])
    lines.extend(result['limitations'])
    text = '\n'.join(lines) + '\n'
    (args.output / 'REPORT.txt').write_text(text, encoding='utf-8')
    print(text, end='')
    return 0 if all(result[k] for k in ('same_saved_inputs', 'same_job_identities', 'all_saved_counts_match')) else 2


if __name__ == '__main__':
    raise SystemExit(main())
