"""Describe saved workload pressure, phase service, and finite-cohort progress."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path


RUNS = {
    "1768_C4": "no_curtailment_cohort_20260905_111513_P3RcIv",
    "1768_C4_repeat": "c4_reference_repeat_20260905_191635_F3cqPX",
    "1768_cap": "c4_power_cap_cohort_20260905_204643_86mccw",
    "1768_cap_repeat": "c4_power_cap_repeat_20260905_213318_IzEt9X",
    "1704_C4": "azure704_c4_power_pair_20260905_223440_ECvtEv/cells/c4_p400",
    "1704_cap": "azure704_c4_power_pair_20260905_223440_ECvtEv/cells/c4_event_p300",
}
PHASES = {"warmup": (0, 150), "event": (150, 450), "recovery": (450, 1950),
          "recovery_early": (450, 950), "recovery_middle": (950, 1450), "recovery_late": (1450, 1950)}


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def iter_rows(path):
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    position = (len(values) - 1) * q
    index = int(position)
    fraction = position - index
    return values[index] * (1 - fraction) + values[min(index + 1, len(values) - 1)] * fraction


def workload_features(path):
    stages = {name: {"prompt": [], "output": []} for name in PHASES}
    mismatches, total = 0, 0
    for row in iter_rows(path):
        arrival = float(row["arrival_ms"]) / 1000
        prompt, output = len(row["prompt_token_ids"]), int(row["max_output_tokens"])
        mismatches += int(prompt != int(row["prompt_tokens"]))
        total += 1
        for name, (left, right) in PHASES.items():
            if left <= arrival < right:
                stages[name]["prompt"].append(prompt)
                stages[name]["output"].append(output)
    result = {}
    for name, values in stages.items():
        duration = PHASES[name][1] - PHASES[name][0]
        prompts, outputs = values["prompt"], values["output"]
        count = len(prompts)
        result[name] = {
            "requests": count, "scheduled_rps": count / duration,
            "scheduled_prompt_tokens_per_s": sum(prompts) / duration,
            "requested_output_tokens_per_s": sum(outputs) / duration,
            "mean_prompt_tokens": sum(prompts) / count if count else None,
            "prompt_p95_tokens": quantile(prompts, .95),
            "output_p50_tokens": quantile(outputs, .5), "output_p95_tokens": quantile(outputs, .95),
            "prompts_over_chunk2048": sum(p > 2048 for p in prompts),
            "single_output_token_requests": sum(o == 1 for o in outputs),
        }
    return {"input_file": str(path), "total_requests": total,
            "prompt_length_metadata_mismatches": mismatches, "phases": result}


def complete_job(row):
    return row.get("error") is None and row.get("status_code") == 200 \
        and row.get("completion_wall_time_ns") is not None \
        and int(row.get("completion_tokens") or 0) == int(row["max_output_tokens"])


def batch_phase(rows, start_ns, left_s, right_s):
    left, right = start_ns + int(left_s * 1e9), start_ns + int(right_s * 1e9)
    starts, finishes, durations = 0, 0, []
    active_ns = 0
    for row in rows:
        began = row.get("dispatch_wall_time_ns")
        end = row.get("completion_wall_time_ns")
        if began is None:
            continue
        began = int(began)
        if left <= began < right:
            starts += 1
            if complete_job(row):
                durations.append((int(end) - began) / 1e9)
        if complete_job(row):
            finishes += int(left <= int(end) < right)
        active_ns += max(0, min(int(end) if end is not None else right, right) - max(began, left))
    return {"dispatches": starts, "complete_jobs_in_half_open_phase": finishes,
            "mean_client_batch_inflight": active_ns / (right - left),
            "batch_e2e_p50_s_by_dispatch_phase": quantile(durations, .5),
            "batch_e2e_p95_s_by_dispatch_phase": quantile(durations, .95)}


def inspect_run(folder):
    report, protocol = read_json(folder / "REPORT.json"), read_json(folder / "protocol.json")
    online, batches = list(iter_rows(folder / "online.jsonl")), list(iter_rows(folder / "batch.jsonl"))
    phases, discrepancies = {}, []
    for name, (left, right) in PHASES.items():
        rows = [r for r in online if left * 1000 <= float(r["arrival_ms"]) < right * 1000]
        good = [r for r in rows if r.get("error") is None]
        gaps = [float(r["mean_tpot_ms"]) for r in good if r.get("mean_tpot_ms") is not None]
        saved = report["online_recovery_reference"] if name == "recovery" else report["online_by_scheduled_phase"][
            "event_time_reference" if name == "event" else name]
        p99 = quantile(gaps, .99)
        expected = saved["request_mean_stream_gap_p99_ms"]
        matches = len(rows) == saved["requests"] and len(gaps) == saved["request_mean_stream_gap_samples"] \
            and ((p99 is None and expected is None) or (p99 is not None and expected is not None
                 and math.isclose(p99, expected, rel_tol=1e-10, abs_tol=1e-7)))
        if not matches:
            discrepancies.append(name)
        dispatch_delays = [(int(r["dispatch_wall_time_ns"]) - int(protocol["start_wall_ns"])) / 1e6
                           - float(r["arrival_ms"]) for r in rows if r.get("dispatch_wall_time_ns") is not None]
        phases[name] = {
            "online": saved, "raw_latency_matches_saved_report": matches,
            "scheduled_to_dispatch_p95_ms": quantile(dispatch_delays, .95),
            "batch": batch_phase(batches, int(protocol["start_wall_ns"]), left, right)}
    return {"run": str(folder), "slos": report["slos"], "phases": phases,
            "batch_total": report["batch"],
            "not_started_by_deadline": sum(r.get("job_status") == "not_started_by_deadline" for r in batches),
            "latency_replay_mismatches": discrepancies}, online


def paired_recovery(first, second):
    a = {r["request_id"]: r for r in first if 450_000 <= float(r["arrival_ms"]) < 1950_000}
    b = {r["request_id"]: r for r in second if 450_000 <= float(r["arrival_ms"]) < 1950_000}
    counts = {"both_above_100ms": 0, "only_p400_above_100ms": 0, "only_p300_above_100ms": 0,
              "neither_above_100ms": 0}
    metadata = ("arrival_ms", "prompt_tokens", "max_output_tokens", "parent_request_id", "tool_delay_ms")
    mismatches, missing_gap = [], 0
    for key in sorted(a.keys() & b.keys()):
        if any(a[key].get(k) != b[key].get(k) for k in metadata):
            mismatches.append(key)
            continue
        x, y = a[key].get("mean_tpot_ms"), b[key].get("mean_tpot_ms")
        if a[key].get("error") is not None or b[key].get("error") is not None or x is None or y is None:
            missing_gap += 1
            continue
        label = ("both_above_100ms" if x > 100 and y > 100 else "only_p400_above_100ms" if x > 100
                 else "only_p300_above_100ms" if y > 100 else "neither_above_100ms")
        counts[label] += 1
    return {"matched_requests": len(a.keys() & b.keys()), "unmatched_p400": len(a.keys() - b.keys()),
            "unmatched_p300": len(b.keys() - a.keys()), "metadata_mismatches": mismatches,
            "without_two_valid_gap_values": missing_gap, "counts": counts}


def format_report(report):
    def f(value):
        return "NA" if value is None else f"{value:.2f}"
    lines = ["=== C4_WORKLOAD_CAPACITY_AUDIT ===", "STATUS=" + report["status"],
             "CPU_ONLY: existing recorded inputs and requests; no GPU workload or source changes.",
             "=== WORKLOAD_FEATURES ===",
             "case phase requests rps prompt_tokens/s output_tokens/s mean_prompt prompt_p95 output_p95"]
    for label, data in report["workloads"].items():
        lines.append("INPUT=" + label + " PROMPT_LENGTH_METADATA_MISMATCHES="
                     + str(data["prompt_length_metadata_mismatches"]))
        for phase, values in data["phases"].items():
            fields = [values[k] for k in ("requests", "scheduled_rps", "scheduled_prompt_tokens_per_s",
                      "requested_output_tokens_per_s", "mean_prompt_tokens", "prompt_p95_tokens", "output_p95_tokens")]
            lines.append(label + " " + phase + " " + " ".join(f(v) for v in fields))
    lines += ["=== SAVED_PHASE_SERVICE_AND_BATCH ===",
              "run phase gap_samples gap_p99_ms TTFT_p95_ms tail_count safe dispatch_p95_ms batch_starts batch_finishes mean_client_batch batch_e2e_p50_s"]
    for label, data in report["runs"].items():
        lines.append("RUN=" + label + " PATH=" + data["run"])
        for phase, values in data["phases"].items():
            o, b = values["online"], values["batch"]
            fields = [o["request_mean_stream_gap_samples"], o["request_mean_stream_gap_p99_ms"], o["ttft_p95_ms"],
                      o["requests_with_mean_stream_gap_over_slo"], int(o["observed_slo_safe"]), values["scheduled_to_dispatch_p95_ms"],
                      b["dispatches"], b["complete_jobs_in_half_open_phase"], b["mean_client_batch_inflight"],
                      b["batch_e2e_p50_s_by_dispatch_phase"]]
            lines.append(label + " " + phase + " " + " ".join(f(v) for v in fields))
        lines.append("LATENCY_REPLAY_MISMATCHES=" + json.dumps(data["latency_replay_mismatches"]))
        lines.append("BATCH_TOTAL=" + json.dumps({k: data["batch_total"][k] for k in
            ("jobs_completed_on_time", "jobs_completed_late", "jobs_unfinished_or_failed")} | {
            "not_started_by_deadline": data["not_started_by_deadline"]}))
    lines += ["=== AZURE1704_MATCHED_RECOVERY ===", json.dumps(report["paired_recovery_1704"]),
              "=== INTERPRETATION_LIMITS ==="]
    lines.extend(report["limitations"])
    if report["errors"]:
        lines += ["=== ITEMS_TO_CONFIRM ===", json.dumps(report["errors"], ensure_ascii=False)]
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    results = args.project / "results"
    report = {"status": "C4_WORKLOAD_CAPACITY_AUDIT_COMPLETE", "workloads": {}, "runs": {}, "errors": [],
              "paired_recovery_1704": None, "gpu_workload_run": False,
              "limitations": [
                  "Arrival timestamps are already stretched in saved input files; no second scaling is applied.",
                  "Prompt/output rates describe scheduled input demand, not measured GPU token throughput.",
                  "Warmup is a different time segment; warmup success alone cannot prove online-only safety over the later workload.",
                  "Mean client batch inflight and batch E2E include gateway/service time; no engine-phase cause is established.",
                  "Scheduled-to-dispatch delay includes dependency waits; it is not an isolated engine queue time.",
                  "Recovery and its three subphases overlap; they are not independent samples.",
                  "The two episodes differ in workload content and arrival pattern; request count is not the only changed property."]}
    for label, folder in (("1768", RUNS["1768_C4"]), ("1704", RUNS["1704_C4"])):
        try:
            report["workloads"][label] = workload_features(results / folder / "online_workload.jsonl")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            report["errors"].append({"item": label, "status": "待确认", "error": str(exc)})
    online_1704 = {}
    for label, folder in RUNS.items():
        try:
            data, online = inspect_run(results / folder)
            report["runs"][label] = data
            if label.startswith("1704"):
                online_1704[label] = online
        except (OSError, ValueError, KeyError, TypeError) as exc:
            report["errors"].append({"item": label, "status": "待确认", "error": str(exc)})
    if len(online_1704) == 2:
        report["paired_recovery_1704"] = paired_recovery(online_1704["1704_C4"], online_1704["1704_cap"])
    if report["errors"] or any(r["latency_replay_mismatches"] for r in report["runs"].values()) \
            or any(w["prompt_length_metadata_mismatches"] for w in report["workloads"].values()):
        report["status"] = "C4_WORKLOAD_CAPACITY_AUDIT_PARTIAL"
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "REPORT.json").write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    text = format_report(report)
    (args.output / "REPORT.txt").write_text(text, encoding="utf-8")
    print(text, end="")
    print("REPORT_TXT=" + str(args.output / "REPORT.txt"))
    print("REPORT_JSON=" + str(args.output / "REPORT.json"))


if __name__ == "__main__":
    main()
