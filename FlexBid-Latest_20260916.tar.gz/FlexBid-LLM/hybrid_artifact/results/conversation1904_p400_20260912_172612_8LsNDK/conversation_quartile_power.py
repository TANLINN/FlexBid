"""Integrate same-trace power differences over fixed measurement windows."""
import cohort_phase_measurement as measure

def paired_power_comparison(p400, p300):
    reference, treatment = measure.gpu_series(p400), measure.gpu_series(p300)

    def compare(left, right):
        a, b = measure.power_window(reference, left, right), measure.power_window(treatment, left, right)
        covered = a['covered'] and b['covered']
        return {'reference': a, 'treatment': b,
                'paired_reduction_w': a['mean_gpu_w'] - b['mean_gpu_w'] if covered else None,
                'energy_saved_wh': a['gpu_energy_wh'] - b['gpu_energy_wh'] if covered else None}

    windows = [dict(window=i, **compare(150 + 30 * i, 180 + 30 * i)) for i in range(10)]
    reductions = [row['paired_reduction_w'] for row in windows]
    covered = all(value is not None for value in reductions)
    stages = {name: compare(left, right) for name, left, right in
              (('event', 150, 450), ('recovery', 450, 1950), ('full_horizon', 150, 1950))}
    recovery_delta = stages['recovery']['paired_reduction_w']
    return {'reference_run': str(p400), 'treatment_run': str(p300),
            'boundary': 'aggregate_gpu_power_w', 'difference_direction': 'P400 minus event-P300',
            'alignment': 'Fixed relative 150/450/1950 s boundaries; actuation delays remain included.',
            'event_30s_windows': windows, 'all_event_windows_covered': covered,
            'minimum_paired_window_reduction_w': min(reductions) if covered else None,
            'all_paired_event_windows_positive': all(value > 0 for value in reductions) if covered else None,
            'stages': stages,
            'recovery_mean_power_above_reference_w': -recovery_delta if recovery_delta is not None else None,
            'offered_bid_w': None,
            'interpretation': 'Same saved workload and placement policy; measured P400 minus P300 differences also contain execution and run-order variation. No prospective offer or statistical delivery guarantee.'}
