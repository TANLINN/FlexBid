"""Relate saved replica choices and stream intervals to observed online latency."""
import argparse
import ast
from bisect import bisect_right
from collections import Counter, defaultdict
import json
from pathlib import Path

RUNS = {
    'c4': 'azure704_admission4_cohort_20260906_190720_4EGgYu',
    'c5': 'azure704_admission4_c5_cohort_20260906_213410_rVau5R',
}


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_rows(path):
    with path.open(encoding='utf-8') as stream:
        return [json.loads(line) for line in stream if line.strip()]


def quantile(values, level):
    values = sorted(values)
    if not values:
        return None
    position = (len(values) - 1) * level
    left = int(position)
    return values[left] + (position - left) * (values[min(left + 1, len(values) - 1)] - values[left])


def describe(values):
    values = [float(v) for v in values if v is not None]
    return {'samples': len(values), 'p50': quantile(values, .5), 'p95': quantile(values, .95),
            'p99': quantile(values, .99), 'min': min(values) if values else None,
            'max': max(values) if values else None}


def saved_rule(path):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    state = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'State')
    choose = next(n for n in state.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'choose')
    keys = [k.value for n in ast.walk(choose) if isinstance(n, ast.Call)
            and isinstance(n.func, ast.Name) and n.func.id == 'min'
            for k in n.keywords if k.arg == 'key']
    expected = ast.parse('lambda item: (self.inflight[item], self.inflight_batch[item], item)', mode='eval').body
    return {'saved_choose_function': ast.unparse(choose),
            'key_matches_total_then_batch_then_index': len(keys) == 1 and ast.dump(keys[0]) == ast.dump(expected)}


def placement(record, allowed):
    chosen = int(record['replica'])
    on = list(map(int, record['inflight_after_selection']['online']))
    ba = list(map(int, record['inflight_after_selection']['batch']))
    on[chosen] -= 1
    if min(on + ba) < 0 or chosen not in allowed:
        raise ValueError('Invalid pre-choice counts: ' + record['request_id'])
    score = lambda i: (on[i] + ba[i], ba[i], i)
    expected = min(allowed, key=score)
    candidates = [i for i in allowed if on[i] == 0]
    free_choice = min(candidates, key=score) if candidates else None
    concentrated = on[chosen] > 0 and free_choice is not None
    reason = None
    if concentrated:
        if score(chosen)[0] < score(free_choice)[0]:
            reason = 'selected_replica_has_lower_total_count'
        elif score(chosen)[0] == score(free_choice)[0] and ba[chosen] < ba[free_choice]:
            reason = 'equal_total_count_batch_tiebreak_favors_online_occupied'
        else:
            reason = 'other_or_reference_rule_mismatch'
    return {'request_id': record['request_id'], 'replica': chosen,
            'online_before': on, 'batch_before': ba,
            'selected_online_count_after_admission': on[chosen] + 1,
            'reference_rule_choice_matches': chosen == expected,
            'online_free_alternative': free_choice,
            'fully_idle_alternatives': [i for i in candidates if ba[i] == 0],
            'selected_online_occupied_with_online_free_alternative': concentrated,
            'comparison_reason': reason}


def summarize_requests(items, gap_slo, ttft_slo):
    good = [r for r in items if r['error'] is None and r['status_code'] == 200]
    gaps = [r['mean_gap_ms'] for r in good if r['mean_gap_ms'] is not None]
    ttft = [r['ttft_ms'] for r in good if r['ttft_ms'] is not None]
    return {'requests': len(items), 'errors': len(items) - len(good), 'gap_samples': len(gaps),
            'gap_p99_ms': quantile(gaps, .99), 'gap_tail_requests': sum(v > gap_slo for v in gaps),
            'ttft_p95_ms': quantile(ttft, .95), 'requests_with_ttft_over_threshold': sum(v > ttft_slo for v in ttft),
            'post_admission_to_first_upstream_text_ms': describe([r['post_admission_first_ms'] for r in good]),
            'ttft_minus_post_admission_first_ms': describe([r['residual_ms'] for r in good])}


def analyze_records(online, gateway, allowed, gap_slo, ttft_slo):
    mapping = {r['request_id']: r for r in gateway}
    if len(mapping) != len(gateway):
        raise ValueError('Gateway request IDs are not unique')
    if len({r['request_id'] for r in online}) != len(online):
        raise ValueError('Online request IDs are not unique')
    if {r['request_id'] for r in online} != {r['request_id'] for r in gateway if r['class'] == 'online'}:
        raise ValueError('Online and gateway request IDs differ')
    # These intervals end at the first observed upstream text, not at engine prefill completion.
    pending = {}
    for replica in allowed:
        for kind in ('online', 'batch'):
            records = [r for r in gateway if int(r['replica']) == replica and r['class'] == kind and r['events']]
            pending[(replica, kind)] = (
                sorted(int(r['admitted_mono_ns']) for r in records),
                sorted(int(r['events'][0]['upstream_read_ns']) for r in records))
    all_choices, evaluated = [], []
    context = {name: Counter() for name in ('gap_tail_requests', 'other_valid_gap_requests')}
    for row in online:
        record = mapping[row['request_id']]
        choice = placement(record, allowed)
        all_choices.append(choice)
        if not 150000 <= float(row['arrival_ms']) < 1950000:
            continue
        events = record['events']
        client_events = row.get('stream_observations', [])
        if record['parse_errors'] or len(events) != len(client_events) or any(
                a['sequence'] != b['sequence'] or a['response_id'] != b['response_id'] or a['text_chars'] != b['text_chars']
                for a, b in zip(events, client_events)):
            raise ValueError('Stream event alignment differs: ' + row['request_id'])
        post = (int(events[0]['upstream_read_ns']) - int(record['admitted_mono_ns'])) / 1e6 if events else None
        ttft = row.get('ttft_ms')
        gap = row.get('mean_tpot_ms')
        item = {**choice, 'ttft_ms': ttft, 'mean_gap_ms': gap,
                'post_admission_first_ms': post,
                'residual_ms': float(ttft) - post if ttft is not None and post is not None else None,
                'error': row.get('error'), 'status_code': row.get('status_code')}
        evaluated.append(item)
        if row.get('error') is not None or row.get('status_code') != 200 or gap is None:
            continue
        group = context['gap_tail_requests' if float(gap) > gap_slo else 'other_valid_gap_requests']
        group['requests'] += 1
        classes_in_request = set()
        for a, b in zip(events, events[1:]):
            left, right = int(a['upstream_read_ns']), int(b['upstream_read_ns'])
            if right < left:
                raise ValueError('Nonmonotonic stream: ' + row['request_id'])
            group['all_inter_message_gaps'] += 1
            if (right - left) / 1e6 <= gap_slo:
                continue
            midpoint = (left + right) // 2
            counts = {}
            for kind in ('online', 'batch'):
                starts, ends = pending[(int(record['replica']), kind)]
                counts[kind] = bisect_right(starts, midpoint) - bisect_right(ends, midpoint)
                if counts[kind] < 0:
                    raise ValueError('Invalid pending-first interval counts')
            category = 'both' if counts['online'] and counts['batch'] else 'online_only' if counts['online'] else 'batch_only' if counts['batch'] else 'neither'
            group['long_gaps'] += 1
            group['long_gaps_pending_' + category] += 1
            classes_in_request.add(category)
        for category in classes_in_request:
            group['requests_with_long_gaps_pending_' + category] += 1
    by_count = defaultdict(list)
    by_placement = defaultdict(list)
    by_replica = defaultdict(list)
    for r in evaluated:
        by_count[str(r['selected_online_count_after_admission'])].append(r)
        by_replica[str(r['replica'])].append(r)
        label = 'online_occupied_with_online_free_alternative' if r['selected_online_occupied_with_online_free_alternative'] else 'online_free_selected' if r['selected_online_count_after_admission'] == 1 else 'online_occupied_no_online_free_alternative'
        by_placement[label].append(r)
    selected = [r for r in evaluated if r['selected_online_occupied_with_online_free_alternative']]
    fields = ['requests', 'all_inter_message_gaps', 'long_gaps']
    fields += ['long_gaps_pending_' + c for c in ('online_only', 'batch_only', 'both', 'neither')]
    fields += ['requests_with_long_gaps_pending_' + c for c in ('online_only', 'batch_only', 'both', 'neither')]
    return {
        'online_records': len(online), 'evaluation_requests': len(evaluated),
        'reference_rule_matches_all_admissions': sum(r['reference_rule_choice_matches'] for r in all_choices),
        'reference_rule_mismatches_first8': [r for r in all_choices if not r['reference_rule_choice_matches']][:8],
        'evaluation': summarize_requests(evaluated, gap_slo, ttft_slo),
        'by_selected_online_count_after_admission': {k: summarize_requests(v, gap_slo, ttft_slo) for k, v in sorted(by_count.items())},
        'by_placement': {k: summarize_requests(v, gap_slo, ttft_slo) for k, v in sorted(by_placement.items())},
        'by_replica': {k: summarize_requests(v, gap_slo, ttft_slo) for k, v in sorted(by_replica.items())},
        'online_occupied_with_online_free_alternative': len(selected),
        'fully_idle_alternative_in_those_choices': sum(bool(r['fully_idle_alternatives']) for r in selected),
        'placement_reasons': dict(Counter(r['comparison_reason'] for r in selected)),
        'long_gap_pending_class': {name: {k: value[k] for k in fields} for name, value in context.items()},
        'placement_examples_highest_ttft': sorted(selected, key=lambda r: -(r['ttft_ms'] if r['ttft_ms'] is not None else -1))[:4],
    }


def format_report(report):
    def number(value):
        return 'NA' if value is None else f'{value:.3f}'
    lines = ['=== ADMISSION4_C5_PLACEMENT_ANALYSIS ===', 'STATUS=' + report['status']]
    for label, value in report['runs'].items():
        lines.extend(['=== ' + label.upper() + ' ===', 'RUN=' + value['run'],
                      'SAVED_RULE_MATCH=' + str(value['routing_source']['key_matches_total_then_batch_then_index']),
                      'SUMMARY_RECONCILIATION=' + json.dumps(value['summary_reconciliation'])])
        for key in ('online_records', 'evaluation_requests', 'reference_rule_matches_all_admissions',
                    'online_occupied_with_online_free_alternative', 'fully_idle_alternative_in_those_choices',
                    'placement_reasons', 'reference_rule_mismatches_first8'):
            lines.append(key.upper() + '=' + json.dumps(value[key], ensure_ascii=False))
        lines.append('group requests gap_n gap_tails gap_p99_ms ttft_p95_ms post_admission_first_p95_ms residual_p95_ms')
        for key, prefix in (('by_selected_online_count_after_admission', 'selected_online_count'),
                            ('by_placement', 'placement'), ('by_replica', 'replica')):
            for name, item in value[key].items():
                values = [item[k] for k in ('requests', 'gap_samples', 'gap_tail_requests', 'gap_p99_ms', 'ttft_p95_ms')]
                values += [item['post_admission_to_first_upstream_text_ms']['p95'], item['ttft_minus_post_admission_first_ms']['p95']]
                lines.append(prefix + ':' + name + ' ' + ' '.join(number(v) for v in values))
        lines.append('request_group requests all_gaps long_gaps pending_online_only pending_batch_only pending_both pending_neither')
        for name, item in value['long_gap_pending_class'].items():
            fields = ('requests', 'all_inter_message_gaps', 'long_gaps', 'long_gaps_pending_online_only',
                      'long_gaps_pending_batch_only', 'long_gaps_pending_both', 'long_gaps_pending_neither')
            lines.append(name + ' ' + ' '.join(str(item[k]) for k in fields))
        lines.append('PLACEMENT_EXAMPLES=' + json.dumps(value['placement_examples_highest_ttft'][:2], ensure_ascii=False))
    if report['runs']['c4']['routing_source']['saved_choose_function'] == report['runs']['c5']['routing_source']['saved_choose_function']:
        lines.append('SAVED_CHOOSE_FUNCTION=' + report['runs']['c5']['routing_source']['saved_choose_function'])
    else:
        for label, value in report['runs'].items():
            lines.append(label.upper() + '_SAVED_CHOOSE_FUNCTION=' + value['routing_source']['saved_choose_function'])
    lines.extend(report['limitations'])
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = {'status': 'ADMISSION4_C5_PLACEMENT_ANALYSIS_COMPLETE', 'gpu_workload_run': False, 'runs': {},
              'limitations': [
                  'Saved observations only; no inference request, service launch, routing change or experiment retry.',
                  'The alternative is online-free at the same saved snapshot, not necessarily batch-free or safe; no counterfactual latency is predicted.',
                  'Pre-choice counts subtract the admitted online request from its recorded post-choice counts; the saved routing source is reported.',
                  'Admission to first upstream text includes upstream queueing and execution; it is not GPU prefill time.',
                  'TTFT minus that interval includes pre-admission waiting and client/transport overhead; it is not pure gateway queueing time.',
                  'First-text pending classes use observed admission/first-text intervals. Temporal overlap alone does not identify the engine cause.',
                  'Request groups differ in workload and phase; group associations and overlapping interval counts are not causal effect estimates.',
                  'The online SLO remains p99 of per-request mean nonempty SSE-text gaps; short outputs and scheduled-phase membership are retained.']}
    for label, dirname in RUNS.items():
        folder = args.project / 'results' / dirname
        saved = read_json(folder / 'REPORT.json')
        control = read_json(folder / 'control.json')
        allowed = list(map(int, control['online_replica_ids']))
        if allowed != [0, 1, 2, 3]:
            raise ValueError('Saved online replica set differs from the four-replica experiment')
        gap_slo = float(saved['slos']['request_mean_stream_gap_p99_ms'])
        ttft_slo = float(saved['slos']['ttft_p95_ms'])
        online, gateways = read_rows(folder / 'online.jsonl'), read_rows(folder / 'stream_gateway.jsonl')
        value = analyze_records(online, gateways, allowed, gap_slo, ttft_slo)
        value['run'] = str(folder)
        value['routing_source'] = saved_rule(folder / 'priority_gateway.py')
        original = saved['phases']['evaluation']['mixed' if label == 'c4' else 'c5']
        value['summary_reconciliation'] = {
            'request_count_matches': value['evaluation_requests'] == original['requests'],
            'gap_sample_count_matches': value['evaluation']['gap_samples'] == original['request_mean_stream_gap_samples'],
            'gap_tail_count_matches': value['evaluation']['gap_tail_requests'] == original['requests_with_mean_stream_gap_over_slo'],
            'gap_p99_absolute_difference_ms': abs(value['evaluation']['gap_p99_ms'] - original['request_mean_stream_gap_p99_ms']),
            'ttft_p95_absolute_difference_ms': abs(value['evaluation']['ttft_p95_ms'] - original['ttft_p95_ms']),
        }
        result['runs'][label] = value
        del online, gateways
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'REPORT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    text = format_report(result)
    (args.output / 'REPORT.txt').write_text(text, encoding='utf-8')
    print(text, end='')
    print('REPORT_TXT=' + str(args.output / 'REPORT.txt'))


if __name__ == '__main__':
    main()
