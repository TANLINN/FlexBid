"""Compare recorded on/off/on recovery runs without changing their results."""
import filecmp
import json
from pathlib import Path

ON_NAME = 'azure704_queue_priority_recovery_20260908_125836_Dhxd7a'
OFF_NAME = 'azure704_queue_priority_ablation_20260908_141730_mFimH0'


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def admission_counts(folder, protocol):
    start = int(protocol['start_wall_ns'])
    counts = {phase: {'batch_admissions': 0, 'while_online_queued': 0, 'policy_enabled': 0,
                      'previously_deferred_for_online': 0} for phase in ('event', 'recovery', 'outside')}
    missing = 0
    with (folder / 'stream_gateway.jsonl').open(encoding='utf-8') as stream:
        for line in stream:
            if not line.strip():
                continue
            row = json.loads(line)
            if row['class'] != 'batch':
                continue
            context = row['inflight_after_selection'].get('online_queue_priority')
            if context is None:
                missing += 1
                continue
            elapsed = (int(context['selection_wall_time_ns']) - start) / 1e9
            phase = 'event' if 150 <= elapsed < 450 else 'recovery' if 450 <= elapsed < 1950 else 'outside'
            item = counts[phase]
            item['batch_admissions'] += 1
            item['while_online_queued'] += int(context['queued_online_at_selection'] > 0)
            item['policy_enabled'] += int(context['enabled'])
            item['previously_deferred_for_online'] += int(context['deferred_for_online'])
    return {'by_selection_phase': counts, 'missing_batch_contexts': missing}


def summarize(output):
    import yaml
    from run_azure704_queue_priority_recovery import normalized_configuration
    folders = {'on_first': output.parent / ON_NAME, 'off': output.parent / OFF_NAME, 'on_repeat': output}
    own_labels = {'on_first': 'queue_priority', 'off': 'priority_off', 'on_repeat': 'queue_priority'}
    reports = {key: load(folder / 'REPORT.json') for key, folder in folders.items()}
    configs = {key: normalized_configuration(yaml.safe_load((folder / 'config.yaml').read_text(encoding='utf-8')))
               for key, folder in folders.items()}
    environments = {key: load(folder / 'ENVIRONMENT.json') for key, folder in folders.items()}
    environment_fields = ('platform', 'python', 'packages', 'torch_cuda', 'gpu_inventory', 'migration_record_directory')
    changes = {field: {key: value.get(field) for key, value in environments.items()}
               for field in environment_fields if any(value.get(field) != environments['on_first'].get(field) for value in environments.values())}
    filenames = ('priority_gateway.py', 'first_text_admission_tools.py', 'replica_batch_limit_tools.py',
                 'stream_trace_tools.py', 'stream_context_tools.py', 'online_queue_priority_tools.py',
                 'online_workload.jsonl', 'batch_jobs.jsonl')
    equal = {name: all(filecmp.cmp(folders['on_first'] / name, folder / name, shallow=False)
                            for folder in folders.values()) for name in filenames}
    runs = {}
    for label, folder in folders.items():
        report, own = reports[label], own_labels[label]
        middle = report['phases']['recovery_middle'][own]
        timing = report['ttft_decomposition'][own]['recovery_middle']
        runs[label] = {
            'run': str(folder), 'measurement_status': report['status'],
            'failed_checks': [k for k, value in report['checks'].items() if not value],
            'aggregate_service_and_deadline_pass': report['service_and_deadline_pass_observed'],
            'original_joint_pass': report['joint_pass_observed'],
            'middle_service_and_deadline_pass': report['middle_service_and_deadline_pass_observed'],
            'online_requests': report['online_requests'], 'online_incomplete_or_error_count': report['online_incomplete_or_error_count'],
            'middle_requests': middle['requests'], 'middle_ttft_p95_ms': middle['ttft_p95_ms'],
            'middle_ttft_tail_requests': timing['ttft_tail_requests'],
            'middle_gap_p99_ms': middle['request_mean_stream_gap_p99_ms'],
            'batch': report['batch'], 'cohort_timing': report['cohort_timing'],
            'control_batch_limits': report['control_batch_limits'],
            'control_phase_flags': report['queue_priority_policy']['control_phase_flags'],
            'admission_counts': admission_counts(folder, load(folder / 'protocol.json')),
            'middle_gateway_snapshots': timing['gateway_snapshots'],
            'phases': {phase: report['phases'][phase][own] for phase in report['phases']},
            'gpu_power': report['gpu_power'], 'paired_power': report['paired_power'],
        }
    result = {
        'status': 'QUEUE_PRIORITY_ON_OFF_ON_MEASURED', 'run_order': list(folders),
        'evidence_unit': 'Three sequential physical runs of one reused trace; not independent workloads or randomized treatment order.',
        'comparability': {'saved_files_identical': equal, 'reported_service_configuration_equal': len({json.dumps(c, sort_keys=True) for c in configs.values()}) == 1,
                          'environment_field_differences': changes,
                          'phase_flags_match_on_off_on': [r['control_phase_flags'] for r in runs.values()] == [[False,False,True],[False,False,False],[False,False,True]],
                          'batch_limits_unchanged': all(r['control_batch_limits'] == [5,5,6] for r in runs.values())},
        'middle_service_and_deadline_pattern': [r['middle_service_and_deadline_pass'] for r in runs.values()],
        'runs': runs,
        'limitations': [
            'Aggregate joint pass does not imply recovery-middle service pass; both are retained without changing the original definition.',
            'A repeated on/off/on association strengthens mechanism evidence on this trace, but does not provide a significance test or a cross-trace guarantee.',
            'Admission counts use actual selection times and separate event from recovery; whole-run queued admissions cannot be compared with recovery-only violations.',
            'Event-period differences precede the recovery flag difference and describe run variation, not recovery-policy benefit.',
            'The original SLO remains p95 TTFT <= 5000 ms and p99 per-request mean nonempty SSE-text gap <= 100 ms. Tail counts are diagnostics.',
            'Paired power values reuse the same earlier P400 reference; they are retrospective and are not independent power pairs or prospective offers.',
            'All 280 batch jobs retain their original release time and deadline; late or unfinished work remains a failure.'
        ]
    }
    return result


def format_report(report):
    def number(value):
        return 'NA' if value is None else f'{value:.3f}'
    lines = ['=== QUEUE_PRIORITY_ON_OFF_ON_RESULT ===', 'STATUS=' + report['status'],
             'COMPARABILITY=' + json.dumps(report['comparability']),
             'condition middle_TTFT_p95_ms middle_TTFT_tails middle_gap_p99_ms jobs_on_time slack_s aggregate_pass middle_pass']
    for label, row in report['runs'].items():
        lines.append(' '.join([label, number(row['middle_ttft_p95_ms']), str(row['middle_ttft_tail_requests']),
                               number(row['middle_gap_p99_ms']), str(row['batch']['jobs_completed_on_time']),
                               number(row['cohort_timing']['all_job_completion_slack_s']),
                               str(row['aggregate_service_and_deadline_pass']), str(row['middle_service_and_deadline_pass'])]))
        lines.append('RUN_DETAIL=' + json.dumps({'condition': label, **{k: row[k] for k in (
            'run','measurement_status','failed_checks','online_requests','online_incomplete_or_error_count',
            'original_joint_pass','batch','control_batch_limits','control_phase_flags','admission_counts','middle_gateway_snapshots')}}))
    lines.append('phase condition requests TTFT_p95_ms mean_text_gap_p99_ms safe')
    for phase in ('warmup','event_time_reference','recovery','recovery_early','recovery_middle','recovery_late','evaluation'):
        for label, row in report['runs'].items():
            value = row['phases'][phase]
            lines.append(' '.join([phase,label,str(value['requests']),str(value['ttft_p95_ms']),
                                   str(value['request_mean_stream_gap_p99_ms']),str(value['observed_slo_safe'])]))
    for label, row in report['runs'].items():
        pair = row['paired_power']
        lines.append('POWER=' + json.dumps({'condition': label, 'measured_stages': row['gpu_power']['stages'],
                                            'p400_reference': pair['reference_run'], 'retrospective_event_difference_w': pair['stages']['event']['paired_reduction_w'],
                                            'minimum_event_window_difference_w': pair['minimum_paired_window_reduction_w']}))
    lines.append('MIDDLE_SERVICE_AND_DEADLINE_PATTERN=' + json.dumps(report['middle_service_and_deadline_pattern']))
    lines.extend(report['limitations'])
    return '\n'.join(lines) + '\n'


def write_report(output):
    from run_azure704_queue_priority_recovery import write_json
    report = summarize(output)
    write_json(output / 'SEQUENCE_REPORT.json', report)
    (output / 'SEQUENCE_REPORT.txt').write_text(format_report(report), encoding='utf-8')
    print(format_report(report), end='', flush=True)

