"""Repeat the recorded priority-on execution, then compare on/off/on outcomes."""
import argparse
from pathlib import Path
import sys

import run_azure704_queue_priority_recovery as measured
from queue_priority_sequence_report import write_report


def main():
    measured.main()
    if '--workload' in sys.argv:
        return
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--output', type=Path, required=True)
    args, _ = parser.parse_known_args()
    try:
        write_report(args.output.resolve())
    except BaseException as exc:
        measured.write_json(args.output / 'SEQUENCE_ANALYSIS_FAILED.json', {
            'stage': 'post_measurement_comparison', 'error_type': type(exc).__name__, 'error': str(exc),
            'measurement_report': str(args.output / 'REPORT.json'), 'automatic_retry': False})
        raise


if __name__ == '__main__':
    main()

