from bisect import bisect_left, bisect_right
from collections import Counter
from datetime import datetime
from importlib import metadata
from pathlib import Path
import json
import re
import sys
import tempfile

def active_at(starts, ends, instant):
    return bisect_right(starts, instant) - bisect_right(ends, instant)

def strictly_inside(times, left, right):
    return bisect_left(times, right) - bisect_right(times, left)

def describe(values):
    ordered = sorted(values)

    def q(level):
        if not ordered:
            return None
        pos = (len(ordered) - 1) * level
        low = int(pos)
        return ordered[low] + (pos - low) * (ordered[min(low + 1, len(ordered) - 1)] - ordered[low])
    return {'count': len(ordered), 'p50': q(0.5), 'p95': q(0.95), 'p99': q(0.99), 'max': ordered[-1] if ordered else None}

def analyze(online, gateway, threshold):
    by_id = {row['request_id']: row for row in gateway}
    if len(by_id) != len(gateway):
        raise ValueError('Duplicate gateway request IDs; no context statistics produced.')
    replicas = sorted({row['replica'] for row in gateway})
    index = {}
    for replica in replicas:
        rows = [row for row in gateway if row['replica'] == replica and row['events']]
        index[replica] = {'starts': sorted((int(row['admitted_mono_ns']) for row in rows)), 'lasts': sorted((int(row['events'][-1]['upstream_read_ns']) for row in rows)), 'firsts': sorted((int(row['events'][0]['upstream_read_ns']) for row in rows)), 'same_events': sorted((int(e['upstream_read_ns']) for row in rows for e in row['events'])), 'other_events': sorted((int(e['upstream_read_ns']) for row in gateway if row['replica'] != replica for e in row['events']))}
    groups = {'client_mean_above_slo': Counter(), 'client_mean_at_or_below_slo': Counter()}
    gaps_by_group = {name: [] for name in groups}
    admissions = {}
    request_context = []
    for row in online:
        if not 150000 <= float(row['arrival_ms']) < 1950000:
            continue
        if row.get('error') is not None or row.get('status_code') != 200:
            continue
        g = by_id[row['request_id']]
        events = g['events']
        if g['parse_errors'] or len(events) != len(row.get('stream_observations', [])):
            raise ValueError('Stream alignment needs inspection: ' + row['request_id'])
        if len(events) < 2:
            continue
        tail = float(row['mean_tpot_ms']) > threshold
        name = 'client_mean_above_slo' if tail else 'client_mean_at_or_below_slo'
        summary = groups[name]
        summary['requests'] += 1
        replica = g['replica']
        ix = index[replica]
        count = int(g['inflight_after_selection']['online'][int(replica)])
        admission_group = str(count)
        admissions.setdefault(admission_group, {'requests': 0, 'client_tail_requests': 0})
        admissions[admission_group]['requests'] += 1
        admissions[admission_group]['client_tail_requests'] += int(tail)
        item = {'request_id': row['request_id'], 'replica': replica, 'output_tokens': row['max_output_tokens'], 'client_tail': tail, 'client_mean_gap_ms': row['mean_tpot_ms'], 'long_gaps': []}
        for a, b in zip(events, events[1:]):
            left, right = (int(a['upstream_read_ns']), int(b['upstream_read_ns']))
            if right < left:
                raise ValueError('Nonmonotonic gateway events: ' + row['request_id'])
            gap_ms = (right - left) / 1000000.0
            summary['all_inter_message_gaps'] += 1
            if gap_ms <= threshold:
                continue
            mid = (left + right) // 2
            others = active_at(ix['starts'], ix['lasts'], mid) - 1
            pending_first = active_at(ix['starts'], ix['firsts'], mid)
            inner_left = left + (right - left) // 10
            inner_right = right - (right - left) // 10
            same_messages = strictly_inside(ix['same_events'], inner_left, inner_right)
            other_messages = strictly_inside(ix['other_events'], inner_left, inner_right)
            if others < 0 or pending_first < 0:
                raise ValueError('Invalid admission/stream interval order: ' + row['request_id'])
            summary['long_inter_message_gaps'] += 1
            summary['long_gaps_with_other_same_replica_observed_request_at_midpoint'] += int(others > 0)
            summary['long_gaps_with_same_replica_request_waiting_for_first_text_at_midpoint'] += int(pending_first > 0)
            summary['long_gaps_with_other_same_replica_text_in_central_80pct'] += int(same_messages > 0)
            summary['long_gaps_with_other_replica_text_in_central_80pct'] += int(other_messages > 0)
            gaps_by_group[name].append(gap_ms)
            item['long_gaps'].append({'sequence_before': a['sequence'], 'gap_ms': gap_ms, 'other_same_replica_observed_requests_at_midpoint': others, 'same_replica_waiting_first_text_at_midpoint': pending_first, 'same_replica_texts_in_central_80pct': same_messages, 'other_replica_texts_in_central_80pct': other_messages})
        request_context.append(item)
    fields = ['requests', 'all_inter_message_gaps', 'long_inter_message_gaps', 'long_gaps_with_other_same_replica_observed_request_at_midpoint', 'long_gaps_with_same_replica_request_waiting_for_first_text_at_midpoint', 'long_gaps_with_other_same_replica_text_in_central_80pct', 'long_gaps_with_other_replica_text_in_central_80pct']
    result = {name: {**{key: groups[name][key] for key in fields}, 'long_gap_ms': describe(gaps_by_group[name])} for name in groups}
    return ({'groups': result, 'selected_replica_online_count_at_admission': admissions, 'largest_tail_contexts': sorted((r for r in request_context if r['client_tail']), key=lambda r: (-r['client_mean_gap_ms'], r['request_id']))[:8]}, request_context)
