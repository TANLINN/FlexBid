"""Observe SSE boundaries while forwarding the original response bytes."""
from __future__ import annotations

import ast
import json
from pathlib import Path
import sys
import time


def decode_observed_chunks(chunks):
    pending, events, errors = b"", [], []

    def line_event(line, chunk):
        line = line.rstrip(b"\r")
        if not line.startswith(b"data: ") or line[6:] == b"[DONE]":
            return
        try:
            value = json.loads(line[6:])
            choices = value.get("choices") or []
            text = choices[0].get("text") if choices else None
            if text:
                events.append({"sequence": len(events) + 1, "response_id": value.get("id"),
                               "text_chars": len(text), "upstream_read_ns": chunk["read_ns"],
                               "forward_ns": chunk["forward_ns"]})
        except (ValueError, TypeError, AttributeError) as exc:
            errors.append(type(exc).__name__ + ": " + str(exc))

    for chunk in chunks:
        pending += chunk["data"]
        while b"\n" in pending:
            line, pending = pending.split(b"\n", 1)
            line_event(line, chunk)
    if pending and chunks:
        line_event(pending, chunks[-1])
    return events, errors


class StreamObservation:
    def __init__(self, request_id, replica, request_class, admitted_ns, counts, output_path=None):
        self.request_id, self.replica, self.request_class = request_id, replica, request_class
        self.admitted_ns, self.counts = admitted_ns, counts
        self.output_path = Path(output_path) if output_path else Path(__file__).with_name("stream_gateway.jsonl")
        self.chunks = []

    def receive(self, chunk):
        self.chunks.append({"read_ns": time.monotonic_ns(), "forward_ns": None, "data": chunk})

    def forwarding(self):
        self.chunks[-1]["forward_ns"] = time.monotonic_ns()

    def finish(self):
        if not self.request_id:
            return
        began = time.monotonic_ns()
        try:
            events, errors = decode_observed_chunks(self.chunks)
            record = {"request_id": self.request_id, "replica": self.replica, "class": self.request_class,
                      "admitted_mono_ns": self.admitted_ns, "inflight_after_selection": self.counts,
                      "chunks": len(self.chunks), "events": events, "parse_errors": errors,
                      "post_stream_parse_ms": (time.monotonic_ns() - began) / 1e6}
            with self.output_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(record) + "\n")
        except Exception as exc:
            print("STREAM_OBSERVATION_ERROR " + str(self.request_id) + " " + repr(exc), file=sys.stderr, flush=True)
        finally:
            self.chunks.clear()


def instrument_gateway(path):
    path = Path(path)
    tree = ast.parse(path.read_text(encoding="utf-8"))
    matches = [n for n in tree.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "proxy"]
    if len(matches) != 1:
        raise ValueError("expected the saved gateway proxy function")
    proxy = matches[0]
    choices = [i for i, n in enumerate(proxy.body) if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == "index" for t in n.targets)
               and isinstance(n.value, ast.Await) and isinstance(n.value.value, ast.Call)
               and isinstance(n.value.value.func, ast.Attribute) and n.value.value.func.attr == "choose"]
    if len(choices) != 1:
        raise ValueError("expected one original replica selection")
    proxy.body[choices[0] + 1:choices[0] + 1] = ast.parse(
        'stream_admitted_ns = time.monotonic_ns()\n'
        'stream_selected_counts = {"online": list(state.inflight_online), "batch": list(state.inflight_batch)}').body
    streams = [n for n in proxy.body if isinstance(n, ast.AsyncFunctionDef) and n.name == "stream"]
    if len(streams) != 1:
        raise ValueError("expected one saved response stream")
    stream = streams[0]
    stream.body.insert(0, ast.parse(
        'observation = StreamObservation(request.headers.get("x-flexbid-trace-id"), index, request_class, '
        'stream_admitted_ns, stream_selected_counts)').body[0])
    loops = [n for n in ast.walk(stream) if isinstance(n, ast.AsyncFor)
             and isinstance(n.target, ast.Name) and n.target.id == "chunk"
             and isinstance(n.iter, ast.Call) and isinstance(n.iter.func, ast.Attribute)
             and n.iter.func.attr == "aiter_bytes"]
    if len(loops) != 1:
        raise ValueError("expected the unchanged upstream byte iterator")
    loop = loops[0]
    yields = [i for i, n in enumerate(loop.body) if isinstance(n, ast.Expr)
              and isinstance(n.value, ast.Yield) and isinstance(n.value.value, ast.Name)
              and n.value.value.id == "chunk"]
    if len(yields) != 1:
        raise ValueError("expected byte-preserving forwarding")
    loop.body.insert(yields[0], ast.parse('observation.forwarding()').body[0])
    loop.body.insert(0, ast.parse('observation.receive(chunk)').body[0])
    releases = [n for n in ast.walk(stream) if isinstance(n, ast.Try) and any(
        isinstance(s, ast.Expr) and isinstance(s.value, ast.Await)
        and isinstance(s.value.value, ast.Call) and isinstance(s.value.value.func, ast.Attribute)
        and s.value.value.func.attr == "release" for s in n.finalbody)]
    if len(releases) != 1:
        raise ValueError("expected the original stream cleanup and admission release")
    releases[0].finalbody.append(ast.parse('observation.finish()').body[0])
    insert = next((i for i, n in enumerate(tree.body) if isinstance(n, (ast.Import, ast.ImportFrom))
                   and not (isinstance(n, ast.ImportFrom) and n.module == "__future__")), 0)
    tree.body.insert(insert, ast.parse('from stream_trace_tools import StreamObservation').body[0])
    ast.fix_missing_locations(tree)
    result = ast.unparse(tree) + "\n"
    compile(result, str(path), "exec")
    path.write_text(result, encoding="utf-8")


def quantile(values, q):
    values = sorted(values)
    if not values:
        return None
    p = (len(values) - 1) * q
    i = int(p)
    return values[i] + (p - i) * (values[min(i + 1, len(values) - 1)] - values[i])


def describe_values(values):
    return {"samples": len(values), "min": min(values) if values else None,
            "p50": quantile(values, .5), "p95": quantile(values, .95), "p99": quantile(values, .99),
            "max": max(values) if values else None}


def analyze_streams(online, gateways, threshold):
    by_id = {}
    duplicates = []
    for item in gateways:
        key = item["request_id"]
        if key in by_id:
            duplicates.append(key)
        by_id[key] = item
    expected = {r["request_id"] for r in online}
    problems, paired, forwards, delivery, parse_delays = [], [], [], [], []
    for row in online:
        key = row["request_id"]
        upstream = by_id.get(key)
        if upstream is None:
            problems.append({"request_id": key, "reason": "gateway observation missing"})
            continue
        before, after = upstream["events"], row.get("stream_observations", [])
        valid = not upstream["parse_errors"] and len(before) == len(after) == int(row.get("nonempty_sse_text_events") or 0)
        valid = valid and all(a["sequence"] == b["sequence"] and a["response_id"] == b["response_id"]
                              and a["text_chars"] == b["text_chars"] and a["forward_ns"] is not None
                              for a, b in zip(before, after))
        if not valid:
            problems.append({"request_id": key, "reason": "stream count, event shape, or parser mismatch"})
            continue
        if not 150_000 <= float(row["arrival_ms"]) < 1950_000 or row.get("error") is not None:
            continue
        for a, b in zip(before, after):
            forwards.append((a["forward_ns"] - a["upstream_read_ns"]) / 1e6)
            delivery.append((b["line_read_ns"] - a["forward_ns"]) / 1e6)
            parse_delays.append((b["parsed_ns"] - b["line_read_ns"]) / 1e6)
        if len(before) < 2:
            continue
        upstream_gaps = [(b["upstream_read_ns"] - a["upstream_read_ns"]) / 1e6 for a, b in zip(before, before[1:])]
        forward_gaps = [(b["forward_ns"] - a["forward_ns"]) / 1e6 for a, b in zip(before, before[1:])]
        paired.append({"request_id": key, "replica": upstream["replica"], "prompt_tokens": row["prompt_tokens"],
                       "output_tokens": row["max_output_tokens"], "events": len(before),
                       "client_mean_gap_ms": row["mean_tpot_ms"],
                       "upstream_read_mean_gap_ms": sum(upstream_gaps) / len(upstream_gaps),
                       "forward_mean_gap_ms": sum(forward_gaps) / len(forward_gaps),
                       "upstream_read_max_gap_ms": max(upstream_gaps),
                       "inflight_after_selection": upstream["inflight_after_selection"],
                       "upstream_first8_gaps_ms": upstream_gaps[:8],
                       "client_first8_gaps_ms": [(b["parsed_ns"] - a["parsed_ns"]) / 1e6 for a, b in zip(after, after[1:])][:8]})
    tails = [r for r in paired if r["client_mean_gap_ms"] > threshold]
    replicas = {}
    for index in sorted({r["replica"] for r in paired}):
        selected = [r for r in paired if r["replica"] == index]
        replicas[str(index)] = {"gap_samples": len(selected),
            "client_tail_requests": sum(r["client_mean_gap_ms"] > threshold for r in selected),
            "upstream_read_tail_requests": sum(r["upstream_read_mean_gap_ms"] > threshold for r in selected)}
    return {
        "gateway_records": len(gateways), "expected_online_requests": len(online),
        "duplicate_gateway_ids": duplicates, "unexpected_gateway_ids": sorted(set(by_id) - expected),
        "alignment_problems": problems, "paired_gap_samples": len(paired),
        "client_tail_requests": len(tails),
        "client_tails_already_above_threshold_at_upstream_read": sum(r["upstream_read_mean_gap_ms"] > threshold for r in tails),
        "client_tails_without_upstream_read_mean_exceedance": sum(r["upstream_read_mean_gap_ms"] <= threshold for r in tails),
        "upstream_read_to_forward_ms": describe_values(forwards),
        "forward_to_client_line_read_ms": describe_values(delivery),
        "client_line_read_to_parsed_ms": describe_values(parse_delays),
        "negative_forward_to_client_time_events": sum(v < 0 for v in delivery),
        "post_stream_parse_ms": describe_values([r["post_stream_parse_ms"] for r in gateways]),
        "by_actual_replica": replicas,
        "largest_client_tails": sorted(tails, key=lambda r: (-r["client_mean_gap_ms"], r["request_id"]))[:8],
        "scope": "Upstream read means bytes becoming available to the gateway application; it does not isolate engine generation, API sending, transport, or gateway event-loop scheduling.",
    }
