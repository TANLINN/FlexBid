"""Report mixed-cohort service, admission behavior and the fixed deadline."""
import filecmp
import json
from pathlib import Path
import re

import cohort_phase_measurement as measure
from online_capacity12_tools import routing_summary
from mamba_prefix_tools import engine_observation

DISPLAY_PHASES = ('warmup', 'event_time_reference', 'recovery', 'recovery_early',
                  'recovery_middle', 'recovery_late', 'evaluation', 'warmup_first30', 'warmup_after30')
PROGRAMS = ('priority_gateway.py', 'first_text_admission_tools.py', 'replica_batch_limit_tools.py',
            'stream_trace_tools.py', 'stream_context_tools.py', 'online_queue_priority_tools.py')


def analyze_cell(output, config, policy_run, event_cap):
    enabled = True
    engine = engine_observation(output, 512)
    import yaml
    from first_text_admission_tools import observed_first_text_overlap
    from replica_batch_limit_tools import occupancy_summary
    from online_queue_priority_tools import policy_summary
    from stream_trace_tools import analyze_streams
    from stream_context_tools import analyze as analyze_context
    from analyze_c6_ttft_decomposition import request_timing, phase_summary

    protocol = measure.read_json(output / 'protocol.json')
    input_root = Path(protocol['input_root'])
    info = measure.read_json(input_root / 'INPUT_SUMMARY.json')
    online = measure.read_rows(output / 'online.jsonl')
    planned, jobs = measure.saved_workload(input_root)
    batches = measure.read_rows(output / 'batch.jsonl')
    gateways = measure.read_rows(output / 'stream_gateway.jsonl')
    states = measure.read_rows(output / 'gateway_state.jsonl')
    actions = measure.read_rows(output / 'power_actions.jsonl')
    expected = {r['request_id']: r for r in planned}
    actual = {r['request_id']: r for r in online}
    ids_match = len(actual) == len(online) and set(actual) == set(expected)
    metadata = ('arrival_ms', 'prompt_tokens', 'max_output_tokens', 'parent_request_id', 'tool_delay_ms')
    metadata_match = ids_match and all(row.get(k) == expected[key].get(k)
                                      for key, row in actual.items() for k in metadata)
    ttft_slo = float(config['slos']['default']['ttft_ms'])
    gap_slo = float(config['slos']['default']['tpot_ms'])
    phases = {}
    for name, (left, right) in measure.PHASES.items():
        selected = measure.select_phase(online, left, right)
        phases[name] = measure.latency_summary(selected, ttft_slo, gap_slo)
        phases[name]['requests_with_ttft_over_slo'] = sum(
            r.get('ttft_ms') is not None and float(r['ttft_ms']) > ttft_slo for r in selected)
    batch = measure.cohort_summary(jobs, batches, protocol)
    concurrency = measure.client_batch_phase_counts(batches, protocol)
    attempts = [r for r in batches if r.get('dispatch_wall_time_ns') is not None]
    on_gates = [r for r in gateways if r['class'] == 'online']
    ba_gates = [r for r in gateways if r['class'] == 'batch']
    streams = analyze_streams(online, on_gates, gap_slo)
    streams_ok = (not streams['alignment_problems'] and not streams['duplicate_gateway_ids']
                  and not streams['unexpected_gateway_ids']
                  and streams['paired_gap_samples'] == phases['evaluation']['request_mean_stream_gap_samples'])
    contexts = {'status': 'unavailable: stream alignment is incomplete'}
    if streams_ok:
        contexts, _ = analyze_context(online, gateways, gap_slo)
    control = measure.read_json(output / 'control.json')
    routing = routing_summary(gateways, control['online_replica_ids'], control['batch_replica_ids'])
    isolation = observed_first_text_overlap(gateways)
    occupancy = occupancy_summary(gateways, states)
    policy = policy_summary(gateways, actions, protocol)
    expected_flags = [False, False, enabled]
    policy['expected_phase_flags'] = expected_flags
    policy['expected_phase_flags_observed'] = policy['control_phase_flags'] == expected_flags
    caps = measure.cap_observations(output, config['hardware']['gpu_indices'], event_cap)
    batch_limits = [r['control']['batch_concurrency'] for r in actions]
    budgets, lengths = {}, {}
    for path in sorted((output / 'service_logs').glob('vllm_replica_*.log')):
        text = path.read_text(encoding='utf-8', errors='replace')
        budgets[path.name] = sorted({int(v) for v in re.findall(
            r'Chunked prefill is enabled with max_num_batched_tokens=(\d+)', text)})
        lengths[path.name] = sorted({int(v.replace(',', '')) for v in re.findall(
            r'Using max model len ([\d,]+)', text)})
    incomplete = sum(r.get('error') is not None or r.get('status_code') != 200
                     or int(r.get('completion_tokens') or 0) != int(r['max_output_tokens']) for r in online)
    policy_config = yaml.safe_load((policy_run / 'config.yaml').read_text(encoding='utf-8'))
    same_programs = {name: filecmp.cmp(output / name, policy_run / name, shallow=False) for name in PROGRAMS[1:]}
    expected_gateway = (policy_run / 'priority_gateway.py').read_text(encoding='utf-8')
    maximum_online = max((sum(r['inflight_after_selection']['online']) for r in gateways), default=None)
    maximum_per_replica = max((max(r['inflight_after_selection']['online']) for r in gateways), default=None)
    occupied_admissions = occupancy['maximum_batch_per_replica_at_admissions']
    occupied_snapshots = occupancy['maximum_batch_per_replica_at_snapshots']
    checks = {
        'workload_process_succeeded': measure.read_json(output / 'workload_complete.json')['status'] == 'complete',
        'same_saved_online_input': filecmp.cmp(output / 'online_workload.jsonl', input_root / 'online_workload.jsonl', shallow=False),
        'same_saved_batch_input': filecmp.cmp(output / 'batch_jobs.jsonl', input_root / 'batch_jobs.jsonl', shallow=False),
        'all_online_request_ids_and_metadata_matched': metadata_match,
        'all_online_outputs_complete_without_errors': incomplete == 0 and ids_match,
        'evaluation_online_slo_safe': phases['evaluation']['observed_slo_safe'],
        'event_reference_online_slo_safe': phases['event_time_reference']['observed_slo_safe'],
        'recovery_reference_online_slo_safe': phases['recovery']['observed_slo_safe'],
        'all_jobs_completed_by_deadline': batch['all_jobs_completed_by_deadline'],
        'batch_client_concurrency_within_phase_limits': concurrency['event']['maximum_client_batch_inflight'] <= 6
                                                        and concurrency['recovery']['maximum_client_batch_inflight'] <= 6,
        'power_cap_sequence_observed': caps['requested_sequence_observed'],
        'configured_gpu_caps_matched': caps['all_configured_gpu_caps_matched_at_transitions'],
        'service_configuration_matches_measured_policy': measure.normalized_configuration(config) == measure.normalized_configuration(policy_config),
        'saved_helpers_identical': all(same_programs.values()),
        'gateway_matches_online_count_ranking': (output / 'priority_gateway.py').read_text(encoding='utf-8') == expected_gateway,
        'context_length_observed': len(lengths) == 4 and all(v == [int(config['model']['max_model_len'])] for v in lengths.values()),
        'all_inputs_fit_context': measure.read_json(output / 'INPUT_CONTEXT.json')['all_requests_fit'],
        'chunk512_observed_in_all_replica_logs': len(budgets) == len(config['model']['replicas']) and all(v == [512] for v in budgets.values()),
        'twelve_online_slots_observed_at_admissions': maximum_online is not None and maximum_online <= 12
            and config['runtime']['online_concurrency'] == 12 and all(r['control']['online_concurrency'] == 12 for r in actions),
        'three_online_per_replica_observed_at_admissions': maximum_per_replica is not None and maximum_per_replica <= 3,
        'online_stream_alignment_complete': streams_ok,
        'cross_process_clock_order_observed': streams['negative_forward_to_client_time_events'] == 0,
        'batch_gateway_ids_match_attempted_jobs': len(ba_gates) == len(attempts) and {r['request_id'] for r in ba_gates} == {r['job_id'] for r in attempts},
        'online_placement_matches_first_text_eligibility': routing['online_records'] == len(online) and routing['online_rule_matches'] == len(online),
        'batch_placement_matches_online_free_eligibility': routing['batch_records'] == len(attempts) and routing['batch_rule_matches'] == len(attempts),
        'no_online_admission_during_batch_pending_first': routing['online_admissions_while_batch_pending_first'] == 0,
        'no_batch_admission_during_online_service': routing['batch_admissions_while_online_present'] == 0,
        'observed_first_text_intervals_disjoint': isolation['overlap_pairs'] == 0 and isolation['online_intervals'] == len(online) and isolation['batch_first_text_intervals'] == len(attempts),
        'batch_per_replica_at_most_two_observed': occupied_admissions is not None and occupied_admissions <= 2 and occupied_snapshots is not None and occupied_snapshots <= 2,
        'phase_control_updates_recorded': batch_limits == [1, 6, 6]
            and [r['action']['batch_concurrency'] for r in actions] == [0, 6, 6]
            and [r['control']['batch_paused'] for r in actions] == [True, False, False],
        'expected_priority_phase_flags_observed': policy['expected_phase_flags_observed'] and policy['policy_enabled_before_recovery'] == 0,
        'queue_priority_admission_context_complete': policy['missing_context_count'] == 0,
        'enabled_queue_priority_not_violated': policy['batch_admissions_while_online_queued'] == 0,
    }
    checks['uncached_launch_arguments_observed'] = engine['requested_arguments_observed']
    checks['uncached_engine_arguments_observed'] = engine['reported_arguments_match']
    phase_dispatch = measure.read_json(output / 'workload_complete.json')['batch_phase_dispatch']
    event_receipt = next(row for row in actions if row['phase'] == 'event')
    first_dispatch = min((int(row['dispatch_wall_time_ns']) for row in attempts), default=None)
    # All six workers start at 150 s; recovery control is checked in actions, not a new-worker receipt.
    checks['first_batch_dispatch_after_event_control'] = (first_dispatch is not None
        and first_dispatch >= int(event_receipt['end_wall_ns'])
        and all(phase_dispatch.get(phase, {}).get('ready_before_deadline') is True
                for phase in ('event',)))
    indexed = {r['request_id']: r for r in on_gates}
    timing = [request_timing(row, indexed.get(row['request_id'])) for row in online]
    power = measure.gpu_series(output)
    passed = all(checks.values())
    result = {
        'status': 'CONVERSATION1904_C6_SERVICE_MEASURED', 'condition': 'c6_from_release_p400',
        'service_source_run': str(policy_run),
        'episode_id': info['episode_id'], 'source': info['source'], 'run': str(output), 'input_root': str(input_root),
        'checks': checks, 'failed_checks': [key for key, value in checks.items() if not value],
        'service_and_deadline_pass_observed': passed,
        'middle_service_and_deadline_pass_observed': passed and phases['recovery_middle']['observed_slo_safe'],
        'all_recovery_subphases_and_deadline_pass_observed': passed and all(phases[p]['observed_slo_safe'] for p in ('recovery_early', 'recovery_middle', 'recovery_late')),
        'all_main_phases_and_deadline_pass_observed': passed and all(phases[p]['observed_slo_safe'] for p in ('warmup', 'event_time_reference', 'recovery_early', 'recovery_middle', 'recovery_late')),
        'online_requests': len(online), 'planned_online_requests': len(planned), 'online_incomplete_or_error_count': incomplete,
        'slos': {'ttft_p95_ms': ttft_slo, 'request_mean_stream_gap_p99_ms': gap_slo},
        'phases': phases, 'batch': batch, 'cohort_timing': measure.cohort_timing(output),
        'client_batch_phase_counts': concurrency, 'control_batch_limits': batch_limits,
        'batch_phase_dispatch': phase_dispatch,
        'first_batch_dispatch_offset_s': None if first_dispatch is None else (first_dispatch - int(protocol['start_wall_ns'])) / 1e9,
        'queue_priority_policy': policy, 'admission_counts': admission_counts(output, protocol),
        'first_text_isolation': isolation, 'routing': routing, 'batch_occupancy': occupancy,
        'stream_observation': streams, 'upstream_interval_context': contexts,
        'ttft_decomposition': {p: phase_summary(timing, states, int(protocol['start_wall_ns']), *measure.PHASES[p], ttft_slo)
                               for p in measure.PHASES},
        'engine_configuration': engine, 'observed_engine_token_budgets': budgets, 'observed_engine_context_lengths': lengths,
        'input_context': measure.read_json(output / 'INPUT_CONTEXT.json'),
        'saved_programs_identical': same_programs,
        'power_cap_observations': caps,
        'gpu_power': {'boundary': 'aggregate_gpu_power_w', 'stages': {p: measure.power_window(power, a, b)
                     for p, a, b in (('event', 150, 450), ('recovery', 450, 1950), ('evaluation', 150, 1950))}},
        'online_dispatches_at_or_after_horizon': sum(r.get('dispatch_wall_time_ns') is not None and int(r['dispatch_wall_time_ns']) >= int(protocol['deadline_wall_ns']) for r in online),
        'arrival_time_multiplier': 16.0, 'environment': measure.read_json(output / 'ENVIRONMENT.json'),
        'offered_bid_w': None, 'external_commitment': False,
        'dr_delivery_evaluated': False,
        'limitations': [
            'Conversation 001904: uncached chunk512, twelve online slots, three per replica, C6 from release and P400 throughout.',
            'The saved C5-event/C6-recovery P400 run is the service comparison; both full outcomes and environments are retained.',
            f'The saved {len(planned)} online requests and 280 batch jobs retain arrivals, token arrays and the 1950 s deadline.',
            'All six batch workers wait for the 150 s control receipt. Online queue priority remains disabled before 450 s and enabled afterwards; waiting consumes the original deadline.',
            'Online-count-first gateway, eligibility, capacity and batch ranking are copied unchanged from the saved policy run.',
            'Warmup has no batch traffic and uses P400 in every run; warmup differences cannot be attributed to the later event cap.',
            'Warmup and every recovery subphase are reported separately; aggregate pass does not imply all-phase pass.',
            'Gap p99 is across per-request mean nonempty SSE-text gaps, not individual token gaps. Client queue waiting remains in TTFT.',
            'First-text intervals are gateway observations, not engine prefill execution intervals. Late and unstarted jobs remain failures.',
            'This fixed cap schedule measures operating feasibility; it does not validate adaptive offers, independent generalization or statistical delivery guarantees.'
        ],
    }
    return result


def cell_text(result):
    def number(v):
        return 'NA' if v is None else f'{v:.3f}'
    lines = ['=== MAMBA512_COHORT_RESULT ===', 'STATUS=' + result['status'], 'EPISODE_ID=' + result['episode_id'],
             'CONDITION=' + result['condition'], 'RUN=' + result['run'],
             'ALL_MAIN_PHASES_AND_DEADLINE_PASS=' + str(result['all_main_phases_and_deadline_pass_observed']),
             'SERVICE_AND_DEADLINE_PASS=' + str(result['service_and_deadline_pass_observed']),
             'ALL_RECOVERY_SUBPHASES_AND_DEADLINE_PASS=' + str(result['all_recovery_subphases_and_deadline_pass_observed']),
             'FAILED_CHECKS=' + json.dumps(result['failed_checks']),
             'phase requests gap_samples TTFT_p95_ms mean_gap_p99_ms TTFT_tails gap_tails errors safe']
    for phase in DISPLAY_PHASES:
        r = result['phases'][phase]
        lines.append(' '.join([phase, str(r['requests']), str(r['request_mean_stream_gap_samples']),
            number(r['ttft_p95_ms']), number(r['request_mean_stream_gap_p99_ms']), str(r['requests_with_ttft_over_slo']),
            str(r['requests_with_mean_stream_gap_over_slo']), str(r['errors']), str(r['observed_slo_safe'])]))
    for key in ('online_requests', 'online_incomplete_or_error_count', 'batch', 'cohort_timing', 'control_batch_limits', 'batch_phase_dispatch', 'first_batch_dispatch_offset_s',
                'admission_counts', 'queue_priority_policy', 'first_text_isolation', 'input_context', 'checks', 'routing', 'batch_occupancy',
                'observed_engine_token_budgets', 'observed_engine_context_lengths', 'gpu_power', 'online_dispatches_at_or_after_horizon'):
        lines.append(key.upper() + '=' + json.dumps(result[key], ensure_ascii=False))
    for phase in ('warmup', 'event_time_reference', 'recovery_early', 'recovery_middle', 'recovery_late'):
        row = result['ttft_decomposition'][phase]
        lines.append('QUEUE_CONTEXT=' + json.dumps({'phase': phase, 'ttft_tail_requests': row['ttft_tail_requests'],
                                                   'gateway_snapshots': row['gateway_snapshots']}))
    lines += result['limitations']
    return '\n'.join(lines) + '\n'



def admission_counts(folder, protocol):
    start = int(protocol['start_wall_ns'])
    counts = {phase: {'batch_admissions': 0, 'while_online_queued': 0, 'policy_enabled': 0, 'previously_deferred_for_online': 0} for phase in ('event', 'recovery', 'outside')}
    missing = 0
    with (folder / 'stream_gateway.jsonl').open(encoding='utf-8') as stream:
        for line in stream:
            if not line.strip():
                continue
            row = json.loads(line)
            if row['class'] != 'batch':
                continue
            context = row['inflight_after_selection'].get('online_queue_priority')
            if context is None:
                missing += 1
                continue
            elapsed = (int(context['selection_wall_time_ns']) - start) / 1000000000.0
            phase = 'event' if 150 <= elapsed < 450 else 'recovery' if 450 <= elapsed < 1950 else 'outside'
            item = counts[phase]
            item['batch_admissions'] += 1
            item['while_online_queued'] += int(context['queued_online_at_selection'] > 0)
            item['policy_enabled'] += int(context['enabled'])
            item['previously_deferred_for_online'] += int(context['deferred_for_online'])
    return {'by_selection_phase': counts, 'missing_batch_contexts': missing}
