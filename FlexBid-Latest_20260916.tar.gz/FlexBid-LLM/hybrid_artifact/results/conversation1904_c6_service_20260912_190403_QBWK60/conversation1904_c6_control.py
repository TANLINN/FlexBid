"""Keep queue-priority timing independent of the batch concurrency setting."""
import cohort_phase_measurement as m


def control_value(action, replicas, online_concurrency, phase):
    return {'action': action.as_dict(),
            'online_replica_ids': list(action.resolved_online_replica_ids()),
            'batch_replica_ids': list(range(replicas)),
            'batch_paused': action.batch_concurrency == 0,
            'online_concurrency': online_concurrency,
            'batch_concurrency': max(1, action.batch_concurrency),
            'defer_batch_for_online_queue': phase == 'recovery'}


def apply_control(path, action, replicas, online_concurrency, phase):
    from flexbid_hybrid.io import atomic_json
    value = control_value(action, replicas, online_concurrency, phase)
    atomic_json(path, value)
    return value


class ServiceSchedule(m.CapSchedule):
    def tick(self):
        elapsed = self.monotonic() - self.start_mono
        if elapsed < m.WARMUP_S:
            phase, desired, boundary = 'warmup', self.baseline, 0.
        elif elapsed < m.RECOVERY_S:
            phase, desired, boundary = 'event', self.event, m.WARMUP_S
        else:
            phase, desired, boundary = 'recovery', self.recovery, m.RECOVERY_S
        if phase != self.phase:
            began = self.wall_ns()
            receipt = self.enact(desired, phase)
            self.emit({'phase': phase, 'planned_boundary_s': boundary,
                       'begin_offset_s': elapsed, 'end_offset_s': self.monotonic() - self.start_mono,
                       'begin_wall_ns': began, 'end_wall_ns': self.wall_ns(),
                       'action': desired.as_dict(), **receipt})
            self.phase, self.action = phase, desired
        return self.action
