"""Order batch dispatch after the controller's existing phase receipt."""
import asyncio
import json
from pathlib import Path
import time


class BatchPhaseDispatch:
    def __init__(self, output, protocol):
        self.path = Path(output) / 'power_actions.jsonl'
        self.protocol = protocol
        self.start_ns = int(protocol['start_wall_ns'])
        self.deadline = time.perf_counter() + (
            int(protocol['deadline_wall_ns']) - time.time_ns()) / 1e9
        self.tasks = {}
        self.observations = {}

    async def wait_for_phase(self, worker_index):
        phase = ('event' if worker_index < int(self.protocol['event_batch_concurrency'])
                 else 'recovery')
        if phase not in self.tasks:
            self.tasks[phase] = asyncio.create_task(self._wait(phase))
        return await self.tasks[phase]

    async def _wait(self, phase):
        expected = int(self.protocol[phase + '_batch_concurrency'])
        boundary = float(self.protocol['batch_admission_offset_s'] if phase == 'event'
                         else self.protocol['recovery_start_offset_s'])
        while time.perf_counter() < self.deadline:
            try:
                text = self.path.read_text(encoding='utf-8')
            except FileNotFoundError:
                text = ''
            # A receipt is usable only after its complete JSON line is visible.
            for line in text.splitlines(keepends=True):
                if not line.endswith('\n') or not line.strip():
                    continue
                row = json.loads(line)
                if row.get('phase') != phase:
                    continue
                control = row['control']
                if control['batch_paused'] or int(control['batch_concurrency']) != expected:
                    raise ValueError('Unexpected batch control in ' + phase + ' receipt')
                seen_ns = time.time_ns()
                on_time = time.perf_counter() < self.deadline
                self.observations[phase] = {
                    'phase': phase, 'ready_before_deadline': on_time,
                    'control_end_wall_ns': int(row['end_wall_ns']),
                    'observed_wall_ns': seen_ns,
                    'control_end_offset_s': (int(row['end_wall_ns']) - self.start_ns) / 1e9,
                    'observed_offset_s': (seen_ns - self.start_ns) / 1e9,
                    'planned_boundary_s': boundary,
                    'batch_concurrency': expected,
                }
                return on_time
            await asyncio.sleep(min(.01, max(0, self.deadline - time.perf_counter())))
        self.observations[phase] = {'phase': phase, 'ready_before_deadline': False,
                                    'reason': 'No complete phase receipt before original deadline'}
        return False
