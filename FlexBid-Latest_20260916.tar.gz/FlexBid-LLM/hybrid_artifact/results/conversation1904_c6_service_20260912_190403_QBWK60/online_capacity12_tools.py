"""Twelve-slot online admission with the saved placement and isolation rules."""
import ast


def gateway_source(source):
    tree = ast.parse(source, feature_version=(3, 10))
    state = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'State')
    choose = next(n for n in state.body if isinstance(n, ast.AsyncFunctionDef) and n.name == 'choose')
    candidates = []
    for node in ast.walk(choose):
        if not isinstance(node, ast.IfExp) or ast.unparse(node.test) != "request_class == 'online'":
            continue
        body = node.body
        if (isinstance(body, ast.Compare) and len(body.ops) == 1 and isinstance(body.ops[0], ast.Lt)
                and isinstance(body.left, ast.Subscript) and ast.unparse(body.left.value) == 'self.inflight_online'
                and len(body.comparators) == 1 and isinstance(body.comparators[0], ast.Constant)
                and body.comparators[0].value == 2
                and ast.unparse(node.orelse) == ast.unparse(body.left) + ' == 0'):
            candidates.append(body.comparators[0])
    if len(candidates) != 1:
        raise ValueError('Expected one online-per-replica capacity of two in State.choose')
    candidates[0].value = 3
    result = ast.unparse(tree) + '\n'
    ast.parse(result, feature_version=(3, 10))
    return result


def routing_summary(records, online_replicas, batch_replicas):
    result = {'online_records': 0, 'batch_records': 0, 'online_rule_matches': 0, 'batch_rule_matches': 0,
              'online_mismatches_first8': [], 'batch_mismatches_first8': [],
              'maximum_online_per_replica_after_selection': 0,
              'online_admissions_while_batch_pending_first': 0, 'batch_admissions_while_online_present': 0}
    for row in records:
        kind, chosen = row['class'], int(row['replica'])
        counts = row['inflight_after_selection']
        online, batch, pending = (list(map(int, counts[key])) for key in ('online', 'batch', 'batch_pending_first'))
        result['maximum_online_per_replica_after_selection'] = max(result['maximum_online_per_replica_after_selection'], max(online))
        if kind == 'online':
            result['online_admissions_while_batch_pending_first'] += int(pending[chosen] > 0)
            online[chosen] -= 1
            ready = [i for i in online_replicas if online[i] < 3 and pending[i] == 0]
        else:
            result['batch_admissions_while_online_present'] += int(online[chosen] > 0)
            batch[chosen] -= 1
            pending[chosen] -= 1
            ready = [i for i in batch_replicas if online[i] == 0 and batch[i] < 2]
            context = counts.get('online_queue_priority')
            if context is not None and context['enabled'] and context['queued_online_at_selection'] > 0:
                ready = []
        if min(online + batch + pending) < 0:
            raise ValueError('Invalid recorded admission counts: ' + row['request_id'])
        key = (lambda i: (online[i], online[i] + batch[i], batch[i], i)) if kind == 'online' else (lambda i: (online[i] + batch[i], batch[i], i))
        expected = min(ready, key=key) if ready else None
        result[kind + '_records'] += 1
        result[kind + '_rule_matches'] += int(chosen == expected)
        if chosen != expected and len(result[kind + '_mismatches_first8']) < 8:
            result[kind + '_mismatches_first8'].append({'request_id': row['request_id'], 'actual': chosen, 'expected': expected})
    return result
