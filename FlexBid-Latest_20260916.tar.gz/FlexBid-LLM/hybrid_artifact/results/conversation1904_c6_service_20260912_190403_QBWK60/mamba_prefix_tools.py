"""Configure the saved service launcher for uncached Mamba chunk comparisons."""
import ast
import inspect
import json
import textwrap


def uncached_start_source(source):
    tree = ast.parse(textwrap.dedent(source), feature_version=(3, 10))
    lists = [node for node in ast.walk(tree) if isinstance(node, ast.List)
             and any(isinstance(item, ast.Constant) and item.value == '--enable-prefix-caching' for item in node.elts)]
    if len(lists) != 1:
        raise ValueError('Saved service start must contain one explicit prefix-cache launch argument')
    command = lists[0]
    index = next(i for i, item in enumerate(command.elts)
                 if isinstance(item, ast.Constant) and item.value == '--enable-prefix-caching')
    command.elts[index:index+1] = [ast.Constant(value) for value in
                                  ('--no-enable-prefix-caching', '--mamba-cache-mode', 'none')]
    return ast.unparse(ast.fix_missing_locations(tree)) + '\n'


def uncached_service_class(base, output):
    source = uncached_start_source(inspect.getsource(base.start))
    (output / 'service_start.py.txt').write_text(source, encoding='utf-8')
    namespace = dict(base.start.__globals__)
    exec(compile(source, str(output / 'service_start.py.txt'), 'exec'), namespace)
    start = namespace['start']

    class UncachedServiceGroup(base):
        def start(self):
            start(self)
            commands = [list(p.args) for p in self.processes]
            (output / 'SERVICE_COMMANDS.json').write_text(
                json.dumps(commands, indent=2) + '\n', encoding='utf-8')

    return UncachedServiceGroup


def engine_observation(output, budget):
    logs = {}
    for path in sorted((output / 'service_logs').glob('vllm_replica_*.log')):
        text = path.read_text(encoding='utf-8', errors='replace')
        args = []
        for line in text.splitlines():
            if 'non-default args:' in line:
                args.append(ast.literal_eval(line.split('non-default args:', 1)[1].strip()))
        logs[path.name] = {
            'reported_arguments': args,
            'prefix_disabled_and_budget_observed': bool(args) and all(
                row.get('enable_prefix_caching') is False and row.get('max_num_batched_tokens') == budget
                for row in args),
            'align_mode_enabled_message': "Mamba cache mode is set to 'align'" in text,
        }
    commands = json.loads((output / 'SERVICE_COMMANDS.json').read_text(encoding='utf-8'))
    engines = [command for command in commands if 'serve' in command]
    def has_value(command, key, value):
        return key in command and command.index(key)+1 < len(command) and command[command.index(key)+1] == str(value)
    command_match = len(engines) == 4 and all(
        '--enable-prefix-caching' not in command and '--no-enable-prefix-caching' in command
        and has_value(command, '--mamba-cache-mode', 'none')
        and has_value(command, '--max-num-batched-tokens', budget) for command in engines)
    return {'logs': logs, 'engine_commands': engines, 'requested_arguments_observed': command_match,
            'reported_arguments_match': len(logs) == 4 and all(
                row['prefix_disabled_and_budget_observed'] and not row['align_mode_enabled_message']
                for row in logs.values()),
            'scope': 'Launch arguments and engine-reported configuration; actual per-step scheduled tokens are not measured.'}
