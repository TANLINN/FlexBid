"""Compare C6-from-release with saved C5-event/C6-recovery service at P400."""
import filecmp
import json

import cohort_phase_measurement as m
from conversation1904_c6_measurement import analyze_cell as measured_cell, cell_text as measured_text, PROGRAMS


def compare(output, config, source, current):
    import yaml
    previous = m.read_json(source / 'REPORT.json')
    protocols = [m.read_json(p / 'protocol.json') for p in (output, source)]
    source_config = yaml.safe_load((source / 'config.yaml').read_text(encoding='utf-8'))
    same_timing = ('duration_s', 'drain_s', 'cohort_release_offset_s', 'batch_admission_offset_s',
                   'recovery_batch_concurrency', 'recovery_start_offset_s')
    helpers = PROGRAMS + ('cohort_phase_measurement.py', 'cohort_phase_dispatch.py', 'mamba_prefix_tools.py')
    checks = {
        'same_episode': current['episode_id'] == previous['episode_id'] == 'azure_conversation:azure-001904',
        'same_relative_timeline_and_recovery_concurrency': all(protocols[0][k] == protocols[1][k] for k in same_timing),
        'event_concurrency_six_vs_five': [p['event_batch_concurrency'] for p in protocols] == [6, 5],
        'same_service_configuration': m.normalized_configuration(config) == m.normalized_configuration(source_config),
        'same_gateway_helpers_and_request_execution': all(filecmp.cmp(output / name, source / name, shallow=False) for name in helpers),
        'same_saved_inputs': all(filecmp.cmp(output / name, source / name, shallow=False)
                                 for name in ('online_workload.jsonl', 'batch_jobs.jsonl')),
        'same_p400_caps_observed': all(
            [(r['phase'], float(r['action']['power_cap_w'])) for r in row['power_cap_observations']['transitions']]
            == [('warmup', 400.), ('event', 400.), ('recovery', 400.)]
            and row['checks']['configured_gpu_caps_matched'] for row in (current, previous)),
        'same_queue_priority_phases': all(row['checks']['expected_priority_phase_flags_observed'] for row in (current, previous)),
        'phase_concurrency_observed': all(row['checks']['phase_control_updates_recorded']
            and row['checks']['batch_client_concurrency_within_phase_limits'] for row in (current, previous)),
    }
    fields = ('run', 'online_requests', 'online_incomplete_or_error_count', 'phases', 'checks', 'failed_checks',
              'batch', 'cohort_timing', 'gpu_power', 'client_batch_phase_counts', 'control_batch_limits',
              'service_and_deadline_pass_observed', 'all_main_phases_and_deadline_pass_observed', 'environment')
    last = [row['cohort_timing']['last_completed_job_offset_s'] for row in (current, previous)]
    return {'checks': checks, 'comparison_interpretable': all(checks.values()),
            'conditions': {name: {k: row[k] for k in fields} for name, row in
                           (('c6_from_release_p400', current), ('c5_event_c6_recovery_p400', previous))},
            'last_successful_completion_c6_minus_c5_event_s': last[0] - last[1] if all(v is not None for v in last) else None,
            'limitations': [
                'Two physical runs of the reused 001904 workload; concurrency effects are not separated from run-order or execution variation.',
                'The changed interval is 150-450 s. Recovery retains C6, P400 and online queue priority; its entering state can differ.',
                'Both original service outcomes and all 280 batch outcomes are retained. Completion timing alone is not a joint pass.',
                'Energy over 150-1950 s can cover different completed work when jobs are late or missing; it is not automatically equal-work energy.',
                'This service condition does not measure curtailment or an adaptive offer and cannot establish a physical infeasibility bound.']}


def analyze_cell(output, config, policy_run, event_cap):
    result = measured_cell(output, config, policy_run, event_cap)
    m.write_json(output / 'CELL_REPORT.json', result)
    try:
        pair = compare(output, config, policy_run, result)
        m.write_json(output / 'SERVICE_COMPARISON.json', pair)
        result['service_comparison'] = pair
    except Exception as exc:
        error = {'error_type': type(exc).__name__, 'error': str(exc), 'raw_measurement_completed': True}
        m.write_json(output / 'COMPARISON_FAILED.json', error)
        result['comparison_error'] = error
    return result


def cell_text(result):
    text = measured_text(result).replace('=== MAMBA512_COHORT_RESULT ===', '=== CONVERSATION1904_C6_SERVICE_RESULT ===')
    if 'comparison_error' in result:
        return text + 'COMPARISON_ERROR=' + json.dumps(result['comparison_error']) + '\n'
    pair = result['service_comparison']
    lines = ['=== CONVERSATION1904_C6_SERVICE_COMPARISON ===', 'COMPARISON_CHECKS=' + json.dumps(pair['checks']),
             'COMPARISON_INTERPRETABLE=' + str(pair['comparison_interpretable'])]
    for name, row in pair['conditions'].items():
        lines.append('CONDITION_RESULT=' + json.dumps({'condition': name, **row}, ensure_ascii=False))
    lines.append('LAST_SUCCESSFUL_COMPLETION_C6_MINUS_C5_EVENT_S=' + json.dumps(pair['last_successful_completion_c6_minus_c5_event_s']))
    return text + '\n'.join(lines + pair['limitations']) + '\n'
