# Event contract decision record — 2026-08-30

## What “one commitment” means

One event has an immutable accepted power floor B, activation t_a, release t_r,
and a batch deadline T_D. It is not one request, one optimizer invocation, or a
claim that every event must offer 800/1100 W. The optimizer jointly chooses the
offer and event/recovery controls; a later event can receive a different offer
or abstention. A changed host/GPU/model needs target-domain evidence, not a
copied watt value or a relabelled old surrogate.

Default historical experiment: warmup 120 s; event 300 s; control 30 s;
settlement 30 s; deadline 1800 s FROM ACTIVATION (1500 s after release).
New protocol adds a separate configurable 30-s offer-preparation lead.
These are prototype parameters, not universal electricity-market standards.
An 800-W offer over 300 s requires every one of ten 30-s windows to average at
least 800 W below the frozen same-boundary reference. Total 66.67 Wh alone is
not enough: surplus in another window does not cancel a failed window.

EMS/product inputs: notice, activation, release, settlement, reference, recovery
power limits. Job-owner input: actual deadlines and the frozen normal schedule.
Controller settings: solver budget, telemetry rate, control period. Do not equate
control period, market settlement interval, or event duration.

## Findings retained, not erased

The old runtime began its event clock before its first offer solve. The old
loop-local energy accumulator could skip the final window when a control tick
crossed event release. These are implementation defects, not evidence that a
smaller fixed bid would solve the research problem. Existing failed/abstained
experiments remain in their original directories and retain their original
protocol. The matched-baseline run with 39 stale + 60 current controller rows
must be segmented by its current run timestamps, not silently concatenated.

The source-aware support and timeout-supervision patches do not establish
cross-environment reliability. Target GPU-only modelling/calibration and matched
load/transition measurements remain prerequisites for new positive-bid trials.
Past GPU+CPU/DRAM power cannot be relabelled as GPU-only power.

## Implemented protocol v1

- The harness records a fixed activation timestamp before controller startup.
  Warmup and offer lead are separate from event/deadline. A late/infeasible offer
  abstains; it never shifts activation later to hide first-window shortfall.
- Offer preparation includes validation at the quantized proposed bid. The first
  actuation uses the prepared plan; subsequent controls replan. Actuation/drain
  latency is still charged to the first window and logged, not forgiven.
- One monotonic anchor drives time; wall timestamps exist for cross-log alignment.
  Background GPU metering runs independently of blocking solver calls. Fixed
  windows use boundary interpolation and piecewise-constant reference integration.
  The last partial window is checked. Missing brackets, nonfinite samples and
  gaps over the configured maximum are invalid, not zero power or delivery success.
- A final per-run event_protocol_<id>.json is authoritative for electrical
  window completeness; controller tick counts and CELL_COMPLETE alone are not.
- This is LOCAL RESEARCH-HARNESS ACCEPTANCE, not a deployed EMS acknowledgement
  handshake or utility revenue settlement. No hard real-time or physical SLO
  guarantee follows from the timing patch.
- Changed-timing collection requires a fresh output root. The old resume path is
  deliberately blocked pending attempt-isolated resume support; do not overwrite
  already collected reference or dynamic trajectories.

## Next experiment, in order

1. CPU boundary/offer tests and synthetic real-loop smoke.
2. About 2-min READ-ONLY GPU meter/clock smoke (95-s event, 30-s windows, 7-s
   control tick, 5-s final window). Synthetic gateway/optimizer; no vLLM, positive
   bid, GPU stress, cap change, or retention. PASS is clock/meter validation ONLY.
3. Target-domain GPU-only evidence/model check; one real-workload, zero-bid
   timing/drain validation on a new root before any long campaign.
4. Positive-bid transition validation and held-out end-to-end events. Planned
   duration sweep 5/15/30/60 min, notice/settlement/control varied separately.
   Deadlines derive from specified job SLOs, not a universal 6x-event rule.
   Trace coverage must span warmup + notice + deadline; do not stretch an isolated
   request or reuse calibration windows as fresh confirmatory evidence.
5. Repeated-event experiments require debt/queue carryover, not a reset between
   events. This is a planned extension, not a completed capability/result.

## Primary-source grounding (checked 2026-08-30)

- NESO DFS Procurement Rules, May 2026, service requirements/submissions and
  definitions: https://www.neso.energy/document/379391/download
- NESO DFS Service Terms, March 2026, obligations and half-hourly meter data:
  https://www.neso.energy/document/379396/download
  A service window can contain consecutive settlement periods. This is not proof
  that every product/event uses our 5-min event or 30-s internal checking period.
- Google production demand response: external alerts determine site/time and
  hour-by-hour flexible-compute limits; reported European peak example 17:00–21:00.
  https://cloud.google.com/blog/products/infrastructure/using-demand-response-to-reduce-data-center-power-consumption
- PowerSlider, arXiv preprint v1, 2026-08-22 (not a claimed accepted EuroSys paper):
  https://arxiv.org/html/2608.21719v1
  External power-cap tracking and multiple control timescales; settlement cadence
  is not an event duration. FlexBid studies sizing a recoverable offer as well.
- EDEALS, CoolDC 2016: https://www.usenix.org/conference/cooldc16/workshop-program/presentation/mcfadden
  Batch resource shifting and peak-related energy bills, not a universal 5-min DR
  contract. Program-specific timing is part of the problem definition.
