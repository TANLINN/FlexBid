from __future__ import annotations

import csv
import json
import os
import random
import signal
import subprocess
import sys
import time
from pathlib import Path

from .config import canonical_hash, resolve
from .io import atomic_json, read_jsonl
from .power import PowerCapManager
from .service import ServiceGroup, get_json, stop_process
from .types import HybridAction


def select_episodes(root: Path, config: dict) -> list[dict]:
    manifest_path = resolve(root, config["workloads"]["manifest"])
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    selections = config["workloads"].get("episode_selections")
    if selections:
        selected = []
        for selection in selections:
            source = str(selection["source"])
            split = str(selection["split"])
            limit = int(selection["count"])
            offset = int(selection.get("offset", 0))
            values = [
                row for row in manifest["episodes"]
                if row["source"] == source and row["split"] == split
            ]
            values = values[offset:offset + limit]
            if len(values) < limit:
                raise RuntimeError(
                    f"not enough {split} episodes for {source}: "
                    f"requested {limit} at offset {offset}, found {len(values)}"
                )
            for row in values:
                item = dict(row)
                trace = Path(item["path"])
                if not trace.is_absolute():
                    trace = (manifest_path.parent / trace).resolve()
                if not trace.exists():
                    raise FileNotFoundError(f"adapted episode is missing: {trace}")
                item["path"] = str(trace)
                selected.append(item)
        if not selected:
            raise RuntimeError("episode_selections resolved to no episodes")
        return selected
    sources = list(config["workloads"]["sources"])
    limit = int(config["workloads"]["test_episodes_per_source"])
    selected = []
    for source in sources:
        values = [row for row in manifest["episodes"]
                  if row["source"] == source and row["split"] == "test"]
        if len(values) < limit:
            raise RuntimeError(f"not enough test episodes for {source}")
        for row in values[:limit]:
            item = dict(row)
            trace = Path(item["path"])
            if not trace.is_absolute():
                trace = (manifest_path.parent / trace).resolve()
            if not trace.exists():
                raise FileNotFoundError(f"adapted episode is missing: {trace}")
            item["path"] = str(trace)
            selected.append(item)
    return selected


def marker_valid(path: Path) -> bool:
    try:
        value = json.loads((path / "CELL_COMPLETE.json").read_text(encoding="utf-8"))
        # Queue-limit 429s are a legitimate observation: they prove that the
        # tested action is not SLO/capacity safe. Keep the cell and let the
        # oracle analysis reject the action. Connection failures, HTTP 500s,
        # and other infrastructure errors remain fatal.
        fatal_online = value.get("fatal_online_errors")
        if fatal_online is None:
            fatal_online = max(
                0, int(value.get("online_errors", 0))
                - int(value.get("online_load_shed", 0))
            )
        return (value["online_return_code"] == 0 and value["batch_return_code"] == 0
                and fatal_online == 0 and value.get("fatal_batch_errors", 0) == 0
                and value["telemetry_rows"] >= 2)
    except (OSError, KeyError, ValueError):
        return False


def apply_control(path: Path, action: HybridAction, replicas: int,
                  online_concurrency: int) -> dict:
    value = {
        "action": action.as_dict(),
        "online_replica_ids": list(action.resolved_online_replica_ids()),
        "batch_replica_ids": list(range(replicas)),
        "batch_paused": action.batch_concurrency == 0,
        "online_concurrency": online_concurrency,
        "batch_concurrency": max(1, action.batch_concurrency),
    }
    atomic_json(path, value)
    return value


def run_cell(root: Path, config: dict, services: ServiceGroup,
             action: HybridAction, episode: dict, run_dir: Path) -> None:
    if marker_valid(run_dir):
        return
    run_dir.mkdir(parents=True, exist_ok=True)
    services.wait_idle()
    services.reset_caches()
    control = apply_control(
        Path(config["hardware"]["control_file"]), action,
        len(config["model"]["replicas"]), int(config["runtime"]["online_concurrency"]),
    )
    # Force the gateway to observe the new atomically-written action before
    # either workload starts.
    get_json(f"http://127.0.0.1:{config['runtime']['gateway_port']}/flexbid/state")
    duration = float(config["workloads"]["measurement_s"])
    start_wall_ns = time.time_ns() + 3_000_000_000
    end_wall_ns = start_wall_ns + int(duration * 1e9)
    atomic_json(run_dir / "cell.json", {
        "episode": episode, "action": action.as_dict(), "control": control,
        "config_hash": canonical_hash(config),
        "action_hash": canonical_hash(action.as_dict()),
        "measurement_start_wall_ns": start_wall_ns,
        "measurement_end_wall_ns": end_wall_ns,
    })
    telemetry = subprocess.Popen([
        sys.executable, "-m", "flexbid_hybrid.telemetry", "--output",
        str(run_dir / "components.csv"), "--interval-ms",
        str(config["hardware"]["telemetry_interval_ms"]),
    ], cwd=root, start_new_session=True)
    model = config["model"]
    base = f"http://127.0.0.1:{config['runtime']['gateway_port']}/v1"
    online_command = [
        sys.executable, str(root / "scripts/replay_online.py"),
        "--trace", str(episode["path"]), "--output", str(run_dir / "online.jsonl"),
        "--api-base", base, "--model", model["name"], "--tokenizer", model["tokenizer"],
        "--arrival-scale", str(config["workloads"]["arrival_scale_by_source"].get(
            episode["source"], 1.0
        )), "--duration-s", str(duration), "--start-wall-ns", str(start_wall_ns),
        "--source", str(episode["source"]),
    ]
    batch_command = [
        sys.executable, str(root / "scripts/run_batch.py"),
        "--output", str(run_dir / "batch.jsonl"), "--api-base", base,
        "--model", model["name"], "--tokenizer", model["tokenizer"],
        "--prompt-tokens", str(config["workloads"]["batch_prompt_tokens"]),
        "--output-tokens", str(config["workloads"]["batch_output_tokens"]),
        "--concurrency", str(action.batch_concurrency), "--duration-s", str(duration),
        "--start-wall-ns", str(start_wall_ns),
    ]
    online_out = (run_dir / "online.stdout.log").open("w", encoding="utf-8")
    online_err = (run_dir / "online.stderr.log").open("w", encoding="utf-8")
    online = subprocess.Popen(online_command, cwd=root, stdout=online_out,
                              stderr=online_err, start_new_session=True)
    if action.batch_concurrency:
        batch_out = (run_dir / "batch.stdout.log").open("w", encoding="utf-8")
        batch_err = (run_dir / "batch.stderr.log").open("w", encoding="utf-8")
        batch = subprocess.Popen(batch_command, cwd=root, stdout=batch_out,
                                 stderr=batch_err, start_new_session=True)
    else:
        (run_dir / "batch.jsonl").write_text("", encoding="utf-8")
        batch_out = batch_err = batch = None
    delay = (end_wall_ns - time.time_ns()) / 1e9
    if delay > 0:
        time.sleep(delay)
    time.sleep(max(0.5, 2 * config["hardware"]["telemetry_interval_ms"] / 1000))
    stop_process(telemetry)
    online_return = online.wait(timeout=1200)
    batch_return = 0 if batch is None else batch.wait(timeout=120)
    online_out.close()
    online_err.close()
    if batch_out is not None:
        batch_out.close()
        batch_err.close()
    online_rows = read_jsonl(run_dir / "online.jsonl")
    batch_rows = read_jsonl(run_dir / "batch.jsonl")
    with (run_dir / "components.csv").open(newline="", encoding="utf-8") as stream:
        telemetry_rows = sum(1 for _ in csv.DictReader(stream))
    marker = {
        "online_return_code": online_return,
        "batch_return_code": batch_return,
        "online_requests": len(online_rows),
        "online_errors": sum(row.get("error") is not None for row in online_rows),
        "online_load_shed": sum(row.get("status_code") == 429 for row in online_rows),
        "fatal_online_errors": sum(
            row.get("error") is not None and row.get("status_code") != 429
            for row in online_rows
        ),
        "batch_jobs_completed": sum(row.get("error") is None for row in batch_rows),
        "batch_errors": sum(row.get("error") is not None for row in batch_rows),
        "fatal_batch_errors": sum(row.get("error") is not None for row in batch_rows),
        "batch_tokens_completed": sum(int(row.get("completion_tokens") or 0)
                                      for row in batch_rows if row.get("error") is None),
        "telemetry_rows": telemetry_rows,
        "config_hash": canonical_hash(config),
        "action_hash": canonical_hash(action.as_dict()),
    }
    atomic_json(run_dir / "CELL_COMPLETE.json", marker)
    if not marker_valid(run_dir):
        raise RuntimeError(f"invalid pilot cell {run_dir}: {marker}")
    services.wait_idle()
    time.sleep(2)


def run_pilot(root: Path, config_path: Path, config: dict, resume: bool) -> Path:
    results = resolve(root, config["paths"]["results_root"])
    results.mkdir(parents=True, exist_ok=True)
    episodes = select_episodes(root, config)
    actions = [HybridAction.from_dict(value) for value in config["actions"]]
    replica_count = len(config["model"]["replicas"])
    if any(action.online_replicas > replica_count for action in actions):
        raise ValueError("action requests more replicas than configured")
    atomic_json(results / "campaign_manifest.json", {
        "config_hash": canonical_hash(config), "config": str(config_path.resolve()),
        "episodes": episodes, "actions": [item.as_dict() for item in actions],
        "expected_cells": len(episodes) * len(actions),
        "resume": resume,
    })
    control_file = Path(config["hardware"]["control_file"])
    apply_control(control_file, actions[0], replica_count,
                  int(config["runtime"]["online_concurrency"]))
    gpu_indices = config["hardware"]["gpu_indices"]
    try:
        with PowerCapManager(gpu_indices) as power, ServiceGroup(
            root, config, results / "service_logs"
        ) as services:
            rng = random.Random(int(config["seed"]))
            for episode in episodes:
                ordered = list(actions)
                rng.shuffle(ordered)
                for action in ordered:
                    run_dir = results / "cells" / episode["episode_id"].replace(":", "_") / action.name
                    if resume and marker_valid(run_dir):
                        continue
                    enforced = power.set_all(action.power_cap_w)
                    atomic_json(run_dir / "power_cap.json", {"enforced_w": enforced})
                    run_cell(root, config, services, action, episode, run_dir)
            restored = power.restore()
            atomic_json(results / "GPU_POWER_RESTORED.json", restored)
    finally:
        # PowerCapManager restores on every exception path. Keep an explicit
        # marker absent on failure so the audit cannot mistake partial data.
        pass
    return results
