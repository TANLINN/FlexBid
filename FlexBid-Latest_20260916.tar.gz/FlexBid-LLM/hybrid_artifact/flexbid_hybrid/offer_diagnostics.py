"""Lossless development-offer logging, and CPU-only observation of MPC searches.

No changed objective, constraints, reference, bid, timeout or action support.
Runtime logging is enabled only for the existing explicit one-cell development
opt-in. Serialization is deferred until after the immutable offer is frozen.
"""
from dataclasses import asdict, replace
import time

from .continuation import GuardedViabilityMPC
from .io import atomic_json


def solve_offer_recorded(loop, state, session, phase):
    if getattr(loop, '_one_cell_development', None) is None:
        return loop.optimizer.solve(state)
    if phase not in ('initial_offer', 'quantized_offer_validation'):
        raise ValueError('Unknown offer diagnostic phase')
    if not hasattr(session, '_offer_diagnostics'):
        session._offer_diagnostics = []
    if any(r['phase'] == phase for r in session._offer_diagnostics):
        raise ValueError('Duplicate offer solve phase; refusing ambiguous diagnostics')
    # These immutable inputs are retained, not serialized/recomputed on the
    # offer clock. In particular do not re-read telemetry or rebuild features.
    row = dict(phase=phase, state=replace(state, workload_features=dict(state.workload_features)), parameters=loop.optimizer.parameters,
               actions=tuple(loop.optimizer.actions),
               baseline_action=loop.optimizer.baseline_action,
               identities=dict(loop._one_cell_development),
               cached_plan_present=getattr(loop.optimizer, '_cached_plan', None) is not None,
               started_wall_ns=time.time_ns(), result=None, error=None)
    session._offer_diagnostics.append(row)
    started = time.perf_counter()
    try:
        result = loop.optimizer.solve(state)
        row['result'] = result  # same object returned, before baseline replacement
        return result
    except BaseException as exc:
        row['error'] = repr(exc)
        raise
    finally:
        row['call_elapsed_ms'] = (time.perf_counter() - started) * 1000
        row['finished_wall_ns'] = time.time_ns()
        if row['error'] is not None:
            # Preserve the original solver exception even if disk logging fails.
            try:
                flush_offer_diagnostics(session)
            except Exception as logging_error:
                print('OFFER_DIAGNOSTIC_WRITE_FAILED:', repr(logging_error), flush=True)


def flush_offer_diagnostics(session):
    pending = getattr(session, '_offer_diagnostics', [])
    if not pending:
        return
    rows = []
    for row in pending:
        value = dict(row)
        value['state'] = asdict(row['state'])
        value['parameters'] = asdict(row['parameters'])
        value['actions'] = [a.as_dict() for a in row['actions']]
        value['result'] = row['result'].as_dict() if row['result'] is not None else None
        rows.append(value)
    path = session.output_dir / ('offer_diagnostic_' + session.run_id + '.json')
    if path.exists():
        raise ValueError('Offer diagnostics already exist; no overwrite')
    atomic_json(path, dict(schema='development_offer_diagnostics_v1',
        input_kind='EXACT_OFFER_INPUT', solves=rows, contract=session.metadata(),
        serialization_started_wall_ns=time.time_ns(),
        note='Fixed activation is unchanged; logging latency is not subtracted from timing.',
        external_delivery_verified=False, deployment_authorized=False))
    session._offer_diagnostics = []


class ObservedCPUOptimizer(GuardedViabilityMPC):
    """Observe existing computations; no second search or envelope prediction."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.observed_envelopes = []
        self.search_proposal = None
        self.effective_search_parameters = None

    def envelopes(self, state):
        result = super().envelopes(state)
        self.observed_envelopes.append(result)
        return result

    def _search(self, state):
        self.effective_search_parameters = self.parameters
        result = super()._search(state)
        self.search_proposal = result
        return result


def classify_result(result):
    """Labels are solver diagnostics, never proofs of physical infeasibility."""
    if result.feasible:
        return 'MODEL_VALIDATED_SCHEDULE_NOT_PHYSICAL_CERTIFICATE'
    if result.validation_reason.startswith('new plan rejected:'):
        return 'SEARCH_PROPOSAL_REJECTED_BY_CONTINUATION_VALIDATOR'
    if 'budget exceeded' in result.underlying_solver_reason:
        return 'SEARCH_BUDGET_EXHAUSTED_NOT_INFEASIBILITY_PROOF'
    if 'baseline prediction is unsafe' in result.underlying_solver_reason:
        return 'BASELINE_OR_ACTION_SLO_BOUND_REJECTION'
    return 'SEARCH_FOUND_NO_VALIDATED_SCHEDULE_NOT_PHYSICAL_INFEASIBILITY_PROOF'
