"""Explicitly incomplete environment observations for one development run only.

NIC enumeration overflow is a documented nvidia-smi failure class, not proof of
healthy GPUs/NVLink. Never invent a matrix or treat this observation as evidence
that permits production use. All other observation failures remain fatal.
"""
import re
import subprocess

from .development_episode import SCHEMA


def read_topology(config, *, diagnostic_topology=False):
    if diagnostic_topology is not False:
        d = config.get('dynamic_controller', {})
        if (diagnostic_topology is not True
                or d.get('deployment_mode') != 'development'
                or d.get('allow_unvalidated_development') is not True
                or d.get('external_commitments_enabled') is not False
                or d.get('force_baseline') is not False
                or d.get('development_episode') != {
                    'schema': SCHEMA, 'diagnostic_reference_only': True}):
            raise ValueError('Incomplete topology observation is restricted to the explicit development episode')
    command = ['nvidia-smi', 'topo', '-m']
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=15, check=True)
    except subprocess.CalledProcessError as exc:
        stdout, stderr = exc.stdout or '', exc.stderr or ''
        text = stdout + '\n' + stderr
        # Normalize presentation only. Preserve raw stdout/stderr in the audit;
        # never remove error words, cursor/erase controls or other escape codes.
        text = re.sub(r'\x1b\[[0-9;]*m', '', text)
        overflow = re.search(r'(\d+) NICs found in the topology, only displaying (\d+) in the matrix\.', text)
        # Whitelist this precise tool failure, not arbitrary rc=255 or NVML faults.
        remaining = re.sub(r'\d+ NICs found in the topology, only displaying \d+ in the matrix\.', '', text)
        remaining = remaining.replace('Failed to run topology matrix', '')
        remaining = re.sub(r'GPU\d+|CPU Affinity|NUMA Affinity|GPU NUMA ID', '', remaining)
        if (not diagnostic_topology or exc.cmd != command or exc.returncode != 255
                or not overflow or int(overflow[1]) <= int(overflow[2])
                or 'Failed to run topology matrix' not in text or remaining.strip()):
            raise
        audit = dict(status='UNAVAILABLE_NIC_ENUMERATION_FAILURE', command=command,
            return_code=exc.returncode, stdout=stdout, stderr=stderr,
            detected_nics=int(overflow[1]), displayed_nic_limit=int(overflow[2]),
            topology_complete=False, gpu_health_verified=False, nvlink_verified=False,
            target_environment_validated=False, deployment_authorized=False,
            note='Signature matches a documented tool failure class; hardware cause is not independently established.')
        print('DEVELOPMENT_TOPOLOGY_UNAVAILABLE: original error retained; GPU/NVLink health NOT certified', flush=True)
        return None, audit
    return result.stdout.strip(), dict(status='OBSERVED', command=command,
        return_code=0, stdout=result.stdout, stderr=result.stderr,
        gpu_health_verified=False, nvlink_verified=False,
        target_environment_validated=False, deployment_authorized=False)
