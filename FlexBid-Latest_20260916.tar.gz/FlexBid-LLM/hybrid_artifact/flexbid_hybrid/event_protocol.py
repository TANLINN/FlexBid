"""Event-clock and fixed-window metering primitives (GPU-domain research harness).

No market acceptance API and no physical reliability certificate. Wall time is
logged for replay alignment; one monotonic anchor drives all event boundaries.
Missing samples are not interpolated across arbitrarily long gaps.
"""
from __future__ import annotations

import math
import threading
import time
import uuid
from dataclasses import replace

from .io import atomic_json
from .mpc import ControlState, MPCPlan, PlanStep


PROTOCOL = "fixed_event_clock_v1"


class FixedWindowMeter:
    """Piecewise-linear power integral with exact, immutable window boundaries."""

    def __init__(self, contract, max_gap_s=1.0):
        if not math.isfinite(max_gap_s) or max_gap_s <= 0 or contract.event_s <= 0:
            raise ValueError("positive event and maximum sample gap required")
        if not contract.reference_power_w:
            raise ValueError("freeze the same-boundary reference before metering")
        self.contract, self.max_gap_s = contract, max_gap_s
        self.previous = None
        self.latest_s = -math.inf
        self.rows = []
        self.pieces = []
        for index in range(math.ceil(contract.event_s / contract.settlement_interval_s)):
            start = index * contract.settlement_interval_s
            end = min(contract.event_s, start + contract.settlement_interval_s)
            self.rows.append(dict(index=index, start_s=start, end_s=end,
                                 covered_s=0.0, delivered_ws=0.0))
            self.pieces.append([])

    def add(self, elapsed_s, power_w):
        if not math.isfinite(elapsed_s) or elapsed_s <= self.latest_s:
            raise ValueError("meter timestamps must strictly increase")
        valid = power_w is not None and math.isfinite(power_w) and power_w >= 0
        current = (float(elapsed_s), float(power_w) if valid else None)
        self.latest_s = elapsed_s
        old, self.previous = self.previous, current
        if old is None or old[1] is None or current[1] is None:
            return
        t0, p0 = old
        t1, p1 = current
        if t1 - t0 > self.max_gap_s:
            return
        for row in self.rows:
            left, right = max(t0, row["start_s"]), min(t1, row["end_s"])
            while right > left + 1e-10:
                # The frozen reference is piecewise constant; split at its
                # knots too, not just at settlement/control boundaries.
                step = self.contract.trajectory_step_s
                knot = (math.floor((left + 1e-9) / step) + 1) * step
                end = min(right, knot)
                pa = p0 + (p1 - p0) * (left - t0) / (t1 - t0)
                pb = p0 + (p1 - p0) * (end - t0) / (t1 - t0)
                dt = end - left
                reference = self.contract.reference_at((left + end) / 2)
                row["covered_s"] += dt
                row["delivered_ws"] += (reference - (pa + pb) / 2) * dt
                self.pieces[row['index']].append((left, end, reference - pa, reference - pb))
                left = end

    def report(self, bid_w, accepted, *, final=False):
        if not math.isfinite(bid_w) or bid_w < 0:
            raise ValueError("invalid frozen bid")
        output = []
        for row in self.rows:
            if not final and self.latest_s < row["end_s"]:
                continue
            dt = row["end_s"] - row["start_s"]
            covered = abs(row["covered_s"] - dt) <= 1e-6
            delivered = row["delivered_ws"] / dt if covered else None
            output.append({**row, "coverage_complete": covered,
                           "delivered_mean_w": delivered,
                           "required_ws": bid_w * dt if accepted else None,
                           "status": ("METER_INVALID" if not covered else
                                      "NOT_COMMITTED" if not accepted else
                                      "DELIVERED" if delivered + 1e-7 >= bid_w else
                                      "UNDERDELIVERED")})
        return output

    def feedback(self, elapsed_s):
        """Partial integral; valid only through an actual sample at this time."""
        if elapsed_s >= self.contract.event_s:
            return 0.0, 0.0, True
        index = min(len(self.rows) - 1, int((max(0, elapsed_s) + 1e-9) / self.contract.settlement_interval_s))
        row = self.rows[index]
        elapsed = max(0, elapsed_s - row["start_s"])
        coverage, energy = 0., 0.
        for left, end, a, b in self.pieces[index]:
            right = min(end, elapsed_s)
            if right <= left:
                continue
            last = a + (b - a) * (right - left) / (end - left)
            coverage += right - left
            energy += (a + last) * (right - left) / 2
        return elapsed, energy, abs(coverage - elapsed) <= 1e-5


class EventSession:
    """Independent meter thread; a blocking optimizer cannot stop event metering."""

    def __init__(self, contract, activation_wall_ns, *, meter_reader, output_dir,
                 sample_s=0.2, max_gap_s=1.0):
        if not (0 < sample_s <= max_gap_s):
            raise ValueError("sample period must fit maximum meter gap")
        wall, mono = time.time_ns(), time.monotonic()
        self.activation_wall_ns = int(activation_wall_ns)
        self.activation_mono = mono + (activation_wall_ns - wall) / 1e9
        self.contract, self.reader, self.sample_s = contract, meter_reader, sample_s
        self.meter = FixedWindowMeter(contract, max_gap_s)
        self.output_dir = output_dir
        self.run_id = uuid.uuid4().hex
        self.bid_w, self.accepted = 0.0, False
        self.offer_finished_wall_ns = None
        self.offer_reason = "not offered"
        self.prepared_plan = None
        self.meter_error = None
        self.first_actuation_elapsed_s = None
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._sample, daemon=True)

    def elapsed(self):
        return time.monotonic() - self.activation_mono

    def start(self):
        self.thread.start()

    def sample_now(self):
        with self.lock:
            power = self.reader()
            elapsed = self.elapsed()
            if elapsed == self.meter.latest_s:
                # Some host clocks have millisecond resolution. A controller
                # read and sampler read may land on the same timestamp.
                return elapsed, self.meter.previous[1]
            self.meter.add(elapsed, power)
        return elapsed, power

    def _sample(self):
        import json
        path = self.output_dir / ("event_meter_" + self.run_id + ".jsonl")
        try:
            with path.open("x", encoding="utf-8") as stream:
                while not self.stop_event.is_set():
                    elapsed, power = self.sample_now()
                    stream.write(json.dumps(dict(elapsed_s=elapsed, gpu_power_w=power,
                                                 wall_time_ns=time.time_ns())) + "\n")
                    stream.flush()
                    if elapsed >= self.contract.event_s:
                        break  # includes the sample bracketing release
                    self.stop_event.wait(self.sample_s)
        except Exception as exc:
            self.meter_error = repr(exc)

    def freeze_offer(self, bid_w, accepted, reason):
        if self.offer_finished_wall_ns is not None:
            raise RuntimeError("offer is immutable")
        on_time = self.elapsed() < 0
        self.accepted = bool(accepted and on_time and math.isfinite(bid_w) and bid_w > 0)
        self.bid_w = float(bid_w) if self.accepted else 0.0
        self.offer_finished_wall_ns = time.time_ns()
        self.offer_reason = reason if on_time else "offer deadline missed; abstained before activation"
        self.save()

    def wait_activation(self):
        while self.elapsed() < 0:
            time.sleep(min(0.1, -self.elapsed()))

    def metadata(self):
        return dict(protocol=PROTOCOL, run_id=self.run_id,
                    acceptance_mode="research_harness_local_acceptance_not_market_ack",
                    activation_wall_ns=self.activation_wall_ns,
                    release_wall_ns=self.activation_wall_ns + int(self.contract.event_s * 1e9),
                    deadline_wall_ns=self.activation_wall_ns + int(self.contract.deadline_s * 1e9),
                    offer_finished_wall_ns=self.offer_finished_wall_ns,
                    accepted=self.accepted, committed_bid_w=self.bid_w, reason=self.offer_reason,
                    event_s=self.contract.event_s, deadline_from_activation_s=self.contract.deadline_s,
                    settlement_interval_s=self.contract.settlement_interval_s,
                    reference_power_w=list(self.contract.reference_power_w),
                    meter_boundary="gpu_nvml", first_actuation_elapsed_s=self.first_actuation_elapsed_s)

    def snapshot(self, elapsed_s, *, final=False):
        with self.lock:
            windows = self.meter.report(self.bid_w, self.accepted, final=final)
            if not final:
                windows = [row for row in windows if row['end_s'] <= elapsed_s]
            partial = self.meter.feedback(elapsed_s)
        failures = [row for row in windows if row["status"] in ("METER_INVALID", "UNDERDELIVERED")]
        return dict(windows=windows, failures=failures, meter_error=self.meter_error,
                    expected_windows=len(self.meter.rows), closed_windows=len(windows),
                    partial_elapsed_s=partial[0], partial_delivered_ws=partial[1],
                    partial_coverage_valid=partial[2])

    def save(self, *, final=False):
        report = {"contract": self.metadata(), **self.snapshot(max(0, self.elapsed()), final=final)}
        atomic_json(self.output_dir / ("event_protocol_" + self.run_id + ".json"), report)
        return report

    def close(self):
        self.stop_event.set()
        self.thread.join(timeout=2.0)
        if self.thread.is_alive():
            self.meter_error = "meter thread did not stop within 2 seconds"
        return self.save(final=True)


def baseline_plan(loop, reason, state=None):
    action = loop.actions[loop.optimizer.baseline_action]
    debt = 0. if state is None else state.debt_tokens
    cohort = 0. if state is None else state.cohort_tokens
    bid = 0. if state is None else float(state.committed_bid_w or 0.)
    stage = 'event' if state is None or state.event_remaining_s > 0 else 'recovery'
    duration = loop.event_s if state is None else min(loop.optimizer.parameters.control_period_s,
                                                       state.deadline_remaining_s)
    step = PlanStep(0, stage, duration, action, debt, debt, 0, 0, math.inf, math.inf,
                    cohort_before_tokens=cohort, cohort_after_tokens=cohort)
    return MPCPlan(False, bid, 0, (step,), debt, 0, 0, 0, reason, terminal_cohort_tokens=cohort)


def prepare_event(loop, initial, baseline_power_w, baseline_ttft_ms, baseline_tpot_ms):
    """Prepare/freeze an offer before activation; never actuate curtailment early.

    Called after warmup, inside the runtime's power-restoration try/finally.
    A zero-offer or forced baseline is explicitly NOT a feasibility certificate.
    """
    from .runtime_controller import read_component_power_w
    from .offer_diagnostics import solve_offer_recorded, flush_offer_diagnostics
    activation = loop.activation_wall_ns
    if activation is None:
        activation = time.time_ns() + int(loop.offer_lead_s * 1e9)
    session = EventSession(loop.contract, activation,
        meter_reader=lambda: read_component_power_w(loop.gpu_indices),
        output_dir=loop.state_path.parent, sample_s=loop.meter_sample_s,
        max_gap_s=loop.meter_max_gap_s)
    loop.event_session = session  # finally closes even if the offer solve raises
    session.start()
    plan = baseline_plan(loop, "zero-offer baseline")
    reason = "forced matched-baseline trajectory"
    state = ControlState(source=loop.source, event_remaining_s=loop.event_s,
        deadline_remaining_s=loop.deadline_s, backlog_tokens=0,
        current_action=loop.current_action, ttft_slo_ms=loop.ttft_slo_ms,
        tpot_slo_ms=loop.tpot_slo_ms, workload_features=loop.features.update(initial),
        baseline_power_w=baseline_power_w, baseline_ttft_ms=baseline_ttft_ms,
        baseline_tpot_ms=baseline_tpot_ms, baseline_batch_tps=loop.baseline_batch_tps,
        cohort_remaining_tokens=loop.initial_cohort_tokens, dr_debt_tokens=0,
        contract=loop.contract, previous_power_w=read_component_power_w(loop.gpu_indices))
    bid = 0.0
    warmup_valid = all(v is not None and math.isfinite(v) for v in
                       (baseline_power_w, baseline_ttft_ms, baseline_tpot_ms))
    if not loop.force_baseline and not warmup_valid:
        reason = "insufficient measured pre-event baseline; abstained"
    if not loop.force_baseline and warmup_valid and session.elapsed() < 0:
        plan = solve_offer_recorded(loop, state, session, 'initial_offer')
        reason = plan.reason
        if plan.feasible and plan.steps:
            bid = loop._commit(plan, state)
            if bid > 0 and getattr(loop, 'offer_calibrator', None) is None:
                # Freeze only after a second search validates the quantized bid.
                plan = solve_offer_recorded(loop, replace(state, committed_bid_w=bid),
                                            session, 'quantized_offer_validation')
                if not plan.feasible or not plan.steps:
                    bid, reason = 0.0, "no validated schedule for candidate offer"
    session.freeze_offer(bid, bid > 0, reason)
    flush_offer_diagnostics(session)
    loop.committed_bid_w, loop.offer_accepted = session.bid_w, session.accepted
    if not session.accepted:
        plan = baseline_plan(loop, session.offer_reason)
    session.prepared_plan = plan
    session.wait_activation()
    return session


def next_plan(session, loop, state):
    if not session.accepted:
        return baseline_plan(loop, session.offer_reason, state)
    if session.prepared_plan is not None:
        # First actuation uses the pre-activation solution, not a new blocking
        # search. Observed actuation latency stays inside the first meter window.
        plan, session.prepared_plan = session.prepared_plan, None
        return plan
    status = session.snapshot(session.contract.event_s - state.event_remaining_s)
    if session.meter_error or not status["partial_coverage_valid"]:
        return baseline_plan(loop, "meter gap; unverified service protection; obligation retained", state)
    return loop.optimizer.solve(state)


def audit_completed_event(run_dir):
    """Collection completeness is not successful delivery; keep both counts."""
    import json
    reports = list(run_dir.glob('event_protocol_*.json'))
    if len(reports) != 1:
        return {'complete': False, 'failed_windows': None, 'reason': 'need exactly one current event report'}
    report = json.loads(reports[0].read_text(encoding='utf-8'))
    cell = json.loads((run_dir / 'cell.json').read_text(encoding='utf-8'))
    contract = report['contract']
    rows = report['windows']
    accepted = bool(contract['accepted'])
    on_time = (contract['offer_finished_wall_ns'] is not None and
               contract['offer_finished_wall_ns'] < contract['activation_wall_ns'])
    expected = math.ceil(contract['event_s'] / contract['settlement_interval_s'])
    complete = (contract['protocol'] == PROTOCOL and
                contract['activation_wall_ns'] == cell.get('activation_wall_ns') and
                contract['event_s'] == cell['event_s'] and
                contract['deadline_from_activation_s'] == cell['deadline_s'] and
                report['meter_error'] is None and (on_time or not accepted) and
                len(rows) == expected and report['expected_windows'] == expected and
                [r['index'] for r in rows] == list(range(expected)) and
                all(r['coverage_complete'] for r in rows) and
                abs(rows[-1]['end_s'] - contract['event_s']) < 1e-8)
    return dict(complete=complete, failed_windows=sum(r['status'] in
                ('METER_INVALID', 'UNDERDELIVERED') for r in rows),
                report=reports[0].name, accepted=accepted, offer_on_time=on_time,
                note='complete means fully measured, NOT successful DR delivery')
