from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Iterable


def finite_sample_quantile(scores: Iterable[float], alpha: float) -> float:
    """Exact one-sided split-conformal order statistic."""
    if not 0 < alpha < 1:
        raise ValueError("alpha must be in (0, 1)")
    ordered = sorted(float(value) for value in scores)
    if not ordered:
        return math.inf
    rank = math.ceil((len(ordered) + 1) * (1 - alpha))
    return math.inf if rank > len(ordered) else ordered[rank - 1]


@dataclass
class HybridJointCalibrator:
    """Jointly calibrate power, online SLO, and batch-throughput tails.

    The episode score is the maximum across every profiled action.  This makes
    action selection after prediction calibration-safe, unlike row-wise CP.
    """

    alpha: float = 0.05
    scales: dict[str, float] = field(default_factory=lambda: {
        "power_mean_w": 100.0,
        "ttft_p95_ms": 1000.0,
        "tpot_p99_ms": 10.0,
        "batch_tokens_per_s": 10.0,
    })
    row_radius: float = math.inf
    episode_radius: float = math.inf
    episode_radius_by_group: dict[str, float] = field(default_factory=dict)
    episode_count: int = 0

    def fit(
        self,
        rows: Iterable[dict],
        prediction_keys: dict[str, str],
        *,
        episode_key: str = "episode_id",
        group_key: str = "source",
    ) -> "HybridJointCalibrator":
        episode_scores: dict[str, list[float]] = defaultdict(list)
        grouped: dict[tuple[str, str], list[float]] = defaultdict(list)
        row_scores: list[float] = []
        for row in rows:
            scores = [
                abs(float(row["power_mean_w"]) - float(row[prediction_keys["power_mean_w"]]))
                / self.scales["power_mean_w"],
                max(0.0, float(row["ttft_p95_ms"]) - float(row[prediction_keys["ttft_p95_ms"]]))
                / self.scales["ttft_p95_ms"],
                max(0.0, float(row["tpot_p99_ms"]) - float(row[prediction_keys["tpot_p99_ms"]]))
                / self.scales["tpot_p99_ms"],
                max(0.0, float(row[prediction_keys["batch_tokens_per_s"]])
                    - float(row["batch_tokens_per_s"]))
                / self.scales["batch_tokens_per_s"],
            ]
            score = max(scores)
            episode = str(row[episode_key])
            group = str(row.get(group_key) or "global")
            row_scores.append(score)
            episode_scores[episode].append(score)
            grouped[(group, episode)].append(score)
        maxima = [max(values) for values in episode_scores.values()]
        self.episode_count = len(maxima)
        self.row_radius = finite_sample_quantile(row_scores, self.alpha)
        self.episode_radius = finite_sample_quantile(maxima, self.alpha)
        by_group: dict[str, list[float]] = defaultdict(list)
        for (group, _episode), values in grouped.items():
            by_group[group].append(max(values))
        self.episode_radius_by_group = {
            group: finite_sample_quantile(values, self.alpha)
            for group, values in by_group.items()
        }
        return self

    def radius(self, mode: str, group: str = "global") -> float:
        if mode == "none":
            return 0.0
        if mode == "row":
            return self.row_radius
        if mode != "episode":
            raise ValueError(f"unknown calibration mode: {mode}")
        conditional = self.episode_radius_by_group.get(group, math.inf)
        return conditional if math.isfinite(conditional) else self.episode_radius

    @property
    def finite(self) -> bool:
        return math.isfinite(self.episode_radius)

    def as_dict(self) -> dict:
        return {
            "alpha": self.alpha,
            "scales": self.scales,
            "row_radius": self.row_radius,
            "episode_radius": self.episode_radius,
            "episode_radius_by_group": self.episode_radius_by_group,
            "episode_count": self.episode_count,
            "finite": self.finite,
        }


def actuator_key(row: dict) -> str:
    """Stable key shared by profiled and runtime-generated action names."""

    return ":".join((
        str(int(float(row["online_replicas"]))),
        str(int(float(row["batch_concurrency"]))),
        f"{float(row['power_cap_w']):g}",
    ))


@dataclass
class ActionNormalizedJointCalibrator:
    """Simultaneous paired-effect bounds with action-local noise scales.

    Scale functions are frozen from training data.  Calibration then takes the
    maximum standardized *directional* error over every target and profiled
    action in an episode.  Consequently the episode quantile still covers
    post-calibration action selection, while a noisy actuator does not impose
    its raw error magnitude on every other actuator.
    """

    alpha: float = 0.05
    scales_by_action: dict[str, dict[str, float]] = field(default_factory=dict)
    row_radius: float = math.inf
    episode_radius: float = math.inf
    episode_radius_by_group: dict[str, float] = field(default_factory=dict)
    episode_count: int = 0

    @staticmethod
    def directional_error(target: str, actual: float, predicted: float) -> float:
        if target in {"power_mean_w", "batch_tokens_per_s"}:
            # These paired targets are reduction/service improvements; an
            # over-prediction is the unsafe direction.
            return max(0.0, predicted - actual)
        # TTFT/TPOT targets are increases over baseline; under-prediction is
        # unsafe.
        return max(0.0, actual - predicted)

    def fit(
        self,
        rows: Iterable[dict],
        prediction_keys: dict[str, str],
        *,
        episode_key: str = "episode_id",
        group_key: str = "source",
    ) -> "ActionNormalizedJointCalibrator":
        episode_scores: dict[str, list[float]] = defaultdict(list)
        grouped: dict[tuple[str, str], list[float]] = defaultdict(list)
        row_scores: list[float] = []
        for row in rows:
            action = actuator_key(row)
            scales = self.scales_by_action.get(action)
            if not scales:
                raise ValueError(f"missing frozen residual scales for {action}")
            scores = []
            for target, prediction_key in prediction_keys.items():
                scale = float(scales[target])
                if not math.isfinite(scale) or scale <= 0:
                    raise ValueError(f"invalid {target} scale for {action}: {scale}")
                scores.append(self.directional_error(
                    target,
                    float(row[target]),
                    float(row[prediction_key]),
                ) / scale)
            score = max(scores, default=0.0)
            episode = str(row[episode_key])
            group = str(row.get(group_key) or "global")
            row_scores.append(score)
            episode_scores[episode].append(score)
            grouped[(group, episode)].append(score)
        maxima = [max(values) for values in episode_scores.values()]
        self.episode_count = len(maxima)
        self.row_radius = finite_sample_quantile(row_scores, self.alpha)
        self.episode_radius = finite_sample_quantile(maxima, self.alpha)
        by_group: dict[str, list[float]] = defaultdict(list)
        for (group, _episode), values in grouped.items():
            by_group[group].append(max(values))
        self.episode_radius_by_group = {
            group: finite_sample_quantile(values, self.alpha)
            for group, values in by_group.items()
        }
        return self

    def radius(self, mode: str, group: str = "global") -> float:
        if mode == "none":
            return 0.0
        if mode == "row":
            return self.row_radius
        if mode != "episode":
            raise ValueError(f"unknown calibration mode: {mode}")
        conditional = self.episode_radius_by_group.get(group, math.inf)
        return conditional if math.isfinite(conditional) else self.episode_radius

    def margin(self, row: dict, target: str, mode: str) -> float:
        scales = self.scales_by_action.get(actuator_key(row))
        if not scales:
            return math.inf
        return self.radius(mode, str(row.get("source") or "global")) * float(
            scales[target]
        )

    @property
    def finite(self) -> bool:
        return math.isfinite(self.episode_radius)

    def as_dict(self) -> dict:
        return {
            "kind": "action_normalized_directional_joint_episode",
            "alpha": self.alpha,
            "scales_by_action": self.scales_by_action,
            "row_radius": self.row_radius,
            "episode_radius": self.episode_radius,
            "episode_radius_by_group": self.episode_radius_by_group,
            "episode_count": self.episode_count,
            "finite": self.finite,
        }
