from __future__ import annotations

from collections.abc import Iterable


class PowerCapManager:
    """Set every configured GPU cap and always restore the original values."""

    def __init__(self, gpu_indices: Iterable[int]):
        import pynvml

        self.nvml = pynvml
        self.nvml.nvmlInit()
        self.indices = list(gpu_indices)
        self.handles = {
            index: self.nvml.nvmlDeviceGetHandleByIndex(index)
            for index in self.indices
        }
        self.original = {
            index: self.nvml.nvmlDeviceGetEnforcedPowerLimit(handle)
            for index, handle in self.handles.items()
        }
        self.closed = False

    def constraints_w(self) -> tuple[float, float]:
        values = [
            self.nvml.nvmlDeviceGetPowerManagementLimitConstraints(handle)
            for handle in self.handles.values()
        ]
        return max(item[0] for item in values) / 1000, min(item[1] for item in values) / 1000

    def set_all(self, watts: float) -> dict[int, float]:
        minimum, maximum = self.constraints_w()
        if not minimum <= watts <= maximum:
            raise ValueError(f"power cap {watts} outside common range [{minimum}, {maximum}]")
        result = {}
        for index, handle in self.handles.items():
            self.nvml.nvmlDeviceSetPowerManagementLimit(handle, int(round(watts * 1000)))
            enforced = self.nvml.nvmlDeviceGetEnforcedPowerLimit(handle) / 1000
            if abs(enforced - watts) > 0.6:
                raise RuntimeError(f"GPU {index}: requested {watts}, enforced {enforced}")
            result[index] = enforced
        return result

    def restore(self) -> dict[int, float]:
        result = {}
        for index, handle in self.handles.items():
            self.nvml.nvmlDeviceSetPowerManagementLimit(handle, self.original[index])
            current = self.nvml.nvmlDeviceGetEnforcedPowerLimit(handle)
            if current != self.original[index]:
                raise RuntimeError(f"GPU {index}: failed to restore power cap")
            result[index] = current / 1000
        return result

    def close(self) -> None:
        if self.closed:
            return
        try:
            self.restore()
        finally:
            self.nvml.nvmlShutdown()
            self.closed = True

    def __enter__(self) -> "PowerCapManager":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()
