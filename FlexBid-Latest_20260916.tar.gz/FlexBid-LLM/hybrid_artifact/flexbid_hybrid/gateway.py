"""Priority-aware gateway for online and interruptible batch inference."""

from __future__ import annotations

import asyncio
import json
import os
import time
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import Response, StreamingResponse


CONTROL_FILE = Path(os.environ.get(
    "FLEXBID_HYBRID_CONTROL_FILE", "/tmp/flexbid-hybrid-control.json"
))
UPSTREAMS = [item.rstrip("/") for item in os.environ.get(
    "FLEXBID_HYBRID_UPSTREAMS", "http://127.0.0.1:18100"
).split(",") if item.strip()]
DEFAULT_ONLINE_CONCURRENCY = int(os.environ.get("FLEXBID_ONLINE_CONCURRENCY", "32"))
MAX_ONLINE_QUEUE = int(os.environ.get("FLEXBID_MAX_ONLINE_QUEUE", "512"))


class AdjustableGate:
    def __init__(self, limit: int):
        self.limit = limit
        self.active = 0
        self.waiting = 0
        self.condition = asyncio.Condition()

    async def acquire(self) -> None:
        async with self.condition:
            self.waiting += 1
            try:
                while self.active >= self.limit:
                    await self.condition.wait()
                self.active += 1
            finally:
                self.waiting -= 1

    async def release(self) -> None:
        async with self.condition:
            self.active = max(0, self.active - 1)
            self.condition.notify_all()

    async def resize(self, limit: int) -> None:
        if limit <= 0:
            raise ValueError("gate limit must be positive")
        async with self.condition:
            self.limit = limit
            self.condition.notify_all()


class State:
    def __init__(self):
        self.online_gate = AdjustableGate(DEFAULT_ONLINE_CONCURRENCY)
        self.batch_gate = AdjustableGate(1)
        self.online_replica_ids = list(range(len(UPSTREAMS)))
        self.batch_replica_ids = list(range(len(UPSTREAMS)))
        self.batch_paused = True
        self.inflight = [0 for _ in UPSTREAMS]
        self.inflight_online = [0 for _ in UPSTREAMS]
        self.inflight_batch = [0 for _ in UPSTREAMS]
        self.completed_online = 0
        self.completed_batch = 0
        self.last_mtime = -1
        self.lock = asyncio.Lock()
        self.metrics = deque(maxlen=2048)
        self.client = httpx.AsyncClient(
            timeout=None,
            limits=httpx.Limits(max_connections=2048, max_keepalive_connections=0),
        )

    async def refresh(self) -> None:
        try:
            stat = CONTROL_FILE.stat()
            if stat.st_mtime_ns == self.last_mtime:
                return
            value = json.loads(CONTROL_FILE.read_text(encoding="utf-8"))
            online = [int(item) for item in value["online_replica_ids"]]
            batch = [int(item) for item in value.get("batch_replica_ids", online)]
            if not online or min(online + batch, default=0) < 0:
                raise ValueError("invalid replica set")
            if max(online + batch, default=0) >= len(UPSTREAMS):
                raise ValueError("replica ID exceeds upstream count")
            self.online_replica_ids = online
            self.batch_replica_ids = batch
            self.batch_paused = bool(value.get("batch_paused", False))
            await self.online_gate.resize(int(value.get(
                "online_concurrency", DEFAULT_ONLINE_CONCURRENCY
            )))
            await self.batch_gate.resize(max(1, int(value.get("batch_concurrency", 1))))
            self.last_mtime = stat.st_mtime_ns
        except FileNotFoundError:
            return

    async def choose(self, request_class: str) -> int:
        allowed = self.online_replica_ids if request_class == "online" else self.batch_replica_ids
        async with self.lock:
            # Online requests avoid replicas currently occupied by batch work
            # when an equally idle alternative exists.
            index = min(allowed, key=lambda item: (
                self.inflight[item], self.inflight_batch[item], item
            ))
            self.inflight[index] += 1
            if request_class == "online":
                self.inflight_online[index] += 1
            else:
                self.inflight_batch[index] += 1
            return index

    async def finish(self, index: int, request_class: str, metric: dict) -> None:
        async with self.lock:
            self.inflight[index] = max(0, self.inflight[index] - 1)
            if request_class == "online":
                self.inflight_online[index] = max(0, self.inflight_online[index] - 1)
                self.completed_online += 1
                sequence = self.completed_online
            else:
                self.inflight_batch[index] = max(0, self.inflight_batch[index] - 1)
                self.completed_batch += 1
                sequence = self.completed_batch
            self.metrics.append({
                "class": request_class,
                "sequence": sequence,
                "completed_wall_time_ns": time.time_ns(),
                **metric,
            })


state = State()


@asynccontextmanager
async def lifespan(_app: FastAPI):
    if not UPSTREAMS:
        raise RuntimeError("FLEXBID_HYBRID_UPSTREAMS is empty")
    yield
    await state.client.aclose()


app = FastAPI(lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "upstreams": UPSTREAMS}


@app.get("/flexbid/state")
async def flexbid_state():
    await state.refresh()
    recent_online = [
        value for value in state.metrics
        if value.get("class") == "online"
    ][-256:]
    return {
        "online_replica_ids": state.online_replica_ids,
        "batch_replica_ids": state.batch_replica_ids,
        "batch_paused": state.batch_paused,
        "inflight": state.inflight,
        "inflight_online": state.inflight_online,
        "inflight_batch": state.inflight_batch,
        "online_waiting": state.online_gate.waiting,
        "batch_waiting": state.batch_gate.waiting,
        "completed_online": state.completed_online,
        "completed_batch": state.completed_batch,
        "recent_online_metrics": recent_online,
    }


@app.post("/flexbid/reset")
async def flexbid_reset():
    """Reset per-trajectory metrics after the gateway drains."""

    await state.refresh()

    if sum(state.inflight):
        raise RuntimeError(
            "gateway must be idle before resetting experiment state"
        )

    state.completed_online = 0
    state.completed_batch = 0
    state.metrics.clear()

    return {"status": "reset"}


def _request_class(request: Request) -> str:
    value = request.headers.get("x-flexbid-class", "online").lower()
    return value if value in {"online", "batch"} else "online"


@app.api_route("/v1/{path:path}", methods=["GET", "POST"])
async def proxy(path: str, request: Request):
    await state.refresh()
    request_class = _request_class(request)
    request_source = request.headers.get("x-flexbid-source", "unknown").lower()
    gate = state.online_gate if request_class == "online" else state.batch_gate
    if request_class == "batch" and state.batch_paused:
        raise HTTPException(status_code=503, detail="batch work paused for demand response")
    if request_class == "online" and gate.waiting >= MAX_ONLINE_QUEUE:
        raise HTTPException(status_code=429, detail="online queue safety limit")
    await gate.acquire()
    index = await state.choose(request_class)
    try:
        body = await request.body()
    except BaseException:
        # A client may be cancelled exactly at the measurement boundary.
        # Release both accounting objects so the next cell can drain.
        await state.finish(
            index, request_class, {"error": "request-body"}
        )
        await gate.release()
        raise
    request_metadata = {}
    try:
        parsed = json.loads(body)
        prompt = parsed.get("prompt")
        if isinstance(prompt, list):
            if prompt and isinstance(prompt[0], list):
                prompt_tokens = len(prompt[0])
            else:
                prompt_tokens = len(prompt)
        elif isinstance(prompt, str):
            # Token arrays are used by the artifact.  This conservative
            # approximation keeps the production interface useful for text
            # clients without invoking a tokenizer in the gateway hot path.
            prompt_tokens = max(1, len(prompt) // 4)
        else:
            prompt_tokens = None
        request_metadata = {
            "prompt_tokens": prompt_tokens,
            "max_output_tokens": parsed.get("max_tokens"),
            "cache_prefix_tokens": parsed.get("cache_prefix_tokens", 0),
            "request_source": request_source,
        }
    except (json.JSONDecodeError, AttributeError, TypeError):
        pass
    headers = {
        key: value for key, value in request.headers.items()
        if key.lower() not in {"host", "content-length", "connection", "x-flexbid-class"}
    }
    started = time.perf_counter()
    upstream_request = state.client.build_request(
        request.method, f"{UPSTREAMS[index]}/v1/{path}", content=body,
        headers=headers, params=request.query_params,
    )
    try:
        response = await state.client.send(upstream_request, stream=True)
    except BaseException:
        await state.finish(index, request_class, {"error": "connect"})
        await gate.release()
        raise
    content_type = response.headers.get("content-type", "")
    if "text/event-stream" not in content_type:
        payload = await response.aread()
        await response.aclose()
        await state.finish(index, request_class, {
            "status": response.status_code,
            "e2e_ms": (time.perf_counter() - started) * 1000,
            **request_metadata,
        })
        await gate.release()
        return Response(payload, status_code=response.status_code,
                        media_type=content_type or "application/octet-stream")

    async def stream():
        first = None
        previous = None
        gaps = []
        try:
            async for chunk in response.aiter_bytes():
                now = time.perf_counter()
                if first is None:
                    first = now
                if previous is not None:
                    gaps.append((now - previous) * 1000)
                previous = now
                yield chunk
        finally:
            await response.aclose()
            await state.finish(index, request_class, {
                "status": response.status_code,
                "ttft_ms": None if first is None else (first - started) * 1000,
                "mean_gap_ms": sum(gaps) / len(gaps) if gaps else None,
                "e2e_ms": (time.perf_counter() - started) * 1000,
                **request_metadata,
            })
            await gate.release()

    return StreamingResponse(stream(), status_code=response.status_code,
                             media_type=content_type)
