from __future__ import annotations

import math
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class RecoveryDecision:
    batch_concurrency: int
    reason: str
    backlog_tokens: float
    required_surplus_tps: float
    observed_surplus_tps: float
    recent_tpot_max_ms: float | None
    recent_ttft_max_ms: float | None
    cooldown_remaining_s: float

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class AdaptiveRecoveryController:
    baseline_batch_tps: float
    initial_backlog_tokens: float
    deadline_s: float
    base_concurrency: int = 4
    boost_concurrency: int = 6
    tpot_guard_ms: float = 80.0
    ttft_guard_ms: float = 4000.0
    cooldown_s: float = 30.0
    safety_factor: float = 1.05
    cooldown_until_s: float = 0.0

    def decide(
        self,
        *,
        elapsed_s: float,
        recovered_tokens: float,
        recent_online_metrics: list[dict],
    ) -> RecoveryDecision:
        backlog = max(0.0, self.initial_backlog_tokens - recovered_tokens)
        remaining_s = max(0.0, self.deadline_s - elapsed_s)
        required_surplus = (
            math.inf if remaining_s <= 0 and backlog > 0
            else 0.0 if backlog <= 0
            else backlog / remaining_s
        )
        observed_surplus = (
            recovered_tokens / elapsed_s if elapsed_s > 0 else 0.0
        )
        tpots = [
            float(row["mean_gap_ms"])
            for row in recent_online_metrics
            if row.get("mean_gap_ms") is not None
        ]
        ttfts = [
            float(row["ttft_ms"])
            for row in recent_online_metrics
            if row.get("ttft_ms") is not None
        ]
        max_tpot = max(tpots, default=None)
        max_ttft = max(ttfts, default=None)
        breached = (
            (max_tpot is not None and max_tpot > self.tpot_guard_ms)
            or (max_ttft is not None and max_ttft > self.ttft_guard_ms)
        )
        if breached:
            self.cooldown_until_s = max(
                self.cooldown_until_s, elapsed_s + self.cooldown_s
            )
        cooldown_remaining = max(0.0, self.cooldown_until_s - elapsed_s)
        if backlog <= 0:
            concurrency = self.base_concurrency
            reason = "backlog cleared"
        elif cooldown_remaining > 0:
            concurrency = self.base_concurrency
            reason = "online tail guard cooldown"
        elif observed_surplus + 1e-9 < required_surplus * self.safety_factor:
            concurrency = self.boost_concurrency
            reason = "deadline catch-up boost"
        else:
            concurrency = self.base_concurrency
            reason = "catch-up on schedule"
        return RecoveryDecision(
            batch_concurrency=concurrency,
            reason=reason,
            backlog_tokens=backlog,
            required_surplus_tps=required_surplus,
            observed_surplus_tps=observed_surplus,
            recent_tpot_max_ms=max_tpot,
            recent_ttft_max_ms=max_ttft,
            cooldown_remaining_s=cooldown_remaining,
        )
