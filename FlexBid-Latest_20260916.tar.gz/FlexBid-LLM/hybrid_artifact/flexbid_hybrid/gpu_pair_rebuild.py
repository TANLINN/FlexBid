"""Offline, provenance-checked conversion of historical paired GPU targets.

This does not validate a new host, change runtime policy, or authorize a bid.
All rows survive conversion or the entire conversion fails.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

from .analysis import clipped_samples, integrate_j, percentile
from .modeling import HybridSurrogate, PairedHybridSurrogate, TARGETS

BOUNDARY = "gpu_nvml"
PROFILE_CAMPAIGN = "hybrid_formal_profile_a800_qwen35_27b_20260821_v2"
ABLATION_CAMPAIGN = "hybrid_formal_ablation_a800_qwen35_27b_20260822"
# The original build_dataset merged these two directories before attaching its
# references. This is a narrow reconstruction of that historical relationship,
# NOT a general nearest-value/cross-campaign fallback or proof of stationarity.
PROFILE_REFERENCED_ABLATIONS = {
    "hybrid_full_cap300": (4, 4, 300.0),
    "pause_r2_cap400": (2, 0, 400.0),
}
BASE_FIELDS = {
    "baseline_power_w": "power_mean_w",
    "baseline_ttft_ms": "ttft_p95_ms",
    "baseline_tpot_ms": "tpot_p99_ms",
    "baseline_batch_tps": "batch_tokens_per_s",
}
MATCH_FIELDS = (
    "duration_s", "power_mean_w", "gpu_power_mean_w", "energy_j", "gpu_energy_j",
    "online_requests", "online_errors", "online_load_shed", "ttft_p95_ms",
    "tpot_p99_ms", "batch_jobs_completed", "batch_tokens_completed", "batch_tokens_per_s",
)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def finite(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("Nonfinite numeric observation")
    return result


def equal(a, b):
    if a in (None, "") or b in (None, ""):
        return a in (None, "") and b in (None, "")
    return math.isclose(finite(a), finite(b), rel_tol=1e-8, abs_tol=1e-5)


def read_rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def read_jsonl(path):
    with path.open(encoding="utf-8") as stream:
        return [json.loads(line) for line in stream if line.strip()]


def inspect_cell(run_dir, max_gap_s=2.0, gpu_count=8):
    """Recompute the original window, requiring readable per-device evidence."""
    run_dir = Path(run_dir).resolve()
    names = ("cell.json", "CELL_COMPLETE.json", "components.csv", "online.jsonl", "batch.jsonl")
    if (run_dir / "CELL_FAILED.json").exists():
        raise ValueError(f"Conflicting failure marker: {run_dir}")
    hashes = {name: digest(run_dir / name) for name in names}
    cell = json.loads((run_dir / "cell.json").read_text(encoding="utf-8"))
    start, end = int(cell["measurement_start_wall_ns"]), int(cell["measurement_end_wall_ns"])
    if end <= start or not math.isfinite(max_gap_s) or max_gap_s <= 0:
        raise ValueError("Invalid window or telemetry gap limit")
    telemetry = read_rows(run_dir / "components.csv")
    stamps = [int(row["wall_time_ns"]) for row in telemetry]
    if len(stamps) < 2 or any(b <= a for a, b in zip(stamps, stamps[1:])):
        raise ValueError(f"Telemetry timestamps not strictly increasing: {run_dir}")
    if stamps[0] > start or stamps[-1] < end:
        raise ValueError(f"Missing window coverage: {run_dir}")
    lo = max(i for i, t in enumerate(stamps) if t <= start)
    hi = next(i for i, t in enumerate(stamps) if t >= end)
    window = telemetry[lo:hi + 1]
    gaps = [(b - a) / 1e9 for a, b in zip(stamps[lo:hi], stamps[lo + 1:hi + 1])]
    gap = max(gaps)
    if gap > max_gap_s:
        raise ValueError(f"Telemetry gap {gap:.3f}s > {max_gap_s}s: {run_dir}")
    gpu, component = [], []
    expected_columns = {f"gpu{i}_power_w" for i in range(gpu_count)}
    actual_columns = {key for key in window[0] if key.startswith("gpu") and key.endswith("_power_w")}
    if actual_columns != expected_columns:
        raise ValueError(f"Unexpected per-GPU power columns: {run_dir}: {actual_columns}")
    for row in window:
        aggregate = finite(row["aggregate_gpu_power_w"])
        devices = [finite(row[key]) for key in expected_columns]
        power = finite(row["observed_component_power_w"])
        if min(devices) < 0 or power < 0 or not equal(sum(devices), aggregate):
            raise ValueError(f"Invalid aggregate/per-device power: {run_dir}")
        gpu.append((int(row["wall_time_ns"]), aggregate))
        component.append((int(row["wall_time_ns"]), power))
    gpu = clipped_samples(gpu, start, end)
    component = clipped_samples(component, start, end)
    online, batch = read_jsonl(run_dir / "online.jsonl"), read_jsonl(run_dir / "batch.jsonl")
    duration = (end - start) / 1e9
    good_batch = [row for row in batch if row.get("error") is None]
    tokens = sum(int(row.get("completion_tokens") or 0) for row in good_batch)
    result = {
        "duration_s": duration, "power_mean_w": integrate_j(component) / duration,
        "gpu_power_mean_w": integrate_j(gpu) / duration, "energy_j": integrate_j(component),
        "gpu_energy_j": integrate_j(gpu), "gpu_power_peak_w": max(v for _, v in gpu),
        "online_requests": len(online), "online_errors": sum(r.get("error") is not None for r in online),
        "online_load_shed": sum(r.get("status_code") == 429 for r in online),
        "ttft_p95_ms": percentile([finite(r["ttft_ms"]) for r in online if r.get("ttft_ms") is not None], .95),
        "tpot_p99_ms": percentile([finite(r["mean_tpot_ms"]) for r in online if r.get("mean_tpot_ms") is not None], .99),
        "batch_jobs_completed": len(good_batch), "batch_tokens_completed": tokens,
        "batch_tokens_per_s": tokens / duration,
    }
    if hashes != {name: digest(run_dir / name) for name in names}:
        raise ValueError(f"Raw input changed while reading: {run_dir}")
    return dict(cell=cell, metrics=result, path=str(run_dir), hashes=hashes,
                max_gap_s=gap, gpu_count=gpu_count)


def rebuild(rows, campaign_roots, max_gap_s=2.0):
    if not rows:
        raise ValueError("Empty input dataset")
    index = defaultdict(list)
    for root in map(lambda p: Path(p).resolve(), campaign_roots):
        markers = sorted((root / "cells").glob("*/*/CELL_COMPLETE.json"))
        if not markers:
            raise ValueError(f"No completed raw cells: {root}")
        for marker in markers:
            cell = json.loads((marker.parent / "cell.json").read_text(encoding="utf-8"))
            key = (cell["episode"]["episode_id"], cell["action"]["name"])
            index[key].append((root, marker.parent, cell))
    cache, seen, converted, provenance, split_by_episode = {}, set(), [], [], {}

    def inspected(path):
        if path not in cache:
            cache[path] = inspect_cell(path, max_gap_s=max_gap_s)
        return cache[path]

    for position, row in enumerate(rows):
        key = (row["episode_id"], row["name"])
        if key in seen:
            raise ValueError(f"Duplicate dataset episode/action: {key}")
        seen.add(key)
        split = row["data_split"]
        if split not in ("train", "calibration"):
            raise ValueError(f"Unexpected split: {split}")
        if split_by_episode.setdefault(key[0], split) != split:
            raise ValueError(f"Train/calibration overlap: {key[0]}")
        matches, diagnostics = [], []
        for root, path, cell in index.get(key, []):
            if cell["episode"]["source"] != row["source"] or cell["episode"].get("split") != split:
                continue
            if any(not equal(cell["action"][f], row[f]) for f in
                   ("online_replicas", "batch_concurrency", "power_cap_w")):
                continue
            raw = inspected(path)
            mismatched = [f for f in MATCH_FIELDS if f not in row or not equal(row[f], raw["metrics"][f])]
            diagnostics.append({"path": str(path), "mismatched": mismatched})
            if not mismatched:
                matches.append((root, raw))
        if len(matches) != 1:
            raise ValueError(f"Need one exact raw action match for {key}, found {len(matches)}: {diagnostics}")
        root, raw = matches[0]
        bases = [(p, c) for r, p, c in index.get((key[0], "hybrid_full"), []) if r == root]
        reference_campaign = root
        pairing_kind = "same_campaign_reference"
        expected_action = PROFILE_REFERENCED_ABLATIONS.get(key[1])
        if not bases and root.name == ABLATION_CAMPAIGN and expected_action is not None:
            if any(not equal(row[f], value) for f, value in zip(
                    ("online_replicas", "batch_concurrency", "power_cap_w"), expected_action)):
                raise ValueError(f"Unexpected historical ablation tuple: {key}")
            reference_campaign = root.parent / PROFILE_CAMPAIGN
            bases = [(p, c) for r, p, c in index.get((key[0], "hybrid_full"), [])
                     if r == reference_campaign]
            pairing_kind = "cross_campaign_profile_reference"
        if len(bases) != 1:
            raise ValueError(f"Need one same-campaign baseline or explicitly linked profile reference "
                             f"for {key} in {reference_campaign}; found {len(bases)}")
        base_path, base_cell = bases[0]
        if base_cell["episode"] != raw["cell"]["episode"]:
            raise ValueError(f"Action/baseline episode metadata differ: {key}")
        if any(not equal(base_cell["action"][f], value) for f, value in
               (("online_replicas", 4), ("batch_concurrency", 4), ("power_cap_w", 400))):
            raise ValueError(f"Unexpected historical baseline action: {base_path}")
        base = inspected(base_path)
        for base_field, target in BASE_FIELDS.items():
            if base_field not in row or not equal(row[base_field], base["metrics"][target]):
                raise ValueError(f"Saved row-local {base_field} mismatches original reference: {key}")
        if not equal(raw["metrics"]["duration_s"], base["metrics"]["duration_s"]):
            raise ValueError(f"Paired durations differ: {key}")
        item = dict(row)
        for field in ("power_mean_w", "energy_j", "power_peak_w", "baseline_power_w"):
            item["legacy_component_" + field] = row[field]
        item.update(power_mean_w=raw["metrics"]["gpu_power_mean_w"],
                    energy_j=raw["metrics"]["gpu_energy_j"], power_peak_w=raw["metrics"]["gpu_power_peak_w"],
                    baseline_power_w=base["metrics"]["gpu_power_mean_w"], power_boundary=BOUNDARY,
                    pairing_verified="true", raw_action_dir=raw["path"], raw_baseline_dir=base["path"],
                    acquisition_campaign=str(root), reference_campaign=str(reference_campaign),
                    pairing_kind=pairing_kind, cross_campaign_drift_ruled_out="false",
                    provenance_row=position)
        converted.append(item)
        provenance.append(dict(row=position, episode_id=key[0], name=key[1], split=split,
                               campaign=str(root), reference_campaign=str(reference_campaign),
                               pairing_kind=pairing_kind, cross_campaign_drift_ruled_out=False,
                               action=raw, baseline=base))
    return converted, provenance


class HistoricalGpuPairedSurrogate(PairedHybridSurrogate):
    """Separate artifact: preserve server model hotfixes, use verified row-local pairs."""
    power_boundary = BOUNDARY
    target_environment_validated = False
    deployment_evidence = None

    @staticmethod
    def _paired_rows(rows):
        result = []
        for row in rows:
            if row.get("power_boundary") != BOUNDARY or str(row.get("pairing_verified")).lower() != "true":
                raise ValueError("Only provenance-verified GPU rows may be fitted")
            item = dict(row)
            for base_field, target in BASE_FIELDS.items():
                base, actual = finite(row[base_field]), finite(row[target])
                item[target] = base - actual if target == "power_mean_w" else actual - base
                if row["name"] == "hybrid_full" and not equal(base, actual):
                    raise ValueError("Baseline row is not self-paired")
            result.append(item)
        return result

    def report(self, train_rows, calibration_rows):
        # Base-class report predicts directly from each row, unlike old paired
        # report implementations which rejoin globally by episode ID.
        report = HybridSurrogate.report(self, train_rows, calibration_rows)
        report.update(power_boundary=BOUNDARY, pairing="verified_original_row_local_reference",
                      pairing_counts=dict(Counter(r["pairing_kind"] for r in train_rows + calibration_rows)),
                      cross_campaign_drift_ruled_out=False,
                      evidence_scope="historical_development_only", target_environment_validated=False,
                      deployment_evidence=None)
        return report


def inventory(rows):
    return dict(rows=len(rows), episodes=len({r["episode_id"] for r in rows}),
                splits=dict(Counter(r["data_split"] for r in rows)),
                actions=dict(Counter(r["name"] for r in rows)))
