"""Frontier search engine for the supervised rolling-horizon controller."""

from __future__ import annotations

from dataclasses import replace
import math
import time

from .continuation import ContinuationRejected, GuardedViabilityMPC
from .mpc import MPCPlan, PlanStep
from .recovery_frontier import (
    ActionEffect,
    ObservationNode,
    TransitionState,
    solve_frontier,
)


class FrontierGuardedViabilityMPC(GuardedViabilityMPC):
    """Use a continuous-work frontier, then retain the existing validator."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._frontier_state = None
        self._frontier_envelopes = ()
        self.last_search_diagnostics = None

    def envelopes(self, state):
        values = tuple(super().envelopes(state))
        self._frontier_state = state
        self._frontier_envelopes = values
        return list(values)

    def _build_chain(self, state, envelopes):
        period = self.parameters.control_period_s
        aligned = [state.event_remaining_s, state.settlement_elapsed_s]
        if state.contract is not None:
            aligned.append(state.contract.settlement_interval_s)
        if any(abs(value / period - round(value / period)) > 1e-7 for value in aligned):
            raise ValueError(
                "frontier controller requires control-aligned event and settlement boundaries"
            )
        windows = self._durations(state)
        if not windows:
            raise ValueError("frontier controller has no remaining planning horizon")

        root = None
        for index in reversed(range(len(windows))):
            window = windows[index]
            reference = (
                state.contract.reference_at(window.event_elapsed_s)
                if state.contract is not None else math.inf
            )
            if not math.isfinite(reference):
                references = [
                    item.power_upper_w + item.guaranteed_reduction_w
                    for item in envelopes if item.slo_safe
                ]
                if not references or max(references) - min(references) > 1e-6:
                    raise ValueError("action envelopes do not share a power reference")
                reference = references[0]
            limit = math.inf
            if window.stage == "recovery" and state.contract is not None:
                limit = state.contract.recovery_envelope_at(window.recovery_elapsed_s)
                rebound_reference = state.contract.reference_at(
                    state.contract.event_s + window.recovery_elapsed_s
                )
                if (
                    math.isfinite(rebound_reference)
                    and math.isfinite(state.contract.rebound_limit_w)
                ):
                    limit = min(
                        limit,
                        rebound_reference + state.contract.rebound_limit_w,
                    )
            effects = tuple(
                ActionEffect(
                    item.action.name,
                    item.action.resolved_online_replica_ids(),
                    item.batch_tps_lower * window.duration_s,
                    item.power_upper_w,
                    item.slo_safe,
                )
                for item in envelopes
                if all(math.isfinite(value) and value >= 0 for value in (
                    item.batch_tps_lower, item.power_upper_w,
                ))
            )
            root = ObservationNode(
                str(index),
                "current_envelope_bounds",
                window.duration_s,
                effects,
                () if root is None else (root,),
                stage=window.stage,
                settlement_end=window.closes_settlement,
                reference_power_w=reference,
                power_limit_w=limit,
            )

        current = next(
            item for item in envelopes if item.action.name == state.current_action
        )
        previous_power = state.previous_power_w
        if previous_power is None:
            previous_power = current.power_upper_w
        initial = TransitionState(
            state.current_action,
            current.action.resolved_online_replica_ids(),
            state.replica_dwell_remaining_s,
            previous_power,
            state.settlement_delivered_ws,
        )
        return root, initial, windows

    def _bid_levels(self, state, envelopes, windows):
        if state.committed_bid_w is not None:
            return [float(state.committed_bid_w)]
        if state.event_remaining_s <= 0:
            return [0.0]
        return sorted({
            max(0.0, min(
                (
                    state.contract.reference_at(window.event_elapsed_s)
                    - item.power_upper_w
                    if state.contract is not None and math.isfinite(
                        state.contract.reference_at(window.event_elapsed_s)
                    )
                    else item.guaranteed_reduction_w
                )
                for window in windows if window.stage == "event"
            ))
            for item in envelopes if item.slo_safe
        }, reverse=True)

    def _search(self, state):
        started = time.perf_counter()
        if self._frontier_state != state:
            envelopes = tuple(super().envelopes(state))
        else:
            envelopes = self._frontier_envelopes
        safe = [item for item in envelopes if item.slo_safe]
        if not safe:
            self.last_search_diagnostics = {
                "status": "NO_SLO_SAFE_ENVELOPES", "trials": [],
            }
            return self._fallback(
                state, safe, started,
                "baseline prediction is unsafe or no SLO-safe action exists",
            )

        root, initial, windows = self._build_chain(state, envelopes)
        actions = {item.action.name: item.action for item in envelopes}
        trials = []
        accepted = None
        for bid in self._bid_levels(state, envelopes, windows):
            remaining = self.parameters.solve_budget_s - (
                time.perf_counter() - started
            )
            if remaining <= 0:
                trials.append({
                    "bid_w": bid,
                    "status": "UNKNOWN",
                    "reason": "total frontier budget exhausted",
                })
                break
            adjusted = replace(
                initial,
                settlement_balance_ws=(
                    state.settlement_delivered_ws
                    - bid * state.settlement_elapsed_s
                ),
            )
            result = solve_frontier(
                root,
                adjusted,
                bid,
                min_replica_dwell_s=self.parameters.replica_min_dwell_s,
                ramp_limit_w_per_s=(
                    state.contract.ramp_limit_w_per_s
                    if state.contract is not None else math.inf
                ),
                solve_budget_s=remaining,
            )
            trial = {
                "bid_w": bid,
                "status": result.status,
                "capacity_tokens": result.max_work_tokens,
                "kernel_ms": result.solve_time_s * 1000.0,
                "states": result.states_evaluated,
                "reason": result.reason,
            }
            trials.append(trial)
            if result.status == "UNKNOWN":
                break
            if (
                result.status != "FEASIBLE"
                or state.cohort_tokens > result.max_work_tokens + 1e-7
            ):
                continue
            policy = result.policy
            steps = []
            for index, window in enumerate(windows):
                steps.append(PlanStep(
                    index,
                    window.stage,
                    window.duration_s,
                    actions[policy.action.action_id],
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                ))
                policy = policy.children[0] if policy.children else None
            try:
                checked = self.validate_schedule(
                    state, steps, envelopes, bid_w=bid,
                )
            except ContinuationRejected as exc:
                trial["validator"] = str(exc)
                continue
            trial["validator"] = "PASS"
            accepted = (bid, checked, result)
            break

        self.last_search_diagnostics = {
            "status": "MODEL_VALIDATED_PLAN" if accepted else (
                "UNKNOWN" if any(item["status"] == "UNKNOWN" for item in trials)
                else "NO_VALIDATED_PLAN_FOUND"
            ),
            "trials": trials,
        }
        if accepted is None:
            reason = (
                "frontier budget exhausted; returning safe service fallback"
                if any(item["status"] == "UNKNOWN" for item in trials)
                else "frontier found no model-validated event and recovery policy"
            )
            return self._fallback(state, safe, started, reason)

        bid, checked, result = accepted
        return MPCPlan(
            feasible=True,
            committed_bid_w=bid,
            objective=result.max_work_tokens,
            steps=checked,
            terminal_backlog_tokens=checked[-1].backlog_after_tokens,
            solve_time_ms=(time.perf_counter() - started) * 1000.0,
            evaluated_actions=len(self.actions),
            pareto_actions=len(envelopes),
            reason="highest model-validated frontier bid for the current envelopes",
            terminal_cohort_tokens=checked[-1].cohort_after_tokens,
        )
