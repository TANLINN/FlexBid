"""Production-facing feedback loop for the viability MPC controller."""

from __future__ import annotations

import json
import math
import time
from collections import deque
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from statistics import mean
from typing import Callable, Iterable

from .contracts import FlexibilityContract
from .io import atomic_json
from .mpc import ControlState, MPCPlan, ViabilityMPC
from .pilot import apply_control
from .power import PowerCapManager
from .service import get_json
from .types import HybridAction
from .trajectory_calibration import FrozenPolicyCalibrator


@dataclass(frozen=True)
class RuntimeObservation:
    wall_time_ns: int
    elapsed_s: float
    event_remaining_s: float
    deadline_remaining_s: float
    backlog_tokens: float
    completed_online: int
    completed_batch: int
    observed_component_power_w: float | None
    workload_features: dict[str, float]
    cohort_remaining_tokens: float = 0.0
    dr_debt_tokens: float = 0.0


class OnlineFeatureEstimator:
    """Build the surrogate's workload features from a rolling gateway window."""

    def __init__(
        self, source: str, window_s: float = 60.0,
        projection_s: float | None = None,
    ):
        if window_s <= 0:
            raise ValueError("window_s must be positive")
        self.source = source
        self.window_s = window_s
        self.projection_s = window_s if projection_s is None else projection_s
        if self.projection_s <= 0:
            raise ValueError("projection_s must be positive")
        self.rows: deque[dict] = deque()
        self.last_sequence = 0
        self.latest_rows: list[dict] = []

    def update(self, state: dict, now_ns: int | None = None) -> dict[str, float]:
        now_ns = time.time_ns() if now_ns is None else now_ns
        self.latest_rows = []
        for row in state.get("recent_online_metrics", []):
            sequence = int(row.get("sequence", 0))
            if sequence <= self.last_sequence:
                continue
            self.rows.append(dict(row))
            self.latest_rows.append(dict(row))
            self.last_sequence = max(self.last_sequence, sequence)
        cutoff = now_ns - int(self.window_s * 1e9)
        while self.rows and int(self.rows[0].get("completed_wall_time_ns", 0)) < cutoff:
            self.rows.popleft()
        prompts = [
            float(row["prompt_tokens"]) for row in self.rows
            if row.get("prompt_tokens") is not None
        ]
        outputs = [
            float(row["max_output_tokens"]) for row in self.rows
            if row.get("max_output_tokens") is not None
        ]
        prefixes = [
            float(row.get("cache_prefix_tokens") or 0.0) for row in self.rows
        ]
        count = len(self.rows)
        prompt_sum = sum(prompts)
        scale = self.projection_s / self.window_s
        source_counts: dict[str, int] = {}
        for row in self.rows:
            value = str(row.get("request_source") or "unknown")
            source_counts[value] = source_counts.get(value, 0) + 1

        def source_fraction(name: str) -> float:
            known = sum(
                source_counts.get(value, 0) for value in (
                    "azure_code", "azure_conversation",
                    "qwen_bailian", "tracelab",
                )
            )
            if known:
                return source_counts.get(name, 0) / known
            return float(self.source == name)

        return {
            "source_azure_code": source_fraction("azure_code"),
            "source_azure_conversation": source_fraction("azure_conversation"),
            "source_qwen_bailian": source_fraction("qwen_bailian"),
            "source_tracelab": source_fraction("tracelab"),
            "online_arrivals": float(count) * scale,
            "online_arrival_rate_rps": count / self.window_s,
            "prompt_tokens_sum": prompt_sum * scale,
            "prompt_tokens_mean": mean(prompts) if prompts else 0.0,
            "prompt_tokens_max": max(prompts, default=0.0),
            "output_tokens_sum": sum(outputs) * scale,
            "output_tokens_mean": mean(outputs) if outputs else 0.0,
            "cache_prefix_fraction": (
                0.0 if prompt_sum <= 0 else sum(prefixes) / prompt_sum
            ),
        }


def read_component_power_w(gpu_indices: Iterable[int]) -> float | None:
    """Best-effort instantaneous GPU power for feedback and audit logging."""

    try:
        import pynvml

        pynvml.nvmlInit()
        try:
            values = []
            for index in gpu_indices:
                handle = pynvml.nvmlDeviceGetHandleByIndex(int(index))
                values.append(pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0)
            return sum(values)
        finally:
            pynvml.nvmlShutdown()
    except Exception:
        return None


def _tail_values(
    observations: Iterable[tuple[int, float]], cutoff_wall_ns: int,
) -> list[float]:
    return [
        value for observed_ns, value in observations
        if observed_ns >= cutoff_wall_ns
    ]


class DynamicControlLoop:
    """Attach to a live gateway, re-plan, actuate once, and repeat."""

    def __init__(
        self,
        *,
        optimizer: ViabilityMPC,
        actions: Iterable[HybridAction],
        source: str,
        gateway_url: str,
        control_file: Path,
        gpu_indices: Iterable[int],
        replica_count: int,
        online_concurrency: int,
        event_s: float,
        deadline_s: float,
        baseline_batch_tps: float,
        batch_output_tokens: int,
        ttft_slo_ms: float,
        tpot_slo_ms: float,
        log_path: Path,
        state_path: Path,
        feature_window_s: float = 60.0,
        feature_projection_s: float | None = None,
        warmup_s: float = 0.0,
        minimum_warmup_online_samples: int = 1,
        baseline_sample_s: float | None = None,
        baseline_tail_s: float | None = None,
        bid_quantum_w: float = 10.0,
        bid_derating: float = 0.95,
        contract: FlexibilityContract | None = None,
        initial_cohort_tokens: float | None = None,
        offer_calibrator: FrozenPolicyCalibrator | None = None,
        force_baseline: bool = False,
        offer_lead_s: float = 30.0,
        activation_wall_ns: int | None = None,
        meter_sample_s: float = 0.2,
        meter_max_gap_s: float = 1.0,
        dry_run: bool = False,
        state_reader: Callable[[str], dict] = get_json,
    ):
        if event_s <= 0 or deadline_s <= event_s:
            raise ValueError("deadline_s must be greater than positive event_s")
        if baseline_batch_tps <= 0:
            raise ValueError("baseline_batch_tps must be positive")
        if batch_output_tokens <= 0:
            raise ValueError("batch_output_tokens must be positive")
        self.optimizer = optimizer
        self.actions = {action.name: action for action in actions}
        self.source = source
        self.gateway_url = gateway_url.rstrip("/")
        self.control_file = control_file
        self.gpu_indices = list(gpu_indices)
        self.replica_count = replica_count
        self.online_concurrency = online_concurrency
        self.event_s = event_s
        self.deadline_s = deadline_s
        self.baseline_batch_tps = baseline_batch_tps
        self.batch_output_tokens = batch_output_tokens
        self.ttft_slo_ms = ttft_slo_ms
        self.tpot_slo_ms = tpot_slo_ms
        self.log_path = log_path
        self.state_path = state_path
        self.bid_quantum_w = bid_quantum_w
        self.bid_derating = bid_derating
        self.contract = contract or FlexibilityContract(
            event_s=event_s,
            deadline_s=deadline_s,
            settlement_interval_s=optimizer.parameters.control_period_s,
        )
        if (
            abs(self.contract.event_s - event_s) > 1e-9
            or abs(self.contract.deadline_s - deadline_s) > 1e-9
        ):
            raise ValueError("contract horizon must match runtime horizon")
        self.initial_cohort_tokens = (
            float(initial_cohort_tokens)
            if initial_cohort_tokens is not None
            else baseline_batch_tps * deadline_s
        )
        if self.initial_cohort_tokens < 0:
            raise ValueError("initial_cohort_tokens cannot be negative")
        self.offer_calibrator = offer_calibrator
        self.force_baseline = bool(force_baseline)
        self.offer_accepted: bool | None = None
        self.last_offer_calibration: dict | None = None
        self.warmup_s = warmup_s
        if self.warmup_s < 0:
            raise ValueError("warmup_s cannot be negative")
        self.minimum_warmup_online_samples = int(
            minimum_warmup_online_samples
        )
        if self.minimum_warmup_online_samples < 1:
            raise ValueError("minimum_warmup_online_samples must be positive")
        self.baseline_sample_s = (
            optimizer.parameters.control_period_s
            if baseline_sample_s is None else float(baseline_sample_s)
        )
        self.baseline_tail_s = (
            self.warmup_s if baseline_tail_s is None else float(baseline_tail_s)
        )
        if not math.isfinite(self.baseline_sample_s) or self.baseline_sample_s <= 0:
            raise ValueError("baseline_sample_s must be finite and positive")
        if (
            not math.isfinite(self.baseline_tail_s)
            or self.baseline_tail_s < 0
            or self.baseline_tail_s > self.warmup_s
            or (self.warmup_s > 0 and self.baseline_tail_s == 0)
        ):
            raise ValueError("baseline_tail_s must be within the warmup")
        self.baseline_reference_metadata: dict | None = None
        # FIXED_EVENT_CLOCK_V1
        if not math.isfinite(offer_lead_s) or offer_lead_s <= 0:
            raise ValueError('offer_lead_s must be finite and positive')
        self.offer_lead_s = offer_lead_s
        self.activation_wall_ns = activation_wall_ns
        self.meter_sample_s = meter_sample_s
        self.meter_max_gap_s = meter_max_gap_s
        self.event_session = None
        self.dry_run = dry_run
        self.state_reader = state_reader
        self.features = OnlineFeatureEstimator(
            source, feature_window_s, feature_projection_s
        )
        self.committed_bid_w: float | None = None
        self.current_action = optimizer.baseline_action
        self.previous_features: dict[str, float] | None = None
        self.previous_elapsed_s = 0.0
        self.previous_completed_batch = 0
        self.last_replica_change_s = -math.inf

    def _predicted_slacks(
        self, plan: MPCPlan, state: ControlState,
    ) -> dict[str, float]:
        slacks = {
            "ttft_ms": min(
                (state.ttft_slo_ms - step.ttft_upper_ms for step in plan.steps),
                default=-math.inf,
            ),
            "tpot_ms": min(
                (state.tpot_slo_ms - step.tpot_upper_ms for step in plan.steps),
                default=-math.inf,
            ),
            "terminal_debt_tokens": (
                self.optimizer.parameters.terminal_tolerance_tokens
                - plan.terminal_backlog_tokens
            ),
            "terminal_cohort_tokens": (
                self.optimizer.parameters.terminal_cohort_tolerance_tokens
                - plan.terminal_cohort_tokens
            ),
        }
        contract = state.contract
        if contract is not None:
            previous_power = state.previous_power_w
            envelope_slacks = []
            ramp_slacks = []
            for step in plan.steps:
                if step.stage == "recovery":
                    # Plan steps are ordered, so elapsed recovery can be
                    # reconstructed without observing future information.
                    recovery_elapsed = sum(
                        value.duration_s for value in plan.steps[:step.index]
                        if value.stage == "recovery"
                    )
                    limit = contract.recovery_envelope_at(recovery_elapsed)
                    reference = contract.reference_at(
                        contract.event_s + recovery_elapsed
                    )
                    if math.isfinite(reference) and math.isfinite(contract.rebound_limit_w):
                        limit = min(limit, reference + contract.rebound_limit_w)
                    if math.isfinite(limit):
                        envelope_slacks.append(
                            limit - step.predicted_power_upper_w
                        )
                if previous_power is not None and math.isfinite(contract.ramp_limit_w_per_s):
                    actual_ramp = abs(
                        step.predicted_power_upper_w - previous_power
                    ) / step.duration_s
                    ramp_slacks.append(
                        contract.ramp_limit_w_per_s - actual_ramp
                    )
                previous_power = step.predicted_power_upper_w
            slacks["recovery_envelope_w"] = min(
                envelope_slacks, default=math.inf,
            )
            slacks["ramp_w_per_s"] = min(ramp_slacks, default=math.inf)
        return slacks

    def _commit(self, plan: MPCPlan, state: ControlState) -> float:
        if self.force_baseline:
            self.committed_bid_w = 0.0
            self.offer_accepted = False
            self.last_offer_calibration = {
                "accepted": False, "raw_bid_w": 0.0, "calibrated_bid_w": 0.0,
                "reason": "forced matched-baseline trajectory",
            }
            return 0.0
        if self.committed_bid_w is None:
            raw = max(0.0, plan.committed_bid_w)
            if self.offer_calibrator is not None:
                calibrated = self.offer_calibrator.calibrate(
                    raw, self._predicted_slacks(plan, state),
                )
                raw = calibrated.calibrated_bid_w
                self.offer_accepted = calibrated.accepted
                self.last_offer_calibration = asdict(calibrated)
            else:
                raw *= self.bid_derating
                self.offer_accepted = raw > 0
            self.committed_bid_w = (
                math.floor(raw / self.bid_quantum_w) * self.bid_quantum_w
                if self.bid_quantum_w > 0 else raw
            )
        return self.committed_bid_w

    def _actuate(
        self, action: HybridAction, power: PowerCapManager | None
    ) -> dict:
        previous = self.actions.get(self.current_action)
        if self.dry_run:
            if previous and previous.resolved_online_replica_ids() != action.resolved_online_replica_ids():
                self.last_replica_change_s = time.monotonic()
            self.current_action = action.name
            return {"dry_run": True, "action": action.as_dict()}
        caps = None
        if power is not None:
            caps = power.set_all(action.power_cap_w)
        control = apply_control(
            self.control_file,
            action,
            self.replica_count,
            self.online_concurrency,
        )
        self.current_action = action.name
        if previous and previous.resolved_online_replica_ids() != action.resolved_online_replica_ids():
            self.last_replica_change_s = time.monotonic()
        return {"dry_run": False, "control": control, "enforced_caps_w": caps}

    def run(self) -> None:
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        power_manager = None if self.dry_run else PowerCapManager(self.gpu_indices)
        try:
            self._actuate(
                self.actions[self.optimizer.baseline_action], power_manager
            )
            warmup_deadline = time.monotonic() + self.warmup_s
            initial = self.state_reader(self.gateway_url + "/flexbid/state")
            baseline_power_observations: list[tuple[int, float]] = []
            baseline_ttft_observations: list[tuple[int, float]] = []
            baseline_tpot_observations: list[tuple[int, float]] = []
            while time.monotonic() < warmup_deadline:
                now_ns = time.time_ns()
                initial = self.state_reader(self.gateway_url + "/flexbid/state")
                self.features.update(initial, now_ns)
                power_sample = read_component_power_w(self.gpu_indices)
                if power_sample is not None and math.isfinite(power_sample):
                    baseline_power_observations.append((now_ns, power_sample))
                for row in self.features.latest_rows:
                    observed_ns = int(
                        row.get("dispatch_wall_time_ns")
                        or row.get("completed_wall_time_ns")
                        or now_ns
                    )
                    if row.get("ttft_ms") is not None:
                        baseline_ttft_observations.append(
                            (observed_ns, float(row["ttft_ms"]))
                        )
                    if row.get("mean_gap_ms") is not None:
                        baseline_tpot_observations.append(
                            (observed_ns, float(row["mean_gap_ms"]))
                        )
                time.sleep(min(
                    self.baseline_sample_s,
                    max(0.0, warmup_deadline - time.monotonic()),
                ))
            warmup_end_wall_ns = time.time_ns()
            tail_start_wall_ns = warmup_end_wall_ns - int(
                self.baseline_tail_s * 1e9
            )
            baseline_power_samples = _tail_values(
                baseline_power_observations, tail_start_wall_ns
            )
            baseline_ttft_samples = _tail_values(
                baseline_ttft_observations, tail_start_wall_ns
            )
            baseline_tpot_samples = _tail_values(
                baseline_tpot_observations, tail_start_wall_ns
            )
            self.baseline_reference_metadata = {
                "sample_period_s": self.baseline_sample_s,
                "tail_window_s": self.baseline_tail_s,
                "tail_start_wall_ns": tail_start_wall_ns,
                "warmup_end_wall_ns": warmup_end_wall_ns,
                "power_samples": len(baseline_power_samples),
                "ttft_samples": len(baseline_ttft_samples),
                "tpot_samples": len(baseline_tpot_samples),
                "latency_time_basis": (
                    "dispatch_wall_time_ns_with_completion_fallback"
                ),
            }
            paired_base = getattr(
                self.optimizer.model, "base", self.optimizer.model
            )
            paired = bool(getattr(paired_base, "paired_effects", False))

            def upper_tail(values: list[float], probability: float) -> float:
                ordered = sorted(values)
                index = max(
                    0,
                    min(
                        len(ordered) - 1,
                        math.ceil(probability * len(ordered)) - 1,
                    ),
                )
                return ordered[index]

            if paired:
                if not baseline_power_samples:
                    raise RuntimeError(
                        "warm-up produced no readable component-power samples"
                    )
                if (
                    len(baseline_ttft_samples)
                    < self.minimum_warmup_online_samples
                    or len(baseline_tpot_samples)
                    < self.minimum_warmup_online_samples
                ):
                    raise RuntimeError(
                        "warm-up produced insufficient online observations: "
                        f"ttft={len(baseline_ttft_samples)} "
                        f"tpot={len(baseline_tpot_samples)} required="
                        f"{self.minimum_warmup_online_samples}"
                    )
                baseline_power_w = mean(baseline_power_samples)
                baseline_ttft_ms = upper_tail(
                    baseline_ttft_samples, 0.95
                )
                baseline_tpot_ms = upper_tail(
                    baseline_tpot_samples, 0.99
                )
            else:
                baseline_power_w = None
                baseline_ttft_ms = None
                baseline_tpot_ms = None
            from .development_episode import freeze_development_reference
            freeze_development_reference(self, baseline_power_w, baseline_power_samples)
            from .zero_bid_reference import freeze_zero_bid_reference
            freeze_zero_bid_reference(self, baseline_power_w)
            from .event_protocol import prepare_event, next_plan
            protocol = prepare_event(self, initial, baseline_power_w,
                                     baseline_ttft_ms, baseline_tpot_ms)
            started_ns = protocol.activation_wall_ns
            initial = self.state_reader(self.gateway_url + '/flexbid/state')
            initial_batch = int(initial["completed_batch"])
            settlement_elapsed_s = 0.0
            settlement_delivered_ws = 0.0
            settlement_failures: list[dict] = []
            with self.log_path.open("a", encoding="utf-8") as stream:
                while True:
                    elapsed_s, observed_power = protocol.sample_now()
                    iteration_ns = started_ns + int(elapsed_s * 1e9)
                    elapsed_s = max(0.0, (iteration_ns - started_ns) / 1e9)
                    if elapsed_s >= self.deadline_s:
                        break
                    gateway = self.state_reader(
                        self.gateway_url + "/flexbid/state"
                    )
                    completed_batch = max(
                        0, int(gateway["completed_batch"]) - initial_batch
                    )
                    actual_batch_tokens = (
                        completed_batch * self.batch_output_tokens
                    )
                    normal_service_tokens = min(
                        self.initial_cohort_tokens,
                        self.baseline_batch_tps * elapsed_s,
                    )
                    dr_debt = max(
                        0.0, normal_service_tokens - actual_batch_tokens,
                    )
                    cohort_remaining = max(
                        0.0,
                        self.initial_cohort_tokens - actual_batch_tokens,
                    )
                    # ``backlog`` remains an output alias for old analysis code.
                    backlog = dr_debt
                    features = self.features.update(gateway, iteration_ns)
                    # Power and monotonic elapsed sampled together above.
                    update_model = getattr(self.optimizer.model, "update", None)
                    if (
                        update_model is not None
                        and self.previous_features is not None
                        and elapsed_s > self.previous_elapsed_s
                    ):
                        action = self.actions[self.current_action]
                        model_row = {
                            **self.previous_features,
                            "source": self.source,
                            "online_replicas": action.online_replicas,
                            "batch_concurrency": action.batch_concurrency,
                            "power_cap_w": action.power_cap_w,
                            "name": action.name,
                            "baseline_power_w": baseline_power_w,
                            "baseline_ttft_ms": baseline_ttft_ms,
                            "baseline_tpot_ms": baseline_tpot_ms,
                            "baseline_batch_tps": self.baseline_batch_tps,
                        }
                        period_s = elapsed_s - self.previous_elapsed_s
                        batch_tps = (
                            max(0, completed_batch - self.previous_completed_batch)
                            * self.batch_output_tokens / period_s
                        )
                        ttfts = [
                            float(row["ttft_ms"])
                            for row in self.features.latest_rows
                            if row.get("ttft_ms") is not None
                        ]
                        tpots = [
                            float(row["mean_gap_ms"])
                            for row in self.features.latest_rows
                            if row.get("mean_gap_ms") is not None
                        ]
                        update_model(
                            model_row,
                            observed_power_w=observed_power,
                            observed_ttft_ms=max(ttfts, default=None),
                            observed_tpot_ms=max(tpots, default=None),
                            observed_batch_tps=batch_tps,
                        )
                    event_remaining = max(0.0, self.event_s - elapsed_s)
                    settlement = protocol.snapshot(elapsed_s)
                    settlement_elapsed_s = settlement["partial_elapsed_s"]
                    settlement_delivered_ws = settlement["partial_delivered_ws"]
                    settlement_failures = settlement["failures"]
                    state = ControlState(
                        source=self.source,
                        event_remaining_s=event_remaining,
                        deadline_remaining_s=max(0.0, self.deadline_s - elapsed_s),
                        backlog_tokens=backlog,
                        current_action=self.current_action,
                        ttft_slo_ms=self.ttft_slo_ms,
                        tpot_slo_ms=self.tpot_slo_ms,
                        workload_features=features,
                        baseline_power_w=baseline_power_w,
                        baseline_ttft_ms=baseline_ttft_ms,
                        baseline_tpot_ms=baseline_tpot_ms,
                        baseline_batch_tps=self.baseline_batch_tps,
                        committed_bid_w=self.committed_bid_w,
                        replica_dwell_remaining_s=max(
                            0.0,
                            self.optimizer.parameters.replica_min_dwell_s
                            - (time.monotonic() - self.last_replica_change_s),
                        ),
                        cohort_remaining_tokens=cohort_remaining,
                        dr_debt_tokens=dr_debt,
                        contract=self.contract,
                        previous_power_w=observed_power,
                        settlement_elapsed_s=settlement_elapsed_s,
                        settlement_delivered_ws=settlement_delivered_ws,
                    )
                    plan = next_plan(protocol, self, state)
                    first_offer = self.committed_bid_w is None
                    bid = self._commit(plan, state)
                    # Re-solve once with the newly frozen bid so the first
                    # action is guaranteed to satisfy the external commitment.
                    if (
                        first_offer
                        and self.offer_calibrator is None
                        and event_remaining > 0
                    ):
                        state = replace(state, committed_bid_w=bid)
                        plan = self.optimizer.solve(state)
                    if self.force_baseline or (self.offer_calibrator is not None and not self.offer_accepted):
                        action = self.actions[self.optimizer.baseline_action]
                    else:
                        action = plan.first_action
                    actuation = self._actuate(action, power_manager)
                    if protocol.first_actuation_elapsed_s is None:
                        protocol.first_actuation_elapsed_s = protocol.elapsed()
                    observation = RuntimeObservation(
                        iteration_ns,
                        elapsed_s,
                        event_remaining,
                        max(0.0, self.deadline_s - elapsed_s),
                        backlog,
                        int(gateway["completed_online"]),
                        completed_batch,
                        observed_power,
                        features,
                        cohort_remaining,
                        dr_debt,
                    )
                    record = {
                        "event_contract": protocol.metadata(),
                        "settlement_status": settlement,
                        "observation": asdict(observation),
                        "committed_bid_w": bid,
                        "offer_calibration": self.last_offer_calibration,
                        "settlement_failures": settlement_failures,
                        "plan": plan.as_dict(),
                        "solver_diagnostics": getattr(
                            self.optimizer, "last_search_diagnostics", None
                        ),
                        "actuation": actuation,
                        "baseline_reference": {
                            "forced_baseline": self.force_baseline,
                            "power_boundary": "gpu_nvml",
                            "power_mean_w": baseline_power_w,
                            "ttft_p95_ms": baseline_ttft_ms,
                            "tpot_p99_ms": baseline_tpot_ms,
                            "batch_tokens_per_s": self.baseline_batch_tps,
                            "warmup_online_samples": len(
                                baseline_tpot_samples
                            ),
                            "ems_reference_power_w": (
                                None
                                if not math.isfinite(
                                    self.contract.reference_at(elapsed_s)
                                )
                                else self.contract.reference_at(elapsed_s)
                            ),
                        },
                    }
                    stream.write(json.dumps(record, ensure_ascii=False) + "\n")
                    stream.flush()
                    atomic_json(self.state_path, record)
                    self.previous_features = features
                    self.previous_elapsed_s = elapsed_s
                    self.previous_completed_batch = completed_batch
                    remaining = self.optimizer.parameters.control_period_s - (
                        protocol.elapsed() - elapsed_s
                    )
                    if remaining > 0:
                        time.sleep(remaining)
        finally:
            if self.event_session is not None:
                try:
                    self.event_session.close()
                except Exception as exc:
                    # Meter report failure must not skip GPU restoration.
                    print("EVENT_REPORT_FAILED:", repr(exc), flush=True)
            baseline = self.actions[self.optimizer.baseline_action]
            try:
                self._actuate(baseline, power_manager)
            finally:
                if power_manager is not None:
                    power_manager.close()
