"""Hybrid online--batch FlexBid physical-flexibility pilot."""

__version__ = "0.1.0"
