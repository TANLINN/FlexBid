from __future__ import annotations

import csv
import json
import random
import subprocess
import sys
import time
from pathlib import Path

from .adaptive import AdaptiveRecoveryController
from .analysis import summarize_cell, write_csv
from .config import canonical_hash, resolve
from .io import atomic_json, read_jsonl
from .modeling import read_csv
from .pilot import apply_control, select_episodes
from .power import PowerCapManager
from .service import ServiceGroup, get_json, stop_process
from .types import HybridAction


def _marker_valid(run_dir: Path) -> bool:
    try:
        marker = json.loads(
            (run_dir / "CELL_COMPLETE.json").read_text(encoding="utf-8")
        )
        return (
            int(marker["online_return_code"]) == 0
            and int(marker["batch_return_code"]) == 0
            and int(marker["fatal_online_errors"]) == 0
            and int(marker["fatal_batch_errors"]) == 0
            and int(marker["telemetry_rows"]) >= 2
        )
    except (OSError, KeyError, ValueError):
        return False


def _baseline_tps(config: dict) -> dict[str, float]:
    path = resolve(
        Path(__file__).resolve().parents[1], config["paths"]["reference_dataset"]
    )
    rows = read_csv(path)
    values = {}
    for row in rows:
        if str(row.get("name")) == "hybrid_full":
            values[str(row["episode_id"])] = float(row["batch_tokens_per_s"])
    return values


def _run_cell(
    root: Path,
    config: dict,
    services: ServiceGroup,
    episode: dict,
    run_dir: Path,
    baseline_tps: float,
) -> None:
    if _marker_valid(run_dir):
        return
    run_dir.mkdir(parents=True, exist_ok=True)
    services.wait_idle()
    services.reset_caches()
    adaptive = config["adaptive_recovery"]
    base_concurrency = int(adaptive["base_concurrency"])
    boost_concurrency = int(adaptive["boost_concurrency"])
    initial = HybridAction(
        "adaptive_recovery",
        int(adaptive["online_replicas"]),
        boost_concurrency,
        float(adaptive["power_cap_w"]),
    )
    control_file = Path(config["hardware"]["control_file"])
    apply_control(
        control_file,
        initial,
        len(config["model"]["replicas"]),
        int(config["runtime"]["online_concurrency"]),
    )
    gateway = f"http://127.0.0.1:{config['runtime']['gateway_port']}"
    initial_state = get_json(gateway + "/flexbid/state")
    initial_online = int(initial_state["completed_online"])
    initial_batch = int(initial_state["completed_batch"])
    duration = float(config["workloads"]["measurement_s"])
    event_s = float(adaptive["dr_event_s"])
    available_catchup_s = float(adaptive["available_catchup_s"])
    initial_backlog = baseline_tps * event_s
    controller = AdaptiveRecoveryController(
        baseline_batch_tps=baseline_tps,
        initial_backlog_tokens=initial_backlog,
        deadline_s=available_catchup_s,
        base_concurrency=base_concurrency,
        boost_concurrency=boost_concurrency,
        tpot_guard_ms=float(adaptive["tpot_guard_ms_by_source"][episode["source"]]),
        ttft_guard_ms=float(adaptive["ttft_guard_ms_by_source"][episode["source"]]),
        cooldown_s=float(adaptive["cooldown_s"]),
        safety_factor=float(adaptive["safety_factor"]),
    )
    start_wall_ns = time.time_ns() + 3_000_000_000
    end_wall_ns = start_wall_ns + int(duration * 1e9)
    atomic_json(run_dir / "cell.json", {
        "episode": episode,
        "action": initial.as_dict(),
        "control": {
            "mode": "adaptive",
            "base_concurrency": base_concurrency,
            "boost_concurrency": boost_concurrency,
            "batch_output_tokens": int(adaptive["batch_output_tokens"]),
            "baseline_batch_tps": baseline_tps,
            "initial_backlog_tokens": initial_backlog,
        },
        "measurement_start_wall_ns": start_wall_ns,
        "measurement_end_wall_ns": end_wall_ns,
    })
    telemetry = subprocess.Popen([
        sys.executable, "-m", "flexbid_hybrid.telemetry", "--output",
        str(run_dir / "components.csv"), "--interval-ms",
        str(config["hardware"]["telemetry_interval_ms"]),
    ], cwd=root, start_new_session=True)
    model = config["model"]
    api_base = gateway + "/v1"
    online_command = [
        sys.executable, str(root / "scripts/replay_online.py"),
        "--trace", str(episode["path"]), "--output", str(run_dir / "online.jsonl"),
        "--api-base", api_base, "--model", model["name"],
        "--tokenizer", model["tokenizer"], "--arrival-scale",
        str(config["workloads"]["arrival_scale_by_source"].get(episode["source"], 1.0)),
        "--duration-s", str(duration), "--start-wall-ns", str(start_wall_ns),
        "--source", str(episode["source"]),
    ]
    batch_command = [
        sys.executable, str(root / "scripts/run_batch.py"),
        "--output", str(run_dir / "batch.jsonl"), "--api-base", api_base,
        "--model", model["name"], "--tokenizer", model["tokenizer"],
        "--prompt-tokens", str(config["workloads"]["batch_prompt_tokens"]),
        "--output-tokens", str(adaptive["batch_output_tokens"]),
        "--concurrency", str(boost_concurrency), "--duration-s", str(duration),
        "--start-wall-ns", str(start_wall_ns),
    ]
    handles = []
    for name in ("online", "batch"):
        handles.append((run_dir / f"{name}.stdout.log").open("w", encoding="utf-8"))
        handles.append((run_dir / f"{name}.stderr.log").open("w", encoding="utf-8"))
    online = subprocess.Popen(
        online_command, cwd=root, stdout=handles[0], stderr=handles[1],
        start_new_session=True,
    )
    batch = subprocess.Popen(
        batch_command, cwd=root, stdout=handles[2], stderr=handles[3],
        start_new_session=True,
    )
    decisions = (run_dir / "controller.jsonl").open("w", encoding="utf-8")
    last_sequence = initial_online
    current_concurrency = boost_concurrency
    poll_s = float(adaptive["poll_s"])
    try:
        delay = (start_wall_ns - time.time_ns()) / 1e9
        if delay > 0:
            time.sleep(delay)
        while time.time_ns() < end_wall_ns:
            state = get_json(gateway + "/flexbid/state")
            elapsed_s = max(0.0, (time.time_ns() - start_wall_ns) / 1e9)
            completed_batch = max(0, int(state["completed_batch"]) - initial_batch)
            total_batch_tokens = completed_batch * int(adaptive["batch_output_tokens"])
            recovered_tokens = max(0.0, total_batch_tokens - baseline_tps * elapsed_s)
            recent = [
                row for row in state.get("recent_online_metrics", [])
                if int(row.get("sequence", 0)) > last_sequence
            ]
            if recent:
                last_sequence = max(int(row["sequence"]) for row in recent)
            decision = controller.decide(
                elapsed_s=elapsed_s,
                recovered_tokens=recovered_tokens,
                recent_online_metrics=recent,
            )
            if decision.batch_concurrency != current_concurrency:
                dynamic = HybridAction(
                    "adaptive_recovery",
                    int(adaptive["online_replicas"]),
                    decision.batch_concurrency,
                    float(adaptive["power_cap_w"]),
                )
                apply_control(
                    control_file, dynamic, len(config["model"]["replicas"]),
                    int(config["runtime"]["online_concurrency"]),
                )
                current_concurrency = decision.batch_concurrency
            decisions.write(json.dumps({
                "wall_time_ns": time.time_ns(),
                "elapsed_s": elapsed_s,
                "completed_batch_jobs": completed_batch,
                **decision.as_dict(),
            }) + "\n")
            decisions.flush()
            time.sleep(min(poll_s, max(0.0, (end_wall_ns - time.time_ns()) / 1e9)))
    finally:
        decisions.close()
    time.sleep(max(0.5, 2 * config["hardware"]["telemetry_interval_ms"] / 1000))
    stop_process(telemetry)
    online_return = online.wait(timeout=1200)
    batch_return = batch.wait(timeout=120)
    for handle in handles:
        handle.close()
    online_rows = read_jsonl(run_dir / "online.jsonl")
    batch_rows = read_jsonl(run_dir / "batch.jsonl")
    with (run_dir / "components.csv").open(newline="", encoding="utf-8") as stream:
        telemetry_rows = sum(1 for _ in csv.DictReader(stream))
    marker = {
        "online_return_code": online_return,
        "batch_return_code": batch_return,
        "online_requests": len(online_rows),
        "online_errors": sum(row.get("error") is not None for row in online_rows),
        "online_load_shed": sum(row.get("status_code") == 429 for row in online_rows),
        "fatal_online_errors": sum(
            row.get("error") is not None and row.get("status_code") != 429
            for row in online_rows
        ),
        "batch_jobs_completed": sum(row.get("error") is None for row in batch_rows),
        "batch_errors": sum(row.get("error") is not None for row in batch_rows),
        "fatal_batch_errors": sum(row.get("error") is not None for row in batch_rows),
        "batch_tokens_completed": sum(
            int(row.get("completion_tokens") or 0)
            for row in batch_rows if row.get("error") is None
        ),
        "telemetry_rows": telemetry_rows,
    }
    atomic_json(run_dir / "CELL_COMPLETE.json", marker)
    if not _marker_valid(run_dir):
        raise RuntimeError(f"invalid adaptive recovery cell {run_dir}: {marker}")
    services.wait_idle()
    time.sleep(2)


def run_adaptive_recovery(
    root: Path, config_path: Path, config: dict, resume: bool
) -> Path:
    results = resolve(root, config["paths"]["results_root"])
    results.mkdir(parents=True, exist_ok=True)
    episodes = select_episodes(root, config)
    baseline = _baseline_tps(config)
    missing = [row["episode_id"] for row in episodes if row["episode_id"] not in baseline]
    if missing:
        raise RuntimeError(f"reference baseline is missing episodes: {missing}")
    atomic_json(results / "campaign_manifest.json", {
        "config_hash": canonical_hash(config),
        "config": str(config_path.resolve()),
        "episodes": episodes,
        "actions": [{"name": "adaptive_recovery"}],
        "expected_cells": len(episodes),
        "resume": resume,
    })
    gpu_indices = config["hardware"]["gpu_indices"]
    action = HybridAction(
        "adaptive_recovery",
        int(config["adaptive_recovery"]["online_replicas"]),
        int(config["adaptive_recovery"]["boost_concurrency"]),
        float(config["adaptive_recovery"]["power_cap_w"]),
    )
    apply_control(
        Path(config["hardware"]["control_file"]), action,
        len(config["model"]["replicas"]), int(config["runtime"]["online_concurrency"]),
    )
    try:
        with PowerCapManager(gpu_indices) as power, ServiceGroup(
            root, config, results / "service_logs"
        ) as services:
            ordered = list(episodes)
            random.Random(int(config["seed"])).shuffle(ordered)
            for episode in ordered:
                run_dir = (
                    results / "cells" / episode["episode_id"].replace(":", "_")
                    / "adaptive_recovery"
                )
                if resume and _marker_valid(run_dir):
                    continue
                power.set_all(action.power_cap_w)
                _run_cell(root, config, services, episode, run_dir, baseline[episode["episode_id"]])
            atomic_json(results / "GPU_POWER_RESTORED.json", power.restore())
    finally:
        pass
    summaries = [
        summarize_cell(marker.parent, config)
        for marker in sorted((results / "cells").glob("*/*/CELL_COMPLETE.json"))
    ]
    write_csv(results / "cell_summary.csv", summaries)
    atomic_json(results / "ADAPTIVE_RECOVERY_COMPLETE.json", {
        "status": "COMPLETE",
        "expected_cells": len(episodes),
        "completed_cells": len(summaries),
    })
    return results
