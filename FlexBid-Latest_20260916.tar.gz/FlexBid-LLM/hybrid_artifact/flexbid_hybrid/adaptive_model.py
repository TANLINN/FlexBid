"""Conservative online residual adaptation for a calibrated surrogate."""

from __future__ import annotations

from dataclasses import asdict, dataclass

from .modeling import HybridBounds, HybridPrediction


@dataclass
class ResidualMargins:
    power_w: float = 0.0
    ttft_ms: float = 0.0
    tpot_ms: float = 0.0
    batch_tps: float = 0.0
    updates: int = 0


class AdaptiveEnvelopeModel:
    """Wrap split-conformal bounds with non-shrinking live error margins.

    Online feedback is allowed to make the envelope more conservative, never
    narrower than the offline calibrated interval.  This preserves the safety
    role of the frozen calibrator while reacting to workload or hardware drift.
    """

    def __init__(self, base):
        self.base = base
        self.margins = ResidualMargins()

    def supports(self, row: dict) -> bool:
        supports = getattr(self.base, "supports", None)
        return True if supports is None else bool(supports(row))

    def predict(self, row: dict) -> HybridPrediction:
        return self.base.predict(row)

    def bounds(self, row: dict, mode: str) -> HybridBounds:
        value = self.base.bounds(row, mode)
        margins = self.margins
        return HybridBounds(
            power_lower_w=value.power_lower_w - margins.power_w,
            power_upper_w=value.power_upper_w + margins.power_w,
            ttft_upper_ms=value.ttft_upper_ms + margins.ttft_ms,
            tpot_upper_ms=value.tpot_upper_ms + margins.tpot_ms,
            batch_tokens_per_s_lower=max(
                0.0, value.batch_tokens_per_s_lower - margins.batch_tps
            ),
        )

    def update(
        self,
        row: dict,
        *,
        observed_power_w: float | None = None,
        observed_ttft_ms: float | None = None,
        observed_tpot_ms: float | None = None,
        observed_batch_tps: float | None = None,
    ) -> None:
        prediction = self.base.predict(row)
        if observed_power_w is not None:
            self.margins.power_w = max(
                self.margins.power_w,
                abs(observed_power_w - prediction.power_mean_w),
            )
        if observed_ttft_ms is not None:
            self.margins.ttft_ms = max(
                self.margins.ttft_ms,
                max(0.0, observed_ttft_ms - prediction.ttft_p95_ms),
            )
        if observed_tpot_ms is not None:
            self.margins.tpot_ms = max(
                self.margins.tpot_ms,
                max(0.0, observed_tpot_ms - prediction.tpot_p99_ms),
            )
        if observed_batch_tps is not None:
            self.margins.batch_tps = max(
                self.margins.batch_tps,
                max(0.0, prediction.batch_tokens_per_s - observed_batch_tps),
            )
        self.margins.updates += 1

    def snapshot(self) -> dict:
        return asdict(self.margins)

