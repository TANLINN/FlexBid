"""Causal finite-scenario planning for a fixed, divisible batch cohort.

At an observed node one action is shared by every possible next observation.
The maximum finishable work is action service plus the *minimum* continuation
capacity across those observations.  Work and DR debt are not discretized.

The scalar frontier is exact, up to floating-point tolerance, only for this
model: one fixed fluid cohort/deadline; exogenous observed scenarios; action
service capacities, power, SLO feasibility and transitions independent of the
remaining work.  Service may stop when the cohort empties, but the specified
action power still applies.  Nonpreemptive jobs, work-dependent power, hidden
queues and switching/draining dynamics require a richer model.  Supplied bounds
and scenarios are not themselves a physical or statistical guarantee.

Each node starts at an allowed control decision boundary.  A settlement boundary
inside an action hold must not be turned into a new freely selectable action by
splitting nodes; such timing needs an explicitly modeled hold state.
"""

from __future__ import annotations

import math
import time
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class ActionEffect:
    action_id: str
    replica_key: tuple[int, ...]
    service_tokens: float
    power_w: float
    slo_safe: bool = True


@dataclass(frozen=True)
class ObservationNode:
    """An observable information state, not an independently known future path.

    Children become distinguishable only AFTER the current action has run.
    A shared DAG suffix is allowed when it represents a valid information state;
    action history relevant to the modeled transitions remains in TransitionState.
    The caller must not reveal hidden future information through node labels.
    """

    node_id: str
    observable_label: str
    duration_s: float
    actions: tuple[ActionEffect, ...]
    children: tuple[ObservationNode, ...] = ()
    stage: str = "recovery"
    settlement_end: bool = False
    reference_power_w: float = 0.0
    power_limit_w: float = math.inf


@dataclass(frozen=True)
class TransitionState:
    previous_action: str
    previous_replica_key: tuple[int, ...]
    dwell_remaining_s: float = 0.0
    previous_power_w: float | None = None
    # Delivered reduction minus committed reduction in the open interval.
    settlement_balance_ws: float = 0.0


@dataclass(frozen=True)
class WorkPolicyNode:
    node_id: str
    observable_label: str
    action: ActionEffect
    duration_s: float
    remaining_before_tokens: float
    remaining_after_tokens: float
    children: tuple[WorkPolicyNode, ...]

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class PolicyNode:
    node_id: str
    observable_label: str
    action: ActionEffect
    duration_s: float
    max_work_tokens: float
    state_before: TransitionState
    state_after: TransitionState
    children: tuple[PolicyNode, ...]

    def as_dict(self) -> dict:
        return asdict(self)

    def for_work(self, work_tokens: float, *, float_tolerance: float = 1e-9) -> WorkPolicyNode:
        """Instantiate the causal policy without choosing a future branch now."""
        if not math.isfinite(work_tokens) or work_tokens < 0:
            raise ValueError("work_tokens must be finite and nonnegative")
        if not math.isfinite(float_tolerance) or float_tolerance < 0:
            raise ValueError("float_tolerance must be finite and nonnegative")
        if work_tokens > self.max_work_tokens + float_tolerance:
            raise ValueError("work exceeds this policy's recoverable range")
        remaining = max(0.0, work_tokens - self.action.service_tokens)
        return WorkPolicyNode(
            self.node_id, self.observable_label, self.action, self.duration_s,
            work_tokens, remaining,
            tuple(child.for_work(remaining, float_tolerance=float_tolerance)
                  for child in self.children),
        )


@dataclass(frozen=True)
class FrontierResult:
    # FEASIBLE describes a nonempty [0, max_work_tokens] interval, even if max=0.
    status: str
    max_work_tokens: float | None
    policy: PolicyNode | None
    states_evaluated: int
    solve_time_s: float
    reason: str

    def as_dict(self) -> dict:
        return asdict(self)


class _SearchIncomplete(Exception):
    pass


def solve_frontier(
    root: ObservationNode,
    initial: TransitionState,
    bid_w: float = 0.0,
    *,
    min_replica_dwell_s: float = 0.0,
    ramp_limit_w_per_s: float = math.inf,
    solve_budget_s: float = 10.0,
    max_states: int | None = None,
    float_tolerance: float = 1e-9,
) -> FrontierResult:
    """Return the largest causally recoverable fluid cohort for a fixed bid.

    All obligations must hold on every supplied observation branch.  Budget
    exhaustion returns UNKNOWN, not an infeasibility result or a truncated
    purported maximum.  Memoization retains exact Python float values; no
    near-equal states are merged.  Comparisons use the supplied absolute
    tolerance, so integer-scale fixtures are preferable for exact comparisons.
    """
    started = time.perf_counter()
    for name, value in (
        ("bid_w", bid_w), ("min_replica_dwell_s", min_replica_dwell_s),
        ("solve_budget_s", solve_budget_s), ("float_tolerance", float_tolerance),
    ):
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and nonnegative")
    if math.isnan(ramp_limit_w_per_s) or ramp_limit_w_per_s < 0:
        raise ValueError("ramp_limit_w_per_s must be nonnegative")
    if max_states is not None and (not isinstance(max_states, int) or max_states < 0):
        raise ValueError("max_states must be a nonnegative integer or None")
    for name, value in (("dwell_remaining_s", initial.dwell_remaining_s),):
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{name} must be finite and nonnegative")
    if initial.previous_power_w is not None and (
        not math.isfinite(initial.previous_power_w) or initial.previous_power_w < 0
    ):
        raise ValueError("previous_power_w must be finite and nonnegative")
    if not math.isfinite(initial.settlement_balance_ws):
        raise ValueError("settlement_balance_ws must be finite")
    if not isinstance(initial.previous_replica_key, tuple):
        raise ValueError("previous_replica_key must be a tuple")

    deadline = started + solve_budget_s
    evaluated = 0
    eps = float_tolerance

    def check_budget() -> None:
        if time.perf_counter() >= deadline:
            raise _SearchIncomplete("solve time budget exhausted")

    # Validate the information graph, including shared suffixes, once.  Distinct
    # histories are never merged automatically based on similar observations.
    nodes: dict[str, ObservationNode] = {}
    starts: dict[str, float] = {}
    visiting: set[str] = set()
    horizon_ends: list[float] = []

    def validate(node: ObservationNode, start_s: float) -> None:
        check_budget()
        if not node.node_id or not node.observable_label:
            raise ValueError("every node needs an id and an observable label")
        if node.node_id in visiting:
            raise ValueError("observation graph contains a cycle")
        if node.node_id in nodes:
            if nodes[node.node_id] is not node:
                raise ValueError("one node_id refers to different node objects")
            if abs(starts[node.node_id] - start_s) > eps:
                raise ValueError("a shared suffix must occur at the same time")
            return
        nodes[node.node_id], starts[node.node_id] = node, start_s
        visiting.add(node.node_id)
        if not math.isfinite(node.duration_s) or node.duration_s <= 0:
            raise ValueError("node duration must be finite and positive")
        if node.stage not in {"event", "recovery"}:
            raise ValueError("node stage must be event or recovery")
        if not math.isfinite(node.reference_power_w) or node.reference_power_w < 0:
            raise ValueError("reference power must be finite and nonnegative")
        if math.isnan(node.power_limit_w) or node.power_limit_w < 0:
            raise ValueError("node power limit must be nonnegative")
        if node.stage == "recovery" and node.settlement_end:
            raise ValueError("recovery nodes cannot close an event settlement")
        action_ids: set[str] = set()
        for action in node.actions:
            if not action.action_id or action.action_id in action_ids:
                raise ValueError("action ids must be nonempty and unique within a node")
            action_ids.add(action.action_id)
            if not isinstance(action.replica_key, tuple):
                raise ValueError("replica_key must be a tuple")
            for value in (action.service_tokens, action.power_w):
                if not math.isfinite(value) or value < 0:
                    raise ValueError("action service and power must be finite and nonnegative")
        labels: set[str] = set()
        for child in node.children:
            if child.observable_label in labels:
                raise ValueError("indistinguishable child observations must share one information node")
            labels.add(child.observable_label)
            if node.stage == "recovery" and child.stage == "event":
                raise ValueError("an event cannot restart after recovery")
            if (node.stage == "event" and child.stage == "recovery"
                    and not node.settlement_end):
                raise ValueError("the final event interval must close before recovery")
            validate(child, start_s + node.duration_s)
        if not node.children:
            if node.stage == "event" and not node.settlement_end:
                raise ValueError("a terminal event interval must close")
            horizon_ends.append(start_s + node.duration_s)
        visiting.remove(node.node_id)

    def transition(node: ObservationNode, state: TransitionState,
                   action: ActionEffect) -> TransitionState | None:
        if not action.slo_safe or action.power_w > node.power_limit_w + eps:
            return None
        changed = action.replica_key != state.previous_replica_key
        if changed and state.dwell_remaining_s > eps:
            return None
        if (state.previous_power_w is not None
                and abs(action.power_w - state.previous_power_w)
                > ramp_limit_w_per_s * node.duration_s + eps):
            return None
        balance = state.settlement_balance_ws
        if node.stage == "event":
            balance += (node.reference_power_w - action.power_w - bid_w) * node.duration_s
            if node.settlement_end:
                if balance < -eps:
                    return None
                balance = 0.0
        elif abs(balance) > eps:
            return None
        dwell = min_replica_dwell_s if changed else state.dwell_remaining_s
        return TransitionState(
            action.action_id, action.replica_key, max(0.0, dwell - node.duration_s),
            action.power_w, balance,
        )

    memo: dict[tuple[str, TransitionState], PolicyNode | None] = {}

    def visit(node: ObservationNode, state: TransitionState) -> PolicyNode | None:
        nonlocal evaluated
        check_budget()
        key = node.node_id, state
        if key in memo:
            return memo[key]
        if max_states is not None and evaluated >= max_states:
            raise _SearchIncomplete("state budget exhausted")
        evaluated += 1
        best: PolicyNode | None = None
        best_tie: tuple | None = None
        for action in node.actions:
            check_budget()
            after = transition(node, state, action)
            if after is None:
                continue
            continuations: list[PolicyNode] = []
            for child in node.children:
                continuation = visit(child, after)
                if continuation is None:
                    break
                continuations.append(continuation)
            if len(continuations) != len(node.children):
                continue
            future = min((item.max_work_tokens for item in continuations), default=0.0)
            capacity = action.service_tokens + future
            tie = (action.power_w, action.replica_key != state.previous_replica_key, action.action_id)
            if (best is None or capacity > best.max_work_tokens + eps
                    or (abs(capacity - best.max_work_tokens) <= eps and tie < best_tie)):
                best = PolicyNode(
                    node.node_id, node.observable_label, action, node.duration_s,
                    capacity, state, after, tuple(continuations),
                )
                best_tie = tie
        memo[key] = best
        return best

    try:
        validate(root, 0.0)
        if horizon_ends and max(horizon_ends) - min(horizon_ends) > eps:
            raise ValueError("all observation paths must share one cohort deadline")
        policy = visit(root, initial)
        if policy is None:
            return FrontierResult(
                "INFEASIBLE", None, None, evaluated, time.perf_counter() - started,
                "no policy satisfies the supplied finite-scenario obligations, even for zero work",
            )
        return FrontierResult(
            "FEASIBLE", policy.max_work_tokens, policy, evaluated,
            time.perf_counter() - started,
            "causal [0, max_work_tokens] frontier for the supplied fluid bound model",
        )
    except _SearchIncomplete as exc:
        return FrontierResult(
            "UNKNOWN", None, None, evaluated, time.perf_counter() - started, str(exc),
        )
