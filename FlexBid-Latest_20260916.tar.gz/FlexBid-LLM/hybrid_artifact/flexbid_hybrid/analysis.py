from __future__ import annotations

import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from statistics import mean

from .config import resolve
from .io import atomic_json, read_jsonl
from .types import HybridAction


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, math.ceil(q * len(ordered)) - 1)]


def interpolate(left: tuple[int, float], right: tuple[int, float], target: int) -> float:
    if right[0] == left[0]:
        return left[1]
    ratio = (target - left[0]) / (right[0] - left[0])
    return left[1] + ratio * (right[1] - left[1])


def clipped_samples(values: list[tuple[int, float]], start: int,
                    end: int) -> list[tuple[int, float]]:
    values = sorted(values)
    if len(values) < 2 or values[0][0] > start or values[-1][0] < end:
        raise ValueError("telemetry does not cover measurement boundaries")
    result = [(stamp, value) for stamp, value in values if start <= stamp <= end]
    before_start = max(item for item in values if item[0] <= start)
    after_start = min(item for item in values if item[0] >= start)
    before_end = max(item for item in values if item[0] <= end)
    after_end = min(item for item in values if item[0] >= end)
    result = [(start, interpolate(before_start, after_start, start)), *result,
              (end, interpolate(before_end, after_end, end))]
    deduplicated = {stamp: value for stamp, value in result}
    return sorted(deduplicated.items())


def integrate_j(samples: list[tuple[int, float]]) -> float:
    return sum(
        (right_t - left_t) / 1e9 * (left_v + right_v) / 2
        for (left_t, left_v), (right_t, right_v) in zip(samples, samples[1:])
    )


def summarize_cell(run_dir: Path, config: dict) -> dict:
    cell = json.loads((run_dir / "cell.json").read_text(encoding="utf-8"))
    marker = json.loads((run_dir / "CELL_COMPLETE.json").read_text(encoding="utf-8"))
    start = int(cell["measurement_start_wall_ns"])
    end = int(cell["measurement_end_wall_ns"])
    with (run_dir / "components.csv").open(newline="", encoding="utf-8") as stream:
        telemetry = list(csv.DictReader(stream))
    component = clipped_samples([
        (int(row["wall_time_ns"]), float(row["observed_component_power_w"]))
        for row in telemetry if row.get("observed_component_power_w")
    ], start, end)
    gpu = clipped_samples([
        (int(row["wall_time_ns"]), float(row["aggregate_gpu_power_w"]))
        for row in telemetry if row.get("aggregate_gpu_power_w")
    ], start, end)
    duration_s = (end - start) / 1e9
    energy_j = integrate_j(component)
    gpu_energy_j = integrate_j(gpu)
    online = read_jsonl(run_dir / "online.jsonl")
    batch = read_jsonl(run_dir / "batch.jsonl")
    source = cell["episode"]["source"]
    slo = config["slos"]["agentic" if source == "tracelab" else "default"]
    ttft = percentile([float(row["ttft_ms"]) for row in online
                       if row.get("ttft_ms") is not None], 0.95)
    tpot = percentile([float(row["mean_tpot_ms"]) for row in online
                       if row.get("mean_tpot_ms") is not None], 0.99)
    errors = sum(row.get("error") is not None for row in online)
    load_shed = sum(row.get("status_code") == 429 for row in online)
    safe = (bool(online) and errors == 0 and load_shed == 0
            and ttft is not None and tpot is not None
            and ttft <= float(slo["ttft_ms"]) and tpot <= float(slo["tpot_ms"]))
    action = HybridAction.from_dict(cell["action"])
    return {
        "episode_id": cell["episode"]["episode_id"], "source": source,
        "data_split": cell["episode"].get("split", "unknown"),
        **action.as_dict(), "duration_s": duration_s,
        "power_mean_w": energy_j / duration_s,
        "gpu_power_mean_w": gpu_energy_j / duration_s,
        "energy_j": energy_j, "gpu_energy_j": gpu_energy_j,
        "power_peak_w": max(value for _, value in component),
        "online_requests": len(online), "online_errors": errors,
        "online_load_shed": load_shed,
        "ttft_p95_ms": ttft, "tpot_p99_ms": tpot,
        "ttft_slo_ms": float(slo["ttft_ms"]),
        "tpot_slo_ms": float(slo["tpot_ms"]), "slo_safe": safe,
        "batch_jobs_completed": sum(row.get("error") is None for row in batch),
        "batch_tokens_completed": sum(int(row.get("completion_tokens") or 0)
                                      for row in batch if row.get("error") is None),
        "batch_tokens_per_s": sum(int(row.get("completion_tokens") or 0)
                                  for row in batch if row.get("error") is None) / duration_s,
        "telemetry_rows": marker["telemetry_rows"],
    }


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def analyze(root: Path, config: dict) -> dict:
    results = resolve(root, config["paths"]["results_root"])
    cells = sorted((results / "cells").glob("*/*/CELL_COMPLETE.json"))
    manifest_path = results / "campaign_manifest.json"
    expected = (
        int(json.loads(manifest_path.read_text(encoding="utf-8"))["expected_cells"])
        if manifest_path.exists()
        else len(config["actions"]) * len(config["workloads"]["sources"]) * int(
            config["workloads"]["test_episodes_per_source"]
        )
    )
    if len(cells) != expected:
        raise RuntimeError(f"expected {expected} cells, found {len(cells)}")
    rows = [summarize_cell(path.parent, config) for path in cells]
    write_csv(results / "cell_summary.csv", rows)
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["episode_id"]].append(row)
    baseline_names = {"hybrid_full", "hybrid_half_batch", "hybrid_quarter_batch"}
    episode_rows = []
    reductions_all = []
    valid_baselines = 0
    safe_controlled = 0
    for episode_id, values in sorted(grouped.items()):
        baselines = [row for row in values if row["name"] in baseline_names
                     and row["slo_safe"] and row["batch_tokens_completed"] > 0]
        # Normal operation uses the highest useful batch throughput that still
        # preserves online SLO. This prevents an invalid overloaded baseline
        # from exaggerating DR capacity.
        baseline = max(baselines, key=lambda row: (
            row["batch_tokens_per_s"], row["power_mean_w"]
        )) if baselines else None
        controlled = [row for row in values if row["name"] not in baseline_names
                      and row["slo_safe"]]
        best = min(controlled, key=lambda row: row["power_mean_w"]) if controlled else None
        reduction_w = reduction_pct = 0.0
        if baseline is not None:
            valid_baselines += 1
        if best is not None:
            safe_controlled += 1
        if baseline is not None and best is not None:
            reduction_w = max(0.0, baseline["power_mean_w"] - best["power_mean_w"])
            reduction_pct = 100 * reduction_w / baseline["power_mean_w"]
        reductions_all.append(reduction_pct)
        episode_rows.append({
            "episode_id": episode_id, "source": values[0]["source"],
            "baseline_valid": baseline is not None,
            "baseline_action": None if baseline is None else baseline["name"],
            "baseline_power_w": None if baseline is None else baseline["power_mean_w"],
            "baseline_batch_tokens_per_s": None if baseline is None else baseline["batch_tokens_per_s"],
            "safe_controlled_action_exists": best is not None,
            "oracle_action": None if best is None else best["name"],
            "oracle_power_w": None if best is None else best["power_mean_w"],
            "oracle_reduction_w": reduction_w,
            "oracle_reduction_pct": reduction_pct,
            "oracle_ttft_p95_ms": None if best is None else best["ttft_p95_ms"],
            "oracle_tpot_p99_ms": None if best is None else best["tpot_p99_ms"],
        })
    write_csv(results / "episode_oracle.csv", episode_rows)
    count = len(episode_rows)
    mean_reduction = mean(reductions_all) if reductions_all else 0.0
    safe_fraction = safe_controlled / count if count else 0.0
    baseline_fraction = valid_baselines / count if count else 0.0
    gate = config["gate"]
    passed = (
        mean_reduction >= float(gate["minimum_mean_reduction_pct"])
        and safe_fraction >= float(gate["minimum_safe_episode_fraction"])
        and baseline_fraction >= float(gate["minimum_safe_episode_fraction"])
    )
    event_s = float(config["workloads"]["measurement_s"])
    slack_s = float(config["workloads"]["batch_deadline_slack_s"])
    catchup = math.inf if slack_s <= event_s else slack_s / (slack_s - event_s)
    report = {
        "status": "PASS_CONTINUE" if passed else "FAIL_STOP_OR_REDESIGN",
        "cells": len(rows), "episodes": count,
        "valid_hybrid_baseline_fraction": baseline_fraction,
        "safe_controlled_action_fraction": safe_fraction,
        "slo_safe_oracle_mean_reduction_w": mean([
            row["oracle_reduction_w"] for row in episode_rows
        ]) if episode_rows else 0.0,
        "slo_safe_oracle_mean_reduction_pct": mean_reduction,
        "slo_safe_oracle_median_reduction_pct": percentile(reductions_all, 0.5),
        "slo_safe_oracle_max_reduction_pct": max(reductions_all, default=0.0),
        "episodes_ge_5pct": sum(item >= 5 for item in reductions_all),
        "episodes_ge_10pct": sum(item >= 10 for item in reductions_all),
        "minimum_gate_pct": gate["minimum_mean_reduction_pct"],
        "target_gate_pct": gate["target_mean_reduction_pct"],
        "batch_deadline_slack_s": slack_s,
        "required_post_event_catchup_multiplier": catchup,
        "important_caveat": (
            "PASS establishes physical curtailment only. The next stage must measure "
            "post-event batch catch-up and enforce batch deadlines before making a DR claim."
        ),
        "measurement_boundary": (
            "GPU NVML plus available CPU package/DRAM RAPL; not facility power"
        ),
    }
    atomic_json(results / "PHYSICAL_GATE.json", report)
    lines = [
        "# Hybrid physical-flexibility gate", "",
        f"- Decision: **{report['status']}**",
        f"- SLO-safe oracle mean reduction: **{mean_reduction:.2f}%**",
        f"- Median / maximum: {report['slo_safe_oracle_median_reduction_pct']:.2f}% / "
        f"{report['slo_safe_oracle_max_reduction_pct']:.2f}%",
        f"- Valid SLO-safe hybrid baseline: {valid_baselines}/{count}",
        f"- Episodes with a safe controlled action: {safe_controlled}/{count}",
        f"- Episodes >=5% / >=10%: {report['episodes_ge_5pct']} / {report['episodes_ge_10pct']}",
        f"- Required post-event batch catch-up multiplier: {catchup:.3f}x", "",
        report["important_caveat"], "",
    ]
    (results / "PHYSICAL_GATE.md").write_text("\n".join(lines), encoding="utf-8")
    return report
