from __future__ import annotations

import argparse
import csv
import json
import signal
import time
from datetime import datetime, timezone
from pathlib import Path

import pynvml


RUNNING = True


def stop(_signum, _frame) -> None:
    global RUNNING
    RUNNING = False


def read_number(path: Path) -> float | None:
    try:
        return float(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def safe(call):
    try:
        return call()
    except (pynvml.NVMLError, AttributeError):
        return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--interval-ms", type=int, default=100)
    args = parser.parse_args()
    if args.interval_ms < 20:
        parser.error("interval must be >=20 ms")
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pynvml.nvmlInit()
    handles = [pynvml.nvmlDeviceGetHandleByIndex(index)
               for index in range(pynvml.nvmlDeviceGetCount())]
    rapl = []
    for path in sorted(Path("/sys/class/powercap").glob("intel-rapl:*/energy_uj")):
        current = read_number(path)
        if current is None:
            continue
        name_path = path.parent / "name"
        try:
            name = name_path.read_text(encoding="utf-8").strip()
        except OSError:
            name = path.parent.name
        rapl.append({
            "path": path, "name": name, "previous": current,
            "maximum": read_number(path.parent / "max_energy_range_uj"),
            "previous_ns": time.perf_counter_ns(),
        })
    fields = ["wall_time_ns", "elapsed_ms", "sample_interval_ms"]
    for index in range(len(handles)):
        fields += [f"gpu{index}_power_w", f"gpu{index}_power_limit_w",
                   f"gpu{index}_util_pct", f"gpu{index}_temperature_c"]
    fields += ["aggregate_gpu_power_w", "aggregate_cpu_package_power_w",
               "aggregate_dram_power_w", "observed_component_power_w"]
    metadata = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "gpu_count": len(handles), "interval_ms": args.interval_ms,
        "measurement_boundary": "NVML GPU modules plus available CPU package/DRAM RAPL",
        "excluded": ["motherboard", "NIC", "storage", "fans", "PSU loss", "cooling"],
        "rapl_domains": [item["name"] for item in rapl],
    }
    metadata_path = args.output.with_suffix(".metadata.json")
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    start = previous = time.perf_counter_ns()
    next_sample = start
    try:
        with args.output.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            stream.flush()
            while RUNNING:
                now = time.perf_counter_ns()
                if now < next_sample:
                    time.sleep((next_sample - now) / 1e9)
                    continue
                row = {
                    "wall_time_ns": time.time_ns(),
                    "elapsed_ms": (now - start) / 1e6,
                    "sample_interval_ms": (now - previous) / 1e6,
                }
                gpu_powers = []
                for index, handle in enumerate(handles):
                    power = safe(lambda h=handle: pynvml.nvmlDeviceGetPowerUsage(h))
                    limit = safe(lambda h=handle: pynvml.nvmlDeviceGetEnforcedPowerLimit(h))
                    util = safe(lambda h=handle: pynvml.nvmlDeviceGetUtilizationRates(h))
                    temp = safe(lambda h=handle: pynvml.nvmlDeviceGetTemperature(
                        h, pynvml.NVML_TEMPERATURE_GPU
                    ))
                    row[f"gpu{index}_power_w"] = None if power is None else power / 1000
                    row[f"gpu{index}_power_limit_w"] = None if limit is None else limit / 1000
                    row[f"gpu{index}_util_pct"] = getattr(util, "gpu", None)
                    row[f"gpu{index}_temperature_c"] = temp
                    if power is not None:
                        gpu_powers.append(power / 1000)
                row["aggregate_gpu_power_w"] = (
                    sum(gpu_powers) if len(gpu_powers) == len(handles) else None
                )
                package, dram = [], []
                for domain in rapl:
                    current = read_number(domain["path"])
                    if current is None:
                        continue
                    delta = current - domain["previous"]
                    if delta < 0 and domain["maximum"] is not None:
                        delta += domain["maximum"]
                    elapsed = (now - domain["previous_ns"]) / 1e9
                    watts = delta / 1e6 / elapsed if elapsed > 0 and delta >= 0 else None
                    domain["previous"] = current
                    domain["previous_ns"] = now
                    if watts is not None and "package" in domain["name"]:
                        package.append(watts)
                    if watts is not None and "dram" in domain["name"]:
                        dram.append(watts)
                row["aggregate_cpu_package_power_w"] = sum(package) if package else None
                row["aggregate_dram_power_w"] = sum(dram) if dram else None
                extras = [item for item in (
                    row["aggregate_cpu_package_power_w"], row["aggregate_dram_power_w"]
                ) if item is not None]
                row["observed_component_power_w"] = (
                    None if row["aggregate_gpu_power_w"] is None
                    else row["aggregate_gpu_power_w"] + sum(extras)
                )
                writer.writerow(row)
                stream.flush()
                previous = now
                next_sample += args.interval_ms * 1_000_000
    finally:
        pynvml.nvmlShutdown()
        metadata["completed_utc"] = datetime.now(timezone.utc).isoformat()
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
