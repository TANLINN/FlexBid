"""Independent calibration for a frozen dynamic policy trajectory.

Unlike action-wise conformal bounds, these calibrators never select or change
an action.  They gate a raw trajectory and shrink its electrical offer only
after the complete policy has been frozen on non-calibration data.
"""

from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Iterable, Mapping

from .conformal import finite_sample_quantile


@dataclass(frozen=True)
class SlackObservation:
    episode_id: str
    constraint: str
    predicted_slack: float
    realized_slack: float


@dataclass(frozen=True)
class DeliveryObservation:
    episode_id: str
    predicted_reduction_w: float
    realized_reduction_w: float


@dataclass
class TrajectorySafetyCalibrator:
    alpha: float
    scales: Mapping[str, float]
    radius: float = math.inf
    episode_count: int = 0

    def fit(self, rows: Iterable[SlackObservation]) -> "TrajectorySafetyCalibrator":
        scores: dict[str, list[float]] = defaultdict(list)
        for row in rows:
            scale = float(self.scales.get(row.constraint, math.nan))
            if not math.isfinite(scale) or scale <= 0:
                raise ValueError(f"invalid frozen scale for {row.constraint}: {scale}")
            error = max(0.0, row.predicted_slack - row.realized_slack)
            scores[row.episode_id].append(error / scale)
        maxima = [max(values) for values in scores.values()]
        self.episode_count = len(maxima)
        self.radius = finite_sample_quantile(maxima, self.alpha)
        return self

    def accepts(self, predicted_slacks: Mapping[str, float]) -> bool:
        if not math.isfinite(self.radius):
            return False
        if not self.scales:
            return False
        for name, raw_scale in self.scales.items():
            if name not in predicted_slacks:
                return False
            scale = float(raw_scale)
            slack = float(predicted_slacks[name])
            if float(slack) / scale + 1e-12 < self.radius:
                return False
        return True

    def as_dict(self) -> dict:
        return {
            "alpha": self.alpha,
            "scales": dict(self.scales),
            "radius": self.radius,
            "episode_count": self.episode_count,
        }

    @classmethod
    def from_dict(cls, value: Mapping) -> "TrajectorySafetyCalibrator":
        return cls(
            alpha=float(value["alpha"]),
            scales={str(k): float(v) for k, v in value["scales"].items()},
            radius=float(value["radius"]),
            episode_count=int(value["episode_count"]),
        )


@dataclass
class ElectricalDeliveryCalibrator:
    alpha: float
    scale_w: float
    radius: float = math.inf
    episode_count: int = 0

    def __post_init__(self) -> None:
        if not math.isfinite(self.scale_w) or self.scale_w <= 0:
            raise ValueError("scale_w must be finite and positive")

    def fit(self, rows: Iterable[DeliveryObservation]) -> "ElectricalDeliveryCalibrator":
        scores: dict[str, list[float]] = defaultdict(list)
        for row in rows:
            underdelivery = max(
                0.0,
                row.predicted_reduction_w - row.realized_reduction_w,
            )
            scores[row.episode_id].append(underdelivery / self.scale_w)
        maxima = [max(values) for values in scores.values()]
        self.episode_count = len(maxima)
        self.radius = finite_sample_quantile(maxima, self.alpha)
        return self

    @property
    def margin_w(self) -> float:
        return self.radius * self.scale_w

    def shrink(self, raw_bid_w: float) -> float:
        if not math.isfinite(self.margin_w):
            return 0.0
        return max(0.0, float(raw_bid_w) - self.margin_w)

    def as_dict(self) -> dict:
        return {
            "alpha": self.alpha,
            "scale_w": self.scale_w,
            "radius": self.radius,
            "episode_count": self.episode_count,
            "margin_w": self.margin_w,
        }

    @classmethod
    def from_dict(cls, value: Mapping) -> "ElectricalDeliveryCalibrator":
        return cls(
            alpha=float(value["alpha"]),
            scale_w=float(value["scale_w"]),
            radius=float(value["radius"]),
            episode_count=int(value["episode_count"]),
        )


@dataclass(frozen=True)
class CalibratedOffer:
    accepted: bool
    raw_bid_w: float
    calibrated_bid_w: float
    reason: str


@dataclass
class FrozenPolicyCalibrator:
    safety: TrajectorySafetyCalibrator
    electrical: ElectricalDeliveryCalibrator

    def calibrate(
        self,
        raw_bid_w: float,
        predicted_slacks: Mapping[str, float],
    ) -> CalibratedOffer:
        if not self.safety.accepts(predicted_slacks):
            return CalibratedOffer(False, raw_bid_w, 0.0, "non-electrical gate rejected raw trajectory")
        bid = self.electrical.shrink(raw_bid_w)
        return CalibratedOffer(
            bid > 0,
            raw_bid_w,
            bid,
            "calibrated electrical offer" if bid > 0 else "electrical margin reduced offer to zero",
        )

    def as_dict(self) -> dict:
        return {
            "status": "FROZEN_POLICY_CALIBRATION",
            "safety": self.safety.as_dict(),
            "electrical": self.electrical.as_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping) -> "FrozenPolicyCalibrator":
        return cls(
            TrajectorySafetyCalibrator.from_dict(value["safety"]),
            ElectricalDeliveryCalibrator.from_dict(value["electrical"]),
        )
