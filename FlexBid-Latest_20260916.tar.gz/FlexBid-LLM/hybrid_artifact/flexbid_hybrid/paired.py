from __future__ import annotations

import math
from dataclasses import dataclass
from statistics import pstdev

from .conformal import finite_sample_quantile
from .modeling import HybridSurrogate
from .policy import BASELINE_ACTION, HybridBid, _zero


@dataclass
class PairedEffectCalibrator:
    """Episode-level CP for paired action effects and online-SLO tails.

    Power is calibrated as P(baseline)-P(action), avoiding the very loose
    subtraction of two independently widened power intervals.  Scale values
    are learned only from the proper-training split; calibration episodes are
    used exclusively for the exact conformal order statistic.
    """

    alpha: float = 0.05
    reduction_scale_w: float = 1.0
    ttft_scale_ms: float = 1.0
    tpot_scale_ms: float = 1.0
    radius: float = math.inf
    calibration_episodes: int = 0

    @staticmethod
    def _group(rows: list[dict]) -> dict[str, list[dict]]:
        grouped: dict[str, list[dict]] = {}
        for row in rows:
            grouped.setdefault(str(row["episode_id"]), []).append(row)
        return grouped

    @staticmethod
    def _errors(rows: list[dict], surrogate: HybridSurrogate) -> list[tuple[float, float, float]]:
        by_name = {str(row["name"]): row for row in rows}
        baseline = by_name[BASELINE_ACTION]
        base_prediction = surrogate.predict(baseline)
        values = [(
            0.0,
            float(baseline["ttft_p95_ms"]) - base_prediction.ttft_p95_ms,
            float(baseline["tpot_p99_ms"]) - base_prediction.tpot_p99_ms,
        )]
        for name, row in by_name.items():
            if name == BASELINE_ACTION:
                continue
            prediction = surrogate.predict(row)
            predicted_reduction = (
                base_prediction.power_mean_w - prediction.power_mean_w
            )
            actual_reduction = (
                float(baseline["power_mean_w"]) - float(row["power_mean_w"])
            )
            values.append((
                predicted_reduction - actual_reduction,
                float(row["ttft_p95_ms"]) - prediction.ttft_p95_ms,
                float(row["tpot_p99_ms"]) - prediction.tpot_p99_ms,
            ))
        return values

    def fit(
        self,
        train_rows: list[dict],
        calibration_rows: list[dict],
        surrogate: HybridSurrogate,
    ) -> "PairedEffectCalibrator":
        train_errors = [
            error
            for rows in self._group(train_rows).values()
            for error in self._errors(rows, surrogate)
        ]
        self.reduction_scale_w = max(1.0, pstdev(error[0] for error in train_errors))
        self.ttft_scale_ms = max(1.0, pstdev(error[1] for error in train_errors))
        self.tpot_scale_ms = max(1.0, pstdev(error[2] for error in train_errors))
        episode_scores = []
        for rows in self._group(calibration_rows).values():
            score = max(
                max(
                    max(0.0, reduction_error) / self.reduction_scale_w,
                    max(0.0, ttft_error) / self.ttft_scale_ms,
                    max(0.0, tpot_error) / self.tpot_scale_ms,
                )
                for reduction_error, ttft_error, tpot_error
                in self._errors(rows, surrogate)
            )
            episode_scores.append(score)
        self.calibration_episodes = len(episode_scores)
        self.radius = finite_sample_quantile(episode_scores, self.alpha)
        return self

    def margins(self) -> tuple[float, float, float]:
        return (
            self.radius * self.reduction_scale_w,
            self.radius * self.ttft_scale_ms,
            self.radius * self.tpot_scale_ms,
        )

    def as_dict(self) -> dict:
        reduction, ttft, tpot = self.margins()
        return {
            "alpha": self.alpha,
            "radius": self.radius,
            "calibration_episodes": self.calibration_episodes,
            "reduction_scale_w": self.reduction_scale_w,
            "ttft_scale_ms": self.ttft_scale_ms,
            "tpot_scale_ms": self.tpot_scale_ms,
            "reduction_margin_w": reduction,
            "ttft_margin_ms": ttft,
            "tpot_margin_ms": tpot,
            "finite": math.isfinite(self.radius),
        }


def paired_effect_bid(
    rows: list[dict],
    surrogate: HybridSurrogate,
    calibrator: PairedEffectCalibrator,
) -> HybridBid:
    by_name = {str(row["name"]): row for row in rows}
    baseline = by_name.get(BASELINE_ACTION)
    if baseline is None or not math.isfinite(calibrator.radius):
        return _zero("paired calibration unavailable", "paired_episode")
    base_prediction = surrogate.predict(baseline)
    reduction_margin, ttft_margin, tpot_margin = calibrator.margins()
    baseline_ttft_upper = base_prediction.ttft_p95_ms + ttft_margin
    baseline_tpot_upper = base_prediction.tpot_p99_ms + tpot_margin
    if (
        baseline_ttft_upper > float(baseline["ttft_slo_ms"])
        or baseline_tpot_upper > float(baseline["tpot_slo_ms"])
    ):
        return _zero("baseline rejected by calibrated admission gate", "paired_episode")
    candidates = []
    for name, row in by_name.items():
        if name == BASELINE_ACTION:
            continue
        prediction = surrogate.predict(row)
        lower_reduction = (
            base_prediction.power_mean_w - prediction.power_mean_w - reduction_margin
        )
        ttft_upper = prediction.ttft_p95_ms + ttft_margin
        tpot_upper = prediction.tpot_p99_ms + tpot_margin
        if (
            lower_reduction > 0
            and ttft_upper <= float(row["ttft_slo_ms"])
            and tpot_upper <= float(row["tpot_slo_ms"])
        ):
            candidates.append((lower_reduction, name, prediction, ttft_upper, tpot_upper))
    if not candidates:
        return _zero("no action passes paired calibrated bounds", "paired_episode")
    reduction, name, prediction, ttft_upper, tpot_upper = max(candidates)
    expected = max(0.0, base_prediction.power_mean_w - prediction.power_mean_w)
    return HybridBid(
        name, reduction, expected, True,
        "maximum paired-effect calibrated reduction", "paired_episode",
        base_prediction.power_mean_w, prediction.power_mean_w,
        ttft_upper, tpot_upper,
    )
