"""Explicit one-cell research opt-in; never supplies a production EMS baseline.

Only the dedicated diagnostic launcher enables this module. Default runtime,
zero-bid and deployment guards remain unchanged. No offer value is configured.
"""
from dataclasses import replace
import math
from pathlib import Path
from statistics import mean
import time

from .deployment import sha256_file
from .io import atomic_json

SCHEMA = 'one_cell_raw_mpc_development_v1'
EPISODE = 'qwen_bailian:bailian-000009:trajectory-window-0'
MODEL_SHA = '7d154bf15d13103a6b56b1a244d9e8d180a4f345ba3bc4ad0549b583bb5ebd36'
DATASET_SHA = 'bd12c5b560d9589edbe8d98732979c98d0c9057b06cfc7a51cd1f3db2923ba55'


def configure_development_episode(loop, config):
    d = config['dynamic_controller']
    options = d.get('development_episode')
    if options is None:
        return
    if (options != {'schema': SCHEMA, 'diagnostic_reference_only': True}
            or d.get('deployment_mode') != 'development'
            or d.get('allow_unvalidated_development') is not True
            or d.get('external_commitments_enabled') is not False
            or d.get('force_baseline') is not False
            or d.get('calibration_mode') != 'none'
            or d.get('trajectory_calibration') is not None
            or d.get('online_residual_adaptation') is not False
            or loop.force_baseline or loop.dry_run or loop.offer_calibrator is not None):
        raise ValueError('Invalid one-cell development opt-in; no reference created')
    if (loop.source != 'qwen_bailian' or list(loop.gpu_indices) != list(range(8))
            or loop.event_s != 300 or loop.deadline_s != 1800
            or loop.warmup_s != 120 or loop.offer_lead_s != 30
            or loop.contract.reference_power_w):
        raise ValueError('Unexpected diagnostic domain, timing or pre-existing reference')
    # These are identities of user-provided historical artifacts, not certificates.
    if sha256_file(Path(d['surrogate_model'])) != MODEL_SHA:
        raise ValueError('Historical candidate changed; re-review before this diagnostic')
    if sha256_file(Path(d['baseline_dataset'])) != DATASET_SHA:
        raise ValueError('Historical baseline dataset changed')
    import json
    cell = json.loads((loop.state_path.parent / 'cell.json').read_text(encoding='utf-8'))
    if cell['episode']['episode_id'] != EPISODE or cell['activation_wall_ns'] != loop.activation_wall_ns:
        raise ValueError('Wrong development cell or activation clock')
    loop._one_cell_development = dict(schema=SCHEMA, episode_id=EPISODE,
        model_sha256=MODEL_SHA, dataset_sha256=DATASET_SHA)


def freeze_development_reference(loop, baseline_power_w, samples):
    options = getattr(loop, '_one_cell_development', None)
    if options is None:
        return
    if (loop.force_baseline or loop.event_session is not None
            or float(loop.committed_bid_w or 0) != 0 or loop.contract.reference_power_w
            or loop.activation_wall_ns is None or time.time_ns() >= loop.activation_wall_ns):
        raise ValueError('Development reference must be frozen before offer/activation')
    if (len(samples) < 3 or any(not math.isfinite(x) or x <= 0 for x in samples)
            or baseline_power_w is None or not math.isfinite(baseline_power_w)
            or not math.isclose(mean(samples), baseline_power_w, rel_tol=1e-9)):
        raise ValueError('Invalid measured GPU warmup reference')
    path = loop.state_path.parent / 'DEVELOPMENT_REFERENCE.json'
    if path.exists():
        raise ValueError('Fresh diagnostic cell required; never replace a frozen reference')
    metadata = getattr(loop, 'baseline_reference_metadata', None) or {}
    record = dict(options, power_boundary='gpu_nvml', reference_power_w=baseline_power_w,
        reference_method='arithmetic_mean_of_causal_warmup_tail_gpu_samples',
        warmup_gpu_samples=list(samples), warmup_s=loop.warmup_s,
        baseline_reference_metadata=metadata,
        frozen_wall_ns=time.time_ns(), activation_wall_ns=loop.activation_wall_ns,
        baseline_batch_tps_used=loop.baseline_batch_tps,
        baseline_batch_tps_origin='historical_dataset_not_target_host_validated',
        initial_cohort_tokens=loop.initial_cohort_tokens,
        diagnostic_reference_only=True, counterfactual_baseline_validated=False,
        external_commitments_enabled=False, deployment_authorized=False,
        warning='Warmup may not represent event load. Local shortfall is diagnostic, not market settlement.')
    atomic_json(path, record)
    loop.contract = replace(loop.contract, reference_power_w=(float(baseline_power_w),))
