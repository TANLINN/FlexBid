from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class HybridAction:
    name: str
    online_replicas: int
    batch_concurrency: int
    power_cap_w: float
    online_replica_ids: tuple[int, ...] | None = None

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("action name is required")
        if self.online_replicas <= 0:
            raise ValueError("online_replicas must be positive")
        if self.batch_concurrency < 0:
            raise ValueError("batch_concurrency cannot be negative")
        if self.power_cap_w <= 0:
            raise ValueError("power_cap_w must be positive")
        if self.online_replica_ids is not None:
            ids = tuple(int(value) for value in self.online_replica_ids)
            if len(ids) != self.online_replicas:
                raise ValueError("online_replica_ids length must equal online_replicas")
            if len(ids) != len(set(ids)) or any(value < 0 for value in ids):
                raise ValueError("online_replica_ids must be unique and non-negative")
            object.__setattr__(self, "online_replica_ids", ids)

    def resolved_online_replica_ids(self) -> tuple[int, ...]:
        if self.online_replica_ids is not None:
            return self.online_replica_ids
        return tuple(range(self.online_replicas))

    def as_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict) -> "HybridAction":
        return cls(
            name=str(value["name"]),
            online_replicas=int(value["online_replicas"]),
            batch_concurrency=int(value["batch_concurrency"]),
            power_cap_w=float(value["power_cap_w"]),
            online_replica_ids=(
                None
                if value.get("online_replica_ids") is None
                else tuple(int(item) for item in value["online_replica_ids"])
            ),
        )
