from __future__ import annotations

import math
from dataclasses import asdict, dataclass
from statistics import mean

from .modeling import HybridSurrogate


BASELINE_ACTION = "hybrid_full"


@dataclass
class HybridBid:
    action_name: str
    committed_reduction_w: float
    expected_reduction_w: float
    feasible: bool
    reason: str
    calibration_mode: str
    baseline_lower_w: float
    controlled_upper_w: float
    ttft_upper_ms: float
    tpot_upper_ms: float

    def as_dict(self) -> dict:
        return asdict(self)


def _zero(reason: str, mode: str) -> HybridBid:
    return HybridBid(
        BASELINE_ACTION, 0.0, 0.0, False, reason, mode,
        0.0, math.inf, math.inf, math.inf,
    )


def risk_calibrated_bid(
    rows: list[dict],
    surrogate: HybridSurrogate,
    mode: str,
) -> HybridBid:
    by_name = {str(row["name"]): row for row in rows}
    baseline = by_name.get(BASELINE_ACTION)
    if baseline is None:
        return _zero("baseline action is missing", mode)
    baseline_prediction = surrogate.predict(baseline)
    baseline_bounds = surrogate.bounds(baseline, mode)
    if (
        not math.isfinite(baseline_bounds.power_lower_w)
        or baseline_bounds.ttft_upper_ms > float(baseline["ttft_slo_ms"])
        or baseline_bounds.tpot_upper_ms > float(baseline["tpot_slo_ms"])
    ):
        return _zero("baseline is not prediction-safe", mode)
    candidates = []
    for name, row in by_name.items():
        if name == BASELINE_ACTION:
            continue
        prediction = surrogate.predict(row)
        bounds = surrogate.bounds(row, mode)
        reduction = baseline_bounds.power_lower_w - bounds.power_upper_w
        feasible = (
            math.isfinite(reduction)
            and reduction > 0
            and bounds.ttft_upper_ms <= float(row["ttft_slo_ms"])
            and bounds.tpot_upper_ms <= float(row["tpot_slo_ms"])
        )
        if feasible:
            candidates.append((reduction, name, row, prediction, bounds))
    if not candidates:
        return _zero("no action satisfies calibrated power and SLO constraints", mode)
    reduction, name, _row, prediction, bounds = max(candidates, key=lambda item: item[0])
    return HybridBid(
        action_name=name,
        committed_reduction_w=max(0.0, reduction),
        expected_reduction_w=max(
            0.0, baseline_prediction.power_mean_w - prediction.power_mean_w
        ),
        feasible=True,
        reason="maximum safe calibrated hybrid reduction",
        calibration_mode=mode,
        baseline_lower_w=baseline_bounds.power_lower_w,
        controlled_upper_w=bounds.power_upper_w,
        ttft_upper_ms=bounds.ttft_upper_ms,
        tpot_upper_ms=bounds.tpot_upper_ms,
    )


def static_conservative_policy(calibration_rows: list[dict]) -> tuple[str, float]:
    episodes: dict[str, dict[str, dict]] = {}
    for row in calibration_rows:
        episodes.setdefault(str(row["episode_id"]), {})[str(row["name"])] = row
    actions = sorted({str(row["name"]) for row in calibration_rows})
    best_name = BASELINE_ACTION
    best_bid = 0.0
    for action in actions:
        if action == BASELINE_ACTION:
            continue
        reductions = []
        valid = True
        for values in episodes.values():
            baseline = values.get(BASELINE_ACTION)
            controlled = values.get(action)
            if baseline is None or controlled is None or not bool(controlled["slo_safe"]):
                valid = False
                break
            reductions.append(
                float(baseline["power_mean_w"]) - float(controlled["power_mean_w"])
            )
        if valid and reductions:
            safe_bid = max(0.0, min(reductions))
            if safe_bid > best_bid:
                best_name, best_bid = action, safe_bid
    return best_name, best_bid


def actual_oracle(rows: list[dict]) -> HybridBid:
    by_name = {str(row["name"]): row for row in rows}
    baseline = by_name[BASELINE_ACTION]
    candidates = [
        row for name, row in by_name.items()
        if name != BASELINE_ACTION and bool(row["slo_safe"])
    ]
    if not candidates:
        return _zero("no actually SLO-safe controlled action", "oracle")
    chosen = min(candidates, key=lambda row: float(row["power_mean_w"]))
    reduction = max(
        0.0,
        float(baseline["power_mean_w"]) - float(chosen["power_mean_w"]),
    )
    return HybridBid(
        str(chosen["name"]), reduction, reduction, reduction > 0,
        "clairvoyant SLO-safe oracle", "oracle",
        float(baseline["power_mean_w"]), float(chosen["power_mean_w"]),
        float(chosen["ttft_p95_ms"]), float(chosen["tpot_p99_ms"]),
    )


def summarize_method(rows: list[dict]) -> dict:
    count = len(rows)
    return {
        "episodes": count,
        "mean_bid_w": mean(float(row["bid_w"]) for row in rows),
        "mean_achieved_reduction_w": mean(
            float(row["achieved_reduction_w"]) for row in rows
        ),
        "mean_achieved_reduction_pct": mean(
            float(row["achieved_reduction_pct"]) for row in rows
        ),
        "delivery_failure_rate": mean(int(row["delivery_failure"]) for row in rows),
        "online_slo_failure_rate": mean(int(row["online_slo_failure"]) for row in rows),
        "batch_deadline_failure_rate": mean(
            int(row["batch_deadline_failure"]) for row in rows
        ),
        "mean_power_w": mean(float(row["power_mean_w"]) for row in rows),
        "mean_energy_kwh": mean(float(row["energy_kwh"]) for row in rows),
        "mean_operational_carbon_g": mean(
            float(row["operational_carbon_g"]) for row in rows
        ),
        "mean_ttft_p95_ms": mean(float(row["ttft_p95_ms"]) for row in rows),
        "mean_tpot_p99_ms": mean(float(row["tpot_p99_ms"]) for row in rows),
    }
