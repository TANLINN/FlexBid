"""Facility-to-domain flexibility contract used by the runtime MPC.

The contract deliberately stays at the component-metered IT-domain boundary.
It does not pretend that NVML/RAPL measurements are a utility settlement meter;
an upper-layer EMS is responsible for the site baseline and aggregation.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


def _finite_nonnegative(name: str, value: float) -> None:
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"{name} must be finite and non-negative")


@dataclass(frozen=True)
class FlexibilityContract:
    """Immutable event and recovery constraints supplied by an EMS.

    Trajectories are sampled at ``trajectory_step_s``.  A scalar trajectory can
    be represented by a one-element tuple and is then held for the full horizon.
    Empty envelope/reference trajectories disable only the corresponding bound.
    """

    event_s: float
    deadline_s: float
    settlement_interval_s: float
    reference_power_w: tuple[float, ...] = ()
    recovery_power_envelope_w: tuple[float, ...] = ()
    rebound_limit_w: float = math.inf
    ramp_limit_w_per_s: float = math.inf
    trajectory_step_s: float = 30.0

    def __post_init__(self) -> None:
        _finite_nonnegative("event_s", self.event_s)
        _finite_nonnegative("deadline_s", self.deadline_s)
        if self.deadline_s < self.event_s:
            raise ValueError("deadline_s cannot precede event_s")
        if not math.isfinite(self.settlement_interval_s) or self.settlement_interval_s <= 0:
            raise ValueError("settlement_interval_s must be finite and positive")
        if not math.isfinite(self.trajectory_step_s) or self.trajectory_step_s <= 0:
            raise ValueError("trajectory_step_s must be finite and positive")
        for name in ("reference_power_w", "recovery_power_envelope_w"):
            values = getattr(self, name)
            if any(not math.isfinite(value) or value < 0 for value in values):
                raise ValueError(f"{name} must contain finite non-negative values")
        for name in ("rebound_limit_w", "ramp_limit_w_per_s"):
            value = getattr(self, name)
            if value < 0 or math.isnan(value):
                raise ValueError(f"{name} cannot be negative or NaN")

    @staticmethod
    def _at(values: tuple[float, ...], elapsed_s: float, step_s: float) -> float:
        if not values:
            return math.inf
        index = min(len(values) - 1, max(0, int(elapsed_s // step_s)))
        return float(values[index])

    def reference_at(self, elapsed_s: float) -> float:
        return self._at(self.reference_power_w, elapsed_s, self.trajectory_step_s)

    def recovery_envelope_at(self, recovery_elapsed_s: float) -> float:
        return self._at(
            self.recovery_power_envelope_w,
            recovery_elapsed_s,
            self.trajectory_step_s,
        )

    @classmethod
    def from_mapping(cls, value: dict, *, event_s: float, deadline_s: float) -> "FlexibilityContract":
        def trajectory(name: str) -> tuple[float, ...]:
            raw = value.get(name, ())
            if raw is None:
                return ()
            if isinstance(raw, (int, float)):
                return (float(raw),)
            return tuple(float(item) for item in raw)

        return cls(
            event_s=float(value.get("event_s", event_s)),
            deadline_s=float(value.get("deadline_s", deadline_s)),
            settlement_interval_s=float(value.get("settlement_interval_s", 30.0)),
            reference_power_w=trajectory("reference_power_w"),
            recovery_power_envelope_w=trajectory("recovery_power_envelope_w"),
            rebound_limit_w=float(value.get("rebound_limit_w", math.inf)),
            ramp_limit_w_per_s=float(value.get("ramp_limit_w_per_s", math.inf)),
            trajectory_step_s=float(value.get("trajectory_step_s", 30.0)),
        )
