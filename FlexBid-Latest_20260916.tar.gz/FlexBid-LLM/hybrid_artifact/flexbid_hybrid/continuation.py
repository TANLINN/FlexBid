"""Commitment-aware MPC supervision; validation is conditional on model bounds.

Never interpret a search timeout as proof of physical infeasibility.  A cached
schedule is shifted, placed on the *current* control clock and revalidated with
fresh envelopes and measured debt.  A service-protection action is explicitly
unverified, not a feasible DR continuation.  No bid or actuator tuple is fixed.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, replace

from .mpc import ControlState, MPCPlan, PlanStep, ViabilityMPC


class ContinuationRejected(ValueError):
    pass


@dataclass(frozen=True)
class SupervisedPlan(MPCPlan):
    controller_status: str = "UNVERIFIED_SERVICE_PROTECTION"
    continuation_model_validated: bool = False
    optimality_proven: bool = False
    underlying_solver_reason: str = ""
    validation_reason: str = ""
    deployment_status: str = "UNSPECIFIED_OR_SYNTHETIC"


class GuardedViabilityMPC(ViabilityMPC):
    """Single-control-loop supervisor; not a hardware-independent certificate."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._cached_plan = None
        self._cached_state = None

    def _search(self, state):
        return super().solve(state)

    def _cache_offset(self, state):
        old = self._cached_state
        if old is None or self._cached_plan is None or state.committed_bid_w is None:
            return None
        elapsed = old.deadline_remaining_s - state.deadline_remaining_s
        if (elapsed < -1e-6 or old.source != state.source or old.contract != state.contract
                or abs(max(0.0, old.event_remaining_s - elapsed)
                       - state.event_remaining_s) > 1e-4):
            return None
        return max(0.0, elapsed)

    def validate_schedule(self, state, steps, envelopes, *, offset_s=0.0, bid_w=0.0):
        """Recompute every constraint; never trust old step powers/debt values.

        Commands are held until the next control tick, even if the settlement
        boundary falls inside the tick.  This does not model unmeasured actuator
        delays or certify real-world SLOs; live timing still needs validation.
        """
        if not steps or not math.isfinite(bid_w) or bid_w < 0:
            raise ContinuationRejected("missing schedule or invalid bid")
        support = {item.action.name: item for item in envelopes if item.slo_safe}
        baseline = support.get(self.baseline_action)
        if baseline is None:
            raise ContinuationRejected("baseline bounds unsupported/unsafe")
        baseline_tps = state.baseline_batch_tps
        baseline_tps = baseline.batch_tps_lower if baseline_tps is None else baseline_tps
        if not math.isfinite(baseline_tps) or baseline_tps < 0:
            raise ContinuationRejected("invalid baseline throughput")
        schedule = []
        total = 0.0
        for step in steps:
            if not math.isfinite(step.duration_s) or step.duration_s <= 0:
                raise ContinuationRejected("invalid cached duration")
            total += step.duration_s
            schedule.append((total, step.action))
        if total + 1e-5 < offset_s + state.deadline_remaining_s:
            raise ContinuationRejected("schedule does not cover remaining horizon")
        period = self.parameters.control_period_s
        debt, cohort = state.debt_tokens, state.cohort_tokens
        dwell, previous = state.replica_dwell_remaining_s, self.actions_by_name.get(state.current_action)
        if previous is None:
            raise ContinuationRejected("unknown current action")
        power = state.previous_power_w
        balance, settlement_s = state.settlement_delivered_ws, state.settlement_elapsed_s
        elapsed = 0.0
        output = []
        for window in self._durations(state):
            left = window.duration_s
            within = 0.0
            while left > 1e-8:
                slot = math.floor((elapsed + 1e-8) / period)
                at = offset_s + slot * period
                selected = next((action for end, action in schedule if end > at + 1e-8), None)
                if selected is None or selected.name not in support:
                    raise ContinuationRejected("action no longer supported/SLO-safe")
                env = support[selected.name]
                if selected.as_dict() != env.action.as_dict():
                    raise ContinuationRejected("cached action geometry changed")
                if not all(math.isfinite(v) for v in (
                        env.power_upper_w, env.power_lower_w, env.batch_tps_lower,
                        env.ttft_upper_ms, env.tpot_upper_ms)) or env.batch_tps_lower < 0:
                    raise ContinuationRejected("nonfinite action bounds")
                dt = min(left, (slot + 1) * period - elapsed)
                changed = selected.resolved_online_replica_ids() != previous.resolved_online_replica_ids()
                if changed and dwell > 1e-8:
                    raise ContinuationRejected("minimum replica dwell violated")
                contract = state.contract
                if contract is not None:
                    if (power is not None and math.isfinite(contract.ramp_limit_w_per_s)
                            and abs(env.power_upper_w - power) > contract.ramp_limit_w_per_s * dt + 1e-8):
                        raise ContinuationRejected("ramp bound violated")
                    if window.stage == "recovery":
                        recovery_s = window.recovery_elapsed_s + within
                        limit = contract.recovery_envelope_at(recovery_s)
                        reference = contract.reference_at(contract.event_s + recovery_s)
                        if math.isfinite(reference) and math.isfinite(contract.rebound_limit_w):
                            limit = min(limit, reference + contract.rebound_limit_w)
                        if env.power_upper_w > limit + 1e-8:
                            raise ContinuationRejected("recovery power envelope violated")
                reduction = env.guaranteed_reduction_w
                if window.stage == "event":
                    reference = contract.reference_at(window.event_elapsed_s + within) if contract else math.inf
                    if math.isfinite(reference):
                        reduction = reference - env.power_upper_w
                    balance += reduction * dt
                    settlement_s += dt
                    if window.closes_settlement and left - dt <= 1e-8:
                        if balance + 1e-7 < bid_w * settlement_s:
                            raise ContinuationRejected("committed settlement energy cannot be delivered")
                        balance, settlement_s = 0.0, 0.0
                new_debt = max(0.0, debt + (baseline_tps - env.batch_tps_lower) * dt)
                new_cohort = max(0.0, cohort - env.batch_tps_lower * dt)
                output.append(PlanStep(
                    len(output), window.stage, dt, selected, debt, new_debt,
                    reduction, env.batch_tps_lower, env.ttft_upper_ms, env.tpot_upper_ms,
                    cohort, new_cohort, env.power_upper_w,
                    window.closes_settlement and left - dt <= 1e-8,
                ))
                dwell = max(0.0, (self.parameters.replica_min_dwell_s if changed else dwell) - dt)
                debt, cohort, previous, power = new_debt, new_cohort, selected, env.power_upper_w
                elapsed += dt
                within += dt
                left -= dt
        if not output:
            raise ContinuationRejected("empty remaining horizon")
        if debt > self.parameters.terminal_tolerance_tokens + 1e-7:
            raise ContinuationRejected("terminal DR debt not repaid")
        if cohort > self.parameters.terminal_cohort_tolerance_tokens + 1e-7:
            raise ContinuationRejected("terminal cohort not completed")
        return tuple(output)

    def _protection(self, state, envelopes, started, solver_reason, validation_reason):
        # This is a *failure* path.  Minimize predicted event shortfall among
        # known SLO-safe, transition-compatible controls, not maximum throughput.
        candidates = []
        current = self.actions_by_name[state.current_action]
        dt = min(self.parameters.control_period_s, state.deadline_remaining_s)
        dt = max(dt, 1e-6)
        for env in envelopes:
            if not env.slo_safe or not math.isfinite(env.power_upper_w):
                continue
            changed = env.action.resolved_online_replica_ids() != current.resolved_online_replica_ids()
            if changed and state.replica_dwell_remaining_s > 1e-9:
                continue
            contract = state.contract
            if (contract and state.previous_power_w is not None
                    and abs(env.power_upper_w - state.previous_power_w)
                    > contract.ramp_limit_w_per_s * dt + 1e-8):
                continue
            if contract and state.event_remaining_s <= 0:
                t = contract.deadline_s - state.deadline_remaining_s
                limit = contract.recovery_envelope_at(max(0.0, t - contract.event_s))
                reference = contract.reference_at(t)
                if math.isfinite(reference) and math.isfinite(contract.rebound_limit_w):
                    limit = min(limit, reference + contract.rebound_limit_w)
                if env.power_upper_w > limit + 1e-8:
                    continue
            candidates.append(env)
        active_commitment = state.event_remaining_s > 0 and (state.committed_bid_w or 0) > 0
        if active_commitment:
            key = lambda e: (e.guaranteed_reduction_w, e.action.name == state.current_action)
        else:
            key = lambda e: (e.action.name == self.baseline_action, e.action.name == state.current_action,
                             -e.power_upper_w)
        chosen = max(candidates, key=key) if candidates else None
        action = chosen.action if chosen else current
        step = PlanStep(
            0, "event" if state.event_remaining_s > 0 else "recovery", dt, action,
            state.debt_tokens, state.debt_tokens,
            chosen.guaranteed_reduction_w if chosen else -math.inf,
            chosen.batch_tps_lower if chosen else 0.0,
            chosen.ttft_upper_ms if chosen else math.inf,
            chosen.tpot_upper_ms if chosen else math.inf,
            state.cohort_tokens, state.cohort_tokens,
            chosen.power_upper_w if chosen else math.inf,
        )
        return SupervisedPlan(
            False, float(state.committed_bid_w or 0.0), -math.inf, (step,),
            state.debt_tokens, (time.perf_counter() - started) * 1000,
            len(self.actions), len(candidates),
            "no validated continuation; delivery is not guaranteed", state.cohort_tokens,
            "UNVERIFIED_SERVICE_PROTECTION" if chosen else "NO_CERTIFIED_SAFE_ACTION",
            False, False, solver_reason, validation_reason,
            getattr(self.model, "deployment_status", "UNSPECIFIED_OR_SYNTHETIC"),
        )

    def solve(self, state: ControlState) -> SupervisedPlan:
        started = time.perf_counter()
        envelopes = self.envelopes(state)
        offset = self._cache_offset(state)
        cached = None
        rejection = "no applicable cached continuation"
        if offset is not None:
            try:
                cached = self.validate_schedule(
                    state, self._cached_plan.steps, envelopes, offset_s=offset,
                    bid_w=float(state.committed_bid_w or 0.0),
                )
            except ContinuationRejected as exc:
                rejection = str(exc)
        parameters = self.parameters
        self.parameters = replace(parameters, solve_budget_s=max(
            1e-6, parameters.solve_budget_s - (time.perf_counter() - started)))
        try:
            proposal = self._search(state)
        finally:
            self.parameters = parameters
        required = (proposal.committed_bid_w if state.committed_bid_w is None
                    else float(state.committed_bid_w))
        validated = None
        if proposal.feasible:
            try:
                validated = self.validate_schedule(state, proposal.steps, envelopes, bid_w=required)
            except ContinuationRejected as exc:
                rejection = "new plan rejected: " + str(exc)
        if validated is not None:
            status = "MODEL_VALIDATED_NEW_PLAN"
        elif cached is not None:
            validated, status = cached, "MODEL_VALIDATED_CACHED_CONTINUATION"
            required = float(state.committed_bid_w or 0.0)
        else:
            self._cached_plan = self._cached_state = None
            return self._protection(state, envelopes, started, proposal.reason, rejection)
        plan = SupervisedPlan(
            True, required, proposal.objective if status == "MODEL_VALIDATED_NEW_PLAN" else -math.inf,
            validated, validated[-1].backlog_after_tokens,
            (time.perf_counter() - started) * 1000, len(self.actions), len(envelopes),
            "model-validated schedule; no global optimality or physical-delivery certificate",
            validated[-1].cohort_after_tokens, status, True, False, proposal.reason, rejection,
            getattr(self.model, "deployment_status", "UNSPECIFIED_OR_SYNTHETIC"),
        )
        self._cached_plan, self._cached_state = plan, state
        return plan
