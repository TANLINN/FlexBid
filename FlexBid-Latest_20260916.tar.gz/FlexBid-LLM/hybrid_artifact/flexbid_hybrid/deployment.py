"""Fail-closed domain binding, NOT automatic hardware transfer or certification.

Metadata must originate from calibration/validation on the target environment.
An observation of hardware alone must never issue a TARGET_VALIDATED manifest.
The runtime currently measures NVML GPU power only; legacy component-power
models therefore cannot be silently reused or merely relabelled.
"""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import math
import platform
import subprocess
from pathlib import Path

from .config import resolve
from .modeling import HybridBounds, HybridPrediction

GPU_BOUNDARY = "gpu_nvml"
REQUIRED_RANGES = (
    "online_arrival_rate_rps", "prompt_tokens_mean", "prompt_tokens_max",
    "output_tokens_mean", "cache_prefix_fraction",
)


class DeploymentRejected(ValueError):
    pass


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def observe_environment(config, root, *, diagnostic_topology=False):
    """Read only. UUID binding deliberately requires revalidation on a new host.

    Model config/tokenizer hashes do not replace full weight-integrity checks.
    Network topology is local-host only: cross-node deployment is unsupported.
    """
    import pynvml

    def string(value):
        return value.decode() if isinstance(value, bytes) else str(value)

    pynvml.nvmlInit()
    try:
        gpus = []
        for index in config["hardware"]["gpu_indices"]:
            handle = pynvml.nvmlDeviceGetHandleByIndex(int(index))
            low, high = pynvml.nvmlDeviceGetPowerManagementLimitConstraints(handle)
            gpus.append({
                "index": int(index), "uuid": string(pynvml.nvmlDeviceGetUUID(handle)),
                "name": string(pynvml.nvmlDeviceGetName(handle)),
                "memory_bytes": int(pynvml.nvmlDeviceGetMemoryInfo(handle).total),
                "min_cap_w": low / 1000.0, "max_cap_w": high / 1000.0,
            })
        driver = string(pynvml.nvmlSystemGetDriverVersion())
    finally:
        pynvml.nvmlShutdown()
    model_dir = resolve(root, config["model"]["name"])
    tokenizer_dir = resolve(root, config["model"]["tokenizer"])
    files = {}
    for prefix, folder, names in (
        ("model", model_dir, ("config.json", "model.safetensors.index.json")),
        ("tokenizer", tokenizer_dir, ("tokenizer.json", "tokenizer_config.json")),
    ):
        for name in names:
            path = folder / name
            files[prefix + "/" + name] = sha256_file(path) if path.exists() else None
    if files["model/config.json"] is None:
        raise DeploymentRejected("model config missing")
    packages = {}
    for package in ("torch", "vllm", "transformers", "scikit-learn", "flash-attn"):
        try:
            packages[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            packages[package] = None
    from .development_environment import read_topology
    topology, topology_audit = read_topology(config, diagnostic_topology=diagnostic_topology)
    return {
        "scope": "single_host", "gpus": gpus, "driver": driver,
        "python": platform.python_version(), "packages": packages,
        "model_metadata_hashes": files, "local_topology": topology,
        **({"topology_observation": topology_audit} if diagnostic_topology else {}),
        "replicas": config["model"]["replicas"],
        "engine": {key: value for key, value in config["model"].items()
                   if key not in {"name", "tokenizer", "replicas"}},
        "runtime": config["runtime"],
        "batch": {key: config["workloads"][key]
                  for key in ("batch_prompt_tokens", "batch_output_tokens")},
        "feature_projection_s": config["dynamic_controller"].get("feature_projection_s"),
        "action_lattice": config["dynamic_controller"]["action_lattice"],
        "policy_settings": {
            key: value for key, value in config["dynamic_controller"].items()
            if key not in {"event_s", "deadline_s", "ems_contract", "runtime_results",
                           "surrogate_model", "baseline_dataset", "deployment_evidence", "force_baseline",
                           "deployment_mode", "allow_unvalidated_development", "external_commitments_enabled"}
        },
        "baseline_dataset_sha256": (
            sha256_file(resolve(root, config["dynamic_controller"]["baseline_dataset"]))
            if config["dynamic_controller"].get("baseline_dataset") else None
        ),
    }


def validate_domain(domain, environment, model_hash, source, model_boundary, root):
    if domain.get("schema_version") != 1 or domain.get("status") != "TARGET_VALIDATED":
        raise DeploymentRejected("missing target validation; observation is not a certificate")
    if model_boundary != GPU_BOUNDARY or domain.get("power_boundary") != GPU_BOUNDARY:
        raise DeploymentRejected("model/runtime power boundary mismatch or unspecified")
    if domain.get("model_sha256") != model_hash:
        raise DeploymentRejected("surrogate changed since target validation")
    if domain.get("environment") != environment:
        raise DeploymentRejected("environment changed; new calibration/validation required")
    if source not in domain.get("sources", []):
        raise DeploymentRejected("source outside validated domain")
    ranges = domain.get("feature_ranges_by_source", {}).get(source, {})
    if not set(REQUIRED_RANGES).issubset(ranges):
        raise DeploymentRejected("validated workload feature ranges missing")
    for name, bounds in ranges.items():
        if (not isinstance(bounds, list) or len(bounds) != 2
                or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in bounds)
                or bounds[0] > bounds[1]):
            raise DeploymentRejected("invalid domain range: " + name)
    evidence = domain.get("evidence_files", [])
    if not {"target_calibration", "target_validation"}.issubset(
            {item.get("role") for item in evidence}):
        raise DeploymentRejected("target calibration/validation evidence missing")
    for item in evidence:
        path = resolve(root, item["path"])
        if sha256_file(path) != item.get("sha256"):
            raise DeploymentRejected("evidence changed: " + str(path))
    # Hashes establish artifact identity, not statistical validity or accuracy.
    return ranges


class EnvironmentBoundModel:
    deployment_status = "TARGET_DOMAIN_METADATA_CHECKED_NOT_A_DELIVERY_CERTIFICATE"
    def __init__(self, base, source, ranges):
        self.base, self.source, self.ranges = base, source, ranges

    def __getattr__(self, name):
        return getattr(self.base, name)

    def in_domain(self, row):
        if row.get("source") != self.source:
            return False
        for name, (low, high) in self.ranges.items():
            try:
                value = float(row[name])
            except (KeyError, TypeError, ValueError):
                return False
            if not math.isfinite(value) or not low <= value <= high:
                return False
        return True

    def supports(self, row):
        supported = getattr(self.base, "supports", lambda _: False)
        return self.in_domain(row) and supported(row)

    def predict(self, row):
        if not self.supports(row):
            return HybridPrediction(0.0, math.inf, math.inf, 0.0)
        return self.base.predict(row)

    def bounds(self, row, mode):
        if not self.supports(row):
            return HybridBounds(-math.inf, math.inf, math.inf, math.inf, 0.0)
        return self.base.bounds(row, mode)


class DevelopmentModel:
    deployment_status = "UNVALIDATED_DEVELOPMENT_ONLY"

    def __init__(self, base):
        self.base = base

    def __getattr__(self, name):
        return getattr(self.base, name)


def bind_live_model(model, frozen_model, config, root, source, *, offline=False):
    dynamic = config["dynamic_controller"]
    if offline or dynamic.get("force_baseline") is True:
        # Offline predictions and a verified forced-zero-bid baseline may be
        # collected without claiming transfer of the old deployment evidence.
        return model
    if dynamic.get("deployment_mode") == "development":
        if (dynamic.get("allow_unvalidated_development") is not True
                or dynamic.get("external_commitments_enabled") is not False):
            raise DeploymentRejected("development requires explicit opt-in and no external commitments")
        if getattr(frozen_model, "power_boundary", None) != GPU_BOUNDARY:
            raise DeploymentRejected("development still requires a GPU-target fitted model; do not relabel old models")
        print("UNVALIDATED_DEVELOPMENT_ONLY: no external delivery claim; no deployment approval issued")
        return DevelopmentModel(model)
    metadata = dynamic.get("deployment_evidence")
    if not metadata:
        raise DeploymentRejected(
            "deployment_evidence absent: no live DR bidding with an unvalidated legacy model"
        )
    domain = json.loads(resolve(root, metadata).read_text(encoding="utf-8"))
    ranges = validate_domain(
        domain, observe_environment(config, root),
        sha256_file(resolve(root, dynamic["surrogate_model"])), source,
        getattr(frozen_model, "power_boundary", None), root,
    )
    return EnvironmentBoundModel(model, source, ranges)
