"""Extend one known development window from its original contiguous trace.

Never repeat/rescale the old window, alter its requests, or manufacture a quiet
tail. The original source must extend beyond the new cutoff; every old request
must reproduce under the same transform before any new trace is written.
"""
import json
import math
from pathlib import Path

from .deployment import sha256_file
from .io import atomic_json

BASE_ID = 'qwen_bailian:bailian-000009'
WINDOW_ID = BASE_ID + ':trajectory-window-0'
RAW_TO_REPLAY = 16.0  # historical transform; verified against ALL old requests


def _rows(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def reconstruct(old_episode, old_rows, raw_episode, raw_rows, duration_s=1950.):
    if (old_episode.get('episode_id') != WINDOW_ID or old_episode.get('base_episode_id') != BASE_ID
            or old_episode.get('source') != 'qwen_bailian'
            or old_episode.get('window_start_raw_s') != 0
            or old_episode.get('window_end_raw_s') != 120
            or raw_episode.get('episode_id') != BASE_ID or raw_episode.get('source') != 'qwen_bailian'
            or duration_s != 1950.):
        raise ValueError('Unexpected original episode/window; no substitute selected')
    if not raw_rows or not old_rows or old_episode.get('requests') != len(old_rows) or raw_episode.get('requests') != len(raw_rows):
        raise ValueError('Manifest/file request-count mismatch')
    raw_times = [float(r['arrival_ms']) for r in raw_rows]
    old_times = [float(r['arrival_ms']) for r in old_rows]
    if any(not math.isfinite(t) or t < 0 for t in raw_times + old_times):
        raise ValueError('Invalid arrival timestamp')
    if any(b < a for a,b in zip(raw_times,raw_times[1:])) or any(b < a for a,b in zip(old_times,old_times[1:])):
        raise ValueError('Input request ordering is not chronological')
    if not math.isclose(float(old_episode['duration_ms']), max(old_times)-min(old_times), abs_tol=1e-5):
        raise ValueError('Original observed-duration metadata differs')
    raw_cut_ms = duration_s * 1000 / RAW_TO_REPLAY
    if max(raw_times) < raw_cut_ms:
        raise ValueError('Original trace does not establish coverage beyond the new cutoff')
    ids = [str(r['request_id']) for r in raw_rows]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate request IDs in original trace')
    # Recognize only a constant namespace around the existing source ID.
    # Verify every old record, including parent links, before extrapolating it.
    first_id = str(old_rows[0]['request_id'])
    matched = [x for x in ids if x in first_id]
    if len(matched) != 1 or first_id.count(matched[0]) != 1:
        raise ValueError('Cannot uniquely reconstruct old request-ID namespace')
    prefix, suffix = first_id.split(matched[0])
    rename = lambda value: prefix + str(value) + suffix if value is not None else None
    prior_raw = [r for r in raw_rows if float(r['arrival_ms']) < 120000.]
    if len(prior_raw) != len(old_rows):
        raise ValueError('Original 120-second prefix differs; do not append incompatible data')
    old_map = {str(r['request_id']):r for r in old_rows}
    if len(old_map) != len(old_rows):
        raise ValueError('Duplicate request IDs in old generated trace')
    episode_values = {r.get('episode_id') for r in old_rows}
    if len(episode_values) != 1 or next(iter(episode_values)) not in (WINDOW_ID, BASE_ID):
        raise ValueError('Unrecognized per-request episode namespace')
    row_episode = next(iter(episode_values))
    def transform(row, remap_parent):
        value = dict(row)
        value['arrival_ms'] = float(row['arrival_ms']) * RAW_TO_REPLAY
        value['episode_id'] = row_episode
        value['request_id'] = rename(row['request_id'])
        if remap_parent and 'parent_request_id' in value:
            value['parent_request_id'] = rename(row['parent_request_id'])
        return value
    def equivalent(a,b):
        return (set(a) == set(b) and math.isclose(float(a['arrival_ms']),float(b['arrival_ms']),abs_tol=1e-5,rel_tol=1e-12)
            and {k:v for k,v in a.items() if k != 'arrival_ms'} == {k:v for k,v in b.items() if k != 'arrival_ms'})
    parent_modes = [mode for mode in (False,True) if all(
        rename(r['request_id']) in old_map and equivalent(transform(r,mode),old_map[rename(r['request_id'])]) for r in prior_raw)]
    if not parent_modes:
        raise ValueError('Old prefix does not reproduce exactly: tokens/session/parent/ID/timing transform differs')
    tail_raw = [r for r in raw_rows if 120000. <= float(r['arrival_ms']) < raw_cut_ms]
    tails = [[transform(r,mode) for r in tail_raw] for mode in parent_modes]
    if any(t != tails[0] for t in tails[1:]):
        raise ValueError('Parent-link transform ambiguous for new tail; no guessed mapping')
    tail = tails[0]
    result = old_rows + tail
    result_ids = [r['request_id'] for r in result]
    if len(result_ids) != len(set(result_ids)):
        raise ValueError('Extension duplicates request IDs')
    return result, dict(original_requests=len(old_rows), appended_requests=len(tail),
        prefix_records_exactly_preserved=True, all_prefix_fields_verified_against_raw=True,
        raw_to_replay_scale=RAW_TO_REPLAY, old_raw_end_s=120., new_raw_end_s=raw_cut_ms/1000,
        replay_coverage_end_s=duration_s, original_source_last_arrival_s=max(raw_times)/1000,
        extended_last_arrival_s=max(float(r['arrival_ms']) for r in result)/1000,
        parent_mapping='namespaced' if parent_modes[0] else 'unchanged',
        request_id_prefix=prefix, request_id_suffix=suffix,
        zero_tail_requests_is_not_missing_coverage=len(tail)==0,
        synthetic_requests_added=False, time_scale_changed=False,
        scope='reused development data; not independent calibration or confirmatory evidence')


def extend_development_trace(root, episode, output, arrival_scale):
    if arrival_scale != 1.:
        raise ValueError('Expected already-scaled generated trace; never rescale it again')
    root, output = Path(root).resolve(), Path(output).resolve()
    original_path = Path(episode['path'])
    source_manifest = root.parent / 'paper_artifact/data/adapted/manifest.json'
    manifest = json.loads(source_manifest.read_text(encoding='utf-8'))
    selected = [e for e in manifest['episodes'] if e['episode_id'] == BASE_ID and e['source'] == 'qwen_bailian']
    if len(selected) != 1:
        raise ValueError('Need exactly one original base trace in the restored adapted manifest')
    raw_episode = selected[0]
    raw_path = Path(raw_episode['path'])
    if not raw_path.is_absolute():
        raw_path = (source_manifest.parent/raw_path).resolve()
    before = {str(p):sha256_file(p) for p in (original_path,raw_path,source_manifest)}
    old_bytes = original_path.read_bytes()
    old_rows, raw_rows = _rows(original_path), _rows(raw_path)
    rows, audit = reconstruct(episode, old_rows, raw_episode, raw_rows)
    if before != {p:sha256_file(Path(p)) for p in before}:
        raise ValueError('Source changed while checking; no trace written')
    target = output/'development_trace_1950s.jsonl'
    tail = rows[len(old_rows):]
    encoded = ''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in tail).encode('utf-8')
    # Preserve the original file's bytes as a prefix, not merely equivalent JSON.
    data = old_bytes + (b'\n' if old_bytes and not old_bytes.endswith(b'\n') else b'') + encoded
    with target.open('xb') as stream:
        stream.write(data)
    generated = dict(episode, path=str(target), requests=len(rows),
        duration_ms=max(float(r['arrival_ms']) for r in rows)-min(float(r['arrival_ms']) for r in rows),
        window_end_raw_s=audit['new_raw_end_s'], declared_replay_coverage_ms=1950000.,
        trace_variant='development_contiguous_extension_1950s', original_trace_path=str(original_path),
        original_trace_sha256=before[str(original_path)], original_base_split=raw_episode['split'])
    audit.update(source_hashes=before, trace_path=str(target), trace_sha256=sha256_file(target),
        original_file_bytes_preserved_as_prefix=data.startswith(old_bytes), original_base_split=raw_episode['split'])
    atomic_json(output/'TRACE_EXTENSION_AUDIT.json',audit)
    print('TRACE_EXTENSION_READY '+json.dumps(audit,ensure_ascii=False),flush=True)
    return generated, audit
