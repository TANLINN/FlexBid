"""Explicit research-only reference initialization for forced-zero-bid runs."""
import math
import time
from dataclasses import replace

from .io import atomic_json


def freeze_zero_bid_reference(loop, warmup_power_w):
    if loop.contract.reference_power_w:
        return  # Never overwrite a declared exogenous reference.
    if loop.force_baseline is not True:
        raise ValueError('Explicit same-boundary reference required for bidding; '
                         'zero-bid warmup reference cannot authorize a positive bid')
    if loop.event_session is not None or float(loop.committed_bid_w or 0) != 0:
        raise ValueError('Reference initialization must precede the event and any bid')
    if (warmup_power_w is None or not math.isfinite(float(warmup_power_w))
            or float(warmup_power_w) <= 0):
        raise ValueError('No finite positive measured warmup power; event not started')
    frozen = replace(loop.contract, reference_power_w=(float(warmup_power_w),))
    atomic_json(loop.state_path.parent / 'ZERO_BID_REFERENCE.json', dict(
        reference_power_w=list(frozen.reference_power_w),
        frozen_wall_ns=time.time_ns(), meter_boundary='gpu_nvml',
        source='pre_event_warmup_gpu_mean', force_baseline=True,
        purpose='zero-bid integration diagnostic only',
        dr_baseline_validated=False, positive_bid_authorized=False))
    loop.contract = frozen
