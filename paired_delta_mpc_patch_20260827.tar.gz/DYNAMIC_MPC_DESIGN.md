# FlexBid Dynamic Viability MPC

## Production objective

FlexBid turns a hybrid online--batch LLM cluster into a feedback-controlled demand-
response resource.  An operator supplies an event duration and batch deadline.  The
controller computes the safe bid and actuator trajectory from live state; neither a
1100 W bid nor a particular pause/recovery action is embedded in the policy.

At re-planning time `t`, the state is

```
(workload features, online queue/tails, component power,
 batch debt, event time remaining, deadline time remaining, previous action)
```

and a joint action is

```
(online replica count, batch concurrency, per-GPU power cap)
```

The current gateway implements these controls without restarting model servers.  A
minimum dwell time separates slower replica routing from faster batch and cap control.

## Robust response envelope

During a baseline warm-up, the runtime measures the current component power, TTFT
p95, TPOT p99, and normal batch service.  For each profiled joint action, the
surrogate predicts the *paired change relative to that live baseline*: power
reduction, TTFT/TPOT increase, and batch-service change.  This removes workload-level
variation that is already observed at decision time instead of asking a global model
to predict it again.  Episode-level split conformal uses the maximum paired-effect
residual across every action and target, so subsequent action selection is covered.
Newly fitted artifacts persist their profiled actuator tuples; live optimization
rejects unprofiled tuples instead of relying on unsafe extrapolation.

Live residual adaptation can only widen the frozen interval:

- absolute power error expands both power tails;
- TTFT/TPOT under-prediction expands their upper tails; and
- batch-throughput over-prediction lowers the service bound.

This reacts safely to drift without claiming that online observations magically
improve the finite-sample guarantee.

## Event--recovery coupling

Let `mu_0` be normal batch service and `mu(a)` the risk-adjusted service under action
`a`.  Batch debt evolves as

```
B[t+1] = max(0, B[t] + (mu_0 - lower_mu(state[t], action[t])) * delta[t])
```

Event steps earn guaranteed power reduction.  Recovery steps trade component power
against service.  The terminal viability constraint is

```
B[deadline] <= tolerance
```

and every step must satisfy risk-adjusted online TTFT and TPOT limits.  Once a bid is
externally committed, every event action must retain at least that guaranteed
reduction.  The first planning pass derives the bid from the minimum guaranteed event
reduction, applies configurable derating and market quantization, and the feedback
loop then treats it as a hard commitment.

## Solver

The action lattice is Pareto-pruned over guaranteed reduction, lower batch service,
and upper SLO tails.  Backward viability is implemented as a finite-horizon dynamic
program over quantized batch debt, previous action, and replica dwell state.  The
controller applies only the first plan step and re-solves after each observation.

If no terminally viable plan exists, the controller explicitly reports infeasibility
and falls back to the SLO-safe action with the strongest batch service.  It never
silently converts an infeasible demand-response commitment into a successful result.

## Required evaluation

The dynamic controller must be compared against:

- no demand response;
- the existing static calibrated menu;
- the fixed threshold recovery controller;
- myopic minimum-power selection;
- an offline clairvoyant sequence oracle; and
- MPC without conformal calibration, without viability, and without live residuals.

Report bid delivery, online SLO and batch-deadline failures, reduction and energy,
solver latency, action switching, abstention, and the gap to the clairvoyant oracle on
untouched dynamic traces.  Static physical-gate results cannot substitute for this
closed-loop evaluation.
