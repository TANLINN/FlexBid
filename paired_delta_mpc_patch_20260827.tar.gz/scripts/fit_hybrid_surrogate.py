#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from flexbid_hybrid.modeling import (
    FEATURES,
    HybridSurrogate,
    PairedHybridSurrogate,
    build_dataset,
    read_csv,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile-results", type=Path, required=True)
    parser.add_argument("--ablation-results", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--alpha", type=float, default=0.05)
    args = parser.parse_args()

    args.output_root.mkdir(parents=True, exist_ok=True)
    dataset_path = args.output_root / "hybrid_surrogate_dataset.csv"
    build_dataset(
        [args.profile_results.resolve(), args.ablation_results.resolve()],
        dataset_path,
        expected_actions=8,
    )
    rows = read_csv(dataset_path)
    train = [row for row in rows if row["data_split"] == "train"]
    calibration = [row for row in rows if row["data_split"] == "calibration"]
    if len(train) != 160 or len(calibration) != 160:
        raise RuntimeError(
            f"expected 160 train and 160 calibration rows, found "
            f"{len(train)} and {len(calibration)}"
        )

    models = {
        "cross_layer": PairedHybridSurrogate(alpha=args.alpha),
        "workload_only": PairedHybridSurrogate(
            alpha=args.alpha,
            features=tuple(feature for feature in FEATURES if feature not in {
                "online_replicas", "batch_concurrency", "power_cap_w"
            }),
        ),
    }
    reports = {}
    for name, model in models.items():
        model.fit(train, calibration)
        model.save(args.output_root / f"{name}_surrogate.joblib")
        reports[name] = model.report(train, calibration)
        (args.output_root / f"{name}_surrogate_report.json").write_text(
            json.dumps(reports[name], indent=2), encoding="utf-8"
        )

    audit = {
        "status": "SURROGATES_READY",
        "dataset": str(dataset_path.resolve()),
        "train_rows": len(train),
        "calibration_rows": len(calibration),
        "models": list(models),
        "episode_cp_finite": all(
            report["conformal"]["finite"] for report in reports.values()
        ),
    }
    (args.output_root / "SURROGATE_FIT_COMPLETE.json").write_text(
        json.dumps(audit, indent=2), encoding="utf-8"
    )
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
