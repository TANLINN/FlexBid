#!/usr/bin/env python3
"""Offline, GPU-free viability-MPC planning over recorded workload episodes."""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flexbid_hybrid.adaptive_model import AdaptiveEnvelopeModel
from flexbid_hybrid.config import load_config, resolve
from flexbid_hybrid.io import atomic_json
from flexbid_hybrid.modeling import HybridSurrogate, read_csv
from flexbid_hybrid.mpc import (
    ControlState,
    MPCParameters,
    ViabilityMPC,
    build_action_lattice,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--dataset", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = ROOT
    config = load_config(args.config)
    settings = config["dynamic_controller"]
    dataset_path = args.dataset or resolve(root, settings["baseline_dataset"])
    rows = read_csv(dataset_path.resolve())
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        grouped[str(row["episode_id"])].append(row)
    frozen = HybridSurrogate.load(resolve(root, settings["surrogate_model"]))
    model = AdaptiveEnvelopeModel(frozen)
    actions = build_action_lattice(settings["action_lattice"])
    optimizer = ViabilityMPC(model, actions, MPCParameters(
        control_period_s=float(settings["control_period_s"]),
        calibration_mode=str(settings["calibration_mode"]),
        debt_quantum_tokens=float(settings["debt_quantum_tokens"]),
        terminal_tolerance_tokens=float(settings["terminal_tolerance_tokens"]),
        switch_penalty=float(settings["switch_penalty"]),
        recovery_power_weight=float(settings["recovery_power_weight"]),
        recovery_service_credit=float(settings["recovery_service_credit"]),
        maximum_states_per_step=int(settings["maximum_states_per_step"]),
        replica_min_dwell_s=float(settings.get("replica_min_dwell_s", 120.0)),
        solve_budget_s=float(settings.get("solve_budget_s", 10.0)),
    ))
    plans = []
    feature_names = tuple(frozen.features)
    for episode_id, episode_rows in sorted(grouped.items()):
        baseline = next(
            (row for row in episode_rows if row["name"] == "hybrid_full"), None
        )
        if baseline is None or not bool(baseline.get("slo_safe", True)):
            continue
        source = str(baseline["source"])
        slos = (
            config["slos"]["agentic"] if source == "tracelab"
            else config["slos"]["default"]
        )
        plan = optimizer.solve(ControlState(
            source=source,
            event_remaining_s=float(settings["event_s"]),
            deadline_remaining_s=float(settings["deadline_s"]),
            backlog_tokens=0.0,
            current_action="hybrid_full",
            ttft_slo_ms=float(slos["ttft_ms"]),
            tpot_slo_ms=float(slos["tpot_ms"]),
            workload_features={name: float(baseline.get(name) or 0) for name in feature_names},
            baseline_power_w=float(baseline["power_mean_w"]),
            baseline_ttft_ms=float(baseline["ttft_p95_ms"]),
            baseline_tpot_ms=float(baseline["tpot_p99_ms"]),
            baseline_batch_tps=float(baseline["batch_tokens_per_s"]),
        ))
        plans.append({
            "episode_id": episode_id,
            "source": source,
            **plan.as_dict(),
        })
    report = {
        "status": "DYNAMIC_MPC_OFFLINE_SIMULATION_COMPLETE",
        "episodes": len(plans),
        "feasible_episodes": sum(bool(plan["feasible"]) for plan in plans),
        "mean_committed_bid_w": (
            mean(float(plan["committed_bid_w"]) for plan in plans)
            if plans else 0.0
        ),
        "mean_solve_time_ms": (
            mean(float(plan["solve_time_ms"]) for plan in plans)
            if plans else 0.0
        ),
        "plans": plans,
    }
    atomic_json(args.output, report)
    print(json.dumps({key: value for key, value in report.items() if key != "plans"}, indent=2))


if __name__ == "__main__":
    main()
