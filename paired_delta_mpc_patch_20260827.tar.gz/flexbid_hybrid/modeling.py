from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from statistics import mean, pstdev
from typing import Iterable

from .analysis import summarize_cell
from .clients import load_trace
from .config import load_config
from .conformal import HybridJointCalibrator


TARGETS = (
    "power_mean_w",
    "ttft_p95_ms",
    "tpot_p99_ms",
    "batch_tokens_per_s",
)

FEATURES = (
    "source_azure_code",
    "source_azure_conversation",
    "source_qwen_bailian",
    "source_tracelab",
    "online_arrivals",
    "online_arrival_rate_rps",
    "prompt_tokens_sum",
    "prompt_tokens_mean",
    "prompt_tokens_max",
    "output_tokens_sum",
    "output_tokens_mean",
    "cache_prefix_fraction",
    "online_replicas",
    "batch_concurrency",
    "power_cap_w",
)


def _number(value, default: float = 0.0) -> float:
    return default if value in (None, "") else float(value)


def _matrix(rows: Iterable[dict], features: Iterable[str] = FEATURES):
    import numpy as np

    feature_names = tuple(features)
    return np.asarray([
        [_number(row.get(feature)) for feature in feature_names]
        for row in rows
    ], dtype=float)


def trace_features(path: Path, source: str, arrival_scale: float,
                   duration_s: float) -> dict[str, float]:
    rows = load_trace(path, arrival_scale, duration_s)
    prompts = [float(row["prompt_tokens"]) for row in rows]
    outputs = [float(row["max_output_tokens"]) for row in rows]
    prefixes = [float(row.get("cache_prefix_tokens") or 0) for row in rows]
    prompt_sum = sum(prompts)
    return {
        "source_azure_code": float(source == "azure_code"),
        "source_azure_conversation": float(source == "azure_conversation"),
        "source_qwen_bailian": float(source == "qwen_bailian"),
        "source_tracelab": float(source == "tracelab"),
        "online_arrivals": float(len(rows)),
        "online_arrival_rate_rps": len(rows) / duration_s,
        "prompt_tokens_sum": prompt_sum,
        "prompt_tokens_mean": mean(prompts),
        "prompt_tokens_max": max(prompts),
        "output_tokens_sum": sum(outputs),
        "output_tokens_mean": mean(outputs),
        "cache_prefix_fraction": 0.0 if prompt_sum <= 0 else sum(prefixes) / prompt_sum,
    }


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        for key in ("slo_safe",):
            if key in row:
                row[key] = str(row[key]).strip().lower() in {"1", "true", "yes"}
    return rows


def build_dataset(result_roots: list[Path], output: Path,
                  expected_actions: int | None = None) -> list[dict]:
    rows: list[dict] = []
    seen: set[tuple[str, str]] = set()
    feature_cache: dict[tuple[str, float, float], dict[str, float]] = {}
    for result in result_roots:
        manifest = json.loads((result / "campaign_manifest.json").read_text(encoding="utf-8"))
        config = load_config(Path(manifest["config"]))
        duration = float(config["workloads"]["measurement_s"])
        scales = config["workloads"]["arrival_scale_by_source"]
        for marker in sorted((result / "cells").glob("*/*/CELL_COMPLETE.json")):
            run_dir = marker.parent
            summary = summarize_cell(run_dir, config)
            cell = json.loads((run_dir / "cell.json").read_text(encoding="utf-8"))
            episode = cell["episode"]
            source = str(episode["source"])
            trace_path = Path(episode["path"])
            scale = float(scales[source])
            cache_key = (str(trace_path), scale, duration)
            if cache_key not in feature_cache:
                feature_cache[cache_key] = trace_features(
                    trace_path, source, scale, duration
                )
            key = (str(summary["episode_id"]), str(summary["name"]))
            if key in seen:
                raise RuntimeError(f"duplicate episode/action row: {key}")
            seen.add(key)
            rows.append({
                **summary,
                **feature_cache[cache_key],
                "trace_path": str(trace_path),
                "arrival_scale": scale,
                "slo_violation": int(not bool(summary["slo_safe"])),
            })
    by_episode: dict[str, set[str]] = defaultdict(set)
    for row in rows:
        by_episode[str(row["episode_id"])].add(str(row["name"]))
    baselines = {
        str(row["episode_id"]): row
        for row in rows
        if str(row["name"]) == "hybrid_full"
    }
    missing_baselines = sorted(set(by_episode) - set(baselines))
    if missing_baselines:
        raise RuntimeError(
            f"episodes missing hybrid_full baseline: {missing_baselines[:5]}"
        )
    # Persist the paired reference in every row.  The dynamic controller
    # predicts an action's *effect relative to the currently observed normal
    # operating point*, rather than trying to predict absolute tail latency
    # across unrelated workloads.  Keeping these columns in the frozen dataset
    # also makes offline replay self-contained and auditable.
    for row in rows:
        baseline = baselines[str(row["episode_id"])]
        row.update({
            "baseline_power_w": _number(baseline["power_mean_w"]),
            "baseline_ttft_ms": _number(baseline["ttft_p95_ms"]),
            "baseline_tpot_ms": _number(baseline["tpot_p99_ms"]),
            "baseline_batch_tps": _number(baseline["batch_tokens_per_s"]),
        })
    action_counts = Counter(len(actions) for actions in by_episode.values())
    if expected_actions is not None and action_counts != {expected_actions: len(by_episode)}:
        raise RuntimeError(f"incomplete action coverage: {dict(action_counts)}")
    split_episodes = Counter()
    for episode, actions in by_episode.items():
        split_name = next(str(row["data_split"]) for row in rows
                          if str(row["episode_id"]) == episode)
        split_episodes[split_name] += 1
    _write_csv(output, rows)
    report = {
        "rows": len(rows),
        "episodes": len(by_episode),
        "actions_per_episode": dict(action_counts),
        "episodes_by_split": dict(split_episodes),
        "sources": sorted({str(row["source"]) for row in rows}),
    }
    output.with_suffix(".report.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    return rows


@dataclass
class HybridPrediction:
    power_mean_w: float
    ttft_p95_ms: float
    tpot_p99_ms: float
    batch_tokens_per_s: float


@dataclass
class HybridBounds:
    power_lower_w: float
    power_upper_w: float
    ttft_upper_ms: float
    tpot_upper_ms: float
    batch_tokens_per_s_lower: float


@dataclass
class HybridSurrogate:
    alpha: float = 0.05
    features: tuple[str, ...] = FEATURES
    regressors: dict[str, object] = field(default_factory=dict)
    calibrator: HybridJointCalibrator | None = None
    supported_actions: tuple[tuple[int, int, float], ...] = ()

    def fit(self, train_rows: list[dict], calibration_rows: list[dict]) -> "HybridSurrogate":
        import numpy as np
        from sklearn.ensemble import HistGradientBoostingRegressor

        if len({row["episode_id"] for row in train_rows}) < 20:
            raise ValueError("at least 20 training episodes are required")
        if len({row["episode_id"] for row in calibration_rows}) < 20:
            raise ValueError("at least 20 calibration episodes are required for alpha=0.05")
        x_train = _matrix(train_rows, self.features)
        x_calibration = _matrix(calibration_rows, self.features)
        self.supported_actions = tuple(sorted({
            (
                int(float(row["online_replicas"])),
                int(float(row["batch_concurrency"])),
                float(row["power_cap_w"]),
            )
            for row in train_rows + calibration_rows
        }))
        for target in TARGETS:
            model = HistGradientBoostingRegressor(
                learning_rate=0.05,
                max_iter=400,
                max_leaf_nodes=15,
                min_samples_leaf=8,
                l2_regularization=1.0,
                random_state=20260822,
            )
            model.fit(x_train, np.asarray([_number(row[target]) for row in train_rows]))
            self.regressors[target] = model
        scales = {
            target: max(1.0, pstdev([_number(row[target]) for row in train_rows]))
            for target in TARGETS
        }
        calibration_predictions = {
            target: self.regressors[target].predict(x_calibration)
            for target in TARGETS
        }
        calibrated_rows = []
        for index, row in enumerate(calibration_rows):
            item = dict(row)
            for target in TARGETS:
                item[f"pred_{target}"] = float(calibration_predictions[target][index])
            calibrated_rows.append(item)
        self.calibrator = HybridJointCalibrator(self.alpha, scales=scales).fit(
            calibrated_rows,
            {target: f"pred_{target}" for target in TARGETS},
        )
        if not self.calibrator.finite:
            raise RuntimeError("episode conformal radius is infinite")
        return self

    def supports(self, row: dict) -> bool:
        """Whether post-selection conformal evidence covers this actuator tuple."""

        supported = getattr(self, "supported_actions", ())
        if not supported:
            # Backward compatibility for previously frozen artifacts.  New
            # models always persist their profiled support explicitly.
            return True
        key = (
            int(float(row["online_replicas"])),
            int(float(row["batch_concurrency"])),
            float(row["power_cap_w"]),
        )
        return key in supported

    def predict(self, row: dict) -> HybridPrediction:
        matrix = _matrix([row], self.features)
        values = {
            target: max(0.0, float(model.predict(matrix)[0]))
            for target, model in self.regressors.items()
        }
        return HybridPrediction(**values)

    def bounds(self, row: dict, mode: str) -> HybridBounds:
        prediction = self.predict(row)
        if self.calibrator is None:
            raise RuntimeError("surrogate is not calibrated")
        radius = self.calibrator.radius(mode, str(row.get("source") or "global"))
        scales = self.calibrator.scales
        return HybridBounds(
            power_lower_w=prediction.power_mean_w - radius * scales["power_mean_w"],
            power_upper_w=prediction.power_mean_w + radius * scales["power_mean_w"],
            ttft_upper_ms=prediction.ttft_p95_ms + radius * scales["ttft_p95_ms"],
            tpot_upper_ms=prediction.tpot_p99_ms + radius * scales["tpot_p99_ms"],
            batch_tokens_per_s_lower=max(
                0.0,
                prediction.batch_tokens_per_s
                - radius * scales["batch_tokens_per_s"],
            ),
        )

    def save(self, path: Path) -> None:
        import joblib

        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, path)

    @staticmethod
    def load(path: Path) -> "HybridSurrogate":
        import joblib

        value = joblib.load(path)
        if not isinstance(value, HybridSurrogate):
            raise TypeError(f"not a HybridSurrogate: {path}")
        return value

    def report(self, train_rows: list[dict], calibration_rows: list[dict]) -> dict:
        import numpy as np

        def metrics(rows: list[dict]) -> dict:
            values = {}
            for target in TARGETS:
                actual = np.asarray([_number(row[target]) for row in rows])
                predicted = np.asarray([getattr(self.predict(row), target) for row in rows])
                error = actual - predicted
                values[target] = {
                    "mae": float(np.mean(np.abs(error))),
                    "rmse": float(np.sqrt(np.mean(error ** 2))),
                    "r2": float(1 - np.sum(error ** 2) / max(1e-12, np.sum((actual - actual.mean()) ** 2))),
                }
            return values
        return {
            "alpha": self.alpha,
            "features": list(self.features),
            "targets": list(TARGETS),
            "supported_actions": [list(value) for value in self.supported_actions],
            "train_rows": len(train_rows),
            "train_episodes": len({row["episode_id"] for row in train_rows}),
            "calibration_rows": len(calibration_rows),
            "calibration_episodes": len({row["episode_id"] for row in calibration_rows}),
            "train_metrics": metrics(train_rows),
            "calibration_metrics": metrics(calibration_rows),
            "conformal": None if self.calibrator is None else self.calibrator.as_dict(),
        }


@dataclass
class PairedHybridSurrogate(HybridSurrogate):
    """Predict actuator effects relative to a measured baseline.

    Absolute online-tail metrics vary far more across workload episodes than
    the causal effect of an actuator.  Calibrating absolute predictions made a
    single difficult episode invalidate every action, including the measured
    baseline.  This model instead learns four paired effects:

    * baseline power minus action power (larger is better),
    * action TTFT minus baseline TTFT (smaller is better),
    * action TPOT minus baseline TPOT (smaller is better), and
    * action batch service minus baseline service (larger is better).

    Split-conformal scores still take the maximum over all actions in an
    episode, so action selection remains covered.  Runtime bounds are anchored
    to the warm-up baseline observation supplied in ``row``.
    """

    paired_effects: bool = True

    @staticmethod
    def _paired_rows(rows: list[dict]) -> list[dict]:
        baselines = {
            str(row["episode_id"]): row
            for row in rows
            if str(row["name"]) == "hybrid_full"
        }
        result = []
        for row in rows:
            episode = str(row["episode_id"])
            if episode not in baselines:
                raise ValueError(f"missing hybrid_full baseline for {episode}")
            baseline = baselines[episode]
            item = dict(row)
            item.update({
                "baseline_power_w": _number(baseline["power_mean_w"]),
                "baseline_ttft_ms": _number(baseline["ttft_p95_ms"]),
                "baseline_tpot_ms": _number(baseline["tpot_p99_ms"]),
                "baseline_batch_tps": _number(baseline["batch_tokens_per_s"]),
                # Reuse TARGETS internally so the existing joint calibrator
                # applies its directional tails to paired effects.
                "power_mean_w": (
                    _number(baseline["power_mean_w"])
                    - _number(row["power_mean_w"])
                ),
                "ttft_p95_ms": (
                    _number(row["ttft_p95_ms"])
                    - _number(baseline["ttft_p95_ms"])
                ),
                "tpot_p99_ms": (
                    _number(row["tpot_p99_ms"])
                    - _number(baseline["tpot_p99_ms"])
                ),
                "batch_tokens_per_s": (
                    _number(row["batch_tokens_per_s"])
                    - _number(baseline["batch_tokens_per_s"])
                ),
            })
            result.append(item)
        return result

    @staticmethod
    def _baseline(row: dict) -> tuple[float, float, float, float]:
        required = (
            "baseline_power_w", "baseline_ttft_ms",
            "baseline_tpot_ms", "baseline_batch_tps",
        )
        missing = [name for name in required if row.get(name) in (None, "")]
        if missing:
            raise ValueError(f"paired surrogate missing baseline inputs: {missing}")
        return tuple(_number(row[name]) for name in required)  # type: ignore[return-value]

    def fit(
        self, train_rows: list[dict], calibration_rows: list[dict],
    ) -> "PairedHybridSurrogate":
        paired_train = self._paired_rows(train_rows)
        paired_calibration = self._paired_rows(calibration_rows)
        super().fit(paired_train, paired_calibration)
        return self

    def _effect_prediction(self, row: dict) -> HybridPrediction:
        matrix = _matrix([row], self.features)
        values = {
            target: float(model.predict(matrix)[0])
            for target, model in self.regressors.items()
        }
        return HybridPrediction(**values)

    def predict(self, row: dict) -> HybridPrediction:
        base_power, base_ttft, base_tpot, base_batch = self._baseline(row)
        if str(row.get("name")) == "hybrid_full":
            return HybridPrediction(
                base_power, base_ttft, base_tpot, base_batch
            )
        effect = self._effect_prediction(row)
        return HybridPrediction(
            power_mean_w=max(0.0, base_power - effect.power_mean_w),
            ttft_p95_ms=max(0.0, base_ttft + effect.ttft_p95_ms),
            tpot_p99_ms=max(0.0, base_tpot + effect.tpot_p99_ms),
            batch_tokens_per_s=max(
                0.0, base_batch + effect.batch_tokens_per_s
            ),
        )

    def bounds(self, row: dict, mode: str) -> HybridBounds:
        base_power, base_ttft, base_tpot, base_batch = self._baseline(row)
        # The baseline is an observed MPC state, not a counterfactual model
        # prediction.  Live drift is handled by AdaptiveEnvelopeModel and
        # causes abstention/widening, never a narrower interval.
        if str(row.get("name")) == "hybrid_full":
            return HybridBounds(
                base_power, base_power, base_ttft, base_tpot, base_batch
            )
        if self.calibrator is None:
            raise RuntimeError("surrogate is not calibrated")
        effect = self._effect_prediction(row)
        radius = self.calibrator.radius(
            mode, str(row.get("source") or "global")
        )
        scales = self.calibrator.scales
        reduction_margin = radius * scales["power_mean_w"]
        ttft_margin = radius * scales["ttft_p95_ms"]
        tpot_margin = radius * scales["tpot_p99_ms"]
        batch_margin = radius * scales["batch_tokens_per_s"]
        reduction_lower = effect.power_mean_w - reduction_margin
        reduction_upper = effect.power_mean_w + reduction_margin
        return HybridBounds(
            power_lower_w=max(0.0, base_power - reduction_upper),
            power_upper_w=max(0.0, base_power - reduction_lower),
            ttft_upper_ms=max(
                0.0, base_ttft + effect.ttft_p95_ms + ttft_margin
            ),
            tpot_upper_ms=max(
                0.0, base_tpot + effect.tpot_p99_ms + tpot_margin
            ),
            batch_tokens_per_s_lower=max(
                0.0,
                base_batch + effect.batch_tokens_per_s - batch_margin,
            ),
        )

    def report(self, train_rows: list[dict], calibration_rows: list[dict]) -> dict:
        import numpy as np

        def metrics(rows: list[dict]) -> dict:
            baselines = {
                str(row["episode_id"]): row
                for row in rows
                if str(row["name"]) == "hybrid_full"
            }
            values = {}
            for target in TARGETS:
                actual = []
                predicted = []
                for row in rows:
                    baseline = baselines[str(row["episode_id"])]
                    model_row = dict(row)
                    model_row.update({
                        "baseline_power_w": _number(baseline["power_mean_w"]),
                        "baseline_ttft_ms": _number(baseline["ttft_p95_ms"]),
                        "baseline_tpot_ms": _number(baseline["tpot_p99_ms"]),
                        "baseline_batch_tps": _number(
                            baseline["batch_tokens_per_s"]
                        ),
                    })
                    actual.append(_number(row[target]))
                    predicted.append(getattr(self.predict(model_row), target))
                actual_array = np.asarray(actual)
                predicted_array = np.asarray(predicted)
                error = actual_array - predicted_array
                values[target] = {
                    "mae": float(np.mean(np.abs(error))),
                    "rmse": float(np.sqrt(np.mean(error ** 2))),
                    "r2": float(1 - np.sum(error ** 2) / max(
                        1e-12,
                        np.sum((actual_array - actual_array.mean()) ** 2),
                    )),
                }
            return values

        return {
            "alpha": self.alpha,
            "modeling_target": "paired_action_effect_relative_to_live_baseline",
            "features": list(self.features),
            "targets": list(TARGETS),
            "supported_actions": [list(value) for value in self.supported_actions],
            "train_rows": len(train_rows),
            "train_episodes": len({row["episode_id"] for row in train_rows}),
            "calibration_rows": len(calibration_rows),
            "calibration_episodes": len({
                row["episode_id"] for row in calibration_rows
            }),
            "train_metrics": metrics(train_rows),
            "calibration_metrics": metrics(calibration_rows),
            "conformal": (
                None if self.calibrator is None else self.calibrator.as_dict()
            ),
        }
