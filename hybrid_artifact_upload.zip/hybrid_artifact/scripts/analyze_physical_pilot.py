#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from flexbid_hybrid.analysis import analyze
from flexbid_hybrid.config import load_config


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    print(json.dumps(analyze(root, load_config(args.config)), indent=2))


if __name__ == "__main__":
    main()
