#!/usr/bin/env python3
from flexbid_hybrid.clients import online_main

if __name__ == "__main__":
    online_main()
