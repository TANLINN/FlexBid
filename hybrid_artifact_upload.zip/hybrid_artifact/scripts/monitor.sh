#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESULT="$ROOT/results/hybrid_physical_gate_a800_qwen35_27b"
cd "$ROOT"
date
printf 'cells: '
find "$RESULT/cells" -name CELL_COMPLETE.json -type f 2>/dev/null | wc -l
printf 'launcher: '
pgrep -af '[r]un_physical_pilot.py' || echo stopped
printf 'services: '
pgrep -af '[v]llm serve|flexbid_hybrid.gateway' | wc -l
if [[ -f "$RESULT/PHYSICAL_GATE.json" ]]; then
  cat "$RESULT/PHYSICAL_GATE.json"
else
  latest="$(find "$RESULT/cells" -name CELL_COMPLETE.json -type f -printf '%T@ %p\n' 2>/dev/null | sort -n | tail -n 1 | cut -d' ' -f2-)"
  echo "latest: ${latest:-none}"
fi
nvidia-smi --query-gpu=index,memory.used,utilization.gpu,power.draw,power.limit --format=csv
