#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CONFIG="${1:-$ROOT/configs/a800_8gpu_qwen35_27b_pilot.yaml}"
RESULT="$ROOT/results/hybrid_physical_gate_a800_qwen35_27b"

cd "$ROOT"
mkdir -p "$RESULT/logs"

restore_caps() {
  for gpu in 0 1 2 3 4 5 6 7; do
    default="$(nvidia-smi -i "$gpu" --query-gpu=power.default_limit --format=csv,noheader,nounits 2>/dev/null | head -n 1 | xargs || true)"
    if [[ -n "$default" ]]; then
      nvidia-smi -i "$gpu" -pl "$default" >/dev/null 2>&1 || true
    fi
  done
}
trap restore_caps EXIT INT TERM

python scripts/preflight.py --config "$CONFIG" --output "$RESULT/preflight.json"
python -m unittest discover -s tests -v
python -u scripts/run_physical_pilot.py --config "$CONFIG" --resume
python scripts/analyze_physical_pilot.py --config "$CONFIG" | tee "$RESULT/logs/analysis.log"
python - <<'PY'
import json
from pathlib import Path

root = Path("results/hybrid_physical_gate_a800_qwen35_27b")
gate = json.loads((root / "PHYSICAL_GATE.json").read_text())
(root / "PIPELINE_COMPLETE").write_text(gate["status"] + "\n")
PY
