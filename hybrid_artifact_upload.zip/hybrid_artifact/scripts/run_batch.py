#!/usr/bin/env python3
from flexbid_hybrid.clients import batch_main

if __name__ == "__main__":
    batch_main()
