#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from flexbid_hybrid.config import load_config
from flexbid_hybrid.pilot import run_pilot


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    result = run_pilot(root, args.config, load_config(args.config), args.resume)
    print(f"pilot complete: {result}")


if __name__ == "__main__":
    main()
