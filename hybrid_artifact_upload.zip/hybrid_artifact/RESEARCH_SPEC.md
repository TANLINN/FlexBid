# FlexBid-LLM Hybrid Online--Batch Research Specification

## Narrow research question

Given uncertain SLO-critical online traffic and deadline-constrained batch inference,
how much five-minute component-power reduction can an LLM cluster safely commit by
pausing batch work and consolidating online replicas, while preserving online TTFT/TPOT,
batch deadlines, and model output quality?

## Optimization target and variables

The upper layer maximizes a risk-calibrated five-minute reduction bid `B` minus grid,
online-SLO, and batch-deadline penalties. Its variables are the committed reduction,
online reserve, active replica count, and admitted batch service rate. The second-level
controller chooses online replica membership, batch pause/resume, prefill budget,
admission concurrency, and a last-mile GPU cap.

Control priority:

1. pause or reduce interruptible batch inference;
2. consolidate online traffic and idle whole replicas;
3. shape chunked prefill and concurrency;
4. use hardware power caps only for residual tracking.

Model quality, quantization, and output limits are fixed.

## Physical gate before algorithm work

The first experiment uses one 8xA800 node as four independent TP2 replicas of
Qwen3.5-27B. It pairs real online test episodes with continuously backlogged 8K/1K
batch summarization-style jobs and tests seven static actions for 300 seconds each.

The gate passes only if:

- at least 80% of episodes have a useful SLO-safe hybrid baseline;
- at least 80% have an SLO-safe controlled action; and
- the all-episode SLO-safe oracle mean reduction is at least 5%.

Ten percent is the target for a full paper campaign. A pass is not yet a complete DR
claim: the next phase must measure post-event catch-up and prove batch deadlines.

## Role of the previous TP8 campaign

The previous 645-profile/90-closed-loop campaign remains a negative result and
motivation: under a non-elastic single-replica TP8 deployment, the ex-post SLO-safe
oracle reduced five-minute mean power by only 0.409%. This establishes why replica-
level and workload-class controls are necessary; it is not used as positive evidence
for FlexBid.
