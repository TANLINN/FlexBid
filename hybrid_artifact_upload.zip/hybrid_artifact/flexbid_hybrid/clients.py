from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import random
import time
from pathlib import Path
from typing import Any


class PromptMaterializer:
    def __init__(self, tokenizer_name: str):
        from transformers import AutoTokenizer

        tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
        candidates = tokenizer.encode(
            " enterprise retrieval document summarization code tool evidence benchmark",
            add_special_tokens=False,
        )
        special = set(tokenizer.all_special_ids)
        self.pool = [item for item in candidates if item not in special]
        if not self.pool:
            raise RuntimeError("could not construct token pool")

    def materialize(self, identity: str, length: int) -> list[int]:
        seed = int(hashlib.sha256(identity.encode()).hexdigest()[:16], 16)
        rng = random.Random(seed)
        pattern = [rng.choice(self.pool) for _ in range(256)]
        return (pattern * ((length + 255) // 256))[:length]

    def online_tokens(self, row: dict[str, Any]) -> list[int]:
        count = int(row["prompt_tokens"])
        prefix_count = min(count, max(0, int(row.get("cache_prefix_tokens") or 0)))
        session = str(row.get("session_id") or row["request_id"])
        return (
            self.materialize("prefix:" + session, prefix_count)
            + self.materialize("suffix:" + str(row["request_id"]), count - prefix_count)
        )


def wait_for_wall(start_wall_ns: int) -> None:
    delay = (start_wall_ns - time.time_ns()) / 1e9
    if delay > 0:
        time.sleep(delay)


async def stream_completion(
    client: httpx.AsyncClient, api_base: str, model: str, prompt: list[int],
    output_tokens: int, request_class: str,
) -> dict[str, Any]:
    import httpx

    started = time.perf_counter_ns()
    dispatch_wall_ns = time.time_ns()
    first = previous = None
    gaps = []
    completion_tokens = 0
    error = None
    status = None
    payload = {
        "model": model, "prompt": prompt, "max_tokens": int(output_tokens),
        "temperature": 0.0, "ignore_eos": True, "stream": True,
        "stream_options": {"include_usage": True},
    }
    try:
        async with client.stream(
            "POST", f"{api_base.rstrip('/')}/completions", json=payload,
            headers={"X-FlexBid-Class": request_class},
        ) as response:
            status = response.status_code
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data = line[6:]
                if data == "[DONE]":
                    break
                message = json.loads(data)
                usage = message.get("usage")
                if usage:
                    completion_tokens = int(usage.get("completion_tokens") or completion_tokens)
                choices = message.get("choices") or []
                if choices and choices[0].get("text"):
                    now = time.perf_counter_ns()
                    if first is None:
                        first = now
                    if previous is not None:
                        gaps.append((now - previous) / 1e6)
                    previous = now
    except asyncio.CancelledError:
        error = "cancelled_at_measurement_boundary"
        raise
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    completed = time.perf_counter_ns()
    return {
        "dispatch_wall_time_ns": dispatch_wall_ns,
        "completion_wall_time_ns": dispatch_wall_ns + completed - started,
        "ttft_ms": None if first is None else (first - started) / 1e6,
        "mean_tpot_ms": sum(gaps) / len(gaps) if gaps else None,
        "max_tpot_ms": max(gaps) if gaps else None,
        "e2e_ms": (completed - started) / 1e6,
        "completion_tokens": completion_tokens,
        "status_code": status,
        "error": error,
    }


def load_trace(path: Path, arrival_scale: float, duration_s: float) -> list[dict]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip()]
    selected = []
    for row in rows:
        item = dict(row)
        item["arrival_ms"] = float(item["arrival_ms"]) * arrival_scale
        item["tool_delay_ms"] = float(item.get("tool_delay_ms") or 0) * arrival_scale
        if item["arrival_ms"] <= duration_s * 1000:
            selected.append(item)
    if not selected:
        raise ValueError(f"trace has no arrivals in measurement interval: {path}")
    return sorted(selected, key=lambda row: (row["arrival_ms"], row["request_id"]))


async def run_online(args) -> None:
    import httpx

    rows = load_trace(args.trace, args.arrival_scale, args.duration_s)
    materializer = PromptMaterializer(args.tokenizer)
    events = {row["request_id"]: asyncio.Event() for row in rows}
    completed_ns: dict[str, int] = {}
    start_mono_ns = time.perf_counter_ns()

    async with httpx.AsyncClient(
        timeout=httpx.Timeout(args.timeout_s),
        limits=httpx.Limits(max_connections=2048, max_keepalive_connections=256),
        headers={"Authorization": "Bearer EMPTY"},
    ) as client:
        async def issue(row: dict) -> dict:
            parent = row.get("parent_request_id")
            if parent in events:
                await events[parent].wait()
            target = start_mono_ns + int(float(row["arrival_ms"]) * 1e6)
            if parent in completed_ns:
                target = max(target, completed_ns[parent] + int(float(
                    row.get("tool_delay_ms") or 0
                ) * 1e6))
            delay = (target - time.perf_counter_ns()) / 1e9
            if delay > 0:
                await asyncio.sleep(delay)
            metric = await stream_completion(
                client, args.api_base, args.model, materializer.online_tokens(row),
                int(row["max_output_tokens"]), "online",
            )
            completed_ns[row["request_id"]] = time.perf_counter_ns()
            events[row["request_id"]].set()
            return {**row, **metric}

        values = await asyncio.gather(*(issue(row) for row in rows))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as stream:
        for value in values:
            stream.write(json.dumps(value, ensure_ascii=False) + "\n")


async def run_batch(args) -> None:
    import httpx

    materializer = PromptMaterializer(args.tokenizer)
    deadline = time.monotonic() + args.duration_s
    rows: list[dict] = []
    lock = asyncio.Lock()
    async with httpx.AsyncClient(
        timeout=None,
        limits=httpx.Limits(max_connections=256, max_keepalive_connections=64),
        headers={"Authorization": "Bearer EMPTY"},
    ) as client:
        async def worker(worker_id: int) -> None:
            job = 0
            while time.monotonic() < deadline:
                identity = f"batch:{worker_id}:{job}"
                try:
                    metric = await asyncio.wait_for(stream_completion(
                        client, args.api_base, args.model,
                        materializer.materialize(identity, args.prompt_tokens),
                        args.output_tokens, "batch",
                    ), timeout=max(0.01, deadline - time.monotonic()))
                except asyncio.TimeoutError:
                    break
                value = {
                    "worker_id": worker_id, "job_id": job,
                    "prompt_tokens": args.prompt_tokens,
                    "max_output_tokens": args.output_tokens,
                    **metric,
                }
                async with lock:
                    rows.append(value)
                job += 1

        await asyncio.gather(*(worker(index) for index in range(args.concurrency)))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8") as stream:
        for value in sorted(rows, key=lambda row: (row["worker_id"], row["job_id"])):
            stream.write(json.dumps(value, ensure_ascii=False) + "\n")


def online_main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--arrival-scale", type=float, default=1.0)
    parser.add_argument("--duration-s", type=float, required=True)
    parser.add_argument("--start-wall-ns", type=int, required=True)
    parser.add_argument("--timeout-s", type=float, default=900)
    args = parser.parse_args()
    wait_for_wall(args.start_wall_ns)
    asyncio.run(run_online(args))


def batch_main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--api-base", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--prompt-tokens", type=int, required=True)
    parser.add_argument("--output-tokens", type=int, required=True)
    parser.add_argument("--concurrency", type=int, required=True)
    parser.add_argument("--duration-s", type=float, required=True)
    parser.add_argument("--start-wall-ns", type=int, required=True)
    args = parser.parse_args()
    wait_for_wall(args.start_wall_ns)
    asyncio.run(run_batch(args))
