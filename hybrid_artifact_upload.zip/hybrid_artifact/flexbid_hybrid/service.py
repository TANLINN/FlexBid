from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
import urllib.request
from pathlib import Path


def post_json(url: str, value: dict | None = None, timeout_s: float = 120) -> dict:
    body = None if value is None else json.dumps(value).encode()
    request = urllib.request.Request(
        url, data=body, method="POST", headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(request, timeout=timeout_s) as response:
        payload = response.read()
    return json.loads(payload) if payload else {}


def get_json(url: str, timeout_s: float = 10) -> dict:
    with urllib.request.urlopen(url, timeout=timeout_s) as response:
        return json.loads(response.read())


def stop_process(process: subprocess.Popen | None, timeout_s: float = 30) -> None:
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGINT)
        process.wait(timeout=timeout_s)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=10)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=10)


def wait_http(url: str, processes: list[subprocess.Popen], timeout_s: float) -> None:
    deadline = time.monotonic() + timeout_s
    last_error = None
    while time.monotonic() < deadline:
        for process in processes:
            if process.poll() is not None:
                raise RuntimeError(f"service exited with {process.returncode}")
        try:
            get_json(url, 3)
            return
        except Exception as exc:
            last_error = exc
        time.sleep(2)
    raise TimeoutError(f"timed out waiting for {url}: {last_error}")


class ServiceGroup:
    def __init__(self, root: Path, config: dict, logs: Path):
        self.root = root
        self.config = config
        self.logs = logs
        self.processes: list[subprocess.Popen] = []
        self.handles = []

    def start(self) -> None:
        model = self.config["model"]
        runtime = self.config["runtime"]
        first_port = int(runtime["first_vllm_port"])
        ports = []
        self.logs.mkdir(parents=True, exist_ok=True)
        for replica_index, gpu_group in enumerate(model["replicas"]):
            port = first_port + replica_index
            ports.append(port)
            env = os.environ.copy()
            env["CUDA_VISIBLE_DEVICES"] = ",".join(map(str, gpu_group))
            command = [
                "vllm", "serve", model["name"], "--host", "127.0.0.1",
                "--port", str(port), "--tensor-parallel-size", str(len(gpu_group)),
                "--max-model-len", str(model["max_model_len"]),
                "--gpu-memory-utilization", str(model["gpu_memory_utilization"]),
                "--max-num-seqs", str(runtime["max_num_seqs"]),
                "--max-num-batched-tokens", str(runtime["max_num_batched_tokens"]),
                "--enable-chunked-prefill", "--enable-prefix-caching",
            ]
            if model.get("language_model_only"):
                command.append("--language-model-only")
            handle = (self.logs / f"vllm_replica_{replica_index}.log").open(
                "a", encoding="utf-8"
            )
            self.handles.append(handle)
            self.processes.append(subprocess.Popen(
                command, stdout=handle, stderr=subprocess.STDOUT,
                env=env, start_new_session=True,
            ))
        for port in ports:
            wait_http(f"http://127.0.0.1:{port}/health", self.processes,
                      float(runtime["startup_timeout_s"]))
            post_json(f"http://127.0.0.1:{port}/v1/completions", {
                "model": model["name"], "prompt": [1, 2, 3], "max_tokens": 8,
                "temperature": 0, "ignore_eos": True,
            })
            post_json(f"http://127.0.0.1:{port}/reset_prefix_cache")
        env = os.environ.copy()
        env["PYTHONPATH"] = str(self.root) + os.pathsep + env.get("PYTHONPATH", "")
        env["FLEXBID_HYBRID_CONTROL_FILE"] = self.config["hardware"]["control_file"]
        env["FLEXBID_HYBRID_UPSTREAMS"] = ",".join(
            f"http://127.0.0.1:{port}" for port in ports
        )
        env["FLEXBID_ONLINE_CONCURRENCY"] = str(runtime["online_concurrency"])
        env["FLEXBID_MAX_ONLINE_QUEUE"] = str(runtime["max_online_queue"])
        handle = (self.logs / "gateway.log").open("a", encoding="utf-8")
        self.handles.append(handle)
        self.processes.append(subprocess.Popen([
            sys.executable, "-m", "uvicorn", "flexbid_hybrid.gateway:app",
            "--host", "127.0.0.1", "--port", str(runtime["gateway_port"]),
        ], stdout=handle, stderr=subprocess.STDOUT, env=env, start_new_session=True))
        wait_http(f"http://127.0.0.1:{runtime['gateway_port']}/health",
                  self.processes, 120)

    def reset_caches(self) -> None:
        first_port = int(self.config["runtime"]["first_vllm_port"])
        for index in range(len(self.config["model"]["replicas"])):
            post_json(f"http://127.0.0.1:{first_port + index}/reset_prefix_cache")

    def wait_idle(self) -> None:
        url = f"http://127.0.0.1:{self.config['runtime']['gateway_port']}/flexbid/state"
        deadline = time.monotonic() + float(self.config["runtime"]["settle_timeout_s"])
        while time.monotonic() < deadline:
            state = get_json(url)
            if sum(state["inflight"]) == 0:
                return
            time.sleep(1)
        raise TimeoutError("gateway did not drain before next cell")

    def close(self) -> None:
        for process in reversed(self.processes):
            stop_process(process)
        for handle in self.handles:
            handle.close()

    def __enter__(self) -> "ServiceGroup":
        try:
            self.start()
        except BaseException:
            self.close()
            raise
        return self

    def __exit__(self, *_exc) -> None:
        self.close()
