from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class HybridAction:
    name: str
    online_replicas: int
    batch_concurrency: int
    power_cap_w: float

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("action name is required")
        if self.online_replicas <= 0:
            raise ValueError("online_replicas must be positive")
        if self.batch_concurrency < 0:
            raise ValueError("batch_concurrency cannot be negative")
        if self.power_cap_w <= 0:
            raise ValueError("power_cap_w must be positive")

    def as_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, value: dict) -> "HybridAction":
        return cls(
            name=str(value["name"]),
            online_replicas=int(value["online_replicas"]),
            batch_concurrency=int(value["batch_concurrency"]),
            power_cap_w=float(value["power_cap_w"]),
        )
