from __future__ import annotations

import json
import unittest
from pathlib import Path

from flexbid_hybrid.analysis import clipped_samples, integrate_j, percentile
from flexbid_hybrid.clients import load_trace
from flexbid_hybrid.types import HybridAction


class ActionTests(unittest.TestCase):
    def test_rejects_zero_online_replicas(self):
        with self.assertRaises(ValueError):
            HybridAction("bad", 0, 0, 400)

    def test_allows_paused_batch(self):
        self.assertEqual(HybridAction("pause", 2, 0, 300).batch_concurrency, 0)


class MeasurementTests(unittest.TestCase):
    def test_boundary_interpolation_and_energy(self):
        values = [(0, 100.0), (10_000_000_000, 200.0), (20_000_000_000, 100.0)]
        clipped = clipped_samples(values, 5_000_000_000, 15_000_000_000)
        self.assertEqual(clipped[0], (5_000_000_000, 150.0))
        self.assertEqual(clipped[-1], (15_000_000_000, 150.0))
        self.assertAlmostEqual(integrate_j(clipped), 1750.0)

    def test_exact_tail(self):
        self.assertEqual(percentile(list(range(1, 101)), 0.95), 95)


class TraceTests(unittest.TestCase):
    def test_arrival_scaling_and_crop(self):
        path = Path("tests/trace_test_runtime.jsonl")
        rows = [
            {"request_id": "a", "arrival_ms": 100, "prompt_tokens": 10,
             "max_output_tokens": 2},
            {"request_id": "b", "arrival_ms": 1000, "prompt_tokens": 10,
             "max_output_tokens": 2},
        ]
        try:
            path.write_text("".join(json.dumps(row) + "\n" for row in rows),
                            encoding="utf-8")
            selected = load_trace(path, 2.0, 1.0)
            self.assertEqual([row["request_id"] for row in selected], ["a"])
            self.assertEqual(selected[0]["arrival_ms"], 200)
        finally:
            path.unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main()
