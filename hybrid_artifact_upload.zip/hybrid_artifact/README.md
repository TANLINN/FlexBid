# FlexBid-LLM Hybrid Physical Gate

This directory is an independent successor to `paper_artifact`. It tests whether
hybrid online--batch serving exposes enough *physical* five-minute flexibility to
justify building the full risk-calibrated bidder. It does not overwrite the completed
TP8 campaign.

## What it runs

- Qwen3.5-27B on 8xA800 as four TP2 replicas;
- four held-out online episodes (Azure conversation, Azure code, Qwen API, TraceLab);
- continuously backlogged 8K-input/1K-output batch work;
- seven actions: full/half batch, batch pause, 3/2 active online replicas, and two
  last-mile 300 W cap variants;
- exact 300-second GPU NVML plus available CPU/DRAM RAPL measurement windows.

Expected runtime is roughly 2.5--4 hours after model startup (28 cells).

## Install and launch

The existing `paper_artifact/data/adapted` dataset and Qwen3.5-27B model are reused.

```bash
cd /root/workspace/FlexBid-LLM/hybrid_artifact
python -m pip install -e . --no-deps

mkdir -p results/hybrid_physical_gate_a800_qwen35_27b/logs
nohup bash scripts/launch_pilot.sh \
  > results/hybrid_physical_gate_a800_qwen35_27b/logs/launcher.log 2>&1 &
echo $! > results/hybrid_physical_gate_a800_qwen35_27b/launcher.pid
```

If the model lives elsewhere, edit `model.name` and `model.tokenizer` in the YAML.
If the adapted manifest lives elsewhere, edit `workloads.manifest`.

## Monitor and resume

```bash
bash scripts/monitor.sh
tail -f results/hybrid_physical_gate_a800_qwen35_27b/logs/launcher.log
```

The launcher always uses `--resume`; validated cells are never overwritten. Re-run
the same launch command after a recoverable failure.

Final decision files:

- `PHYSICAL_GATE.json`
- `PHYSICAL_GATE.md`
- `cell_summary.csv`
- `episode_oracle.csv`
- `PIPELINE_COMPLETE`
