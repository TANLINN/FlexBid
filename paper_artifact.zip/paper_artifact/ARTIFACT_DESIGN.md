# Experimental contract

The artifact enforces four evidence levels.

1. **Measured request metrics:** TTFT, inter-token gaps, completion errors and output tokens.
2. **Measured component metrics:** all participating GPU modules through NVML plus CPU/DRAM
   RAPL where exposed by the host kernel.
3. **Statistically calibrated claims:** episode is the exchangeability unit and its score is
   the maximum residual over windows/actions. Insufficient calibration produces an infinite
   radius and therefore a zero bid.
4. **Projected metrics:** PUE, operational carbon and GPU counts other than the measured
   eight-GPU node. Projection rows are labelled and cannot pass as hardware measurements.

The upper bidding loop commits

`B = max_a [ lower(P_default) - upper(P_a) - reserve ]_+`

subject to conformal upper bounds on TTFT and TPOT. The lower loop updates the coupled
action `(K, C, Pcap)` every second with hysteresis, protects decode from low caps when TPOT
slack is exhausted, releases K under TTFT pressure, and invokes a load-shedding/fallback
signal at extreme queue depth. Model weights, quantization and output length are unchanged.

The replayer uses the trace's observed output length only to reproduce the physical decode
work. That field is deliberately excluded from the bidding surrogate, so neither the upper
loop nor the controller receives future output length. The committed product is reduction
in **five-minute average measured component power** relative to a paired no-DR run.

The ex-ante workload forecast uses only the immediately preceding contiguous episode of the
same source (falling back to a train-split historical mean). Test episode features are opened
only after the bid for that episode has been produced; only the explicitly labelled
clairvoyant-workload surrogate benchmark
is allowed to use them before action selection.
