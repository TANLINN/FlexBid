from __future__ import annotations

import csv
import json
import math
import random
import subprocess
from collections import defaultdict
from pathlib import Path
from statistics import mean

from .actuation import atomic_write_json


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def _f(row: dict, key: str, default: float = 0.0) -> float:
    try:
        return float(row.get(key, default) or default)
    except ValueError:
        return default


def summarize_methods(rows: list[dict], carbon_intensities: list[float],
                      pue_values: list[float]) -> list[dict]:
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["model"], row["method"])].append(row)
    output = []
    for (model, method), values in sorted(grouped.items()):
        bids = [_f(row, "bid_w") for row in values]
        achieved = [_f(row, "achieved_reduction_w") for row in values]
        energy_kwh = sum(_f(row, "energy_j") for row in values) / 3.6e6
        item = {
            "model": model, "method": method, "episodes": len(values),
            "mean_bid_w": mean(bids), "mean_achieved_reduction_w": mean(achieved),
            "positive_bid_rate": mean(value > 0 for value in bids),
            "delivery_failure_rate": mean(_f(row, "delivery_failure") for row in values),
            "slo_window_violation_rate": (
                sum(_f(row, "slo_windows") for row in values)
                / max(1, sum(_f(row, "windows") for row in values))
            ),
            "max_ttft_p95_ms": max((_f(row, "ttft_p95_ms") for row in values), default=0),
            "max_tpot_p99_ms": max((_f(row, "tpot_p99_ms") for row in values), default=0),
            "component_energy_kwh": energy_kwh,
            "load_shed_requests": sum(_f(row, "load_shed_requests") for row in values),
            "load_shed_rate": (sum(_f(row, "load_shed_requests") for row in values)
                               / max(1, sum(_f(row, "requests") for row in values))),
        }
        for intensity in carbon_intensities:
            for pue in pue_values:
                item[f"operational_carbon_g_ci_{intensity:g}_pue_{pue:g}"] = energy_kwh * pue * intensity
        output.append(item)
    baseline_energy = {item["model"]: item["component_energy_kwh"]
                       for item in output if item["method"] == "no_dr"}
    for item in output:
        saved = (
            baseline_energy.get(item["model"], item["component_energy_kwh"])
            - item["component_energy_kwh"]
        )
        item["component_energy_saved_vs_no_dr_kwh"] = saved
        for intensity in carbon_intensities:
            for pue in pue_values:
                item[f"avoided_operational_carbon_g_ci_{intensity:g}_pue_{pue:g}"] = saved * pue * intensity
    return output


def conformal_audit(results: Path, summary_rows: list[dict]) -> list[dict]:
    actual = {(row["model"], row["episode_id"], row["method"]): row for row in summary_rows}
    baseline = {(row["model"], row["episode_id"]): _f(row, "power_mean_w")
                for row in summary_rows if row["method"] == "no_dr"}
    grouped = defaultdict(list)
    for bid_path in results.glob("closed_loop/*/*/*/bid.json"):
        decision = json.loads(bid_path.read_text(encoding="utf-8"))
        method = bid_path.parent.name
        if method not in {"flexbid_no_cp", "flexbid_row_cp", "flexbid_episode_cp"}:
            continue
        episode_slug = bid_path.parent.parent.name
        model_slug = bid_path.parent.parent.parent.name
        # Resolve via unique path slug to avoid relying on ':' on Windows.
        matches = [key for key in actual if key[2] == method
                   and key[1].replace(":", "_") == episode_slug
                   and key[0].replace("/", "_") == model_slug]
        for key in matches:
            model, episode, _ = key
            row = actual[key]
            controlled_upper = float(decision.get("controlled_upper_w", math.inf))
            baseline_lower = float(decision.get("baseline_lower_w", -math.inf))
            covered = (_f(row, "power_mean_w") <= controlled_upper
                       and baseline[(model, episode)] >= baseline_lower)
            grouped[(model, method)].append({
                "covered": covered,
                "conservatism_w": float(decision.get("expected_reduction_w", 0))
                                  - float(decision.get("committed_reduction_w", 0)),
            })
    return [{
        "model": model, "method": method, "episodes": len(values),
        "joint_power_coverage": mean(item["covered"] for item in values),
        "mean_conformal_conservatism_w": mean(item["conservatism_w"] for item in values),
    } for (model, method), values in sorted(grouped.items())]


def scale_projection(rows: list[dict], gpu_counts: list[int], seed: int,
                     bootstraps: int = 2000) -> list[dict]:
    """Bootstrap projection anchored to a measured 8-GPU node.

    Counts below eight are interpolation and counts above eight assume
    independent nodes. They are labelled projections, never hardware results.
    """
    rng = random.Random(seed)
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["model"], row["method"])].append(row)
    output = []
    for (model, method), values in sorted(grouped.items()):
        for count in gpu_counts:
            node_equiv = count / 8.0
            samples = []
            failures = []
            draws = max(1, math.ceil(node_equiv))
            for _ in range(bootstraps):
                selected = [rng.choice(values) for _ in range(draws)]
                scale = node_equiv / draws
                bid = sum(_f(row, "bid_w") for row in selected) * scale
                achieved = sum(_f(row, "achieved_reduction_w") for row in selected) * scale
                samples.append(bid)
                failures.append(achieved < bid)
            ordered = sorted(samples)
            output.append({
                "model": model, "method": method, "gpu_count": count,
                "evidence": "measured" if count == 8 else "bootstrap_projection_from_8gpu",
                "mean_bid_w": mean(samples),
                "bid_ci95_low_w": ordered[int(0.025 * (len(ordered) - 1))],
                "bid_ci95_high_w": ordered[int(0.975 * (len(ordered) - 1))],
                "projected_delivery_failure_rate": mean(failures),
            })
    return output


def write_csv(rows: list[dict], path: Path) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=sorted({key for row in rows for key in row}))
        writer.writeheader(); writer.writerows(rows)


def add_posthoc_best(rows: list[dict]) -> list[dict]:
    """Add an explicitly post-hoc envelope over policies that were really run."""
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["model"], row["episode_id"])].append(row)
    output = list(rows)
    for (_model, _episode), values in grouped.items():
        baseline = next(row for row in values if row["method"] == "no_dr")
        safe = [row for row in values if _f(row, "request_errors") == 0
                and _f(row, "load_shed_requests") == 0 and _f(row, "slo_windows") == 0]
        best = min(safe or [baseline], key=lambda row: _f(row, "power_mean_w"))
        item = dict(best)
        item["method"] = "posthoc_best_observed_tested_policy"
        achieved = _f(baseline, "power_mean_w") - _f(best, "power_mean_w")
        item["bid_w"] = achieved
        item["achieved_reduction_w"] = achieved
        item["delivery_failure"] = 0
        output.append(item)
    return output


def audit(results: Path, config: dict) -> dict:
    summary_path = results / "closed_loop_summary.csv"
    if not summary_path.exists():
        raise FileNotFoundError(summary_path)
    rows = read_csv(summary_path)
    analysis_rows = add_posthoc_best(rows)
    method_rows = summarize_methods(
        analysis_rows, [float(value) for value in config["evaluation"].get(
            "carbon_intensity_sensitivity_g_per_kwh",
            [config["evaluation"]["carbon_intensity_g_per_kwh"]]
        )],
        [float(value) for value in config["evaluation"]["pue_sensitivity"]],
    )
    coverage = conformal_audit(results, rows)
    scale = scale_projection(analysis_rows, [int(value) for value in config["evaluation"]["scale_gpu_counts"]],
                             int(config["seed"]))
    write_csv(method_rows, results / "paper_method_summary.csv")
    write_csv(coverage, results / "conformal_test_audit.csv")
    write_csv(scale, results / "scale_projection.csv")
    gpu = subprocess.run([
        "nvidia-smi", "--query-gpu=power.limit,power.default_limit",
        "--format=csv,noheader,nounits",
    ], text=True, capture_output=True, check=False)
    initial = json.loads((results / "preflight.json").read_text(encoding="utf-8"))
    initial_caps = [float(item["power.limit"]) for item in initial["devices"]]
    current_caps = [float(line.split(",")[0]) for line in gpu.stdout.splitlines() if line.strip()]
    restored = (gpu.returncode == 0 and len(current_caps) == len(initial_caps)
                and all(abs(left - right) <= 0.6 for left, right in zip(current_caps, initial_caps)))
    marker = json.loads((results / "CLOSED_LOOP_COMPLETE.json").read_text(encoding="utf-8"))
    telemetry_meta = [json.loads(path.read_text(encoding="utf-8"))
                      for path in results.glob("closed_loop/**/components.metadata.json")]
    rapl_variants = {tuple(item.get("rapl_domains", [])) for item in telemetry_meta}
    boundary_consistent = len(rapl_variants) <= 1 and bool(telemetry_meta)
    rapl_domains = list(next(iter(rapl_variants), ()))
    expected_runs = (int(marker.get("test_episodes", 0))
                     * len(marker.get("methods", [])) * len(config["models"]))
    identities = {(row["model"], row["episode_id"], row["method"]) for row in rows}
    cardinality_ok = len(rows) == expected_runs and len(identities) == expected_runs
    finite_power = all(math.isfinite(_f(row, "power_mean_w", math.nan)) for row in rows)
    report = {
        "passed": (marker.get("request_errors") == 0 and restored and bool(rows)
                   and boundary_consistent and cardinality_ok and finite_power),
        "closed_loop": marker, "gpu_power_restored": restored,
        "methods": len(method_rows), "coverage_rows": len(coverage),
        "scale_rows": len(scale),
        "measurement_boundary": "GPU NVML plus available CPU package/DRAM RAPL; not facility power",
        "rapl_domains": rapl_domains, "measurement_boundary_consistent": boundary_consistent,
        "expected_runs": expected_runs, "actual_unique_runs": len(identities),
        "cardinality_ok": cardinality_ok, "finite_power": finite_power,
        "carbon": ("operational component-boundary projection only; embodied carbon excluded; "
                   "a lower bound when CPU/DRAM RAPL are absent"),
    }
    atomic_write_json(results / "FINAL_AUDIT.json", report)
    if not report["passed"]:
        raise RuntimeError(f"final audit failed: {report}")
    return report
