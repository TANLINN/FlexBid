from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def make_freeze(paths: Iterable[Path], output: Path, metadata: dict | None = None) -> dict:
    files = {}
    for path in sorted({Path(item).resolve() for item in paths}):
        if not path.is_file():
            raise FileNotFoundError(path)
        files[str(path)] = sha256(path)
    value = {
        "schema_version": 1,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "files": files,
        "metadata": metadata or {},
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
    return value


def verify_freeze(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    failures = []
    for name, expected in value.get("files", {}).items():
        target = Path(name)
        if not target.is_file():
            failures.append({"path": name, "error": "missing"})
        else:
            actual = sha256(target)
            if actual != expected:
                failures.append({"path": name, "expected": expected, "actual": actual})
    if failures:
        raise RuntimeError(f"algorithm freeze verification failed: {failures}")
    return value

