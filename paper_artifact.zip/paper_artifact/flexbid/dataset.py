from __future__ import annotations

import csv
import json
import math
from collections import Counter
from pathlib import Path
from statistics import mean
from typing import Any


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, max(0, math.ceil(q * len(ordered)) - 1))]


def integrate(samples: list[tuple[int, float]]) -> float | None:
    if len(samples) < 2:
        return None
    return sum(
        (left_w + right_w) / 2 * (right_ns - left_ns) / 1e9
        for (left_ns, left_w), (right_ns, right_w) in zip(samples, samples[1:])
    )


def clip_samples(samples: list[tuple[int, float]], left: int,
                 right: int) -> list[tuple[int, float]]:
    """Linearly interpolate power at exact interval boundaries."""
    if len(samples) < 2:
        return []
    samples = sorted(samples)

    def at(target: int) -> float | None:
        for (t0, p0), (t1, p1) in zip(samples, samples[1:]):
            if t0 <= target <= t1:
                if t1 == t0:
                    return p1
                ratio = (target - t0) / (t1 - t0)
                return p0 + ratio * (p1 - p0)
        return None

    left_power, right_power = at(left), at(right)
    if left_power is None or right_power is None:
        return []
    return [(left, left_power)] + [(t, p) for t, p in samples if left < t < right] + [(right, right_power)]


def summarize_run(
    run_dir: Path, *, action: dict, split: str, episode_id: str,
    model: str, window_s: float = 5.0, measurement_duration_s: float | None = None,
) -> list[dict[str, Any]]:
    requests = [json.loads(line) for line in (run_dir / "requests.jsonl").read_text(
        encoding="utf-8"
    ).splitlines() if line.strip()]
    with (run_dir / "components.csv").open(newline="", encoding="utf-8") as stream:
        telemetry = list(csv.DictReader(stream))
    if not requests or len(telemetry) < 2:
        raise ValueError(f"empty or incomplete run: {run_dir}")
    power = [
        (int(row["wall_time_ns"]), float(row["observed_component_power_w"]))
        for row in telemetry if row.get("observed_component_power_w") not in (None, "")
    ]
    gpu_power = [
        (int(row["wall_time_ns"]), float(row["aggregate_gpu_power_w"]))
        for row in telemetry if row.get("aggregate_gpu_power_w") not in (None, "")
    ]
    if len(power) < 2:
        raise ValueError("component power boundary is unavailable")
    replay_starts = [
        int(row["dispatch_wall_time_ns"]) - int(float(row.get("actual_dispatch_ms") or 0) * 1e6)
        for row in requests if row.get("dispatch_wall_time_ns") is not None
    ]
    start = min(replay_starts) if replay_starts else min(time_ns for time_ns, _ in power)
    telemetry_end = max(time_ns for time_ns, _ in power)
    end = (start + int(measurement_duration_s * 1e9)
           if measurement_duration_s is not None else telemetry_end)
    if telemetry_end + int(0.25e9) < end:
        raise ValueError(f"telemetry does not cover fixed measurement interval: {run_dir}")
    window_ns = int(window_s * 1e9)
    rows = []
    index = 0
    while start + index * window_ns < end:
        left = start + index * window_ns
        right = left + window_ns
        arrived = [
            row for row in requests
            if left <= int(row["dispatch_wall_time_ns"]) < right
        ]
        component_samples = clip_samples(power, left, right)
        gpu_samples = clip_samples(gpu_power, left, right)
        component_w = [p for _, p in component_samples]
        gpu_w = [p for _, p in gpu_samples]
        prompt = [float(row["prompt_tokens"]) for row in arrived]
        output = [float(row["max_output_tokens"]) for row in arrived]
        ttft = [float(row["ttft_ms"]) for row in arrived if row.get("ttft_ms") is not None]
        tpot = [float(row["max_tpot_ms"]) for row in arrived if row.get("max_tpot_ms") is not None]
        groups = [str(row.get("workload_group") or "global") for row in arrived]
        group = max(set(groups), key=groups.count) if groups else "idle"
        active_prefill = sum(
            int(row["dispatch_wall_time_ns"]) <= left
            < int(row.get("first_token_wall_time_ns") or row["completion_wall_time_ns"])
            for row in requests
        )
        active_decode = sum(
            row.get("first_token_wall_time_ns") is not None
            and int(row["first_token_wall_time_ns"]) <= left
            < int(row["completion_wall_time_ns"])
            for row in requests
        )
        rows.append({
            "run_dir": str(run_dir), "model": model, "data_split": split,
            "episode_id": episode_id, "window_index": index,
            "workload_group": group,
            "chunk_budget_tokens": action["chunk_budget_tokens"],
            "power_cap_w": action["power_cap_w"],
            "admission_concurrency": action["admission_concurrency"],
            "arrivals": len(arrived), "arrival_rate_rps": len(arrived) / window_s,
            "prompt_tokens_sum": sum(prompt),
            "prompt_tokens_mean": mean(prompt) if prompt else 0,
            "prompt_tokens_max": max(prompt, default=0),
            "requested_output_budget_sum": sum(output),
            "active_prefill": active_prefill, "active_decode": active_decode,
            # Gateway queue occupancy is logged separately by the controller;
            # zero here means unavailable, not an oracle observation.
            "queued": 0,
            "cache_hit_rate": mean([
                float(row.get("cache_prefix_tokens") or 0) / max(1, float(row["prompt_tokens"]))
                for row in arrived
            ]) if arrived else 0,
            "agent_workflows": len({row.get("session_id") for row in arrived if row.get("workload_group") == "agentic"}),
            "power_mean_w": mean(component_w) if component_w else None,
            "power_p95_w": percentile(component_w, 0.95),
            "gpu_power_mean_w": mean(gpu_w) if gpu_w else None,
            "energy_j": integrate(component_samples),
            "gpu_energy_j": integrate(gpu_samples),
            "ttft_p95_ms": percentile(ttft, 0.95),
            "tpot_p99_ms": percentile(tpot, 0.99),
            "any_slo_violation": int(any(
                row.get("ttft_violation") or row.get("tpot_violation") for row in arrived
            )),
            "request_errors": sum(row.get("error") is not None and not row.get("load_shed") for row in arrived),
            "load_shed_requests": sum(bool(row.get("load_shed")) for row in arrived),
        })
        index += 1
    return rows


def write_rows(rows: list[dict[str, Any]], path: Path) -> None:
    if not rows:
        raise ValueError("zero dataset rows")
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def read_rows(path: Path) -> list[dict[str, Any]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def aggregate_episode_rows(rows: list[dict[str, Any]], episode_s: float = 300.0) -> list[dict[str, Any]]:
    """Convert 5-second telemetry windows to one response per episode/action.

    This keeps the surrogate's training unit identical to the upper loop's
    five-minute bidding unit. Window rows remain available for diagnostics.
    """
    grouped: dict[tuple, list[dict]] = {}
    keys = ("run_dir", "model", "data_split", "episode_id",
            "chunk_budget_tokens", "power_cap_w", "admission_concurrency")
    for row in rows:
        grouped.setdefault(tuple(row.get(key) for key in keys), []).append(row)
    output = []
    for identity, values in grouped.items():
        base = dict(zip(keys, identity))
        number = lambda row, key: float(row.get(key, 0) or 0)
        arrivals = sum(number(row, "arrivals") for row in values)
        prompt_sum = sum(number(row, "prompt_tokens_sum") for row in values)
        weights = max(1.0, arrivals)
        power = [number(row, "power_mean_w") for row in values if row.get("power_mean_w") not in (None, "")]
        ttft = [number(row, "ttft_p95_ms") for row in values if row.get("ttft_p95_ms") not in (None, "")]
        tpot = [number(row, "tpot_p99_ms") for row in values if row.get("tpot_p99_ms") not in (None, "")]
        groups = [str(row.get("workload_group")) for row in values
                  if row.get("workload_group") not in (None, "", "idle")]
        output.append({**base,
            "workload_group": Counter(groups).most_common(1)[0][0] if groups else "idle",
            "arrivals": arrivals, "arrival_rate_rps": arrivals / episode_s,
            "prompt_tokens_sum": prompt_sum,
            "prompt_tokens_mean": prompt_sum / weights,
            "prompt_tokens_max": max(number(row, "prompt_tokens_max") for row in values),
            "requested_output_budget_sum": sum(number(row, "requested_output_budget_sum") for row in values),
            "active_prefill": sum(number(row, "active_prefill") for row in values) / len(values),
            "active_decode": sum(number(row, "active_decode") for row in values) / len(values),
            "queued": sum(number(row, "queued") for row in values) / len(values),
            "cache_hit_rate": sum(number(row, "cache_hit_rate") * number(row, "arrivals")
                                  for row in values) / weights,
            "agent_workflows": sum(number(row, "agent_workflows") for row in values),
            "power_mean_w": mean(power) if power else None,
            "ttft_p95_ms": max(ttft, default=None),
            "tpot_p99_ms": max(tpot, default=None),
            "energy_j": sum(number(row, "energy_j") for row in values),
            "any_slo_violation": max(int(number(row, "any_slo_violation")) for row in values),
            "request_errors": sum(int(number(row, "request_errors")) for row in values),
            "load_shed_requests": sum(int(number(row, "load_shed_requests")) for row in values),
        })
    return output
