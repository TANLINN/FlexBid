from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True, order=True)
class Action:
    """One cross-layer serving action."""

    chunk_budget_tokens: int
    power_cap_w: float
    admission_concurrency: int

    def __post_init__(self) -> None:
        if self.chunk_budget_tokens <= 0:
            raise ValueError("chunk_budget_tokens must be positive")
        if self.power_cap_w <= 0:
            raise ValueError("power_cap_w must be positive")
        if self.admission_concurrency <= 0:
            raise ValueError("admission_concurrency must be positive")

    @property
    def key(self) -> str:
        return f"k{self.chunk_budget_tokens}_p{self.power_cap_w:g}_c{self.admission_concurrency}"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class WorkloadState:
    timestamp_s: float
    arrivals: float
    arrival_rate_rps: float
    prompt_tokens_sum: float
    prompt_tokens_mean: float
    prompt_tokens_max: float
    requested_output_budget_sum: float
    active_prefill: float
    active_decode: float
    queued: float
    cache_hit_rate: float = 0.0
    agent_workflows: float = 0.0
    workload_group: str = "global"
    extra: dict[str, float] = field(default_factory=dict)

    def features(self) -> dict[str, float]:
        values = {
            "arrivals": self.arrivals,
            "arrival_rate_rps": self.arrival_rate_rps,
            "prompt_tokens_sum": self.prompt_tokens_sum,
            "prompt_tokens_mean": self.prompt_tokens_mean,
            "prompt_tokens_max": self.prompt_tokens_max,
            "requested_output_budget_sum": self.requested_output_budget_sum,
            "active_prefill": self.active_prefill,
            "active_decode": self.active_decode,
            "queued": self.queued,
            "cache_hit_rate": self.cache_hit_rate,
            "agent_workflows": self.agent_workflows,
        }
        values.update(self.extra)
        return values


@dataclass
class Prediction:
    power_mean_w: float
    ttft_p95_ms: float
    tpot_p99_ms: float
    slo_violation_probability: float
    energy_j: float | None = None


@dataclass
class PredictionBounds:
    power_lower_w: float
    power_upper_w: float
    ttft_upper_ms: float
    tpot_upper_ms: float
    slo_violation_probability_upper: float


@dataclass
class BidDecision:
    interval_id: str
    action: Action | None
    committed_reduction_w: float
    baseline_lower_w: float
    controlled_upper_w: float
    expected_reduction_w: float
    feasible: bool
    reason: str
    risk_alpha: float
    diagnostics: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["action"] = None if self.action is None else self.action.as_dict()
        return value


@dataclass
class RuntimeObservation:
    timestamp_s: float
    aggregate_power_w: float
    queue_depth: int
    active_prefill: int
    active_decode: int
    ttft_slack_ms: float
    tpot_slack_ms: float
    arrival_rate_rps: float


@dataclass
class ControlDecision:
    action: Action
    fallback: str | None
    reason: str
    diagnostics: dict[str, Any] = field(default_factory=dict)
