"""vLLM V1 custom scheduler with a runtime token-budget control file.

Launch vLLM with:
  --scheduler-cls flexbid.runtime_scheduler.FlexBidScheduler

The server must start with --max-num-batched-tokens equal to the largest K that
will be used. Runtime values only reduce max_num_scheduled_tokens and therefore
do not resize compiled buffers or KV-cache structures.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

from vllm.v1.core.sched.scheduler import Scheduler


class FlexBidScheduler(Scheduler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._flexbid_control_path = Path(
            os.environ.get("FLEXBID_CONTROL_FILE", "/tmp/flexbid-control.json")
        )
        self._flexbid_poll_s = float(os.environ.get("FLEXBID_SCHEDULER_POLL_S", "0.1"))
        self._flexbid_last_poll = 0.0
        self._flexbid_last_mtime_ns = -1
        self._flexbid_static_max = int(self.max_num_scheduled_tokens)

    def _flexbid_refresh(self) -> None:
        now = time.monotonic()
        if now - self._flexbid_last_poll < self._flexbid_poll_s:
            return
        self._flexbid_last_poll = now
        try:
            stat = self._flexbid_control_path.stat()
            if stat.st_mtime_ns == self._flexbid_last_mtime_ns:
                return
            payload = json.loads(self._flexbid_control_path.read_text(encoding="utf-8"))
            requested = int(payload["chunk_budget_tokens"])
            # At least one token per active sequence keeps decode progress legal.
            minimum = max(1, int(self.max_num_running_reqs))
            if not minimum <= requested <= self._flexbid_static_max:
                raise ValueError(
                    f"runtime K={requested} outside [{minimum}, {self._flexbid_static_max}]"
                )
            self.max_num_scheduled_tokens = requested
            self._flexbid_last_mtime_ns = stat.st_mtime_ns
        except FileNotFoundError:
            return
        except Exception:
            # Never crash the serving engine because of a malformed control
            # update. Keep the last verified value; the controller audit log
            # records the rejected action separately.
            return

    def schedule(self, *args, **kwargs):
        self._flexbid_refresh()
        return super().schedule(*args, **kwargs)
