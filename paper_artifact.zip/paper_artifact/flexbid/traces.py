from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable


@dataclass
class TraceRequest:
    request_id: str
    arrival_ms: float
    prompt_tokens: int
    max_output_tokens: int
    workload_group: str
    source: str
    session_id: str | None = None
    parent_request_id: str | None = None
    workflow_step: int | None = None
    tool_delay_ms: float = 0.0
    cache_prefix_tokens: int = 0
    ttft_slo_ms: float = 5000.0
    tpot_slo_ms: float = 100.0
    episode_id: str = "episode-0"

    def __post_init__(self) -> None:
        if self.arrival_ms < 0 or self.prompt_tokens <= 0 or self.max_output_tokens <= 0:
            raise ValueError(f"invalid trace request: {self}")


def _first(row: dict[str, Any], names: Iterable[str], default=None):
    normalized = {str(key).strip().lower().replace("_", " "): value for key, value in row.items()}
    for name in names:
        key = name.strip().lower().replace("_", " ")
        if key in normalized and normalized[key] not in (None, ""):
            return normalized[key]
    return default


def _number(value: Any, default: float = 0.0) -> float:
    if value in (None, "", "null", "None"):
        return default
    return float(value)


def _timestamp(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        text = str(value).replace("Z", "+00:00")
        return datetime.fromisoformat(text).timestamp()


def _row_timestamp(row: dict[str, Any], fallback: float) -> float:
    value = _first(row, [
        "timestamp", "start time", "start_time", "started at", "started_at", "created at"
    ])
    if value not in (None, ""):
        return _timestamp(value)
    events = row.get("timing_events")
    if isinstance(events, list) and events:
        event_value = _first(events[0], ["timestamp", "emitted at", "time", "at"])
        if event_value not in (None, ""):
            return _timestamp(event_value)
    return fallback


def _stable_id(prefix: str, *parts: Any) -> str:
    digest = hashlib.sha256("|".join(map(str, parts)).encode()).hexdigest()[:16]
    return f"{prefix}-{digest}"


def adapt_burstgpt(path: Path, episode_s: float = 300.0) -> list[TraceRequest]:
    with path.open(newline="", encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))
    if not rows:
        raise ValueError("empty BurstGPT trace")
    timestamps = [_number(_first(row, ["timestamp"])) for row in rows]
    origin = min(timestamps)
    output = []
    for index, (row, timestamp) in enumerate(zip(rows, timestamps)):
        prompt = int(_number(_first(row, ["request tokens", "input tokens"]), 1))
        generated = int(_number(_first(row, ["response tokens", "output tokens"]), 1))
        if generated <= 0:
            continue
        relative_s = timestamp - origin
        session = str(_first(row, ["session id"], "")) or None
        log_type = str(_first(row, ["log type"], "api")).lower()
        group = "conversation" if "conversation" in log_type else "api"
        output.append(TraceRequest(
            request_id=_stable_id("burst", index, timestamp, session),
            arrival_ms=relative_s * 1000,
            prompt_tokens=max(1, prompt), max_output_tokens=max(1, generated),
            workload_group=group, source="burstgpt", session_id=session,
            cache_prefix_tokens=max(0, int(prompt * 0.5)) if session else 0,
            episode_id=f"burst-{int(relative_s // episode_s):06d}",
        ))
    return output


def adapt_azure(path: Path, episode_s: float = 300.0) -> list[TraceRequest]:
    with path.open(newline="", encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))
    timestamps = [_number(_first(row, ["timestamp", "TIMESTAMP"])) for row in rows]
    origin = min(timestamps)
    output = []
    for index, (row, timestamp) in enumerate(zip(rows, timestamps)):
        relative = timestamp - origin
        output.append(TraceRequest(
            request_id=_stable_id("azure", index, timestamp),
            arrival_ms=relative * 1000,
            prompt_tokens=max(1, int(_number(_first(row, ["ContextTokens", "context tokens"]), 1))),
            max_output_tokens=max(1, int(_number(_first(row, ["GeneratedTokens", "generated tokens"]), 1))),
            workload_group="code" if "code" in path.name.lower() else "conversation",
            source="azure2024", episode_id=f"azure-{int(relative // episode_s):06d}",
        ))
    return output


def adapt_qwen_bailian(path: Path, episode_s: float = 300.0) -> list[TraceRequest]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    timestamps = [_number(_first(row, ["timestamp"])) for row in rows]
    origin = min(timestamps)
    output = []
    request_by_chat: dict[str, str] = {}
    blocks_by_chat: dict[str, list] = {}
    root_by_chat: dict[str, str] = {}
    for index, (row, timestamp) in enumerate(zip(rows, timestamps)):
        relative = timestamp - origin
        chat_id = str(_first(row, ["chat id"], "")) or None
        parent_chat = str(_first(row, ["parent chat id"], ""))
        if parent_chat in {"", "-1", "None"}:
            parent_chat = ""
        turn = int(_number(_first(row, ["turn"]), 0))
        request_id = _stable_id("bailian", chat_id, turn, index)
        parent = request_by_chat.get(parent_chat) if parent_chat else None
        root = root_by_chat.get(parent_chat, parent_chat) if parent_chat else (chat_id or request_id)
        hashes = list(_first(row, ["hash ids"], []) or [])
        parent_hashes = blocks_by_chat.get(parent_chat, [])
        common_blocks = 0
        for left, right in zip(hashes, parent_hashes):
            if left != right:
                break
            common_blocks += 1
        if chat_id:
            request_by_chat[chat_id] = request_id
            blocks_by_chat[chat_id] = hashes
            root_by_chat[chat_id] = root
        prompt = max(1, int(_number(_first(row, ["input length"]), 1)))
        output.append(TraceRequest(
            request_id=request_id, arrival_ms=relative * 1000,
            prompt_tokens=prompt,
            max_output_tokens=max(1, int(_number(_first(row, ["output length"]), 1))),
            workload_group="qwen_" + str(_first(row, ["type"], "text")),
            source="qwen_bailian", session_id=root,
            parent_request_id=parent, workflow_step=turn,
            cache_prefix_tokens=min(prompt, common_blocks * 16),
            episode_id=f"bailian-{int(relative // episode_s):06d}",
        ))
    return output


def adapt_tracelab(path: Path, episode_s: float = 300.0) -> list[TraceRequest]:
    """Adapt a TraceLab JSONL/CSV export using tolerant field aliases."""
    if path.suffix.lower() == ".csv":
        with path.open(newline="", encoding="utf-8-sig") as stream:
            rows = list(csv.DictReader(stream))
    else:
        rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows:
        raise ValueError("empty TraceLab trace")
    timestamps = [_row_timestamp(row, float(index)) for index, row in enumerate(rows)]
    origin = min(timestamps)
    output = []
    previous_by_session: dict[str, str] = {}
    for index, (row, timestamp) in enumerate(zip(rows, timestamps)):
        relative = timestamp - origin
        session = str(_first(row, [
            "session id", "session_id", "session key", "conversation id", "trace key"
        ], "unknown"))
        step = int(_number(_first(row, ["step", "step index", "request index"]), index))
        request_id = _stable_id("agent", session, step, index)
        parent = previous_by_session.get(session)
        previous_by_session[session] = request_id
        prefix = int(_number(_first(row, [
            "cached read tokens", "cache read tokens", "prefix tokens", "cache_read_input_tokens"
        ]), 0))
        append = int(_number(_first(row, ["append input tokens", "append tokens"]), 0))
        total_input = _first(row, ["input tokens", "prompt tokens"])
        prompt = int(_number(total_input, prefix + append if prefix + append else 1))
        output_tokens = int(_number(_first(row, ["output tokens", "completion tokens"]), 1))
        tool_ms = 1000 * _number(_first(row, ["tool latency s", "tool duration s"]), 0)
        tool_ms = _number(_first(row, ["tool latency ms", "tool duration ms"]), tool_ms)
        if tool_ms == 0 and isinstance(row.get("tools"), list):
            tool_ms = sum(_number(tool.get("tool_wall_latency_ms"), 0) for tool in row["tools"])
        output.append(TraceRequest(
            request_id=request_id, arrival_ms=relative * 1000,
            prompt_tokens=max(1, prompt), max_output_tokens=max(1, output_tokens),
            workload_group="agentic", source="tracelab", session_id=session,
            parent_request_id=parent, workflow_step=step, tool_delay_ms=max(0, tool_ms),
            cache_prefix_tokens=max(0, prefix),
            ttft_slo_ms=8000, tpot_slo_ms=120,
            episode_id=f"agent-{session}-{int(relative // episode_s):06d}",
        ))
    return output


ADAPTERS = {
    "burstgpt": adapt_burstgpt,
    "azure": adapt_azure,
    "qwen_bailian": adapt_qwen_bailian,
    "tracelab": adapt_tracelab,
}


def write_trace(rows: list[TraceRequest], output: Path) -> dict[str, Any]:
    output.parent.mkdir(parents=True, exist_ok=True)
    rows.sort(key=lambda row: (row.arrival_ms, row.request_id))
    with output.open("w", encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(asdict(row), ensure_ascii=False) + "\n")
    metadata = {
        "requests": len(rows),
        "episodes": len({row.episode_id for row in rows}),
        "sources": sorted({row.source for row in rows}),
        "workload_groups": sorted({row.workload_group for row in rows}),
        "duration_ms": max((row.arrival_ms for row in rows), default=0),
        "prompt_tokens": sum(row.prompt_tokens for row in rows),
        "output_tokens": sum(row.max_output_tokens for row in rows),
    }
    output.with_suffix(".metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    return metadata
