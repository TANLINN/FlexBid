from __future__ import annotations

import math
from dataclasses import dataclass

from .surrogate import ResponseSurrogate
from .types import Action, BidDecision, WorkloadState


@dataclass
class RiskCalibratedBidder:
    surrogate: ResponseSurrogate
    actions: list[Action]
    default_action: Action
    alpha: float = 0.05
    ttft_slo_ms: float = 5000.0
    tpot_slo_ms: float = 100.0
    max_slo_violation_probability: float = 0.05
    enforce_slo_classifier: bool = False
    reserve_margin_w: float = 0.0
    calibration_mode: str = "episode"

    def bid(self, interval_id: str, forecast: WorkloadState) -> BidDecision:
        baseline_prediction = self.surrogate.predict(forecast, self.default_action)
        baseline_bounds = self.surrogate.bounds(
            forecast, self.default_action, self.calibration_mode
        )
        baseline_lower = baseline_bounds.power_lower_w
        if not math.isfinite(baseline_lower):
            return self._zero(interval_id, "no finite baseline conformal bound")
        candidates = []
        for action in self.actions:
            prediction = self.surrogate.predict(forecast, action)
            bounds = self.surrogate.bounds(forecast, action, self.calibration_mode)
            safe_reduction = baseline_lower - bounds.power_upper_w - self.reserve_margin_w
            feasible = (
                math.isfinite(safe_reduction)
                and safe_reduction > 0
                and bounds.ttft_upper_ms <= self.ttft_slo_ms
                and bounds.tpot_upper_ms <= self.tpot_slo_ms
                and (
                    not self.enforce_slo_classifier
                    or bounds.slo_violation_probability_upper
                    <= self.max_slo_violation_probability
                )
            )
            candidates.append((safe_reduction, feasible, action, prediction, bounds))
        feasible = [candidate for candidate in candidates if candidate[1]]
        if not feasible:
            return self._zero(interval_id, "no action satisfies calibrated power and SLO constraints")
        safe_reduction, _, action, prediction, bounds = max(feasible, key=lambda item: item[0])
        return BidDecision(
            interval_id=interval_id,
            action=action,
            committed_reduction_w=max(0.0, safe_reduction),
            baseline_lower_w=baseline_lower,
            controlled_upper_w=bounds.power_upper_w,
            expected_reduction_w=baseline_prediction.power_mean_w - prediction.power_mean_w,
            feasible=True,
            reason="maximum safe calibrated reduction",
            risk_alpha=self.alpha,
            diagnostics={
                "ttft_upper_ms": bounds.ttft_upper_ms,
                "tpot_upper_ms": bounds.tpot_upper_ms,
                "slo_probability": bounds.slo_violation_probability_upper,
                "candidate_count": len(candidates),
                "feasible_candidate_count": len(feasible),
                "feasible_actions": [item[2].key for item in feasible],
            },
        )

    def _zero(self, interval_id: str, reason: str) -> BidDecision:
        return BidDecision(
            interval_id=interval_id, action=None, committed_reduction_w=0.0,
            baseline_lower_w=0.0, controlled_upper_w=math.inf,
            expected_reduction_w=0.0, feasible=False, reason=reason,
            risk_alpha=self.alpha,
        )
