from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

from .bidder import RiskCalibratedBidder
from .surrogate import ResponseSurrogate
from .types import Action, WorkloadState


def state_from_trace(path: Path, source: str, arrival_scale: float = 1.0,
                     duration_limit_s: float | None = None) -> WorkloadState:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    rows = [dict(row, arrival_ms=float(row["arrival_ms"]) * arrival_scale) for row in rows
            if duration_limit_s is None or float(row["arrival_ms"]) * arrival_scale <= duration_limit_s * 1000]
    if not rows:
        raise ValueError(f"scaled trace is empty: {path}")
    duration_s = (duration_limit_s if duration_limit_s is not None else
                  max(1.0, max(float(row["arrival_ms"]) for row in rows) / 1000))
    prompts = [float(row["prompt_tokens"]) for row in rows]
    groups = [str(row.get("workload_group") or source) for row in rows]
    return WorkloadState(
        timestamp_s=0, arrivals=len(rows), arrival_rate_rps=len(rows) / duration_s,
        prompt_tokens_sum=sum(prompts), prompt_tokens_mean=mean(prompts),
        prompt_tokens_max=max(prompts),
        requested_output_budget_sum=sum(float(row["max_output_tokens"]) for row in rows),
        active_prefill=0, active_decode=0, queued=0,
        cache_hit_rate=mean([
            float(row.get("cache_prefix_tokens") or 0) / max(1, float(row["prompt_tokens"]))
            for row in rows
        ]),
        agent_workflows=len({row.get("session_id") for row in rows if row.get("session_id")}),
        workload_group=Counter(groups).most_common(1)[0][0],
    )


class HistoricalForecaster:
    def __init__(self, arrival_scale_by_source: dict[str, float] | None = None,
                 duration_limit_s: float | None = None):
        self.by_source: dict[str, WorkloadState] = {}
        self.arrival_scale_by_source = arrival_scale_by_source or {}
        self.duration_limit_s = duration_limit_s

    def fit(self, episodes: list[dict]) -> "HistoricalForecaster":
        grouped = defaultdict(list)
        for episode in episodes:
            source = episode["source"]
            grouped[source].append(state_from_trace(
                Path(episode["path"]), source,
                self.arrival_scale_by_source.get(source, 1.0), self.duration_limit_s,
            ))
        for source, states in grouped.items():
            self.by_source[source] = WorkloadState(
                timestamp_s=0,
                arrivals=mean(s.arrivals for s in states),
                arrival_rate_rps=mean(s.arrival_rate_rps for s in states),
                prompt_tokens_sum=mean(s.prompt_tokens_sum for s in states),
                prompt_tokens_mean=mean(s.prompt_tokens_mean for s in states),
                prompt_tokens_max=mean(s.prompt_tokens_max for s in states),
                requested_output_budget_sum=mean(s.requested_output_budget_sum for s in states),
                active_prefill=0, active_decode=0, queued=0,
                cache_hit_rate=mean(s.cache_hit_rate for s in states),
                agent_workflows=mean(s.agent_workflows for s in states),
                workload_group=Counter(s.workload_group for s in states).most_common(1)[0][0],
            )
        return self

    def predict(self, source: str) -> WorkloadState:
        if source not in self.by_source:
            raise KeyError(f"unseen workload source: {source}")
        return self.by_source[source]

    def predict_episode(self, episode: dict, manifest: dict) -> WorkloadState:
        same_source = [item for item in manifest["episodes"]
                       if item["source"] == episode["source"]]
        index = next((i for i, item in enumerate(same_source)
                      if item["episode_id"] == episode["episode_id"]), -1)
        if index <= 0:
            return self.predict(episode["source"])
        previous = same_source[index - 1]
        source = episode["source"]
        return state_from_trace(
            Path(previous["path"]), source,
            self.arrival_scale_by_source.get(source, 1.0), self.duration_limit_s,
        )


def evaluate_bidders(
    surrogate: ResponseSurrogate, actions: list[Action], default_action: Action,
    manifest: dict, *, alpha: float, ttft_slo_ms: float, tpot_slo_ms: float,
    arrival_scale_by_source: dict[str, float] | None = None,
    duration_limit_s: float | None = None,
) -> list[dict]:
    train = [item for item in manifest["episodes"] if item["split"] == "train"]
    calibration_episodes = [item for item in manifest["episodes"] if item["split"] == "calibration"]
    test = [item for item in manifest["episodes"] if item["split"] == "test"]
    scales = arrival_scale_by_source or {}
    forecaster = HistoricalForecaster(scales, duration_limit_s).fit(train)
    min_cap = min(action.power_cap_w for action in actions)
    cap_only = [
        action for action in actions
        if action.chunk_budget_tokens == default_action.chunk_budget_tokens
        and action.admission_concurrency == default_action.admission_concurrency
    ] or [Action(default_action.chunk_budget_tokens, min_cap, default_action.admission_concurrency)]
    policies = {
        "flexbid_no_cp": (actions, "none", False),
        "flexbid_row_cp": (actions, "row", False),
        "flexbid_episode_cp": (actions, "episode", False),
        "power_cap_only": (cap_only, "episode", False),
        "pals_reactive": ([a for a in actions if a.chunk_budget_tokens == default_action.chunk_budget_tokens], "none", False),
        "workload_only": ([min(actions, key=lambda a: (a.power_cap_w, -a.chunk_budget_tokens))], "episode", False),
    }
    calibration_states = [
        state_from_trace(Path(item["path"]), item["source"],
                         scales.get(item["source"], 1.0), duration_limit_s)
        for item in calibration_episodes
    ]
    static_candidates = []
    for action in actions:
        reductions = []
        slo_safe = True
        for state in calibration_states:
            base = surrogate.bounds(state, default_action, "episode")
            controlled = surrogate.bounds(state, action, "episode")
            reductions.append(base.power_lower_w - controlled.power_upper_w)
            slo_safe &= controlled.ttft_upper_ms <= ttft_slo_ms and controlled.tpot_upper_ms <= tpot_slo_ms
        if reductions and slo_safe:
            static_candidates.append((min(reductions), action))
    static_bid, static_action = max(static_candidates, default=(0.0, default_action), key=lambda item: item[0])
    static_bid = max(0.0, static_bid)
    output = []
    for episode in test:
        forecast = forecaster.predict_episode(episode, manifest)
        actual = state_from_trace(Path(episode["path"]), episode["source"],
                                  scales.get(episode["source"], 1.0), duration_limit_s)
        default_prediction = surrogate.predict(actual, default_action)
        output.append({
            "episode_id": episode["episode_id"], "source": episode["source"],
            "method": "no_dr", "bid_w": 0.0, "action": default_action.key,
            "predicted_power_w": default_prediction.power_mean_w,
            "predicted_ttft_ms": default_prediction.ttft_p95_ms,
            "predicted_tpot_ms": default_prediction.tpot_p99_ms,
        })
        static_prediction = surrogate.predict(actual, static_action)
        output.append({
            "episode_id": episode["episode_id"], "source": episode["source"],
            "method": "static_conservative", "bid_w": static_bid,
            "action": static_action.key,
            "predicted_power_w": static_prediction.power_mean_w,
            "predicted_ttft_ms": static_prediction.ttft_p95_ms,
            "predicted_tpot_ms": static_prediction.tpot_p99_ms,
        })
        for method, (method_actions, calibration, enforce_classifier) in policies.items():
            bidder = RiskCalibratedBidder(
                surrogate=surrogate, actions=method_actions, default_action=default_action,
                alpha=alpha, ttft_slo_ms=ttft_slo_ms, tpot_slo_ms=tpot_slo_ms,
                calibration_mode=calibration,
                enforce_slo_classifier=enforce_classifier,
            )
            decision = bidder.bid(episode["episode_id"], forecast)
            prediction = surrogate.predict(actual, decision.action or default_action)
            output.append({
                "episode_id": episode["episode_id"], "source": episode["source"],
                "method": method, "bid_w": decision.committed_reduction_w,
                "action": (decision.action or default_action).key,
                "predicted_power_w": prediction.power_mean_w,
                "predicted_ttft_ms": prediction.ttft_p95_ms,
                "predicted_tpot_ms": prediction.tpot_p99_ms,
                "feasible": decision.feasible, "reason": decision.reason,
            })
        oracle = RiskCalibratedBidder(
            surrogate, actions, default_action, alpha=alpha,
            ttft_slo_ms=ttft_slo_ms, tpot_slo_ms=tpot_slo_ms,
            calibration_mode="none",
        ).bid(episode["episode_id"], actual)
        prediction = surrogate.predict(actual, oracle.action or default_action)
        output.append({
            "episode_id": episode["episode_id"], "source": episode["source"],
            "method": "clairvoyant_surrogate", "bid_w": oracle.committed_reduction_w,
            "action": (oracle.action or default_action).key,
            "predicted_power_w": prediction.power_mean_w,
            "predicted_ttft_ms": prediction.ttft_p95_ms,
            "predicted_tpot_ms": prediction.tpot_p99_ms,
            "feasible": oracle.feasible,
        })
    return output
