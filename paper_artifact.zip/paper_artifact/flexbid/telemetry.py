from __future__ import annotations

import argparse
import csv
import json
import re
import signal
import time
from datetime import datetime, timezone
from pathlib import Path

import pynvml


RUNNING = True


def _stop(_signum, _frame) -> None:
    global RUNNING
    RUNNING = False


def _read(path: Path) -> float | None:
    try:
        return float(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None


def _name(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return path.parent.name


def _slug(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def _safe(call):
    try:
        return call()
    except (pynvml.NVMLError, AttributeError):
        return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--interval-ms", type=int, default=100)
    args = parser.parse_args()
    if args.interval_ms < 20:
        parser.error("interval must be at least 20 ms")
    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    pynvml.nvmlInit()
    handles = [pynvml.nvmlDeviceGetHandleByIndex(i) for i in range(pynvml.nvmlDeviceGetCount())]
    rapl = []
    for path in sorted(Path("/sys/class/powercap").glob("intel-rapl:*/energy_uj")):
        value = _read(path)
        if value is not None:
            rapl.append({
                "path": path, "name": _name(path.parent / "name"), "previous": value,
                "max": _read(path.parent / "max_energy_range_uj"),
                "previous_ns": time.perf_counter_ns(),
                "column": f"rapl_{_slug(_name(path.parent / 'name'))}_{_slug(path.parent.name)}",
            })
    fields = ["wall_time_ns", "elapsed_ms", "sample_interval_ms"]
    for index in range(len(handles)):
        fields += [
            f"gpu{index}_power_w", f"gpu{index}_power_limit_w",
            f"gpu{index}_total_energy_mj", f"gpu{index}_util_pct",
            f"gpu{index}_temperature_c",
        ]
    fields += ["aggregate_gpu_power_w", "aggregate_gpu_total_energy_mj"]
    for domain in rapl:
        fields += [f"{domain['column']}_energy_uj", f"{domain['column']}_power_w"]
    fields += ["aggregate_cpu_package_power_w", "aggregate_dram_power_w", "observed_component_power_w"]
    metadata = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "gpu_count": len(handles), "interval_ms": args.interval_ms,
        "measurement_boundary": "NVML GPU modules + CPU package RAPL + DRAM RAPL",
        "excluded": ["motherboard", "NIC", "storage", "fans", "PSU loss", "cooling"],
        "rapl_domains": [domain["name"] for domain in rapl],
    }
    metadata_path = args.output.with_suffix(".metadata.json")
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    start = previous = time.perf_counter_ns()
    next_sample = start
    try:
        with args.output.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            stream.flush()
            while RUNNING:
                now = time.perf_counter_ns()
                if now < next_sample:
                    time.sleep((next_sample - now) / 1e9)
                    continue
                row = {
                    "wall_time_ns": time.time_ns(), "elapsed_ms": (now - start) / 1e6,
                    "sample_interval_ms": (now - previous) / 1e6,
                }
                powers, energies = [], []
                for index, handle in enumerate(handles):
                    power = _safe(lambda h=handle: pynvml.nvmlDeviceGetPowerUsage(h))
                    cap = _safe(lambda h=handle: pynvml.nvmlDeviceGetEnforcedPowerLimit(h))
                    energy = _safe(lambda h=handle: pynvml.nvmlDeviceGetTotalEnergyConsumption(h))
                    util = _safe(lambda h=handle: pynvml.nvmlDeviceGetUtilizationRates(h))
                    temp = _safe(lambda h=handle: pynvml.nvmlDeviceGetTemperature(h, pynvml.NVML_TEMPERATURE_GPU))
                    row[f"gpu{index}_power_w"] = None if power is None else power / 1000
                    row[f"gpu{index}_power_limit_w"] = None if cap is None else cap / 1000
                    row[f"gpu{index}_total_energy_mj"] = energy
                    row[f"gpu{index}_util_pct"] = getattr(util, "gpu", None)
                    row[f"gpu{index}_temperature_c"] = temp
                    if power is not None:
                        powers.append(power / 1000)
                    if energy is not None:
                        energies.append(float(energy))
                row["aggregate_gpu_power_w"] = sum(powers) if len(powers) == len(handles) else None
                row["aggregate_gpu_total_energy_mj"] = sum(energies) if len(energies) == len(handles) else None
                package, dram = [], []
                for domain in rapl:
                    current = _read(domain["path"])
                    power = None
                    if current is not None:
                        delta = current - domain["previous"]
                        if delta < 0 and domain["max"] is not None:
                            delta += domain["max"]
                        elapsed = (now - domain["previous_ns"]) / 1e9
                        power = delta / 1e6 / elapsed if elapsed > 0 and delta >= 0 else None
                        domain["previous"], domain["previous_ns"] = current, now
                    row[f"{domain['column']}_energy_uj"] = current
                    row[f"{domain['column']}_power_w"] = power
                    if power is not None and "package" in domain["name"]:
                        package.append(power)
                    if power is not None and "dram" in domain["name"]:
                        dram.append(power)
                row["aggregate_cpu_package_power_w"] = sum(package) if package else None
                row["aggregate_dram_power_w"] = sum(dram) if dram else None
                # GPU power is mandatory. CPU/DRAM are added when RAPL exposes
                # them; their absence does not silently invalidate GPU results.
                components = [row["aggregate_gpu_power_w"]]
                components += [value for value in (
                    row["aggregate_cpu_package_power_w"], row["aggregate_dram_power_w"]
                ) if value is not None]
                row["observed_component_power_w"] = (
                    sum(components) if row["aggregate_gpu_power_w"] is not None else None
                )
                writer.writerow(row)
                stream.flush()
                previous = now
                next_sample += args.interval_ms * 1_000_000
    finally:
        pynvml.nvmlShutdown()
        metadata["completed_utc"] = datetime.now(timezone.utc).isoformat()
        metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
