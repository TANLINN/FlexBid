from __future__ import annotations

from dataclasses import dataclass, field

from .types import Action, BidDecision, ControlDecision, RuntimeObservation


@dataclass
class SLOAwareController:
    """A hysteretic lower-loop policy over a discrete safe action set."""

    actions: list[Action]
    default_action: Action
    decode_power_cap_floor_w: float
    queue_fallback_threshold: int = 32
    power_deadband_w: float = 20.0
    min_action_hold_s: float = 2.0
    last_action: Action | None = None
    last_change_s: float = float("-inf")
    history: list[dict] = field(default_factory=list)

    def choose(self, observation: RuntimeObservation, bid: BidDecision) -> ControlDecision:
        if not bid.feasible or bid.action is None:
            action = self.default_action
            return self._record(observation, action, None, "zero-bid/default execution")
        target_power = bid.baseline_lower_w - bid.committed_reduction_w
        preferred = bid.action
        fallback = None
        if observation.queue_depth >= self.queue_fallback_threshold:
            fallback = "remote_route_or_reject"
        # Protect decode when TPOT slack is exhausted. Admission is reduced
        # before forcing a low cap on a memory-bound decode-heavy interval.
        decode_dominant = observation.active_decode > observation.active_prefill
        if decode_dominant and observation.tpot_slack_ms <= 0:
            candidates = [
                action for action in self.actions
                if action.power_cap_w >= self.decode_power_cap_floor_w
            ]
            if candidates:
                preferred = min(
                    candidates,
                    key=lambda action: (
                        action.admission_concurrency > preferred.admission_concurrency,
                        abs(action.chunk_budget_tokens - preferred.chunk_budget_tokens),
                        action.admission_concurrency,
                    ),
                )
        # If TTFT is already violated, release K before increasing concurrency.
        if observation.ttft_slack_ms <= 0:
            candidates = [
                action for action in self.actions
                if action.power_cap_w >= preferred.power_cap_w
                and action.admission_concurrency <= preferred.admission_concurrency
            ]
            if candidates:
                preferred = max(candidates, key=lambda action: action.chunk_budget_tokens)
        # Track a power overshoot by stepping toward a tighter cap and smaller
        # prefill budget; release in the opposite direction only inside the
        # SLO-safe envelope. This makes Pcap a coupled actuator, not a static
        # ablation knob.
        error = observation.aggregate_power_w - target_power
        if error > self.power_deadband_w:
            candidates = [
                action for action in self.actions
                if action.power_cap_w <= preferred.power_cap_w
                and action.chunk_budget_tokens <= preferred.chunk_budget_tokens
                and action.admission_concurrency <= preferred.admission_concurrency
                and (not decode_dominant or action.power_cap_w >= self.decode_power_cap_floor_w)
            ]
            if candidates:
                preferred = min(candidates, key=lambda action: (
                    abs(action.power_cap_w - max(
                        self.decode_power_cap_floor_w if decode_dominant else 0,
                        preferred.power_cap_w - error / max(1, len(self.actions))
                    )),
                    -action.chunk_budget_tokens,
                    -action.admission_concurrency,
                ))
        if (
            self.last_action is not None
            and observation.timestamp_s - self.last_change_s < self.min_action_hold_s
            and abs(observation.aggregate_power_w - target_power) <= self.power_deadband_w
        ):
            preferred = self.last_action
        reason = "track committed power target with phase/SLO protection"
        return self._record(observation, preferred, fallback, reason, target_power)

    def _record(
        self, observation: RuntimeObservation, action: Action,
        fallback: str | None, reason: str, target_power: float | None = None,
    ) -> ControlDecision:
        if action != self.last_action:
            self.last_action = action
            self.last_change_s = observation.timestamp_s
        decision = ControlDecision(
            action=action, fallback=fallback, reason=reason,
            diagnostics={"target_power_w": target_power},
        )
        self.history.append({
            "timestamp_s": observation.timestamp_s,
            "action": action.as_dict(), "fallback": fallback,
            "reason": reason, "target_power_w": target_power,
        })
        return decision
