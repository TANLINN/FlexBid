from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Iterable


def finite_sample_quantile(scores: Iterable[float], alpha: float) -> float:
    """Exact one-sided split-conformal order statistic.

    Returns infinity when there are too few exchangeable calibration units for
    the requested risk. This forces a zero bid instead of silently replacing
    the infinity atom by the observed maximum.
    """
    if not 0 < alpha < 1:
        raise ValueError("alpha must be in (0, 1)")
    ordered = sorted(float(score) for score in scores)
    if not ordered:
        return math.inf
    rank = math.ceil((len(ordered) + 1) * (1 - alpha))
    return math.inf if rank > len(ordered) else ordered[rank - 1]


@dataclass
class EpisodeCalibrator:
    """Selection-safe calibration using a whole episode as the unit.

    Each episode score is the maximum residual over all windows and candidate
    actions. Conditional groups can sharpen bounds, but fall back to the global
    radius when a group lacks the required number of episodes.
    """

    alpha: float = 0.05
    upper_global: float = math.inf
    lower_global: float = math.inf
    row_upper: float = math.inf
    row_lower: float = math.inf
    upper_by_group: dict[str, float] = field(default_factory=dict)
    lower_by_group: dict[str, float] = field(default_factory=dict)
    episode_count: int = 0

    def fit(
        self,
        rows: Iterable[dict],
        *,
        actual_key: str,
        predicted_key: str,
        episode_key: str = "episode_id",
        group_key: str = "workload_group",
    ) -> "EpisodeCalibrator":
        upper_episode: dict[str, list[float]] = defaultdict(list)
        lower_episode: dict[str, list[float]] = defaultdict(list)
        group_upper_episode: dict[tuple[str, str], list[float]] = defaultdict(list)
        group_lower_episode: dict[tuple[str, str], list[float]] = defaultdict(list)
        for row in rows:
            actual = float(row[actual_key])
            predicted = float(row[predicted_key])
            episode = str(row[episode_key])
            group = str(row.get(group_key) or "global")
            upper = actual - predicted
            lower = predicted - actual
            upper_episode[episode].append(upper)
            lower_episode[episode].append(lower)
            group_upper_episode[(group, episode)].append(upper)
            group_lower_episode[(group, episode)].append(lower)
        upper_scores = [max(values) for values in upper_episode.values()]
        lower_scores = [max(values) for values in lower_episode.values()]
        all_upper_rows = [value for values in upper_episode.values() for value in values]
        all_lower_rows = [value for values in lower_episode.values() for value in values]
        self.row_upper = finite_sample_quantile(all_upper_rows, self.alpha)
        self.row_lower = finite_sample_quantile(all_lower_rows, self.alpha)
        self.episode_count = len(upper_scores)
        self.upper_global = finite_sample_quantile(upper_scores, self.alpha)
        self.lower_global = finite_sample_quantile(lower_scores, self.alpha)
        grouped_upper: dict[str, list[float]] = defaultdict(list)
        grouped_lower: dict[str, list[float]] = defaultdict(list)
        for (group, _episode), values in group_upper_episode.items():
            grouped_upper[group].append(max(values))
        for (group, _episode), values in group_lower_episode.items():
            grouped_lower[group].append(max(values))
        self.upper_by_group = {
            group: finite_sample_quantile(values, self.alpha)
            for group, values in grouped_upper.items()
        }
        self.lower_by_group = {
            group: finite_sample_quantile(values, self.alpha)
            for group, values in grouped_lower.items()
        }
        return self

    def upper(self, prediction: float, group: str = "global") -> float:
        radius = self.upper_by_group.get(group, self.upper_global)
        if not math.isfinite(radius):
            radius = self.upper_global
        return prediction + radius

    def lower(self, prediction: float, group: str = "global") -> float:
        radius = self.lower_by_group.get(group, self.lower_global)
        if not math.isfinite(radius):
            radius = self.lower_global
        return prediction - radius

    def row_upper_bound(self, prediction: float) -> float:
        return prediction + self.row_upper

    def row_lower_bound(self, prediction: float) -> float:
        return prediction - self.row_lower

    @property
    def finite(self) -> bool:
        return math.isfinite(self.upper_global) and math.isfinite(self.lower_global)

    def as_dict(self) -> dict:
        return {
            "alpha": self.alpha,
            "episode_count": self.episode_count,
            "upper_global": self.upper_global,
            "lower_global": self.lower_global,
            "row_upper": self.row_upper,
            "row_lower": self.row_lower,
            "upper_by_group": self.upper_by_group,
            "lower_by_group": self.lower_by_group,
            "finite": self.finite,
        }


@dataclass
class JointEpisodeCalibrator:
    """One CP score jointly covers power, TTFT and TPOT constraints.

    Fixed unit scales do not use calibration labels, so the ordinary split
    conformal guarantee is retained. Each episode score is the maximum over
    rows/actions and over both power tails plus the two latency upper tails.
    """

    alpha: float = 0.05
    scales: dict[str, float] = field(default_factory=lambda: {
        "power_mean_w": 100.0, "ttft_p95_ms": 1000.0, "tpot_p99_ms": 10.0,
    })
    global_radius: float = math.inf
    row_radius: float = math.inf
    by_group: dict[str, float] = field(default_factory=dict)
    episode_count: int = 0

    def fit(self, rows: Iterable[dict], prediction_keys: dict[str, str],
            episode_key: str = "episode_id", group_key: str = "workload_group") -> "JointEpisodeCalibrator":
        episode_scores: dict[str, list[float]] = defaultdict(list)
        grouped_scores: dict[tuple[str, str], list[float]] = defaultdict(list)
        row_scores = []
        for row in rows:
            power = abs(float(row["power_mean_w"]) - float(row[prediction_keys["power_mean_w"]])) / self.scales["power_mean_w"]
            ttft = (float(row["ttft_p95_ms"]) - float(row[prediction_keys["ttft_p95_ms"]])) / self.scales["ttft_p95_ms"]
            tpot = (float(row["tpot_p99_ms"]) - float(row[prediction_keys["tpot_p99_ms"]])) / self.scales["tpot_p99_ms"]
            score = max(0.0, power, ttft, tpot)
            episode = str(row[episode_key]); group = str(row.get(group_key) or "global")
            row_scores.append(score)
            episode_scores[episode].append(score)
            grouped_scores[(group, episode)].append(score)
        maxima = [max(values) for values in episode_scores.values()]
        self.episode_count = len(maxima)
        self.global_radius = finite_sample_quantile(maxima, self.alpha)
        self.row_radius = finite_sample_quantile(row_scores, self.alpha)
        by_group: dict[str, list[float]] = defaultdict(list)
        for (group, _episode), values in grouped_scores.items():
            by_group[group].append(max(values))
        self.by_group = {group: finite_sample_quantile(values, self.alpha)
                         for group, values in by_group.items()}
        return self

    def radius(self, mode: str, group: str = "global") -> float:
        if mode == "row":
            return self.row_radius
        if mode != "episode":
            raise ValueError(mode)
        value = self.by_group.get(group, self.global_radius)
        return value if math.isfinite(value) else self.global_radius

    @property
    def finite(self) -> bool:
        return math.isfinite(self.global_radius)

    def as_dict(self) -> dict:
        return {"alpha": self.alpha, "scales": self.scales,
                "episode_count": self.episode_count, "global_radius": self.global_radius,
                "row_radius": self.row_radius, "by_group": self.by_group,
                "finite": self.finite}
