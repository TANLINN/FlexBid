from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Iterable

from .types import Action


def atomic_write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class PowerCapManager:
    """Per-GPU NVML power caps with verified restoration."""

    def __init__(self, gpu_indices: Iterable[int]):
        import pynvml

        self.nvml = pynvml
        self.nvml.nvmlInit()
        self.gpu_indices = list(gpu_indices)
        self.handles = {
            index: self.nvml.nvmlDeviceGetHandleByIndex(index)
            for index in self.gpu_indices
        }
        self.original_mw = {
            index: self.nvml.nvmlDeviceGetEnforcedPowerLimit(handle)
            for index, handle in self.handles.items()
        }
        self.closed = False

    def constraints_w(self) -> dict[int, tuple[float, float]]:
        result = {}
        for index, handle in self.handles.items():
            minimum, maximum = self.nvml.nvmlDeviceGetPowerManagementLimitConstraints(handle)
            result[index] = (minimum / 1000, maximum / 1000)
        return result

    def set_all(self, watts: float) -> dict[int, float]:
        result = {}
        for index, handle in self.handles.items():
            minimum, maximum = self.constraints_w()[index]
            if not minimum <= watts <= maximum:
                raise ValueError(f"GPU {index}: cap {watts} outside [{minimum}, {maximum}]")
            self.nvml.nvmlDeviceSetPowerManagementLimit(handle, int(round(watts * 1000)))
            enforced = self.nvml.nvmlDeviceGetEnforcedPowerLimit(handle) / 1000
            if abs(enforced - watts) > 0.6:
                raise RuntimeError(f"GPU {index}: requested {watts} W, enforced {enforced} W")
            result[index] = enforced
        return result

    def restore(self) -> dict[int, float]:
        result = {}
        for index, handle in self.handles.items():
            original = self.original_mw[index]
            self.nvml.nvmlDeviceSetPowerManagementLimit(handle, original)
            enforced = self.nvml.nvmlDeviceGetEnforcedPowerLimit(handle)
            if enforced != original:
                raise RuntimeError(f"GPU {index}: restoration was not verified")
            result[index] = enforced / 1000
        return result

    def close(self) -> None:
        if self.closed:
            return
        try:
            self.restore()
        finally:
            self.nvml.nvmlShutdown()
            self.closed = True

    def __enter__(self) -> "PowerCapManager":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()


class RuntimeActuator:
    def __init__(self, control_file: Path, gpu_indices: Iterable[int]):
        self.control_file = control_file
        self.power = PowerCapManager(gpu_indices)
        self.load_shed_queue_threshold: int | None = None

    def set_load_shed_threshold(self, value: int | None) -> None:
        self.load_shed_queue_threshold = value

    def apply(self, action: Action) -> dict:
        enforced = self.power.set_all(action.power_cap_w)
        payload = {
            **action.as_dict(),
            "enforced_power_caps_w": enforced,
        }
        if self.load_shed_queue_threshold is not None:
            payload["load_shed_queue_threshold"] = self.load_shed_queue_threshold
        atomic_write_json(self.control_file, payload)
        return payload

    def close(self) -> None:
        self.power.close()

    def __enter__(self) -> "RuntimeActuator":
        return self

    def __exit__(self, *_exc) -> None:
        self.close()
