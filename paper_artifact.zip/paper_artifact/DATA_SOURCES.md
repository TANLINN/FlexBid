# Public trace provenance

- BurstGPT v2.0: <https://github.com/HPMLL/BurstGPT/releases/tag/v2.0>
- Azure LLM inference trace 2024: <https://github.com/Azure/AzurePublicDataset/blob/master/AzureLLMInferenceDataset2024.md>
- Qwen-Bailian anonymous production trace: <https://github.com/alibaba-edu/qwen-bailian-usagetraces-anon>
- TraceLab v0.0.1: <https://github.com/uw-syfi/TraceLab/releases/tag/v0.0.1>

`scripts/fetch_public_traces.py` pins release URLs and verifies the published TraceLab
JSONL SHA-256. `data/adapted/manifest.json` records SHA-256 for every raw source actually
used. Preserve the corresponding dataset licenses and cite the papers named by upstream.
