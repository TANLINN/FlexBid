#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
RESULTS=results/paper_artifact_a100
echo "pid=$(cat "$RESULTS/launcher.pid" 2>/dev/null || echo unknown)"
test -f "$RESULTS/FINAL_AUDIT.json" && cat "$RESULTS/FINAL_AUDIT.json" || true
find "$RESULTS" -name CELL_COMPLETE.json -type f 2>/dev/null | wc -l
tail -n 40 "$RESULTS/logs/launcher.log" 2>/dev/null || true
nvidia-smi --query-gpu=index,name,power.draw,power.limit,utilization.gpu,memory.used \
  --format=csv,noheader || true

