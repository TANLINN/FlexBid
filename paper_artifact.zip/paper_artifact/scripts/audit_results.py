#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from flexbid.config import load_config, resolve_from_config
from flexbid.reporting import audit


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    report = audit(resolve_from_config(args.config, config["paths"]["results_root"]), config)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
