#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from huggingface_hub import snapshot_download

from flexbid.config import load_config


def main() -> None:
    parser = argparse.ArgumentParser(description="Fail-fast cache warmup for all campaign models")
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    repositories = []
    for model in config["models"]:
        repositories.extend([model["name"], model.get("tokenizer", model["name"])])
    for repository in dict.fromkeys(repositories):
        print(f"prefetching {repository}", flush=True)
        local_path = snapshot_download(repo_id=repository, resume_download=True)
        print(f"cached {repository} at {local_path}", flush=True)


if __name__ == "__main__":
    main()
