#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import asdict
from pathlib import Path

from flexbid.config import load_config, resolve_from_config
from flexbid.traces import ADAPTERS


def checksum(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def adapter_name(source: str) -> str:
    if source.startswith("azure"):
        return "azure"
    if source.startswith("qwen"):
        return "qwen_bailian"
    return source


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--overwrite", action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)
    workload = config["workloads"]
    root = resolve_from_config(args.config, workload["adapted_root"])
    manifest_path = root / "manifest.json"
    if manifest_path.exists() and not args.overwrite:
        print(manifest_path)
        return
    root.mkdir(parents=True, exist_ok=True)
    episode_s = float(workload["episode_s"])
    train_fraction = float(workload["train_fraction"])
    calibration_fraction = float(workload["calibration_fraction"])
    manifest = {"schema_version": 1, "sources": {}, "episodes": []}
    max_context = min(int(model["max_model_len"]) for model in config["models"])
    for source, raw_value in workload["sources"].items():
        raw = resolve_from_config(args.config, raw_value)
        if not raw.exists():
            raise FileNotFoundError(f"missing raw trace for {source}: {raw}")
        rows = ADAPTERS[adapter_name(source)](raw, episode_s)
        original_count = len(rows)
        rows = [row for row in rows if row.prompt_tokens + row.max_output_tokens <= max_context]
        dropped_oversize = original_count - len(rows)
        if not rows:
            raise RuntimeError(f"all {source} requests exceed model context {max_context}")
        by_episode = {}
        for row in rows:
            by_episode.setdefault(row.episode_id, []).append(row)
        ordered = sorted(by_episode.items(), key=lambda item: min(row.arrival_ms for row in item[1]))
        n = len(ordered)
        train_end = max(1, int(n * train_fraction))
        cal_end = min(n, train_end + max(1, int(n * calibration_fraction)))
        source_dir = root / source
        source_dir.mkdir(exist_ok=True)
        manifest["sources"][source] = {
            "raw": str(raw), "sha256": checksum(raw), "requests": len(rows), "episodes": n,
            "dropped_oversize_requests": dropped_oversize,
            "context_limit_tokens": max_context,
        }
        for index, (episode_id, episode_rows) in enumerate(ordered):
            split = "train" if index < train_end else "calibration" if index < cal_end else "test"
            origin = min(row.arrival_ms for row in episode_rows)
            destination = source_dir / f"{index:06d}_{split}.jsonl"
            with destination.open("w", encoding="utf-8") as stream:
                for row in episode_rows:
                    value = asdict(row)
                    value["arrival_ms"] -= origin
                    value["episode_id"] = f"{source}:{episode_id}"
                    stream.write(json.dumps(value, ensure_ascii=False) + "\n")
            manifest["episodes"].append({
                "source": source, "episode_id": f"{source}:{episode_id}",
                "split": split, "path": str(destination), "requests": len(episode_rows),
                "duration_ms": max(row.arrival_ms for row in episode_rows) - origin,
            })
    counts = {
        split: sum(item["split"] == split for item in manifest["episodes"])
        for split in ("train", "calibration", "test")
    }
    minimum = int(config["risk"]["minimum_calibration_episodes"])
    if counts["calibration"] < minimum:
        raise RuntimeError(f"only {counts['calibration']} calibration episodes; require {minimum}")
    manifest["split_counts"] = counts
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(json.dumps(counts, indent=2))


if __name__ == "__main__":
    main()
