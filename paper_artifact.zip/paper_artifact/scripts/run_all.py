#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from flexbid.config import load_config, resolve_from_config


PHASES = ("preflight", "prepare", "pilot", "profile", "fit", "freeze", "offline", "closed-loop", "audit")


def main() -> None:
    parser = argparse.ArgumentParser(description="Resumable end-to-end FlexBid paper campaign")
    parser.add_argument("--config", type=Path, default=Path("configs/a100_8gpu.yaml"))
    parser.add_argument("--from-phase", choices=PHASES)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    config = load_config(args.config)
    results = resolve_from_config(args.config, config["paths"]["results_root"])
    start = PHASES.index(args.from_phase) if args.from_phase else 0
    for phase in PHASES[start:]:
        command = [sys.executable, str(root / "scripts/run_campaign.py"),
                   "--config", str(args.config), "--phase", phase]
        if phase in {"pilot", "profile", "closed-loop"}:
            command.append("--resume")
        print(json.dumps({"phase": phase, "command": command}), flush=True)
        subprocess.run(command, cwd=root, check=True)
    print(json.dumps({"status": "PIPELINE_COMPLETE", "results": str(results)}, indent=2))


if __name__ == "__main__":
    main()
