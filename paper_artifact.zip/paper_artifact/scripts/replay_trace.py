#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
from pathlib import Path

from flexbid.replay import replay


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trace", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--api-base", default="http://127.0.0.1:18000/v1")
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer")
    parser.add_argument("--timeout-s", type=float, default=900)
    parser.add_argument("--arrival-scale", type=float, default=1.0)
    parser.add_argument("--duration-limit-s", type=float)
    parser.add_argument("--allow-load-shedding", action="store_true")
    args = parser.parse_args()
    asyncio.run(replay(
        args.trace, args.output, args.api_base, args.model,
        args.tokenizer or args.model, args.timeout_s,
        args.arrival_scale, args.duration_limit_s,
        args.allow_load_shedding,
    ))


if __name__ == "__main__":
    main()
