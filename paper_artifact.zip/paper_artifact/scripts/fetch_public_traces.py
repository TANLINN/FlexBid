#!/usr/bin/env python3
from __future__ import annotations

import argparse
import gzip
import hashlib
import shutil
import urllib.request
from pathlib import Path


URLS = {
    "BurstGPT_without_fails_1.csv": "https://github.com/HPMLL/BurstGPT/releases/download/v2.0/BurstGPT_without_fails_1.csv",
    "AzureLLMInferenceTrace_code_1week.csv": "https://github.com/Azure/AzurePublicDataset/releases/download/dataset-llm-2024/AzureLLMInferenceTrace_code_1week.csv",
    "AzureLLMInferenceTrace_conv_1week.csv": "https://github.com/Azure/AzurePublicDataset/releases/download/dataset-llm-2024/AzureLLMInferenceTrace_conv_1week.csv",
    "qwen_traceB_blksz_16.jsonl": "https://media.githubusercontent.com/media/alibaba-edu/qwen-bailian-usagetraces-anon/main/qwen_traceB_blksz_16.jsonl",
    "syfi_coding_trace.jsonl.gz": "https://github.com/uw-syfi/TraceLab/releases/download/v0.0.1/syfi_coding_trace.jsonl.gz",
}
TRACELAB_SHA256 = "9d265eae69a31cae203848bea936f018148eed7ca8bf56050c5abe96da0b4e6b"
MIN_BYTES = {
    "BurstGPT_without_fails_1.csv": 10_000_000,
    "AzureLLMInferenceTrace_code_1week.csv": 1_000_000,
    "AzureLLMInferenceTrace_conv_1week.csv": 1_000_000,
    "qwen_traceB_blksz_16.jsonl": 90_000_000,
    "syfi_coding_trace.jsonl.gz": 1_000_000,
}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("data/raw"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for name, url in URLS.items():
        destination = args.output / name
        if destination.exists() and destination.stat().st_size >= MIN_BYTES[name]:
            print(f"exists: {destination}")
            continue
        temporary = destination.with_suffix(destination.suffix + ".part")
        print(f"downloading {url}")
        request = urllib.request.Request(url, headers={"User-Agent": "FlexBid-paper-artifact/0.1"})
        with urllib.request.urlopen(request, timeout=120) as source, temporary.open("wb") as target:
            shutil.copyfileobj(source, target, length=1024 * 1024)
        if temporary.stat().st_size < MIN_BYTES[name]:
            raise RuntimeError(f"download is unexpectedly small (possible Git LFS pointer): {name}")
        temporary.replace(destination)
    archive = args.output / "syfi_coding_trace.jsonl.gz"
    if digest(archive) != TRACELAB_SHA256:
        raise RuntimeError("TraceLab checksum mismatch")
    output = args.output / "tracelab_export.jsonl"
    if not output.exists():
        with gzip.open(archive, "rb") as source, output.open("wb") as destination:
            shutil.copyfileobj(source, destination)
    print("public traces ready")


if __name__ == "__main__":
    main()
