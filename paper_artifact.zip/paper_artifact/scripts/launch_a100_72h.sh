#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

results_root="results/paper_artifact_a100_72h"
mkdir -p "$results_root/logs"
python scripts/self_test.py
python scripts/fetch_public_traces.py
python scripts/prefetch_models.py --config configs/a100_8gpu_72h.yaml
nohup python -u scripts/run_all.py --config configs/a100_8gpu_72h.yaml \
  > "$results_root/logs/launcher.log" 2>&1 &
echo $! > "$results_root/launcher.pid"
echo "started 72-hour A100 campaign PID $(cat "$results_root/launcher.pid")"
