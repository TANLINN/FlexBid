#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p results/paper_artifact_a100/logs
python scripts/self_test.py
python scripts/fetch_public_traces.py
nohup python -u scripts/run_all.py --config configs/a100_8gpu.yaml \
  > results/paper_artifact_a100/logs/launcher.log 2>&1 &
echo $! > results/paper_artifact_a100/launcher.pid
echo "started PID $(cat results/paper_artifact_a100/launcher.pid)"
