#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from flexbid.dataset import aggregate_episode_rows, read_rows
from flexbid.surrogate import ResponseSurrogate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--model", required=True)
    parser.add_argument("--episode-s", type=float, default=300)
    args = parser.parse_args()
    rows = aggregate_episode_rows([
        row for row in read_rows(args.dataset) if row.get("model") == args.model
    ], args.episode_s)
    if not rows:
        raise SystemExit(f"no rows for model {args.model}")
    train = [row for row in rows if row["data_split"] == "train"]
    calibration = [row for row in rows if row["data_split"] == "calibration"]
    model = ResponseSurrogate(alpha=args.alpha).fit(train, calibration)
    model.save(args.output)
    report = {
        "model": args.model, "train_rows": len(train), "calibration_rows": len(calibration),
        "targets": sorted(model.regressors),
        "calibration": {key: value.as_dict() for key, value in model.calibrators.items()},
        "joint_calibration": None if model.joint_calibrator is None else model.joint_calibrator.as_dict(),
    }
    args.output.with_suffix(".report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
