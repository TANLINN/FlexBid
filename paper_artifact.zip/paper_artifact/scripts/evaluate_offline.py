#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from flexbid.campaign import effective_model_config, sparse_actions
from flexbid.config import load_config, resolve_from_config
from flexbid.evaluation import evaluate_bidders
from flexbid.surrogate import ResponseSurrogate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    model_root = resolve_from_config(args.config, config["paths"]["models_root"])
    surrogate = ResponseSurrogate.load(model_root / f"{args.model.replace('/', '_')}.joblib")
    manifest = json.loads((resolve_from_config(
        args.config, config["workloads"]["adapted_root"]
    ) / "manifest.json").read_text(encoding="utf-8"))
    actions, default_action = sparse_actions(config)
    results = resolve_from_config(args.config, config["paths"]["results_root"])
    effective_model = effective_model_config(results, next(
        item for item in config["models"] if item["name"] == args.model
    ))
    rows = evaluate_bidders(
        surrogate, actions, default_action, manifest,
        alpha=float(config["risk"]["alpha"]),
        ttft_slo_ms=float(config["slos"]["default"]["ttft_ms"]),
        tpot_slo_ms=float(config["slos"]["default"]["tpot_ms"]),
        arrival_scale_by_source=effective_model.get("arrival_scale_by_source", {}),
        duration_limit_s=float(config["workloads"]["episode_s"]),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=sorted({key for row in rows for key in row}))
        writer.writeheader(); writer.writerows(rows)
    print(json.dumps({"rows": len(rows), "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
