#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from flexbid.campaign import run_load_pilot, run_profile
from flexbid.config import load_config, resolve_from_config


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--phase", choices=[
        "prepare", "preflight", "pilot", "profile", "fit", "freeze", "offline", "closed-loop", "audit"
    ], required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    artifact_root = Path(__file__).resolve().parents[1]
    config = load_config(args.config)
    if args.phase == "prepare":
        subprocess.run([sys.executable, str(artifact_root / "scripts/prepare_data.py"), "--config", str(args.config)], check=True)
    elif args.phase == "preflight":
        results = resolve_from_config(args.config, config["paths"]["results_root"])
        subprocess.run([
            sys.executable, str(artifact_root / "scripts/preflight.py"),
            "--config", str(args.config), "--output", str(results / "preflight.json"),
        ], check=True)
    elif args.phase == "profile":
        run_profile(artifact_root, args.config, config, args.resume)
    elif args.phase == "pilot":
        run_load_pilot(artifact_root, args.config, config, args.resume)
    elif args.phase == "fit":
        results = resolve_from_config(args.config, config["paths"]["results_root"])
        model_root = resolve_from_config(args.config, config["paths"]["models_root"])
        for model in config["models"]:
            slug = model["name"].replace("/", "_")
            subprocess.run([
                sys.executable, str(artifact_root / "scripts/fit_surrogate.py"),
                "--dataset", str(results / "surrogate_dataset.csv"),
                "--output", str(model_root / f"{slug}.joblib"),
                "--alpha", str(config["risk"]["alpha"]),
                "--model", model["name"],
                "--episode-s", str(config["workloads"]["episode_s"]),
            ], check=True)
    elif args.phase == "freeze":
        subprocess.run([sys.executable, str(artifact_root / "scripts/freeze_algorithm.py"),
                        "--config", str(args.config)], check=True)
    elif args.phase == "offline":
        results = resolve_from_config(args.config, config["paths"]["results_root"])
        for model in config["models"]:
            subprocess.run([
                sys.executable, str(artifact_root / "scripts/evaluate_offline.py"),
                "--config", str(args.config), "--model", model["name"],
                "--output", str(results / "offline" / f"{model['name'].replace('/', '_')}.csv"),
            ], check=True)
    elif args.phase == "closed-loop":
        command = [sys.executable, str(artifact_root / "scripts/run_closed_loop.py"),
                   "--config", str(args.config)]
        if args.resume:
            command.append("--resume")
        subprocess.run(command, check=True)
    elif args.phase == "audit":
        subprocess.run([sys.executable, str(artifact_root / "scripts/audit_results.py"),
                        "--config", str(args.config)], check=True)


if __name__ == "__main__":
    main()
