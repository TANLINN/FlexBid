#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from flexbid.campaign import sparse_actions
from flexbid.config import canonical_hash, load_config, resolve_from_config
from flexbid.freeze import make_freeze


def main() -> None:
    parser = argparse.ArgumentParser(description="Freeze code/models before opening the test split")
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    config = load_config(args.config)
    results = resolve_from_config(args.config, config["paths"]["results_root"])
    model_root = resolve_from_config(args.config, config["paths"]["models_root"])
    manifest_path = resolve_from_config(args.config, config["workloads"]["adapted_root"]) / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    # Test trace payloads are deliberately not read or hashed here. Only their
    # immutable manifest entries are committed before evaluation.
    public_manifest = dict(manifest)
    public_manifest["episodes"] = [
        {key: value for key, value in item.items() if key != "path"}
        for item in manifest["episodes"]
    ]
    public_path = results / "frozen_split_manifest.json"
    public_path.write_text(json.dumps(public_manifest, indent=2), encoding="utf-8")
    paths = [args.config.resolve(), public_path]
    paths.extend([results / "load_scales.json", results / "campaign_manifest.json"])
    paths.extend(sorted((root / "flexbid").glob("*.py")))
    paths.extend(sorted((root / "scripts").glob("*.py")))
    paths.extend(sorted(model_root.glob("*.joblib")))
    if not any(path.suffix == ".joblib" for path in paths):
        raise RuntimeError("no fitted surrogate models; run fit first")
    actions, default = sparse_actions(config)
    value = make_freeze(paths, results / "ALGORITHM_FREEZE.json", {
        "config_hash": canonical_hash(config),
        "actions": [action.as_dict() for action in actions],
        "default_action": default.as_dict(),
        "test_split_not_opened": True,
    })
    print(json.dumps({"freeze": str(results / "ALGORITHM_FREEZE.json"), "files": len(value["files"])}, indent=2))


if __name__ == "__main__":
    main()
