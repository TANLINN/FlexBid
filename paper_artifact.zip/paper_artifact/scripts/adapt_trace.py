#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

from flexbid.traces import ADAPTERS, write_trace


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=sorted(ADAPTERS), required=True)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--episode-s", type=float, default=300)
    args = parser.parse_args()
    rows = ADAPTERS[args.source](args.input, args.episode_s)
    print(json.dumps(write_trace(rows, args.output), indent=2))


if __name__ == "__main__":
    main()
