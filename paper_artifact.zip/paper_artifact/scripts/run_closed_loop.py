#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from flexbid.closed_loop import run_closed_loop
from flexbid.config import load_config


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    run_closed_loop(Path(__file__).resolve().parents[1], args.config, load_config(args.config), args.resume)


if __name__ == "__main__":
    main()
