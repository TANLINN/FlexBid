#!/usr/bin/env bash
set -eu
PROJECT=/root/workspace/FlexBid-LLM
BASE_PY=${BASE_PY:-python3.10}
"$BASE_PY" -c 'import sys; assert sys.version_info[:2] == (3,10), "需要Python3.10"'
if [ ! -e "$PROJECT/.venv" ]; then
  "$BASE_PY" -m venv "$PROJECT/.venv"
fi
PY="$PROJECT/.venv/bin/python"
"$PY" -c 'import sys; assert sys.version_info[:2] == (3,10), "已有环境不是Python3.10"'
"$PY" -m pip install -r "$PROJECT/migration/recorded_environment/requirements-recorded.txt"
"$PY" -m pip install --no-deps --no-build-isolation -e "$PROJECT/hybrid_artifact" -e "$PROJECT/paper_artifact"
"$PY" -m pip check
echo 'Environment installation completed; GPU compatibility and workload execution remain untested.'
