# FlexBid

单机P/C控制与恢复可行性研究项目。用户验收入口为 `FLEXBID_REVIEW_OUTLINE.md`；内部执行入口为 `FLEXBID_ROADMAP.md`。当前开发任务是001918事件暂停与恢复负担实验。

## 换电脑接续

电脑交接包解压后以 `Idea/FlexBid-Latest` 为最新项目工作目录；单独解压服务器小包时目录名为 `FlexBid-LLM`。先读取 `AGENTS.md`、本文件、`FLEXBID_ROADMAP.md`、`FLEXBID_CURRENT_STATUS.md`、`FLEXBID_CORE_METHOD.md`。接续说明以这些文件为准，不要求依赖旧聊天记录。

可交给新会话的任务：

> 继续这个FlexBid项目。先读取AGENTS.md、README.md、推进清单、当前状态和方法规格。三个CV小包已在旧电脑校验并合并；当前优先验证新服务器恢复与依赖安装，再执行operations/prepare_core_pause.txt的CPU消融和实验准备。001918的ABC/CBA六轮方案已确定但尚未执行，不能当作已有结果。原始实验大日志不在此包中，缺失时不能用摘要伪造重建。GPU操作由我在服务器执行并返回结果；继续到需要我操作为止。仅更新文字状态，不主动更新进度图。

本包不携带账号、凭据、聊天历史或旧电脑软件环境。现有实验配置限定硬件与路径；更换A100/A800或驱动后需核对，不自动放宽检查或合并成同环境结果。历史文档中的旧电脑路径和未收录分析材料引用，不代表这些文件存在于当前包；当前可执行入口见 `operations/`。

## 内容

- `hybrid_artifact/`：服务器源码、配置、被现有启动器引用的历史源文件、保存的报告及模型记录。
- `hybrid_artifact/development/core_pause/`：当前截止约束消融与ABC/CBA六轮实验代码。
- `hybrid_artifact/results/`：已接收的记录，以及001710、001918、001976的原始保存输入；各输入含完整280任务cohort。
- `paper_artifact/`、`paper_submission/`：服务器备份中的源码和文档；不代表论文内容已与当前证据对齐。
- `migration/recorded_environment/`：原实验环境与模型配置记录。
- `operations/`：新服务器环境安装与当前CPU准备入口。

本包不含Qwen权重、Python虚拟环境、编译缓存、完整历史请求/流/功率日志、完整trace数据集，以及未被选入迁移包的其他训练产物。历史报告可以查阅，但不能仅凭本包重算所有历史主表。旧服务器大备份无法传出，不作为本项目恢复的前置文件。

## 新服务器恢复

使用电脑交接包内的最新版项目压缩包即可恢复当前开发和已接收数据。范围见 `migration/REQUIRED_FILES.md`；未迁入的历史原始日志不能重算，不以重新运行旧GPU实验补缺。

把 `FlexBid-Latest_20260916.tar.gz` 放到新服务器 `/root/workspace/`。使用原项目路径，避免破坏历史启动器中的绝对路径引用：

```bash
(
set -eu
mkdir -p /root/workspace
if [ -e /root/workspace/FlexBid-LLM ]; then
  echo '目标目录已存在，请先确认其中的数据，不要覆盖。'
  exit 1
fi
tar -xzf /root/workspace/FlexBid-Latest_20260916.tar.gz \
  -C /root/workspace --no-same-owner
)
```

安装环境：

```bash
bash /root/workspace/FlexBid-LLM/operations/install_environment.sh
```

需要已安装Python3.10；原记录版本为3.10.15。安装使用原包版本列表与当前机器配置的软件源，不安装或更换GPU驱动。新机器的GPU、驱动、CUDA兼容性与安装结果尚需实际核对，不能视为已复现原环境。

将Qwen3.5-27B重新下载到 `/root/FlexBid-LLM/models/Qwen3.5-27B`，这是保存配置使用的模型目录。原记录的revision为可变的 `master`；配置文件和版本记录不能证明重新下载的权重与原权重完全相同。正式比较须记录新机器与新下载模型的环境。

## CPU准备

```bash
bash /root/workspace/FlexBid-LLM/operations/prepare_core_pause.txt
```

该入口分析保存的50个决策状态并准备六轮实验，不启动GPU、不停止保活。实际GPU启动命令须使用准备返回的目录。新服务器实测尚未完成。

## 本地验证

三份压缩包已通过XZ完整性检查和解压。三个输入分别含3315、4640、3711条在线请求及各280个批任务，通过原保存输入验证函数。当前开发入口8项CPU测试通过。历史源码保留用于路径依赖和审计，没有把全部历史实验标记为可运行或全部通过。
