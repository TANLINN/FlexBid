from dataclasses import replace
import unittest

from flexbid_hybrid.frontier_controller import FrontierGuardedViabilityMPC
from flexbid_hybrid.modeling import HybridBounds, HybridPrediction
from flexbid_hybrid.mpc import ControlState, MPCParameters
from flexbid_hybrid.runtime_controller import _tail_values
from flexbid_hybrid.types import HybridAction


class FrontierControllerTests(unittest.TestCase):
    class Model:
        values = {
            "hybrid_full": (400.0, 100.0),
            "pause": (200.0, 0.0),
            "boost": (420.0, 200.0),
        }

        def predict(self, row):
            power, batch = self.values[row["name"]]
            return HybridPrediction(power, 100.0, 10.0, batch)

        def bounds(self, row, mode):
            prediction = self.predict(row)
            return HybridBounds(
                prediction.power_mean_w,
                prediction.power_mean_w,
                prediction.ttft_p95_ms,
                prediction.tpot_p99_ms,
                prediction.batch_tokens_per_s,
            )

    def setUp(self):
        self.actions = [
            HybridAction("hybrid_full", 4, 4, 400),
            HybridAction("pause", 2, 0, 200),
            HybridAction("boost", 4, 6, 400),
        ]
        parameters = MPCParameters(
            control_period_s=10.0,
            terminal_tolerance_tokens=0.0,
            terminal_cohort_tolerance_tokens=0.0,
            switch_penalty=0.0,
            recovery_power_weight=0.0,
            recovery_service_credit=0.0,
            replica_min_dwell_s=0.0,
        )
        self.optimizer = FrontierGuardedViabilityMPC(
            self.Model(), self.actions, parameters,
        )

    def state(self, *, event=10.0, deadline=20.0, committed=None):
        return ControlState(
            source="qwen_bailian",
            event_remaining_s=event,
            deadline_remaining_s=deadline,
            backlog_tokens=0.0,
            current_action="hybrid_full",
            ttft_slo_ms=5000.0,
            tpot_slo_ms=100.0,
            baseline_batch_tps=100.0,
            committed_bid_w=committed,
        )

    def test_frontier_finds_event_and_recovery_witness(self):
        plan = self.optimizer.solve(self.state())
        self.assertTrue(plan.feasible)
        self.assertEqual(plan.committed_bid_w, 200.0)
        self.assertEqual(
            [step.action.name for step in plan.steps],
            ["pause", "boost"],
        )
        self.assertEqual(plan.terminal_backlog_tokens, 0.0)
        self.assertEqual(
            self.optimizer.last_search_diagnostics["status"],
            "MODEL_VALIDATED_PLAN",
        )

    def test_replans_recovery_from_measured_debt(self):
        state = replace(
            self.state(),
            event_remaining_s=0.0,
            deadline_remaining_s=10.0,
            current_action="pause",
            committed_bid_w=200.0,
            backlog_tokens=1000.0,
            dr_debt_tokens=1000.0,
        )
        plan = self.optimizer.solve(state)
        self.assertTrue(plan.feasible)
        self.assertEqual([step.action.name for step in plan.steps], ["boost"])
        self.assertEqual(plan.terminal_backlog_tokens, 0.0)

    def test_baseline_tail_excludes_startup_observations(self):
        observations = [(10, 500.0), (70, 2200.0), (90, 2450.0)]
        self.assertEqual(_tail_values(observations, 70), [2200.0, 2450.0])


if __name__ == "__main__":
    unittest.main()
