import copy
import csv
import json
from pathlib import Path
import tempfile
import unittest

from flexbid_hybrid.gpu_pair_rebuild import (
    ABLATION_CAMPAIGN, PROFILE_CAMPAIGN, HistoricalGpuPairedSurrogate, inspect_cell, rebuild,
)


def make_cell(root, name, gpu_power=2000, component_power=2500, concurrency=4, replicas=4, cap=400):
    path = root / "cells" / "episode" / name
    path.mkdir(parents=True)
    cell = dict(episode=dict(episode_id="qwen:e1", source="qwen_bailian", split="train"),
                action=dict(name=name, online_replicas=replicas, batch_concurrency=concurrency, power_cap_w=cap),
                measurement_start_wall_ns=1_000_000_000, measurement_end_wall_ns=3_000_000_000)
    (path / "cell.json").write_text(json.dumps(cell))
    (path / "CELL_COMPLETE.json").write_text("{}")
    with (path / "components.csv").open("w", newline="") as stream:
        rows = [dict(wall_time_ns=t * 1_000_000_000, aggregate_gpu_power_w=gpu_power,
                     observed_component_power_w=component_power,
                     **{f"gpu{i}_power_w": gpu_power / 8 for i in range(8)}) for t in (0, 1, 2, 3, 4)]
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (path / "online.jsonl").write_text(json.dumps(dict(ttft_ms=10, mean_tpot_ms=2, error=None)) + "\n")
    (path / "batch.jsonl").write_text(json.dumps(dict(error=None, completion_tokens=100)) + "\n")
    return path


def dataset_row(action, baseline):
    a, b = inspect_cell(action), inspect_cell(baseline)
    return dict(episode_id="qwen:e1", source="qwen_bailian", data_split="train",
                **a["cell"]["action"], **a["metrics"], power_peak_w=a["metrics"]["power_mean_w"],
                baseline_power_w=b["metrics"]["power_mean_w"], baseline_ttft_ms=10,
                baseline_tpot_ms=2, baseline_batch_tps=50, slo_safe="True")


class GpuPairRebuildTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.old = self.root / "old"
        self.new = self.root / "new"
        self.oldbase = make_cell(self.old, "hybrid_full", 2500, 3000)
        self.newbase = make_cell(self.new, "hybrid_full", 2400, 2850)
        self.action = make_cell(self.new, "recovery_batch5", 2420, 2860, 5)
        self.rows = [dataset_row(self.oldbase, self.oldbase), dataset_row(self.action, self.newbase)]

    def test_same_round_baseline_not_global_episode_baseline(self):
        before = copy.deepcopy(self.rows)
        rows, evidence = rebuild(self.rows, [self.old, self.new])
        self.assertEqual(rows[1]["baseline_power_w"], 2400)
        self.assertEqual(rows[1]["power_mean_w"], 2420)
        self.assertEqual(rows[1]["legacy_component_baseline_power_w"], 2850)
        self.assertEqual(evidence[1]["baseline"]["path"], str(self.newbase.resolve()))
        paired = HistoricalGpuPairedSurrogate._paired_rows(rows)
        self.assertEqual(paired[1]["power_mean_w"], -20)
        self.assertEqual(self.rows, before)

    def test_wrong_saved_baseline_blocks_all(self):
        self.rows[1]["baseline_power_w"] = 3000
        with self.assertRaisesRegex(ValueError, "row-local"):
            rebuild(self.rows, [self.old, self.new])

    def test_missing_same_round_baseline_is_not_substituted(self):
        (self.newbase / "CELL_COMPLETE.json").unlink()
        with self.assertRaisesRegex(ValueError, "same-campaign"):
            rebuild(self.rows, [self.old, self.new])

    def test_ambiguous_action_blocks(self):
        other = self.root / "duplicate"
        make_cell(other, "recovery_batch5", 2420, 2860, 5)
        with self.assertRaisesRegex(ValueError, "found 2"):
            rebuild(self.rows, [self.old, self.new, other])

    def test_wrong_gpu_measurement_blocks(self):
        self.rows[1]["gpu_power_mean_w"] = 999
        with self.assertRaisesRegex(ValueError, "found 0"):
            rebuild(self.rows, [self.old, self.new])

    def test_failed_marker_is_not_ignored(self):
        (self.action / "CELL_FAILED.json").write_text("{}")
        with self.assertRaisesRegex(ValueError, "failure marker"):
            rebuild(self.rows, [self.old, self.new])

    def test_duplicate_rows_block(self):
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            rebuild([self.rows[0], self.rows[0]], [self.old])

    def test_gap_blocks(self):
        with self.assertRaisesRegex(ValueError, "Telemetry gap"):
            inspect_cell(self.action, max_gap_s=.5)

    def test_gpu_aggregate_must_match_devices(self):
        path = self.action / "components.csv"
        text = path.read_text().replace("2420", "2421")
        path.write_text(text)
        with self.assertRaisesRegex(ValueError, "aggregate"):
            inspect_cell(self.action)

    def test_model_refuses_unverified_or_mixed_boundary_rows(self):
        with self.assertRaisesRegex(ValueError, "provenance-verified"):
            HistoricalGpuPairedSurrogate._paired_rows(self.rows)

    def test_invalid_numeric_not_silently_zero(self):
        rows, _ = rebuild(self.rows, [self.old, self.new])
        rows[1]["baseline_power_w"] = float("nan")
        with self.assertRaisesRegex(ValueError, "Nonfinite"):
            HistoricalGpuPairedSurrogate._paired_rows(rows)

    def test_baseline_self_pair_is_required(self):
        rows, _ = rebuild(self.rows, [self.old, self.new])
        rows[0]["baseline_power_w"] += 10
        with self.assertRaisesRegex(ValueError, "self-paired"):
            HistoricalGpuPairedSurrogate._paired_rows(rows)

    def ablation_fixture(self, action_name="hybrid_full_cap300", replicas=4, concurrency=4, cap=300):
        profile, ablation = self.root / PROFILE_CAMPAIGN, self.root / ABLATION_CAMPAIGN
        base = make_cell(profile, "hybrid_full", 2500, 3000)
        action = make_cell(ablation, action_name, 2300, 2800, concurrency, replicas, cap)
        row = dataset_row(action, base)
        return profile, ablation, base, action, row

    def test_ablation_can_reconstruct_exact_saved_profile_reference(self):
        profile, ablation, base, action, row = self.ablation_fixture()
        rows, evidence = rebuild([row], [profile, ablation, self.new])
        self.assertEqual(rows[0]["baseline_power_w"], 2500)
        self.assertEqual(rows[0]["pairing_kind"], "cross_campaign_profile_reference")
        self.assertEqual(evidence[0]["reference_campaign"], str(profile.resolve()))
        self.assertFalse(evidence[0]["cross_campaign_drift_ruled_out"])

    def test_pause_ablation_can_reconstruct_exact_profile_reference(self):
        profile, ablation, base, action, row = self.ablation_fixture("pause_r2_cap400", 2, 0, 400)
        rows, _ = rebuild([row], [profile, ablation])
        self.assertEqual(rows[0]["pairing_kind"], "cross_campaign_profile_reference")

    def test_profile_reference_requires_all_four_saved_metrics(self):
        for field in ("baseline_power_w", "baseline_ttft_ms", "baseline_tpot_ms", "baseline_batch_tps"):
            with self.subTest(field=field):
                if not hasattr(self, "ablation_data"):
                    self.ablation_data = self.ablation_fixture()
                profile, ablation, base, action, original = self.ablation_data
                row = dict(original)
                row[field] = float(row[field]) + 1
                with self.assertRaisesRegex(ValueError, "row-local"):
                    rebuild([row], [profile, ablation, self.new])

    def test_ablation_does_not_take_matching_recovery_reference(self):
        profile, ablation, base, action, row = self.ablation_fixture()
        row["baseline_power_w"] = 2850
        with self.assertRaisesRegex(ValueError, "row-local"):
            rebuild([row], [profile, ablation, self.new])

    def test_same_named_action_in_unknown_campaign_cannot_cross_pair(self):
        profile, ablation, base, action, row = self.ablation_fixture()
        renamed = self.root / "unrelated_ablation"
        ablation.rename(renamed)
        with self.assertRaisesRegex(ValueError, "same-campaign"):
            rebuild([row], [profile, renamed])

    def test_recovery_cannot_use_profile_even_if_saved_values_match(self):
        profile = self.root / PROFILE_CAMPAIGN
        base = make_cell(profile, "hybrid_full", 2500, 3000)
        row = dataset_row(self.action, base)
        (self.newbase / "CELL_COMPLETE.json").unlink()
        with self.assertRaisesRegex(ValueError, "same-campaign"):
            rebuild([row], [profile, self.new])

    def test_profile_same_episode_wrong_split_blocks(self):
        profile, ablation, base, action, row = self.ablation_fixture()
        cp = base / "cell.json"
        cell = json.loads(cp.read_text())
        cell["episode"]["split"] = "calibration"
        cp.write_text(json.dumps(cell))
        with self.assertRaisesRegex(ValueError, "episode metadata"):
            rebuild([row], [profile, ablation])

    def test_duplicate_profile_baselines_block(self):
        profile, ablation, base, action, row = self.ablation_fixture()
        import shutil
        shutil.copytree(base, profile / "cells" / "duplicate" / "hybrid_full")
        with self.assertRaisesRegex(ValueError, "found 2"):
            rebuild([row], [profile, ablation])

    def test_ablation_wrong_actuator_tuple_blocks(self):
        profile, ablation, base, action, row = self.ablation_fixture(cap=400)
        with self.assertRaisesRegex(ValueError, "ablation tuple"):
            rebuild([row], [profile, ablation])


if __name__ == "__main__":
    unittest.main()
