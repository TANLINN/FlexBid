import copy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]


def module(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / ('scripts/' + name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


smoke = module('run_zero_bid_integration_smoke')
installer = module('install_zero_bid_reference')


class IntegrationSmokeTests(unittest.TestCase):
    def config(self):
        return dict(dynamic_controller=dict(force_baseline=True, surrogate_model='model.joblib',
                    baseline_dataset='baseline.csv', initial_cohort_tokens=999999),
            hardware=dict(gpu_indices=list(range(8))), model=dict(replicas=[[0,1],[2,3],[4,5],[6,7]]),
            workloads=dict(arrival_scale_by_source={'qwen_bailian': 1.}), slos={'unchanged': True})

    def prepare(self, config, arrivals=(0, 120, 150, 245, 306)):
        episode = dict(episode_id='qwen_bailian:bailian-000009:trajectory-window-0',
                       source='qwen_bailian', split='calibration', path='/diagnostic/trace.jsonl')
        source = '\n'.join(json.dumps(dict(arrival_ms=t * 1000)) for t in arrivals)
        with patch.object(smoke, 'load_config', return_value=config), \
             patch.object(smoke, 'select_episodes', return_value=[episode]), \
             patch.object(Path, 'is_file', return_value=True), patch.object(Path, 'read_text', return_value=source), \
             patch.object(Path, 'write_text') as write, patch.object(smoke, 'atomic_json') as save:
            smoke.prepare(ROOT, Path('old.yaml'), ROOT / 'never_written')
        return write, save

    def test_one_cell_config_is_zero_bid_with_explicit_horizons(self):
        config = self.config()
        original = copy.deepcopy(config)
        write, save = self.prepare(config)
        d = config['dynamic_controller']
        self.assertTrue(d['force_baseline'])
        self.assertFalse(d['external_commitments_enabled'])
        self.assertEqual((d['warmup_s'], d['offer_lead_s'], d['event_s'], d['deadline_s']), (120,30,95,155))
        self.assertEqual(d['action_lattice']['batch_concurrency'], [4])
        self.assertEqual(d['ems_contract']['reference_power_w'], [])
        self.assertNotIn('initial_cohort_tokens', d)
        self.assertEqual(config['slos'], original['slos'])
        self.assertEqual(config['model'], original['model'])
        self.assertEqual(config['workloads']['episode_selections'][0]['count'], 1)
        self.assertTrue(save.call_args.args[1]['reused_development_trace'])
        write.assert_called_once()

    def test_sparse_trace_is_refused(self):
        with self.assertRaisesRegex(ValueError, 'Insufficient real trace'):
            self.prepare(self.config(), (0, 306))

    def test_nonbaseline_input_config_is_refused(self):
        config = self.config()
        config['dynamic_controller']['force_baseline'] = False
        with self.assertRaisesRegex(ValueError, 'force_baseline'):
            self.prepare(config)

    def test_patch_idempotent_and_preserves_server_cold_start_branch(self):
        source = (ROOT / 'flexbid_hybrid/runtime_controller.py').read_text()
        self.assertEqual(installer.patch_runtime(source), source)
        source = source.replace(installer.CALL, '')
        source = source.replace(installer.ANCHOR, '            cold_start_abstain = True\n' + installer.ANCHOR)
        patched = installer.patch_runtime(source)
        self.assertIn('            cold_start_abstain = True\n', patched)
        self.assertIn(installer.CALL + installer.ANCHOR, patched)
        self.assertEqual(installer.patch_runtime(patched), patched)

    def test_unknown_anchor_refused(self):
        with self.assertRaises(ValueError):
            installer.patch_runtime('print("unknown runtime")')
