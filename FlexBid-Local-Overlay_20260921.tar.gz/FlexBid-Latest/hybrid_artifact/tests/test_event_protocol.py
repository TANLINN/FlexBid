import importlib.util
import json
import math
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace

from flexbid_hybrid.contracts import FlexibilityContract
from flexbid_hybrid.event_protocol import FixedWindowMeter, EventSession, prepare_event
from flexbid_hybrid.mpc import MPCPlan, PlanStep
from flexbid_hybrid.types import HybridAction


class FixedMeterTests(unittest.TestCase):
    def meter(self, event=300, interval=30, **kw):
        return FixedWindowMeter(FlexibilityContract(event, event + 100, interval,
                               reference_power_w=(3000.,), **kw), max_gap_s=45)

    def test_crossing_release_includes_tenth_window(self):
        meter = self.meter()
        for t in range(-1, 322, 7):
            meter.add(t, 2200.)
        rows = meter.report(800, True, final=True)
        self.assertEqual(len(rows), 10)
        self.assertTrue(all(r['status'] == 'DELIVERED' for r in rows))
        self.assertAlmostEqual(sum(r['delivered_ws'] for r in rows), 240000.)

    def test_partial_last_window_not_dropped(self):
        meter = self.meter(event=95)
        for t in (-1, 13, 47, 74, 100):
            meter.add(t, 2200.)
        rows = meter.report(800, True, final=True)
        self.assertEqual([r['end_s'] for r in rows], [30, 60, 90, 95])
        self.assertAlmostEqual(rows[-1]['required_ws'], 4000.)

    def test_long_gap_is_not_interpolated(self):
        meter = self.meter(event=60)
        meter.add(-1, 2200.)
        meter.add(61, 2200.)
        self.assertTrue(all(r['status'] == 'METER_INVALID' for r in meter.report(800, True, final=True)))

    def test_nan_sample_invalidates_adjacent_coverage(self):
        meter = self.meter(event=30)
        for t, p in [(-1, 2200), (10, float('nan')), (31, 2200)]:
            meter.add(t, p)
        self.assertEqual(meter.report(800, True, final=True)[0]['status'], 'METER_INVALID')

    def test_missing_final_bracket_invalid_not_pass(self):
        meter = self.meter(event=30)
        meter.add(-1, 2000)
        meter.add(29, 2000)
        row = meter.report(800, True, final=True)[0]
        self.assertFalse(row['coverage_complete'])
        self.assertIsNone(row['delivered_mean_w'])

    def test_zero_bid_is_not_delivery_success(self):
        meter = self.meter(event=30)
        meter.add(-1, 3200)
        meter.add(31, 3200)
        row = meter.report(0, False, final=True)[0]
        self.assertEqual(row['status'], 'NOT_COMMITTED')
        self.assertIsNone(row['required_ws'])

    def test_reference_knots_split_inside_meter_window(self):
        contract = FlexibilityContract(30, 60, 30, (3000, 2000), trajectory_step_s=15)
        meter = FixedWindowMeter(contract, max_gap_s=40)
        meter.add(-1, 1000)
        meter.add(31, 1000)
        self.assertAlmostEqual(meter.report(0, False, final=True)[0]['delivered_ws'], 45000)

    def test_linear_power_boundary_interpolation(self):
        meter = self.meter(event=30)
        meter.add(-10, 1900)
        meter.add(30, 2300)
        self.assertAlmostEqual(meter.report(0, False, final=True)[0]['delivered_mean_w'], 850)

    def test_timestamp_reversal_rejected(self):
        meter = self.meter()
        meter.add(2, 1)
        with self.assertRaises(ValueError):
            meter.add(1, 1)

    def test_unobserved_tail_not_claimed_as_complete_feedback(self):
        meter = self.meter()
        meter.add(-1, 2200)
        meter.add(10, 2200)
        self.assertTrue(meter.feedback(10)[2])
        self.assertFalse(meter.feedback(11)[2])

    def test_background_sample_after_control_read_does_not_leak_energy(self):
        meter = self.meter()
        meter.add(-1, 2200)
        meter.add(10, 2200)
        meter.add(11, 2200)
        elapsed, energy, valid = meter.feedback(10)
        self.assertTrue(valid)
        self.assertEqual(elapsed, 10)
        self.assertAlmostEqual(energy, 8000)


class OfferClockTests(unittest.TestCase):
    def session(self, output):
        return EventSession(FlexibilityContract(30, 60, 10, (3000,)),
                            time.time_ns() + 10_000_000_000,
                            meter_reader=lambda: 2200, output_dir=Path(output))

    def test_late_offer_abstains_without_moving_activation(self):
        with patch('flexbid_hybrid.event_protocol.atomic_json'):
            session = self.session('.')
            anchor = session.activation_wall_ns
            with patch.object(session, 'elapsed', return_value=.01):
                session.freeze_offer(800, True, 'candidate')
            self.assertEqual(session.activation_wall_ns, anchor)
            self.assertEqual(session.bid_w, 0)
            self.assertFalse(session.accepted)

    def test_accepted_bid_is_immutable(self):
        with patch('flexbid_hybrid.event_protocol.atomic_json'):
            session = self.session('.')
            session.freeze_offer(800, True, 'candidate')
            with self.assertRaises(RuntimeError):
                session.freeze_offer(100, True, 'reduce after acceptance')
            self.assertEqual(session.bid_w, 800)

    def test_wall_clock_jump_does_not_change_elapsed(self):
        with patch('flexbid_hybrid.event_protocol.atomic_json'):
            session = self.session('.')
            before = session.elapsed()
            with patch('time.time_ns', return_value=0):
                after = session.elapsed()
            self.assertLess(abs(after - before), .1)


class InstallerTests(unittest.TestCase):
    def test_transform_is_idempotent(self):
        root = Path(__file__).resolve().parents[1]
        spec = importlib.util.spec_from_file_location('install_event', root / 'scripts/install_event_protocol.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        for name, transform in module.TRANSFORMS.items():
            source = (root / name).read_text()
            result = transform(source)
            compile(result, name, 'exec')
            self.assertEqual(result, transform(result))


class OfferPreparationTests(unittest.TestCase):
    def fixture(self):
        from unittest.mock import Mock
        action = HybridAction('hybrid_full', 4, 4, 400.)
        step = PlanStep(0, 'event', 300., action, 0, 0, 0, 0, 10, 10)
        plan = MPCPlan(True, 300, 0, (step,), 0, 0, 1, 1, 'fixture only')
        optimizer = SimpleNamespace(baseline_action='hybrid_full', solve=Mock(return_value=plan))
        loop = SimpleNamespace(activation_wall_ns=None, offer_lead_s=1.,
            contract=FlexibilityContract(300, 1800, 30, (3000,)), gpu_indices=[],
            state_path=Path('not_written/latest.json'), meter_sample_s=.2, meter_max_gap_s=1.,
            source='fixture', event_s=300, deadline_s=1800, current_action='hybrid_full',
            ttft_slo_ms=100., tpot_slo_ms=100., features=SimpleNamespace(update=lambda *_: {}),
            baseline_batch_tps=100., initial_cohort_tokens=180000., optimizer=optimizer,
            actions={'hybrid_full': action}, force_baseline=False, _commit=Mock(return_value=250.),
            _actuate=Mock())
        return loop, plan

    def execute(self, loop, elapsed=None):
        with patch.object(EventSession, 'start'), patch.object(EventSession, 'save'), \
             patch.object(EventSession, 'wait_activation'), \
             patch('flexbid_hybrid.runtime_controller.read_component_power_w', return_value=3000):
            if elapsed is not None:
                with patch.object(EventSession, 'elapsed', side_effect=elapsed):
                    return prepare_event(loop, {}, 3000, 10, 10)
            return prepare_event(loop, {}, 3000, 10, 10)

    def test_offer_and_validation_use_full_horizon_without_early_actuation(self):
        loop, _ = self.fixture()
        session = self.execute(loop)
        self.assertTrue(session.accepted)
        self.assertEqual(session.bid_w, 250)
        calls = loop.optimizer.solve.call_args_list
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0].args[0].event_remaining_s, 300)
        self.assertEqual(calls[1].args[0].deadline_remaining_s, 1800)
        self.assertEqual(calls[1].args[0].committed_bid_w, 250)
        loop._actuate.assert_not_called()

    def test_failed_quantized_bid_validation_abstains(self):
        from dataclasses import replace
        loop, plan = self.fixture()
        loop.optimizer.solve.side_effect = [plan, replace(plan, feasible=False)]
        session = self.execute(loop)
        self.assertFalse(session.accepted)
        self.assertEqual(loop.committed_bid_w, 0)
        self.assertFalse(session.prepared_plan.feasible)

    def test_slow_offer_does_not_start_late_positive_event(self):
        loop, _ = self.fixture()
        session = self.execute(loop, [-1., .1])
        self.assertFalse(session.accepted)
        self.assertEqual(loop.committed_bid_w, 0)

    def test_forced_baseline_never_calls_optimizer(self):
        loop, _ = self.fixture()
        loop.force_baseline = True
        session = self.execute(loop)
        self.assertFalse(session.accepted)
        loop.optimizer.solve.assert_not_called()


if __name__ == '__main__':
    unittest.main()
