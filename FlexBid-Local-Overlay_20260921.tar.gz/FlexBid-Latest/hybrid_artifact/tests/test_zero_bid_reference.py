import math
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from flexbid_hybrid.contracts import FlexibilityContract
from flexbid_hybrid.zero_bid_reference import freeze_zero_bid_reference


class ZeroBidReferenceTests(unittest.TestCase):
    def loop(self, **changes):
        values = dict(contract=FlexibilityContract(95, 155, 30), force_baseline=True,
                      event_session=None, committed_bid_w=None,
                      state_path=Path('never_written/latest.json'))
        return SimpleNamespace(**{**values, **changes})

    def test_freezes_actual_measured_mean_with_provenance(self):
        loop = self.loop()
        with patch('flexbid_hybrid.zero_bid_reference.atomic_json') as save:
            freeze_zero_bid_reference(loop, 2456.7)
        self.assertEqual(loop.contract.reference_power_w, (2456.7,))
        self.assertFalse(save.call_args.args[1]['positive_bid_authorized'])
        self.assertFalse(save.call_args.args[1]['dr_baseline_validated'])

    def test_positive_bid_mode_never_uses_implicit_reference(self):
        loop = self.loop(force_baseline=False)
        with self.assertRaisesRegex(ValueError, 'Explicit same-boundary'):
            freeze_zero_bid_reference(loop, 2456.7)
        self.assertEqual(loop.contract.reference_power_w, ())

    def test_invalid_power_rejected(self):
        for value in (None, math.inf, math.nan, 0, -10):
            with self.subTest(value=value), self.assertRaises(ValueError):
                freeze_zero_bid_reference(self.loop(), value)

    def test_existing_reference_is_never_overwritten(self):
        loop = self.loop(force_baseline=False, contract=FlexibilityContract(95, 155, 30, (3000,)))
        with patch('flexbid_hybrid.zero_bid_reference.atomic_json') as save:
            freeze_zero_bid_reference(loop, 2456.7)
            save.assert_not_called()
        self.assertEqual(loop.contract.reference_power_w, (3000,))

    def test_mid_event_or_positive_commitment_rejected(self):
        for changes in ({'event_session': object()}, {'committed_bid_w': 100.}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                freeze_zero_bid_reference(self.loop(**changes), 2456.7)

    def test_failure_to_record_provenance_does_not_freeze_contract(self):
        loop = self.loop()
        with patch('flexbid_hybrid.zero_bid_reference.atomic_json', side_effect=OSError):
            with self.assertRaises(OSError):
                freeze_zero_bid_reference(loop, 2456.7)
        self.assertEqual(loop.contract.reference_power_w, ())

    def test_reference_cannot_change_on_reentry(self):
        loop = self.loop()
        with patch('flexbid_hybrid.zero_bid_reference.atomic_json') as save:
            freeze_zero_bid_reference(loop, 2456.7)
            freeze_zero_bid_reference(loop, 500.)
            self.assertEqual(save.call_count, 1)
        self.assertEqual(loop.contract.reference_power_w, (2456.7,))
