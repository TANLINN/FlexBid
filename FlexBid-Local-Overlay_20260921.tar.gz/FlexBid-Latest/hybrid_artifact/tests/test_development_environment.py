import copy
import importlib.util
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

from flexbid_hybrid import deployment
from flexbid_hybrid.development_episode import SCHEMA
from flexbid_hybrid.development_environment import read_topology

COMMAND = ['nvidia-smi', 'topo', '-m']
OUTPUT = ('231 NICs found in the topology, only displaying 56 in the matrix.\n'
          '\tGPU0 GPU1 GPU2 GPU3 GPU4 GPU5 GPU6 GPU7 CPU Affinity NUMA Affinity\n'
          'Failed to run topology matrix\n')


def config():
    return dict(dynamic_controller=dict(deployment_mode='development',
        allow_unvalidated_development=True, external_commitments_enabled=False,
        force_baseline=False, development_episode=dict(schema=SCHEMA, diagnostic_reference_only=True),
        action_lattice={'baseline': {'online_replicas': 4}}),
        hardware={'gpu_indices': list(range(8))},
        model=dict(name='/model', tokenizer='/tokenizer', replicas=[[0,1],[2,3],[4,5],[6,7]]),
        runtime={}, workloads=dict(batch_prompt_tokens=8192, batch_output_tokens=1024))


def failure(text=OUTPUT, code=255):
    return subprocess.CalledProcessError(code, COMMAND, output=text, stderr='')


class DevelopmentEnvironmentTests(unittest.TestCase):
    def test_known_error_is_not_a_fake_matrix_or_health_certificate(self):
        error=failure()
        with patch('subprocess.run', side_effect=error), patch('builtins.print'):
            matrix, audit=read_topology(config(), diagnostic_topology=True)
        self.assertIsNone(matrix)
        self.assertEqual(audit['stdout'], OUTPUT)
        self.assertEqual(audit['return_code'],255)
        self.assertEqual(audit['status'],'UNAVAILABLE_NIC_ENUMERATION_FAILURE')
        self.assertFalse(audit['deployment_authorized'])
        self.assertFalse(audit['nvlink_verified'])

    def test_default_remains_strict_even_with_development_config(self):
        error=failure()
        with patch('subprocess.run', side_effect=error), self.assertRaises(subprocess.CalledProcessError) as got:
            read_topology(config())
        self.assertIs(got.exception,error)

    def test_production_zero_bid_and_external_configs_cannot_opt_in(self):
        for key,value in [('deployment_mode','production'), ('force_baseline',True),
                ('allow_unvalidated_development',False), ('external_commitments_enabled',True),
                ('development_episode',{}), ('external_commitments_enabled',0)]:
            cfg=config()
            cfg['dynamic_controller'][key]=value
            with patch('subprocess.run') as run, self.assertRaises(ValueError):
                read_topology(cfg,diagnostic_topology=True)
            run.assert_not_called()

    def test_unknown_failure_and_extra_hardware_error_remain_fatal(self):
        for text,code in [('Unknown Error',255),('Failed to run topology matrix',255),
                (OUTPUT,1),(OUTPUT+'GPU has fallen off the bus',255),
                (OUTPUT+'Failed to initialize NVML',255),
                (OUTPUT.replace('231 NICs','5 NICs'),255)]:
            with patch('subprocess.run',side_effect=failure(text,code)), self.assertRaises(subprocess.CalledProcessError):
                read_topology(config(),diagnostic_topology=True)

    def test_timeout_and_missing_executable_not_swallowed(self):
        for exc in [subprocess.TimeoutExpired(COMMAND,15),FileNotFoundError('nvidia-smi')]:
            with patch('subprocess.run',side_effect=exc), self.assertRaises(type(exc)):
                read_topology(config(),diagnostic_topology=True)

    def test_success_records_real_matrix_no_new_driver_flags(self):
        result=SimpleNamespace(stdout=' GPU0 GPU1\nGPU0 X NV12\nGPU1 NV12 X\n',stderr='')
        with patch('subprocess.run',return_value=result) as run:
            matrix,audit=read_topology(config(),diagnostic_topology=True)
        self.assertEqual(matrix,result.stdout.strip())
        self.assertEqual(audit['status'],'OBSERVED')
        run.assert_called_once_with(COMMAND,capture_output=True,text=True,timeout=15,check=True)

    def test_error_signature_may_be_on_stderr(self):
        exc=subprocess.CalledProcessError(255,COMMAND,output='',stderr=OUTPUT)
        with patch('subprocess.run',side_effect=exc), patch('builtins.print'):
            matrix,audit=read_topology(config(),diagnostic_topology=True)
        self.assertIsNone(matrix)
        self.assertEqual(audit['stderr'],OUTPUT)

    def test_real_server_ansi_underline_preserves_raw_evidence(self):
        text = ('231 NICs found in the topology, only displaying 56 in the matrix.\n'
                '\t\x1b[4mGPU0\tGPU1\tGPU2\tGPU3\tGPU4\tGPU5\tGPU6\tGPU7'
                + '\t' * 57 + 'CPU Affinity\tNUMA Affinity\x1b[0m\n'
                'Failed to run topology matrix\n\n')
        with patch('subprocess.run',side_effect=failure(text)), patch('builtins.print'):
            matrix,audit=read_topology(config(),diagnostic_topology=True)
        self.assertIsNone(matrix)
        self.assertEqual(audit['stdout'],text)
        self.assertIn('\x1b[4m',audit['stdout'])
        self.assertFalse(audit['nvlink_verified'])
        with patch('subprocess.run',side_effect=failure(text)), self.assertRaises(subprocess.CalledProcessError):
            read_topology(config())

    def test_ansi_does_not_hide_actual_hardware_error(self):
        text=OUTPUT+'\x1b[31mGPU has fallen off the bus\x1b[0m\n'
        with patch('subprocess.run',side_effect=failure(text)), self.assertRaises(subprocess.CalledProcessError):
            read_topology(config(),diagnostic_topology=True)

    def test_non_sgr_terminal_controls_remain_rejected(self):
        for control in ['\x1b[2J','\x1b[1A','\x1b]0;title\x07']:
            with patch('subprocess.run',side_effect=failure(OUTPUT+control)), self.assertRaises(subprocess.CalledProcessError):
                read_topology(config(),diagnostic_topology=True)

    def nvml(self):
        nvml=Mock()
        nvml.nvmlDeviceGetPowerManagementLimitConstraints.return_value=(100000,400000)
        nvml.nvmlDeviceGetMemoryInfo.return_value=SimpleNamespace(total=80*1024**3)
        nvml.nvmlDeviceGetUUID.return_value='GPU-example'
        nvml.nvmlDeviceGetName.return_value='NVIDIA A800-SXM4-80GB'
        nvml.nvmlSystemGetDriverVersion.return_value='470.161.03'
        return nvml

    def observe(self, *, diagnostic=False, error=None, nvml=None):
        nvml=nvml or self.nvml()
        with patch.dict(sys.modules, {'pynvml':nvml}), patch.object(Path,'exists',return_value=True), \
             patch.object(deployment,'sha256_file',return_value='hash'), \
             patch.object(deployment.importlib.metadata,'version',return_value='version'), \
             patch('subprocess.run',side_effect=error,return_value=SimpleNamespace(stdout='matrix',stderr='')), \
             patch('builtins.print'):
            return deployment.observe_environment(config(),Path('/root'),diagnostic_topology=diagnostic)

    def test_environment_metadata_preserved_and_unknown_explicit(self):
        normal=self.observe()
        self.assertNotIn('topology_observation',normal)
        diagnostic=self.observe(diagnostic=True,error=failure())
        self.assertIsNone(diagnostic.pop('local_topology'))
        audit=diagnostic.pop('topology_observation')
        self.assertEqual(audit['status'],'UNAVAILABLE_NIC_ENUMERATION_FAILURE')
        normal.pop('local_topology')
        self.assertEqual(normal,diagnostic)

    def test_observe_default_still_raises_known_topology_failure(self):
        with self.assertRaises(subprocess.CalledProcessError):
            self.observe(error=failure())

    def test_nvml_failure_not_ignored_in_development(self):
        nvml=self.nvml()
        nvml.nvmlDeviceGetMemoryInfo.side_effect=RuntimeError('NVML failure')
        with self.assertRaisesRegex(RuntimeError,'NVML failure'):
            self.observe(diagnostic=True,nvml=nvml)
        nvml.nvmlShutdown.assert_called_once()

    def test_environment_patch_idempotent_and_preserves_production_binding(self):
        root=Path(__file__).resolve().parents[1]
        spec=importlib.util.spec_from_file_location('installer_environment_test',root/'scripts/install_development_episode.py')
        installer=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(installer)
        current=(root/'flexbid_hybrid/deployment.py').read_text()
        old=current
        for before,after in installer.DEPLOYMENT_EDITS:
            old=old.replace(after,before,1)
        modified=installer.patch_deployment(old+'\n# server-only\n')
        self.assertEqual(installer.patch_deployment(modified),modified)
        self.assertIn('# server-only',modified)
        self.assertEqual(modified.split('def bind_live_model',1)[1],(old+'\n# server-only\n').split('def bind_live_model',1)[1])
        with self.assertRaises(ValueError):
            installer.patch_deployment(old.replace('    ).stdout.strip()','    ).stdout.rstrip()'))


if __name__ == '__main__':
    unittest.main()
