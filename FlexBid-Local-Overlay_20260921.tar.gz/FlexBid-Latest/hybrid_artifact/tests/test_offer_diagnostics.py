import ast
from dataclasses import asdict, replace
import importlib.util
import json
from pathlib import Path
import tempfile
import shutil
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import test_core
from flexbid_hybrid.continuation import GuardedViabilityMPC, ContinuationRejected
from flexbid_hybrid.offer_diagnostics import (ObservedCPUOptimizer, classify_result,
    solve_offer_recorded, flush_offer_diagnostics)

ROOT = Path(__file__).resolve().parents[1]


def load_script(name):
    spec = importlib.util.spec_from_file_location(name, ROOT/'scripts'/f'{name}.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class OfferDiagnosticsTests(unittest.TestCase):
    def setUp(self):
        self.fixture = test_core.ViabilityMPCTests()
        self.state = self.fixture.state()
        self.optimizer = ObservedCPUOptimizer(self.fixture.Model(), self.fixture.actions(), self.fixture.optimizer().parameters)

    def test_observer_preserves_model_plan_and_parameters(self):
        reference = GuardedViabilityMPC(self.fixture.Model(), self.fixture.actions(), self.optimizer.parameters).solve(self.state)
        actual = self.optimizer.solve(self.state)
        a, b = reference.as_dict(), actual.as_dict()
        a.pop('solve_time_ms'); b.pop('solve_time_ms')
        self.assertEqual(a, b)
        self.assertIsNotNone(self.optimizer.search_proposal)
        self.assertEqual(len(self.optimizer.observed_envelopes), 2)
        self.assertEqual(self.optimizer.parameters, self.fixture.optimizer().parameters)

    def test_validator_rejection_is_separate_from_raw_feasible_search(self):
        with patch.object(self.optimizer, 'validate_schedule', side_effect=ContinuationRejected('terminal cohort not completed')):
            result = self.optimizer.solve(self.state)
        self.assertTrue(self.optimizer.search_proposal.feasible)
        self.assertFalse(result.feasible)
        self.assertEqual(classify_result(result), 'SEARCH_PROPOSAL_REJECTED_BY_CONTINUATION_VALIDATOR')
        self.assertIn('terminal cohort', result.validation_reason)

    def test_timeout_does_not_become_physical_infeasibility(self):
        result = self.optimizer.solve(self.state)
        result = replace(result, feasible=False, validation_reason='no applicable cached continuation',
                         underlying_solver_reason='solver budget exceeded; returning safe service fallback')
        self.assertEqual(classify_result(result), 'SEARCH_BUDGET_EXHAUSTED_NOT_INFEASIBILITY_PROOF')

    def session(self, directory):
        return SimpleNamespace(output_dir=Path(directory), run_id='test_run',
                               metadata=lambda:dict(accepted=False, activation_wall_ns=100))

    def test_original_offer_saved_before_baseline_overwrites_it(self):
        with tempfile.TemporaryDirectory() as directory:
            loop = SimpleNamespace(optimizer=self.optimizer, _one_cell_development={'model_sha256':'fixture'})
            session = self.session(directory)
            with patch.object(self.optimizer, 'solve', wraps=self.optimizer.solve) as solve:
                result = solve_offer_recorded(loop, self.state, session, 'initial_offer')
                self.assertIs(result, session._offer_diagnostics[0]['result'])
                solve.assert_called_once_with(self.state)
            self.assertEqual(list(Path(directory).iterdir()), [])  # no disk I/O before offer freeze
            flush_offer_diagnostics(session)
            data = json.loads((Path(directory)/'offer_diagnostic_test_run.json').read_text())
            self.assertEqual(data['solves'][0]['result'], json.loads(json.dumps(result.as_dict())))
            self.assertEqual(data['solves'][0]['state'], json.loads(json.dumps(asdict(self.state))))
            self.assertFalse(data['contract']['accepted'])
            flush_offer_diagnostics(session)  # no duplicate file on second flush

    def test_no_opt_in_has_no_diagnostic_side_effect(self):
        with tempfile.TemporaryDirectory() as directory:
            session = self.session(directory)
            result = solve_offer_recorded(SimpleNamespace(optimizer=self.optimizer), self.state, session, 'initial_offer')
            self.assertTrue(result.feasible)
            self.assertFalse(hasattr(session, '_offer_diagnostics'))
            flush_offer_diagnostics(session)
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_solver_exception_logged_and_rethrown(self):
        with tempfile.TemporaryDirectory() as directory:
            session = self.session(directory)
            loop = SimpleNamespace(optimizer=self.optimizer, _one_cell_development={})
            with patch.object(self.optimizer, 'solve', side_effect=RuntimeError('original error')):
                with self.assertRaisesRegex(RuntimeError, 'original error'):
                    solve_offer_recorded(loop, self.state, session, 'initial_offer')
            data = json.loads((Path(directory)/'offer_diagnostic_test_run.json').read_text())
            self.assertIn('original error', data['solves'][0]['error'])
            self.assertIsNone(data['solves'][0]['result'])

    def test_second_phase_preserves_quantized_commitment(self):
        with tempfile.TemporaryDirectory() as directory:
            session = self.session(directory)
            loop = SimpleNamespace(optimizer=self.optimizer, _one_cell_development={})
            result = solve_offer_recorded(loop, self.state, session, 'initial_offer')
            committed = replace(self.state, committed_bid_w=result.committed_bid_w)
            solve_offer_recorded(loop, committed, session, 'quantized_offer_validation')
            flush_offer_diagnostics(session)
            data = json.loads((Path(directory)/'offer_diagnostic_test_run.json').read_text())
            self.assertEqual(len(data['solves']), 2)
            self.assertEqual(data['solves'][1]['state']['committed_bid_w'], result.committed_bid_w)

    def test_no_overwrite_of_previous_diagnostic(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'offer_diagnostic_test_run.json'
            path.write_text('evidence')
            session = self.session(directory)
            solve_offer_recorded(SimpleNamespace(optimizer=self.optimizer, _one_cell_development={}),
                                self.state, session, 'initial_offer')
            with self.assertRaisesRegex(ValueError, 'no overwrite'):
                flush_offer_diagnostics(session)
            self.assertEqual(path.read_text(), 'evidence')

    def test_runner_parameters_are_read_without_importing_gpu_runner(self):
        script = load_script('diagnose_development_offer')
        params = script.runner_parameters((ROOT/'scripts/run_dynamic_controller.py').read_text(),
                                         {'control_period_s':30, 'calibration_mode':'none'})
        self.assertEqual(params.control_period_s, 30)
        self.assertEqual(params.calibration_mode, 'none')
        self.assertEqual(params.solve_budget_s, 10)
        with self.assertRaises(ValueError):
            script.runner_parameters('p=MPCParameters(solve_budget_s=__import__("os").system("false"))', {})

    def test_exact_state_roundtrip(self):
        script = load_script('diagnose_development_offer')
        from flexbid_hybrid.contracts import FlexibilityContract
        state = replace(self.state, contract=FlexibilityContract(10,20,10,reference_power_w=(400,)))
        self.assertEqual(script.restore_state(json.loads(json.dumps(asdict(state)))), state)

    def test_patch_is_idempotent_and_only_wraps_offer_solves(self):
        installer = load_script('install_offer_diagnostics')
        text = (ROOT/'flexbid_hybrid/event_protocol.py').read_text()
        before = text
        for old, new in reversed(installer.EDITS):
            before = before.replace(new, old)
        after = installer.patch_event(before)
        self.assertEqual(installer.patch_event(after), after)
        # Every unrelated function, including all clock/meter/continuation logic,
        # is AST-identical. Only prepare_event receives logging calls.
        def functions(source):
            return {n.name:ast.dump(n) for n in ast.parse(source).body
                    if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name!='prepare_event'}
        self.assertEqual(functions(before), functions(after))
        with self.assertRaises(ValueError):
            installer.patch_event(before.replace('    session.freeze_offer(bid, bid > 0, reason)\n',''))

    def make_run(self, root, script):
        import yaml
        run = root/'old_run'
        cell = run/'cells/episode'
        cell.mkdir(parents=True)
        for name in ('scripts/run_dynamic_controller.py','flexbid_hybrid/mpc.py',
                     'flexbid_hybrid/continuation.py','flexbid_hybrid/modeling.py',
                     'flexbid_hybrid/gpu_pair_rebuild.py','flexbid_hybrid/offer_diagnostics.py'):
            target = root/name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT/name, target)
        (root/'model.bin').write_bytes(b'test model; loader mocked')
        (root/'dataset.csv').write_text('test dataset; no fitting')
        config = dict(schema_version=1, dynamic_controller=dict(
            deployment_mode='development', allow_unvalidated_development=True,
            external_commitments_enabled=False, force_baseline=False,
            online_residual_adaptation=False, trajectory_calibration=None, calibration_mode='none',
            surrogate_model='model.bin', baseline_dataset='dataset.csv', action_lattice={},
            event_s=10, deadline_s=20, ems_contract={'settlement_interval_s':10},
            **{k:v for k,v in asdict(self.optimizer.parameters).items() if k!='calibration_mode'}),
            slos={'default':{'ttft_ms':5000,'tpot_ms':100}})
        (run/'diagnostic_config.yaml').write_text(yaml.safe_dump(config))
        model_sha, dataset_sha = script.sha256_file(root/'model.bin'), script.sha256_file(root/'dataset.csv')
        def save(path, data):
            path.write_text(json.dumps(data))
        save(run/'DIAGNOSTIC_PLAN.json',dict(config_sha256=script.sha256_file(run/'diagnostic_config.yaml'),model_sha256=model_sha))
        save(cell/'CELL_COMPLETE.json',{})
        save(cell/'cell.json',dict(episode={'episode_id':script.EPISODE,'source':'qwen_bailian'},activation_wall_ns=100))
        save(cell/'DEVELOPMENT_REFERENCE.json',dict(episode_id=script.EPISODE,power_boundary='gpu_nvml',
            diagnostic_reference_only=True,reference_power_w=400,baseline_batch_tps_used=100,initial_cohort_tokens=2000))
        save(cell/'qwen_bailian_controller.jsonl',dict(event_contract={'activation_wall_ns':100},
            baseline_reference={'power_mean_w':400,'ttft_p95_ms':100,'tpot_p99_ms':10,'batch_tokens_per_s':100},
            observation={'elapsed_s':1,'workload_features':{},'observed_component_power_w':405}))
        self.model = self.fixture.Model()
        self.model.power_boundary = 'gpu_nvml'
        return run, cell, model_sha, dataset_sha

    def test_cpu_proxy_end_to_end_preserves_all_input_files(self):
        import contextlib
        import io
        script = load_script('diagnose_development_offer')
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            run, cell, msha, dsha = self.make_run(root, script)
            before = {p:p.read_bytes() for p in run.rglob('*') if p.is_file()}
            with patch.object(script,'MODEL_SHA',msha), patch.object(script,'DATASET_SHA',dsha), \
                 patch.object(script.HybridSurrogate,'load',return_value=self.model), \
                 patch.object(script,'build_action_lattice',return_value=self.fixture.actions()), \
                 contextlib.redirect_stdout(io.StringIO()):
                result = script.diagnose(root,run,root/'probe')
            self.assertEqual(result['input_kind'],'FIRST_RECORDED_STATE_PROXY_NOT_ORIGINAL_OFFER')
            self.assertFalse(result['gpu_workload_started'])
            self.assertFalse(result['deployment_authorized'])
            self.assertEqual(before, {p:p.read_bytes() for p in run.rglob('*') if p.is_file()})
            self.assertTrue((root/'probe/REPORT.json').exists())
            self.assertEqual(result['state']['event_remaining_s'],10)
            self.assertEqual(result['state']['previous_power_w'],405)

    def test_cpu_exact_input_end_to_end(self):
        import contextlib
        import io
        script = load_script('diagnose_development_offer')
        from flexbid_hybrid.contracts import FlexibilityContract
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            run, cell, msha, dsha = self.make_run(root, script)
            state = replace(self.state,contract=FlexibilityContract(10,20,10,reference_power_w=(400,)),
                            previous_power_w=411,source='qwen_bailian')
            saved = dict(schema='development_offer_diagnostics_v1',contract={'activation_wall_ns':100},
                solves=[dict(phase='initial_offer',cached_plan_present=False,identities={'model_sha256':msha},
                    parameters=asdict(replace(self.optimizer.parameters, calibration_mode='none')),baseline_action='hybrid_full',
                    actions=[a.as_dict() for a in self.fixture.actions()],state=asdict(state))])
            (cell/'offer_diagnostic_fixture.json').write_text(json.dumps(saved))
            with patch.object(script,'MODEL_SHA',msha), patch.object(script,'DATASET_SHA',dsha), \
                 patch.object(script.HybridSurrogate,'load',return_value=self.model), \
                 patch.object(script,'build_action_lattice',return_value=self.fixture.actions()), \
                 contextlib.redirect_stdout(io.StringIO()):
                result = script.diagnose(root,run,root/'probe')
            self.assertEqual(result['input_kind'],'EXACT_SAVED_INITIAL_OFFER_INPUT')
            self.assertEqual(result['state']['previous_power_w'],411)  # not post-activation 405

    def test_cpu_config_mutation_blocks_before_model_load(self):
        script = load_script('diagnose_development_offer')
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            run, cell, msha, dsha = self.make_run(root,script)
            with (run/'diagnostic_config.yaml').open('a') as stream:
                stream.write('\n# changed after collection\n')
            with patch.object(script.HybridSurrogate,'load') as load:
                with self.assertRaisesRegex(ValueError,'identity mismatch'):
                    script.diagnose(root,run,root/'probe')
                load.assert_not_called()
            self.assertFalse((root/'probe').exists())


if __name__ == '__main__':
    unittest.main()
