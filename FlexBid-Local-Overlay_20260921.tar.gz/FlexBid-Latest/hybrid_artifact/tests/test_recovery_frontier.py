"""Mechanism tests for the finite-scenario fluid planning model."""

import unittest
from dataclasses import replace

from flexbid_hybrid.recovery_frontier import (
    ActionEffect,
    ObservationNode,
    TransitionState,
    solve_frontier,
)


def effect(name, service=0, power=0, replicas=(0,), safe=True):
    return ActionEffect(name, replicas, service, power, safe)


def observed(name, actions, children=(), **kwargs):
    return ObservationNode(name, name, 1.0, tuple(actions), tuple(children), **kwargs)


INITIAL = TransitionState("initial", (0,), previous_power_w=0)


class RecoveryFrontierTests(unittest.TestCase):
    def test_common_action_then_observation_specific_continuations(self):
        low = observed("low", [effect("low_best", 5), effect("wrong_low", 1)])
        high = observed("high", [effect("wrong_high", 1), effect("high_best", 8)])
        root = observed("now", [effect("shared", 2)], [low, high])
        result = solve_frontier(root, INITIAL)
        self.assertEqual(result.status, "FEASIBLE")
        self.assertEqual(result.max_work_tokens, 7)
        self.assertEqual(result.policy.action.action_id, "shared")
        self.assertEqual([p.action.action_id for p in result.policy.children],
                         ["low_best", "high_best"])
        work = result.policy.for_work(7)
        self.assertEqual(work.remaining_after_tokens, 5)
        self.assertTrue(all(p.remaining_after_tokens == 0 for p in work.children))
        self.assertEqual(result.policy.for_work(1).remaining_after_tokens, 0)
        with self.assertRaisesRegex(ValueError, "exceeds"):
            result.policy.for_work(8)

    def test_independent_future_paths_overstate_a_causal_offer(self):
        left = observed("left", [effect("A", 10), effect("B", 0, replicas=(1,))])
        right = observed("right", [effect("A", 0), effect("B", 10, replicas=(1,))])
        root = observed("now", [effect("A"), effect("B", replicas=(1,))], [left, right])
        # Every root action leaves one possible future with no service while
        # a two-second dwell prevents changing the replica in the second step.
        initial = TransitionState("external", (2,), previous_power_w=0)
        causal = solve_frontier(root, initial, min_replica_dwell_s=2)
        clairvoyant_left = solve_frontier(replace(root, children=(left,)), initial,
                                         min_replica_dwell_s=2)
        clairvoyant_right = solve_frontier(replace(root, children=(right,)), initial,
                                          min_replica_dwell_s=2)
        self.assertEqual(causal.max_work_tokens, 0)
        self.assertEqual(clairvoyant_left.max_work_tokens, 10)
        self.assertEqual(clairvoyant_right.max_work_tokens, 10)
        self.assertNotEqual(clairvoyant_left.policy.action.action_id,
                            clairvoyant_right.policy.action.action_id)
        # When switching really is available, adapting after observation works.
        self.assertEqual(solve_frontier(root, initial).max_work_tokens, 10)

    def test_one_infeasible_future_invalidates_shared_action(self):
        left = observed("left", [effect("service", 5)])
        right = observed("right", [effect("unsafe", 100, safe=False)])
        root = observed("now", [effect("shared", 5)], [left, right])
        result = solve_frontier(root, INITIAL)
        self.assertEqual(result.status, "INFEASIBLE")
        self.assertIsNone(result.max_work_tokens)
        self.assertIsNone(result.policy)

    def test_event_balance_carries_until_its_actual_settlement_boundary(self):
        recovery = observed("recovery", [effect("finish", 5)])
        closing = observed("closing", [effect("dr", 0, 10)], [recovery],
                           stage="event", reference_power_w=20, settlement_end=True)
        root = observed("now", [effect("dr", 0, 10)], [closing],
                        stage="event", reference_power_w=20)
        initial = replace(INITIAL, settlement_balance_ws=-10)
        result = solve_frontier(root, initial, bid_w=5)
        self.assertEqual(result.max_work_tokens, 5)
        self.assertEqual(result.policy.state_after.settlement_balance_ws, -5)
        self.assertEqual(result.policy.children[0].state_after.settlement_balance_ws, 0)
        too_late = solve_frontier(replace(root, settlement_end=True), initial, bid_w=5)
        self.assertEqual(too_late.status, "INFEASIBLE")

    def test_event_total_surplus_does_not_erase_an_earlier_interval_failure(self):
        late = observed("late", [effect("large_surplus", 10, 0)], stage="event",
                        reference_power_w=20, settlement_end=True)
        root = observed("now", [effect("shortfall", 0, 16)], [late], stage="event",
                        reference_power_w=20, settlement_end=True)
        self.assertEqual(solve_frontier(root, INITIAL, bid_w=5).status, "INFEASIBLE")

    def test_recovery_only_keeps_dwell_ramp_and_power_constraints(self):
        root = observed("now", [
            effect("switch", 100, 100, replicas=(1,)),
            effect("too_fast_ramp", 90, 80),
            effect("above_limit", 80, 60),
            effect("unsafe", 70, 40, safe=False),
            effect("stay", 5, 40),
        ], power_limit_w=50)
        initial = replace(INITIAL, dwell_remaining_s=2, previous_power_w=40)
        result = solve_frontier(root, initial, min_replica_dwell_s=3, ramp_limit_w_per_s=10)
        self.assertEqual(result.max_work_tokens, 5)
        self.assertEqual(result.policy.action.action_id, "stay")
        self.assertEqual(result.policy.state_after.dwell_remaining_s, 1)
        ramp_only = observed("ramp", [effect("ramp", 10, 80)], power_limit_w=100)
        self.assertEqual(solve_frontier(ramp_only, initial, ramp_limit_w_per_s=10).status,
                         "INFEASIBLE")

    def test_new_replica_dwell_counts_time_spent_executing_current_action(self):
        tail = observed("tail", [effect("C", 4, replicas=(2,))])
        root = observed("now", [effect("B", 3, replicas=(1,))], [tail])
        self.assertEqual(solve_frontier(root, INITIAL, min_replica_dwell_s=1).max_work_tokens, 7)
        self.assertEqual(solve_frontier(root, INITIAL, min_replica_dwell_s=2).status,
                         "INFEASIBLE")

    def test_dag_reuses_a_suffix_only_with_the_full_transition_state(self):
        tail = observed("tail", [effect("common", 3)])
        left = observed("left", [effect("common", 2)], [tail])
        right = observed("right", [effect("common", 2)], [tail])
        root = observed("now", [effect("common", 1)], [left, right])
        result = solve_frontier(root, INITIAL)
        self.assertEqual(result.max_work_tokens, 6)
        self.assertEqual(result.states_evaluated, 4)
        self.assertIs(result.policy.children[0].children[0], result.policy.children[1].children[0])
        different_right = replace(right, actions=(effect("different", 2, replicas=(1,)),))
        result = solve_frontier(replace(root, children=(left, different_right)), INITIAL)
        self.assertEqual(result.states_evaluated, 5)

    def test_budget_exhaustion_is_unknown_not_physical_infeasibility(self):
        root = observed("now", [effect("serve", 10)])
        for options in ({"max_states": 0}, {"solve_budget_s": 0}):
            result = solve_frontier(root, INITIAL, **options)
            self.assertEqual(result.status, "UNKNOWN")
            self.assertIsNone(result.max_work_tokens)
            self.assertIsNone(result.policy)

    def test_tolerance_is_explicit_not_hidden_state_rounding(self):
        root = observed("now", [effect("dr", 1)], stage="event", settlement_end=True)
        state = replace(INITIAL, settlement_balance_ws=-1e-10)
        self.assertEqual(solve_frontier(root, state, float_tolerance=0).status, "INFEASIBLE")
        self.assertEqual(solve_frontier(root, state, float_tolerance=1e-9).status, "FEASIBLE")

    def test_unobservable_branching_and_unfinished_obligations_are_rejected(self):
        left = observed("left", [effect("serve", 1)])
        right = replace(observed("right", [effect("serve", 1)]), observable_label="left")
        with self.assertRaisesRegex(ValueError, "indistinguishable"):
            solve_frontier(observed("now", [effect("serve")], [left, right]), INITIAL)
        with self.assertRaisesRegex(ValueError, "must close"):
            solve_frontier(observed("event", [effect("serve")], stage="event"), INITIAL)
        with self.assertRaisesRegex(ValueError, "one cohort deadline"):
            solve_frontier(observed("now", [effect("serve")], [left, replace(right, duration_s=2,
                                                                          observable_label="right")]), INITIAL)

    def test_result_exposes_reconstructable_observed_node_policy(self):
        root = observed("now", [effect("serve", 3, 10)])
        output = solve_frontier(root, INITIAL).as_dict()
        self.assertEqual(output["policy"]["node_id"], "now")
        self.assertEqual(output["policy"]["action"]["service_tokens"], 3)
        self.assertEqual(output["policy"]["state_after"]["previous_power_w"], 10)


if __name__ == "__main__":
    unittest.main()
