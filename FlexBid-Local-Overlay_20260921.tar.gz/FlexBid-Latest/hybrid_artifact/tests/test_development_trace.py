import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from flexbid_hybrid.development_trace import BASE_ID, WINDOW_ID, reconstruct, extend_development_trace


class DevelopmentTraceTests(unittest.TestCase):
    def fixture(self, suffix=''):
        raw = [dict(request_id=f'req-{i}', arrival_ms=t, episode_id=BASE_ID,
                    prompt_tokens=100+i, max_output_tokens=10+i, session_id='same-session',
                    parent_request_id=None, source='qwen_bailian', tool_delay_ms=0)
               for i,t in enumerate([0.,1000.,119975.,120000.,121800.,121875.,200000.])]
        old = [dict(r, arrival_ms=r['arrival_ms']*16, episode_id=WINDOW_ID,
                    request_id=r['request_id']+suffix) for r in raw[:3]]
        episode = dict(episode_id=WINDOW_ID, base_episode_id=BASE_ID, source='qwen_bailian',
            requests=len(old), duration_ms=old[-1]['arrival_ms'], split='calibration',
            window_start_raw_s=0., window_end_raw_s=120.)
        original = dict(episode_id=BASE_ID, source='qwen_bailian', requests=len(raw), split='train')
        return episode, old, original, raw

    def test_extends_half_open_window_without_rescaling_prefix(self):
        args=self.fixture()
        result,audit=reconstruct(*args)
        self.assertEqual(result[:3],args[1])
        self.assertEqual([r['arrival_ms'] for r in result[3:]],[1920000.,1948800.])
        self.assertEqual(audit['new_raw_end_s'],121.875)
        self.assertEqual(audit['appended_requests'],2)
        self.assertLess(audit['extended_last_arrival_s'],1950)
        self.assertEqual(audit['replay_coverage_end_s'],1950)
        self.assertFalse(audit['synthetic_requests_added'])

    def test_constant_request_namespace_is_reconstructed(self):
        result,_=reconstruct(*self.fixture(':window-0'))
        self.assertTrue(all(r['request_id'].endswith(':window-0') for r in result))

    def test_existing_prompt_or_session_change_blocks(self):
        for field,value in [('prompt_tokens',999),('session_id','different'),('max_output_tokens',50)]:
            args=self.fixture()
            args[1][1][field]=value
            with self.assertRaisesRegex(ValueError,'prefix does not reproduce'):
                reconstruct(*args)

    def test_new_time_stretch_is_not_allowed(self):
        args=self.fixture()
        args[1][1]['arrival_ms']*=1.01
        with self.assertRaisesRegex(ValueError,'prefix does not reproduce'):
            reconstruct(*args)

    def test_missing_source_future_is_refused(self):
        episode,old,source,raw=self.fixture()
        raw=raw[:4]
        source['requests']=len(raw)
        with self.assertRaisesRegex(ValueError,'coverage beyond'):
            reconstruct(episode,old,source,raw)

    def test_genuine_quiet_tail_is_not_missing_coverage(self):
        episode,old,source,raw=self.fixture()
        raw=raw[:3]+raw[-1:]
        source['requests']=len(raw)
        result,audit=reconstruct(episode,old,source,raw)
        self.assertEqual(result,old)
        self.assertEqual(audit['appended_requests'],0)
        self.assertTrue(audit['zero_tail_requests_is_not_missing_coverage'])

    def test_ambiguous_parent_mapping_for_tail_is_refused(self):
        args=self.fixture(':window-0')
        args[3][3]['parent_request_id']='req-1'
        with self.assertRaisesRegex(ValueError,'Parent-link transform ambiguous'):
            reconstruct(*args)

    def test_parent_mapping_proven_on_prefix_is_preserved(self):
        args=self.fixture(':window-0')
        args[3][1]['parent_request_id']='req-0'
        args[1][1]['parent_request_id']='req-0:window-0'
        args[3][3]['parent_request_id']='req-1'
        result,audit=reconstruct(*args)
        self.assertEqual(result[3]['parent_request_id'],'req-1:window-0')
        self.assertEqual(audit['parent_mapping'],'namespaced')

    def test_manifest_count_mismatch_blocks(self):
        args=self.fixture()
        args[0]['requests']=99
        with self.assertRaisesRegex(ValueError,'request-count mismatch'):
            reconstruct(*args)

    def test_duplicate_ids_block(self):
        args=self.fixture()
        args[3][-1]['request_id']=args[3][0]['request_id']
        with self.assertRaisesRegex(ValueError,'Duplicate request IDs'):
            reconstruct(*args)

    def test_file_extension_preserves_original_bytes_and_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            project=Path(tmp)
            root=project/'hybrid_artifact'
            output=root/'results'/'new-run'
            output.mkdir(parents=True)
            adapted=project/'paper_artifact/data/adapted'
            adapted.mkdir(parents=True)
            episode,old,source,raw=self.fixture()
            original_file=root/'old-generated.jsonl'
            raw_file=adapted/'raw.jsonl'
            original_bytes='\r\n'.join(json.dumps(r,indent=None) for r in old).encode()
            original_file.write_bytes(original_bytes)
            raw_file.write_text('\n'.join(map(json.dumps,raw)))
            episode['path']=str(original_file)
            source['path']='raw.jsonl'
            manifest=adapted/'manifest.json'
            manifest.write_text(json.dumps({'episodes':[source]}))
            before={p:p.read_bytes() for p in [manifest,raw_file,original_file]}
            with patch('builtins.print'):
                result,audit=extend_development_trace(root,episode,output,1.)
            self.assertEqual(result['requests'],5)
            self.assertEqual(result['window_end_raw_s'],121.875)
            self.assertEqual(result['declared_replay_coverage_ms'],1950000)
            self.assertTrue(Path(result['path']).read_bytes().startswith(original_bytes))
            self.assertEqual(before,{p:p.read_bytes() for p in before})
            self.assertTrue(audit['original_file_bytes_preserved_as_prefix'])
            with self.assertRaises(FileExistsError):
                extend_development_trace(root,episode,output,1.)


if __name__ == '__main__':
    unittest.main()
