import json
import ast
import math
import unittest
import uuid
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

import test_core
from flexbid_hybrid.continuation import GuardedViabilityMPC, ContinuationRejected
from flexbid_hybrid.contracts import FlexibilityContract
from flexbid_hybrid.deployment import (
    DeploymentRejected, EnvironmentBoundModel, REQUIRED_RANGES, sha256_file,
    validate_domain, bind_live_model,
)
from flexbid_hybrid.mpc import MPCParameters


class ContinuationTests(unittest.TestCase):
    def setUp(self):
        self.fixture = test_core.ViabilityMPCTests()
        self.model = self.fixture.Model()
        self.optimizer = GuardedViabilityMPC(
            self.model, self.fixture.actions(),
            replace(self.fixture.optimizer().parameters, terminal_cohort_tolerance_tokens=0),
        )

    def failure(self, state, reason="solver budget exceeded"):
        import time
        return self.optimizer._fallback(state, self.optimizer.envelopes(state), time.perf_counter(), reason)

    def test_next_replan_timeout_revalidates_cached_pause_not_boost(self):
        state = self.fixture.state(event=20, deadline=40)
        plan = self.optimizer.solve(state)
        self.assertTrue(plan.feasible)
        new = replace(state, event_remaining_s=10, deadline_remaining_s=30,
                      current_action="pause", backlog_tokens=1000, committed_bid_w=200)
        failure = self.failure(new)
        self.assertEqual(failure.first_action.name, "boost")  # reproduce old failure path
        with patch.object(self.optimizer, "_search", return_value=failure):
            result = self.optimizer.solve(new)
        self.assertTrue(result.feasible)
        self.assertEqual(result.first_action.name, "pause")
        self.assertEqual(result.committed_bid_w, 200)
        self.assertEqual(result.controller_status, "MODEL_VALIDATED_CACHED_CONTINUATION")
        self.assertFalse(result.optimality_proven)

    def test_changed_recovery_bounds_invalidate_cache(self):
        state = self.fixture.state(event=20, deadline=40)
        self.optimizer.solve(state)
        self.model.unsafe.add("boost")
        new = replace(state, event_remaining_s=10, deadline_remaining_s=30,
                      current_action="pause", backlog_tokens=1000, committed_bid_w=200)
        with patch.object(self.optimizer, "_search", return_value=self.failure(new)):
            result = self.optimizer.solve(new)
        self.assertFalse(result.feasible)
        self.assertEqual(result.committed_bid_w, 200)  # cannot erase old obligation
        self.assertFalse(result.continuation_model_validated)

    def test_cohort_constraint_is_rechecked_not_only_debt(self):
        state = self.fixture.state()
        plan = self.optimizer.solve(state)
        with self.assertRaises(ContinuationRejected):
            self.optimizer.validate_schedule(
                replace(state, cohort_remaining_tokens=10000), plan.steps,
                self.optimizer.envelopes(state), bid_w=plan.committed_bid_w)

    def test_dwell_constraint_rechecked(self):
        state = self.fixture.state()
        plan = self.optimizer.solve(state)
        new = replace(state, replica_dwell_remaining_s=30)
        with self.assertRaises(ContinuationRejected):
            self.optimizer.validate_schedule(new, plan.steps, self.optimizer.envelopes(new), bid_w=200)

    def test_recovery_envelope_rechecked(self):
        state = self.fixture.state()
        plan = self.optimizer.solve(state)
        new = replace(state, contract=FlexibilityContract(10, 20, 10, recovery_power_envelope_w=(410,)))
        with self.assertRaises(ContinuationRejected):
            self.optimizer.validate_schedule(new, plan.steps, self.optimizer.envelopes(new), bid_w=200)

    def test_measured_settlement_deficit_rechecked(self):
        state = self.fixture.state()
        plan = self.optimizer.solve(state)
        new = replace(state, settlement_elapsed_s=5, settlement_delivered_ws=-10000)
        with self.assertRaises(ContinuationRejected):
            self.optimizer.validate_schedule(new, plan.steps, self.optimizer.envelopes(new), bid_w=200)

    def test_timeout_before_offer_never_invents_positive_bid(self):
        state = self.fixture.state()
        with patch.object(self.optimizer, "_search", return_value=self.failure(state)):
            result = self.optimizer.solve(state)
        self.assertFalse(result.feasible)
        self.assertEqual(result.committed_bid_w, 0)
        self.assertEqual(result.first_action.name, "hybrid_full")

    def test_emergency_event_does_not_maximize_batch_throughput(self):
        state = self.fixture.state(committed=200)
        with patch.object(self.optimizer, "_search", return_value=self.failure(state)):
            result = self.optimizer.solve(state)
        self.assertFalse(result.feasible)
        self.assertEqual(result.first_action.name, "pause")
        self.assertEqual(result.committed_bid_w, 200)

    def test_new_contract_does_not_reuse_old_schedule(self):
        state = self.fixture.state()
        self.optimizer.solve(state)
        new = replace(state, committed_bid_w=200, contract=FlexibilityContract(10, 20, 10))
        self.assertIsNone(self.optimizer._cache_offset(new))

    def test_bid_tracks_model_capability_not_fixed_watts(self):
        bids = []
        for pause_power in (200, 250, 350):
            model = self.fixture.Model()
            model.values = dict(model.values, pause=(pause_power, 100, 10, 0))
            optimizer = GuardedViabilityMPC(model, self.fixture.actions(), self.optimizer.parameters)
            plan = optimizer.solve(self.fixture.state())
            self.assertTrue(plan.feasible)
            bids.append(plan.committed_bid_w)
        # At the last setting throttle (100 W) beats pause (50 W): the
        # optimizer must change action, not preserve a hand-written pause rule.
        self.assertEqual(bids, [200, 150, 100])
        self.assertEqual(plan.first_action.name, "throttle")

    def test_new_plan_does_not_claim_global_optimality(self):
        result = self.optimizer.solve(self.fixture.state())
        self.assertFalse(result.as_dict()["optimality_proven"])


class DomainTests(unittest.TestCase):
    def setUp(self):
        self.root = Path(__file__).resolve().parent
        evidence = self.root / ("domain_test_" + uuid.uuid4().hex + ".json")
        self.evidence = evidence
        self.addCleanup(lambda: evidence.unlink(missing_ok=True))
        evidence.write_text("{}")
        self.env = {"gpus": [{"uuid": "one", "name": "A800"}], "driver": "d1"}
        self.domain = {
            "schema_version": 1, "status": "TARGET_VALIDATED", "power_boundary": "gpu_nvml",
            "model_sha256": "model", "environment": self.env, "sources": ["qwen_bailian"],
            "feature_ranges_by_source": {"qwen_bailian": {k: [0, 100] for k in REQUIRED_RANGES}},
            "evidence_files": [{"role": role, "path": str(evidence), "sha256": sha256_file(evidence)}
                               for role in ("target_calibration", "target_validation")],
        }

    def validate(self, **kwargs):
        values = dict(domain=self.domain, environment=self.env, model_hash="model",
                      source="qwen_bailian", model_boundary="gpu_nvml", root=self.root)
        values.update(kwargs)
        return validate_domain(**values)

    def test_matching_metadata_accepted_but_is_not_statistical_certificate(self):
        self.assertEqual(set(self.validate()), set(REQUIRED_RANGES))

    def test_new_server_gpu_uuid_rejected(self):
        with self.assertRaises(DeploymentRejected):
            self.validate(environment={"gpus": [{"uuid": "two", "name": "A800"}], "driver": "d1"})

    def test_driver_change_rejected(self):
        with self.assertRaises(DeploymentRejected):
            self.validate(environment={**self.env, "driver": "d2"})

    def test_new_gpu_type_rejected(self):
        with self.assertRaises(DeploymentRejected):
            self.validate(environment={"gpus": [{"uuid": "two", "name": "H100"}], "driver": "d1"})

    def test_component_model_cannot_be_silently_used_with_gpu_meter(self):
        for boundary in (None, "gpu_plus_rapl"):
            with self.assertRaises(DeploymentRejected):
                self.validate(model_boundary=boundary)

    def test_new_model_requires_new_evidence(self):
        with self.assertRaises(DeploymentRejected):
            self.validate(model_hash="changed")

    def test_observation_is_not_approval(self):
        with self.assertRaises(DeploymentRejected):
            self.validate(domain={**self.domain, "status": "OBSERVATION_ONLY_NOT_VALIDATED"})

    def test_changed_evidence_rejected(self):
        self.evidence.write_text('{"changed":true}')
        with self.assertRaises(DeploymentRejected):
            self.validate()

    def test_missing_evidence_stops_live_entry_before_gpu_query(self):
        with self.assertRaises(DeploymentRejected):
            bind_live_model(None, None, {"dynamic_controller": {}}, self.root, "qwen_bailian")

    def test_development_is_explicit_and_never_certifies_deployment(self):
        model = test_core.ViabilityMPCTests.Model()
        model.power_boundary = "gpu_nvml"
        settings = {"deployment_mode": "development", "allow_unvalidated_development": True,
                    "external_commitments_enabled": False}
        wrapped = bind_live_model(model, model, {"dynamic_controller": settings}, self.root, "qwen_bailian")
        self.assertEqual(wrapped.deployment_status, "UNVALIDATED_DEVELOPMENT_ONLY")
        with self.assertRaises(DeploymentRejected):
            bind_live_model(model, model, {"dynamic_controller": {**settings, "external_commitments_enabled": True}},
                            self.root, "qwen_bailian")
        model.power_boundary = "gpu_plus_rapl"
        with self.assertRaises(DeploymentRejected):
            bind_live_model(model, model, {"dynamic_controller": settings}, self.root, "qwen_bailian")


class InstallerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import importlib.util
        path = Path(__file__).resolve().parents[1] / "scripts/install_runtime_safety.py"
        spec = importlib.util.spec_from_file_location("safety_installer", path)
        cls.installer = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.installer)

    def test_runtime_patch_preserves_server_cold_start_and_is_idempotent(self):
        root = Path(__file__).resolve().parents[1]
        text = (root / "flexbid_hybrid/runtime_controller.py").read_text(encoding="utf-8")
        # A server-side cold-start condition must survive the installer.
        run = self.installer.method(text, "run")
        branch = next(node for node in ast.walk(run) if isinstance(node, ast.If) and any(
            isinstance(statement, ast.Assign)
            and ast.unparse(statement) == "action = self.actions[self.optimizer.baseline_action]"
            for statement in node.body))
        text = self.installer.replace_node(text, branch.test,
            "cold_start_abstain or (self.offer_calibrator is not None and not self.offer_accepted)")
        updated = self.installer.patch_runtime(text)
        self.assertIn("cold_start_abstain", updated)
        self.assertIn("self.force_baseline or (cold_start_abstain", updated)
        self.assertEqual(self.installer.patch_runtime(updated), updated)

    def test_runner_and_mpc_patches_are_idempotent(self):
        root = Path(__file__).resolve().parents[1]
        for relative, transform in (
            ("scripts/run_dynamic_controller.py", self.installer.patch_runner),
            ("flexbid_hybrid/mpc.py", self.installer.patch_mpc),
        ):
            text = (root / relative).read_text(encoding="utf-8")
            updated = transform(text)
            self.assertEqual(transform(updated), updated)

    def test_unknown_runner_anchor_is_rejected(self):
        with self.assertRaises(ValueError):
            self.installer.patch_runner("def main():\n    pass\n")

    def test_load_shift_has_infinite_unsafe_bounds_not_optimistic_extrapolation(self):
        model = test_core.ViabilityMPCTests.Model()
        model.supports = lambda row: row["name"] in model.values
        bound = EnvironmentBoundModel(model, "qwen_bailian", {"online_arrival_rate_rps": [1, 10]})
        row = {"source": "qwen_bailian", "name": "pause", "online_arrival_rate_rps": 5}
        self.assertTrue(bound.supports(row))
        self.assertEqual(bound.bounds(row, "none").power_upper_w, 200)
        for bad in (11, math.nan, math.inf, None):
            invalid = {**row, "online_arrival_rate_rps": bad}
            self.assertFalse(bound.supports(invalid))
            self.assertTrue(math.isinf(bound.bounds(invalid, "none").tpot_upper_ms))


if __name__ == "__main__":
    unittest.main()
