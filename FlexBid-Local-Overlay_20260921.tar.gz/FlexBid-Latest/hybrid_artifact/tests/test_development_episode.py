import copy
from dataclasses import replace
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from flexbid_hybrid.contracts import FlexibilityContract
from flexbid_hybrid import development_episode as dev
from flexbid_hybrid.zero_bid_reference import freeze_zero_bid_reference

ROOT = Path(__file__).resolve().parents[1]


def module(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / ('scripts/'+name+'.py'))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


installer = module('install_development_episode')
runner = module('run_development_episode')


class DevelopmentEpisodeTests(unittest.TestCase):
    def loop(self):
        return SimpleNamespace(force_baseline=False, event_session=None, committed_bid_w=None,
            contract=FlexibilityContract(event_s=300, deadline_s=1800, settlement_interval_s=30), activation_wall_ns=1000000,
            state_path=Path('/not-written/current.json'), baseline_batch_tps=100., initial_cohort_tokens=180000.,
            warmup_s=120, source='qwen_bailian', gpu_indices=list(range(8)), event_s=300, deadline_s=1800,
            offer_lead_s=30, offer_calibrator=None, dry_run=False)

    def test_default_hook_is_noop(self):
        loop = self.loop()
        dev.configure_development_episode(loop, {'dynamic_controller':{}})
        dev.freeze_development_reference(loop, None, [])
        self.assertFalse(loop.contract.reference_power_w)

    def test_zero_bid_guard_still_rejects_positive_reference_fallback(self):
        with self.assertRaisesRegex(ValueError, 'Explicit same-boundary reference'):
            freeze_zero_bid_reference(self.loop(), 2500.)

    def test_opt_in_does_not_create_fixed_offer(self):
        loop = self.loop()
        loop._one_cell_development = {'schema':dev.SCHEMA}
        with patch.object(dev.time, 'time_ns', return_value=100), patch.object(Path, 'exists', return_value=False), patch.object(dev, 'atomic_json') as save:
            dev.freeze_development_reference(loop, 2500., [2400.,2500.,2600.])
        self.assertEqual(loop.contract.reference_power_w, (2500.,))
        self.assertIsNone(loop.committed_bid_w)
        self.assertFalse(save.call_args.args[1]['deployment_authorized'])
        self.assertFalse(save.call_args.args[1]['counterfactual_baseline_validated'])

    def test_reference_refuses_late_frozen_or_invalid_observation(self):
        for change, samples in [({'activation_wall_ns':100},[2500.]*3),
                ({'committed_bid_w':1},[2500.]*3), ({'event_session':object()},[2500.]*3),
                ({},[2500.]), ({},[float('nan')]*3)]:
            loop = self.loop()
            loop._one_cell_development = {}
            for k,v in change.items():
                setattr(loop,k,v)
            with patch.object(dev.time,'time_ns',return_value=100), self.assertRaises(ValueError):
                dev.freeze_development_reference(loop,2500.,samples)

    def test_opt_in_rejects_external_or_production(self):
        for d in [dict(development_episode={}), dict(development_episode={'schema':dev.SCHEMA,
                'diagnostic_reference_only':True}, external_commitments_enabled=True)]:
            with self.assertRaises(ValueError):
                dev.configure_development_episode(self.loop(), {'dynamic_controller':d})

    def test_configuration_checks_identity_and_only_attaches_development_metadata(self):
        loop=self.loop()
        d=dict(development_episode=dict(schema=dev.SCHEMA,diagnostic_reference_only=True),
            deployment_mode='development',allow_unvalidated_development=True,
            external_commitments_enabled=False,force_baseline=False,calibration_mode='none',
            trajectory_calibration=None,online_residual_adaptation=False,
            surrogate_model='/model.joblib',baseline_dataset='/dataset.csv')
        cell=dict(episode=dict(episode_id=dev.EPISODE),activation_wall_ns=loop.activation_wall_ns)
        with patch.object(dev,'sha256_file',side_effect=[dev.MODEL_SHA,dev.DATASET_SHA]), \
             patch.object(Path,'read_text',return_value=json.dumps(cell)):
            dev.configure_development_episode(loop,{'dynamic_controller':d})
        self.assertEqual(loop._one_cell_development['schema'],dev.SCHEMA)
        self.assertFalse(loop.contract.reference_power_w)
        self.assertIsNone(loop.committed_bid_w)
        with patch.object(dev,'sha256_file',return_value='changed'), self.assertRaisesRegex(ValueError,'candidate changed'):
            dev.configure_development_episode(self.loop(),{'dynamic_controller':d})

    def test_provenance_write_failure_never_installs_reference(self):
        loop=self.loop()
        loop._one_cell_development={}
        with patch.object(dev.time,'time_ns',return_value=100), patch.object(Path,'exists',return_value=False), \
             patch.object(dev,'atomic_json',side_effect=OSError), self.assertRaises(OSError):
            dev.freeze_development_reference(loop,2500.,[2500.]*3)
        self.assertFalse(loop.contract.reference_power_w)

    def test_narrow_hooks_idempotent_preserve_server_hotfix(self):
        runtime = (ROOT / 'flexbid_hybrid/runtime_controller.py').read_text()
        runtime = runtime.replace(installer.RUNTIME_CALL, '')
        runtime = runtime.replace(installer.RUNTIME_ANCHOR, '            cold_start_abstain = True # server-only\n'+installer.RUNTIME_ANCHOR)
        result = installer.patch_runtime(runtime)
        self.assertIn('cold_start_abstain = True # server-only', result)
        self.assertEqual(installer.patch_runtime(result),result)
        controller = (ROOT / 'scripts/run_dynamic_controller.py').read_text()
        self.assertEqual(installer.patch_runner(installer.patch_runner(controller)),installer.patch_runner(controller))
        with self.assertRaises(ValueError):
            installer.patch_runtime('print("wrong version")')

    def config(self):
        return dict(dynamic_controller=dict(force_baseline=True, action_lattice=dict(
            online_replicas=[2,3,4], batch_concurrency=[0,1,2,4,5,6], power_cap_w=[300,400],
            baseline=dict(online_replicas=4,batch_concurrency=4,power_cap_w=400)),
            ems_contract=dict(ramp_limit_w_per_s=50)),
            hardware=dict(gpu_indices=list(range(8))),model=dict(replicas=[[0,1],[2,3],[4,5],[6,7]]),
            workloads=dict(arrival_scale_by_source={'qwen_bailian':1.}), slos=dict(default=dict(ttft_ms=5000,tpot_ms=100)))

    def test_multiline_force_baseline_and_single_quotes_are_accepted(self):
        original=self.runner_fixture()
        source=original.replace('force_baseline=bool(dynamic.get("force_baseline", False)),',
            "force_baseline=bool(\n            dynamic.get('force_baseline', False)\n        ),")
        self.assertNotIn('force_baseline=bool(dynamic.get("force_baseline", False))',source)
        result=installer.patch_runner(source)
        self.assertEqual(result,source.replace(installer.RUNNER_ANCHOR,installer.RUNNER_CALL+installer.RUNNER_ANCHOR))
        self.assertEqual(installer.patch_runner(result),result)

    def test_comment_cannot_supply_missing_binding(self):
        source=self.runner_fixture().replace(
            '    model = bind_live_model(model, frozen_model, config, root, args.source, offline=args.dry_run)',
            '    # model = bind_live_model(model, frozen_model, config, root, args.source, offline=args.dry_run)')
        with self.assertRaisesRegex(ValueError,'DEPLOYMENT_BINDING_MISSING'):
            installer.patch_runner(source)

    def test_constant_false_is_not_zero_bid_forwarding(self):
        source=self.runner_fixture().replace(
            'force_baseline=bool(dynamic.get("force_baseline", False))','force_baseline=False')
        with self.assertRaisesRegex(ValueError,'FORCE_BASELINE_FORWARDING_MISSING'):
            installer.patch_runner(source)

    def test_different_guard_import_is_refused(self):
        source=self.runner_fixture().replace(
            'from flexbid_hybrid.deployment import bind_live_model','from unrelated_module import bind_live_model')
        with self.assertRaisesRegex(ValueError,'DEPLOYMENT_BINDING_MISSING'):
            installer.patch_runner(source)

    def test_guard_result_cannot_be_discarded(self):
        source=self.runner_fixture().replace(
            '    optimizer = GuardedViabilityMPC(model, actions, parameters)',
            '    model = frozen_model\n    optimizer = GuardedViabilityMPC(model, actions, parameters)')
        with self.assertRaisesRegex(ValueError,'DEPLOYMENT_BINDING_OVERWRITTEN'):
            installer.patch_runner(source)

    def test_optimizer_cannot_use_unguarded_model(self):
        source=self.runner_fixture().replace(
            'GuardedViabilityMPC(model, actions, parameters)','GuardedViabilityMPC(frozen_model, actions, parameters)')
        with self.assertRaisesRegex(ValueError,'DEPLOYMENT_BINDING_UNRECOGNIZED'):
            installer.patch_runner(source)

    def runner_fixture(self):
        # Deliberately independent of the installed server's formatting: these
        # are AST-transform fixtures, not a replacement/executable GPU runner.
        return '''def main():
    from flexbid_hybrid.deployment import bind_live_model
    model = bind_live_model(model, frozen_model, config, root, args.source, offline=args.dry_run)
    optimizer = GuardedViabilityMPC(model, actions, parameters)
    loop = DynamicControlLoop(
        optimizer=optimizer,
        force_baseline=bool(dynamic.get("force_baseline", False)),
    )
    loop.run()
'''

    def prepare(self, config, times=(0,120,150,450,950,1450,1960)):
        episode = dict(episode_id=dev.EPISODE,source='qwen_bailian',split='calibration',path='/trace.jsonl')
        text='\n'.join(json.dumps(dict(arrival_ms=t*1000)) for t in times)
        def digest(p):
            return dev.MODEL_SHA if str(p).endswith('.joblib') else dev.DATASET_SHA
        with patch.object(runner,'load_config',return_value=config), \
             patch.object(runner,'select_episodes',return_value=[episode]), \
             patch.object(runner,'extend_development_trace',return_value=(episode,{'replay_coverage_end_s':1950})), \
             patch.object(runner,'sha256_file',side_effect=digest), \
             patch.object(Path,'read_text',return_value=text), patch.object(Path,'write_text'), \
             patch.object(runner,'atomic_json') as save:
            runner.prepare(ROOT,Path('source.yaml'),ROOT/'not-written')
        return save

    def test_one_cell_preserves_lattice_slos_no_fixed_w(self):
        cfg=self.config()
        original=copy.deepcopy(cfg)
        save=self.prepare(cfg)
        d=cfg['dynamic_controller']
        self.assertEqual(d['action_lattice'],original['dynamic_controller']['action_lattice'])
        self.assertEqual(cfg['slos'],original['slos'])
        self.assertEqual(d['ems_contract']['ramp_limit_w_per_s'],50)
        self.assertFalse(d['force_baseline'])
        self.assertEqual((d['event_s'],d['deadline_s'],d['warmup_s'],d['offer_lead_s']),(300,1800,120,30))
        self.assertEqual(d['solver_engine'],'frontier')
        self.assertEqual((d['baseline_sample_s'],d['baseline_tail_s']),(1.,30.))
        self.assertIsNone(save.call_args.args[1]['fixed_bid_w'])
        self.assertTrue(save.call_args.args[1]['reused_development_trace'])

    def test_full_recovery_trace_coverage_required(self):
        with self.assertRaisesRegex(ValueError,'coverage'):
            self.prepare(self.config(),(0,120,150,450,1960))

    def test_audit_keeps_failed_delivery_and_excludes_drain_tokens(self):
        with tempfile.TemporaryDirectory() as tmp:
            output=Path(tmp)
            cell=output/'cells'/'one'
            cell.mkdir(parents=True)
            marker=dict(event_protocol_complete=True,controller_return_code=0,online_return_code=0,batch_return_code=0)
            activation=150*10**9
            metadata=dict(episode=dict(episode_id=dev.EPISODE),measurement_start_wall_ns=0)
            reference=dict(frozen_wall_ns=120*10**9,diagnostic_reference_only=True,external_commitments_enabled=False,
                initial_cohort_tokens=180000,baseline_batch_tps_used=100,reference_power_w=2500)
            contract=dict(activation_wall_ns=activation,deadline_wall_ns=1950*10**9,accepted=True,committed_bid_w=123,reason='raw MPC')
            event=dict(contract=contract,windows=[dict(coverage_complete=True,status='UNDERDELIVERED',delivered_mean_w=-10)]*10,meter_error=None)
            for name,obj in [('CELL_COMPLETE.json',marker),('cell.json',metadata),('DEVELOPMENT_REFERENCE.json',reference),('event_protocol_one.json',event)]:
                (cell/name).write_text(json.dumps(obj))
            row=dict(actuation=dict(dry_run=False,enforced_caps_w={str(i):300 for i in range(8)},control=dict(action=dict(online_replicas=2,batch_concurrency=0,power_cap_w=300))),observation=dict(elapsed_s=0))
            (cell/'qwen_bailian_controller.jsonl').write_text(json.dumps(row)+'\n')
            online=[dict(dispatch_wall_time_ns=int(s*1e9),ttft_ms=10,mean_tpot_ms=20,error=None) for s in [10,200,500]]
            batch=[dict(completion_wall_time_ns=int(s*1e9),completion_tokens=1024,error=None) for s in [30,200,1951]]
            for name,records in [('online.jsonl',online),('batch.jsonl',batch)]:
                (cell/name).write_text('\n'.join(map(json.dumps,records)))
            with patch.object(runner,'load_config',return_value=self.config()), patch('builtins.print'):
                result=runner.performance_report(output)
            self.assertEqual(result['diagnostic_underfilled_windows'],10)
            self.assertEqual(result['completed_batch_tokens_activation_to_deadline'],1024)
            self.assertFalse(result['external_delivery_verified'])
            self.assertNotIn('PASS',result['status'])
            event['contract'].update(accepted=False,committed_bid_w=0)
            (cell/'event_protocol_one.json').write_text(json.dumps(event))
            with patch.object(runner,'load_config',return_value=self.config()), patch('builtins.print'):
                result=runner.performance_report(output)
            self.assertEqual(result['status'],'DEVELOPMENT_ABSTAINED_NO_CURTAILMENT_VALIDATION')


if __name__ == '__main__':
    unittest.main()
