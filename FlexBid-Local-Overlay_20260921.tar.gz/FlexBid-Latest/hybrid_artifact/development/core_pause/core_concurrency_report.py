"""Summarize the C1-C8 development sweep from original cell reports."""
import csv
import json


def summarize(output, spec, complete):
    import cohort_phase_measurement as m
    rows = []
    cells = []
    for item in spec['order']:
        cell = output / 'cells' / item['cell_name']
        path = cell / 'REPORT.json'
        if not path.is_file():
            cells.append(dict(cell=cell.name, measured=False))
            continue
        report = json.loads(path.read_text())
        event = report['phases']['event_time_reference']
        power = report['gpu_power']['stages']
        row = dict(cell=cell.name, event_c=item['event_batch_concurrency'],
            event_p_w=item['event_cap_w'],
            service_deadline_pass=report['service_and_deadline_pass_observed'],
            event_service_safe=event['observed_slo_safe'],
            event_ttft_p95_ms=event['ttft_p95_ms'],
            event_gap_p99_ms=event['request_mean_stream_gap_p99_ms'],
            on_time=report['batch']['jobs_completed_on_time'],
            late=report['batch']['jobs_completed_late'],
            unfinished=report['batch']['jobs_unfinished_or_failed'],
            deadline_slack_s=report['cohort_timing']['all_job_completion_slack_s'],
            event_mean_gpu_w=power['event']['mean_gpu_w'],
            event_energy_wh=power['event']['gpu_energy_wh'],
            recovery_energy_wh=power['recovery']['gpu_energy_wh'],
            evaluation_energy_wh=power['evaluation']['gpu_energy_wh'])
        rows.append(row)
        cells.append(dict(cell=cell.name, measured=True, failed_checks=report['failed_checks'],
                          row=row))
    rows.sort(key=lambda value: value['event_c'])
    report = dict(status='CORE_CONCURRENCY_SWEEP_COMPLETE' if complete else
                  'CORE_CONCURRENCY_SWEEP_PARTIAL', measured_cells=len(rows),
                  planned_cells=len(spec['order']), cells=cells,
                  scope='One development identity and one run per new C. C0/C5 are saved separately; boundary points require repetition before inferential claims.')
    m.write_json(output / 'REPORT.json', report)
    if rows:
        with (output / 'RESULTS.csv').open('w', newline='', encoding='utf-8') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)
    lines = ['=== CORE_CONCURRENCY_SWEEP ===', 'STATUS=' + report['status'],
             f'MEASURED_CELLS={len(rows)}/{len(spec["order"])}']
    lines.extend('CELL=' + json.dumps(row) for row in rows)
    lines += [report['scope'], 'REPORT_JSON=' + str(output / 'REPORT.json'),
              'RESULTS_CSV=' + str(output / 'RESULTS.csv')]
    (output / 'REPORT.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return report
