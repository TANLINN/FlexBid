"""Check whether saved P300/P350/P400 runs can supply the coarse power curve."""
import json
from pathlib import Path
import re
import sys


def read(path):
    return json.loads(path.read_text())


def stable_environment(value):
    gpu = value.get('gpu_inventory', value.get('gpus', {}))
    return dict(python=value.get('python'), packages=value.get('packages'),
                torch_cuda=value.get('torch_cuda'), gpu_inventory=gpu)


def protocol_projection(value):
    keys = ('duration_s', 'cohort_release_offset_s', 'batch_admission_offset_s',
            'recovery_start_offset_s', 'deadline_offset_s', 'deadline_s',
            'recovery_batch_concurrency', 'online_concurrency')
    return {key: value.get(key) for key in keys if key in value}


def discover_pause(root):
    found = {}
    for cell in (root / 'cells').glob('*'):
        condition = cell / 'CONDITION.json'
        report = cell / 'REPORT.json'
        if not condition.is_file() or not report.is_file():
            continue
        value = read(condition)
        match = re.search(r'_p(\d+)_c(\d+)$', cell.name)
        if not match:
            continue
        p = int(match.group(1))
        c = int(value.get('event_batch_concurrency', -1))
        if c == 5 and p in (300, 400):
            found.setdefault(p, cell)
    return found


def audit(project, output):
    pause = project / 'results/core_pause_run_20260919_124043_gd0PiC'
    p350 = project / 'results/core_boundary_20260915_214607_7AYMZ5/cells/r01_001918_p350'
    found = discover_pause(pause)
    runs = {300: found.get(300), 350: p350, 400: found.get(400)}
    missing = [p for p, path in runs.items() if path is None or not (path / 'REPORT.json').is_file()]
    if missing:
        raise FileNotFoundError(f'Missing saved power points: {missing}')
    records = []
    for p, path in sorted(runs.items()):
        protocol = read(path / 'protocol.json')
        environment = read(path / 'ENVIRONMENT.json')
        report = read(path / 'REPORT.json')
        inputs = Path(protocol['input_root'])
        summary = read(inputs / 'INPUT_SUMMARY.json')
        records.append(dict(p=p, run=str(path), input_root=str(inputs),
            episode_id=summary['episode_id'], online_requests=summary.get('online_requests'),
            batch_jobs=summary.get('batch_jobs'), environment=stable_environment(environment),
            protocol=protocol_projection(protocol), event_c=5,
            on_time=report['batch']['jobs_completed_on_time'],
            event_safe=report['phases']['event_time_reference']['observed_slo_safe']))
    checks = dict(
        same_episode=len({row['episode_id'] for row in records}) == 1,
        same_input_root=len({row['input_root'] for row in records}) == 1,
        same_environment=all(row['environment'] == records[0]['environment'] for row in records[1:]),
        same_protocol_projection=all(row['protocol'] == records[0]['protocol'] for row in records[1:]),
        all_event_c5=all(row['event_c'] == 5 for row in records),
        all_saved_points_complete=all(row['on_time'] == 280 for row in records))
    result = dict(status='CORE_POWER_REUSE_AUDIT_COMPLETE', checks=checks,
                  all_checks_pass=all(checks.values()), runs=records,
                  scope='Saved P300/P350/P400 reuse compatibility. Run order and startup variation remain.')
    output.mkdir(parents=True, exist_ok=True)
    (output / 'REPORT.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('=== CORE_POWER_REUSE_AUDIT ===')
    print(json.dumps(result))
    print('REPORT_JSON=' + str(output / 'REPORT.json'))
    if not result['all_checks_pass']:
        raise SystemExit('Saved power points are not reusable as one coarse curve')


if __name__ == '__main__':
    audit(Path(sys.argv[1]), Path(sys.argv[2]))
