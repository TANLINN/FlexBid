import asyncio
import json
from pathlib import Path
import tempfile
import time
import unittest
from core_concurrency_campaign import CONCURRENCIES, plan, wait_gpu_quiescence
from core_pause_sources import cohort_source, runner_source
import cohort_phase_measurement as m


class ConcurrencySweepTests(unittest.TestCase):
    def test_missing_points_complete_c0_through_c8(self):
        self.assertEqual(set(CONCURRENCIES) | {0, 5}, set(range(9)))
        self.assertEqual(len(CONCURRENCIES), len(set(CONCURRENCIES)))

    def test_low_high_interleaving_and_deadline(self):
        self.assertEqual(CONCURRENCIES, (1, 8, 2, 7, 3, 6, 4))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'protocol.json').write_text(json.dumps(dict(input_root=str(root))))
            (root / 'INPUT_SUMMARY.json').write_text(json.dumps(
                dict(episode_id='azure_conversation:azure-001918')))
            spec = plan(root)
            self.assertEqual(spec['deadline_s'], 1950)
            self.assertEqual(spec['event_p'], 300)
            self.assertEqual(spec['recovery_c'], 6)

    def test_boundary_repeat_plan(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'protocol.json').write_text(json.dumps(dict(input_root=str(root))))
            (root / 'INPUT_SUMMARY.json').write_text(json.dumps(
                dict(episode_id='azure_conversation:azure-001918')))
            spec = plan(root, (3, 6, 2))
            self.assertEqual([row['event_batch_concurrency'] for row in spec['order']], [3, 6, 2])

    def test_quiescence_records_stale_context_then_clear(self):
        from unittest.mock import patch
        class Result:
            returncode=0; stderr=''
            def __init__(self, stdout): self.stdout=stdout
        with tempfile.TemporaryDirectory() as directory, patch(
                'core_concurrency_campaign.subprocess.run',
                side_effect=[Result('255477, [Not Found]\n'), Result('')]), patch(
                'core_concurrency_campaign.time.sleep'):
            out=Path(directory)
            wait_gpu_quiescence(out, timeout_s=10)
            record=json.loads((out/'GPU_QUIESCENCE.json').read_text())
            self.assertEqual(record['status'],'QUIESCENT')
            self.assertEqual(len(record['observations']),2)

    def test_source_supports_c8_and_eight_workers(self):
        root = Path(__file__).parent
        runner = runner_source((root / 'run_core_boundary_cell.py').read_text())
        cohort = cohort_source((root / 'cohort_phase_measurement.py').read_text())
        self.assertIn('range(0, 9)', runner)
        self.assertIn("concurrency=max(int(protocol['event_batch_concurrency'])", cohort)


class RuntimeConcurrencyTests(unittest.IsolatedAsyncioTestCase):
    async def test_eight_client_workers_are_reachable(self):
        active = maximum = 0
        lock = asyncio.Lock()
        start = time.time_ns()
        protocol = dict(start_wall_ns=start, duration_s=1, drain_s=.1,
            cohort_release_offset_s=0, batch_admission_offset_s=0,
            event_batch_concurrency=8, recovery_start_offset_s=.8,
            recovery_batch_concurrency=6)
        async def request(row, kind):
            nonlocal active, maximum
            async with lock:
                active += 1; maximum = max(maximum, active)
            await asyncio.sleep(.02)
            async with lock:
                active -= 1
            return dict(completion_tokens=1024)
        results = []
        await m.execute_requests([], [dict(job_id=i) for i in range(16)], protocol,
            request, lambda kind, row: results.append(row), concurrency=8)
        self.assertEqual(maximum, 8)
        self.assertEqual(len(results), 16)


if __name__ == '__main__':
    unittest.main()
