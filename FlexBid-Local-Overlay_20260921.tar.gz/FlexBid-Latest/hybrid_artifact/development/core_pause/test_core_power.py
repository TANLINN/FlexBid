import json
from pathlib import Path
import tempfile
import unittest
from core_power_campaign import POWER_CAPS, plan


class PowerSweepTests(unittest.TestCase):
    def source(self, root):
        (root / 'protocol.json').write_text(json.dumps(dict(input_root=str(root))))
        (root / 'INPUT_SUMMARY.json').write_text(json.dumps(
            dict(episode_id='azure_conversation:azure-001918')))

    def test_only_missing_coarse_caps_are_run(self):
        self.assertEqual(POWER_CAPS, (100, 250, 150, 200))
        self.assertEqual(set(POWER_CAPS) | {300, 350, 400},
                         {100, 150, 200, 250, 300, 350, 400})

    def test_plan_keeps_c5_and_original_deadline(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); self.source(root)
            spec = plan(root)
            self.assertEqual(spec['deadline_s'], 1950)
            self.assertEqual(spec['event_c'], 5)
            self.assertTrue(all(row['event_batch_concurrency'] == 5 for row in spec['order']))

    def test_integer_hardware_range_is_enforced(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); self.source(root)
            with self.assertRaises(ValueError): plan(root, (99,))
            with self.assertRaises(ValueError): plan(root, (200, 200))


if __name__ == '__main__':
    unittest.main()
