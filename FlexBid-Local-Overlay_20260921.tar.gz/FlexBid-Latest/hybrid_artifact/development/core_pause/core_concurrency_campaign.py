"""Measure the missing C1-C8 event-admission points on one saved workload."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time


CONCURRENCIES = (1, 8, 2, 7, 3, 6, 4)


def write(path, value):
    path.write_text(json.dumps(value, indent=2), encoding='utf-8')


def wait_gpu_quiescence(output, timeout_s=180):
    """Wait for driver cleanup between owned cells; never terminate a process."""
    began = time.monotonic()
    observations = []
    while True:
        query = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name',
            '--format=csv,noheader,nounits'], text=True, capture_output=True, timeout=20)
        observations.append(dict(elapsed_s=time.monotonic() - began,
            returncode=query.returncode, stdout=query.stdout, stderr=query.stderr))
        if query.returncode != 0:
            write(output / 'GPU_QUIESCENCE.json', dict(status='QUERY_FAILED', observations=observations))
            raise RuntimeError('GPU process query failed while waiting for cell cleanup')
        if not query.stdout.strip():
            write(output / 'GPU_QUIESCENCE.json', dict(status='QUIESCENT', observations=observations))
            return
        if time.monotonic() - began >= timeout_s:
            write(output / 'GPU_QUIESCENCE.json', dict(status='TIMEOUT', observations=observations))
            raise RuntimeError('GPU processes remained after bounded inter-cell cleanup wait')
        time.sleep(2)


def plan(source, concurrencies=CONCURRENCIES):
    protocol = json.loads((source / 'protocol.json').read_text())
    inputs = Path(protocol['input_root'])
    summary = json.loads((inputs / 'INPUT_SUMMARY.json').read_text())
    identity = summary['episode_id']
    if identity != 'azure_conversation:azure-001918':
        raise ValueError('Expected saved 001918 workload')
    order = [dict(cell_name=f'c{c}_p300', event_cap_w=300,
                  event_batch_concurrency=c, input_root=str(inputs))
             for c in concurrencies]
    return dict(order=order, source_run=str(source), identity=identity,
        existing_points=dict(c0='core_pause_run_20260919_124043_gd0PiC',
                             c5='core_pause_run_20260919_124043_gd0PiC'),
        cohort_jobs=280, cohort_release_s=150, event_start_s=150,
        recovery_start_s=450, deadline_s=1950, event_p=300,
        recovery_p=400, recovery_c=6, measurement_minutes=32.5 * len(order),
        startup_and_drain_extra=True, automatic_retry=False,
        purpose='Complete the C0-C8 development response curve; C0 and C5 are reused.',
        followup='Repeat only boundary, reversal, or decision-relevant points.')


def run(project, source, prepared, output, concurrencies=CONCURRENCIES):
    sys.path[:0] = [str(project), str(project / 'scripts'), str(prepared),
                    str(prepared / 'cell_template')]
    from flexbid_hybrid.service import stop_process
    from core_concurrency_report import summarize
    spec = plan(source, concurrencies)
    write(output / 'EXPERIMENT_PLAN.json', spec)
    try:
        for position, item in enumerate(spec['order'], 1):
            if position > 1:
                wait_gpu_quiescence(output)
            cell = output / 'cells' / item['cell_name']
            (cell / 'logs').mkdir(parents=True, exist_ok=False)
            for path in (prepared / 'cell_template').glob('*.py'):
                shutil.copyfile(path, cell / path.name)
            write(cell / 'CONDITION.json', dict(recovery_queue_priority=True,
                episode_id=spec['identity'],
                event_batch_concurrency=item['event_batch_concurrency'],
                minimum_power_w=100, maximum_power_w=400))
            cmd = [sys.executable, '-B', '-u', str(cell / 'run_core_boundary_cell.py'),
                '--project', str(project), '--source', str(source),
                '--input-root', item['input_root'], '--output', str(cell),
                '--event-cap', str(item['event_cap_w'])]
            write(output / 'CURRENT_CELL.json', {**item, 'position': position,
                                                  'state': 'STARTING'})
            env = dict(os.environ)
            env['PYTHONPATH'] = str(cell) + os.pathsep + env.get('PYTHONPATH', '')
            with (cell / 'logs/launcher.log').open('w') as log:
                process = subprocess.Popen(cmd, cwd=project, env=env, stdout=log,
                    stderr=subprocess.STDOUT, start_new_session=True)
                write(output / 'CURRENT_CELL.json', {**item, 'position': position,
                    'state': 'RUNNING', 'pid': process.pid})
                try:
                    code = process.wait()
                finally:
                    if process.poll() is None:
                        stop_process(process, timeout_s=180)
            if code:
                raise RuntimeError(f'{cell.name} exited with {code}; see {cell}/logs/launcher.log')
            summarize(output, spec, complete=False)
            print('MEASURED=' + cell.name, flush=True)
        summarize(output, spec, complete=True)
        write(output / 'CURRENT_CELL.json', {'state': 'COMPLETE', 'completed_cells': len(spec['order'])})
    except BaseException as exc:
        write(output / 'CAMPAIGN_ERROR.json', dict(error_type=type(exc).__name__,
              error=str(exc), automatic_retry=False))
        summarize(output, spec, complete=False)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for name in ('project', 'source', 'prepared', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--concurrencies', nargs='+', type=int, default=list(CONCURRENCIES))
    args = parser.parse_args()
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'Signal {signum}')
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    run(args.project.resolve(), args.source.resolve(), args.prepared.resolve(), args.output.resolve(), tuple(args.concurrencies))
