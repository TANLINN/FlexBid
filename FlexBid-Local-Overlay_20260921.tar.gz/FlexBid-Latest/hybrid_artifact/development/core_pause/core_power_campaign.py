"""Run the missing coarse event-power points at fixed event C5."""
import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys

from core_concurrency_campaign import wait_gpu_quiescence, write


POWER_CAPS = (100, 250, 150, 200)


def plan(source, caps=POWER_CAPS):
    protocol = json.loads((source / 'protocol.json').read_text())
    inputs = Path(protocol['input_root'])
    summary = json.loads((inputs / 'INPUT_SUMMARY.json').read_text())
    identity = summary['episode_id']
    if identity != 'azure_conversation:azure-001918':
        raise ValueError('Expected saved 001918 workload')
    caps = tuple(int(value) for value in caps)
    if len(caps) != len(set(caps)) or any(value not in range(100, 401) for value in caps):
        raise ValueError('Power caps must be unique integer watts in the recorded 100-400 W range')
    order = [dict(cell_name=f'p{p}_c5', event_cap_w=p,
                  event_batch_concurrency=5, input_root=str(inputs)) for p in caps]
    return dict(order=order, source_run=str(source), identity=identity,
        reused_points=dict(p300='core_pause_run_20260919_124043_gd0PiC',
                           p350='core_boundary_20260915_214607_7AYMZ5/cells/r01_001918_p350',
                           p400='core_pause_run_20260919_124043_gd0PiC'),
        cohort_jobs=280, cohort_release_s=150, event_start_s=150,
        recovery_start_s=450, deadline_s=1950, event_c=5,
        recovery_p=400, recovery_c=6, measurement_minutes=32.5 * len(order),
        startup_and_drain_extra=True, automatic_retry=False,
        purpose='Complete the missing P100/P150/P200/P250 coarse event-power points at C5.',
        followup='Merge with comparable saved P300/P350/P400, then refine only a measured boundary.')


def run(project, source, prepared, output, caps=POWER_CAPS):
    sys.path[:0] = [str(project), str(project / 'scripts'), str(prepared),
                    str(prepared / 'cell_template')]
    from flexbid_hybrid.service import stop_process
    from core_power_report import summarize
    spec = plan(source, caps)
    write(output / 'EXPERIMENT_PLAN.json', spec)
    try:
        for position, item in enumerate(spec['order'], 1):
            if position > 1:
                wait_gpu_quiescence(output)
            cell = output / 'cells' / item['cell_name']
            (cell / 'logs').mkdir(parents=True, exist_ok=False)
            for path in (prepared / 'cell_template').glob('*.py'):
                shutil.copyfile(path, cell / path.name)
            write(cell / 'CONDITION.json', dict(recovery_queue_priority=True,
                episode_id=spec['identity'], event_batch_concurrency=5,
                minimum_power_w=100, maximum_power_w=400))
            cmd = [sys.executable, '-B', '-u', str(cell / 'run_core_boundary_cell.py'),
                '--project', str(project), '--source', str(source),
                '--input-root', item['input_root'], '--output', str(cell),
                '--event-cap', str(item['event_cap_w'])]
            write(output / 'CURRENT_CELL.json', {**item, 'position': position, 'state': 'STARTING'})
            env = dict(os.environ)
            env['PYTHONPATH'] = str(cell) + os.pathsep + env.get('PYTHONPATH', '')
            with (cell / 'logs/launcher.log').open('w') as log:
                process = subprocess.Popen(cmd, cwd=project, env=env, stdout=log,
                    stderr=subprocess.STDOUT, start_new_session=True)
                write(output / 'CURRENT_CELL.json', {**item, 'position': position,
                    'state': 'RUNNING', 'pid': process.pid})
                try:
                    code = process.wait()
                finally:
                    if process.poll() is None:
                        stop_process(process, timeout_s=180)
            if code:
                raise RuntimeError(f'{cell.name} exited with {code}; see {cell}/logs/launcher.log')
            summarize(output, spec, complete=False)
            print('MEASURED=' + cell.name, flush=True)
        summarize(output, spec, complete=True)
        write(output / 'CURRENT_CELL.json', {'state': 'COMPLETE', 'completed_cells': len(spec['order'])})
    except BaseException as exc:
        write(output / 'CAMPAIGN_ERROR.json', dict(error_type=type(exc).__name__,
              error=str(exc), automatic_retry=False))
        summarize(output, spec, complete=False)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for name in ('project', 'source', 'prepared', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--caps', nargs='+', type=int, default=list(POWER_CAPS))
    args = parser.parse_args()
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'Signal {signum}')
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    run(args.project.resolve(), args.source.resolve(), args.prepared.resolve(),
        args.output.resolve(), tuple(args.caps))
