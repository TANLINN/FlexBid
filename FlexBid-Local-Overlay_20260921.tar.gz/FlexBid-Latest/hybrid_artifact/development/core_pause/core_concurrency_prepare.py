"""Prepare the missing-concurrency sweep without starting services."""
import ast
import json
from pathlib import Path
import shutil
import sys
from core_pause_sources import runner_source, reporter_source, cohort_source, BOUNDARY_REPORT
from core_concurrency_campaign import plan


def prepare(source, output, concurrencies=None):
    template = output / 'cell_template'
    template.mkdir()
    for parent in (source.parent.parent, source):
        for path in parent.glob('*.py'):
            shutil.copyfile(path, template / path.name)
    required = ('run_core_boundary_cell.py', 'core_recovery_cell_report.py',
                'cohort_phase_measurement.py', 'core_boundary_report.py',
                'conversation_quartile_power.py', 'core_serial_startup.py')
    for name in required:
        if not (template / name).is_file():
            raise FileNotFoundError(template / name)
    path = template / 'run_core_boundary_cell.py'
    path.write_text(runner_source(path.read_text()), encoding='utf-8')
    path = template / 'core_recovery_cell_report.py'
    path.write_text(reporter_source(path.read_text()), encoding='utf-8')
    path = template / 'cohort_phase_measurement.py'
    path.write_text(cohort_source(path.read_text()), encoding='utf-8')
    (template / 'core_boundary_cell_report.py').write_text(BOUNDARY_REPORT, encoding='utf-8')
    for path in template.glob('*.py'):
        ast.parse(path.read_text(encoding='utf-8'), feature_version=(3, 10))
    spec = plan(source) if concurrencies is None else plan(source, tuple(concurrencies))
    (output / 'EXPERIMENT_PLAN.json').write_text(json.dumps(spec, indent=2), encoding='utf-8')
    report = dict(status='CORE_CONCURRENCY_SWEEP_PREPARED_CPU_ONLY', source=str(source),
        output=str(output), order=spec['order'], measurement_minutes=spec['measurement_minutes'],
        syntax_pass=True, gpu_workload=False, keepalive_stopped=False, installed=False,
        scope=f'Saved-source preparation only. {len(spec["order"])} physical measurements remain unstarted.')
    (output / 'REPORT.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print('=== CORE_CONCURRENCY_SWEEP_PREPARATION ===')
    print(json.dumps(report))


if __name__ == '__main__':
    prepare(Path(sys.argv[1]), Path(sys.argv[2]), [int(value) for value in sys.argv[3:]] or None)
