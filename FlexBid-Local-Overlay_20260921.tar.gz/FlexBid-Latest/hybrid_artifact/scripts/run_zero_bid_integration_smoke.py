#!/usr/bin/env python3
"""One real-workload zero-bid integration diagnostic. NOT DR validation."""
import argparse
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from flexbid_hybrid.config import load_config, resolve
from flexbid_hybrid.io import atomic_json
from flexbid_hybrid.pilot import select_episodes


def prepare(root, source_path, output):
    import yaml
    config = load_config(source_path)
    chosen = [row for row in select_episodes(root, config)
              if row['episode_id'] == 'qwen_bailian:bailian-000009:trajectory-window-0']
    if len(chosen) != 1:
        raise ValueError('Need exactly the previously used Qwen diagnostic trace; no substitute chosen')
    episode = chosen[0]
    dynamic = config['dynamic_controller']
    if dynamic.get('force_baseline') is not True:
        raise ValueError('Expected restored force_baseline config')
    # No trained model, SLO, request timing/length or hardware layout is changed.
    dynamic.update(force_baseline=True, event_s=95., deadline_s=155., warmup_s=120.,
                   offer_lead_s=30., control_period_s=7., meter_sample_s=.2,
                   meter_max_gap_s=1., calibration_mode='none', trajectory_calibration=None,
                   online_residual_adaptation=False, external_commitments_enabled=False,
                   runtime_results=str(output))
    dynamic['ems_contract'] = dict(event_s=95., deadline_s=155., settlement_interval_s=30.,
        trajectory_step_s=30., reference_power_w=[], recovery_power_envelope_w=[],
        rebound_limit_w=math.inf, ramp_limit_w_per_s=math.inf)
    dynamic['action_lattice'] = dict(online_replicas=[4], batch_concurrency=[4], power_cap_w=[400],
        baseline=dict(online_replicas=4, batch_concurrency=4, power_cap_w=400))
    dynamic.pop('initial_cohort_tokens', None)  # derive from the diagnostic horizon, not old 1800 s
    for key in ('surrogate_model', 'baseline_dataset'):
        dynamic[key] = str(resolve(root, dynamic[key]))
        if not Path(dynamic[key]).is_file():
            raise FileNotFoundError(dynamic[key])
    if config['hardware']['gpu_indices'] != list(range(8)) or config['model']['replicas'] != [[0,1],[2,3],[4,5],[6,7]]:
        raise ValueError('This diagnostic is for the current 8-GPU/4-TP2 configuration only')
    scale = float(config['workloads']['arrival_scale_by_source'][episode['source']])
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('Invalid arrival scale')
    arrivals = [float(json.loads(line)['arrival_ms']) * scale / 1000
                for line in Path(episode['path']).read_text().splitlines() if line.strip()]
    bins = [(0, 120), (120, 150), (150, 245), (245, 305)]
    counts = [sum(a <= t < b for t in arrivals) for a, b in bins]
    if not arrivals or max(arrivals) < 305 or not all(counts):
        raise ValueError('Insufficient real trace coverage for warmup/lead/event/post-event observation')
    manifest = output / 'diagnostic_manifest.json'
    atomic_json(manifest, {'episodes': [episode]})
    config['workloads'].update(manifest=str(manifest), sources=[episode['source']],
        episode_selections=[dict(source=episode['source'], split=episode['split'], count=1, offset=0)],
        test_episodes_per_source=1, measurement_s=305.)
    config['actions'] = [dict(name='hybrid_full', online_replicas=4, batch_concurrency=4, power_cap_w=400.)]
    config['hardware']['control_file'] = str(output / 'control.json')
    config.setdefault('paths', {})['results_root'] = str(output)
    config['experiment_name'] = output.name
    path = output / 'diagnostic_config.yaml'
    path.write_text(yaml.safe_dump(config, sort_keys=False), encoding='utf-8')
    if len(select_episodes(root, config)) != 1:
        raise ValueError('Expected exactly one diagnostic cell')
    atomic_json(output / 'DIAGNOSTIC_PLAN.json', dict(
        purpose='real-workload zero-bid clock and process-lifecycle integration only',
        reused_development_trace=True, confirmatory=False, expected_cells=1,
        workload_seconds=305, warmup_s=120, offer_lead_s=30, event_s=95,
        deadline_from_activation_s=155, post_event_observation_s=60,
        settlement_interval_s=30, final_window_s=5,
        phase_request_counts=counts, config=str(path), episode=episode,
        fixed_baseline_action=config['actions'][0], positive_bid_authorized=False))
    return path


def audit(output):
    cells = list((output / 'cells').glob('*/CELL_COMPLETE.json'))
    if len(cells) != 1:
        raise ValueError('Need exactly one completed diagnostic cell')
    cell = cells[0].parent
    marker = json.loads(cells[0].read_text())
    reports = list(cell.glob('event_protocol_*.json'))
    if len(reports) != 1:
        raise ValueError('Need exactly one event report')
    report = json.loads(reports[0].read_text())
    rows = [json.loads(line) for p in cell.glob('*_controller.jsonl')
            for line in p.read_text().splitlines() if line.strip()]
    baseline_only = bool(rows)
    for row in rows:
        actuation = row.get('actuation', {})
        action = actuation.get('control', {}).get('action', {})
        baseline_only &= (actuation.get('dry_run') is False
            and row.get('committed_bid_w') == 0
            and (action.get('online_replicas'), action.get('batch_concurrency'), action.get('power_cap_w')) == (4, 4, 400))
    provenance = json.loads((cell / 'ZERO_BID_REFERENCE.json').read_text())
    checks = dict(event_protocol_complete=marker.get('event_protocol_complete') is True,
        processes_succeeded=all(marker.get(k) == 0 for k in
            ('controller_return_code', 'online_return_code', 'batch_return_code')),
        no_request_errors=all(marker.get(k) == 0 for k in ('online_errors', 'online_load_shed', 'batch_errors')),
        real_requests=marker.get('online_requests', 0) > 0,
        real_batch_jobs=marker.get('batch_jobs_completed', 0) > 0,
        baseline_only=baseline_only, zero_bid=report['contract']['committed_bid_w'] == 0,
        no_commitment=report['contract']['accepted'] is False,
        four_windows=len(report['windows']) == 4,
        coverage=all(r['coverage_complete'] and r['status'] == 'NOT_COMMITTED' for r in report['windows']),
        final_window=report['windows'][-1]['end_s'] - report['windows'][-1]['start_s'] == 5,
        diagnostic_reference=provenance.get('positive_bid_authorized') is False)
    result = dict(status='PASS_ZERO_BID_INTEGRATION_ONLY' if all(checks.values()) else 'FAIL_ZERO_BID_INTEGRATION',
        checks=checks, controller_records=len(rows), event_report=str(reports[0]),
        dr_delivery_verified=False, slo_verified=False, mpc_performance_verified=False,
        recovery_deadline_verified=False, target_environment_validated=False)
    atomic_json(output / 'ZERO_BID_INTEGRATION_REPORT.json', result)
    print(json.dumps(result, indent=2), flush=True)
    if not all(checks.values()):
        raise ValueError('Diagnostic integration checks failed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', required=True, type=Path)
    parser.add_argument('--audit-only', action='store_true')
    args = parser.parse_args()
    output = args.output_root.resolve()
    if args.audit_only:
        audit(output)
        return
    import fcntl  # server launcher is Linux-only
    from install_runtime_safety import active_collectors
    with (ROOT / 'results/zero_bid_integration.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if active_collectors(ROOT):
            raise RuntimeError('Another collector/controller is active; no experiment started')
        if (output / 'DIAGNOSTIC_PLAN.json').exists() or (output / 'cells').exists():
            raise ValueError('NEW output root required; old results preserved')
        output.mkdir(parents=True, exist_ok=True)
        (output / 'launcher.pid').write_text(str(os.getpid()) + '\n')
        env = {**os.environ, 'PYTHONPATH': str(ROOT) + os.pathsep + os.environ.get('PYTHONPATH', ''),
               'PATH': str(Path(sys.executable).parent) + os.pathsep + os.environ.get('PATH', '')}
        try:
            path = prepare(ROOT, ROOT / 'configs/generated/a800_8gpu_qwen35_27b_dynamic_reference_baseline.yaml', output)
            print('ONE_CELL_READY; zero bid; 305 s workload plus engine startup/drain', flush=True)
            # All imports/deserialization happen before launching four GPU replicas.
            subprocess.run([sys.executable, '-B', '-c',
                'import vllm; from pathlib import Path; from flexbid_hybrid.config import load_config; '
                'from flexbid_hybrid.modeling import HybridSurrogate; '
                'import sys; c=load_config(Path(sys.argv[1])); '
                'HybridSurrogate.load(Path(c["dynamic_controller"]["surrogate_model"])); '
                'print("MODEL_IMPORT_OK")', str(path)], cwd=ROOT, env=env, check=True)
            subprocess.run([sys.executable, '-B', 'scripts/preflight.py', '--config', str(path),
                            '--output', str(output / 'preflight.json')], cwd=ROOT, env=env, check=True)
            subprocess.run([sys.executable, '-B', '-u', 'scripts/run_dynamic_policy_selection.py',
                '--config', str(path), '--output-root', str(output)], cwd=ROOT, env=env, check=True)
            audit(output)
        except BaseException as exc:
            atomic_json(output / 'ZERO_BID_INTEGRATION_FAILED.json', dict(error=repr(exc),
                no_automatic_retry=True, instruction='Preserve logs; no broad cleanup or GPU retention started'))
            raise


if __name__ == '__main__':
    main()
