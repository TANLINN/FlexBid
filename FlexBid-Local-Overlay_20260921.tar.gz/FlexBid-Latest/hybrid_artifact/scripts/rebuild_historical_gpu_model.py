"""Read preserved static measurements; write a NEW offline GPU-only candidate."""
import argparse
import csv
from collections import Counter
import inspect
import json
import math
import os
from pathlib import Path
import sys

from flexbid_hybrid.gpu_pair_rebuild import (
    HistoricalGpuPairedSurrogate, digest, inventory, read_rows, rebuild,
)
from flexbid_hybrid.modeling import HybridSurrogate

CAMPAIGNS = (
    "hybrid_formal_profile_a800_qwen35_27b_20260821_v2",
    "hybrid_formal_ablation_a800_qwen35_27b_20260822",
    "hybrid_recovery_support_train_a800_qwen35_27b_20260828",
    "hybrid_recovery_support_calibration_a800_qwen35_27b_20260828",
)


def strict_json(value):
    if isinstance(value, float) and not math.isfinite(value):
        return "Infinity" if value > 0 else "-Infinity" if value < 0 else "NaN"
    if isinstance(value, dict):
        return {str(k): strict_json(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [strict_json(v) for v in value]
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", default="results/hybrid_dynamic_recovery_supported_offline_20260828/models/hybrid_surrogate_dataset.csv")
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--campaign", action="append")
    parser.add_argument("--max-gap-s", type=float, default=2.0)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    dataset = (root / args.dataset).resolve()
    output = (root / args.output_root).resolve()
    if output.exists():
        raise ValueError("Output already exists; choose a fresh directory (no resume/overwrite)")
    if root / "results" not in output.parents:
        raise ValueError("Output must be a new directory under project results")
    output.mkdir(parents=True)

    def save(name, data):
        (output / name).write_text(json.dumps(strict_json(data), indent=2, allow_nan=False), encoding="utf-8")

    try:
        source_hash = digest(dataset)
        rows = read_rows(dataset)
        before = inventory(rows)
        if before["rows"] != 400 or before["episodes"] != 40 or before["splits"] != {"train": 200, "calibration": 200}:
            raise ValueError(f"Unexpected preserved dataset; review rather than silently refit: {before}")
        campaigns = [(root / p).resolve() for p in args.campaign] if args.campaign else [root / "results" / p for p in CAMPAIGNS]
        print("Auditing raw action/baseline pairs for all 400 rows; no GPU workload.", flush=True)
        converted, provenance = rebuild(rows, campaigns, max_gap_s=args.max_gap_s)
        if inventory(converted) != before or digest(dataset) != source_hash:
            raise ValueError("Source changed or row/split inventory differs")
        save("PAIRING_PROVENANCE.json", provenance)
        csv_path = output / "gpu_paired_dataset.csv"
        with csv_path.open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(converted[0]))
            writer.writeheader()
            writer.writerows(converted)
        audit = dict(status="HISTORICAL_GPU_PAIRING_COMPLETE", **before,
                     source_dataset=str(dataset), source_sha256=source_hash,
                     dataset_sha256=digest(csv_path), power_boundary="gpu_nvml",
                     max_allowed_telemetry_gap_s=args.max_gap_s,
                     provenance_sha256=digest(output / "PAIRING_PROVENANCE.json"),
                     raw_files_verified=True, row_local_baselines_verified=True,
                     pairing_counts=dict(Counter(r["pairing_kind"] for r in converted)),
                     cross_campaign_drift_ruled_out=False,
                     target_environment_validated=False, deployment_authorized=False)
        save("DATASET_AUDIT.json", audit)
        print(json.dumps(audit, indent=2), flush=True)
        print("Refitting historical candidate on CPU; calibration alpha is unchanged (0.05).", flush=True)
        train = [r for r in converted if r["data_split"] == "train"]
        calibration = [r for r in converted if r["data_split"] == "calibration"]
        # Restored server support masks may read this field as a bool. A CSV
        # string "False" must never become truthy in that code.
        for row in train + calibration:
            value = str(row["slo_safe"]).strip().lower()
            if value not in {"true", "false", "1", "0"}:
                raise ValueError("Invalid stored SLO boolean")
            row["slo_safe"] = value in {"true", "1"}
        model = HistoricalGpuPairedSurrogate(alpha=.05).fit(train, calibration)
        if not isinstance(model, HistoricalGpuPairedSurrogate):
            raise TypeError("Installed fit implementation replaced the candidate class")
        path = output / "historical_gpu_surrogate.joblib"
        model.save(path)
        loaded = HybridSurrogate.load(path)
        for row in converted:
            if loaded.predict(row) != model.predict(row):
                raise ValueError("Serialization changed predictions")
        import sklearn
        import joblib
        import numpy
        report = loaded.report(train, calibration)
        report.update(status="HISTORICAL_GPU_CANDIDATE_READY_NOT_DEPLOYED", model=str(path),
                      model_sha256=digest(path), dataset_sha256=digest(csv_path),
                      python=sys.version, sklearn=sklearn.__version__, joblib=joblib.__version__,
                      numpy=numpy.__version__, gpu_workload_started=False,
                      active_config_changed=False, deployment_authorized=False,
                      modeling_code_sha256=digest(Path(inspect.getfile(HybridSurrogate))),
                      rebuild_code_sha256=digest(Path(inspect.getfile(HistoricalGpuPairedSurrogate))))
        report["supported_source_actions"] = getattr(loaded, "supported_source_actions", None)
        save("MODEL_REPORT.json", report)
        print(json.dumps(strict_json(report), indent=2), flush=True)
        print("GPU_CANDIDATE_READY; no active configuration/model replaced; no target-host validation.", flush=True)
    except BaseException as exc:
        save("REBUILD_FAILED.json", dict(status="BLOCKED_NO_DEPLOYMENT", error=str(exc),
                                        error_type=type(exc).__name__, original_data_unchanged=True))
        raise


if __name__ == "__main__":
    # Limit CPU parallelism; this is not a GPU collection process.
    os.environ.setdefault("OMP_NUM_THREADS", "2")
    os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
    main()
