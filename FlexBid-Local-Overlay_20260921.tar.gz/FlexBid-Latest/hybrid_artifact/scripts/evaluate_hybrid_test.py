#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

from flexbid_hybrid.modeling import HybridSurrogate, build_dataset, read_csv
from flexbid_hybrid.policy import (
    BASELINE_ACTION,
    HybridBid,
    actual_oracle,
    risk_calibrated_bid,
    static_conservative_policy,
    summarize_method,
)


def write_csv(path: Path, rows: list[dict]) -> None:
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def fixed_bid(action: str, bid_w: float, reason: str) -> HybridBid:
    return HybridBid(
        action, bid_w, bid_w, bid_w > 0, reason, "fixed",
        0.0, 0.0, 0.0, 0.0,
    )


def conservative_fixed_bid(calibration: list[dict], action: str) -> float:
    episodes: dict[str, dict[str, dict]] = defaultdict(dict)
    for row in calibration:
        episodes[str(row["episode_id"])][str(row["name"])] = row
    reductions = []
    for values in episodes.values():
        baseline = values.get(BASELINE_ACTION)
        controlled = values.get(action)
        if baseline is None or controlled is None or not bool(controlled["slo_safe"]):
            return 0.0
        reductions.append(
            float(baseline["power_mean_w"]) - float(controlled["power_mean_w"])
        )
    return max(0.0, min(reductions, default=0.0))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-results", type=Path, required=True)
    parser.add_argument("--test-config", type=Path, required=True)
    parser.add_argument("--fit-root", type=Path, required=True)
    parser.add_argument("--catchup-report", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--delivery-tolerance-w", type=float, default=50.0)
    parser.add_argument("--carbon-intensity-g-per-kwh", type=float, default=400.0)
    args = parser.parse_args()

    args.output_root.mkdir(parents=True, exist_ok=True)
    test_dataset = args.output_root / "hybrid_test_dataset.csv"
    test = build_dataset([args.test_results.resolve()], test_dataset, expected_actions=8)
    test = read_csv(test_dataset)
    episode_count = len({row["episode_id"] for row in test})
    if episode_count < 1 or len(test) != 8 * episode_count:
        raise RuntimeError(
            f"expected 8 actions for every test episode, found "
            f"{len(test)} rows across {episode_count} episodes"
        )
    training = read_csv(args.fit_root / "hybrid_surrogate_dataset.csv")
    calibration = [row for row in training if row["data_split"] == "calibration"]
    cross_layer = HybridSurrogate.load(args.fit_root / "cross_layer_surrogate.joblib")
    workload_only = HybridSurrogate.load(args.fit_root / "workload_only_surrogate.joblib")
    catchup = json.loads(args.catchup_report.read_text(encoding="utf-8"))
    if catchup.get("status") != "PASS_CATCHUP_DEADLINE":
        raise RuntimeError("batch catch-up deadline proof did not pass")
    catchup_by_source = {str(row["source"]): bool(row["deadline_safe"])
                         for row in catchup["sources"]}

    static_action, static_bid = static_conservative_policy(calibration)
    fixed_actions = {
        "no_dr": BASELINE_ACTION,
        "static_conservative": static_action,
        "power_cap_only": "hybrid_full_cap300",
        "batch_throttle_only": "hybrid_half_batch",
        "workload_only_control": "pause_r2_cap400",
        "pals_reactive_proxy": "pause_batch_r4",
    }
    fixed_bids = {
        method: (0.0 if method == "no_dr" else (
            static_bid if method == "static_conservative"
            else conservative_fixed_bid(calibration, action)
        ))
        for method, action in fixed_actions.items()
    }

    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in test:
        grouped[str(row["episode_id"])].append(row)
    episode_rows: list[dict] = []
    coverage = {mode: {"rows": 0, "covered_rows": 0, "episodes": 0,
                       "covered_episodes": 0} for mode in ("row", "episode")}
    for episode_id, rows in sorted(grouped.items()):
        by_name = {str(row["name"]): row for row in rows}
        baseline = by_name[BASELINE_ACTION]
        decisions: dict[str, HybridBid] = {
            method: fixed_bid(action, fixed_bids[method], method)
            for method, action in fixed_actions.items()
        }
        decisions.update({
            "workload_only_surrogate": risk_calibrated_bid(
                rows, workload_only, "episode"
            ),
            "flexbid_no_cp": risk_calibrated_bid(rows, cross_layer, "none"),
            "flexbid_row_cp": risk_calibrated_bid(rows, cross_layer, "row"),
            "flexbid_episode_cp": risk_calibrated_bid(rows, cross_layer, "episode"),
            "clairvoyant_oracle": actual_oracle(rows),
        })
        for mode in ("row", "episode"):
            episode_covered = True
            for row in rows:
                bounds = cross_layer.bounds(row, mode)
                covered = (
                    bounds.power_lower_w <= float(row["power_mean_w"]) <= bounds.power_upper_w
                    and float(row["ttft_p95_ms"]) <= bounds.ttft_upper_ms
                    and float(row["tpot_p99_ms"]) <= bounds.tpot_upper_ms
                    and float(row["batch_tokens_per_s"]) >= bounds.batch_tokens_per_s_lower
                )
                coverage[mode]["rows"] += 1
                coverage[mode]["covered_rows"] += int(covered)
                episode_covered = episode_covered and covered
            coverage[mode]["episodes"] += 1
            coverage[mode]["covered_episodes"] += int(episode_covered)

        for method, decision in decisions.items():
            actual = by_name[decision.action_name]
            baseline_power = float(baseline["power_mean_w"])
            power = float(actual["power_mean_w"])
            achieved = baseline_power - power
            energy_kwh = float(actual["energy_j"]) / 3_600_000
            online_failure = int(not bool(actual["slo_safe"]))
            deadline_failure = int(
                decision.action_name != BASELINE_ACTION
                and not catchup_by_source.get(str(actual["source"]), False)
            )
            episode_rows.append({
                "episode_id": episode_id,
                "source": actual["source"],
                "method": method,
                "action": decision.action_name,
                "bid_w": decision.committed_reduction_w,
                "achieved_reduction_w": achieved,
                "achieved_reduction_pct": 100 * achieved / baseline_power,
                "delivery_failure": int(
                    achieved + args.delivery_tolerance_w
                    < decision.committed_reduction_w
                ),
                "online_slo_failure": online_failure,
                "batch_deadline_failure": deadline_failure,
                "power_mean_w": power,
                "energy_kwh": energy_kwh,
                "operational_carbon_g": energy_kwh * args.carbon_intensity_g_per_kwh,
                "ttft_p95_ms": actual["ttft_p95_ms"],
                "tpot_p99_ms": actual["tpot_p99_ms"],
                "batch_tokens_per_s": actual["batch_tokens_per_s"],
                "decision_feasible": decision.feasible,
                "decision_reason": decision.reason,
            })

    write_csv(args.output_root / "hybrid_method_episode_results.csv", episode_rows)
    by_method: dict[str, list[dict]] = defaultdict(list)
    for row in episode_rows:
        by_method[str(row["method"])].append(row)
    method_rows = [
        {"method": method, **summarize_method(rows)}
        for method, rows in sorted(by_method.items())
    ]
    write_csv(args.output_root / "hybrid_method_summary.csv", method_rows)
    for values in coverage.values():
        values["row_coverage"] = values["covered_rows"] / values["rows"]
        values["episode_coverage"] = values["covered_episodes"] / values["episodes"]
    audit = {
        "status": "HYBRID_OFFLINE_EVALUATION_COMPLETE",
        "test_rows": len(test),
        "test_episodes": len(grouped),
        "methods": sorted(by_method),
        "conformal_test_coverage": coverage,
        "catchup_status": catchup["status"],
        "carbon_boundary": (
            "operational component-boundary projection using configured grid intensity; "
            "facility overhead and embodied carbon excluded"
        ),
        "reactive_caveat": (
            "pals_reactive_proxy is an offline fixed-action proxy; a final real replay "
            "is required for a controller claim"
        ),
    }
    (args.output_root / "HYBRID_OFFLINE_EVALUATION_COMPLETE.json").write_text(
        json.dumps(audit, indent=2), encoding="utf-8"
    )
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
