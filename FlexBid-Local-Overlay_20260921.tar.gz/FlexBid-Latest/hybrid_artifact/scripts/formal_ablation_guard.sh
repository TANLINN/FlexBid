#!/usr/bin/env bash
set -u

ROOT=/root/workspace/FlexBid-LLM/hybrid_artifact
CONFIG="$ROOT/configs/a800_8gpu_qwen35_27b_formal_ablation.yaml"
R="$ROOT/results/hybrid_formal_ablation_a800_qwen35_27b_20260822"
EVENTS="$R/logs/formal_guard.events.log"
WORKERS="$R/formal_guard.worker.pids"

cd "$ROOT"
mkdir -p "$R/logs"

stamp() {
  date '+%F %T %Z'
}

progress() {
  find "$R/cells" -type f -name CELL_COMPLETE.json 2>/dev/null |
    wc -l
}

restore_caps() {
  for gpu in 0 1 2 3 4 5 6 7
  do
    default=$(nvidia-smi -i "$gpu" \
      --query-gpu=power.default_limit \
      --format=csv,noheader,nounits 2>/dev/null |
      head -n 1 |
      xargs)

    if [ -n "$default" ]; then
      nvidia-smi -i "$gpu" -pl "$default" >/dev/null 2>&1 || true
    fi
  done
}

cleanup_services() {
  pkill -TERM -f '[r]un_physical_pilot.py' 2>/dev/null || true
  pkill -TERM -f '[r]eplay_online.py' 2>/dev/null || true
  pkill -TERM -f '[r]un_batch.py' 2>/dev/null || true
  pkill -TERM -f '[f]lexbid_hybrid.telemetry' 2>/dev/null || true
  pkill -TERM -f '[v]llm serve /root/FlexBid-LLM/models/Qwen3.5-27B' 2>/dev/null || true
  pkill -TERM -f '[f]lexbid_hybrid.gateway:app' 2>/dev/null || true
}

stop_workers() {
  trap - INT TERM EXIT

  if [ -f "$WORKERS" ]; then
    while read -r pid
    do
      kill -TERM "$pid" 2>/dev/null || true
    done < "$WORKERS"
  fi

  wait 2>/dev/null || true
  rm -f "$WORKERS"
  echo "$(stamp) guard stopped; workers cleaned" >> "$EVENTS"
}

trap 'stop_workers; exit 0' INT TERM
trap stop_workers EXIT

echo "$(stamp) formal ablation guard started" >> "$EVENTS"

attempt=0
stagnant=0
before=$(progress)

while [ "$attempt" -lt 4 ]
do
  attempt=$((attempt + 1))
  echo "$(stamp) attempt=$attempt progress_before=$before" >> "$EVENTS"

  PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" \
    python -u scripts/run_physical_pilot.py \
    --config "$CONFIG" \
    --resume \
    >> "$R/logs/collector_guarded.log" 2>&1

  rc=$?
  after=$(progress)

  restore_caps

  echo "$(stamp) attempt=$attempt rc=$rc progress_after=$after" \
    >> "$EVENTS"

  if [ "$after" -ge 80 ]; then
    echo "$(stamp) collection complete: $after/80" >> "$EVENTS"
    break
  fi

  if [ "$after" -gt "$before" ]; then
    stagnant=0
  else
    stagnant=$((stagnant + 1))
  fi

  if [ "$stagnant" -ge 3 ]; then
    echo "$(stamp) stopped after three stagnant attempts" >> "$EVENTS"
    break
  fi

  cleanup_services
  sleep 15
  before=$after
done

cleanup_services
restore_caps
sleep 10

echo "$(stamp) activating tracked GPU retention" >> "$EVENTS"
: > "$WORKERS"

for gpu in 0 1 2 3 4 5 6 7
do
  CUDA_VISIBLE_DEVICES="$gpu" \
    python -u scripts/hybrid_retention_worker.py \
    >> "$R/logs/formal_retention_gpu_${gpu}.log" 2>&1 &

  echo "$!" >> "$WORKERS"
done

wait
