#!/usr/bin/env python3
"""Short, read-only GPU-meter/real-runtime clock experiment, never a DR trial.

No vLLM, matrix workload, model loading, GPU cap writes, or process cleanup.
The optimizer and gateway are fixtures; the GPU meter and clock are real unless
--synthetic is explicitly requested. Existing retained GPU work is not stopped.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from flexbid_hybrid.contracts import FlexibilityContract
from flexbid_hybrid.runtime_controller import DynamicControlLoop, read_component_power_w
from flexbid_hybrid.types import HybridAction
from flexbid_hybrid.io import atomic_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--synthetic', action='store_true')
    args = parser.parse_args()
    output = args.output_root.resolve()
    output.mkdir(parents=True, exist_ok=False)  # no accidental resume/overwrite
    if args.synthetic:
        gpus, reader = [], lambda *_: 1000.0
        event, deadline, lead, warmup, period, interval, sample = 1.1, 1.5, .2, .1, .4, .3, .02
        compute = 'synthetic fixture, no NVML'
    else:
        import pynvml
        pynvml.nvmlInit()
        try:
            gpus = list(range(pynvml.nvmlDeviceGetCount()))
            identities = [str(pynvml.nvmlDeviceGetUUID(pynvml.nvmlDeviceGetHandleByIndex(i))) for i in gpus]
        finally:
            pynvml.nvmlShutdown()
        if not gpus or read_component_power_w(gpus) is None:
            raise RuntimeError('GPU power unreadable; no experiment or cap change made')
        reader = read_component_power_w
        # Non-dividing control/meter periods and a short final window exercise
        # boundary splitting: 95 s = 3*30 s + 5 s, recovery observation 15 s.
        event, deadline, lead, warmup, period, interval, sample = 95., 110., 5., 5., 7., 30., .2
        compute = subprocess.run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,used_memory',
                                  '--format=csv'], capture_output=True, text=True).stdout
        atomic_json(output / 'gpu_identity.json', {'uuids': identities, 'compute_snapshot': compute})
    action = HybridAction('hybrid_full', 4, 4, 400.0)
    def forbidden_solve(_):
        raise AssertionError('forced meter-only fixture must not call MPC')
    optimizer = SimpleNamespace(baseline_action='hybrid_full',
        model=SimpleNamespace(paired_effects=True), solve=forbidden_solve,
        parameters=SimpleNamespace(control_period_s=period, replica_min_dwell_s=0))
    sequence = [0]
    def gateway(_):
        import time
        sequence[0] += 1
        return {'completed_batch': 0, 'completed_online': 0, 'recent_online_metrics': [
            dict(sequence=sequence[0], completed_wall_time_ns=time.time_ns(),
                 ttft_ms=1., mean_gap_ms=1.)]}
    loop = DynamicControlLoop(optimizer=optimizer, actions=[action], source='CLOCK_FIXTURE',
        gateway_url='http://not-used', control_file=output / 'unused_control.json',
        gpu_indices=gpus, replica_count=4, online_concurrency=1,
        event_s=event, deadline_s=deadline, baseline_batch_tps=1., batch_output_tokens=1,
        ttft_slo_ms=100., tpot_slo_ms=100., log_path=output / 'controller.jsonl',
        state_path=output / 'latest.json', warmup_s=warmup, offer_lead_s=lead,
        contract=FlexibilityContract(event, deadline, interval), initial_cohort_tokens=0,
        force_baseline=True, dry_run=True, state_reader=gateway,
        meter_sample_s=sample, meter_max_gap_s=max(1., sample * 5))
    print('START: meter-only; NO LLM, NO bid, NO GPU load/cap changes', flush=True)
    print('planned seconds =', warmup + lead + deadline, flush=True)
    with patch('flexbid_hybrid.runtime_controller.read_component_power_w', reader):
        loop.run()
    reports = list(output.glob('event_protocol_*.json'))
    report = json.loads(reports[0].read_text())
    contract = report['contract']
    rows = [json.loads(line) for line in (output / 'controller.jsonl').read_text().splitlines()]
    passed = (len(reports) == 1 and len(report['windows']) == report['expected_windows']
              and all(r['coverage_complete'] for r in report['windows'])
              and report['windows'][-1]['end_s'] == event and not report['meter_error']
              and contract['offer_finished_wall_ns'] < contract['activation_wall_ns']
              and contract['committed_bid_w'] == 0 and not contract['accepted']
              and contract['first_actuation_elapsed_s'] is not None
              and contract['first_actuation_elapsed_s'] >= 0
              and all(r['committed_bid_w'] == 0 and r['actuation']['dry_run'] for r in rows))
    result = dict(status='PASS_CLOCK_AND_METER_ONLY' if passed else 'FAIL_CLOCK_OR_METER',
                  synthetic=args.synthetic, expected_windows=report['expected_windows'],
                  observed_windows=len(report['windows']),
                  final_window_s=report['windows'][-1]['end_s'] - report['windows'][-1]['start_s'],
                  controller_records=len(rows), first_actuation_elapsed_s=contract['first_actuation_elapsed_s'],
                  dr_delivery_verified=False, slo_verified=False, mpc_performance_verified=False,
                  no_gpu_workload_or_cap_changes=True, event_report=reports[0].name)
    atomic_json(output / 'SMOKE_REPORT.json', result)
    print(json.dumps(result, indent=2), flush=True)
    if not passed:
        raise SystemExit(2)


if __name__ == '__main__':
    main()
