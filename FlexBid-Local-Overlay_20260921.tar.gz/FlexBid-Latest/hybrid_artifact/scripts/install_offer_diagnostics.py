"""Transactional diagnostics-only patch; no collector, model, or optimizer replacement."""
from datetime import datetime
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import uuid

FILES = {'flexbid_hybrid/offer_diagnostics.py', 'scripts/diagnose_development_offer.py',
         'scripts/install_offer_diagnostics.py', 'tests/test_offer_diagnostics.py'}
EDITS = (
    ('    from .runtime_controller import read_component_power_w\n',
     '    from .runtime_controller import read_component_power_w\n'
     '    from .offer_diagnostics import solve_offer_recorded, flush_offer_diagnostics\n'),
    ('        plan = loop.optimizer.solve(state)\n',
     "        plan = solve_offer_recorded(loop, state, session, 'initial_offer')\n"),
    ('                plan = loop.optimizer.solve(replace(state, committed_bid_w=bid))\n',
     '                plan = solve_offer_recorded(loop, replace(state, committed_bid_w=bid),\n'
     "                                            session, 'quantized_offer_validation')\n"),
    ('    session.freeze_offer(bid, bid > 0, reason)\n',
     '    session.freeze_offer(bid, bid > 0, reason)\n'
     '    flush_offer_diagnostics(session)\n'),
)


def patch_event(source):
    for before, after in EDITS:
        if source.count(after) == 1:
            continue
        if source.count(before) != 1:
            raise ValueError('Unknown event-protocol anchor; no changes')
        source = source.replace(before, after, 1)
    compile(source, 'event_protocol.py', 'exec')
    return source


def install(bundle, root):
    root = Path(root).resolve()
    if root.name != 'hybrid_artifact' or set(bundle) != FILES:
        raise ValueError('Unexpected project/payload')
    spec = importlib.util.spec_from_file_location('prior_safety', root/'scripts/install_runtime_safety.py')
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)
    if prior.active_collectors(root):
        raise RuntimeError('Active collector; diagnostics patch not installed')
    prepared = dict(bundle)
    prepared['flexbid_hybrid/event_protocol.py'] = patch_event((root/'flexbid_hybrid/event_protocol.py').read_text(encoding='utf-8'))
    original = {}
    for name, source in prepared.items():
        path = root/name
        if path.is_symlink() or root not in path.resolve().parents:
            raise ValueError('Unsafe target: '+name)
        original[name] = path.read_bytes() if path.exists() else None
        if name in FILES and original[name] is not None:
            if original[name].decode().replace('\r\n', '\n') != source:
                raise ValueError('Existing diagnostic file differs; refusing overwrite: '+name)
        compile(source, name, 'exec')
    backup = root/'results/patch_backups'/('offer_diagnostics_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    for name, data in original.items():
        if data is not None:
            target = backup/name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    changed = []
    try:
        for name, source in prepared.items():
            path = root/name
            if (path.read_bytes() if path.exists() else None) != original[name]:
                raise RuntimeError('Concurrent file edit')
            if original[name] != source.encode():
                changed.append(name)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(source, encoding='utf-8', newline='\n')
        subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-q'],
            cwd=root, env={**os.environ, 'PYTHONPATH':str(root), 'PYTHONDONTWRITEBYTECODE':'1'}, check=True)
    except BaseException:
        for name in reversed(changed):
            path = root/name
            if original[name] is None:
                path.unlink()
            else:
                path.write_bytes(original[name])
        print('INSTALL_ROLLED_BACK: original code restored; no workload started', flush=True)
        raise
    print('OFFER_DIAGNOSTICS_READY; BACKUP='+str(backup), flush=True)
    print('Only development-offer logging added. MPC core/runtime_controller/collector/config/model unchanged.', flush=True)


if __name__ == '__main__':
    install(BUNDLE, Path.cwd())
