#!/usr/bin/env bash
set -u

ROOT=/root/workspace/FlexBid-LLM/hybrid_artifact
R=results/hybrid_physical_gate_a800_qwen35_27b
ACTIVE_PID=439566

cd "$ROOT" || exit 2
mkdir -p "$R/logs"

echo "$(date) monitoring existing pilot PID=$ACTIVE_PID" \
  >> "$R/logs/handoff.log"

while true; do
  CMD="$(tr '\0' ' ' < "/proc/$ACTIVE_PID/cmdline" 2>/dev/null || true)"
  case "$CMD" in
    *run_physical_pilot.py*) sleep 20 ;;
    *) break ;;
  esac
done

echo "$(date) existing pilot stopped; starting resilient supervisor" \
  >> "$R/logs/handoff.log"

exec env PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" \
  python -u scripts/hybrid_overnight.py
