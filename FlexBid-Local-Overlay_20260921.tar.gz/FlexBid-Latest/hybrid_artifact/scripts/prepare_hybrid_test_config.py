#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import yaml

from flexbid_hybrid.config import load_config


def manifest(path: Path) -> dict:
    return json.loads((path / "campaign_manifest.json").read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile-results", type=Path, required=True)
    parser.add_argument("--ablation-results", type=Path, required=True)
    parser.add_argument("--output-config", type=Path, required=True)
    parser.add_argument("--test-results", required=True)
    parser.add_argument("--test-episodes-per-source", type=int, default=5)
    args = parser.parse_args()

    profile_manifest = manifest(args.profile_results.resolve())
    ablation_manifest = manifest(args.ablation_results.resolve())
    config = copy.deepcopy(load_config(Path(profile_manifest["config"])))
    action_by_name = {}
    for value in [*profile_manifest["actions"], *ablation_manifest["actions"]]:
        action_by_name[str(value["name"])] = value
    if len(action_by_name) != 8:
        raise RuntimeError(f"expected 8 unique actions, found {sorted(action_by_name)}")
    ordered_names = ["hybrid_full"] + sorted(
        name for name in action_by_name if name != "hybrid_full"
    )
    sources = sorted({str(item["source"]) for item in profile_manifest["episodes"]})
    config["experiment_name"] = Path(args.test_results).name
    config["seed"] = int(config["seed"]) + 1000
    config["actions"] = [action_by_name[name] for name in ordered_names]
    config["workloads"]["sources"] = sources
    config["workloads"]["episode_selections"] = [
        {
            "source": source,
            "split": "test",
            "count": args.test_episodes_per_source,
            "offset": 0,
        }
        for source in sources
    ]
    config["paths"]["results_root"] = args.test_results
    args.output_config.parent.mkdir(parents=True, exist_ok=True)
    args.output_config.write_text(
        yaml.safe_dump(config, sort_keys=False), encoding="utf-8"
    )
    report = {
        "status": "TEST_CONFIG_READY",
        "config": str(args.output_config.resolve()),
        "sources": sources,
        "episodes": len(sources) * args.test_episodes_per_source,
        "actions": ordered_names,
        "expected_cells": len(sources) * args.test_episodes_per_source * len(ordered_names),
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
