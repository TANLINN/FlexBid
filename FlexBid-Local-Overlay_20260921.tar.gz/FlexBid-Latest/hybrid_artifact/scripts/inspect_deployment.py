#!/usr/bin/env python3
"""Read-only environment observation. Does NOT issue deployment approval."""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from flexbid_hybrid.config import load_config
from flexbid_hybrid.deployment import observe_environment


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps({
        "status": "OBSERVATION_ONLY_NOT_VALIDATED",
        "environment": observe_environment(load_config(args.config), ROOT),
        "requires": ["same-boundary fitted model", "target calibration", "target validation"],
    }, indent=2))


if __name__ == "__main__":
    main()
