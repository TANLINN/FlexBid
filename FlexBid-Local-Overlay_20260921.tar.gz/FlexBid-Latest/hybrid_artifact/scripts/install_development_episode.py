"""Narrow transactional hooks; preserve server-only cold-start/lifecycle fixes."""
import ast
import hashlib
from datetime import datetime
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import uuid

FILES = {'flexbid_hybrid/development_episode.py', 'scripts/run_development_episode.py',
         'scripts/install_development_episode.py', 'tests/test_development_episode.py',
         'flexbid_hybrid/development_trace.py', 'tests/test_development_trace.py',
         'flexbid_hybrid/development_environment.py', 'tests/test_development_environment.py'}
# Exact installed V2 content may be upgraded. Unknown user edits still block.
PREVIOUS_V2 = {
    'flexbid_hybrid/development_episode.py': '6682e8fbce1b799bd2887106415684bd6ee178b23ea38b47458c01807ae3474b',
    'scripts/install_development_episode.py': '896a7da8382a790ede52ce8aaeede9414d4cd04e24c6e60d26d6204c15abec80',
    'scripts/run_development_episode.py': 'db37c2dcc20d3d645f6ae502d3cd1afc2f57a167d9ca700b6c44379627774193',
    'tests/test_development_episode.py': '36918b6bbcb5e1ea821aaf8f174655ecf4ceda986c09a8c915e30390ff01a877',
}
PREVIOUS_V3 = {
    'flexbid_hybrid/development_episode.py': '6682e8fbce1b799bd2887106415684bd6ee178b23ea38b47458c01807ae3474b',
    'flexbid_hybrid/development_trace.py': '673b0cd4c3e063b0dd671f159fbe6f6ef3ee03e8aadebe7ff7efd6f3b694bac0',
    'scripts/install_development_episode.py': '38d1bd3f85cf9529d152e285e5065865c8a538da15677666a553fe5495e92923',
    'scripts/run_development_episode.py': '74ccfb1af884ae7e8884359aa1770af289203d799e6f40700ed03833a485d00a',
    'tests/test_development_episode.py': 'a32c6c1f8cc7b1e2ed1ce8369354235ff9f149843ed051b94f58d81103412f45',
    'tests/test_development_trace.py': 'e954db2a81663622b605513563b072e76990fdb36a4de4aa9b07f380d70f7f7a',
}
DEPLOYMENT_EDITS = (
    ('def observe_environment(config, root):',
     'def observe_environment(config, root, *, diagnostic_topology=False):'),
    ('    topology = subprocess.run(\n'
     '        ["nvidia-smi", "topo", "-m"], capture_output=True, text=True, timeout=15,\n'
     '        check=True,\n'
     '    ).stdout.strip()\n',
     '    from .development_environment import read_topology\n'
     '    topology, topology_audit = read_topology(config, diagnostic_topology=diagnostic_topology)\n'),
    ('        "model_metadata_hashes": files, "local_topology": topology,\n',
     '        "model_metadata_hashes": files, "local_topology": topology,\n'
     '        **({"topology_observation": topology_audit} if diagnostic_topology else {}),\n'),
)


def patch_deployment(source):
    for before, after in DEPLOYMENT_EDITS:
        if source.count(after) == 1:
            continue
        if source.count(before) != 1:
            raise ValueError('Unknown environment observation interface; no changes')
        source = source.replace(before, after, 1)
    compile(source, 'deployment.py', 'exec')
    return source
RUNTIME_ANCHOR = '            from .zero_bid_reference import freeze_zero_bid_reference\n'
RUNTIME_CALL = ('            from .development_episode import freeze_development_reference\n'
                '            freeze_development_reference(self, baseline_power_w, baseline_power_samples)\n')
RUNNER_ANCHOR = '    loop.run()\n'
RUNNER_CALL = ('    from flexbid_hybrid.development_episode import configure_development_episode\n'
               '    configure_development_episode(loop, config)\n')


def insert(source, anchor, addition, name):
    if source.count(anchor) != 1:
        raise ValueError('Unknown server interface: '+name)
    if addition not in source:
        if 'development_episode import' in source:
            raise ValueError('Partial or differing development hook: '+name)
        source = source.replace(anchor, addition+anchor, 1)
    if source.count(addition+anchor) != 1:
        raise ValueError('Unexpected hook placement: '+name)
    compile(source, name, 'exec')
    return source


def patch_runtime(source):
    required = ('baseline_power_samples', 'freeze_zero_bid_reference(self, baseline_power_w)',
                'protocol = prepare_event(self, initial, baseline_power_w,')
    if not all(s in source for s in required):
        raise ValueError('Install fixed-event-clock and zero-bid reference first')
    return insert(source, RUNTIME_ANCHOR, RUNTIME_CALL, 'runtime_controller.py')


def patch_runner(source):
    # Server hotfixes legitimately wrap keyword arguments across lines. Check
    # syntax, not spelling/quotes/whitespace; comments cannot satisfy a guard.
    tree = ast.parse(source)
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main']
    if len(functions) != 1:
        raise ValueError('RUNNER_MAIN_AMBIGUOUS: expected one main function')
    body = functions[0].body
    def assigned_call(statement, target, function):
        return (isinstance(statement, ast.Assign) and len(statement.targets) == 1
            and isinstance(statement.targets[0], ast.Name) and statement.targets[0].id == target
            and isinstance(statement.value, ast.Call) and isinstance(statement.value.func, ast.Name)
            and statement.value.func.id == function)
    loops = [n for n in body if assigned_call(n, 'loop', 'DynamicControlLoop')]
    if len(loops) != 1:
        raise ValueError('LOOP_CONSTRUCTION_AMBIGUOUS: expected one direct loop assignment')
    kwargs = [k for k in loops[0].value.keywords if k.arg == 'force_baseline']
    expected = ast.parse('bool(dynamic.get("force_baseline", False))', mode='eval').body
    if len(kwargs) != 1 or ast.dump(kwargs[0].value) != ast.dump(expected):
        raise ValueError('FORCE_BASELINE_FORWARDING_MISSING: expected bool(dynamic.get("force_baseline", False))')
    bindings = [n for n in body if assigned_call(n, 'model', 'bind_live_model')]
    optimizers = [n for n in body if assigned_call(n, 'optimizer', 'GuardedViabilityMPC')]
    imports = [n for n in tree.body + body if isinstance(n, ast.ImportFrom)
        and n.module == 'flexbid_hybrid.deployment'
        and any(a.name == 'bind_live_model' and a.asname in (None, 'bind_live_model') for a in n.names)]
    if len(bindings) != 1 or len(optimizers) != 1 or not imports:
        raise ValueError('DEPLOYMENT_BINDING_MISSING: require imported bind_live_model and guarded optimizer; nothing modified')
    binding, optimizer, loop = bindings[0], optimizers[0], loops[0]
    expected_binding = ast.parse('bind_live_model(model, frozen_model, config, root, args.source, offline=args.dry_run)', mode='eval').body
    if (ast.dump(binding.value) != ast.dump(expected_binding)
            or not any(n.lineno < binding.lineno for n in imports)
            or not binding.lineno < optimizer.lineno < loop.lineno
            or not optimizer.value.args or ast.dump(optimizer.value.args[0]) != ast.dump(ast.Name(id='model', ctx=ast.Load()))
            or not any(k.arg == 'optimizer' and isinstance(k.value, ast.Name) and k.value.id == 'optimizer' for k in loop.value.keywords)):
        raise ValueError('DEPLOYMENT_BINDING_UNRECOGNIZED: guarded model must feed optimizer before loop construction')
    # Refuse a discarded gate result rather than accepting a token in a comment.
    for n in body:
        if binding.lineno < n.lineno < optimizer.lineno:
            if any(isinstance(v, ast.Name) and isinstance(v.ctx, ast.Store) and v.id == 'model' for v in ast.walk(n)):
                raise ValueError('DEPLOYMENT_BINDING_OVERWRITTEN: model replaced after guard')
    return insert(source, RUNNER_ANCHOR, RUNNER_CALL, 'run_dynamic_controller.py')


def install(bundle, root):
    root = Path(root).resolve()
    if root.name != 'hybrid_artifact' or set(bundle) != FILES:
        raise ValueError('Unexpected project or payload')
    spec = importlib.util.spec_from_file_location('prior_safety', root / 'scripts/install_runtime_safety.py')
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)
    if prior.active_collectors(root):
        raise RuntimeError('Active collection; no files modified')
    prepared = dict(bundle)
    for name, function in [('flexbid_hybrid/runtime_controller.py', patch_runtime),
                           ('scripts/run_dynamic_controller.py', patch_runner),
                           ('flexbid_hybrid/deployment.py', patch_deployment)]:
        prepared[name] = function((root / name).read_text(encoding='utf-8'))
    original, changed = {}, []
    for name, source in prepared.items():
        path = root / name
        if path.is_symlink() or root not in path.resolve().parents:
            raise ValueError('Unsafe target')
        original[name] = path.read_bytes() if path.exists() else None
        if name in FILES and original[name] is not None:
            normalized=original[name].decode().replace('\r\n','\n')
            if normalized != source and hashlib.sha256(normalized.encode()).hexdigest() not in {
                    PREVIOUS_V2.get(name), PREVIOUS_V3.get(name)}:
                raise ValueError('Existing diagnostic module differs from exact V2/V3/current content: '+name)
        compile(source, name, 'exec')
    backup = root / 'results/patch_backups' / ('development_episode_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8])
    for name, data in original.items():
        if data is not None:
            target = backup / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    try:
        for name, source in prepared.items():
            path = root / name
            if (path.read_bytes() if path.exists() else None) != original[name]:
                raise RuntimeError('Concurrent file change')
            if original[name] != source.encode():
                changed.append(name)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(source, encoding='utf-8', newline='\n')
        subprocess.run([sys.executable,'-B','-m','unittest','discover','-s','tests','-q'], cwd=root,
            env={**os.environ, 'PYTHONPATH':str(root), 'PYTHONDONTWRITEBYTECODE':'1'}, check=True)
    except BaseException:
        for name in reversed(changed):
            path = root / name
            if original[name] is None:
                path.unlink()
            else:
                path.write_bytes(original[name])
        raise
    print('DEVELOPMENT_DIAGNOSTIC_READY; BACKUP='+str(backup))
    print('Production/zero-bid guards unchanged; no fixed bid and no external commitment')


if __name__ == '__main__':
    install(BUNDLE, Path.cwd())
