#!/usr/bin/env python3
import argparse
import time

import torch


parser = argparse.ArgumentParser()
parser.add_argument("--busy-s", type=float, default=1.0)
parser.add_argument("--idle-s", type=float, default=1.0)
args = parser.parse_args()

torch.set_grad_enabled(False)

left = torch.randn(
    (4096, 4096), device="cuda", dtype=torch.float16
)
right = torch.randn_like(left)
output = torch.empty_like(left)

while True:
    deadline = time.monotonic() + args.busy_s

    while time.monotonic() < deadline:
        torch.mm(left, right, out=output)
        torch.cuda.synchronize()
        left, output = output, left

    time.sleep(args.idle_s)
