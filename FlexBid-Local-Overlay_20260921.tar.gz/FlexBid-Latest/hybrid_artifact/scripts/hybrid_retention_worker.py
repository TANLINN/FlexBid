#!/usr/bin/env python3
from __future__ import annotations

import time

import torch


left = torch.randn((4096, 4096), device="cuda", dtype=torch.float16)
right = torch.randn_like(left)
output = torch.empty_like(left)

while True:
    deadline = time.monotonic() + 1.0
    while time.monotonic() < deadline:
        torch.mm(left, right, out=output)
        torch.cuda.synchronize()
        left, output = output, left
    time.sleep(2.0)
