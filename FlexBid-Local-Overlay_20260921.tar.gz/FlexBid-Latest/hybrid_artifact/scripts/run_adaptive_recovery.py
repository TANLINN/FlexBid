#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

from flexbid_hybrid.adaptive_recovery import run_adaptive_recovery
from flexbid_hybrid.config import load_config


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    run_adaptive_recovery(root, args.config, load_config(args.config), args.resume)


if __name__ == "__main__":
    main()
