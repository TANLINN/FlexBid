#!/usr/bin/env bash
set -u

ROOT=/root/workspace/FlexBid-LLM/hybrid_artifact
CONFIG="$ROOT/configs/a800_8gpu_qwen35_27b_qwen_recovery_b5.yaml"
R="$ROOT/results/hybrid_qwen_recovery_b5_a800_qwen35_27b_20260823"
PYTHON=/root/miniconda3/bin/python
EXPECTED=5

export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

cd "$ROOT"
mkdir -p "$R/logs"

EVENTS="$R/logs/guard.events.log"
COLLECTOR_LOG="$R/logs/collector.log"
WORKERS="$R/retention_worker.pids"

count_cells() {
    find "$R/cells" \
        -type f \
        -name CELL_COMPLETE.json \
        2>/dev/null |
    wc -l
}

restore_power() {
    for gpu in 0 1 2 3 4 5 6 7
    do
        default=$(
            nvidia-smi \
                --query-gpu=power.default_limit \
                --format=csv,noheader,nounits \
                -i "$gpu" 2>/dev/null |
            head -n 1
        )

        if [ -n "$default" ]
        then
            nvidia-smi -i "$gpu" -pl "$default" \
                >> "$EVENTS" 2>&1
        fi
    done
}

start_retention() {
    : > "$WORKERS"

    for gpu in 0 1 2 3 4 5 6 7
    do
        CUDA_VISIBLE_DEVICES="$gpu" \
        "$PYTHON" -u scripts/hybrid_retention_worker.py \
            > "$R/logs/retention_gpu_${gpu}.log" 2>&1 &

        echo "$!" >> "$WORKERS"
    done

    echo "$(date '+%F %T %Z') retention started" \
        >> "$EVENTS"

    wait
}

echo "$(date '+%F %T %Z') qwen recovery-b5 guard started" \
    >> "$EVENTS"

attempt=0
stagnant=0

while [ "$(count_cells)" -lt "$EXPECTED" ] &&
      [ "$stagnant" -lt 3 ]
do
    attempt=$((attempt + 1))
    before="$(count_cells)"

    echo "$(date '+%F %T %Z') attempt=$attempt before=$before" \
        >> "$EVENTS"

    "$PYTHON" scripts/preflight.py \
        --config "$CONFIG" \
        --output "$R/preflight.json" \
        > "$R/logs/preflight.log" 2>&1

    preflight_rc=$?

    if [ "$preflight_rc" -eq 0 ]
    then
        "$PYTHON" -u scripts/run_physical_pilot.py \
            --config "$CONFIG" \
            --resume \
            >> "$COLLECTOR_LOG" 2>&1

        collector_rc=$?
    else
        collector_rc="$preflight_rc"
    fi

    restore_power

    after="$(count_cells)"

    echo "$(date '+%F %T %Z') attempt=$attempt rc=$collector_rc after=$after" \
        >> "$EVENTS"

    if [ "$after" -gt "$before" ]
    then
        stagnant=0
    else
        stagnant=$((stagnant + 1))
    fi

    if [ "$after" -lt "$EXPECTED" ]
    then
        sleep 20
    fi
done

completed="$(count_cells)"

restore_power

if [ "$completed" -ge "$EXPECTED" ]
then
    printf '{"status":"COMPLETE","cells":%s}\n' "$completed" \
        > "$R/RECOVERY_B5_COMPLETE.json"

    echo "$(date '+%F %T %Z') collection complete $completed/$EXPECTED" \
        >> "$EVENTS"
else
    printf '{"status":"INCOMPLETE","cells":%s}\n' "$completed" \
        > "$R/RECOVERY_B5_INCOMPLETE.json"

    echo "$(date '+%F %T %Z') collection incomplete $completed/$EXPECTED" \
        >> "$EVENTS"
fi

start_retention
