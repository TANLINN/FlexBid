#!/usr/bin/env python3
"""Surgical installer for a version-skewed server; never replace whole runners.

The generated paste command supplies BUNDLE. With no payload this module can be
imported to test transformations. All anchors/compilation are checked before any
source change; failed CPU tests restore original files. No GPU jobs are started.
"""
from __future__ import annotations

import ast
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def replace_one(text, old, new):
    if text.count(old) != 1:
        raise ValueError("source differs; expected exactly one anchor: " + old[:100])
    return text.replace(old, new, 1)


def position(text, line, column):
    lines = text.splitlines(keepends=True)
    return sum(len(value) for value in lines[:line - 1]) + len(
        lines[line - 1].encode("utf-8")[:column].decode("utf-8"))


def replace_node(text, node, new):
    start = position(text, node.lineno, node.col_offset)
    end = position(text, node.end_lineno, node.end_col_offset)
    return text[:start] + new + text[end:]


def method(text, name):
    cls = next(node for node in ast.parse(text).body
               if isinstance(node, ast.ClassDef) and node.name == "DynamicControlLoop")
    return next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == name)


def patch_runtime(text):
    init = method(text, "__init__")
    if "force_baseline" not in {arg.arg for arg in init.args.kwonlyargs}:
        text = replace_one(text, "        dry_run: bool = False,",
                           "        force_baseline: bool = False,\n        dry_run: bool = False,")
    if "self.force_baseline = bool(force_baseline)" not in text:
        text = replace_one(text, "        self.offer_calibrator = offer_calibrator",
                           "        self.offer_calibrator = offer_calibrator\n"
                           "        self.force_baseline = bool(force_baseline)")
    commit = method(text, "_commit")
    if not any(isinstance(node, ast.If) and ast.unparse(node.test) == "self.force_baseline"
               for node in ast.walk(commit)):
        first = commit.body[0]
        at = position(text, first.lineno, 0)
        block = (
            "        if self.force_baseline:\n"
            "            self.committed_bid_w = 0.0\n"
            "            self.offer_accepted = False\n"
            "            self.last_offer_calibration = {\n"
            "                'accepted': False, 'raw_bid_w': 0.0, 'calibrated_bid_w': 0.0,\n"
            "                'reason': 'forced matched-baseline trajectory',\n"
            "            }\n"
            "            return 0.0\n"
        )
        text = text[:at] + block + text[at:]
    run = method(text, "run")
    branches = []
    for node in ast.walk(run):
        if isinstance(node, ast.If) and any(
            isinstance(statement, ast.Assign)
            and ast.unparse(statement) == "action = self.actions[self.optimizer.baseline_action]"
            for statement in node.body
        ):
            branches.append(node)
    if len(branches) != 1:
        raise ValueError("cannot uniquely locate baseline actuation branch")
    branch = branches[0]
    if "self.force_baseline" not in ast.unparse(branch.test):
        original = ast.get_source_segment(text, branch.test)
        text = replace_node(text, branch.test, "self.force_baseline or (" + original + ")")
    # Preserve any server cold-start logic inside the existing condition.
    run = method(text, "run")
    dictionaries = [value for node in ast.walk(run) if isinstance(node, ast.Dict)
                    for key, value in zip(node.keys, node.values)
                    if isinstance(key, ast.Constant) and key.value == "baseline_reference"]
    if len(dictionaries) != 1 or not isinstance(dictionaries[0], ast.Dict):
        raise ValueError("baseline reference logging schema differs")
    target = dictionaries[0]
    keys = {key.value for key in target.keys if isinstance(key, ast.Constant)}
    extra = ""
    if "forced_baseline" not in keys:
        extra += '\n                            "forced_baseline": self.force_baseline,'
    if "power_boundary" not in keys:
        extra += '\n                            "power_boundary": "gpu_nvml",'
    if extra:
        at = position(text, target.lineno, target.col_offset) + 1
        text = text[:at] + extra + text[at:]
    text = text.replace("previous.online_replicas != action.online_replicas",
                        "previous.resolved_online_replica_ids() != action.resolved_online_replica_ids()")
    # Do not relabel a server that already has a different meter implementation.
    functions = [node for node in ast.parse(text).body
                 if isinstance(node, ast.FunctionDef) and node.name == "read_component_power_w"]
    if len(functions) != 1:
        raise ValueError("power reader missing")
    body = ast.get_source_segment(text, functions[0])
    if "nvmlDeviceGetPowerUsage" not in body or "rapl" in body.lower():
        raise ValueError("power reader differs; review measurement boundary before installing")
    compile(text, "runtime_controller.py", "exec")
    return text


def patch_runner(text):
    if "optimizer = GuardedViabilityMPC(model, actions, parameters)" not in text:
        text = replace_one(text, "    optimizer = ViabilityMPC(model, actions, parameters)",
            "    from flexbid_hybrid.continuation import GuardedViabilityMPC\n"
            "    from flexbid_hybrid.deployment import bind_live_model\n"
            "    model = bind_live_model(model, frozen_model, config, root, args.source, offline=args.dry_run)\n"
            "    optimizer = GuardedViabilityMPC(model, actions, parameters)")
    elif "model = bind_live_model(" not in text:
        raise ValueError("supervisor present without environment binding")
    calls = [node for node in ast.walk(ast.parse(text))
             if isinstance(node, ast.Call) and ast.unparse(node.func) == "DynamicControlLoop"]
    if len(calls) != 1:
        raise ValueError("runtime constructor call differs")
    if "force_baseline" not in {arg.arg for arg in calls[0].keywords}:
        text = replace_one(text, "        offer_calibrator=calibrator,",
                           "        offer_calibrator=calibrator,\n"
                           '        force_baseline=bool(dynamic.get("force_baseline", False)),')
    compile(text, "run_dynamic_controller.py", "exec")
    return text


def patch_mpc(text):
    loops = [node for node in ast.walk(ast.parse(text)) if isinstance(node, ast.For)
             and ast.unparse(node.target) == "envelope" and ast.unparse(node.iter) == "frontier"]
    if len(loops) != 1:
        raise ValueError("MPC frontier expansion differs")
    loop = loops[0]
    if not any(isinstance(node, ast.If) and ast.unparse(node.test) == "time.perf_counter() > solve_deadline"
               for node in loop.body):
        first = loop.body[0]
        at = position(text, first.lineno, 0)
        indent = " " * first.col_offset
        text = text[:at] + (
            indent + "# Cooperative deadline inside frontier expansion.\n"
            + indent + "if time.perf_counter() > solve_deadline:\n"
            + indent + "    timed_out = True\n" + indent + "    return None\n"
        ) + text[at:]
    compile(text, "mpc.py", "exec")
    return text


def active_collectors(root):
    if os.name != "posix":
        return []
    names = {"run_dynamic_controller.py", "run_dynamic_policy_selection.py", "run_physical_pilot.py"}
    found = []
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit():
            continue
        try:
            args = (directory / "cmdline").read_bytes().decode(errors="replace").split("\0")
            if any(Path(arg).name in names for arg in args):
                found.append(directory.name)
        except (OSError, ValueError):
            continue
    return found


def install(bundle, root):
    root = Path(root).resolve()
    if root.name != "hybrid_artifact" or not (root / "flexbid_hybrid/runtime_controller.py").is_file():
        raise ValueError("run from the restored hybrid_artifact directory")
    active = active_collectors(root)
    if active:
        raise RuntimeError("collection still active; no files changed, PIDs=" + ",".join(active))
    transforms = {
        "flexbid_hybrid/runtime_controller.py": patch_runtime,
        "scripts/run_dynamic_controller.py": patch_runner,
        "flexbid_hybrid/mpc.py": patch_mpc,
    }
    prepared, originals = {}, {}
    for name, transform in transforms.items():
        path = root / name
        originals[name] = path.read_bytes()
        text = originals[name].decode("utf-8").replace("\r\n", "\n")
        prepared[name] = transform(text).encode("utf-8")
    allowed = {
        "flexbid_hybrid/continuation.py", "flexbid_hybrid/deployment.py",
        "scripts/inspect_deployment.py", "tests/test_runtime_safety.py",
        "scripts/install_runtime_safety.py",
        "RUNTIME_SAFETY.md",
    }
    if set(bundle) != allowed:
        raise ValueError("unexpected payload file set")
    for name, text in bundle.items():
        path = root / name
        if path.resolve().parent != (root / name).parent.resolve() or path.is_symlink():
            raise ValueError("symlink target refused")
        if root not in path.resolve().parents:
            raise ValueError("target escaped project")
        existing = path.read_bytes() if path.exists() else None
        data = text.encode("utf-8")
        if existing is not None and existing.replace(b"\r\n", b"\n") != data:
            raise ValueError("new module already exists with different content: " + name)
        originals[name] = existing
        if name.endswith(".py"):
            compile(text, name, "exec")
        prepared[name] = data
    for name in transforms:
        if root not in (root / name).resolve().parents or (root / name).is_symlink():
            raise ValueError("source symlink/escaped project refused")
    backup = root / "results/patch_backups" / datetime.now().strftime("runtime_safety_%Y%m%d_%H%M%S_%f")
    if root not in backup.resolve().parents:
        raise ValueError("backup directory escaped project")
    backup.mkdir(parents=True, exist_ok=False)
    for name, data in originals.items():
        if data is not None:
            path = backup / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
    changed = []
    try:
        for name, data in prepared.items():
            path = root / name
            before = path.read_bytes() if path.exists() else None
            if before != originals[name]:
                raise RuntimeError("source changed during install: " + name)
            if before != data:
                path.parent.mkdir(parents=True, exist_ok=True)
                changed.append(name)
                path.write_bytes(data)
        env = {**os.environ, "PYTHONPATH": str(root) + os.pathsep + os.environ.get("PYTHONPATH", ""),
               "PYTHONDONTWRITEBYTECODE": "1"}
        result = subprocess.run([sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-q"],
                                cwd=root, env=env)
        if result.returncode:
            raise RuntimeError("CPU tests failed")
    except BaseException:
        for name in reversed(changed):
            path = root / name
            if originals[name] is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(originals[name])
        print("ROLLED_BACK_SOURCE_CHANGES; original files kept; backup=" + str(backup))
        raise
    print("RUNTIME_SAFETY_INSTALLED; CPU_TESTS_PASSED; GPU_COLLECTION_NOT_STARTED")
    print("LIVE_BIDDING_REQUIRES_TARGET_EVIDENCE; no old model was certified or relabelled")
    print("BACKUP=" + str(backup))


if __name__ == "__main__":
    if "BUNDLE" not in globals():
        raise SystemExit("Use the generated paste command; no payload supplied")
    install(BUNDLE, Path.cwd())
