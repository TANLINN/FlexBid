#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def run(root: Path, phase: str, command: list[str]) -> None:
    print(json.dumps({"phase": phase, "command": command}), flush=True)
    subprocess.run(command, cwd=root, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile-results", type=Path, required=True)
    parser.add_argument("--ablation-results", type=Path, required=True)
    parser.add_argument("--catchup-report", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--test-results", required=True)
    parser.add_argument("--test-config", type=Path, required=True)
    parser.add_argument("--test-episodes-per-source", type=int, default=5)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    output = args.output_root.resolve()
    output.mkdir(parents=True, exist_ok=True)
    logs = output / "logs"
    logs.mkdir(exist_ok=True)
    fit_root = output / "models"

    if not (fit_root / "SURROGATE_FIT_COMPLETE.json").exists():
        run(root, "fit", [
            sys.executable, "-u", "scripts/fit_hybrid_surrogate.py",
            "--profile-results", str(args.profile_results.resolve()),
            "--ablation-results", str(args.ablation_results.resolve()),
            "--output-root", str(fit_root),
        ])

    run(root, "prepare-test", [
        sys.executable, "-u", "scripts/prepare_hybrid_test_config.py",
        "--profile-results", str(args.profile_results.resolve()),
        "--ablation-results", str(args.ablation_results.resolve()),
        "--output-config", str(args.test_config.resolve()),
        "--test-results", args.test_results,
        "--test-episodes-per-source", str(args.test_episodes_per_source),
    ])

    run(root, "preflight-test", [
        sys.executable, "-u", "scripts/preflight.py",
        "--config", str(args.test_config.resolve()),
        "--output", str(output / "test_preflight.json"),
    ])

    run(root, "collect-test", [
        sys.executable, "-u", "scripts/run_physical_pilot.py",
        "--config", str(args.test_config.resolve()), "--resume",
    ])
    run(root, "analyze-test", [
        sys.executable, "-u", "scripts/analyze_physical_pilot.py",
        "--config", str(args.test_config.resolve()),
    ])
    if not (output / "HYBRID_OFFLINE_EVALUATION_COMPLETE.json").exists():
        run(root, "evaluate-test", [
            sys.executable, "-u", "scripts/evaluate_hybrid_test.py",
            "--test-results", str((root / args.test_results).resolve()),
            "--test-config", str(args.test_config.resolve()),
            "--fit-root", str(fit_root),
            "--catchup-report", str(args.catchup_report.resolve()),
            "--output-root", str(output),
        ])
    complete = {
        "status": "HYBRID_ALGORITHM_PIPELINE_COMPLETE",
        "fit_root": str(fit_root),
        "test_results": str((root / args.test_results).resolve()),
        "evaluation": str(output),
    }
    (output / "PIPELINE_COMPLETE.json").write_text(
        json.dumps(complete, indent=2), encoding="utf-8"
    )
    print(json.dumps(complete, indent=2))


if __name__ == "__main__":
    main()
