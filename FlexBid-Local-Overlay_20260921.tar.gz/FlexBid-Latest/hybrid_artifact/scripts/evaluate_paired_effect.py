#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

from flexbid_hybrid.modeling import HybridSurrogate, read_csv
from flexbid_hybrid.paired import PairedEffectCalibrator, paired_effect_bid
from flexbid_hybrid.policy import BASELINE_ACTION


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = list(rows[0]) if rows else []
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def average(rows: list[dict], key: str) -> float:
    return mean(float(row[key]) for row in rows) if rows else 0.0


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fit-root", type=Path, required=True)
    parser.add_argument("--test-dataset", type=Path, required=True)
    parser.add_argument("--catchup-report", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--alpha", type=float, default=0.05)
    parser.add_argument("--delivery-tolerance-w", type=float, default=50.0)
    args = parser.parse_args()

    args.output_root.mkdir(parents=True, exist_ok=True)
    fitting = read_csv(args.fit_root / "hybrid_surrogate_dataset.csv")
    train = [row for row in fitting if row["data_split"] == "train"]
    calibration = [row for row in fitting if row["data_split"] == "calibration"]
    test = read_csv(args.test_dataset)
    surrogate = HybridSurrogate.load(args.fit_root / "cross_layer_surrogate.joblib")
    calibrator = PairedEffectCalibrator(args.alpha).fit(train, calibration, surrogate)
    catchup = json.loads(args.catchup_report.read_text(encoding="utf-8"))
    catchup_by_source = {
        str(row["source"]): bool(row["deadline_safe"])
        for row in catchup["sources"]
    }
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in test:
        grouped[str(row["episode_id"])].append(row)

    reduction_margin, ttft_margin, tpot_margin = calibrator.margins()
    episode_rows = []
    covered_episodes = 0
    for episode_id, rows in sorted(grouped.items()):
        by_name = {str(row["name"]): row for row in rows}
        baseline = by_name[BASELINE_ACTION]
        baseline_prediction = surrogate.predict(baseline)
        covered = (
            float(baseline["ttft_p95_ms"])
            <= baseline_prediction.ttft_p95_ms + ttft_margin
            and float(baseline["tpot_p99_ms"])
            <= baseline_prediction.tpot_p99_ms + tpot_margin
        )
        for name, row in by_name.items():
            if name == BASELINE_ACTION:
                continue
            prediction = surrogate.predict(row)
            predicted_reduction = (
                baseline_prediction.power_mean_w - prediction.power_mean_w
            )
            actual_reduction = (
                float(baseline["power_mean_w"]) - float(row["power_mean_w"])
            )
            covered = covered and (
                actual_reduction >= predicted_reduction - reduction_margin
                and float(row["ttft_p95_ms"])
                <= prediction.ttft_p95_ms + ttft_margin
                and float(row["tpot_p99_ms"])
                <= prediction.tpot_p99_ms + tpot_margin
            )
        covered_episodes += int(covered)

        decision = paired_effect_bid(rows, surrogate, calibrator)
        actual = by_name[decision.action_name]
        baseline_safe = bool(baseline["slo_safe"])
        selected_safe = bool(actual["slo_safe"])
        achieved = float(baseline["power_mean_w"]) - float(actual["power_mean_w"])
        nonbaseline = decision.action_name != BASELINE_ACTION
        catchup_known = (not nonbaseline) or str(actual["source"]) in catchup_by_source
        deadline_safe = (
            True if not nonbaseline else catchup_by_source.get(str(actual["source"]))
        )
        episode_rows.append({
            "episode_id": episode_id,
            "source": actual["source"],
            "action": decision.action_name,
            "feasible": int(decision.feasible),
            "abstained": int(not decision.feasible),
            "bid_w": decision.committed_reduction_w,
            "achieved_reduction_w": achieved,
            "achieved_reduction_pct": (
                100 * achieved / float(baseline["power_mean_w"])
            ),
            "delivery_failure": int(
                decision.committed_reduction_w > 0
                and achieved + args.delivery_tolerance_w
                < decision.committed_reduction_w
            ),
            "baseline_slo_failure": int(not baseline_safe),
            "selected_slo_failure": int(not selected_safe),
            "dr_induced_slo_failure": int(baseline_safe and not selected_safe),
            "catchup_known": int(catchup_known),
            "batch_deadline_failure": int(
                catchup_known and deadline_safe is False
            ),
            "decision_reason": decision.reason,
        })

    write_csv(args.output_root / "paired_effect_episode_results.csv", episode_rows)
    eligible = [row for row in episode_rows if not row["baseline_slo_failure"]]
    committed = [row for row in eligible if float(row["bid_w"]) > 0]
    summary = {
        "status": "PAIRED_EFFECT_AUDIT_COMPLETE",
        "calibrator": calibrator.as_dict(),
        "test_episodes": len(episode_rows),
        "episode_coverage": covered_episodes / len(episode_rows),
        "baseline_safe_episodes": len(eligible),
        "committed_eligible_episodes": len(committed),
        "eligible_commit_rate": len(committed) / len(eligible) if eligible else 0.0,
        "mean_bid_w_on_committed": average(committed, "bid_w"),
        "mean_reduction_pct_on_committed": average(
            committed, "achieved_reduction_pct"
        ),
        "delivery_failure_rate_on_committed": average(
            committed, "delivery_failure"
        ),
        "dr_induced_slo_failure_rate_on_committed": average(
            committed, "dr_induced_slo_failure"
        ),
        "catchup_unknown_committed": sum(
            not int(row["catchup_known"]) for row in committed
        ),
        "action_counts": dict(Counter(row["action"] for row in episode_rows)),
        "important": (
            "Batch-deadline safety remains provisional for committed sources "
            "without a matching recovery experiment."
        ),
    }
    (args.output_root / "PAIRED_EFFECT_AUDIT.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
