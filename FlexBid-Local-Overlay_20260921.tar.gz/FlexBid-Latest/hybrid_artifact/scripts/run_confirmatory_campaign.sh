#!/usr/bin/env bash
set -Eeuo pipefail

ROOT=/root/workspace/FlexBid-LLM/hybrid_artifact
CAMPAIGN=$ROOT/results/hybrid_confirmatory_a800_qwen35_27b_20260823
EVENT_CONFIG=$ROOT/configs/a800_8gpu_qwen35_27b_confirmatory_event.yaml
ADAPTIVE_CONFIG=$ROOT/configs/a800_8gpu_qwen35_27b_confirmatory_adaptive.yaml
EVENT_RESULT=$ROOT/results/hybrid_confirmatory_event_a800_qwen35_27b_20260823
ADAPTIVE_RESULT=$ROOT/results/hybrid_confirmatory_adaptive_a800_qwen35_27b_20260823

cd "$ROOT"
source /root/workspace/FlexBid-LLM/.venv/bin/activate
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

mkdir -p "$CAMPAIGN/logs"

start_retention() {
    echo "$(date) campaign process ended" >> "$CAMPAIGN/logs/campaign.events.log"

    for attempt in $(seq 1 18)
    do
        if ! pgrep -f '[v]llm serve' >/dev/null 2>&1; then
            break
        fi
        sleep 10
    done

    if pgrep -f '[v]llm serve' >/dev/null 2>&1; then
        echo "$(date) retention refused: vLLM still running" \
            >> "$CAMPAIGN/logs/campaign.events.log"
        return
    fi

    if [ ! -f scripts/hybrid_retention_worker.py ]; then
        echo "$(date) retention worker missing" \
            >> "$CAMPAIGN/logs/campaign.events.log"
        return
    fi

    : > "$CAMPAIGN/retention_worker.pids"

    for gpu in 0 1 2 3 4 5 6 7
    do
        nohup setsid env CUDA_VISIBLE_DEVICES="$gpu" \
            python -u scripts/hybrid_retention_worker.py \
            > "$CAMPAIGN/logs/retention_gpu_${gpu}.log" 2>&1 &
        echo $! >> "$CAMPAIGN/retention_worker.pids"
    done

    echo "$(date) tracked retention started" \
        >> "$CAMPAIGN/logs/campaign.events.log"
}

trap start_retention EXIT

echo "$(date) confirmatory campaign started" \
    >> "$CAMPAIGN/logs/campaign.events.log"

echo "preflight-event" > "$CAMPAIGN/phase.txt"

python scripts/preflight.py \
    --config "$EVENT_CONFIG" \
    --output "$CAMPAIGN/event_preflight.json"

echo "collect-event" > "$CAMPAIGN/phase.txt"

python -u scripts/run_physical_pilot.py \
    --config "$EVENT_CONFIG" \
    --resume \
    > "$CAMPAIGN/logs/event_collection.log" 2>&1

python scripts/analyze_physical_pilot.py \
    --config "$EVENT_CONFIG" \
    > "$CAMPAIGN/logs/event_analysis.log" 2>&1

sleep 15

echo "preflight-adaptive" > "$CAMPAIGN/phase.txt"

python scripts/preflight.py \
    --config "$ADAPTIVE_CONFIG" \
    --output "$CAMPAIGN/adaptive_preflight.json"

echo "collect-adaptive" > "$CAMPAIGN/phase.txt"

python -u scripts/run_adaptive_recovery.py \
    --config "$ADAPTIVE_CONFIG" \
    --resume \
    > "$CAMPAIGN/logs/adaptive_collection.log" 2>&1

echo "complete" > "$CAMPAIGN/phase.txt"

python - <<'PY'
import json
from pathlib import Path

campaign = Path(
    "results/hybrid_confirmatory_a800_qwen35_27b_20260823"
)
event = Path(
    "results/hybrid_confirmatory_event_a800_qwen35_27b_20260823"
)
adaptive = Path(
    "results/hybrid_confirmatory_adaptive_a800_qwen35_27b_20260823"
)

event_cells = len(list(event.glob("cells/*/*/CELL_COMPLETE.json")))
adaptive_cells = len(
    list(adaptive.glob("cells/*/adaptive_recovery/CELL_COMPLETE.json"))
)

marker = {
    "status": (
        "CONFIRMATORY_COLLECTION_COMPLETE"
        if event_cells == 20 and adaptive_cells == 10
        else "INCOMPLETE"
    ),
    "event_cells": event_cells,
    "adaptive_cells": adaptive_cells,
}

(campaign / "CONFIRMATORY_COLLECTION_COMPLETE.json").write_text(
    json.dumps(marker, indent=2),
    encoding="utf-8",
)

print(json.dumps(marker, indent=2))
PY

echo "$(date) confirmatory collection complete" \
    >> "$CAMPAIGN/logs/campaign.events.log"
