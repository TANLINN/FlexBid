#!/usr/bin/env bash
set -u

ROOT=/root/workspace/FlexBid-LLM/hybrid_artifact
PY=/root/workspace/FlexBid-LLM/.venv/bin/python
MASTER=$ROOT/results/hybrid_recovery_support_campaign_20260828
EVENTS=$MASTER/logs/events.log

cd "$ROOT"
mkdir -p "$MASTER/logs"

export PATH="/root/workspace/FlexBid-LLM/.venv/bin:$PATH"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"

echo "$(date) recovery-support campaign started" >> "$EVENTS"

OVERALL_RC=0

for PHASE in train calibration
do
  CONFIG="$ROOT/configs/generated/a800_8gpu_qwen35_27b_recovery_support_${PHASE}.yaml"
  RESULT="$ROOT/results/hybrid_recovery_support_${PHASE}_a800_qwen35_27b_20260828"
  EXPECTED=60

  mkdir -p "$RESULT/logs"

  BEFORE=$(
    find "$RESULT/cells" -type f -name CELL_COMPLETE.json \
      2>/dev/null | wc -l
  )

  echo "$(date) phase=$PHASE before=$BEFORE expected=$EXPECTED" \
    >> "$EVENTS"

  "$PY" scripts/preflight.py \
    --config "$CONFIG" \
    --output "$RESULT/preflight.json" \
    > "$RESULT/logs/preflight.log" 2>&1

  RC=$?
  if [ "$RC" -ne 0 ]; then
    echo "$(date) phase=$PHASE preflight_failed rc=$RC" \
      >> "$EVENTS"
    OVERALL_RC=$RC
    break
  fi

  "$PY" -u scripts/run_physical_pilot.py \
    --config "$CONFIG" \
    --resume \
    > "$RESULT/logs/collector.log" 2>&1

  RC=$?

  AFTER=$(
    find "$RESULT/cells" -type f -name CELL_COMPLETE.json \
      2>/dev/null | wc -l
  )

  echo "$(date) phase=$PHASE collector_rc=$RC after=$AFTER" \
    >> "$EVENTS"

  if [ "$RC" -ne 0 ] || [ "$AFTER" -ne "$EXPECTED" ]; then
    OVERALL_RC=3
    break
  fi

  "$PY" scripts/analyze_physical_pilot.py \
    --config "$CONFIG" \
    > "$RESULT/logs/analysis.log" 2>&1

  RC=$?
  echo "$(date) phase=$PHASE analysis_rc=$RC" >> "$EVENTS"

  if [ "$RC" -ne 0 ]; then
    OVERALL_RC=$RC
    break
  fi
done

TRAIN=$(
  find results/hybrid_recovery_support_train_a800_qwen35_27b_20260828/cells \
    -type f -name CELL_COMPLETE.json 2>/dev/null | wc -l
)
CAL=$(
  find results/hybrid_recovery_support_calibration_a800_qwen35_27b_20260828/cells \
    -type f -name CELL_COMPLETE.json 2>/dev/null | wc -l
)

"$PY" - "$MASTER" "$TRAIN" "$CAL" "$OVERALL_RC" <<'PYMARK'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
train = int(sys.argv[2])
calibration = int(sys.argv[3])
rc = int(sys.argv[4])

report = {
    "status": (
        "RECOVERY_SUPPORT_COMPLETE"
        if rc == 0 and train == 60 and calibration == 60
        else "RECOVERY_SUPPORT_INCOMPLETE"
    ),
    "train_cells": train,
    "expected_train_cells": 60,
    "calibration_cells": calibration,
    "expected_calibration_cells": 60,
    "return_code": rc,
}
(root / "COLLECTION_COMPLETE.json").write_text(
    json.dumps(report, indent=2),
    encoding="utf-8",
)
print(json.dumps(report, indent=2))
PYMARK

echo "$(date) campaign ended train=$TRAIN calibration=$CAL rc=$OVERALL_RC" \
  >> "$EVENTS"

exit "$OVERALL_RC"
