#!/usr/bin/env bash
set -uo pipefail

ROOT=/root/workspace/FlexBid-LLM/hybrid_artifact
CONFIG="$ROOT/configs/a800_8gpu_qwen35_27b_lowload_recovery.yaml"
RESULT="$ROOT/results/hybrid_lowload_recovery_a800_qwen35_27b_20260823"
EVENTS="$RESULT/logs/guard.events.log"
WORKERS="$RESULT/retention_worker.pids"
EXPECTED=10

cd "$ROOT"
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" || exit 2
mkdir -p "$RESULT/logs"

stamp() {
  date '+%F %T %Z'
}

count_cells() {
  find "$RESULT/cells" -type f -name CELL_COMPLETE.json \
    2>/dev/null | wc -l
}

restore_caps() {
  local gpu default

  for gpu in 0 1 2 3 4 5 6 7
  do
    default="$(
      nvidia-smi -i "$gpu" \
        --query-gpu=power.default_limit \
        --format=csv,noheader,nounits \
        2>/dev/null |
      head -n 1 |
      xargs || true
    )"

    if [ -n "$default" ]; then
      nvidia-smi -i "$gpu" -pl "$default" \
        >/dev/null 2>&1 || true
    fi
  done
}

start_retention() {
  local gpu

  restore_caps
  : > "$WORKERS"

  for gpu in 0 1 2 3 4 5 6 7
  do
    CUDA_VISIBLE_DEVICES="$gpu" \
      python -u scripts/hybrid_retention_worker.py \
      >> "$RESULT/logs/retention_gpu_${gpu}.log" 2>&1 &

    echo "$!" >> "$WORKERS"
  done

  echo "$(stamp) retention started" >> "$EVENTS"
  wait
}

echo "$(stamp) recovery guard started" >> "$EVENTS"

attempt=0
stagnant=0

while [ "$(count_cells)" -lt "$EXPECTED" ]
do
  attempt=$((attempt + 1))
  before="$(count_cells)"

  echo "$(stamp) attempt=$attempt before=$before" >> "$EVENTS"

  python scripts/preflight.py \
    --config "$CONFIG" \
    --output "$RESULT/preflight.json" \
    >> "$RESULT/logs/preflight.log" 2>&1

  preflight_rc=$?

  if [ "$preflight_rc" -eq 0 ]; then
    PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" \
      python -u scripts/run_physical_pilot.py \
        --config "$CONFIG" \
        --resume \
        >> "$RESULT/logs/collection.log" 2>&1

    rc=$?
  else
    rc=$preflight_rc
  fi

  restore_caps
  after="$(count_cells)"

  echo \
    "$(stamp) attempt=$attempt rc=$rc after=$after" \
    >> "$EVENTS"

  if [ "$after" -ge "$EXPECTED" ]; then
    break
  fi

  if [ "$after" -gt "$before" ]; then
    stagnant=0
  else
    stagnant=$((stagnant + 1))
  fi

  if [ "$stagnant" -ge 3 ]; then
    echo \
      "$(stamp) blocked after three stagnant attempts" \
      >> "$EVENTS"
    break
  fi

  sleep 15
done

complete="$(count_cells)"
restore_caps

if [ "$complete" -ge "$EXPECTED" ]; then
  python - <<PY
import json
from pathlib import Path

Path("$RESULT/RECOVERY_COLLECTION_COMPLETE.json").write_text(
    json.dumps(
        {
            "status": "RECOVERY_COLLECTION_COMPLETE",
            "cells": $complete,
            "expected": $EXPECTED,
        },
        indent=2,
    ),
    encoding="utf-8",
)
PY

  echo "$(stamp) recovery complete $complete/$EXPECTED" \
    >> "$EVENTS"
else
  echo "$(stamp) recovery incomplete $complete/$EXPECTED" \
    >> "$EVENTS"
fi

start_retention
