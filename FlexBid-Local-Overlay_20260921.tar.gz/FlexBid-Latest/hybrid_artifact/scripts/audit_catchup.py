#!/usr/bin/env python3
import csv
import json
import math
from pathlib import Path

root = Path(
    "results/hybrid_catchup_a800_qwen35_27b_20260821"
)
rows = list(csv.DictReader((root / "cell_summary.csv").open()))

event_s = 300.0
deadline_s = 1800.0
remaining_s = deadline_s - event_s
required_ratio = deadline_s / remaining_s

reports = []
passed = True

for source in ("azure_code", "azure_conversation"):
    values = [row for row in rows if row["source"] == source]
    baseline = next(row for row in values if row["name"] == "hybrid_full")

    baseline_tps = float(baseline["batch_tokens_per_s"])
    baseline_safe = baseline["slo_safe"].lower() == "true"
    required_tps = baseline_tps * required_ratio

    candidates = []
    for row in values:
        if not row["name"].startswith("recovery_"):
            continue
        safe = row["slo_safe"].lower() == "true"
        throughput = float(row["batch_tokens_per_s"])
        if safe and throughput >= required_tps:
            candidates.append(row)

    selected = min(
        candidates,
        key=lambda row: (
            int(float(row["batch_concurrency"])),
            float(row["power_mean_w"]),
        ),
    ) if candidates else None

    recovery_tps = (
        None if selected is None
        else float(selected["batch_tokens_per_s"])
    )

    catchup_s = None
    if recovery_tps is not None and recovery_tps > baseline_tps:
        catchup_s = baseline_tps * event_s / (
            recovery_tps - baseline_tps
        )

    source_passed = (
        baseline_safe
        and selected is not None
        and catchup_s is not None
        and catchup_s <= remaining_s
    )
    passed = passed and source_passed

    reports.append({
        "source": source,
        "baseline_slo_safe": baseline_safe,
        "baseline_batch_tokens_per_s": baseline_tps,
        "required_recovery_ratio": required_ratio,
        "required_recovery_tokens_per_s": required_tps,
        "selected_recovery_action": (
            None if selected is None else selected["name"]
        ),
        "selected_recovery_tokens_per_s": recovery_tps,
        "estimated_catchup_s": catchup_s,
        "available_catchup_s": remaining_s,
        "deadline_safe": source_passed,
    })

report = {
    "status": (
        "PASS_CATCHUP_DEADLINE"
        if passed else "FAIL_CATCHUP_DEADLINE"
    ),
    "dr_event_s": event_s,
    "batch_deadline_s": deadline_s,
    "required_recovery_ratio": required_ratio,
    "sources": reports,
}

(root / "CATCHUP_REPORT.json").write_text(
    json.dumps(report, indent=2)
)
(root / (
    "PIPELINE_COMPLETE" if passed else "PIPELINE_BLOCKED"
)).write_text(report["status"] + "\n")

print(json.dumps(report, indent=2))
