#!/usr/bin/env python3
"""Transactional, surgical timing patch. Unknown server versions fail closed."""
from __future__ import annotations

import ast
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def once(text, old, new):
    if text.count(old) != 1:
        raise ValueError("source differs, no installation: " + old[:110])
    return text.replace(old, new, 1)


def patch_runtime(text):
    if "# FIXED_EVENT_CLOCK_V1" in text:
        return text
    text = once(text, "        dry_run: bool = False,",
        "        offer_lead_s: float = 30.0,\n"
        "        activation_wall_ns: int | None = None,\n"
        "        meter_sample_s: float = 0.2,\n"
        "        meter_max_gap_s: float = 1.0,\n        dry_run: bool = False,")
    text = once(text, "        self.dry_run = dry_run",
        "        # FIXED_EVENT_CLOCK_V1\n"
        "        if not math.isfinite(offer_lead_s) or offer_lead_s <= 0:\n"
        "            raise ValueError('offer_lead_s must be finite and positive')\n"
        "        self.offer_lead_s = offer_lead_s\n"
        "        self.activation_wall_ns = activation_wall_ns\n"
        "        self.meter_sample_s = meter_sample_s\n"
        "        self.meter_max_gap_s = meter_max_gap_s\n"
        "        self.event_session = None\n        self.dry_run = dry_run")
    text = once(text, "            started_ns = time.time_ns()",
        "            from .event_protocol import prepare_event, next_plan\n"
        "            protocol = prepare_event(self, initial, baseline_power_w,\n"
        "                                     baseline_ttft_ms, baseline_tpot_ms)\n"
        "            started_ns = protocol.activation_wall_ns\n"
        "            initial = self.state_reader(self.gateway_url + '/flexbid/state')")
    text = once(text, '                    iteration_ns = time.time_ns()',
        '                    elapsed_s, observed_power = protocol.sample_now()\n'
        '                    iteration_ns = started_ns + int(elapsed_s * 1e9)')
    text = once(text, '                    observed_power = read_component_power_w(self.gpu_indices)',
                     '                    # Power and monotonic elapsed sampled together above.')
    # Replace precisely the legacy settlement block, retaining server-specific
    # model updates, cold-start checks and remaining loop logic.
    start = '                    period_s = max(0.0, elapsed_s - self.previous_elapsed_s)\n'
    end = '                    state = ControlState('
    if text.count(start) != 1 or text.count(end) != 1:
        raise ValueError('legacy settlement block differs')
    a, b = text.index(start), text.index(end)
    if b <= a or 'settlement_delivered_ws +=' not in text[a:b]:
        raise ValueError('legacy meter layout differs')
    text = text[:a] + (
        '                    settlement = protocol.snapshot(elapsed_s)\n'
        '                    settlement_elapsed_s = settlement["partial_elapsed_s"]\n'
        '                    settlement_delivered_ws = settlement["partial_delivered_ws"]\n'
        '                    settlement_failures = settlement["failures"]\n'
    ) + text[b:]
    text = once(text, '\n                    plan = self.optimizer.solve(state)\n',
                     '\n                    plan = next_plan(protocol, self, state)\n')
    text = once(text, '                    actuation = self._actuate(action, power_manager)',
        '                    actuation = self._actuate(action, power_manager)\n'
        '                    if protocol.first_actuation_elapsed_s is None:\n'
        '                        protocol.first_actuation_elapsed_s = protocol.elapsed()')
    text = once(text, '                        "observation": asdict(observation),',
        '                        "event_contract": protocol.metadata(),\n'
        '                        "settlement_status": settlement,\n'
        '                        "observation": asdict(observation),')
    text = once(text, '                        time.time_ns() - iteration_ns\n'
                     '                    ) / 1e9',
        '                        protocol.elapsed() - elapsed_s\n                    )')
    text = once(text, '        finally:\n            baseline = self.actions[self.optimizer.baseline_action]',
        '        finally:\n'
        '            if self.event_session is not None:\n'
        '                try:\n'
        '                    self.event_session.close()\n'
        '                except Exception as exc:\n'
        '                    # Meter report failure must not skip GPU restoration.\n'
        '                    print("EVENT_REPORT_FAILED:", repr(exc), flush=True)\n'
        '            baseline = self.actions[self.optimizer.baseline_action]')
    compile(text, 'runtime_controller.py', 'exec')
    return text


def patch_runner(text):
    if '"--activation-wall-ns"' in text:
        return text
    text = once(text, '    parser.add_argument("--dry-run", action="store_true")',
        '    parser.add_argument("--activation-wall-ns", type=int)\n'
        '    parser.add_argument("--dry-run", action="store_true")')
    text = once(text, '        dry_run=args.dry_run,',
        '        offer_lead_s=float(dynamic.get("offer_lead_s", 30.0)),\n'
        '        activation_wall_ns=args.activation_wall_ns,\n'
        '        meter_sample_s=float(dynamic.get("meter_sample_s", 0.2)),\n'
        '        meter_max_gap_s=float(dynamic.get("meter_max_gap_s", 1.0)),\n'
        '        dry_run=args.dry_run,')
    return text


def patch_collector(text):
    if '# FIXED_EVENT_CLOCK_V1' in text:
        return text
    text = once(text, '    workload_s = warmup_s + deadline_s',
        '    # FIXED_EVENT_CLOCK_V1: explicit offer lead is outside the event.\n'
        '    offer_lead_s = float(dynamic.get("offer_lead_s", 30.0))\n'
        '    workload_s = warmup_s + offer_lead_s + deadline_s')
    text = once(text, '        "raw_policy": True,',
        '        "event_protocol": "fixed_event_clock_v1",\n'
        '        "offer_lead_s": offer_lead_s,\n'
        '        "activation_wall_ns": start_wall_ns + int((warmup_s + offer_lead_s) * 1e9),\n'
        '        "raw_policy": True,')
    text = once(text, '            "--output-dir", str(run_dir.resolve()),',
        '            "--output-dir", str(run_dir.resolve()),\n'
        '            "--activation-wall-ns", str(start_wall_ns + int((warmup_s + offer_lead_s) * 1e9)),')
    # Refuse mixing old/partially resumed measurements with changed protocol.
    text = once(text, '    output.mkdir(parents=True, exist_ok=True)',
        '    output.mkdir(parents=True, exist_ok=True)\n'
        '    if any((output / "cells").rglob("cell.json")):\n'
        '        raise RuntimeError("Timing protocol requires a NEW output root; old cells preserved")')
    text = once(text, '            marker["controller_return_code"] == 0',
        '            marker.get("event_protocol_complete") is True\n'
        '            and marker["controller_return_code"] == 0')
    text = once(text, '    marker = {\n        "controller_return_code": controller_rc,',
        '    from flexbid_hybrid.event_protocol import audit_completed_event\n'
        '    event_audit = audit_completed_event(run_dir)\n'
        '    marker = {\n'
        '        "event_protocol_complete": event_audit["complete"],\n'
        '        "event_audit": event_audit,\n'
        '        "controller_return_code": controller_rc,')
    text = once(text, '        "settlement_failures": len(settlement_failures),',
        '        "settlement_failures": event_audit["failed_windows"],')
    return text


FILES = {
    'flexbid_hybrid/event_protocol.py', 'scripts/install_event_protocol.py',
    'scripts/run_event_clock_smoke.py', 'tests/test_event_protocol.py',
    'EVENT_CONTRACT_DECISIONS.md',
}
TRANSFORMS = {'flexbid_hybrid/runtime_controller.py': patch_runtime,
              'scripts/run_dynamic_controller.py': patch_runner,
              'scripts/run_dynamic_policy_selection.py': patch_collector}


def install(bundle, root):
    root = Path(root).resolve()
    if root.name != 'hybrid_artifact' or set(bundle) != FILES:
        raise ValueError('unexpected project or payload')
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location('prior_safety', root / 'scripts/install_runtime_safety.py')
    prior = module_from_spec(spec)
    spec.loader.exec_module(prior)
    if prior.active_collectors(root):
        raise RuntimeError('active collection; no files modified')
    prepared, old = {}, {}
    for name in {*FILES, *TRANSFORMS}:
        path = root / name
        if path.is_symlink() or root not in path.resolve().parents:
            raise ValueError('escaped/symlink target')
        old[name] = path.read_bytes() if path.exists() else None
        if name in TRANSFORMS:
            prepared[name] = TRANSFORMS[name](old[name].decode('utf-8').replace('\r\n', '\n'))
        else:
            prepared[name] = bundle[name]
            if old[name] is not None and old[name].decode('utf-8').replace('\r\n', '\n') != bundle[name]:
                raise ValueError('existing new module differs: ' + name)
        if name.endswith('.py'):
            compile(prepared[name], name, 'exec')
    backup = root / 'results/patch_backups' / datetime.now().strftime('event_clock_%Y%m%d_%H%M%S_%f')
    if root not in backup.resolve().parents:
        raise ValueError('backup escaped project')
    for name, data in old.items():
        if data is not None:
            dest = backup / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
    changed = []
    try:
        for name, text in prepared.items():
            path = root / name
            if (path.read_bytes() if path.exists() else None) != old[name]:
                raise RuntimeError('concurrent source change')
            if old[name] != text.encode():
                changed.append(name)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(text, encoding='utf-8', newline='\n')
        env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(root)}
        subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-q'],
                       cwd=root, env=env, check=True)
    except BaseException:
        for name in reversed(changed):
            path = root / name
            if old[name] is None:
                path.unlink(missing_ok=True)
            else:
                path.write_bytes(old[name])
        print('ROLLED_BACK; original code and results preserved')
        raise
    print('EVENT_CLOCK_INSTALLED; GPU_COLLECTION_NOT_STARTED; BACKUP=' + str(backup))


if __name__ == '__main__':
    install(BUNDLE, Path.cwd())
