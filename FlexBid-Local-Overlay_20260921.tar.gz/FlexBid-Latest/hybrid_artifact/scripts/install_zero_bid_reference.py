#!/usr/bin/env python3
"""Narrow transactional fix for restored event-clock runtimes; preserve hotfixes."""
import ast
from datetime import datetime
import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import uuid

FILES = {'flexbid_hybrid/zero_bid_reference.py', 'tests/test_zero_bid_reference.py',
         'scripts/run_zero_bid_integration_smoke.py', 'tests/test_zero_bid_integration_smoke.py',
         'scripts/install_zero_bid_reference.py'}
ANCHOR = '            from .event_protocol import prepare_event, next_plan\n'
CALL = ('            from .zero_bid_reference import freeze_zero_bid_reference\n'
        '            freeze_zero_bid_reference(self, baseline_power_w)\n')


def patch_runtime(source):
    if source.count(ANCHOR) != 1:
        raise ValueError('Unknown runtime; expected exactly one event preparation anchor')
    # The local original has a legacy generic fallback; the preserved server
    # hotfix has none. Remove only the exact standalone fallback if present.
    tree = ast.parse(source)
    targets = [node for node in ast.walk(tree) if isinstance(node, ast.If)
               and ast.unparse(node.test) == 'not self.contract.reference_power_w']
    if len(targets) > 1:
        raise ValueError('Ambiguous legacy reference blocks')
    if targets:
        node = targets[0]
        segment = ast.get_source_segment(source, node)
        if ('self.contract = replace(' not in segment or 'baseline_power_w' not in segment
                or node.orelse):
            raise ValueError('Unrecognized legacy reference fallback')
        lines = source.splitlines(keepends=True)
        del lines[node.lineno - 1:node.end_lineno]
        source = ''.join(lines)
    if CALL not in source:
        if 'freeze_zero_bid_reference' in source:
            raise ValueError('Partially applied reference fix')
        source = source.replace(ANCHOR, CALL + ANCHOR, 1)
    if CALL + ANCHOR not in source:
        raise ValueError('Reference initialization must directly precede event preparation')
    compile(source, 'runtime_controller.py', 'exec')
    return source


def install(bundle, root):
    root = Path(root).resolve()
    if root.name != 'hybrid_artifact' or set(bundle) != FILES:
        raise ValueError('Unexpected project or payload')
    spec = importlib.util.spec_from_file_location('prior_safety', root / 'scripts/install_runtime_safety.py')
    prior = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prior)
    if prior.active_collectors(root):
        raise RuntimeError('Active collection; no files modified')
    changed, original, prepared = [], {}, dict(bundle)
    runtime = 'flexbid_hybrid/runtime_controller.py'
    prepared[runtime] = patch_runtime((root / runtime).read_text(encoding='utf-8'))
    for name, text in prepared.items():
        path = root / name
        if path.is_symlink() or root not in path.resolve().parents:
            raise ValueError('Unsafe target')
        original[name] = path.read_bytes() if path.exists() else None
        if name != runtime and original[name] is not None:
            if original[name].decode().replace('\r\n', '\n') != text:
                raise ValueError('Existing module differs: ' + name)
        compile(text, name, 'exec')
    backup = root / 'results/patch_backups' / ('zero_bid_reference_' +
        datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid.uuid4().hex[:8])
    for name, data in original.items():
        if data is not None:
            saved = backup / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(data)
    try:
        for name, text in prepared.items():
            path = root / name
            if (path.read_bytes() if path.exists() else None) != original[name]:
                raise RuntimeError('Concurrent file change')
            if original[name] != text.encode():
                changed.append(name)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(text, encoding='utf-8', newline='\n')
        subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-q'],
            cwd=root, env={**os.environ, 'PYTHONPATH': str(root), 'PYTHONDONTWRITEBYTECODE': '1'}, check=True)
    except BaseException:
        for name in reversed(changed):
            path = root / name
            if original[name] is None:
                path.unlink()
            else:
                path.write_bytes(original[name])
        raise
    print('ZERO_BID_REFERENCE_READY; BACKUP=' + str(backup))


if __name__ == '__main__':
    install(BUNDLE, Path.cwd())
