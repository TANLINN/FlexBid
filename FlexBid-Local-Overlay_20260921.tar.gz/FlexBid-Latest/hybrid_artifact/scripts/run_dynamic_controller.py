#!/usr/bin/env python3
"""Attach the deployable FlexBid MPC controller to a running gateway."""

from __future__ import annotations

import argparse
from pathlib import Path
from statistics import mean
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flexbid_hybrid.config import load_config, resolve
from flexbid_hybrid.contracts import FlexibilityContract
from flexbid_hybrid.adaptive_model import AdaptiveEnvelopeModel
from flexbid_hybrid.modeling import HybridSurrogate, read_csv
from flexbid_hybrid.mpc import (
    MPCParameters,
    ViabilityMPC,
    build_action_lattice,
)
from flexbid_hybrid.runtime_controller import DynamicControlLoop
from flexbid_hybrid.trajectory_calibration import FrozenPolicyCalibrator


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--source", required=True)
    parser.add_argument("--event-s", type=float)
    parser.add_argument("--deadline-s", type=float)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--activation-wall-ns", type=int)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    root = ROOT
    config = load_config(args.config)
    dynamic = config["dynamic_controller"]
    actions = build_action_lattice(dynamic["action_lattice"])
    frozen_model = HybridSurrogate.load(resolve(root, dynamic["surrogate_model"]))
    if (
        bool(dynamic.get("require_explicit_action_support", True))
        and not getattr(frozen_model, "supported_actions", ())
    ):
        parser.error(
            "surrogate predates explicit action-support tracking; re-run "
            "fit_hybrid_surrogate.py before live deployment"
        )
    model = (
        AdaptiveEnvelopeModel(frozen_model)
        if bool(dynamic.get("online_residual_adaptation", True))
        else frozen_model
    )
    parameters = MPCParameters(
        control_period_s=float(dynamic.get("control_period_s", 10.0)),
        calibration_mode=str(dynamic.get("calibration_mode", "episode")),
        debt_quantum_tokens=float(dynamic.get("debt_quantum_tokens", 1024.0)),
        terminal_tolerance_tokens=float(
            dynamic.get("terminal_tolerance_tokens", 1024.0)
        ),
        switch_penalty=float(dynamic.get("switch_penalty", 25.0)),
        recovery_power_weight=float(
            dynamic.get("recovery_power_weight", 0.02)
        ),
        recovery_service_credit=float(
            dynamic.get("recovery_service_credit", 0.001)
        ),
        maximum_states_per_step=int(
            dynamic.get("maximum_states_per_step", 20_000)
        ),
        replica_min_dwell_s=float(dynamic.get("replica_min_dwell_s", 120.0)),
        solve_budget_s=float(dynamic.get("solve_budget_s", 10.0)),
        terminal_cohort_tolerance_tokens=float(
            dynamic.get("terminal_cohort_tolerance_tokens", 1024.0)
        ),
        debt_penalty=float(dynamic.get("debt_penalty", 0.001)),
        slo_risk_penalty=float(dynamic.get("slo_risk_penalty", 1.0)),
    )
    from flexbid_hybrid.continuation import GuardedViabilityMPC
    from flexbid_hybrid.deployment import bind_live_model
    model = bind_live_model(model, frozen_model, config, root, args.source, offline=args.dry_run)
    optimizer = GuardedViabilityMPC(model, actions, parameters)
    solver_engine = str(dynamic.get("solver_engine", "discrete_dp"))
    if solver_engine == "frontier":
        from flexbid_hybrid.frontier_controller import FrontierGuardedViabilityMPC
        optimizer = FrontierGuardedViabilityMPC(model, actions, parameters)
    elif solver_engine != "discrete_dp":
        parser.error(f"unknown solver_engine: {solver_engine}")
    source = args.source
    baseline_by_source = dynamic.get("baseline_batch_tps_by_source", {})
    if source in baseline_by_source:
        baseline_batch_tps = float(baseline_by_source[source])
    else:
        dataset = read_csv(resolve(root, dynamic["baseline_dataset"]))
        values = [
            float(row["batch_tokens_per_s"])
            for row in dataset
            if str(row.get("source")) == source
            and str(row.get("name")) == "hybrid_full"
            and bool(row.get("slo_safe", True))
        ]
        if not values:
            parser.error(f"no safe baseline throughput evidence for source: {source}")
        baseline_batch_tps = mean(values)
    slos = (
        config["slos"]["agentic"] if source == "tracelab"
        else config["slos"]["default"]
    )
    results = (
        args.output_dir.resolve()
        if args.output_dir is not None
        else resolve(root, dynamic["runtime_results"])
    )
    event_s = float(args.event_s or dynamic["event_s"])
    deadline_s = float(args.deadline_s or dynamic["deadline_s"])
    contract = FlexibilityContract.from_mapping(
        dynamic.get("ems_contract", {}),
        event_s=event_s,
        deadline_s=deadline_s,
    )
    calibrator = None
    if dynamic.get("trajectory_calibration"):
        if str(dynamic.get("calibration_mode", "none")) != "none":
            parser.error(
                "trajectory calibration requires calibration_mode=none; "
                "otherwise calibration data would be applied twice"
            )
        calibration_path = resolve(root, dynamic["trajectory_calibration"])
        import json
        calibrator = FrozenPolicyCalibrator.from_dict(json.loads(
            calibration_path.read_text(encoding="utf-8")
        ))
    loop = DynamicControlLoop(
        optimizer=optimizer,
        actions=actions,
        source=source,
        gateway_url=f"http://127.0.0.1:{config['runtime']['gateway_port']}",
        control_file=Path(config["hardware"]["control_file"]),
        gpu_indices=config["hardware"]["gpu_indices"],
        replica_count=len(config["model"]["replicas"]),
        online_concurrency=int(config["runtime"]["online_concurrency"]),
        event_s=event_s,
        deadline_s=deadline_s,
        baseline_batch_tps=baseline_batch_tps,
        batch_output_tokens=int(config["workloads"]["batch_output_tokens"]),
        ttft_slo_ms=float(slos["ttft_ms"]),
        tpot_slo_ms=float(slos["tpot_ms"]),
        log_path=results / f"{source}_controller.jsonl",
        state_path=results / f"{source}_latest.json",
        feature_window_s=float(dynamic.get("feature_window_s", 60.0)),
        feature_projection_s=float(
            dynamic.get("feature_projection_s", 180.0)
        ),
        warmup_s=float(dynamic.get("warmup_s", 120.0)),
        minimum_warmup_online_samples=int(
            dynamic.get("minimum_warmup_online_samples", 1)
        ),
        baseline_sample_s=(
            None if dynamic.get("baseline_sample_s") is None
            else float(dynamic["baseline_sample_s"])
        ),
        baseline_tail_s=(
            None if dynamic.get("baseline_tail_s") is None
            else float(dynamic["baseline_tail_s"])
        ),
        bid_quantum_w=float(dynamic.get("bid_quantum_w", 10.0)),
        bid_derating=float(dynamic.get("bid_derating", 0.95)),
        contract=contract,
        initial_cohort_tokens=float(dynamic.get(
            "initial_cohort_tokens", baseline_batch_tps * deadline_s
        )),
        offer_calibrator=calibrator,
        force_baseline=bool(dynamic.get("force_baseline", False)),
        offer_lead_s=float(dynamic.get("offer_lead_s", 30.0)),
        activation_wall_ns=args.activation_wall_ns,
        meter_sample_s=float(dynamic.get("meter_sample_s", 0.2)),
        meter_max_gap_s=float(dynamic.get("meter_max_gap_s", 1.0)),
        dry_run=args.dry_run,
    )
    from flexbid_hybrid.development_episode import configure_development_episode
    configure_development_episode(loop, config)
    loop.run()


if __name__ == "__main__":
    main()
