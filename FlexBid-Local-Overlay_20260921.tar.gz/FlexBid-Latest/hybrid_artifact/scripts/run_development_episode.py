#!/usr/bin/env python3
"""One reused development trajectory with real MPC; no external commitment."""
import argparse
from collections import Counter
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from flexbid_hybrid.analysis import percentile
from flexbid_hybrid.config import load_config, resolve
from flexbid_hybrid.deployment import sha256_file
from flexbid_hybrid.development_episode import SCHEMA, EPISODE, MODEL_SHA, DATASET_SHA
from flexbid_hybrid.development_trace import extend_development_trace
from flexbid_hybrid.io import atomic_json
from flexbid_hybrid.pilot import select_episodes

CANDIDATE = 'results/historical_gpu_rebuild_v2_20260830_161733_445061'


def prepare(root, source, output):
    import yaml
    config = load_config(source)
    d = config['dynamic_controller']
    if d.get('force_baseline') is not True:
        raise ValueError('Expected restored force-baseline input config')
    episodes = [e for e in select_episodes(root, config) if e['episode_id'] == EPISODE]
    if len(episodes) != 1:
        raise ValueError('Expected exactly the specified reused development trace')
    episode = episodes[0]
    if config['hardware']['gpu_indices'] != list(range(8)) or config['model']['replicas'] != [[0,1],[2,3],[4,5],[6,7]]:
        raise ValueError('This diagnostic requires the current eight-GPU/four-TP2 layout')
    model = root / CANDIDATE / 'historical_gpu_surrogate.joblib'
    dataset = root / CANDIDATE / 'gpu_paired_dataset.csv'
    if sha256_file(model) != MODEL_SHA or sha256_file(dataset) != DATASET_SHA:
        raise ValueError('Historical candidate/dataset identities differ; no GPU launch')
    lattice = d['action_lattice']
    if (lattice['online_replicas'] != [2,3,4] or lattice['batch_concurrency'] != [0,1,2,4,5,6]
            or lattice['power_cap_w'] != [300,400]
            or lattice['baseline'] != dict(online_replicas=4, batch_concurrency=4, power_cap_w=400)):
        raise ValueError('Unexpected action lattice; no fixed-action replacement is allowed')
    d.update(force_baseline=False, deployment_mode='development', allow_unvalidated_development=True,
        external_commitments_enabled=False, calibration_mode='none', trajectory_calibration=None,
        online_residual_adaptation=False, deployment_evidence=None,
        solver_engine='frontier', baseline_sample_s=1., baseline_tail_s=30.,
        development_episode=dict(schema=SCHEMA, diagnostic_reference_only=True),
        surrogate_model=str(model), baseline_dataset=str(dataset), runtime_results=str(output),
        warmup_s=120., offer_lead_s=30., event_s=300., deadline_s=1800., control_period_s=30.,
        meter_sample_s=.2, meter_max_gap_s=1.)
    d.pop('initial_cohort_tokens', None)
    d.pop('baseline_batch_tps_by_source', None)  # record/use historical dataset, no hidden fixed override
    contract = dict(d.get('ems_contract', {}))
    contract.update(event_s=300., deadline_s=1800., settlement_interval_s=30., trajectory_step_s=30.,
                    reference_power_w=[])
    d['ems_contract'] = contract  # preserve configured ramp/rebound/recovery constraints
    scale = float(config['workloads']['arrival_scale_by_source'][episode['source']])
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError('Invalid trace time scaling')
    episode, trace_audit = extend_development_trace(root, episode, output, scale)
    arrivals = [float(json.loads(line)['arrival_ms']) * scale / 1000
                for line in Path(episode['path']).read_text().splitlines() if line.strip()]
    bins = [(0,120), (120,150), (150,450), (450,950), (950,1450), (1450,1950)]
    counts = [sum(a <= t < b for t in arrivals) for a,b in bins]
    if (not arrivals or any(not math.isfinite(t) or t < 0 for t in arrivals)
            or trace_audit['replay_coverage_end_s'] != 1950 or not all(counts)):
        raise ValueError('Insufficient genuine online trace coverage for the complete 1950-second replay')
    manifest = output / 'diagnostic_manifest.json'
    atomic_json(manifest, {'episodes': [episode]})
    config['workloads'].update(manifest=str(manifest), sources=[episode['source']],
        episode_selections=[dict(source=episode['source'], split=episode['split'], count=1, offset=0)],
        test_episodes_per_source=1, measurement_s=1950.)
    # Static preflight uses this baseline; the dynamic runner uses the full lattice above.
    config['actions'] = [dict(name='hybrid_full', online_replicas=4, batch_concurrency=4, power_cap_w=400.)]
    config['hardware']['control_file'] = str(output / 'control.json')
    config.setdefault('paths', {})['results_root'] = str(output)
    config['experiment_name'] = output.name
    path = output / 'diagnostic_config.yaml'
    path.write_text(yaml.safe_dump(config, sort_keys=False), encoding='utf-8')
    if len(select_episodes(root, config)) != 1:
        raise ValueError('Exactly one diagnostic cell required')
    atomic_json(output / 'DIAGNOSTIC_PLAN.json', dict(schema=SCHEMA, expected_cells=1, episode=episode,
        reused_development_trace=True, confirmatory=False, warmup_s=120, offer_lead_s=30,
        baseline_sample_s=1, baseline_tail_s=30, solver_engine='frontier',
        event_s=300, deadline_from_activation_s=1800, workload_seconds=1950,
        phase_request_counts=counts, fixed_bid_w=None, fixed_event_action=None,
        trace_extension_audit=str(output/'TRACE_EXTENSION_AUDIT.json'),
        policy='frontier rolling-horizon MPC with existing schedule validation',
        reference='causal current-host warmup-tail GPU mean; diagnostic only',
        model_sha256=MODEL_SHA, dataset_sha256=DATASET_SHA, config_sha256=sha256_file(path),
        source_config_sha256=sha256_file(source), trace_sha256=sha256_file(Path(episode['path'])),
        source_config=str(source), source_model=str(model),
        external_commitments_enabled=False, deployment_authorized=False,
        no_automatic_retry=True, no_retention=True))
    return path


def read_lines(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def performance_report(output):
    markers = list((output / 'cells').glob('*/CELL_COMPLETE.json'))
    if len(markers) != 1 or list((output / 'cells').rglob('CELL_FAILED.json')):
        raise ValueError('Need one complete cell with no conflicting failure markers')
    cell = markers[0].parent
    marker = json.loads(markers[0].read_text())
    metadata = json.loads((cell / 'cell.json').read_text())
    provenance = json.loads((cell / 'DEVELOPMENT_REFERENCE.json').read_text())
    paths = list(cell.glob('event_protocol_*.json'))
    controllers = list(cell.glob('*_controller.jsonl'))
    if len(paths) != 1 or len(controllers) != 1:
        raise ValueError('Ambiguous current-run logs')
    event = json.loads(paths[0].read_text())
    rows = read_lines(controllers[0])
    online, batch = read_lines(cell / 'online.jsonl'), read_lines(cell / 'batch.jsonl')
    contract = event['contract']
    start, activation, end = (int(metadata['measurement_start_wall_ns']),
        int(contract['activation_wall_ns']), int(contract['deadline_wall_ns']))
    def batch_tokens(a, b):
        # Count only completed, error-free jobs, never post-deadline drain.
        selected = [r for r in batch if a <= int(r['completion_wall_time_ns']) < b and r.get('error') is None]
        tokens = [float(r['completion_tokens']) for r in selected]
        if any(not math.isfinite(t) or t < 0 or not t.is_integer() for t in tokens):
            raise ValueError('Invalid actual batch token count')
        return sum(tokens)
    actual_tokens = batch_tokens(activation, end)
    warmup_tps = batch_tokens(start, start + 120_000_000_000) / 120
    target = float(provenance['initial_cohort_tokens'])
    baseline_tps = float(provenance['baseline_batch_tps_used'])
    cfg = load_config(output / 'diagnostic_config.yaml')
    environment_path = output / 'ENVIRONMENT_OBSERVED_NOT_VALIDATED.json'
    topology_audit = (json.loads(environment_path.read_text()).get('topology_observation')
                      if environment_path.exists() else None)
    slos = cfg['slos']['default']
    latency = {}
    for label, a, b in [('warmup', start, activation), ('event', activation, activation + 300_000_000_000),
                        ('recovery', activation + 300_000_000_000, end)]:
        selected = [r for r in online if a <= int(r['dispatch_wall_time_ns']) < b]
        good = [r for r in selected if r.get('error') is None]
        ttft = [float(r['ttft_ms']) for r in good if r.get('ttft_ms') is not None]
        tpot = [float(r['mean_tpot_ms']) for r in good if r.get('mean_tpot_ms') is not None]
        if any(not math.isfinite(t) or t < 0 for t in ttft + tpot):
            raise ValueError('Invalid latency observation')
        p95, p99 = (percentile(ttft, .95) if ttft else None, percentile(tpot, .99) if tpot else None)
        latency[label] = dict(requests=len(selected), errors=len(selected)-len(good),
            ttft_samples=len(ttft), tpot_samples=len(tpot), ttft_p95_ms=p95, tpot_p99_ms=p99,
            empirical_slo_safe=(p95 <= slos['ttft_ms'] and p99 <= slos['tpot_ms']
                and len(selected) == len(good)) if p95 is not None and p99 is not None else None)
    actions, event_actions, reasons = Counter(), Counter(), Counter()
    caps_match = True
    solve_times = []
    for row in rows:
        action = row['actuation']['control']['action']
        key = f"R{action['online_replicas']}/C{action['batch_concurrency']}/P{action['power_cap_w']:g}"
        actions[key] += 1
        caps = row['actuation'].get('enforced_caps_w') or {}
        caps_match &= (set(map(str,caps)) == set(map(str,range(8))) and
            all(math.isfinite(float(v)) and abs(float(v)-float(action['power_cap_w'])) <= .6 for v in caps.values()))
        plan = row.get('plan', {})
        reasons[str(plan.get('controller_status', plan.get('reason','UNRECORDED')))] += 1
        if plan.get('solve_time_ms') is not None:
            value = float(plan['solve_time_ms'])
            if not math.isfinite(value) or value < 0:
                raise ValueError('Invalid solver timing')
            solve_times.append(value)
        if float(row['observation']['elapsed_s']) < 300:
            event_actions[key] += 1
    checks = dict(protocol_complete=marker.get('event_protocol_complete') is True,
        processes_succeeded=all(marker.get(k) == 0 for k in ('controller_return_code','online_return_code','batch_return_code')),
        one_current_episode=metadata['episode']['episode_id'] == EPISODE,
        reference_frozen_before_activation=provenance['frozen_wall_ns'] < activation,
        ten_meter_windows=len(event['windows']) == 10,
        coverage=event.get('meter_error') is None and all(r['coverage_complete'] for r in event['windows']),
        real_actuation=bool(rows) and all(r['actuation'].get('dry_run') is False for r in rows),
        enforced_eight_gpu_caps_match=bool(rows) and caps_match,
        controller_clock_monotonic=bool(rows) and all(float(b['observation']['elapsed_s']) > float(a['observation']['elapsed_s']) for a,b in zip(rows,rows[1:])),
        no_request_errors=bool(online) and bool(batch) and all(r.get('error') is None for r in online+batch),
        diagnostic_only=provenance['diagnostic_reference_only'] is True and provenance['external_commitments_enabled'] is False)
    local_accepted = contract['accepted'] is True
    result = dict(status=('DEVELOPMENT_PIPELINE_FAILED' if not all(checks.values()) else
        'DEVELOPMENT_ABSTAINED_NO_CURTAILMENT_VALIDATION' if not local_accepted else 'DEVELOPMENT_EPISODE_MEASURED_NOT_CERTIFIED'),
        checks=checks, local_experimental_bid_w=contract['committed_bid_w'],
        local_experimental_offer_accepted=local_accepted, offer_reason=contract['reason'],
        action_counts=dict(actions), event_action_counts=dict(event_actions),
        controller_status_counts=dict(reasons),
        solve_time_ms_mean=sum(solve_times)/len(solve_times) if solve_times else None,
        solve_time_ms_max=max(solve_times) if solve_times else None,
        nonbaseline_actuation_records=sum(v for k,v in actions.items() if k != 'R4/C4/P400'),
        diagnostic_reference_power_w=provenance['reference_power_w'],
        diagnostic_interval_reduction_w=[w['delivered_mean_w'] for w in event['windows']],
        diagnostic_underfilled_windows=sum(w['status'] == 'UNDERDELIVERED' for w in event['windows']),
        empirical_latency_by_dispatch_phase=latency,
        historical_baseline_batch_tps_used=baseline_tps, measured_warmup_completed_batch_tps=warmup_tps,
        completed_batch_tokens_activation_to_deadline=actual_tokens,
        configured_cohort_target_tokens=target, configured_cohort_token_deficit=max(0, target-actual_tokens),
        nominal_service_debt_at_deadline_tokens=max(0, baseline_tps*1800-actual_tokens),
        controller_last_observation=rows[-1]['observation'] if rows else None,
        deadline_note='Counts are diagnostic: historical TPS defines synthetic cohort; no per-job deadline certificate.',
        deployment_authorized=False, target_environment_validated=False,
        environment_topology_observation=topology_audit,
        external_delivery_verified=False, statistical_safety_verified=False)
    atomic_json(output / 'DEVELOPMENT_REPORT.json', result)
    print(json.dumps(result, indent=2), flush=True)
    if not all(checks.values()):
        raise ValueError('Development pipeline integrity checks failed; preserve evidence')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path, required=True)
    parser.add_argument('--audit-only', action='store_true')
    args = parser.parse_args()
    output = args.output_root.resolve()
    if args.audit_only:
        performance_report(output)
        return
    import fcntl
    from install_runtime_safety import active_collectors
    with (ROOT / 'results/development_episode.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if active_collectors(ROOT):
            raise RuntimeError('Active workload; no new collection started')
        if (output / 'DIAGNOSTIC_PLAN.json').exists() or (output / 'cells').exists():
            raise ValueError('Fresh output directory required; old results remain unchanged')
        output.mkdir(parents=True, exist_ok=True)
        (output / 'launcher.pid').write_text(str(os.getpid())+'\n')
        env = {**os.environ, 'PYTHONPATH': str(ROOT)+os.pathsep+os.environ.get('PYTHONPATH',''),
               'PATH': str(Path(sys.executable).parent)+os.pathsep+os.environ.get('PATH','')}
        try:
            path = prepare(ROOT, ROOT / 'configs/generated/a800_8gpu_qwen35_27b_dynamic_reference_baseline.yaml', output)
            print('ONE DEVELOPMENT CELL: 1950 s workload plus startup/drain; raw MPC; NO external commitments', flush=True)
            subprocess.run([sys.executable,'-B','-c',
                'import vllm; import sys; from pathlib import Path; '
                'from flexbid_hybrid.modeling import HybridSurrogate; '
                'm=HybridSurrogate.load(Path(sys.argv[1])); '
                'assert m.power_boundary == "gpu_nvml"; print("GPU_MODEL_IMPORT_OK")',
                str(ROOT / CANDIDATE / 'historical_gpu_surrogate.joblib')], cwd=ROOT, env=env, check=True)
            subprocess.run([sys.executable,'-B','scripts/preflight.py','--config',str(path),
                '--output',str(output / 'preflight.json')], cwd=ROOT, env=env, check=True)
            from flexbid_hybrid.deployment import observe_environment
            atomic_json(output / 'ENVIRONMENT_OBSERVED_NOT_VALIDATED.json',
                        observe_environment(load_config(path), ROOT, diagnostic_topology=True))
            subprocess.run([sys.executable,'-B','-u','scripts/run_dynamic_policy_selection.py',
                '--config',str(path),'--output-root',str(output)], cwd=ROOT, env=env, check=True)
            performance_report(output)
        except BaseException as exc:
            atomic_json(output / 'DEVELOPMENT_FAILED.json', dict(error=repr(exc), no_automatic_retry=True,
                instruction='Preserve logs; do not restart or clean unrelated processes'))
            raise


if __name__ == '__main__':
    main()
