#!/usr/bin/env bash
set +e

ROOT=/root/workspace/FlexBid-LLM/hybrid_artifact
R=results/hybrid_dynamic_trajectory_calibration_raw_a800_qwen35_27b_20260828
TOTAL=20

EVENTS="$R/logs/retention_guard.events.log"
WORKERS="$R/retention_50_workers.pids"

cd "$ROOT" || return 1
mkdir -p "$R/logs"

if [ -x /root/workspace/FlexBid-LLM/.venv/bin/python ]; then
    PY=/root/workspace/FlexBid-LLM/.venv/bin/python
elif [ -x /opt/conda/bin/python ]; then
    PY=/opt/conda/bin/python
else
    PY="$(command -v python3)"
fi

log_event() {
    echo "$(date '+%F %T %Z') $*" >> "$EVENTS"
}

cleanup() {
    if [ -f "$WORKERS" ]; then
        while read -r gpu pid
        do
            [ -n "$pid" ] || continue
            cmd="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null)"
            case "$cmd" in
                *gpu_retention_50.py*)
                    kill -TERM "$pid" 2>/dev/null
                    ;;
            esac
        done < "$WORKERS"
    fi

    log_event "guard stopped; tracked workers terminated"
}

trap cleanup EXIT INT TERM

log_event "trajectory retention guard started"

while true
do
    completed=$(
        find "$R/cells" -type f \
            -name CELL_COMPLETE.json 2>/dev/null |
        wc -l
    )

    collector=$(
        pgrep -af \
          '[r]un_dynamic_policy_selection.py' |
        wc -l
    )

    workloads=$(
        pgrep -af \
          '[v]llm serve|[r]eplay_online.py|[r]un_batch.py' |
        wc -l
    )

    if [ "$collector" -gt 0 ] || [ "$workloads" -gt 0 ]; then
        sleep 30
        continue
    fi

    if [ "$completed" -ge "$TOTAL" ]; then
        log_event "collection complete $completed/$TOTAL; starting 50-percent retention"
    else
        log_event "collection stopped at $completed/$TOTAL; starting 50-percent retention"
    fi

    : > "$WORKERS"

    for gpu in 0 1 2 3 4 5 6 7
    do
        nvidia-smi -i "$gpu" -pl 400 \
            >> "$EVENTS" 2>&1

        nohup env CUDA_VISIBLE_DEVICES="$gpu" \
            "$PY" -u scripts/gpu_retention_50.py \
            --busy-s 1.0 \
            --idle-s 1.0 \
            > "$R/logs/retention_50_gpu_${gpu}.log" \
            2>&1 &

        pid=$!
        echo "$gpu $pid" >> "$WORKERS"
        log_event "retention gpu=$gpu pid=$pid"
    done

    log_event "all tracked retention workers started"
    wait
    log_event "all retention workers exited"
    break
done
