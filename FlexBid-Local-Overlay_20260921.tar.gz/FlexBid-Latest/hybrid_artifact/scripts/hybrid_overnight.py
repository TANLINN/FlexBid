#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/root/workspace/FlexBid-LLM/hybrid_artifact")
CONFIG = ROOT / "configs/a800_8gpu_qwen35_27b_pilot.yaml"
RESULT = ROOT / "results/hybrid_physical_gate_a800_qwen35_27b"
EVENTS = RESULT / "logs/night_guard.log"


def stamp() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def log(message: str) -> None:
    EVENTS.parent.mkdir(parents=True, exist_ok=True)
    with EVENTS.open("a", encoding="utf-8") as stream:
        stream.write(f"{stamp()} {message}\n")


def restore_caps() -> None:
    for gpu in range(8):
        query = subprocess.run([
            "nvidia-smi", "-i", str(gpu), "--query-gpu=power.default_limit",
            "--format=csv,noheader,nounits",
        ], text=True, capture_output=True, check=False)
        if query.returncode == 0 and query.stdout.strip():
            subprocess.run([
                "nvidia-smi", "-i", str(gpu), "-pl",
                query.stdout.splitlines()[0].strip(),
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)


def progress_count() -> int:
    cells = RESULT / "cells"
    if not cells.exists():
        return 0
    return sum(1 for path in cells.glob("*/*/*")
               if path.name in {"CELL_COMPLETE.json", "CELL_FAILED.json"})


def failed_cells() -> list[Path]:
    return sorted((RESULT / "cells").glob("*/*/CELL_FAILED.json"))


def collect_once() -> None:
    from flexbid_hybrid.config import load_config, resolve
    from flexbid_hybrid.io import atomic_json
    import flexbid_hybrid.pilot as pilot

    config = load_config(CONFIG)
    results = resolve(ROOT, config["paths"]["results_root"])
    original_run_cell = pilot.run_cell

    def resumable_marker_valid(run_dir: Path) -> bool:
        if (run_dir / "CELL_FAILED.json").exists():
            return True
        try:
            marker = json.loads(
                (run_dir / "CELL_COMPLETE.json").read_text(encoding="utf-8")
            )
            fatal_online = marker.get("fatal_online_errors")
            if fatal_online is None:
                fatal_online = max(
                    0,
                    int(marker.get("online_errors", 0))
                    - int(marker.get("online_load_shed", 0)),
                )
            return (
                marker["online_return_code"] == 0
                and marker["batch_return_code"] == 0
                and fatal_online == 0
                and int(marker.get("fatal_batch_errors", 0)) == 0
                and int(marker["telemetry_rows"]) >= 2
            )
        except (OSError, KeyError, TypeError, ValueError, json.JSONDecodeError):
            return False

    def resilient_run_cell(root: Path, config: dict, services, action,
                           episode: dict, run_dir: Path) -> None:
        if (run_dir / "CELL_FAILED.json").exists():
            return
        try:
            original_run_cell(root, config, services, action, episode, run_dir)
        except BaseException as exc:
            atomic_json(run_dir / "CELL_FAILED.json", {
                "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                "episode_id": episode.get("episode_id"),
                "source": episode.get("source"),
                "action": action.as_dict(),
                "exception_type": type(exc).__name__,
                "exception": str(exc),
                "traceback": traceback.format_exc(),
                "services_alive": all(process.poll() is None
                                      for process in services.processes),
            })
            raise

    pilot.marker_valid = resumable_marker_valid
    pilot.run_cell = resilient_run_cell
    pilot.run_pilot(ROOT, CONFIG, config, resume=True)
    failures = [str(path.parent.relative_to(results)) for path in failed_cells()]
    atomic_json(results / "NIGHT_COLLECTION_COMPLETE.json", {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "failed_count": len(failures),
        "failed_cells": failures,
    })


WORKER_CODE = r'''import time
import torch
x=torch.randn((4096,4096),device="cuda",dtype=torch.float16)
y=torch.randn_like(x)
z=torch.empty_like(x)
while True:
    end=time.monotonic()+1.0
    while time.monotonic()<end:
        torch.mm(x,y,out=z)
        torch.cuda.synchronize()
        x,z=z,x
    time.sleep(2.0)
'''


def retain_gpus() -> None:
    restore_caps()
    workers: dict[int, subprocess.Popen] = {}

    def start(gpu: int) -> subprocess.Popen:
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(gpu)
        handle = (RESULT / "logs" / f"retention_gpu_{gpu}.log").open(
            "a", encoding="utf-8"
        )
        return subprocess.Popen(
            [sys.executable, "-c", WORKER_CODE], cwd=ROOT, env=env,
            stdout=handle, stderr=subprocess.STDOUT, start_new_session=True,
        )

    def save_pids() -> None:
        (RESULT / "retention_worker.pids").write_text(
            "".join(f"{workers[gpu].pid}\n" for gpu in range(8)),
            encoding="utf-8",
        )

    def stop(*_args) -> None:
        for process in workers.values():
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        raise SystemExit(0)

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    for gpu in range(8):
        workers[gpu] = start(gpu)
    save_pids()
    log("duty-cycled GPU retention started")
    while True:
        time.sleep(30)
        for gpu, process in list(workers.items()):
            if process.poll() is not None:
                log(f"restarting retention worker gpu={gpu} rc={process.returncode}")
                workers[gpu] = start(gpu)
        save_pids()


def supervise() -> None:
    os.chdir(ROOT)
    log("resilient overnight collection started")
    stagnant = 0
    attempt = 0
    while stagnant < 3:
        attempt += 1
        before = progress_count()
        log(f"attempt={attempt} progress_before={before}")
        with (RESULT / "logs/resilient_pilot.log").open("a", encoding="utf-8") as log_file:
            run = subprocess.run(
                [sys.executable, str(Path(__file__).resolve()), "--collect-once"],
                cwd=ROOT, stdout=log_file, stderr=subprocess.STDOUT, check=False,
            )
        restore_caps()
        after = progress_count()
        log(f"attempt={attempt} rc={run.returncode} progress_after={after}")
        if run.returncode == 0:
            break
        stagnant = 0 if after > before else stagnant + 1
        time.sleep(10)

    complete = len(list((RESULT / "cells").glob("*/*/CELL_COMPLETE.json")))
    failures = failed_cells()
    log(f"collection ended complete={complete} failed={len(failures)} stagnant={stagnant}")
    if (RESULT / "NIGHT_COLLECTION_COMPLETE.json").exists() and not failures:
        with (RESULT / "logs/analysis.log").open("a", encoding="utf-8") as output:
            analysis = subprocess.run([
                sys.executable, "scripts/analyze_physical_pilot.py",
                "--config", str(CONFIG),
            ], cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=False)
        if analysis.returncode == 0:
            gate = json.loads((RESULT / "PHYSICAL_GATE.json").read_text(encoding="utf-8"))
            (RESULT / "PIPELINE_COMPLETE").write_text(
                str(gate["status"]) + "\n", encoding="utf-8"
            )
    retain_gpus()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--collect-once", action="store_true")
    arguments = parser.parse_args()
    if arguments.collect_once:
        collect_once()
    else:
        supervise()
