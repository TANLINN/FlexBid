#!/usr/bin/env python3
"""One CPU-only MPC probe. Old post-activation observations are explicitly proxies."""
import argparse
import ast
from dataclasses import asdict, replace
import json
import math
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from flexbid_hybrid.config import load_config, resolve
from flexbid_hybrid.contracts import FlexibilityContract
from flexbid_hybrid.deployment import DevelopmentModel, sha256_file
from flexbid_hybrid.development_episode import MODEL_SHA, DATASET_SHA, EPISODE
from flexbid_hybrid.io import atomic_json
from flexbid_hybrid.modeling import HybridSurrogate
from flexbid_hybrid.mpc import ControlState, MPCParameters, build_action_lattice, _row
from flexbid_hybrid.offer_diagnostics import ObservedCPUOptimizer, classify_result


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def one(paths, label):
    values = list(paths)
    if len(values) != 1:
        raise ValueError(f'Need exactly one {label}; found {len(values)}')
    return values[0]


def runner_parameters(source, dynamic):
    """Read the actual runner's simple parameter literals; never execute its main."""
    calls = [n for n in ast.walk(ast.parse(source)) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Name) and n.func.id == 'MPCParameters']
    if len(calls) != 1 or calls[0].args:
        raise ValueError('Unknown runner MPCParameters construction')
    values = {}
    converters = {'float': float, 'int': int, 'str': str}
    for keyword in calls[0].keywords:
        call = keyword.value
        if (keyword.arg is None or not isinstance(call, ast.Call)
                or not isinstance(call.func, ast.Name) or call.func.id not in converters
                or len(call.args) != 1 or call.keywords):
            raise ValueError('Unknown runner parameter expression')
        get = call.args[0]
        if (not isinstance(get, ast.Call) or not isinstance(get.func, ast.Attribute)
                or not isinstance(get.func.value, ast.Name) or get.func.value.id != 'dynamic'
                or get.func.attr != 'get' or len(get.args) != 2 or get.keywords
                or ast.literal_eval(get.args[0]) != keyword.arg):
            raise ValueError('Unknown runner parameter lookup')
        default = ast.literal_eval(get.args[1])
        values[keyword.arg] = converters[call.func.id](dynamic.get(keyword.arg, default))
    if set(values) != set(MPCParameters.__dataclass_fields__):
        raise ValueError('Runner/parameter schema differs; no guessed defaults')
    return MPCParameters(**values)


def restore_state(data):
    value = dict(data)
    if value['contract'] is not None:
        contract = dict(value['contract'])
        for name in ('reference_power_w', 'recovery_power_envelope_w'):
            contract[name] = tuple(contract[name])
        value['contract'] = FlexibilityContract(**contract)
    return ControlState(**value)


def proxy_state(config, metadata, reference, first, baseline_action):
    d = config['dynamic_controller']
    source = metadata['episode']['source']
    slos = config['slos']['agentic' if source == 'tracelab' else 'default']
    baseline = first['baseline_reference']
    observation = first['observation']
    contract = FlexibilityContract.from_mapping(d.get('ems_contract', {}),
        event_s=float(d['event_s']), deadline_s=float(d['deadline_s']))
    contract = replace(contract, reference_power_w=(float(reference['reference_power_w']),))
    for key in ('power_mean_w', 'ttft_p95_ms', 'tpot_p99_ms', 'batch_tokens_per_s'):
        if not math.isfinite(float(baseline[key])) or float(baseline[key]) < 0:
            raise ValueError('Invalid saved baseline field: '+key)
    if (not math.isclose(float(baseline['power_mean_w']), reference['reference_power_w'], rel_tol=1e-9)
            or not math.isclose(float(baseline['batch_tokens_per_s']), reference['baseline_batch_tps_used'], rel_tol=1e-9)):
        raise ValueError('Controller and frozen reference disagree')
    return ControlState(source=source, event_remaining_s=float(d['event_s']),
        deadline_remaining_s=float(d['deadline_s']), backlog_tokens=0,
        current_action=baseline_action, ttft_slo_ms=float(slos['ttft_ms']),
        tpot_slo_ms=float(slos['tpot_ms']), workload_features=observation['workload_features'],
        baseline_power_w=float(baseline['power_mean_w']),
        baseline_ttft_ms=float(baseline['ttft_p95_ms']), baseline_tpot_ms=float(baseline['tpot_p99_ms']),
        baseline_batch_tps=float(reference['baseline_batch_tps_used']),
        cohort_remaining_tokens=float(reference['initial_cohort_tokens']), dr_debt_tokens=0,
        contract=contract, previous_power_w=float(observation['observed_component_power_w']))


def diagnose(root, run, output):
    root, run, output = root.resolve(), run.resolve(), output.resolve()
    if output.exists() or run == output or run in output.parents or output in run.parents:
        raise ValueError('Fresh separate diagnostic output required; original results unchanged')
    config_path = run / 'diagnostic_config.yaml'
    config = load_config(config_path)
    d = config['dynamic_controller']
    if (d.get('deployment_mode') != 'development' or d.get('allow_unvalidated_development') is not True
            or d.get('external_commitments_enabled') is not False or d.get('force_baseline') is not False
            or d.get('online_residual_adaptation') is not False or d.get('trajectory_calibration') is not None
            or d.get('calibration_mode') != 'none'):
        raise ValueError('This CPU probe only accepts the unchanged explicit raw development configuration')
    plan = read_json(run / 'DIAGNOSTIC_PLAN.json')
    model_path = resolve(root, d['surrogate_model'])
    dataset_path = resolve(root, d['baseline_dataset'])
    if (sha256_file(config_path) != plan['config_sha256'] or sha256_file(model_path) != MODEL_SHA
            or plan['model_sha256'] != MODEL_SHA or sha256_file(dataset_path) != DATASET_SHA):
        raise ValueError('Config/model/dataset identity mismatch; no substitution or refitting')
    marker_path = one(run.glob('cells/*/CELL_COMPLETE.json'), 'completed cell')
    cell = marker_path.parent
    if list(run.glob('cells/**/CELL_FAILED.json')):
        raise ValueError('Conflicting failed cell marker; inspect before diagnosis')
    metadata = read_json(cell / 'cell.json')
    reference = read_json(cell / 'DEVELOPMENT_REFERENCE.json')
    if (metadata['episode']['episode_id'] != EPISODE or reference['episode_id'] != EPISODE
            or reference['power_boundary'] != 'gpu_nvml'
            or reference['diagnostic_reference_only'] is not True):
        raise ValueError('Unexpected episode or reference boundary')
    runner = root / 'scripts/run_dynamic_controller.py'
    parameters = runner_parameters(runner.read_text(encoding='utf-8'), d)
    actions = build_action_lattice(d['action_lattice'])
    model = HybridSurrogate.load(model_path)
    if getattr(model, 'power_boundary', None) != 'gpu_nvml':
        raise ValueError('GPU boundary required; no model relabeling')
    optimizer = ObservedCPUOptimizer(DevelopmentModel(model), actions, parameters)
    files = list(cell.glob('offer_diagnostic_*.json'))
    sources = [config_path, run/'DIAGNOSTIC_PLAN.json', marker_path, cell/'cell.json', cell/'DEVELOPMENT_REFERENCE.json', runner]
    if files:
        saved = read_json(one(files, 'offer diagnostic'))
        selected = one([r for r in saved['solves'] if r['phase'] == 'initial_offer'], 'initial offer input')
        if (saved['schema'] != 'development_offer_diagnostics_v1' or selected['cached_plan_present']
                or selected['identities']['model_sha256'] != MODEL_SHA
                or selected['parameters'] != asdict(parameters)
                or selected['actions'] != json.loads(json.dumps([a.as_dict() for a in actions]))
                or selected['baseline_action'] != optimizer.baseline_action
                or saved['contract']['activation_wall_ns'] != metadata['activation_wall_ns']):
            raise ValueError('Exact diagnostic identities/parameters/clock differ')
        state = restore_state(selected['state'])
        input_kind = 'EXACT_SAVED_INITIAL_OFFER_INPUT'
        caveats = ['Current CPU timing may differ; exact inputs do not guarantee the same budget-limited search outcome.']
        sources += files
    else:
        controller = one(cell.glob('*_controller.jsonl'), 'controller log')
        rows = [json.loads(line) for line in controller.read_text(encoding='utf-8').splitlines() if line.strip()]
        if (not rows or any(b['observation']['elapsed_s'] <= a['observation']['elapsed_s'] for a,b in zip(rows,rows[1:]))
                or rows[0]['event_contract']['activation_wall_ns'] != metadata['activation_wall_ns']):
            raise ValueError('Ambiguous controller run/clock')
        state = proxy_state(config, metadata, reference, rows[0], optimizer.baseline_action)
        input_kind = 'FIRST_RECORDED_STATE_PROXY_NOT_ORIGINAL_OFFER'
        caveats = ['Original pre-offer features and previous power were not saved and cannot be recovered exactly.',
            'Uses first post-activation workload features/power with the original initial horizon, debt=0 and saved cohort.',
            'Current runner parameters/code are used and hashed; old runtime code identity is not independently verified.',
            'This probe can suggest a cause but does not establish why the historical offer was rejected.']
        sources.append(controller)
    output.mkdir(parents=True, exist_ok=False)
    source_hashes = {str(p): sha256_file(p) for p in sources}
    common = dict(input_kind=input_kind, caveats=caveats, state=asdict(state), parameters=asdict(parameters),
        model_sha256=MODEL_SHA, dataset_sha256=DATASET_SHA, source_files=source_hashes,
        code_sha256={name:sha256_file(root/name) for name in (
            'flexbid_hybrid/mpc.py','flexbid_hybrid/continuation.py','flexbid_hybrid/modeling.py',
            'flexbid_hybrid/gpu_pair_rebuild.py','flexbid_hybrid/offer_diagnostics.py')},
        gpu_workload_started=False, external_delivery_verified=False, deployment_authorized=False)
    atomic_json(output/'INPUT.json', common)
    print('INPUT_KIND =', input_kind, flush=True)
    print('CPU_ONLY: one unchanged-budget solve; no vLLM, telemetry commands or actuation.', flush=True)
    started = time.perf_counter()
    result = optimizer.solve(state)
    elapsed = (time.perf_counter()-started)*1000
    envelopes = optimizer.observed_envelopes[0]
    safe = [e for e in envelopes if e.slo_safe]
    proposal = optimizer.search_proposal
    # Separate post-solve baseline inspection: never fed into the measured search.
    baseline_row = _row(state, optimizer.actions_by_name[optimizer.baseline_action])
    baseline_bounds = asdict(model.bounds(baseline_row, parameters.calibration_mode))
    report = dict(common, status='CPU_DIAGNOSTIC_COMPLETE_NOT_VALIDATION', classification=classify_result(result),
        observed_call_ms=elapsed, supervised_result=result.as_dict(),
        search_proposal=proposal.as_dict() if proposal is not None else None,
        effective_search_parameters=asdict(optimizer.effective_search_parameters) if optimizer.effective_search_parameters else None,
        envelopes=[e.as_dict() for e in envelopes], baseline_bounds=baseline_bounds,
        summary=dict(action_lattice_size=len(actions), returned_envelopes=len(envelopes), slo_safe_actions=len(safe),
            safe_positive_reduction_actions=sum(e.guaranteed_reduction_w>0 for e in safe),
            safe_positive_recovery_surplus_actions=sum(e.batch_tps_lower>state.baseline_batch_tps for e in safe),
            raw_search_reason=proposal.reason if proposal else None,
            continuation_validation_reason=result.validation_reason,
            feasible_under_model=result.feasible, candidate_bid_w=result.committed_bid_w))
    if any(sha256_file(Path(p)) != h for p,h in source_hashes.items()):
        raise ValueError('Input files changed during diagnosis; result not published')
    atomic_json(output/'REPORT.json', report)
    print(json.dumps(dict(input_kind=input_kind, classification=report['classification'],
        **report['summary'], observed_call_ms=elapsed), indent=2), flush=True)
    print('BASELINE_BOUNDS =', json.dumps(baseline_bounds), flush=True)
    print('INPUT_BASELINE_TPS =', state.baseline_batch_tps, 'INITIAL_COHORT_TOKENS =', state.cohort_tokens)
    for e in envelopes:
        print('ACTION', e.action.name, 'slo_safe=', e.slo_safe,
              'reduction_w=', round(e.guaranteed_reduction_w, 3),
              'surplus_tps=', round(e.batch_tps_lower-state.baseline_batch_tps, 3),
              'ttft_ms=', round(e.ttft_upper_ms, 3), 'tpot_ms=', round(e.tpot_upper_ms, 3))
    print('REPORT =', output/'REPORT.json')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-root', type=Path, required=True)
    parser.add_argument('--output-root', type=Path, required=True)
    args = parser.parse_args()
    diagnose(ROOT, args.run_root, args.output_root)


if __name__ == '__main__':
    main()
