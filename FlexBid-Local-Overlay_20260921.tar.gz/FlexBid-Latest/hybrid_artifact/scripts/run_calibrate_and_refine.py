#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import os
import subprocess
import sys
import time
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
BASE_CONFIG = ROOT / "configs/a800_8gpu_qwen35_27b_pilot.yaml"
CAMPAIGN_ROOT = ROOT / "results/hybrid_calibrate_and_refine_a800_qwen35_27b"
LOG_ROOT = CAMPAIGN_ROOT / "logs"
CALIBRATION_GRID = [
    ("c16_v10", 16.0, 10.0),
    ("c32_v12", 32.0, 12.0),
    ("c64_v16", 64.0, 16.0),
]


def atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def restore_caps() -> None:
    for gpu in range(8):
        query = subprocess.run([
            "nvidia-smi", "-i", str(gpu), "--query-gpu=power.default_limit",
            "--format=csv,noheader,nounits",
        ], text=True, capture_output=True, check=False)
        if query.returncode == 0 and query.stdout.strip():
            subprocess.run([
                "nvidia-smi", "-i", str(gpu), "-pl",
                query.stdout.splitlines()[0].strip(),
            ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)


def run_logged(name: str, command: list[str]) -> int:
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    with (LOG_ROOT / f"{name}.log").open("a", encoding="utf-8") as output:
        output.write(f"\n[{datetime.now(timezone.utc).isoformat()}] {command!r}\n")
        output.flush()
        return subprocess.run(
            command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, check=False
        ).returncode


def dump_config(path: Path, config: dict) -> None:
    path.write_text(yaml.safe_dump(config, sort_keys=False), encoding="utf-8")


def experiment(config_path: Path, tag: str) -> dict:
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    result = ROOT / config["paths"]["results_root"]
    result.mkdir(parents=True, exist_ok=True)
    preflight = -1
    for attempt in range(3):
        if attempt:
            time.sleep(30)
        preflight = run_logged(tag + "_preflight", [
            sys.executable, "scripts/preflight.py", "--config", str(config_path),
            "--output", str(result / "preflight.json"),
        ])
        if preflight == 0:
            break
    pilot = -1
    analysis = -1
    if preflight == 0:
        pilot = run_logged(tag + "_pilot", [
            sys.executable, "-u", "scripts/run_physical_pilot.py",
            "--config", str(config_path), "--resume",
        ])
    if pilot == 0:
        analysis = run_logged(tag + "_analysis", [
            sys.executable, "scripts/analyze_physical_pilot.py",
            "--config", str(config_path),
        ])
    return {
        "tag": tag, "config": str(config_path), "result": str(result),
        "preflight_rc": preflight, "pilot_rc": pilot, "analysis_rc": analysis,
    }


def read_summary(result: Path) -> list[dict]:
    path = result / "cell_summary.csv"
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def is_true(value: object) -> bool:
    return str(value).strip().lower() == "true"


def main() -> None:
    os.chdir(ROOT)
    LOG_ROOT.mkdir(parents=True, exist_ok=True)
    base = yaml.safe_load(BASE_CONFIG.read_text(encoding="utf-8"))
    calibration_actions = [
        deepcopy(action) for action in base["actions"]
        if action["name"] in {"hybrid_full", "pause_batch_r4"}
    ]
    statuses = []
    observations: dict[str, list[dict]] = {
        "azure_code": [], "azure_conversation": [],
    }

    try:
        for tag, code_scale, conversation_scale in CALIBRATION_GRID:
            config = deepcopy(base)
            config["seed"] = int(base["seed"]) + len(statuses) + 1
            config["experiment_name"] = f"hybrid_load_calibration_{tag}"
            config["workloads"]["sources"] = ["azure_code", "azure_conversation"]
            config["workloads"]["measurement_s"] = 180
            config["workloads"]["arrival_scale_by_source"]["azure_code"] = code_scale
            config["workloads"]["arrival_scale_by_source"]["azure_conversation"] = conversation_scale
            config["actions"] = deepcopy(calibration_actions)
            config["paths"]["results_root"] = f"results/hybrid_load_calibration_{tag}"
            path = ROOT / "configs" / f"a800_qwen35_27b_load_calibration_{tag}.yaml"
            dump_config(path, config)
            status = experiment(path, tag)
            statuses.append(status)
            if status["analysis_rc"] != 0:
                continue
            for row in read_summary(Path(status["result"])):
                source = row["source"]
                scale = code_scale if source == "azure_code" else conversation_scale
                observations[source].append({
                    "scale": scale,
                    "action": row["name"],
                    "safe": is_true(row["slo_safe"]),
                    "power_mean_w": float(row["power_mean_w"]),
                    "ttft_p95_ms": float(row["ttft_p95_ms"]),
                    "tpot_p99_ms": float(row["tpot_p99_ms"]),
                    "online_errors": int(row["online_errors"]),
                    "online_load_shed": int(row["online_load_shed"]),
                })

        selected = {}
        for source, rows in observations.items():
            by_scale: dict[float, dict[str, dict]] = {}
            for row in rows:
                by_scale.setdefault(row["scale"], {})[row["action"]] = row
            feasible = []
            for scale, actions in by_scale.items():
                baseline = actions.get("hybrid_full")
                pause = actions.get("pause_batch_r4")
                if baseline and pause and baseline["safe"] and pause["safe"]:
                    feasible.append(scale)
            if feasible:
                # Larger arrival_scale means lower offered load. Choose the
                # smallest safe dilation, then reserve 10% rate headroom.
                selected[source] = min(feasible) / 0.9

        calibration_report = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "statuses": statuses,
            "observations": observations,
            "selected_scales_with_10pct_headroom": selected,
        }
        atomic_json(CAMPAIGN_ROOT / "LOAD_CALIBRATION_REPORT.json", calibration_report)

        if set(selected) == {"azure_code", "azure_conversation"}:
            refined = deepcopy(base)
            refined["seed"] = int(base["seed"]) + 100
            refined["experiment_name"] = "hybrid_physical_gate_refined_a800_qwen35_27b"
            refined["workloads"]["arrival_scale_by_source"].update(selected)
            refined["paths"]["results_root"] = (
                "results/hybrid_physical_gate_refined_a800_qwen35_27b"
            )
            refined_path = ROOT / "configs/a800_8gpu_qwen35_27b_refined.yaml"
            dump_config(refined_path, refined)
            refined_status = experiment(refined_path, "refined_gate")
            calibration_report["refined_gate"] = refined_status
            gate_path = Path(refined_status["result"]) / "PHYSICAL_GATE.json"
            if gate_path.exists():
                calibration_report["refined_gate_report"] = json.loads(
                    gate_path.read_text(encoding="utf-8")
                )
            atomic_json(
                CAMPAIGN_ROOT / "CALIBRATE_AND_REFINE_COMPLETE.json",
                calibration_report,
            )
        else:
            calibration_report["blocked"] = "no jointly SLO-safe scale for every Azure source"
            atomic_json(CAMPAIGN_ROOT / "CALIBRATE_AND_REFINE_BLOCKED.json", calibration_report)
    finally:
        restore_caps()

    # Reuse the tested supervisor's retention mode after all measurement work.
    os.execvpe(sys.executable, [
        sys.executable, "-u", "scripts/hybrid_overnight.py",
    ], os.environ | {"PYTHONPATH": str(ROOT)})


if __name__ == "__main__":
    main()
