#!/usr/bin/env python3
"""Collect raw frozen-policy trajectories under the live viability MPC.

This is deliberately separate from the static physical pilot.  Each cell runs
one warm-up, one DR event, and its complete recovery horizon while the
controller re-solves and applies only the first action every control period.
"""

from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from flexbid_hybrid.config import canonical_hash, load_config, resolve
from flexbid_hybrid.io import atomic_json, read_jsonl
from flexbid_hybrid.mpc import build_action_lattice
from flexbid_hybrid.pilot import apply_control, select_episodes
from flexbid_hybrid.power import PowerCapManager
from flexbid_hybrid.service import ServiceGroup, get_json, stop_process


def _cell_name(episode_id: str) -> str:
    return episode_id.replace(":", "_").replace("/", "_")


def _valid(run_dir: Path) -> bool:
    try:
        marker = json.loads(
            (run_dir / "CELL_COMPLETE.json").read_text(encoding="utf-8")
        )
        return (
            marker.get("event_protocol_complete") is True
            and marker["controller_return_code"] == 0
            and marker["online_return_code"] == 0
            and marker["batch_return_code"] == 0
            and marker["controller_records"] >= 2
            and marker["telemetry_rows"] >= 2
            and marker["fatal_online_errors"] == 0
            and marker["fatal_batch_errors"] == 0
        )
    except (OSError, KeyError, TypeError, ValueError):
        return False


def _wait(process: subprocess.Popen, timeout_s: float) -> int:
    try:
        return process.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        stop_process(process)
        return -9


def _read_controller(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [
        json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def run_cell(
    config_path: Path,
    config: dict,
    services: ServiceGroup,
    episode: dict,
    run_dir: Path,
) -> None:
    run_dir.mkdir(parents=True, exist_ok=True)
    services.wait_idle()
    services.reset_caches()
    services.reset_state()

    dynamic = config["dynamic_controller"]
    actions = build_action_lattice(dynamic["action_lattice"])
    baseline = next(action for action in actions if action.name == "hybrid_full")
    apply_control(
        Path(config["hardware"]["control_file"]),
        baseline,
        len(config["model"]["replicas"]),
        int(config["runtime"]["online_concurrency"]),
    )
    get_json(
        f"http://127.0.0.1:{config['runtime']['gateway_port']}/flexbid/state"
    )

    warmup_s = float(dynamic.get("warmup_s", 0.0))
    deadline_s = float(dynamic["deadline_s"])
    # FIXED_EVENT_CLOCK_V1: explicit offer lead is outside the event.
    offer_lead_s = float(dynamic.get("offer_lead_s", 30.0))
    workload_s = warmup_s + offer_lead_s + deadline_s
    start_wall_ns = time.time_ns() + 3_000_000_000
    end_wall_ns = start_wall_ns + int(workload_s * 1e9)
    atomic_json(run_dir / "cell.json", {
        "episode": episode,
        "config": str(config_path.resolve()),
        "config_hash": canonical_hash(config),
        "measurement_start_wall_ns": start_wall_ns,
        "measurement_end_wall_ns": end_wall_ns,
        "warmup_s": warmup_s,
        "event_s": float(dynamic["event_s"]),
        "deadline_s": deadline_s,
        "event_protocol": "fixed_event_clock_v1",
        "offer_lead_s": offer_lead_s,
        "activation_wall_ns": start_wall_ns + int((warmup_s + offer_lead_s) * 1e9),
        "raw_policy": True,
    })

    model = config["model"]
    base = f"http://127.0.0.1:{config['runtime']['gateway_port']}/v1"
    maximum_batch = max(
        int(value) for value in dynamic["action_lattice"]["batch_concurrency"]
    )
    commands = {
        "online": [
            sys.executable, str(ROOT / "scripts/replay_online.py"),
            "--trace", str(episode["path"]),
            "--output", str(run_dir / "online.jsonl"),
            "--api-base", base,
            "--model", model["name"],
            "--tokenizer", model["tokenizer"],
            "--arrival-scale", str(
                config["workloads"]["arrival_scale_by_source"].get(
                    episode["source"], 1.0
                )
            ),
            "--duration-s", str(workload_s),
            "--start-wall-ns", str(start_wall_ns),
            "--source", str(episode["source"]),
        ],
        "batch": [
            sys.executable, str(ROOT / "scripts/run_batch.py"),
            "--output", str(run_dir / "batch.jsonl"),
            "--api-base", base,
            "--model", model["name"],
            "--tokenizer", model["tokenizer"],
            "--prompt-tokens", str(config["workloads"]["batch_prompt_tokens"]),
            "--output-tokens", str(config["workloads"]["batch_output_tokens"]),
            "--concurrency", str(maximum_batch),
            "--duration-s", str(workload_s),
            "--start-wall-ns", str(start_wall_ns),
        ],
        "controller": [
            sys.executable, "-u", str(ROOT / "scripts/run_dynamic_controller.py"),
            "--config", str(config_path.resolve()),
            "--source", str(episode["source"]),
            "--output-dir", str(run_dir.resolve()),
            "--activation-wall-ns", str(start_wall_ns + int((warmup_s + offer_lead_s) * 1e9)),
        ],
    }

    handles: list = []
    processes: dict[str, subprocess.Popen] = {}
    telemetry: subprocess.Popen | None = None
    try:
        telemetry = subprocess.Popen([
            sys.executable, "-m", "flexbid_hybrid.telemetry",
            "--output", str(run_dir / "components.csv"),
            "--interval-ms", str(config["hardware"]["telemetry_interval_ms"]),
        ], cwd=ROOT, start_new_session=True)
        for name in ("online", "batch"):
            out = (run_dir / f"{name}.stdout.log").open("w", encoding="utf-8")
            err = (run_dir / f"{name}.stderr.log").open("w", encoding="utf-8")
            handles.extend((out, err))
            processes[name] = subprocess.Popen(
                commands[name], cwd=ROOT, stdout=out, stderr=err,
                start_new_session=True,
            )
        delay = (start_wall_ns - time.time_ns()) / 1e9
        if delay > 0:
            time.sleep(delay)
        out = (run_dir / "controller.stdout.log").open("w", encoding="utf-8")
        err = (run_dir / "controller.stderr.log").open("w", encoding="utf-8")
        handles.extend((out, err))
        processes["controller"] = subprocess.Popen(
            commands["controller"], cwd=ROOT, stdout=out, stderr=err,
            start_new_session=True,
        )
        controller_rc = _wait(
            processes["controller"], workload_s + 900.0,
        )

        # A controller startup/configuration failure must stop both
        # clients immediately. Do not burn another 25 minutes waiting
        # for workloads that can no longer produce a valid trajectory.
        if controller_rc != 0:
            stop_process(processes["online"])
            stop_process(processes["batch"])

        online_rc = _wait(processes["online"], 1200.0)
        batch_rc = _wait(processes["batch"], 300.0)
    finally:
        for process in processes.values():
            if process.poll() is None:
                stop_process(process)
        if telemetry is not None:
            stop_process(telemetry)
        for handle in handles:
            handle.close()

    controller_path = run_dir / f"{episode['source']}_controller.jsonl"
    controller_rows = _read_controller(controller_path)
    online_rows = read_jsonl(run_dir / "online.jsonl")
    batch_rows = read_jsonl(run_dir / "batch.jsonl")
    with (run_dir / "components.csv").open(newline="", encoding="utf-8") as stream:
        telemetry_rows = sum(1 for _ in csv.DictReader(stream))
    action_counts = Counter(
        row.get("actuation", {}).get("control", {}).get("action", {}).get("name")
        or row.get("actuation", {}).get("action", {}).get("name")
        for row in controller_rows
    )
    action_counts.pop(None, None)
    bids = [float(row.get("committed_bid_w") or 0.0) for row in controller_rows]
    settlement_failures = (
        controller_rows[-1].get("settlement_failures", [])
        if controller_rows else []
    )
    from flexbid_hybrid.event_protocol import audit_completed_event
    event_audit = audit_completed_event(run_dir)
    marker = {
        "event_protocol_complete": event_audit["complete"],
        "event_audit": event_audit,
        "controller_return_code": controller_rc,
        "online_return_code": online_rc,
        "batch_return_code": batch_rc,
        "controller_records": len(controller_rows),
        "committed_bid_w": max(bids, default=0.0),
        "action_counts": dict(action_counts),
        "settlement_failures": event_audit["failed_windows"],
        "online_requests": len(online_rows),
        "online_errors": sum(row.get("error") is not None for row in online_rows),
        "online_load_shed": sum(row.get("status_code") == 429 for row in online_rows),
        "fatal_online_errors": sum(
            row.get("error") is not None and row.get("status_code") != 429
            for row in online_rows
        ),
        "batch_jobs_completed": sum(row.get("error") is None for row in batch_rows),
        "batch_errors": sum(row.get("error") is not None for row in batch_rows),
        "fatal_batch_errors": sum(row.get("error") is not None for row in batch_rows),
        "telemetry_rows": telemetry_rows,
        "config_hash": canonical_hash(config),
    }
    atomic_json(run_dir / "CELL_COMPLETE.json", marker)
    if not _valid(run_dir):
        atomic_json(run_dir / "CELL_FAILED.json", marker)
        raise RuntimeError(f"invalid dynamic policy cell {run_dir}: {marker}")
    services.wait_idle()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    config_path = args.config.resolve()
    config = load_config(config_path)
    dynamic = config["dynamic_controller"]
    if str(dynamic.get("calibration_mode")) != "none":
        parser.error("raw policy selection requires calibration_mode=none")
    if dynamic.get("trajectory_calibration") is not None:
        parser.error("raw policy selection cannot use trajectory calibration")
    if bool(dynamic.get("online_residual_adaptation", False)):
        parser.error("freeze online residual adaptation during policy selection")
    episodes = select_episodes(ROOT, config)
    output = args.output_root.resolve()
    output.mkdir(parents=True, exist_ok=True)
    if any((output / "cells").rglob("cell.json")):
        raise RuntimeError("Timing protocol requires a NEW output root; old cells preserved")
    atomic_json(output / "campaign_manifest.json", {
        "status": "RAW_DYNAMIC_POLICY_SELECTION",
        "config": str(config_path),
        "config_hash": canonical_hash(config),
        "episodes": episodes,
        "expected_cells": len(episodes),
    })
    actions = build_action_lattice(dynamic["action_lattice"])
    baseline = next(action for action in actions if action.name == "hybrid_full")
    apply_control(
        Path(config["hardware"]["control_file"]), baseline,
        len(config["model"]["replicas"]),
        int(config["runtime"]["online_concurrency"]),
    )
    with PowerCapManager(config["hardware"]["gpu_indices"]) as safety_power:
        with ServiceGroup(ROOT, config, output / "service_logs") as services:
            for episode in episodes:
                run_dir = output / "cells" / _cell_name(episode["episode_id"])
                if args.resume and _valid(run_dir):
                    continue
                try:
                    run_cell(
                        config_path, config, services, episode, run_dir
                    )
                except TimeoutError as exc:
                    # run_cell writes and validates CELL_COMPLETE before its
                    # final drain check. Preserve that evidence and restart
                    # isolated services before advancing to the next cell.
                    if not _valid(run_dir):
                        raise
                    print(json.dumps({
                        "warning": "post-cell gateway drain timed out",
                        "completed_cell_preserved": str(run_dir),
                        "recovery": "restart services and continue",
                        "error": str(exc),
                    }), flush=True)
                    safety_power.restore()
                    services.restart()
                safety_power.restore()
    completed = sum(
        _valid(path.parent)
        for path in (output / "cells").glob("*/CELL_COMPLETE.json")
    )
    marker = {
        "status": "DYNAMIC_POLICY_SELECTION_COMPLETE",
        "expected_cells": len(episodes),
        "completed_cells": completed,
    }
    atomic_json(output / "COLLECTION_COMPLETE.json", marker)
    if completed != len(episodes):
        raise RuntimeError(f"dynamic collection incomplete: {completed}/{len(episodes)}")
    print(json.dumps(marker, indent=2))


if __name__ == "__main__":
    main()
