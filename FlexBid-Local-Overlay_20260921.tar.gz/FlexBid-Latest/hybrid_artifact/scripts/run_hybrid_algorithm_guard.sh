#!/usr/bin/env bash
set -uo pipefail

ROOT="/root/workspace/FlexBid-LLM/hybrid_artifact"
PROFILE="$ROOT/results/hybrid_formal_profile_a800_qwen35_27b_20260821_v2"
ABLATION="$ROOT/results/hybrid_formal_ablation_a800_qwen35_27b_20260822"
CATCHUP="$ROOT/results/hybrid_catchup_a800_qwen35_27b_20260821/CATCHUP_REPORT.json"
OUTPUT="$ROOT/results/hybrid_algorithm_a800_qwen35_27b_20260822"
TEST_RESULTS="results/hybrid_formal_test_a800_qwen35_27b_20260822"
TEST_CONFIG="$ROOT/configs/a800_8gpu_qwen35_27b_formal_test.yaml"
EVENTS="$OUTPUT/logs/guard.events.log"
WORKERS="$OUTPUT/retention_worker.pids"
MAX_STAGNANT=3

cd "$ROOT" || exit 2
mkdir -p "$OUTPUT/logs"

stamp() { date '+%F %T %Z'; }
count_cells() {
  find "$ROOT/$TEST_RESULTS/cells" -type f -name CELL_COMPLETE.json \
    2>/dev/null | wc -l
}
restore_caps() {
  local gpu default
  for gpu in 0 1 2 3 4 5 6 7; do
    default="$(nvidia-smi -i "$gpu" --query-gpu=power.default_limit \
      --format=csv,noheader,nounits 2>/dev/null | head -n 1 | xargs || true)"
    [[ -n "$default" ]] && nvidia-smi -i "$gpu" -pl "$default" \
      >/dev/null 2>&1 || true
  done
}
stop_tracked_retention() {
  local file pid args
  for file in \
    "$ABLATION/post_complete_retention.pids" \
    "$OUTPUT/retention_worker.pids"; do
    [[ -f "$file" ]] || continue
    while read -r pid; do
      [[ "$pid" =~ ^[0-9]+$ ]] || continue
      args="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
      if [[ "$args" == *"scripts/hybrid_retention_worker.py"* ]]; then
        kill -TERM "$pid" 2>/dev/null || true
      fi
    done < "$file"
  done
  sleep 12
}
start_retention() {
  local gpu pid
  declare -a pids=()
  restore_caps
  : > "$WORKERS"
  for gpu in 0 1 2 3 4 5 6 7; do
    CUDA_VISIBLE_DEVICES="$gpu" \
      python -u scripts/hybrid_retention_worker.py \
      >> "$OUTPUT/logs/retention_gpu_${gpu}.log" 2>&1 &
    pids+=("$!")
    echo "$!" >> "$WORKERS"
  done
  echo "$(stamp) retention started pids=$(tr '\n' ',' < "$WORKERS")" >> "$EVENTS"
  wait
}

for required in "$PROFILE/campaign_manifest.json" \
  "$ABLATION/campaign_manifest.json" "$CATCHUP" \
  "$ROOT/scripts/hybrid_retention_worker.py"; do
  if [[ ! -f "$required" ]]; then
    echo "$(stamp) missing required file: $required" | tee -a "$EVENTS"
    restore_caps
    exit 2
  fi
done

stop_tracked_retention
echo "$(stamp) algorithm campaign guard started" >> "$EVENTS"

attempt=0
stagnant=0
while [[ ! -f "$OUTPUT/PIPELINE_COMPLETE.json" ]]; do
  attempt=$((attempt + 1))
  before="$(count_cells)"
  echo "$(stamp) attempt=$attempt test_cells_before=$before" >> "$EVENTS"

  PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}" \
    python -u scripts/run_hybrid_algorithm_campaign.py \
      --profile-results "$PROFILE" \
      --ablation-results "$ABLATION" \
      --catchup-report "$CATCHUP" \
      --output-root "$OUTPUT" \
      --test-results "$TEST_RESULTS" \
      --test-config "$TEST_CONFIG" \
      >> "$OUTPUT/logs/pipeline.log" 2>&1
  rc=$?
  restore_caps
  after="$(count_cells)"
  echo "$(stamp) attempt=$attempt rc=$rc test_cells_after=$after" >> "$EVENTS"

  [[ -f "$OUTPUT/PIPELINE_COMPLETE.json" ]] && break
  if (( after > before )); then
    stagnant=0
  else
    stagnant=$((stagnant + 1))
  fi
  if (( stagnant >= MAX_STAGNANT )); then
    echo "$(stamp) blocked after $stagnant attempts without test-cell progress" \
      >> "$EVENTS"
    break
  fi
  sleep 15
done

restore_caps
if [[ -f "$OUTPUT/PIPELINE_COMPLETE.json" ]]; then
  echo "$(stamp) algorithm pipeline complete" >> "$EVENTS"
else
  echo "$(stamp) algorithm pipeline stopped incomplete" >> "$EVENTS"
fi
start_retention
