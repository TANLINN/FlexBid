# Runtime safety and deployment boundaries — 2026-08-30

This patch fixes a failure path and adds deployment identity checks. It does not
establish delivery reliability, implement automatic hardware adaptation, or
turn historical calibration into a certificate for another server.

## What stays dynamic

The MPC jointly selects event and recovery actions and a proposed bid from its
model, measured state, action space, and contract constraints. No 810/820/1100 W
bid is introduced here. Once an offer is accepted, that contract's commitment
must remain fixed; changing actuator decisions is not permission to erase the
obligation. A later event can have a different proposed bid.

The optimization procedure can be reused across environments. GPU topology,
actuator implementation, inference performance, power response and uncertainty
bounds cannot be assumed to transfer. In particular, two servers with the same
GPU label need not have equivalent drivers, power limits, interference or load.

## Commitment-aware supervision

`GuardedViabilityMPC` independently checks a proposed schedule against the
current model envelopes, debt, cohort, settlement energy, dwell, ramp and
recovery constraints. It saves a validated continuation. If a later solve
times out or returns no feasible plan, the previous continuation is shifted to
the current control clock and rechecked; it is never blindly replayed.

If neither schedule validates, the returned plan is explicitly infeasible.
The existing commitment stays in the log. The emergency action minimizes
predicted event shortfall among transition-compatible, predicted SLO-safe
actions instead of maximizing batch concurrency. If no such action is known,
the status is `NO_CERTIFIED_SAFE_ACTION`. Neither emergency status guarantees
delivery or service safety. Historical failed intervals must remain failures.

The additional deadline check is cooperative, not hard real-time scheduling.
Validation uses a state snapshot and model bounds; it does not yet incorporate
all inference, solve and actuation delays into a verified physical trajectory.
A validated continuation is not a proof of global optimality or real-world
delivery. The new logs make these distinctions explicit.

## Deployment binding

The live runner uses `bind_live_model` before creating the optimizer:

* Offline simulation and explicitly forced zero-bid baseline collection are
  allowed without target deployment approval.
* Live development requires all three explicit settings below. It is labelled
  unvalidated and must not be connected to an external commitment endpoint.
* The default live bidding path requires target validation metadata and
  evidence-file identity checks. An environment mismatch rejects startup.
* During a bound run, unsupported source/feature ranges produce unsafe bounds
  instead of optimistic extrapolation. This is not automatic model adaptation.

```yaml
dynamic_controller:
  deployment_mode: development
  allow_unvalidated_development: true
  external_commitments_enabled: false
```

This is an explicit developer declaration, not an external EMS authorization
mechanism. The repository does not gain an EMS connector through this patch.

The current runtime reader measures GPU NVML power only. Both development and
deployment require an actual GPU-target fitted surrogate with
`power_boundary = "gpu_nvml"`. Historical component-power models trained on
GPU plus RAPL must **not** simply be tagged or renamed. Refit from the correct
GPU target and pair each action with its matching measured baseline. Do not
subtract a guessed constant CPU power from old training labels.

The metadata observer can be run without changing GPU state:

```bash
python scripts/inspect_deployment.py --config YOUR_CONFIG.yaml
```

Its output is `OBSERVATION_ONLY_NOT_VALIDATED`, never deployment approval.
The default path expects `dynamic_controller.deployment_evidence` to reference
a JSON document containing:

* `schema_version: 1`, `status: TARGET_VALIDATED`;
* the exact observed `environment`, `power_boundary`, `model_sha256`;
* validated `sources` and `feature_ranges_by_source`;
* hashed `evidence_files` with `target_calibration` and `target_validation` roles.

Required feature ranges are arrival rate, mean/max prompt length, mean output
length and cache-prefix fraction. GPU UUID, driver, package versions, local
topology, model/tokenizer metadata, runtime configuration, action lattice,
policy settings and baseline dataset identity are checked. The observer does
not hash every model-weight shard or measure inter-node networks.

No tool in this patch issues `TARGET_VALIDATED`: that decision requires review
of actual target-environment calibration and held-out validation. Hashes prove
artifact identity, not experiment quality or statistical coverage. A rectangular
feature-range check cannot detect every joint-distribution or temporal shift.

## Safe next experiment

1. Preserve the old raw runs and their failed settlements unchanged.
2. Verify GPU-only training targets and refit for the target environment.
3. Use CPU fault injection, then a small explicitly development-only GPU run
   to check timeout recovery, actuator readback, settlement and backlog logs.
4. Only after that, freeze the policy and evaluate on untouched target data.
   Do not combine cross-server paired power values as a deployment certificate.

Cross-node placement, communication/KV migration, automatic target profiling,
online model identification and production certification are not implemented
by this patch. A new GPU count/type may also need action-space and actuator
changes, not just refitting coefficients.

## Installation and rollback

The generated paste command validates its payload hash, inspects source
anchors, backs up affected files, preserves unrelated server hotfixes, and
runs CPU tests. Unknown source layouts refuse installation. Failed tests roll
back edited files. No results are overwritten and no GPU experiment, retention
worker, power change or package installation is started.

Tests exercise synthetic model-dependent bids, timeout continuation, debt and
settlement rejection, hardware/model identity rejection and installer behavior.
They are not GPU performance or physical delivery tests.
