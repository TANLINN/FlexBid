from __future__ import annotations

import math
import unittest
import json
import tempfile
from pathlib import Path

import numpy as np

from flexbid.conformal import EpisodeCalibrator, JointEpisodeCalibrator, finite_sample_quantile
from flexbid.controller import SLOAwareController
from flexbid.types import Action, BidDecision, Prediction, RuntimeObservation, WorkloadState
from flexbid.surrogate import ResponseSurrogate
from flexbid.dataset import clip_samples, integrate
from flexbid.traces import adapt_qwen_bailian, adapt_tracelab
from flexbid import campaign
from unittest.mock import patch


class ConformalTests(unittest.TestCase):
    def test_exact_finite_sample_gate(self):
        self.assertTrue(math.isinf(finite_sample_quantile(range(18), 0.05)))
        self.assertEqual(finite_sample_quantile(range(19), 0.05), 18)

    def test_episode_uses_max_window_residual(self):
        rows = []
        for episode in range(20):
            rows.extend([
                {"episode_id": episode, "workload_group": "rag", "actual": 10, "pred": 9},
                {"episode_id": episode, "workload_group": "rag", "actual": 30, "pred": 10},
            ])
        cal = EpisodeCalibrator(0.05).fit(rows, actual_key="actual", predicted_key="pred")
        self.assertEqual(cal.upper_global, 20)
        self.assertEqual(cal.upper(100, "rag"), 120)

    def test_joint_score_covers_all_constraints(self):
        rows = []
        for episode in range(20):
            rows.append({"episode_id": episode, "workload_group": "rag",
                         "power_mean_w": 150, "pp": 100,
                         "ttft_p95_ms": 1000, "pt": 1000,
                         "tpot_p99_ms": 20, "po": 0})
        cal = JointEpisodeCalibrator(0.05).fit(
            rows, prediction_keys={"power_mean_w": "pp", "ttft_p95_ms": "pt",
                                   "tpot_p99_ms": "po"})
        self.assertEqual(cal.global_radius, 2)


class ControllerTests(unittest.TestCase):
    def test_decode_guard_does_not_choose_low_cap(self):
        actions = [Action(512, 200, 2), Action(1024, 300, 4), Action(2048, 400, 8)]
        decision = BidDecision("x", actions[0], 50, 400, 350, 60, True, "test", 0.05)
        controller = SLOAwareController(actions, actions[-1], decode_power_cap_floor_w=300)
        observation = RuntimeObservation(0, 380, 0, 1, 8, 100, -1, 1)
        chosen = controller.choose(observation, decision)
        self.assertGreaterEqual(chosen.action.power_cap_w, 300)

    def test_infeasible_bid_returns_default(self):
        default = Action(2048, 400, 8)
        controller = SLOAwareController([default], default, 300)
        decision = BidDecision("x", None, 0, 0, math.inf, 0, False, "zero", 0.05)
        observation = RuntimeObservation(0, 100, 0, 0, 0, 1, 1, 0)
        self.assertEqual(controller.choose(observation, decision).action, default)


class DataTests(unittest.TestCase):
    def test_energy_boundary_interpolation(self):
        clipped = clip_samples([(0, 100), (10, 200), (20, 100)], 5, 15)
        self.assertEqual(clipped[0], (5, 150))
        self.assertEqual(clipped[-1], (15, 150))
        self.assertAlmostEqual(integrate(clipped), 0.00000175)

    def test_qwen_hash_prefix_and_parent(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "qwen.jsonl"
            rows = [
                {"chat_id": 1, "parent_chat_id": -1, "timestamp": 0,
                 "input_length": 32, "output_length": 2, "type": "text",
                 "turn": 0, "hash_ids": [10, 11]},
                {"chat_id": 2, "parent_chat_id": 1, "timestamp": 1,
                 "input_length": 48, "output_length": 2, "type": "text",
                 "turn": 1, "hash_ids": [10, 11, 12]},
            ]
            path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")
            adapted = adapt_qwen_bailian(path)
            self.assertEqual(adapted[1].parent_request_id, adapted[0].request_id)
            self.assertEqual(adapted[1].cache_prefix_tokens, 32)
            self.assertEqual(adapted[1].session_id, adapted[0].session_id)

    def test_tracelab_normalized_aliases(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "trace.jsonl"
            row = {"session_id": "s", "started_at": "2026-01-01T00:00:00Z",
                   "input_tokens": 100, "prefix_tokens": 80, "output_tokens": 4,
                   "tools": [{"tool_wall_latency_ms": 25}]}
            path.write_text(json.dumps(row) + "\n", encoding="utf-8")
            adapted = adapt_tracelab(path)
            self.assertEqual(adapted[0].prompt_tokens, 100)
            self.assertEqual(adapted[0].cache_prefix_tokens, 80)
            self.assertEqual(adapted[0].tool_delay_ms, 25)

    def test_sparse_design_preserves_power_cap_axis(self):
        config = {"seed": 1, "actions": {
            "chunk_budgets": [512, 1024, 2048, 4096, 8192],
            "power_cap_fractions": [0.5, 0.625, 0.75, 0.875, 1.0],
            "admission_concurrency": [2, 4, 8, 16], "sparse_design_size": 13,
        }}
        with patch.object(campaign, "cap_intersection", return_value=(100, 400, 400)):
            actions, default = campaign.sparse_actions(config)
        cap_axis = [item for item in actions if item.chunk_budget_tokens == default.chunk_budget_tokens
                    and item.admission_concurrency == default.admission_concurrency]
        self.assertEqual(len(actions), 13)
        self.assertEqual(len(cap_axis), 5)


class SurrogateBatchTests(unittest.TestCase):
    class Regressor:
        def predict(self, matrix):
            return np.sum(matrix, axis=1)

    class Classifier:
        def predict_proba(self, matrix):
            probability = np.full(len(matrix), 0.25)
            return np.column_stack((1 - probability, probability))

    def test_batch_precompute_matches_single_prediction(self):
        surrogate = ResponseSurrogate(
            regressors={target: self.Regressor() for target in (
                "power_mean_w", "ttft_p95_ms", "tpot_p99_ms", "energy_j"
            )},
            slo_classifier=self.Classifier(),
        )
        state = WorkloadState(
            timestamp_s=0, arrivals=3, arrival_rate_rps=1,
            prompt_tokens_sum=300, prompt_tokens_mean=100,
            prompt_tokens_max=150, requested_output_budget_sum=30,
            active_prefill=0, active_decode=0, queued=0,
            cache_hit_rate=0.5,
        )
        actions = [Action(512, 200, 2), Action(1024, 300, 4)]
        expected = [surrogate.predict(state, action) for action in actions]
        surrogate._prediction_cache.clear()
        self.assertEqual(surrogate.precompute((state, action) for action in actions), 2)
        actual = [surrogate.predict(state, action) for action in actions]
        self.assertEqual(expected, actual)
        self.assertEqual(surrogate.precompute((state, action) for action in actions), 0)


if __name__ == "__main__":
    unittest.main()
