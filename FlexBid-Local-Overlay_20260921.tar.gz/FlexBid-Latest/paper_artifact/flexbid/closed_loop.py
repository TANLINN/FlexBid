from __future__ import annotations

import csv
import json
import math
import random
import subprocess
import sys
import time
import urllib.request
from collections import defaultdict
from pathlib import Path
from statistics import mean

from .actuation import RuntimeActuator, atomic_write_json
from .bidder import RiskCalibratedBidder
from .campaign import (ServiceGroup, effective_model_config, reset_prefix_caches,
                       sparse_actions, stop_process, validated)
from .controller import SLOAwareController
from .dataset import summarize_run, write_rows
from .evaluation import HistoricalForecaster, state_from_trace
from .freeze import verify_freeze
from .surrogate import ResponseSurrogate
from .types import Action, BidDecision, RuntimeObservation


METHODS = (
    "no_dr", "static_conservative", "power_cap_only", "pals_reactive",
    "workload_only", "flexbid_no_cp", "flexbid_row_cp",
    "flexbid_episode_cp", "clairvoyant_surrogate",
)


def _measurement_deadline_ns(
    request_path: Path, duration_s: float
) -> int:
    requests = [
        json.loads(line)
        for line in request_path.read_text(
            encoding="utf-8"
        ).splitlines()
        if line.strip()
    ]
    replay_starts = [
        int(row["dispatch_wall_time_ns"])
        - int(
            float(row.get("actual_dispatch_ms") or 0)
            * 1e6
        )
        for row in requests
        if row.get("dispatch_wall_time_ns") is not None
    ]
    if not replay_starts:
        raise ValueError(
            f"cannot recover replay start from {request_path}"
        )
    return min(replay_starts) + int(duration_s * 1e9)


def _gateway_state(port: int) -> dict:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/flexbid/state", timeout=2) as response:
            return json.load(response)
    except Exception:
        return {}


def _latest_power(path: Path) -> float | None:
    try:
        with path.open(newline="", encoding="utf-8") as stream:
            rows = list(csv.DictReader(stream))
        values = [float(row["observed_component_power_w"]) for row in rows[-10:]
                  if row.get("observed_component_power_w") not in (None, "")]
        return mean(values) if values else None
    except (OSError, ValueError):
        return None


def _zero(interval: str, default: Action) -> BidDecision:
    return BidDecision(interval, default, 0.0, 0.0, math.inf, 0.0, True,
                       "no demand-response commitment", 0.0)


def _bid(
    method: str, interval: str, forecast, actual, surrogate: ResponseSurrogate,
    actions: list[Action], default: Action, alpha: float, ttft: float, tpot: float,
    static_decision: BidDecision | None = None,
) -> BidDecision:
    if method == "no_dr":
        return _zero(interval, default)
    if method == "static_conservative":
        if static_decision is None:
            raise ValueError("static decision was not frozen")
        value = static_decision.as_dict()
        value["interval_id"] = interval
        value["action"] = static_decision.action
        return BidDecision(**value)
    calibration = {
        "flexbid_no_cp": "none", "flexbid_row_cp": "row",
        "flexbid_episode_cp": "episode", "power_cap_only": "episode",
        "pals_reactive": "none", "workload_only": "episode",
        "clairvoyant_surrogate": "none",
    }.get(method, "episode")
    candidates = actions
    if method == "power_cap_only":
        candidates = [a for a in actions if a.chunk_budget_tokens == default.chunk_budget_tokens
                      and a.admission_concurrency == default.admission_concurrency]
    elif method == "pals_reactive":
        candidates = [a for a in actions if a.chunk_budget_tokens == default.chunk_budget_tokens]
    elif method == "workload_only":
        # Workload-only deliberately removes both cross-layer choices: a
        # single globally conservative action is selected before test.
        candidates = [min(actions, key=lambda a: (a.power_cap_w,
                                                   a.admission_concurrency,
                                                   -a.chunk_budget_tokens))]
    state = actual if method == "clairvoyant_surrogate" else forecast
    return RiskCalibratedBidder(
        surrogate, candidates or [default], default, alpha=alpha,
        ttft_slo_ms=ttft, tpot_slo_ms=tpot, calibration_mode=calibration,
    ).bid(interval, state)


def _static_policy(surrogate: ResponseSurrogate, actions: list[Action], default: Action,
                   states: list, alpha: float, ttft: float, tpot: float) -> BidDecision:
    best = None
    for action in actions:
        reductions = []
        feasible = True
        for state in states:
            base = surrogate.bounds(state, default, "episode")
            controlled = surrogate.bounds(state, action, "episode")
            reductions.append(base.power_lower_w - controlled.power_upper_w)
            feasible = feasible and controlled.ttft_upper_ms <= ttft and controlled.tpot_upper_ms <= tpot
        safe = min(reductions, default=-math.inf)
        if feasible and math.isfinite(safe) and safe > 0 and (best is None or safe > best[0]):
            best = (safe, action)
    if best is None:
        return _zero("static", default)
    safe, action = best
    return BidDecision("static", action, safe, 0.0, 0.0, safe, True,
                       "globally fixed worst-case calibration policy", alpha)


def _run_policy_cell(
    artifact_root: Path, config: dict, model_config: dict, episode: dict,
    method: str, decision: BidDecision, actions: list[Action], default: Action,
    run_dir: Path, actuator: RuntimeActuator, ttft_slo_ms: float,
    tpot_slo_ms: float,
) -> list[dict]:
    action = decision.action or default
    if validated(run_dir):
        return summarize_run(run_dir, action=action.as_dict(), split="test",
                             episode_id=episode["episode_id"], model=model_config["name"],
                             window_s=float(config["evaluation"]["window_s"]),
                             measurement_duration_s=float(config["workloads"]["episode_s"]))
    run_dir.mkdir(parents=True, exist_ok=True)
    reset_prefix_caches(config, model_config)
    actuator.set_load_shed_threshold(32 if method.startswith("flexbid_") else int(config["runtime"]["max_queue"]))
    actuator.apply(action)
    time.sleep(2)
    telemetry_path = run_dir / "components.csv"
    telemetry = subprocess.Popen([
        sys.executable, "-m", "flexbid.telemetry", "--output", str(telemetry_path),
        "--interval-ms", str(config["hardware"]["telemetry_interval_ms"]),
    ], cwd=artifact_root, start_new_session=True)
    replay = subprocess.Popen([
        sys.executable, str(artifact_root / "scripts/replay_trace.py"),
        "--trace", episode["path"], "--output", str(run_dir / "requests.jsonl"),
        "--api-base", f"http://127.0.0.1:{config['runtime']['gateway_port']}/v1",
        "--model", model_config["name"], "--tokenizer", model_config["tokenizer"],
        "--arrival-scale", str(model_config.get("arrival_scale_by_source", {}).get(episode["source"], 1.0)),
        "--duration-limit-s", str(config["workloads"]["episode_s"]),
        "--allow-load-shedding",
    ], cwd=artifact_root, stdout=(run_dir / "replay.stdout.log").open("w"),
       stderr=(run_dir / "replay.stderr.log").open("w"), start_new_session=True)
    dynamic = method in {"pals_reactive", "flexbid_no_cp", "flexbid_row_cp", "flexbid_episode_cp"}
    safe_keys = set(decision.diagnostics.get("feasible_actions", []))
    safe_actions = [item for item in actions if not safe_keys or item.key in safe_keys]
    controller = SLOAwareController(
        actions=safe_actions if method != "pals_reactive" else [
            item for item in safe_actions if item.chunk_budget_tokens == default.chunk_budget_tokens
        ],
        default_action=default,
        decode_power_cap_floor_w=max(a.power_cap_w for a in actions) * 0.75,
        min_action_hold_s=float(config["runtime"]["controller_hold_s"]),
    )
    applied = action
    control_log = []
    started = time.monotonic()
    try:
        while replay.poll() is None:
            if dynamic:
                state = _gateway_state(int(config["runtime"]["gateway_port"]))
                power = _latest_power(telemetry_path)
                if power is not None:
                    observation = RuntimeObservation(
                        timestamp_s=time.monotonic() - started,
                        aggregate_power_w=power,
                        queue_depth=int(state.get("waiting", 0)),
                        active_prefill=int(state.get("active_prefill", 0)),
                        active_decode=int(state.get("active_decode", 0)),
                        ttft_slack_ms=ttft_slo_ms - float(state.get("ttft_p95_ms") or 0),
                        tpot_slack_ms=tpot_slo_ms - float(state.get("tpot_p99_ms") or 0),
                        arrival_rate_rps=0.0,
                    )
                    chosen = controller.choose(observation, decision)
                    if chosen.action != applied:
                        actuator.apply(chosen.action)
                        applied = chosen.action
                    control_log.append({**controller.history[-1], "power_w": power,
                                        "gateway": state})
            time.sleep(float(config["runtime"]["controller_tick_s"]))
        return_code = replay.wait()
        # Align the fixed measurement interval to the replay
        # process's true wall-clock origin. The controller's
        # `started` timestamp is initialized after Popen and may
        # lag the replay origin by several seconds.
        deadline_ns = _measurement_deadline_ns(
            run_dir / "requests.jsonl",
            float(config["workloads"]["episode_s"]),
        )
        remaining = (deadline_ns - time.time_ns()) / 1e9
        if remaining > 0:
            time.sleep(remaining)

        # Retain at least one telemetry sample strictly beyond
        # the fixed measurement boundary.
        telemetry_tail_s = max(
            0.5,
            4
            * float(
                config["hardware"]["telemetry_interval_ms"]
            )
            / 1000,
        )
        time.sleep(telemetry_tail_s)
    finally:
        if replay.poll() is None:
            stop_process(replay)
        stop_process(telemetry)
        actuator.apply(default)
    atomic_write_json(run_dir / "bid.json", decision.as_dict())
    (run_dir / "controller.jsonl").write_text(
        "".join(json.dumps(row) + "\n" for row in control_log), encoding="utf-8")
    request_path = run_dir / "requests.jsonl"
    requests = [json.loads(line) for line in request_path.read_text(encoding="utf-8").splitlines()
                if line.strip()] if request_path.exists() else []
    with telemetry_path.open(newline="", encoding="utf-8") as stream:
        telemetry_rows = sum(1 for _ in csv.DictReader(stream))
    marker = {
        "return_code": return_code,
        "request_errors": sum(row.get("error") is not None and not row.get("load_shed") for row in requests),
        "load_shed_requests": sum(bool(row.get("load_shed")) for row in requests),
        "requests": len(requests), "telemetry_rows": telemetry_rows,
        "method": method, "initial_action": action.as_dict(), "final_action": applied.as_dict(),
    }
    atomic_write_json(run_dir / "CELL_COMPLETE.json", marker)
    if return_code or marker["request_errors"] or telemetry_rows < 2:
        raise RuntimeError(f"invalid test cell: {run_dir}: {marker}")
    return summarize_run(run_dir, action=action.as_dict(), split="test",
                         episode_id=episode["episode_id"], model=model_config["name"],
                         window_s=float(config["evaluation"]["window_s"]),
                         measurement_duration_s=float(config["workloads"]["episode_s"]))


def _aggregate(rows: list[dict]) -> dict:
    finite = lambda key: [float(row[key]) for row in rows if row.get(key) not in (None, "")]
    return {
        "requests": sum(int(row.get("arrivals") or 0) for row in rows),
        "power_mean_w": mean(finite("power_mean_w")),
        "energy_j": sum(finite("energy_j")),
        "ttft_p95_ms": max(finite("ttft_p95_ms"), default=None),
        "tpot_p99_ms": max(finite("tpot_p99_ms"), default=None),
        "request_errors": sum(int(row.get("request_errors") or 0) for row in rows),
        "load_shed_requests": sum(int(row.get("load_shed_requests") or 0) for row in rows),
        "slo_windows": sum(int(row.get("any_slo_violation") or 0) for row in rows),
        "windows": len(rows),
    }


def run_closed_loop(artifact_root: Path, config_path: Path, config: dict, resume: bool) -> None:
    from .config import resolve_from_config

    results = resolve_from_config(config_path, config["paths"]["results_root"])
    verify_freeze(results / "ALGORITHM_FREEZE.json")
    manifest = json.loads((resolve_from_config(config_path, config["workloads"]["adapted_root"])
                           / "manifest.json").read_text(encoding="utf-8"))
    train = [item for item in manifest["episodes"] if item["split"] == "train"]
    calibration_items = [item for item in manifest["episodes"] if item["split"] == "calibration"]
    test_by_source = defaultdict(list)
    for item in manifest["episodes"]:
        if item["split"] == "test":
            test_by_source[item["source"]].append(item)
    limit = int(config["evaluation"]["real_test_episodes_per_source"])
    test = [item for source in sorted(test_by_source) for item in test_by_source[source][:limit]]
    actions, default = sparse_actions(config)
    summaries, all_windows = [], []
    rng = random.Random(int(config["seed"]) + 1)
    model_root = resolve_from_config(config_path, config["paths"]["models_root"])
    with RuntimeActuator(Path(config["hardware"]["control_file"]), config["hardware"]["gpu_indices"]) as actuator:
        for raw_model_config in config["models"]:
            model_config = effective_model_config(results, raw_model_config)
            slug = model_config["name"].replace("/", "_")
            surrogate = ResponseSurrogate.load(model_root / f"{slug}.joblib")
            scales = model_config.get("arrival_scale_by_source", {})
            duration = float(config["workloads"]["episode_s"])
            forecaster = HistoricalForecaster(scales, duration).fit(train)
            static_decision = _static_policy(
                surrogate, actions, default,
                [state_from_trace(Path(item["path"]), item["source"],
                                  scales.get(item["source"], 1.0), duration)
                 for item in calibration_items],
                float(config["risk"]["alpha"]),
                float(config["slos"]["default"]["ttft_ms"]),
                float(config["slos"]["default"]["tpot_ms"]),
            )
            with ServiceGroup(artifact_root, config, model_config, results / "closed_loop_logs" / slug):
                for episode in test:
                    forecast = forecaster.predict_episode(episode, manifest)
                    slo_name = "agentic" if episode["source"] == "tracelab" else "default"
                    ttft_slo = float(config["slos"][slo_name]["ttft_ms"])
                    tpot_slo = float(config["slos"][slo_name]["tpot_ms"])
                    decisions = {
                        method: _bid(
                            method, episode["episode_id"], forecast, None, surrogate,
                            actions, default, float(config["risk"]["alpha"]),
                            ttft_slo, tpot_slo, static_decision,
                        )
                        for method in METHODS if method != "clairvoyant_surrogate"
                    }
                    # Only after every deployable method has committed its bid
                    # may the labelled oracle inspect the current test episode.
                    actual = state_from_trace(
                        Path(episode["path"]), episode["source"],
                        scales.get(episode["source"], 1.0), duration,
                    )
                    decisions["clairvoyant_surrogate"] = _bid(
                        "clairvoyant_surrogate", episode["episode_id"], forecast, actual,
                        surrogate, actions, default, float(config["risk"]["alpha"]),
                        ttft_slo, tpot_slo, static_decision,
                    )
                    order = list(METHODS)
                    rng.shuffle(order)
                    episode_results = {}
                    for method in order:
                        decision = decisions[method]
                        run_dir = results / "closed_loop" / slug / episode["episode_id"].replace(":", "_") / method
                        rows = _run_policy_cell(artifact_root, config, model_config, episode,
                                                method, decision, actions, default, run_dir, actuator,
                                                ttft_slo, tpot_slo)
                        for row in rows:
                            row["method"] = method
                        all_windows.extend(rows)
                        episode_results[method] = _aggregate(rows)
                    baseline = episode_results["no_dr"]["power_mean_w"]
                    for method, values in episode_results.items():
                        decision = decisions[method]
                        achieved = baseline - values["power_mean_w"]
                        bid = decision.committed_reduction_w
                        tolerance = float(config["evaluation"]["delivery_tolerance_w"])
                        summaries.append({
                            "model": model_config["name"], "episode_id": episode["episode_id"],
                            "source": episode["source"], "method": method,
                            "bid_w": bid, "achieved_reduction_w": achieved,
                            "delivery_failure": int(achieved + tolerance < bid),
                            **values,
                        })
    write_rows(all_windows, results / "closed_loop_windows.csv")
    write_rows(summaries, results / "closed_loop_summary.csv")
    atomic_write_json(results / "CLOSED_LOOP_COMPLETE.json", {
        "test_episodes": len(test), "methods": list(METHODS), "runs": len(summaries),
        "request_errors": sum(row["request_errors"] for row in summaries),
    })
