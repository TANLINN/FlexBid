"""OpenAI-compatible multi-replica gateway with runtime admission control."""

from __future__ import annotations

import asyncio
import json
import os
import time
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import Response, StreamingResponse


CONTROL_FILE = Path(os.environ.get("FLEXBID_CONTROL_FILE", "/tmp/flexbid-control.json"))
UPSTREAMS = [item.rstrip("/") for item in os.environ.get(
    "FLEXBID_UPSTREAMS", "http://127.0.0.1:18001"
).split(",") if item.strip()]
MAX_QUEUE = int(os.environ.get("FLEXBID_MAX_QUEUE", "256"))
FALLBACK_UPSTREAM = os.environ.get("FLEXBID_FALLBACK_UPSTREAM", "").rstrip("/") or None


class AdjustableGate:
    def __init__(self, limit: int):
        self.limit = limit
        self.active = 0
        self.waiting = 0
        self.condition = asyncio.Condition()

    async def acquire(self) -> None:
        async with self.condition:
            self.waiting += 1
            try:
                while self.active >= self.limit:
                    await self.condition.wait()
                self.active += 1
            finally:
                self.waiting -= 1

    async def release(self) -> None:
        async with self.condition:
            self.active -= 1
            self.condition.notify_all()

    async def resize(self, limit: int) -> None:
        if limit <= 0:
            raise ValueError("admission concurrency must be positive")
        async with self.condition:
            self.limit = limit
            self.condition.notify_all()


class GatewayState:
    def __init__(self):
        self.gate = AdjustableGate(int(os.environ.get("FLEXBID_INITIAL_CONCURRENCY", "8")))
        self.inflight = [0 for _ in UPSTREAMS]
        self.latencies = deque(maxlen=512)
        self.last_control_mtime = -1
        self.client = httpx.AsyncClient(
            timeout=None,
            limits=httpx.Limits(
                max_connections=1024,
                max_keepalive_connections=0,
            ),
        )
        self.lock = asyncio.Lock()
        self.active_prefill = 0
        self.active_decode = 0
        self.load_shed_queue_threshold = MAX_QUEUE

    async def refresh_control(self) -> None:
        try:
            stat = CONTROL_FILE.stat()
            if stat.st_mtime_ns == self.last_control_mtime:
                return
            payload = json.loads(CONTROL_FILE.read_text(encoding="utf-8"))
            await self.gate.resize(int(payload["admission_concurrency"]))
            self.load_shed_queue_threshold = int(payload.get("load_shed_queue_threshold", MAX_QUEUE))
            self.last_control_mtime = stat.st_mtime_ns
        except FileNotFoundError:
            return

    async def choose(self) -> int:
        async with self.lock:
            index = min(range(len(self.inflight)), key=self.inflight.__getitem__)
            self.inflight[index] += 1
            return index

    async def finish(self, index: int, metric: dict) -> None:
        async with self.lock:
            self.inflight[index] -= 1
            self.latencies.append(metric)

    async def begin_request(self) -> None:
        async with self.lock:
            self.active_prefill += 1

    async def first_token(self) -> None:
        async with self.lock:
            self.active_prefill = max(0, self.active_prefill - 1)
            self.active_decode += 1

    async def end_request(self, saw_token: bool) -> None:
        async with self.lock:
            if saw_token:
                self.active_decode = max(0, self.active_decode - 1)
            else:
                self.active_prefill = max(0, self.active_prefill - 1)


state = GatewayState()


@asynccontextmanager
async def lifespan(_app: FastAPI):
    if not UPSTREAMS:
        raise RuntimeError("FLEXBID_UPSTREAMS is empty")
    yield
    await state.client.aclose()


app = FastAPI(lifespan=lifespan)


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    values = sorted(values)
    return values[min(len(values) - 1, max(0, int(q * len(values))))]


@app.get("/health")
async def health():
    return {"status": "ok", "upstreams": UPSTREAMS}


@app.get("/flexbid/state")
async def flexbid_state():
    await state.refresh_control()
    metrics = list(state.latencies)
    return {
        "active": state.gate.active,
        "waiting": state.gate.waiting,
        "admission_concurrency": state.gate.limit,
        "upstream_inflight": state.inflight,
        "active_prefill": state.active_prefill,
        "active_decode": state.active_decode,
        "ttft_p95_ms": percentile([
            item["ttft_ms"] for item in metrics if item.get("ttft_ms") is not None
        ], 0.95),
        "tpot_p99_ms": percentile([
            item["mean_chunk_gap_ms"] for item in metrics
            if item.get("mean_chunk_gap_ms") is not None
        ], 0.99),
        "completed_window": len(metrics),
        "load_shed_queue_threshold": state.load_shed_queue_threshold,
    }


@app.post("/flexbid/control")
async def flexbid_control(request: Request):
    payload = await request.json()
    limit = int(payload["admission_concurrency"])
    await state.gate.resize(limit)
    return {"admission_concurrency": limit}


@app.api_route("/v1/{path:path}", methods=["GET", "POST"])
async def proxy(path: str, request: Request):
    await state.refresh_control()
    if state.gate.waiting >= state.load_shed_queue_threshold:
        if FALLBACK_UPSTREAM is None:
            raise HTTPException(status_code=429, detail="FlexBid overload fallback")
        upstream = FALLBACK_UPSTREAM
        index = -1
    else:
        await state.gate.acquire()
        index = await state.choose()
        upstream = UPSTREAMS[index]
    body = await request.body()
    headers = {
        key: value for key, value in request.headers.items()
        if key.lower() not in {"host", "content-length", "connection"}
    }
    started = time.perf_counter()
    upstream_request = state.client.build_request(
        request.method, f"{upstream}/v1/{path}", content=body,
        headers=headers, params=request.query_params,
    )
    try:
        if index >= 0:
            await state.begin_request()
        response = await state.client.send(upstream_request, stream=True)
    except Exception:
        if index >= 0:
            await state.end_request(False)
            await state.finish(index, {"error": "upstream_connect"})
            await state.gate.release()
        raise
    content_type = response.headers.get("content-type", "")
    if "text/event-stream" not in content_type:
        payload = await response.aread()
        await response.aclose()
        if index >= 0:
            await state.end_request(False)
            await state.finish(index, {"e2e_ms": (time.perf_counter() - started) * 1000})
            await state.gate.release()
        return Response(content=payload, status_code=response.status_code,
                        media_type=content_type or "application/octet-stream")

    async def stream():
        first = None
        previous = None
        gaps = []
        try:
            async for chunk in response.aiter_bytes():
                now = time.perf_counter()
                first = now if first is None else first
                if previous is None and index >= 0:
                    await state.first_token()
                if previous is not None:
                    gaps.append((now - previous) * 1000)
                previous = now
                yield chunk
        finally:
            await response.aclose()
            if index >= 0:
                await state.end_request(first is not None)
                await state.finish(index, {
                    "ttft_ms": None if first is None else (first - started) * 1000,
                    "mean_chunk_gap_ms": sum(gaps) / len(gaps) if gaps else None,
                    "max_chunk_gap_ms": max(gaps) if gaps else None,
                    "e2e_ms": (time.perf_counter() - started) * 1000,
                })
                await state.gate.release()

    return StreamingResponse(stream(), status_code=response.status_code, media_type=content_type)
