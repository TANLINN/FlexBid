from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor

from .conformal import EpisodeCalibrator, JointEpisodeCalibrator
from .types import Action, Prediction, PredictionBounds, WorkloadState


DEFAULT_FEATURES = [
    "arrivals", "arrival_rate_rps", "prompt_tokens_sum", "prompt_tokens_mean",
    "prompt_tokens_max", "cache_hit_rate",
    "chunk_budget_tokens", "power_cap_w", "admission_concurrency",
]
TARGETS = ("power_mean_w", "ttft_p95_ms", "tpot_p99_ms", "energy_j")


def _matrix(rows: Iterable[dict], features: list[str]) -> np.ndarray:
    return np.asarray([
        [float(row.get(feature, 0.0) or 0.0) for feature in features]
        for row in rows
    ], dtype=float)


def combine(state: WorkloadState, action: Action) -> dict[str, float]:
    row = state.features()
    row.update({
        "chunk_budget_tokens": float(action.chunk_budget_tokens),
        "power_cap_w": float(action.power_cap_w),
        "admission_concurrency": float(action.admission_concurrency),
    })
    return row


@dataclass
class ResponseSurrogate:
    features: list[str] = field(default_factory=lambda: list(DEFAULT_FEATURES))
    alpha: float = 0.05
    regressors: dict[str, object] = field(default_factory=dict)
    slo_classifier: object | None = None
    calibrators: dict[str, EpisodeCalibrator] = field(default_factory=dict)
    joint_calibrator: JointEpisodeCalibrator | None = None
    # This cache is populated only for inference.  Keep the key at the exact
    # feature-vector level so precomputed batch predictions are bit-for-bit
    # interchangeable with the former one-row-at-a-time path.
    _prediction_cache: dict[tuple[float, ...], Prediction] = field(
        default_factory=dict, init=False, repr=False, compare=False
    )

    def fit(self, train_rows: list[dict], calibration_rows: list[dict]) -> "ResponseSurrogate":
        if not train_rows or not calibration_rows:
            raise ValueError("non-empty train and calibration rows are required")
        x_train = _matrix(train_rows, self.features)
        x_cal = _matrix(calibration_rows, self.features)
        for target in TARGETS:
            usable_train = [index for index, row in enumerate(train_rows) if row.get(target) not in (None, "")]
            usable_cal = [index for index, row in enumerate(calibration_rows) if row.get(target) not in (None, "")]
            if len(usable_train) < 20 or len(usable_cal) < 5:
                continue
            model = HistGradientBoostingRegressor(
                learning_rate=0.06, max_iter=300, max_leaf_nodes=15,
                l2_regularization=1.0, random_state=2026,
            )
            model.fit(x_train[usable_train], np.asarray([
                float(train_rows[index][target]) for index in usable_train
            ]))
            self.regressors[target] = model
            predictions = model.predict(x_cal[usable_cal])
            cal_rows = []
            for index, prediction in zip(usable_cal, predictions):
                item = dict(calibration_rows[index])
                item["_prediction"] = float(prediction)
                cal_rows.append(item)
            self.calibrators[target] = EpisodeCalibrator(self.alpha).fit(
                cal_rows, actual_key=target, predicted_key="_prediction"
            )
        labels = [int(float(row.get("any_slo_violation", 0))) for row in train_rows]
        if len(set(labels)) == 2:
            classifier = HistGradientBoostingClassifier(
                learning_rate=0.06, max_iter=300, max_leaf_nodes=15,
                l2_regularization=1.0, random_state=2026,
            )
            classifier.fit(x_train, np.asarray(labels))
            self.slo_classifier = classifier
        required = ("power_mean_w", "ttft_p95_ms", "tpot_p99_ms")
        if all(target in self.regressors for target in required):
            scales = {}
            for target in required:
                values = [float(row[target]) for row in train_rows
                          if row.get(target) not in (None, "")]
                scales[target] = max(1.0, float(np.std(values)))
            joint_rows = []
            for index, row in enumerate(calibration_rows):
                if any(row.get(target) in (None, "") for target in required):
                    continue
                item = dict(row)
                for target in required:
                    item[f"_joint_{target}"] = float(self.regressors[target].predict(
                        x_cal[index:index + 1]
                    )[0])
                joint_rows.append(item)
            self.joint_calibrator = JointEpisodeCalibrator(self.alpha, scales=scales).fit(
                joint_rows, prediction_keys={target: f"_joint_{target}" for target in required}
            )
        return self

    def _predict_target(self, target: str, row: dict[str, float]) -> float:
        model = self.regressors.get(target)
        if model is None:
            return math.inf
        return float(model.predict(_matrix([row], self.features))[0])

    def _prediction_key(self, row: dict[str, float]) -> tuple[float, ...]:
        return tuple(float(row.get(feature, 0.0) or 0.0) for feature in self.features)

    def precompute(
        self,
        state_actions: Iterable[tuple[WorkloadState, Action]],
        *,
        batch_size: int = 65_536,
    ) -> int:
        """Batch-fill predictions used by large offline evaluations.

        The original implementation invoked five sklearn estimators for every
        state/action lookup, even though bidding policies repeatedly query the
        same points.  This method evaluates each unique point once in large
        matrices and leaves the bidding/calibration logic unchanged.
        """
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        cache = getattr(self, "_prediction_cache", None)
        if cache is None:  # Backward-compatible with joblib artifacts saved before this field existed.
            cache = {}
            self._prediction_cache = cache
        missing: dict[tuple[float, ...], dict[str, float]] = {}
        for state, action in state_actions:
            row = combine(state, action)
            key = self._prediction_key(row)
            if key not in cache and key not in missing:
                missing[key] = row
        items = list(missing.items())
        for start in range(0, len(items), batch_size):
            batch = items[start:start + batch_size]
            matrix = _matrix((row for _, row in batch), self.features)
            if self.slo_classifier is None:
                probabilities = np.ones(len(batch), dtype=float)
            else:
                probabilities = self.slo_classifier.predict_proba(matrix)[:, 1]
            values: dict[str, np.ndarray] = {}
            for target in TARGETS:
                model = self.regressors.get(target)
                values[target] = (
                    np.full(len(batch), math.inf, dtype=float)
                    if model is None else np.asarray(model.predict(matrix), dtype=float)
                )
            for index, (key, _) in enumerate(batch):
                cache[key] = Prediction(
                    power_mean_w=float(values["power_mean_w"][index]),
                    ttft_p95_ms=float(values["ttft_p95_ms"][index]),
                    tpot_p99_ms=float(values["tpot_p99_ms"][index]),
                    slo_violation_probability=float(probabilities[index]),
                    energy_j=float(values["energy_j"][index]),
                )
        return len(items)

    def predict(self, state: WorkloadState, action: Action) -> Prediction:
        row = combine(state, action)
        cache = getattr(self, "_prediction_cache", None)
        if cache is None:  # Backward-compatible with previously frozen joblib files.
            cache = {}
            self._prediction_cache = cache
        key = self._prediction_key(row)
        cached = cache.get(key)
        if cached is not None:
            return cached
        probability = 1.0
        if self.slo_classifier is not None:
            probability = float(self.slo_classifier.predict_proba(
                _matrix([row], self.features)
            )[0, 1])
        prediction = Prediction(
            power_mean_w=self._predict_target("power_mean_w", row),
            ttft_p95_ms=self._predict_target("ttft_p95_ms", row),
            tpot_p99_ms=self._predict_target("tpot_p99_ms", row),
            slo_violation_probability=probability,
            energy_j=self._predict_target("energy_j", row),
        )
        cache[key] = prediction
        return prediction

    def bounds(
        self, state: WorkloadState, action: Action, calibration: str = "episode"
    ) -> PredictionBounds:
        prediction = self.predict(state, action)
        group = state.workload_group
        joint = self.joint_calibrator
        if joint is None:
            return PredictionBounds(-math.inf, math.inf, math.inf, math.inf, 1.0)
        if calibration == "none":
            power_lower = power_upper = prediction.power_mean_w
            ttft_upper = prediction.ttft_p95_ms
            tpot_upper = prediction.tpot_p99_ms
        elif calibration == "row":
            radius = joint.radius("row", group)
            power_lower = prediction.power_mean_w - radius * joint.scales["power_mean_w"]
            power_upper = prediction.power_mean_w + radius * joint.scales["power_mean_w"]
            ttft_upper = prediction.ttft_p95_ms + radius * joint.scales["ttft_p95_ms"]
            tpot_upper = prediction.tpot_p99_ms + radius * joint.scales["tpot_p99_ms"]
        elif calibration == "episode":
            radius = joint.radius("episode", group)
            power_lower = prediction.power_mean_w - radius * joint.scales["power_mean_w"]
            power_upper = prediction.power_mean_w + radius * joint.scales["power_mean_w"]
            ttft_upper = prediction.ttft_p95_ms + radius * joint.scales["ttft_p95_ms"]
            tpot_upper = prediction.tpot_p99_ms + radius * joint.scales["tpot_p99_ms"]
        else:
            raise ValueError(f"unknown calibration mode: {calibration}")
        return PredictionBounds(
            power_lower_w=power_lower, power_upper_w=power_upper,
            ttft_upper_ms=ttft_upper, tpot_upper_ms=tpot_upper,
            # Classifier probabilities are diagnostic until separately calibrated.
            slo_violation_probability_upper=prediction.slo_violation_probability,
        )

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, path)

    @staticmethod
    def load(path: Path) -> "ResponseSurrogate":
        model = joblib.load(path)
        if not isinstance(model, ResponseSurrogate):
            raise TypeError(f"not a ResponseSurrogate artifact: {path}")
        return model
