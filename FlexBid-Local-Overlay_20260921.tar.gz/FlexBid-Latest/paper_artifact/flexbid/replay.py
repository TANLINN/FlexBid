from __future__ import annotations

import asyncio
import hashlib
import json
import random
import time
from pathlib import Path
from typing import Any

import httpx


class PromptMaterializer:
    """Create exact-length valid token-ID prompts with session prefix reuse."""

    def __init__(self, tokenizer_name: str):
        from transformers import AutoTokenizer

        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
        candidates = self.tokenizer.encode(
            " enterprise retrieval document analysis code tool result evidence benchmark",
            add_special_tokens=False,
        )
        special = set(self.tokenizer.all_special_ids)
        self.pool = [token for token in candidates if token not in special]
        if not self.pool:
            raise RuntimeError("could not construct a non-special token pool")

    def tokens(self, row: dict[str, Any]) -> list[int]:
        count = int(row["prompt_tokens"])
        prefix_count = min(count, max(0, int(row.get("cache_prefix_tokens") or 0)))

        def materialize(identity: str, length: int) -> list[int]:
            seed = int(hashlib.sha256(identity.encode()).hexdigest()[:16], 16)
            rng = random.Random(seed)
            pattern = [rng.choice(self.pool) for _ in range(256)]
            return (pattern * ((length + len(pattern) - 1) // len(pattern)))[:length]

        session = str(row.get("session_id") or row["request_id"])
        prefix = materialize("prefix:" + session, prefix_count)
        suffix = materialize("suffix:" + str(row["request_id"]), count - prefix_count)
        return prefix + suffix


def load_trace(path: Path, arrival_scale: float = 1.0,
               duration_limit_s: float | None = None) -> list[dict[str, Any]]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if not rows:
        raise ValueError(f"empty trace: {path}")
    required = {"request_id", "arrival_ms", "prompt_tokens", "max_output_tokens"}
    for index, row in enumerate(rows):
        missing = required - row.keys()
        if missing:
            raise ValueError(f"trace row {index} missing {sorted(missing)}")
    if arrival_scale <= 0:
        raise ValueError("arrival_scale must be positive")
    scaled = []
    for row in rows:
        item = dict(row)
        item["arrival_ms"] = float(item["arrival_ms"]) * arrival_scale
        item["tool_delay_ms"] = float(item.get("tool_delay_ms") or 0) * arrival_scale
        if duration_limit_s is None or item["arrival_ms"] <= duration_limit_s * 1000:
            scaled.append(item)
    if not scaled:
        raise ValueError("trace scaling/cropping removed every request")
    return sorted(scaled, key=lambda row: (float(row["arrival_ms"]), row["request_id"]))


async def issue(
    row: dict[str, Any], client: httpx.AsyncClient, api_base: str, model: str,
    materializer: PromptMaterializer, start_ns: int,
    completion_events: dict[str, asyncio.Event], completion_times: dict[str, int],
) -> dict[str, Any]:
    parent = row.get("parent_request_id")
    if parent and parent in completion_events:
        await completion_events[parent].wait()
    trace_target_ns = start_ns + int(float(row["arrival_ms"]) * 1_000_000)
    dependency_target_ns = completion_times.get(parent, start_ns) + int(
        float(row.get("tool_delay_ms") or 0) * 1_000_000
    )
    target_ns = max(trace_target_ns, dependency_target_ns)
    delay = (target_ns - time.perf_counter_ns()) / 1e9
    if delay > 0:
        await asyncio.sleep(delay)
    dispatch_ns = time.perf_counter_ns()
    dispatch_wall_ns = time.time_ns()
    first_ns = None
    previous_ns = None
    gaps_ms = []
    completion_tokens = None
    error = None
    load_shed = False
    payload = {
        "model": model,
        "prompt": materializer.tokens(row),
        "max_tokens": int(row["max_output_tokens"]),
        "temperature": 0.0,
        "ignore_eos": True,
        "stream": True,
        "stream_options": {"include_usage": True},
    }
    try:
        async with client.stream("POST", f"{api_base.rstrip('/')}/completions", json=payload) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith("data: "):
                    continue
                data = line[6:]
                if data == "[DONE]":
                    break
                message = json.loads(data)
                usage = message.get("usage")
                if usage:
                    completion_tokens = usage.get("completion_tokens", completion_tokens)
                choices = message.get("choices") or []
                if choices and choices[0].get("text"):
                    now = time.perf_counter_ns()
                    if first_ns is None:
                        first_ns = now
                    if previous_ns is not None:
                        gaps_ms.append((now - previous_ns) / 1e6)
                    previous_ns = now
    except httpx.HTTPStatusError as exc:
        load_shed = exc.response.status_code == 429
        error = f"{type(exc).__name__}: {exc}"
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    completed_ns = time.perf_counter_ns()
    completed_wall_ns = dispatch_wall_ns + (completed_ns - dispatch_ns)
    completion_times[row["request_id"]] = completed_ns
    completion_events[row["request_id"]].set()
    ttft = None if first_ns is None else (first_ns - dispatch_ns) / 1e6
    mean_gap = sum(gaps_ms) / len(gaps_ms) if gaps_ms else None
    max_gap = max(gaps_ms) if gaps_ms else None
    return {
        **{key: value for key, value in row.items() if key != "prompt_token_ids"},
        "actual_dispatch_ms": (dispatch_ns - start_ns) / 1e6,
        "actual_completion_ms": (completed_ns - start_ns) / 1e6,
        "dispatch_wall_time_ns": dispatch_wall_ns,
        "first_token_wall_time_ns": None if first_ns is None else dispatch_wall_ns + (first_ns - dispatch_ns),
        "completion_wall_time_ns": completed_wall_ns,
        "completion_tokens": completion_tokens,
        "ttft_ms": ttft,
        "mean_tpot_ms": mean_gap,
        "tpot_p99_ms": sorted(gaps_ms)[min(len(gaps_ms) - 1, int(0.99 * len(gaps_ms)))] if gaps_ms else None,
        "max_tpot_ms": max_gap,
        "e2e_ms": (completed_ns - dispatch_ns) / 1e6,
        "ttft_violation": ttft is None or ttft > float(row.get("ttft_slo_ms", float("inf"))),
        "tpot_violation": mean_gap is None or mean_gap > float(row.get("tpot_slo_ms", float("inf"))),
        "error": error,
        "load_shed": load_shed,
    }


async def replay(
    trace: Path, output: Path, api_base: str, model: str, tokenizer: str,
    timeout_s: float = 900, arrival_scale: float = 1.0,
    duration_limit_s: float | None = None, allow_load_shedding: bool = False,
) -> None:
    rows = load_trace(trace, arrival_scale, duration_limit_s)
    materializer = PromptMaterializer(tokenizer)
    events = {row["request_id"]: asyncio.Event() for row in rows}
    completion_times: dict[str, int] = {}
    headers = {"Authorization": "Bearer EMPTY"}
    limits = httpx.Limits(max_connections=2048, max_keepalive_connections=256)
    start_ns = time.perf_counter_ns()
    async with httpx.AsyncClient(
        timeout=httpx.Timeout(timeout_s), headers=headers, limits=limits
    ) as client:
        results = await asyncio.gather(*[
            issue(row, client, api_base, model, materializer, start_ns, events, completion_times)
            for row in rows
        ])
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as stream:
        for result in results:
            stream.write(json.dumps(result, ensure_ascii=False) + "\n")
    errors = sum(result["error"] is not None and not (
        allow_load_shedding and result.get("load_shed")
    ) for result in results)
    if errors:
        raise RuntimeError(f"{errors}/{len(results)} requests failed")
