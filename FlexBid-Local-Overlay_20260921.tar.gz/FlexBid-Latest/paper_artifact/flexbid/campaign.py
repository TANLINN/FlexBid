from __future__ import annotations

import csv
import hashlib
import json
import os
import random
import signal
import subprocess
import sys
import time
import urllib.request
import copy
from pathlib import Path
from typing import Any

from .actuation import RuntimeActuator, atomic_write_json
from .config import canonical_hash, resolve_from_config
from .dataset import percentile, summarize_run, write_rows
from .types import Action


def stop_process(process: subprocess.Popen | None, timeout_s: float = 30) -> None:
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGINT)
        process.wait(timeout=timeout_s)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        try:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait(timeout=10)
        except (ProcessLookupError, subprocess.TimeoutExpired):
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=10)


def wait_http(url: str, processes: list[subprocess.Popen], timeout_s: float) -> None:
    deadline = time.monotonic() + timeout_s
    last_error = None
    while time.monotonic() < deadline:
        for process in processes:
            if process.poll() is not None:
                raise RuntimeError(f"service exited with {process.returncode}")
        try:
            with urllib.request.urlopen(url, timeout=3) as response:
                if response.status < 500:
                    return
        except Exception as exc:
            last_error = exc
        time.sleep(2)
    raise TimeoutError(f"timed out waiting for {url}: {last_error}")


def post_json(url: str, payload: dict | None = None, timeout_s: float = 60) -> None:
    body = None if payload is None else json.dumps(payload).encode()
    request = urllib.request.Request(url, data=body, method="POST",
                                     headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout_s) as response:
        if response.status >= 300:
            raise RuntimeError(f"POST {url} returned {response.status}")


def reset_prefix_caches(config: dict, model_config: dict) -> None:
    first_port = int(config["runtime"]["first_vllm_port"])
    for index in range(len(model_config["replicas"])):
        post_json(f"http://127.0.0.1:{first_port + index}/reset_prefix_cache")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def cap_intersection() -> tuple[float, float, float]:
    query = subprocess.run([
        "nvidia-smi", "--query-gpu=power.min_limit,power.max_limit,power.default_limit",
        "--format=csv,noheader,nounits",
    ], check=True, text=True, capture_output=True)
    rows = [[float(item.strip()) for item in line.split(",")] for line in query.stdout.splitlines()]
    return max(row[0] for row in rows), min(row[1] for row in rows), min(row[2] for row in rows)


def sparse_actions(config: dict[str, Any]) -> tuple[list[Action], Action]:
    minimum, maximum, default = cap_intersection()
    action_config = config["actions"]
    caps = sorted({
        round(max(minimum, min(maximum, maximum * float(fraction))) / 5) * 5
        for fraction in action_config["power_cap_fractions"]
    })
    all_actions = [
        Action(int(k), float(cap), int(c))
        for k in action_config["chunk_budgets"] for cap in caps
        for c in action_config["admission_concurrency"]
    ]
    default_action = Action(
        max(action_config["chunk_budgets"]), default,
        max(action_config["admission_concurrency"]),
    )
    # Preserve a complete Pcap-only axis for a fair single-knob baseline,
    # then fill the remaining budget by deterministic maximin coverage of the
    # normalized 3-D action space.
    anchors = {
        Action(default_action.chunk_budget_tokens, cap,
               default_action.admission_concurrency) for cap in caps
    }
    anchors.update({
        Action(default_action.chunk_budget_tokens, default_action.power_cap_w,
               int(concurrency))
        for concurrency in action_config["admission_concurrency"]
    })
    size = int(action_config["sparse_design_size"])
    actions = list(sorted(anchors))
    ranges = (
        max(action_config["chunk_budgets"]) - min(action_config["chunk_budgets"]),
        max(caps) - min(caps),
        max(action_config["admission_concurrency"]) - min(action_config["admission_concurrency"]),
    )

    def distance(left: Action, right: Action) -> float:
        return sum(value * value for value in (
            (left.chunk_budget_tokens - right.chunk_budget_tokens) / max(1, ranges[0]),
            (left.power_cap_w - right.power_cap_w) / max(1, ranges[1]),
            (left.admission_concurrency - right.admission_concurrency) / max(1, ranges[2]),
        ))

    remaining = set(all_actions) - set(actions)
    while remaining and len(actions) < size:
        chosen = max(sorted(remaining), key=lambda candidate: (
            min(distance(candidate, selected) for selected in actions), candidate.key
        ))
        actions.append(chosen)
        remaining.remove(chosen)
    return sorted(actions), default_action


def effective_model_config(results: Path, model_config: dict) -> dict:
    value = copy.deepcopy(model_config)
    path = results / "load_scales.json"
    if path.exists():
        scales = json.loads(path.read_text(encoding="utf-8"))["models"].get(model_config["name"])
        if scales:
            value["arrival_scale_by_source"] = scales
    return value


class ServiceGroup:
    def __init__(self, artifact_root: Path, config: dict, model_config: dict, logs: Path):
        self.artifact_root = artifact_root
        self.config = config
        self.model_config = model_config
        self.logs = logs
        self.processes: list[subprocess.Popen] = []
        self.log_handles = []

    def start(self) -> None:
        runtime = self.config["runtime"]
        first_port = int(runtime["first_vllm_port"])
        control_file = self.config["hardware"]["control_file"]
        pythonpath = str(self.artifact_root)
        ports = []
        for replica_index, gpu_group in enumerate(self.model_config["replicas"]):
            port = first_port + replica_index
            ports.append(port)
            environment = os.environ.copy()
            environment["CUDA_VISIBLE_DEVICES"] = ",".join(map(str, gpu_group))
            environment["FLEXBID_CONTROL_FILE"] = control_file
            environment["VLLM_SERVER_DEV_MODE"] = "1"
            environment["PYTHONPATH"] = pythonpath + os.pathsep + environment.get("PYTHONPATH", "")
            command = [
                "vllm", "serve", self.model_config["name"], "--host", "127.0.0.1",
                "--port", str(port), "--tensor-parallel-size", str(len(gpu_group)),
                "--max-model-len", str(self.model_config["max_model_len"]),
                "--gpu-memory-utilization", str(self.model_config["gpu_memory_utilization"]),
                "--max-num-seqs", str(runtime["max_num_seqs"]),
                "--max-num-batched-tokens", str(runtime["max_num_batched_tokens"]),
                "--enable-chunked-prefill",
                "--enable-prefix-caching",
                "--scheduler-cls", "flexbid.runtime_scheduler.FlexBidScheduler",
            ]
            if self.model_config.get("language_model_only", False):
                command.append("--language-model-only")
            self.logs.mkdir(parents=True, exist_ok=True)
            handle = (self.logs / f"vllm_replica_{replica_index}.log").open("a", encoding="utf-8")
            self.log_handles.append(handle)
            self.processes.append(subprocess.Popen(
                command, stdout=handle, stderr=subprocess.STDOUT,
                env=environment, start_new_session=True,
            ))
        for port in ports:
            wait_http(f"http://127.0.0.1:{port}/health", self.processes, runtime["startup_timeout_s"])
            post_json(f"http://127.0.0.1:{port}/v1/completions", {
                "model": self.model_config["name"], "prompt": [1, 2, 3],
                "max_tokens": 8, "temperature": 0, "ignore_eos": True,
            }, timeout_s=120)
            post_json(f"http://127.0.0.1:{port}/reset_prefix_cache")
        environment = os.environ.copy()
        environment.update({
            "PYTHONPATH": pythonpath + os.pathsep + environment.get("PYTHONPATH", ""),
            "FLEXBID_CONTROL_FILE": control_file,
            "FLEXBID_UPSTREAMS": ",".join(f"http://127.0.0.1:{port}" for port in ports),
            "FLEXBID_INITIAL_CONCURRENCY": str(runtime["initial_concurrency"]),
            "FLEXBID_MAX_QUEUE": str(runtime["max_queue"]),
        })
        gateway_log = (self.logs / "gateway.log").open("a", encoding="utf-8")
        self.log_handles.append(gateway_log)
        gateway = subprocess.Popen([
            sys.executable, "-m", "uvicorn", "flexbid.gateway:app",
            "--host", "127.0.0.1", "--port", str(runtime["gateway_port"]),
        ], stdout=gateway_log, stderr=subprocess.STDOUT, env=environment, start_new_session=True)
        self.processes.append(gateway)
        wait_http(
            f"http://127.0.0.1:{runtime['gateway_port']}/health",
            self.processes, 120,
        )

    def close(self) -> None:
        for process in reversed(self.processes):
            stop_process(process)
        for handle in self.log_handles:
            handle.close()

    def __enter__(self) -> "ServiceGroup":
        try:
            self.start()
        except BaseException:
            self.close()
            raise
        return self

    def __exit__(self, *_exc) -> None:
        self.close()


def validated(run_dir: Path) -> bool:
    marker = run_dir / "CELL_COMPLETE.json"
    if not marker.exists():
        return False
    try:
        value = json.loads(marker.read_text(encoding="utf-8"))
        return value.get("request_errors") == 0 and value.get("telemetry_rows", 0) >= 2
    except Exception:
        return False


def run_cell(
    artifact_root: Path, config: dict, model_config: dict, episode: dict,
    action: Action, split: str, run_dir: Path, actuator: RuntimeActuator,
) -> list[dict]:
    if validated(run_dir):
        return summarize_run(
            run_dir, action=action.as_dict(), split=split,
            episode_id=episode["episode_id"], model=model_config["name"],
            window_s=float(config["evaluation"]["window_s"]),
            measurement_duration_s=float(config["workloads"]["episode_s"]),
        )
    run_dir.mkdir(parents=True, exist_ok=True)
    reset_prefix_caches(config, model_config)
    applied = actuator.apply(action)
    time.sleep(2)
    telemetry = subprocess.Popen([
        sys.executable, "-m", "flexbid.telemetry", "--output", str(run_dir / "components.csv"),
        "--interval-ms", str(config["hardware"]["telemetry_interval_ms"]),
    ], cwd=artifact_root, start_new_session=True)
    replay_started = time.monotonic()
    replay_command = [
        sys.executable, str(artifact_root / "scripts/replay_trace.py"),
        "--trace", episode["path"], "--output", str(run_dir / "requests.jsonl"),
        "--api-base", f"http://127.0.0.1:{config['runtime']['gateway_port']}/v1",
        "--model", model_config["name"], "--tokenizer", model_config["tokenizer"],
        "--arrival-scale", str(model_config.get("arrival_scale_by_source", {}).get(episode["source"], 1.0)),
        "--duration-limit-s", str(config["workloads"]["episode_s"]),
        "--allow-load-shedding",
    ]
    replay = subprocess.run(
        replay_command,
        cwd=artifact_root,
        text=True,
        capture_output=True,
    )
    measurement_s = float(config["workloads"]["episode_s"])
    remaining = measurement_s - (time.monotonic() - replay_started)
    request_path = run_dir / "requests.jsonl"
    if request_path.exists():
        completed_requests = [
            json.loads(line)
            for line in request_path.read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        replay_origins = [
            int(row["dispatch_wall_time_ns"])
            - int(float(row.get("actual_dispatch_ms") or 0) * 1e6)
            for row in completed_requests
            if row.get("dispatch_wall_time_ns") is not None
        ]
        if replay_origins:
            target_end_ns = min(replay_origins) + int(measurement_s * 1e9)
            remaining = (target_end_ns - time.time_ns()) / 1e9
    if remaining > 0:
        time.sleep(remaining)
    time.sleep(max(
        0.5,
        2 * float(config["hardware"]["telemetry_interval_ms"]) / 1000,
    ))
    stop_process(telemetry)
    (run_dir / "replay.stdout.log").write_text(replay.stdout, encoding="utf-8")
    (run_dir / "replay.stderr.log").write_text(replay.stderr, encoding="utf-8")
    requests = [json.loads(line) for line in (run_dir / "requests.jsonl").read_text(
        encoding="utf-8"
    ).splitlines() if line.strip()] if (run_dir / "requests.jsonl").exists() else []
    with (run_dir / "components.csv").open(newline="", encoding="utf-8") as stream:
        telemetry_rows = sum(1 for _ in csv.DictReader(stream))
    marker = {
        "action": applied, "return_code": replay.returncode,
        "request_errors": sum(
            row.get("error") is not None and not row.get("load_shed")
            for row in requests
        ),
        "load_shed_requests": sum(
            bool(row.get("load_shed")) for row in requests
        ),
        "requests": len(requests), "telemetry_rows": telemetry_rows,
    }
    atomic_write_json(run_dir / "CELL_COMPLETE.json", marker)
    if replay.returncode != 0 or marker["request_errors"] or telemetry_rows < 2:
        raise RuntimeError(f"invalid cell {run_dir}: {marker}")
    return summarize_run(
        run_dir, action=action.as_dict(), split=split,
        episode_id=episode["episode_id"], model=model_config["name"],
        window_s=float(config["evaluation"]["window_s"]),
        measurement_duration_s=float(config["workloads"]["episode_s"]),
    )


def run_profile(artifact_root: Path, config_path: Path, config: dict, resume: bool) -> None:
    results = resolve_from_config(config_path, config["paths"]["results_root"])
    manifest = json.loads((resolve_from_config(
        config_path, config["workloads"]["adapted_root"]
    ) / "manifest.json").read_text(encoding="utf-8"))
    if any(item["split"] == "test" and Path(item["path"]).exists() is False for item in manifest["episodes"]):
        raise RuntimeError("dataset manifest is incomplete")
    actions, default_action = sparse_actions(config)
    by_source: dict[str, dict[str, list[dict]]] = {}
    for episode in manifest["episodes"]:
        by_source.setdefault(episode["source"], {}).setdefault(episode["split"], []).append(episode)
    train_limit = int(config["workloads"]["profile_train_episodes_per_source"])
    selected_train = [
        item for source in sorted(by_source)
        for item in by_source[source].get("train", [])[:train_limit]
    ]
    cal_limit = int(config["workloads"]["profile_calibration_episodes_total"])
    selected_cal: list[dict] = []
    offsets = {source: 0 for source in by_source}
    while len(selected_cal) < cal_limit:
        progressed = False
        for source in sorted(by_source):
            values = by_source[source].get("calibration", [])
            index = offsets[source]
            if index < len(values) and len(selected_cal) < cal_limit:
                selected_cal.append(values[index])
                offsets[source] += 1
                progressed = True
        if not progressed:
            break
    if len(selected_cal) < int(config["risk"]["minimum_calibration_episodes"]):
        raise RuntimeError("selected calibration campaign is too small for requested alpha")
    selected_ids = {item["episode_id"] for item in selected_train + selected_cal}
    initial = default_action.as_dict()
    atomic_write_json(Path(config["hardware"]["control_file"]), initial)
    campaign_manifest = {
        "config_hash": canonical_hash(config), "actions": [action.as_dict() for action in actions],
        "default_action": default_action.as_dict(), "phase": "profile",
        "selected_train_episodes": [item["episode_id"] for item in selected_train],
        "selected_calibration_episodes": [item["episode_id"] for item in selected_cal],
    }
    results.mkdir(parents=True, exist_ok=True)
    atomic_write_json(results / "campaign_manifest.json", campaign_manifest)
    all_rows = []
    with RuntimeActuator(Path(config["hardware"]["control_file"]), config["hardware"]["gpu_indices"]) as actuator:
        for model_index, raw_model_config in enumerate(config["models"]):
            model_config = effective_model_config(results, raw_model_config)
            model_slug = model_config["name"].replace("/", "_")
            logs = results / "logs" / model_slug
            with ServiceGroup(artifact_root, config, model_config, logs):
                for episode in manifest["episodes"]:
                    split = episode["split"]
                    if episode["episode_id"] not in selected_ids:
                        continue
                    episode_order = list(actions)
                    episode_seed = int(hashlib.sha256(
                        episode["episode_id"].encode()
                    ).hexdigest()[:8], 16) + int(config["seed"])
                    random.Random(episode_seed).shuffle(episode_order)
                    train_action_limit = int(
                        config["workloads"].get("profile_train_actions_per_episode", 3)
                    )
                    selected = (
                        episode_order if split == "calibration"
                        else episode_order[:train_action_limit]
                    )
                    for action in selected:
                        run_dir = results / "profile" / model_slug / split / episode["episode_id"].replace(":", "_") / action.key
                        all_rows.extend(run_cell(
                            artifact_root, config, model_config, episode, action, split,
                            run_dir, actuator,
                        ))
    dataset_path = results / "surrogate_dataset.csv"
    write_rows(all_rows, dataset_path)
    atomic_write_json(results / "PROFILE_COMPLETE.json", {
        "rows": len(all_rows), "dataset": str(dataset_path), "sha256": sha256(dataset_path),
    })


def run_load_pilot(artifact_root: Path, config_path: Path, config: dict, resume: bool) -> None:
    results = resolve_from_config(config_path, config["paths"]["results_root"])
    marker = results / "LOAD_PILOT_COMPLETE.json"
    if marker.exists() and (results / "load_scales.json").exists():
        return
    manifest = json.loads((resolve_from_config(
        config_path, config["workloads"]["adapted_root"]
    ) / "manifest.json").read_text(encoding="utf-8"))
    first_train = {}
    for episode in manifest["episodes"]:
        if episode["split"] == "train":
            first_train.setdefault(episode["source"], episode)
    actions, default = sparse_actions(config)
    pilot_config = copy.deepcopy(config)
    pilot_config["workloads"]["episode_s"] = 60
    selected_scales, audit = {}, []
    with RuntimeActuator(Path(config["hardware"]["control_file"]), config["hardware"]["gpu_indices"]) as actuator:
        for raw_model in config["models"]:
            model = copy.deepcopy(raw_model)
            slug = model["name"].replace("/", "_")
            selected_scales[model["name"]] = {}
            with ServiceGroup(artifact_root, config, model, results / "pilot_logs" / slug):
                for source, episode in sorted(first_train.items()):
                    initial = float(model.get("arrival_scale_by_source", {}).get(source, 1.0))
                    accepted = None
                    for attempt in range(int(config["workloads"].get("load_pilot_max_attempts", 9))):
                        scale = initial * (2 ** attempt)
                        model["arrival_scale_by_source"] = {**model.get("arrival_scale_by_source", {}), source: scale}
                        run_dir = results / "load_pilot" / slug / source / f"scale_{scale:g}"
                        rows = run_cell(artifact_root, pilot_config, model, episode, default,
                                        "pilot", run_dir, actuator)
                        request_rows = [
                            json.loads(line)
                            for line in (run_dir / "requests.jsonl").read_text(
                                encoding="utf-8"
                            ).splitlines() if line.strip()
                        ]
                        ttft = percentile([
                            float(row["ttft_ms"]) for row in request_rows
                            if row.get("ttft_ms") is not None
                        ], 0.95) or 0
                        tpot = percentile([
                            float(row["mean_tpot_ms"]) for row in request_rows
                            if row.get("mean_tpot_ms") is not None
                        ], 0.99) or 0
                        max_gap_p99 = percentile([
                            float(row["max_tpot_ms"]) for row in request_rows
                            if row.get("max_tpot_ms") is not None
                        ], 0.99)
                        safe = (ttft <= float(config["slos"]["default"]["ttft_ms"])
                                and tpot <= float(config["slos"]["default"]["tpot_ms"])
                                and not any(row.get("load_shed") for row in request_rows))
                        audit.append({"model": model["name"], "source": source, "scale": scale,
                                      "ttft_p95_ms": ttft, "tpot_p99_ms": tpot,
                                      "max_token_gap_p99_ms": max_gap_p99,
                                      "requests": sum(int(row["arrivals"]) for row in rows), "safe": safe})
                        if safe:
                            accepted = scale
                            break
                    if accepted is None:
                        raise RuntimeError(f"load pilot cannot find SLO-safe scale: {model['name']} {source}")
                    selected_scales[model["name"]][source] = accepted
    atomic_write_json(results / "load_scales.json", {"models": selected_scales, "pilot": audit})
    atomic_write_json(marker, {"models": len(selected_scales), "sources": len(first_train),
                               "trials": len(audit)})
