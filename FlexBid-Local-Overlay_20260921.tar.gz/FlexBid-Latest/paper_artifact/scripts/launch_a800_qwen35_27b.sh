#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

config="configs/a800_8gpu_qwen35_27b.yaml"
results_root="results/paper_artifact_a800_qwen35_27b"
model_root="/root/FlexBid-LLM/models/Qwen3.5-27B"

test -f "$model_root/config.json" || {
  echo "missing model config: $model_root/config.json" >&2
  exit 2
}

mkdir -p "$results_root/logs"
python scripts/self_test.py
python scripts/fetch_public_traces.py

nohup python -u scripts/run_all.py --config "$config" \
  > "$results_root/logs/launcher.log" 2>&1 &
echo $! > "$results_root/launcher.pid"
echo "started A800/Qwen3.5-27B campaign PID $(cat "$results_root/launcher.pid")"
