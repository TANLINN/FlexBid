import torch
x=torch.randn((4096,4096),device="cuda",dtype=torch.float16)
y=torch.empty_like(x)
while True:
    torch.mm(x,x,out=y)
    torch.cuda.synchronize()
    x,y=y,x
