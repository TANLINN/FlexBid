#!/usr/bin/env bash
set -u

ROOT="/root/workspace/FlexBid-LLM/paper_artifact"
RESULT="$ROOT/results/paper_artifact_a800_qwen35_27b"
WORKER_FILE="$ROOT/results/night_guard/worker.pids"
EVENT_LOG="$ROOT/results/night_guard/events.log"

cd "$ROOT"
mkdir -p results/night_guard
LAUNCH_PID="$(cat "$RESULT/launcher.pid")"

if ! ps -ww -p "$LAUNCH_PID" -o args= 2>/dev/null | grep -q '[r]un_all.py'; then
    echo "$(date) failure guard refused: launcher not running" >> "$EVENT_LOG"
    exit 2
fi
echo "$(date) failure guard monitoring launcher PID $LAUNCH_PID" >> "$EVENT_LOG"

while ps -ww -p "$LAUNCH_PID" -o args= 2>/dev/null | grep -q '[r]un_all.py'; do
    sleep 15
done

echo "$(date) campaign stopped; activating failure-retention load" >> "$EVENT_LOG"
: > "$WORKER_FILE"
for gpu in 0 1 2 3 4 5 6 7; do
    CUDA_VISIBLE_DEVICES="$gpu" python scripts/gpu_retention_worker.py \
        >> results/night_guard/workers.log 2>&1 &
    echo $! >> "$WORKER_FILE"
done
wait
