#!/usr/bin/env bash
set -u

ROOT="/root/workspace/FlexBid-LLM/paper_artifact"
RESULT="$ROOT/results/paper_artifact_a800_qwen35_27b"
LOG="$RESULT/logs/launcher.log"
WORKER_FILE="$ROOT/results/night_guard/offline_worker.pids"
EVENT_LOG="$ROOT/results/night_guard/events.log"

cd "$ROOT"
mkdir -p results/night_guard
LAUNCH_PID="$(cat "$RESULT/launcher.pid")"

cleanup() {
    if [ -s "$WORKER_FILE" ]; then
        while read -r worker; do
            kill -TERM "$worker" 2>/dev/null || true
        done < "$WORKER_FILE"
    fi
    echo "$(date) offline guard stopped; workers cleaned" >> "$EVENT_LOG"
}
trap cleanup EXIT INT TERM

if ! ps -ww -p "$LAUNCH_PID" -o args= 2>/dev/null | grep -q '[r]un_all.py'; then
    echo "$(date) offline guard refused: launcher not running" >> "$EVENT_LOG"
    exit 2
fi
if grep -q '"phase": "closed-loop"' "$LOG"; then
    echo "$(date) offline guard not needed: closed-loop started" >> "$EVENT_LOG"
    exit 0
fi

: > "$WORKER_FILE"
for gpu in 0 1 2 3 4 5 6 7; do
    CUDA_VISIBLE_DEVICES="$gpu" python scripts/gpu_retention_worker.py \
        >> results/night_guard/offline_workers.log 2>&1 &
    echo $! >> "$WORKER_FILE"
done
echo "$(date) offline GPU retention started for launcher $LAUNCH_PID" >> "$EVENT_LOG"

while ps -ww -p "$LAUNCH_PID" -o args= 2>/dev/null | grep -q '[r]un_all.py'; do
    if grep -q '"phase": "closed-loop"' "$LOG"; then
        echo "$(date) closed-loop detected; removing offline GPU load" >> "$EVENT_LOG"
        exit 0
    fi
    sleep 1
done
echo "$(date) launcher stopped; handing protection to failure guard" >> "$EVENT_LOG"
