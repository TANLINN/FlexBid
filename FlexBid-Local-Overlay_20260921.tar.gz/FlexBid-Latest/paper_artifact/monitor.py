import subprocess
import time
import sys

def get_avg_gpu_utilization():
    """通过 nvidia-smi 获取所有 GPU 的平均利用率"""
    try:
        # 执行 nvidia-smi 命令获取单纯的数字
        result = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"], 
            encoding="utf-8"
        )
        # 解析输出
        utils = [int(x.strip()) for x in result.strip().split('\n') if x.strip().isdigit()]
        if not utils:
            return 100
        return sum(utils) / len(utils)
    except Exception as e:
        print(f"获取 GPU 状态失败: {e}")
        return 100 # 如果出错，假装是满载，防止误触发烧机程序

def main():
    # ---------------- 配置区 ----------------
    THRESHOLD = 10       # 触发阈值：平均利用率低于 10% 视为闲置
    CHECK_INTERVAL = 10  # 检查间隔：每 10 秒检查一次
    STRIKE_LIMIT = 3     # 容错次数：连续 3 次低于阈值才触发 (防止程序正常换代/保存权重时 GPU 瞬时掉零)
    # ----------------------------------------

    print(f"🚀 开始监控 GPU... (阈值: {THRESHOLD}%, 检查间隔: {CHECK_INTERVAL}秒)")
    strikes = 0
    
    try:
        while True:
            avg_util = get_avg_gpu_utilization()
            print(f"[{time.strftime('%H:%M:%S')}] 当前 8 卡平均利用率: {avg_util:.1f}%")
            
            if avg_util < THRESHOLD:
                strikes += 1
                print(f"⚠️ 警告: 利用率过低！({strikes}/{STRIKE_LIMIT})")
                
                if strikes >= STRIKE_LIMIT:
                    print("🚨 确认主程序可能已停止或中断，正在启动保活空算程序 (gpu_burn.py)...")
                    
                    # 使用当前的 Python 环境启动 gpu_burn.py
                    subprocess.run([sys.executable, "gpu_burn.py"])
                    
                    # 如果你按 Ctrl+C 关掉了 gpu_burn，跳出循环退出监控
                    break
            else:
                if strikes > 0:
                    print("✅ 利用率恢复正常，取消警告。")
                strikes = 0
                
            time.sleep(CHECK_INTERVAL)
            
    except KeyboardInterrupt:
        print("\n监控已手动停止。")

if __name__ == "__main__":
    main()

