from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_completed(path: Path) -> set[str]:
    if not path.exists():
        return set()
    completed = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        if row.get("terminal", False):
            completed.add(str(row["case_id"]))
    return completed


def append_jsonl(path: Path, row: dict[str, Any]) -> None:
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(row, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def run_command(
    command: list[str],
    log: Path,
    environment: dict[str, str],
    timeout_s: float,
) -> tuple[str, int | None, float]:
    started = time.monotonic()
    with log.open("a", encoding="utf-8") as handle:
        handle.write("COMMAND=" + json.dumps(command) + "\n")
        handle.flush()
        try:
            result = subprocess.run(
                command,
                cwd=Path(__file__).resolve().parents[1],
                env=environment,
                stdout=handle,
                stderr=subprocess.STDOUT,
                timeout=timeout_s,
                check=False,
            )
            return (
                "PASS" if result.returncode == 0 else "FAILED",
                result.returncode,
                time.monotonic() - started,
            )
        except subprocess.TimeoutExpired:
            handle.write(f"TIMEOUT_AFTER_S={timeout_s}\n")
            handle.flush()
            return "TIMEOUT", None, time.monotonic() - started


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Checkpointed exact-oracle scaling sweep. Cases that fail or time "
            "out are recorded and the sweep continues."
        )
    )
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--windows", type=int, nargs="+", default=[0, 1, 2, 3])
    parser.add_argument(
        "--request-counts", type=int, nargs="+",
        default=[8, 10, 12, 14, 16, 18, 20, 22],
    )
    parser.add_argument(
        "--epoch-ms", type=float, nargs="+",
        default=[100, 250, 500, 1000, 2000],
    )
    parser.add_argument("--max-states", type=int, default=500_000)
    parser.add_argument("--case-timeout-s", type=float, default=900.0)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    output_root = args.output_root.resolve()
    cases_root = output_root / "cases"
    cases_root.mkdir(parents=True, exist_ok=True)
    summary = output_root / "summary.jsonl"
    completed = load_completed(summary)
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(root)
    total = len(args.windows) * len(args.request_counts) * len(args.epoch_ms)
    planned = {
        "status": "RUNNING",
        "started_unix_s": time.time(),
        "total_cases": total,
        "windows": args.windows,
        "request_counts": args.request_counts,
        "epoch_ms": args.epoch_ms,
        "max_states": args.max_states,
        "case_timeout_s": args.case_timeout_s,
    }
    (output_root / "SWEEP_DESIGN.json").write_text(
        json.dumps(planned, indent=2), encoding="utf-8"
    )

    index = 0
    for window in args.windows:
        config = root / "configs" / f"real_window_{window:02d}.generated.yaml"
        if not config.is_file():
            raise FileNotFoundError(config)
        for request_count in args.request_counts:
            for epoch_ms in args.epoch_ms:
                index += 1
                epoch_label = str(epoch_ms).replace(".", "p")
                case_id = f"w{window:02d}_n{request_count}_e{epoch_label}"
                if case_id in completed:
                    print(f"SKIP {index}/{total} {case_id}", flush=True)
                    continue
                case_root = cases_root / case_id
                case_root.mkdir(parents=True, exist_ok=True)
                problem = case_root / "problem.json"
                solution = case_root / "solution.json"
                log = case_root / "case.log"
                print(f"START {index}/{total} {case_id}", flush=True)

                build_command = [
                    sys.executable,
                    str(root / "scripts" / "build_offline_oracle_problem.py"),
                    "--config", str(config),
                    "--output", str(problem),
                    "--max-requests", str(request_count),
                    "--epoch-ms", str(epoch_ms),
                ]
                build_status, build_rc, build_s = run_command(
                    build_command, log, environment,
                    min(300.0, args.case_timeout_s),
                )
                row: dict[str, Any] = {
                    "case_id": case_id,
                    "window": window,
                    "request_count": request_count,
                    "epoch_ms": epoch_ms,
                    "build_status": build_status,
                    "build_returncode": build_rc,
                    "build_duration_s": build_s,
                    "terminal": True,
                }
                if build_status == "PASS":
                    solve_command = [
                        sys.executable,
                        str(root / "scripts" / "solve_offline_oracle.py"),
                        "--input", str(problem),
                        "--output", str(solution),
                        "--max-states", str(args.max_states),
                    ]
                    solve_status, solve_rc, solve_s = run_command(
                        solve_command, log, environment, args.case_timeout_s
                    )
                    row.update({
                        "solve_status": solve_status,
                        "solve_returncode": solve_rc,
                        "solve_duration_s": solve_s,
                    })
                    if solve_status == "PASS":
                        solved = json.loads(solution.read_text(encoding="utf-8"))
                        row.update({
                            "objective_carbon_g": solved["cost"]["objective_carbon_g"],
                            "migrations": solved["cost"]["migrations"],
                            "explored_transitions": solved["explored_transitions"],
                            "max_frontier": max(solved["frontier_sizes"]),
                            "problem_sha256": solved["problem_sha256"],
                            "solution_sha256": sha256(solution),
                        })
                append_jsonl(summary, row)
                print(
                    f"FINISH {index}/{total} {case_id} "
                    f"build={row['build_status']} "
                    f"solve={row.get('solve_status', 'NOT_RUN')}",
                    flush=True,
                )

    records = [
        json.loads(line)
        for line in summary.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    final = {
        **planned,
        "status": "COMPLETE",
        "completed_unix_s": time.time(),
        "recorded_cases": len(records),
        "passed_cases": sum(row.get("solve_status") == "PASS" for row in records),
        "timed_out_cases": sum(row.get("solve_status") == "TIMEOUT" for row in records),
        "failed_cases": sum(
            row.get("build_status") != "PASS"
            or row.get("solve_status") not in {"PASS", "TIMEOUT"}
            for row in records
        ),
        "summary_sha256": sha256(summary),
    }
    (output_root / "SWEEP_COMPLETE.json").write_text(
        json.dumps(final, indent=2), encoding="utf-8"
    )
    print("OFFLINE_ORACLE_SWEEP_COMPLETE =", output_root, flush=True)


if __name__ == "__main__":
    main()
