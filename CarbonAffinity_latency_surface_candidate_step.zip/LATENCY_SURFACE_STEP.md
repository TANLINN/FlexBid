# Latency-surface candidate step

This step does not overwrite `profiles/*.json` and does not change the frozen
energy model.

It fits an 18-cell steady-state latency surface over:

- mode: cold / warm;
- prompt tokens: 2048 / 8192 / 32768;
- concurrency: 1 / 4 / 8.

The eight synchronized `cold, 2048, concurrency=1, repeat=0` startup rows are
preserved in the report but excluded from the steady-state fit.  Uncertainty
margins are calibrated with leave-one-GPU-out validation.

Run on the server:

```bash
cd /root/CarbonAffinity
source .venv/bin/activate

GATE=/root/CarbonAffinity/results/new_server_latency_gate_20260827T120555Z
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$PWD/results/latency_surface_candidate_$STAMP"
mkdir -p "$OUT"

PYTHONPATH="$PWD" python scripts/fit_latency_surface.py \
  --input-root "$GATE" \
  --output-model "$OUT/latency_surface_candidate.json" \
  --output-report "$OUT/latency_surface_fit_report.json" \
  | tee "$OUT/latency_surface_fit_report.txt"

sha256sum \
  "$OUT/latency_surface_candidate.json" \
  "$OUT/latency_surface_fit_report.json" \
  | tee "$OUT/SHA256SUMS"

echo "$OUT" > results/latency_surface_candidate_latest.txt
```

Expected integrity facts:

- `rows_used = 280`;
- `startup_rows_excluded` contains exactly 8 records, one for every GPU;
- `cells = 18`;
- 8 leave-one-GPU-out folds;
- model status remains `CANDIDATE_REQUIRES_INDEPENDENT_VALIDATION`.

Do not install the candidate into the production profiles yet.  The next step
is a fresh 144-row run after explicit server warmup, followed by
`validate_latency_surface.py`.
