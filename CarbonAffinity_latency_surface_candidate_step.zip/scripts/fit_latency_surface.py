from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path


REQUIRED_FIELDS = {
    "gpu_index",
    "prompt_tokens",
    "mode",
    "concurrency",
    "repeat",
    "ttft_p95_ms",
    "tpot_p95_ms",
}


def quantile(values: list[float], q: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, math.ceil(q * len(ordered)) - 1))
    return float(ordered[index])


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_rows(root: Path) -> tuple[list[dict], list[dict], list[dict]]:
    rows: list[dict] = []
    excluded: list[dict] = []
    sources: list[dict] = []
    for path in sorted(root.rglob("*.jsonl")):
        file_rows = 0
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if not REQUIRED_FIELDS.issubset(row):
                continue
            file_rows += 1
            # The first cold 2K/c=1 inference on every newly started server was
            # a synchronized ~12.5 s startup event.  Keep a complete exclusion
            # record; do not silently winsorize or mix it into steady state.
            if (
                row["mode"] == "cold"
                and int(row["prompt_tokens"]) == 2048
                and int(row["concurrency"]) == 1
                and int(row["repeat"]) == 0
            ):
                excluded.append({
                    "source": path.as_posix(),
                    "gpu_index": int(row["gpu_index"]),
                    "ttft_p95_ms": float(row["ttft_p95_ms"]),
                    "reason": "first-shape server startup; excluded from steady-state model",
                })
                continue
            rows.append(row)
        if file_rows:
            sources.append({
                "path": path.as_posix(),
                "sha256": sha256(path),
                "measurement_rows": file_rows,
            })
    return rows, excluded, sources


def key(row: dict) -> tuple[str, int, int]:
    return row["mode"], int(row["prompt_tokens"]), int(row["concurrency"])


def fit_cells(rows: list[dict], excluded_gpu: int | None = None) -> dict:
    grouped: dict[tuple[str, int, int], list[dict]] = defaultdict(list)
    for row in rows:
        if excluded_gpu is None or int(row["gpu_index"]) != excluded_gpu:
            grouped[key(row)].append(row)
    return {
        cell: {
            "ttft_ms": statistics.median(float(row["ttft_p95_ms"]) for row in values),
            "tpot_ms": statistics.median(float(row["tpot_p95_ms"]) for row in values),
            "samples": len(values),
        }
        for cell, values in grouped.items()
    }


def summarize(values: list[float]) -> dict:
    return {
        "samples": len(values),
        "median": statistics.median(values) if values else None,
        "q90": quantile(values, 0.90),
        "q95": quantile(values, 0.95),
        "q975": quantile(values, 0.975),
        "max": max(values) if values else None,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fit a pooled steady-state TTFT/TPOT surface without modifying profiles."
    )
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output-model", type=Path, required=True)
    parser.add_argument("--output-report", type=Path, required=True)
    parser.add_argument("--quantile", type=float, default=0.95)
    args = parser.parse_args()

    rows, excluded, sources = load_rows(args.input_root)
    if not rows:
        raise RuntimeError("no compatible latency measurements")
    modes = sorted({str(row["mode"]) for row in rows})
    prompts = sorted({int(row["prompt_tokens"]) for row in rows})
    concurrencies = sorted({int(row["concurrency"]) for row in rows})
    gpus = sorted({int(row["gpu_index"]) for row in rows})
    expected_cells = {
        (mode, prompt, concurrency)
        for mode in ("cold", "warm")
        for prompt in prompts
        for concurrency in concurrencies
    }
    if modes != ["cold", "warm"]:
        raise RuntimeError(f"expected cold/warm modes, found {modes}")

    final_cells = fit_cells(rows)
    missing = sorted(expected_cells - set(final_cells))
    if missing:
        raise RuntimeError(f"missing latency cells: {missing}")

    residuals: dict[str, dict[str, list[float]]] = {
        mode: {"ttft_ms": [], "tpot_ms": []} for mode in modes
    }
    absolute_errors: dict[str, list[float]] = {"ttft_ms": [], "tpot_ms": []}
    fold_rows = []
    for gpu in gpus:
        fold = fit_cells(rows, excluded_gpu=gpu)
        heldout = [row for row in rows if int(row["gpu_index"]) == gpu]
        for row in heldout:
            prediction = fold[key(row)]
            mode = str(row["mode"])
            for metric, field in (("ttft_ms", "ttft_p95_ms"), ("tpot_ms", "tpot_p95_ms")):
                actual = float(row[field])
                predicted = float(prediction[metric])
                residuals[mode][metric].append(max(0.0, actual - predicted))
                absolute_errors[metric].append(abs(actual - predicted))
        fold_rows.append({"heldout_gpu": gpu, "rows": len(heldout)})

    margins = {
        mode: {
            metric: quantile(values, args.quantile)
            for metric, values in by_metric.items()
        }
        for mode, by_metric in residuals.items()
    }
    covered = {"ttft_ms": 0, "tpot_ms": 0}
    totals = {"ttft_ms": 0, "tpot_ms": 0}
    for gpu in gpus:
        fold = fit_cells(rows, excluded_gpu=gpu)
        for row in (item for item in rows if int(item["gpu_index"]) == gpu):
            prediction = fold[key(row)]
            mode = str(row["mode"])
            for metric, field in (("ttft_ms", "ttft_p95_ms"), ("tpot_ms", "tpot_p95_ms")):
                upper = float(prediction[metric]) + margins[mode][metric]
                covered[metric] += float(row[field]) <= upper
                totals[metric] += 1

    model = {
        "schema_version": 1,
        "kind": "pooled_steady_state_latency_surface",
        "status": "CANDIDATE_REQUIRES_INDEPENDENT_VALIDATION",
        "semantics": (
            "server-side p95 latency; excludes queue waiting and network RTT; "
            "partial-cache requests interpolate cold and warm endpoints"
        ),
        "prompt_interpolation": "linear_in_log2_tokens_clamped",
        "concurrency_interpolation": "linear_clamped",
        "prompt_buckets": prompts,
        "concurrency_buckets": concurrencies,
        "one_sided_q95_residual_ms": margins,
        "cells": {
            f"{mode}|{prompt}|{concurrency}": value
            for (mode, prompt, concurrency), value in sorted(final_cells.items())
        },
        "training": {
            "input_root": args.input_root.resolve().as_posix(),
            "rows_used": len(rows),
            "startup_rows_excluded": len(excluded),
            "gpus": gpus,
            "leave_one_gpu_out": True,
            "sources": sources,
        },
    }
    report = {
        "schema_version": 1,
        "rows_used": len(rows),
        "startup_rows_excluded": excluded,
        "gpus": gpus,
        "cells": len(final_cells),
        "folds": fold_rows,
        "one_sided_q95_residual_ms": margins,
        "leave_one_gpu_out_absolute_error_ms": {
            metric: summarize(values) for metric, values in absolute_errors.items()
        },
        "post_margin_coverage": {
            metric: covered[metric] / totals[metric] for metric in covered
        },
        "model_status": model["status"],
    }
    args.output_model.parent.mkdir(parents=True, exist_ok=True)
    args.output_report.parent.mkdir(parents=True, exist_ok=True)
    args.output_model.write_text(json.dumps(model, indent=2), encoding="utf-8")
    args.output_report.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"LATENCY_SURFACE_CANDIDATE={args.output_model.resolve()}")
    print("LATENCY_SURFACE_FIT_COMPLETE")


if __name__ == "__main__":
    main()
