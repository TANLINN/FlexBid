# 单张低保 A800：首次四小时试跑手册

本次试跑只验证三件事：低保 A800 是否真的能运行 Qwen3.5-27B、完整软件链路是否可用、下一次租机能否一键启动。两个逻辑区域共用同一个 vLLM 端点，因此本次路由和碳结果不能写进论文。

## 0. “低保”到底要测什么

低保常常代表较低调度优先级、CPU/内存/磁盘缩水或可抢占，不一定代表 GPU 芯片缩水。不能看商品名判断，必须实测：

- 硬门槛：A800、约 80 GiB 总显存且启动前至少 70 GiB 空闲、BF16、至少 64 GiB 主机内存、至少 100 GiB 空闲磁盘、vLLM 可用、GPU 无其他计算进程；
- 建议值：主机内存不少于 96 GiB，空闲磁盘不少于 150 GiB；
- 性能记录：8192 方阵 BF16 matmul 有效 TFLOPS、显存复制带宽、时钟、P-state 和功率上限。

显存/内存/磁盘决定 27B 能不能加载；TFLOPS 和带宽主要用于发现低保实例是否被严重限频，并估计四小时能完成多少实验。不同 PyTorch/vLLM 内核下不设置武断的通用 TFLOPS 及格线。

上传代码后，**先不要下载模型**：

```bash
cd /root/CarbonAffinity
chmod +x scripts/*.sh
mkdir -p results/bootstrap

python3 scripts/probe_one_gpu_capability.py \
  --gpu-index 0 \
  --workdir /root \
  --target-model qwen35_27b \
  --output results/bootstrap/capability_report.json
```

查看结论：

```bash
grep -E '"candidate"|"qwen35_27b_bf16_candidate"|"matmul_effective_tflops"|"device_copy_effective_gbps"' \
  results/bootstrap/capability_report.json
```

只有 `qwen35_27b_bf16_candidate: true` 才走下面的 27B 路径。探测失败仍会留下完整 JSON；先把这个文件发回来，不要盲目下载 27B。

## 1. 所有下载均走镜像

脚本的默认下载路径为：

- Python 包：阿里云 PyPI 镜像；
- 模型：ModelScope 的 `Qwen/Qwen3.5-27B`；
- Hugging Face：只配置 `hf-mirror.com` 作为备用；正式运行使用本地模型，并强制 `HF_HUB_OFFLINE=1`、`TRANSFORMERS_OFFLINE=1`；
- 数据：单卡试跑使用仓库内置微型 trace 和碳数据，不下载 BurstGPT/Azure 等公开数据集。

如平台提供内部 PyPI 镜像，只需覆盖变量：

```bash
export PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/
export HF_ENDPOINT=https://hf-mirror.com
```

脚本会清除可能残留的 `PIP_EXTRA_INDEX_URL`，避免同时访问外网源。ModelScope 以 `--no-deps` 安装，防止改坏镜像自带的 torch/vLLM/transformers 组合。

## 2A. 能力探测通过：下载并验证 Qwen3.5-27B

```bash
cd /root/CarbonAffinity

DOWNLOAD_MODEL=1 \
TARGET_MODEL=qwen35_27b \
MODEL_ID=Qwen/Qwen3.5-27B \
MODEL_DIR=/root/models/Qwen3.5-27B \
PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/ \
nohup bash scripts/bootstrap_one_gpu.sh \
  > results/bootstrap/bootstrap.log 2>&1 &

echo $! > results/bootstrap/bootstrap.pid
tail -f results/bootstrap/bootstrap.log
```

若模型已经存在，把 `DOWNLOAD_MODEL=1` 改成 `DOWNLOAD_MODEL=0`。成功标志是 `BOOTSTRAP_COMPLETE`。

```bash
du -sh /root/models/Qwen3.5-27B
cat results/bootstrap/environment_report.json
```

## 2B. 27B 不通过：只用 9B 检查软件链路

这条路径仅用于排除代码、API、遥测和数据格式问题，结果不得用于论文，也不能证明 27B 可以运行：

```bash
cd /root/CarbonAffinity

DOWNLOAD_MODEL=1 \
TARGET_MODEL=smoke_only \
MODEL_ID=Qwen/Qwen3.5-9B \
MODEL_DIR=/root/models/Qwen3.5-9B \
PIP_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/ \
nohup bash scripts/bootstrap_one_gpu.sh \
  > results/bootstrap/bootstrap.log 2>&1 &

echo $! > results/bootstrap/bootstrap.pid
tail -f results/bootstrap/bootstrap.log
```

## 3. 启动本地 vLLM

27B 路径：

```bash
cd /root/CarbonAffinity

MODEL_DIR=/root/models/Qwen3.5-27B \
SERVED_MODEL_NAME=Qwen3.5-27B \
GPU_INDEX=0 \
bash scripts/start_vllm_one_gpu.sh
```

9B 兜底路径只需替换两个变量：

```bash
MODEL_DIR=/root/models/Qwen3.5-9B \
SERVED_MODEL_NAME=Qwen3.5-9B \
GPU_INDEX=0 \
bash scripts/start_vllm_one_gpu.sh
```

检查：

```bash
tail -n 100 results/vllm/server.log
curl http://127.0.0.1:18000/health
curl http://127.0.0.1:18000/v1/models
```

默认是 TP=1、32k 上下文、prefix caching、最多 8 个序列。若启动失败，保留完整日志，不要连续随意修改参数。

## 4. 一键跑完整 smoke flow

27B：

```bash
MODEL_DIR=/root/models/Qwen3.5-27B \
SERVED_MODEL_NAME=Qwen3.5-27B \
GPU_INDEX=0 \
API_BASE=http://127.0.0.1:18000/v1 \
bash scripts/run_single_gpu_smoke.sh \
  2>&1 | tee results/single_gpu_smoke_console.log
```

9B 兜底时将 `MODEL_DIR` 与 `SERVED_MODEL_NAME` 替换为 9B。脚本会完成冷/热前缀标定、双逻辑区域配置、100 ms NVML 遥测、四轮多会话 replay、状态更新与审计。

成功标志：

```text
SINGLE_GPU_SMOKE_COMPLETE=/root/CarbonAffinity/results/single_gpu_smoke/<timestamp>
```

核验：

```bash
RUN_DIR="$(find results/single_gpu_smoke -mindepth 1 -maxdepth 1 -type d | sort | tail -n 1)"
cat "$RUN_DIR/audit.json"
wc -l "$RUN_DIR/requests.jsonl" "$RUN_DIR/gpu.csv"
grep -R -n -E 'Traceback|ERROR|Exception|failed' "$RUN_DIR" results/vllm/server.log | tail -n 100
```

预期请求数为 4、请求失败数为 0、遥测非空。

## 5. 打包下次租机所需信息

```bash
MODEL_DIR=/root/models/Qwen3.5-27B \
bash scripts/collect_reuse_bundle.sh
```

9B 路径相应替换模型目录。下载脚本打印的 `reuse_bundle_*.tar.gz`。模型权重不会被重复打包；正式实验前应制作平台镜像、快照或持久卷。

需要发回的文件：

```text
results/bootstrap/capability_report.json
results/bootstrap/environment_report.json
results/bootstrap/bootstrap.log
results/vllm/server.log
results/single_gpu_smoke/<timestamp>/audit.json
results/single_gpu_smoke/<timestamp>/requests.jsonl
results/single_gpu_smoke/<timestamp>/gpu.csv
results/reuse_bundle_<timestamp>.tar.gz
```

只有 27B 路径产生 `SMOKE_COMPLETE` 且审计通过，才说明该类低保 A800 可进入正式双区域实验准备；9B 通过只说明软件流程正确。
