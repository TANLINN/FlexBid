from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from carbonaffinity.carbon import CarbonTrace, carbon_grams
from carbonaffinity.config import validate_config
from carbonaffinity.models import RegionSnapshot, RequestSpec
from carbonaffinity.policy import PolicySettings, RouterPolicy
from carbonaffinity.profile import HardwareProfile
from carbonaffinity.state import StateDirectory


def profile(region: str) -> HardwareProfile:
    return HardwareProfile(
        region_id=region,
        accelerator="A800",
        model="Qwen3.5-27B",
        base_request_j=0,
        cold_prefill_j_per_token=1.0,
        cached_prefill_j_per_token=0.01,
        decode_j_per_token=0,
        base_ttft_ms=10,
        cold_prefill_ms_per_token=0.1,
        cached_prefill_ms_per_token=0.001,
        base_tpot_ms=10,
        queue_ttft_ms_per_request=10,
    )


class CoreTests(unittest.TestCase):
    def carbon_trace(self, directory: Path, missing_b: bool = False) -> CarbonTrace:
        path = directory / "carbon.csv"
        lines = [
            "timestamp,region_id,forecast_lbs_per_mwh,historical_lbs_per_mwh",
            "1000,region_a,500,510",
        ]
        if not missing_b:
            lines.append("1000,region_b,100,110")
        path.write_text("\n".join(lines), encoding="utf-8")
        return CarbonTrace.from_csv(path, max_age_s=100)

    def test_carbon_unit_conversion(self) -> None:
        self.assertAlmostEqual(carbon_grams(3_600_000, 1000), 453.59237, places=5)

    def test_cache_requires_explicit_shared_prefix_and_expires(self) -> None:
        state = StateDirectory()
        original = RequestSpec("a", 0, 1000, 10, "s", shared_prefix_tokens=0)
        state.update(original, "region_a", 1000, 10)
        no_evidence = RequestSpec("b", 1, 1100, 10, "s", shared_prefix_tokens=0)
        shared = RequestSpec("c", 2, 1100, 10, "s", shared_prefix_tokens=900)
        self.assertEqual(state.reusable_tokens("s", "region_a", no_evidence, 1001), 0)
        self.assertEqual(state.reusable_tokens("s", "region_a", shared, 1001), 900)
        self.assertEqual(state.reusable_tokens("s", "region_a", shared, 1011), 0)

    def test_state_aware_policy_can_prefer_cached_dirtier_region(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary))
            state = StateDirectory()
            prime = RequestSpec("prime", 0, 1000, 1, "session")
            state.update(prime, "region_a", 1000, 100)
            request = RequestSpec("turn", 1, 1000, 1, "session", shared_prefix_tokens=1000)
            policy = RouterPolicy(
                PolicySettings(migration_hysteresis_g=0), carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")}, state,
            )
            snapshots = {
                "region_a": RegionSnapshot("region_a", 0, 0),
                "region_b": RegionSnapshot("region_b", 0, 0),
            }
            decision = policy.decide(request, snapshots, 1001, 1001)
            self.assertEqual(decision.selected_region, "region_a")
            expired = policy.decide(request, snapshots, 1101, 1001)
            self.assertEqual(expired.selected_region, "region_b")

    def test_missing_carbon_falls_back_to_pressure(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary), missing_b=True)
            state = StateDirectory()
            policy = RouterPolicy(
                PolicySettings(), carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")}, state,
            )
            request = RequestSpec("x", 0, 10, 1, "x")
            snapshots = {
                "region_a": RegionSnapshot("region_a", 0, 2),
                "region_b": RegionSnapshot("region_b", 0, 0),
            }
            decision = policy.decide(request, snapshots, 1001, 1001)
            self.assertTrue(decision.fallback)
            self.assertEqual(decision.policy, "pressure_only")
            self.assertEqual(decision.selected_region, "region_b")

    def test_adaptive_lease_can_release_cache_under_high_shadow_cost(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            carbon = self.carbon_trace(Path(temporary))
            settings = PolicySettings(
                migration_hysteresis_g=0,
                ttl_candidates_s=(0, 60, 300),
                memory_shadow_g_per_gib_s=1000,
                kv_bytes_per_token=1_000_000,
                return_models={"default": {"return_probability": 0.9, "mean_gap_s": 30}},
            )
            policy = RouterPolicy(
                settings, carbon,
                {"region_a": profile("region_a"), "region_b": profile("region_b")},
                StateDirectory(),
            )
            request = RequestSpec("lease", 0, 1000, 1, "lease")
            snapshots = {
                "region_a": RegionSnapshot("region_a", 0, 0),
                "region_b": RegionSnapshot("region_b", 0, 0),
            }
            decision = policy.decide(request, snapshots, 1001, 1001)
            self.assertEqual(decision.lease_ttl_s, 0)
            self.assertIn("max lease value", decision.lease_reason)

    def test_main_config_rejects_tp8(self) -> None:
        config = {
            "regions": [
                {"id": "a", "model": "m", "api_base": "x", "profile": "p", "gpu_count": 8, "tensor_parallel_size": 8},
                {"id": "b", "model": "m", "api_base": "y", "profile": "q", "gpu_count": 1, "tensor_parallel_size": 1},
            ]
        }
        with self.assertRaisesRegex(ValueError, "gpu_count"):
            validate_config(config)


if __name__ == "__main__":
    unittest.main()
