# CarbonAffinity LaTeX draft

This folder contains the paper-style research plan.

Files:

- `main.tex`: paper-style research plan and system design.
- `references.bib`: references used by the draft.

Generic build:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

The current class is a portable two-column `article` draft. Replace the
document class and margins after selecting a target venue template; the paper
content does not depend on a venue-specific package.

