from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class RequestSpec:
    request_id: str
    arrival_ms: float
    prompt_tokens: int
    max_output_tokens: int
    session_id: str
    turn_id: int = 0
    parent_request_id: str | None = None
    tool_delay_ms: float = 0.0
    shared_prefix_tokens: int = 0
    ttft_slo_ms: float = 5000.0
    tpot_slo_ms: float = 200.0
    workload: str = "unknown"
    prompt: str | None = None
    carbon_timestamp_s: float | None = None

    @classmethod
    def from_dict(cls, raw: dict[str, Any]) -> "RequestSpec":
        request_id = str(raw["request_id"])
        return cls(
            request_id=request_id,
            arrival_ms=float(raw.get("arrival_ms", 0.0)),
            prompt_tokens=int(raw["prompt_tokens"]),
            max_output_tokens=int(raw.get("max_output_tokens", raw.get("output_tokens", 128))),
            session_id=str(raw.get("session_id") or request_id),
            turn_id=int(raw.get("turn_id", raw.get("workflow_step", 0))),
            parent_request_id=(str(raw["parent_request_id"]) if raw.get("parent_request_id") else None),
            tool_delay_ms=float(raw.get("tool_delay_ms", 0.0)),
            shared_prefix_tokens=max(0, int(raw.get("shared_prefix_tokens", raw.get("cache_prefix_tokens", 0)))),
            ttft_slo_ms=float(raw.get("ttft_slo_ms", 5000.0)),
            tpot_slo_ms=float(raw.get("tpot_slo_ms", 200.0)),
            workload=str(raw.get("workload", raw.get("source", "unknown"))),
            prompt=raw.get("prompt"),
            carbon_timestamp_s=(float(raw["carbon_timestamp_s"]) if raw.get("carbon_timestamp_s") is not None else None),
        )


@dataclass(frozen=True)
class CarbonObservation:
    region_id: str
    forecast_lbs_per_mwh: float | None
    historical_lbs_per_mwh: float | None
    source_timestamp_s: float | None
    stale: bool


@dataclass(frozen=True)
class RegionSnapshot:
    region_id: str
    active_requests: int
    queue_depth: int
    healthy: bool = True
    rtt_ms: float = 0.0
    capacity: int = 1


@dataclass
class CacheEntry:
    session_id: str
    region_id: str
    prefix_tokens: int
    turn_id: int
    expires_at_s: float
    updated_at_s: float
    observed_cached_tokens: int | None = None
    cache_salt: str | None = None

    def reusable_tokens(self, request: RequestSpec, now_s: float) -> int:
        if now_s >= self.expires_at_s:
            return 0
        # Session identity alone is not evidence that token prefixes match.
        requested = request.shared_prefix_tokens
        return max(0, min(self.prefix_tokens, requested, request.prompt_tokens))


@dataclass(frozen=True)
class CandidateEstimate:
    region_id: str
    cached_tokens: int
    energy_j: float
    ttft_ms: float
    tpot_ms: float
    forecast_lbs_per_mwh: float | None
    forecast_carbon_g: float | None
    slo_feasible: bool
    in_domain: bool
    score: float
    state_loss_energy_j: float
    queue_depth: int
    reason: str = ""


@dataclass(frozen=True)
class RouteDecision:
    request_id: str
    session_id: str
    selected_region: str
    policy: str
    previous_region: str | None
    migrated: bool
    fallback: bool
    lease_ttl_s: float
    lease_value: float
    lease_reason: str
    reason: str
    candidates: tuple[CandidateEstimate, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CompletionResult:
    request_id: str
    region_id: str
    success: bool
    status_code: int | None
    dispatch_wall_time_ns: int
    first_token_wall_time_ns: int | None
    completed_wall_time_ns: int
    ttft_ms: float | None
    tpot_ms: float | None
    output_tokens: int
    prompt_tokens_reported: int | None
    cached_prompt_tokens_observed: int | None
    error: str | None = None
