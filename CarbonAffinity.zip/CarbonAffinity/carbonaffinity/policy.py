from __future__ import annotations

import math
from dataclasses import dataclass

from .carbon import CarbonTrace, carbon_grams
from .models import CandidateEstimate, RegionSnapshot, RequestSpec, RouteDecision
from .profile import HardwareProfile
from .state import StateDirectory


@dataclass(frozen=True)
class PolicySettings:
    name: str = "carbon_affinity"
    lease_ttl_s: float = 900.0
    carbon_weight: float = 1.0
    slo_violation_penalty: float = 1000.0
    queue_penalty: float = 0.02
    migration_hysteresis_g: float = 0.002
    uncertainty_penalty_g: float = 0.0
    ttl_candidates_s: tuple[float, ...] = (0.0, 60.0, 300.0, 900.0)
    adaptive_lease: bool = True
    kv_bytes_per_token: float = 327680.0
    memory_shadow_g_per_gib_s: float = 0.0
    latency_value_g_per_ms: float = 0.0
    return_models: dict | None = None

    @classmethod
    def from_dict(cls, raw: dict) -> "PolicySettings":
        lease = raw.get("lease", {})
        return cls(
            name=str(raw.get("policy", "carbon_affinity")),
            lease_ttl_s=float(raw.get("lease_ttl_s", 900.0)),
            carbon_weight=float(raw.get("carbon_weight", 1.0)),
            slo_violation_penalty=float(raw.get("slo_violation_penalty", 1000.0)),
            queue_penalty=float(raw.get("queue_penalty", 0.02)),
            migration_hysteresis_g=float(raw.get("migration_hysteresis_g", 0.002)),
            uncertainty_penalty_g=float(raw.get("uncertainty_penalty_g", 0.0)),
            ttl_candidates_s=tuple(float(value) for value in lease.get("ttl_candidates_s", [0, 60, 300, 900])),
            adaptive_lease=bool(lease.get("adaptive", True)),
            kv_bytes_per_token=float(lease.get("kv_bytes_per_token", 327680.0)),
            memory_shadow_g_per_gib_s=float(lease.get("memory_shadow_g_per_gib_s", 0.0)),
            latency_value_g_per_ms=float(lease.get("latency_value_g_per_ms", 0.0)),
            return_models=lease.get("return_models") or {"default": {"return_probability": 0.7, "mean_gap_s": 120.0}},
        )


class RouterPolicy:
    def __init__(
        self,
        settings: PolicySettings,
        carbon: CarbonTrace,
        profiles: dict[str, HardwareProfile],
        state: StateDirectory,
    ):
        self.settings = settings
        self.carbon = carbon
        self.profiles = profiles
        self.state = state
        self._round_robin_index = 0

    def decide(
        self,
        request: RequestSpec,
        snapshots: dict[str, RegionSnapshot],
        now_s: float,
        carbon_time_s: float | None = None,
    ) -> RouteDecision:
        carbon_time_s = now_s if carbon_time_s is None else carbon_time_s
        previous = self.state.last_region(request.session_id, now_s)
        candidates: list[CandidateEstimate] = []
        missing_carbon = False
        for region_id, snapshot in snapshots.items():
            if not snapshot.healthy:
                continue
            cached = self.state.reusable_tokens(request.session_id, region_id, request, now_s)
            if self.settings.name == "cedar_like":
                cached = 0
            service = self.profiles[region_id].estimate(request, cached, snapshot)
            in_domain = self.profiles[region_id].in_domain(request, snapshot)
            observation = self.carbon.at(region_id, carbon_time_s)
            signal = (
                observation.historical_lbs_per_mwh
                if self.settings.name == "oracle_historical"
                else observation.forecast_lbs_per_mwh
            )
            carbon_g = (
                carbon_grams(service.energy_j, signal)
                if signal is not None else None
            )
            missing_carbon = missing_carbon or carbon_g is None
            feasible = in_domain and service.ttft_ms <= request.ttft_slo_ms and service.tpot_ms <= request.tpot_slo_ms
            fully_warm = self.profiles[region_id].estimate(request, request.prompt_tokens, snapshot)
            state_loss_j = max(0.0, service.energy_j - fully_warm.energy_j)
            score = self._score(snapshot, carbon_g, feasible)
            candidates.append(CandidateEstimate(
                region_id=region_id,
                cached_tokens=cached,
                energy_j=service.energy_j,
                ttft_ms=service.ttft_ms,
                tpot_ms=service.tpot_ms,
                forecast_lbs_per_mwh=signal,
                forecast_carbon_g=carbon_g,
                slo_feasible=feasible,
                in_domain=in_domain,
                score=score,
                state_loss_energy_j=state_loss_j,
                queue_depth=snapshot.queue_depth,
            ))
        if not candidates:
            raise RuntimeError("no healthy region is available")

        fallback = missing_carbon and self.settings.name in {
            "carbon_affinity", "cleanest_now", "cedar_like", "oracle_historical"
        }
        policy = "pressure_only" if fallback else self.settings.name
        feasible = [candidate for candidate in candidates if candidate.slo_feasible]
        selectable = feasible or candidates
        if not feasible:
            fallback = True
            policy = "pressure_only"
        chosen, reason = self._select(policy, selectable, previous)
        lease_ttl_s, lease_value, lease_reason = self._choose_lease(request, chosen, snapshots[chosen.region_id], policy)
        return RouteDecision(
            request_id=request.request_id,
            session_id=request.session_id,
            selected_region=chosen.region_id,
            policy=policy,
            previous_region=previous,
            migrated=previous is not None and previous != chosen.region_id,
            fallback=fallback,
            lease_ttl_s=lease_ttl_s,
            lease_value=lease_value,
            lease_reason=lease_reason,
            reason=reason,
            candidates=tuple(candidates),
        )

    def _choose_lease(
        self,
        request: RequestSpec,
        selected: CandidateEstimate,
        snapshot: RegionSnapshot,
        policy: str,
    ) -> tuple[float, float, str]:
        if policy not in {"carbon_affinity", "oracle_historical"} or not self.settings.adaptive_lease:
            return self.settings.lease_ttl_s, 0.0, "fixed lease for baseline or ablation"
        model = (self.settings.return_models or {}).get(
            request.workload,
            (self.settings.return_models or {}).get("default", {}),
        )
        return_probability = min(1.0, max(0.0, float(model.get("return_probability", 0.7))))
        mean_gap_s = max(1e-6, float(model.get("mean_gap_s", 120.0)))
        profile = self.profiles[selected.region_id]
        cold = profile.estimate(request, 0, snapshot)
        warm = profile.estimate(request, request.prompt_tokens, snapshot)
        avoided_energy_j = max(0.0, cold.energy_j - warm.energy_j)
        avoided_latency_ms = max(0.0, cold.ttft_ms - warm.ttft_ms)
        avoided_carbon_g = (
            carbon_grams(avoided_energy_j, selected.forecast_lbs_per_mwh)
            if selected.forecast_lbs_per_mwh is not None else 0.0
        )
        kv_gib = request.prompt_tokens * self.settings.kv_bytes_per_token / 2**30
        best = (0.0, 0.0)
        for ttl_s in self.settings.ttl_candidates_s:
            return_by_ttl = return_probability * (1.0 - math.exp(-max(0.0, ttl_s) / mean_gap_s))
            benefit = return_by_ttl * (
                avoided_carbon_g + self.settings.latency_value_g_per_ms * avoided_latency_ms
            )
            opportunity_cost = self.settings.memory_shadow_g_per_gib_s * kv_gib * max(0.0, ttl_s)
            value = benefit - opportunity_cost
            if value > best[1] or (value == best[1] and ttl_s < best[0]):
                best = (ttl_s, value)
        return best[0], best[1], (
            f"max lease value over {list(self.settings.ttl_candidates_s)}; "
            f"P(return)={return_probability:.3f}, mean_gap={mean_gap_s:.1f}s"
        )

    def _score(self, snapshot: RegionSnapshot, carbon_g: float | None, feasible: bool) -> float:
        carbon_term = carbon_g * self.settings.carbon_weight if carbon_g is not None else 0.0
        pressure = (snapshot.active_requests + snapshot.queue_depth) / max(1, snapshot.capacity)
        return carbon_term + pressure * self.settings.queue_penalty + (0.0 if feasible else self.settings.slo_violation_penalty)

    def _select(
        self, policy: str, candidates: list[CandidateEstimate], previous: str | None
    ) -> tuple[CandidateEstimate, str]:
        by_region = {candidate.region_id: candidate for candidate in candidates}
        if policy == "round_robin":
            ordered = sorted(candidates, key=lambda item: item.region_id)
            winner = ordered[self._round_robin_index % len(ordered)]
            self._round_robin_index += 1
            return winner, "round-robin baseline"
        if policy == "sticky" and previous in by_region:
            return by_region[previous], "session affinity"
        if policy == "sticky":
            winner = min(candidates, key=lambda item: (item.queue_depth, item.ttft_ms, item.region_id))
            return winner, "carbon-blind initial placement for sticky baseline"
        if policy == "pressure_only":
            winner = min(candidates, key=lambda item: (item.queue_depth, item.ttft_ms, item.region_id))
            return winner, "carbon unavailable or pressure-only baseline"
        if policy == "cleanest_now":
            winner = min(candidates, key=lambda item: (float("inf") if item.forecast_lbs_per_mwh is None else item.forecast_lbs_per_mwh, item.score))
            return winner, "lowest instantaneous forecast MOER"

        if policy == "cedar_like":
            winner = min(candidates, key=lambda item: (item.score, item.ttft_ms, item.region_id))
            return winner, "stateless forecast-carbon plus queue baseline"

        if policy == "oracle_historical":
            winner = min(candidates, key=lambda item: (item.score, item.ttft_ms, item.region_id))
            return winner, "historical-MOER state-aware oracle"

        winner = min(candidates, key=lambda item: (item.score, item.ttft_ms, item.region_id))
        if previous in by_region and winner.region_id != previous:
            incumbent = by_region[previous]
            improvement = incumbent.score - winner.score
            threshold = self.settings.migration_hysteresis_g + self.settings.uncertainty_penalty_g
            if improvement < threshold:
                return incumbent, f"migration benefit {improvement:.6f} below hysteresis+risk {threshold:.6f}"
        return winner, "minimum state-aware predicted carbon under SLO"
