from __future__ import annotations

import hashlib
import random
from typing import Any


class PromptMaterializer:
    """Construct exact-length token-ID prompts with stable per-session prefixes."""

    def __init__(self, tokenizer_name: str):
        from transformers import AutoTokenizer

        self.tokenizer = AutoTokenizer.from_pretrained(
            tokenizer_name,
            trust_remote_code=True,
            local_files_only=True,
        )
        candidates = self.tokenizer.encode(
            " enterprise retrieval document analysis code tool result evidence benchmark carbon routing",
            add_special_tokens=False,
        )
        special = set(self.tokenizer.all_special_ids)
        self.pool = [token for token in candidates if token not in special]
        if not self.pool:
            raise RuntimeError("could not construct a non-special token pool")

    def tokens(self, row: dict[str, Any]) -> list[int]:
        count = int(row["prompt_tokens"])
        shared = min(count, max(0, int(row.get("shared_prefix_tokens", row.get("cache_prefix_tokens", 0)))))
        session = str(row.get("session_id") or row["request_id"])
        return self._materialize("prefix:" + session, shared) + self._materialize(
            "suffix:" + str(row["request_id"]), count - shared
        )

    def _materialize(self, identity: str, length: int) -> list[int]:
        if length <= 0:
            return []
        seed = int(hashlib.sha256(identity.encode()).hexdigest()[:16], 16)
        rng = random.Random(seed)
        pattern = [rng.choice(self.pool) for _ in range(256)]
        return (pattern * ((length + len(pattern) - 1) // len(pattern)))[:length]
