from __future__ import annotations

import csv
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any

from .carbon import CarbonTrace, carbon_grams


def _percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = min(len(ordered) - 1, max(0, math.ceil(q * len(ordered)) - 1))
    return ordered[position]


def integrate_telemetry(
    path: Path,
    region_id: str,
    carbon: CarbonTrace,
    carbon_start_s: float | None,
    measurement_window_ns: tuple[int, int] | None = None,
    carbon_anchor: tuple[int, float] | None = None,
) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    usable = [row for row in rows if row.get("power_w") and row.get("wall_time_ns")]
    energy_j = 0.0
    operational_carbon_g = 0.0
    carbon_intervals = 0
    selected_intervals = 0
    for left, right in zip(usable, usable[1:]):
        left_ns, right_ns = int(left["wall_time_ns"]), int(right["wall_time_ns"])
        midpoint_ns = (left_ns + right_ns) // 2
        if measurement_window_ns and not (measurement_window_ns[0] <= midpoint_ns <= measurement_window_ns[1]):
            continue
        selected_intervals += 1
        duration_s = max(0.0, (right_ns - left_ns) / 1e9)
        interval_energy = duration_s * (float(left["power_w"]) + float(right["power_w"])) / 2.0
        energy_j += interval_energy
        midpoint_wall_s = midpoint_ns / 1e9
        if carbon_anchor is not None:
            carbon_time_s = carbon_anchor[1] + (midpoint_ns - carbon_anchor[0]) / 1e9
        elif carbon_start_s is None:
            carbon_time_s = midpoint_wall_s
        else:
            elapsed_s = (float(left.get("elapsed_ms") or 0) + float(right.get("elapsed_ms") or 0)) / 2000.0
            carbon_time_s = carbon_start_s + elapsed_s
        observation = carbon.at(region_id, carbon_time_s)
        if observation.historical_lbs_per_mwh is not None:
            operational_carbon_g += carbon_grams(interval_energy, observation.historical_lbs_per_mwh)
            carbon_intervals += 1
    return {
        "region_id": region_id,
        "telemetry_rows": len(rows),
        "usable_rows": len(usable),
        "gpu_energy_j": energy_j,
        "operational_carbon_g": operational_carbon_g,
        "carbon_covered_intervals": carbon_intervals,
        "total_intervals": selected_intervals,
    }


def audit_results(results_path: Path, telemetry: dict[str, Path] | None = None, carbon: CarbonTrace | None = None, carbon_start_s: float | None = None) -> dict[str, Any]:
    rows = [json.loads(line) for line in results_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    regions = Counter(row["decision"]["selected_region"] for row in rows)
    ttfts = [float(row["completion"]["ttft_ms"]) for row in rows if row["completion"].get("ttft_ms") is not None]
    tpots = [float(row["completion"]["tpot_ms"]) for row in rows if row["completion"].get("tpot_ms") is not None]
    failures = [row for row in rows if not row["completion"].get("success")]
    cache_pairs = []
    for row in rows:
        observed = row["completion"].get("cached_prompt_tokens_observed")
        if observed is None:
            continue
        selected_region = row["decision"]["selected_region"]
        candidate = next(
            item for item in row["decision"]["candidates"]
            if item["region_id"] == selected_region
        )
        cache_pairs.append((int(candidate["cached_tokens"]), int(observed)))
    summary: dict[str, Any] = {
        "requests": len(rows),
        "request_failures": len(failures),
        "regions": dict(regions),
        "migrations": sum(bool(row["decision"].get("migrated")) for row in rows),
        "fallback_decisions": sum(bool(row["decision"].get("fallback")) for row in rows),
        "ttft_violation_rate": sum(bool(row.get("ttft_violation")) for row in rows) / len(rows) if rows else None,
        "tpot_violation_rate": sum(bool(row.get("tpot_violation")) for row in rows) / len(rows) if rows else None,
        "ttft_p50_ms": _percentile(ttfts, 0.50),
        "ttft_p95_ms": _percentile(ttfts, 0.95),
        "ttft_p99_ms": _percentile(ttfts, 0.99),
        "tpot_p95_ms": _percentile(tpots, 0.95),
        "profile_forecast_carbon_g": sum(float(row.get("forecast_profile_carbon_g") or 0) for row in rows),
        "profile_settled_carbon_g": sum(float(row.get("settled_profile_carbon_g") or 0) for row in rows),
        "cache_observation_rate": sum(row["completion"].get("cached_prompt_tokens_observed") is not None for row in rows) / len(rows) if rows else None,
        "cache_prediction_mae_tokens": (
            sum(abs(predicted - observed) for predicted, observed in cache_pairs) / len(cache_pairs)
            if cache_pairs else None
        ),
        "cache_hit_classification_accuracy": (
            sum((predicted > 0) == (observed > 0) for predicted, observed in cache_pairs) / len(cache_pairs)
            if cache_pairs else None
        ),
        "cache_false_positive_rate": (
            sum(predicted > 0 and observed == 0 for predicted, observed in cache_pairs)
            / max(1, sum(predicted > 0 for predicted, _ in cache_pairs))
            if cache_pairs else None
        ),
        "lease_enforcement": dict(Counter(str(row.get("lease_enforced")) for row in rows)),
        "config_fingerprints": sorted({row.get("config_fingerprint") for row in rows}),
    }
    if telemetry:
        if carbon is None:
            raise ValueError("carbon trace is required when telemetry is audited")
        dispatches = [int(row["completion"]["dispatch_wall_time_ns"]) for row in rows]
        completions = [int(row["completion"]["completed_wall_time_ns"]) for row in rows]
        earliest_index = min(range(len(rows)), key=lambda index: dispatches[index])
        measurement_window = (min(dispatches), max(completions))
        anchor = (dispatches[earliest_index], float(rows[earliest_index]["routing_carbon_timestamp_s"]))
        per_region = [
            integrate_telemetry(path, region, carbon, carbon_start_s, measurement_window, anchor)
            for region, path in telemetry.items()
        ]
        summary["measurement_window_wall_time_ns"] = measurement_window
        summary["carbon_time_anchor"] = {"wall_time_ns": anchor[0], "carbon_timestamp_s": anchor[1]}
        summary["telemetry"] = per_region
        summary["measured_gpu_energy_j"] = sum(item["gpu_energy_j"] for item in per_region)
        summary["measured_operational_carbon_g"] = sum(item["operational_carbon_g"] for item in per_region)
    telemetry_valid = True
    if telemetry:
        telemetry_valid = all(
            item["usable_rows"] >= 2
            and item["total_intervals"] > 0
            and item["carbon_covered_intervals"] == item["total_intervals"]
            for item in summary["telemetry"]
        )
    summary["telemetry_valid"] = telemetry_valid
    summary["passed"] = (
        bool(rows) and not failures
        and len(summary["config_fingerprints"]) == 1
        and telemetry_valid
    )
    return summary
