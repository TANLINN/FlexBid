from __future__ import annotations

import argparse
import asyncio
import json
import statistics
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import pynvml

from .materialize import PromptMaterializer
from .models import RequestSpec
from .region import RegionClient


def _energy_mj(handle) -> float | None:
    try:
        return float(pynvml.nvmlDeviceGetTotalEnergyConsumption(handle))
    except (pynvml.NVMLError, AttributeError):
        return None


def _power_w(handle) -> float | None:
    try:
        return pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
    except pynvml.NVMLError:
        return None


async def _measured_completion(client, request, prompt, handle, interval_s: float = 0.02):
    samples: list[tuple[int, float]] = []
    stopped = asyncio.Event()

    async def poll() -> None:
        while not stopped.is_set():
            power = _power_w(handle)
            if power is not None:
                samples.append((time.perf_counter_ns(), power))
            await asyncio.sleep(interval_s)

    before_mj = _energy_mj(handle)
    before_ns = time.perf_counter_ns()
    task = asyncio.create_task(poll())
    result = await client.complete(request, prompt)
    final_power = _power_w(handle)
    if final_power is not None:
        samples.append((time.perf_counter_ns(), final_power))
    stopped.set()
    await task
    after_ns = time.perf_counter_ns()
    after_mj = _energy_mj(handle)
    if before_mj is not None and after_mj is not None and after_mj >= before_mj:
        total_energy_j = (after_mj - before_mj) / 1000.0
        source = "nvml_total_energy_counter"
    else:
        total_energy_j = 0.0
        for left, right in zip(samples, samples[1:]):
            total_energy_j += (right[0] - left[0]) / 1e9 * (left[1] + right[1]) / 2.0
        source = "integrated_nvml_power"
    return result, before_ns, after_ns, total_energy_j, source, len(samples)


async def calibrate(args: argparse.Namespace) -> None:
    materializer = PromptMaterializer(args.tokenizer)
    client = RegionClient({
        "id": args.region_id,
        "api_base": args.api_base,
        "api_key": args.api_key,
        "model": args.model,
        "admission_concurrency": 1,
    }, timeout_s=args.timeout_s)
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(args.gpu_index)
    samples: list[dict] = []
    try:
        idle_samples = []
        for _ in range(20):
            power = _power_w(handle)
            if power is not None:
                idle_samples.append(power)
            await asyncio.sleep(0.1)
        if not idle_samples:
            raise RuntimeError("NVML power telemetry unavailable")
        idle_power_w = statistics.median(idle_samples)
        index = 0
        for prompt_tokens in args.prompt_tokens:
            for output_tokens in args.output_tokens:
                for mode in ("cold", "warm"):
                    for repeat in range(args.repeats):
                        index += 1
                        session = f"cal-{mode}-{prompt_tokens}-{output_tokens}-{repeat}"
                        raw = {
                            "request_id": f"{session}-prompt",
                            "session_id": session,
                            "prompt_tokens": prompt_tokens,
                            "shared_prefix_tokens": prompt_tokens if mode == "warm" else 0,
                        }
                        prompt = materializer.tokens(raw)
                        request = RequestSpec(
                            request_id=f"{session}-measure",
                            arrival_ms=0,
                            prompt_tokens=prompt_tokens,
                            max_output_tokens=output_tokens,
                            session_id=session,
                            shared_prefix_tokens=prompt_tokens if mode == "warm" else 0,
                        )
                        if mode == "warm":
                            prime = await client.complete(request, prompt)
                            if not prime.success:
                                raise RuntimeError(f"warm-cache prime failed: {prime.error}")
                            await asyncio.sleep(args.settle_s)
                        result, before_ns, after_ns, total_energy_j, energy_source, power_samples = await _measured_completion(
                            client, request, prompt, handle
                        )
                        duration_s = (after_ns - before_ns) / 1e9
                        dynamic_energy_j = max(0.0, total_energy_j - idle_power_w * duration_s)
                        cached = result.cached_prompt_tokens_observed
                        if cached is None:
                            cached = prompt_tokens if mode == "warm" else 0
                        samples.append({
                            "index": index,
                            "mode": mode,
                            "prompt_tokens": prompt_tokens,
                            "output_tokens": output_tokens,
                            "cached_tokens_for_fit": cached,
                            "cached_tokens_observed": result.cached_prompt_tokens_observed,
                            "total_energy_j": total_energy_j,
                            "dynamic_energy_j": dynamic_energy_j,
                            "duration_s": duration_s,
                            "idle_power_w": idle_power_w,
                            "energy_source": energy_source,
                            "power_samples": power_samples,
                            "result": asdict(result),
                        })
                        await asyncio.sleep(args.settle_s)
        successful = [row for row in samples if row["result"]["success"]]
        if len(successful) < 8:
            raise RuntimeError(f"only {len(successful)} successful calibration samples")
        energy_x, energy_y, ttft_x, ttft_y, tpots = [], [], [], [], []
        for row in successful:
            cached = min(row["cached_tokens_for_fit"], row["prompt_tokens"])
            cold = row["prompt_tokens"] - cached
            energy_x.append([1.0, cold, cached, row["output_tokens"]])
            energy_y.append(row["dynamic_energy_j"])
            ttft_x.append([1.0, cold, cached])
            ttft_y.append(row["result"]["ttft_ms"])
            if row["result"]["tpot_ms"] is not None:
                tpots.append(row["result"]["tpot_ms"])
        energy_beta = np.maximum(0.0, np.linalg.lstsq(np.asarray(energy_x), np.asarray(energy_y), rcond=None)[0])
        ttft_beta = np.maximum(0.0, np.linalg.lstsq(np.asarray(ttft_x), np.asarray(ttft_y), rcond=None)[0])
        profile = {
            "region_id": args.region_id,
            "accelerator": args.accelerator,
            "model": args.model,
            "base_request_j": float(energy_beta[0]),
            "cold_prefill_j_per_token": float(energy_beta[1]),
            "cached_prefill_j_per_token": float(energy_beta[2]),
            "decode_j_per_token": float(energy_beta[3]),
            "base_ttft_ms": float(ttft_beta[0]),
            "cold_prefill_ms_per_token": float(ttft_beta[1]),
            "cached_prefill_ms_per_token": float(ttft_beta[2]),
            "base_tpot_ms": float(statistics.median(tpots)) if tpots else 0.0,
            "queue_ttft_ms_per_request": float(args.queue_ttft_ms_per_request),
            "uncertainty_margin": float(args.uncertainty_margin),
            "max_prompt_tokens": max(args.prompt_tokens),
            "max_output_tokens": max(args.output_tokens),
            "max_concurrency": int(args.max_concurrency),
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(profile, indent=2), encoding="utf-8")
        args.output.with_suffix(".samples.jsonl").write_text(
            "".join(json.dumps(row) + "\n" for row in samples), encoding="utf-8"
        )
    finally:
        pynvml.nvmlShutdown()
        await client.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Calibrate one physical A800/TP=1 region")
    parser.add_argument("--region-id", required=True)
    parser.add_argument("--api-base", default="http://127.0.0.1:18000/v1")
    parser.add_argument("--api-key", default="EMPTY")
    parser.add_argument("--model", required=True)
    parser.add_argument("--tokenizer", required=True)
    parser.add_argument("--accelerator", default="NVIDIA A800 80GB")
    parser.add_argument("--gpu-index", type=int, default=0)
    parser.add_argument("--prompt-tokens", type=int, nargs="+", default=[512, 2048, 8192, 16384])
    parser.add_argument("--output-tokens", type=int, nargs="+", default=[32, 128, 512])
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--settle-s", type=float, default=1.0)
    parser.add_argument("--timeout-s", type=float, default=900.0)
    parser.add_argument("--queue-ttft-ms-per-request", type=float, default=100.0)
    parser.add_argument("--uncertainty-margin", type=float, default=1.10)
    parser.add_argument("--max-concurrency", type=int, default=16)
    parser.add_argument("--output", type=Path, required=True)
    asyncio.run(calibrate(parser.parse_args()))


if __name__ == "__main__":
    main()
