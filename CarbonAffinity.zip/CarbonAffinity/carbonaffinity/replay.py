from __future__ import annotations

import asyncio
import json
import time
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any

from .carbon import CarbonTrace, carbon_grams
from .config import config_fingerprint, resolve_path
from .materialize import PromptMaterializer
from .models import RequestSpec
from .policy import PolicySettings, RouterPolicy
from .profile import HardwareProfile
from .region import RegionClient
from .state import StateDirectory


def load_trace(path: Path, arrival_scale: float = 1.0, duration_limit_s: float | None = None) -> list[dict[str, Any]]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    required = {"request_id", "arrival_ms", "prompt_tokens", "max_output_tokens"}
    for index, row in enumerate(rows):
        missing = required - row.keys()
        if missing:
            raise ValueError(f"trace row {index} missing {sorted(missing)}")
        row["arrival_ms"] = float(row["arrival_ms"]) * arrival_scale
        row["tool_delay_ms"] = float(row.get("tool_delay_ms", 0.0)) * arrival_scale
    selected = [row for row in rows if duration_limit_s is None or row["arrival_ms"] <= duration_limit_s * 1000]
    if not selected:
        raise ValueError("trace is empty after scaling/cropping")
    return sorted(selected, key=lambda row: (row["arrival_ms"], str(row["request_id"])))


async def run_replay(
    config: dict[str, Any],
    trace_path: Path,
    output: Path,
    policy_name: str | None = None,
    resume: bool = False,
) -> None:
    runtime = config.get("runtime", {})
    routing_raw = dict(config.get("routing", {}))
    if policy_name:
        routing_raw["policy"] = policy_name
    state_path = output.parent / f"state_{routing_raw.get('policy', 'carbon_affinity')}.json"
    if output.exists() and not resume:
        raise FileExistsError(f"output exists; use --resume or a fresh directory: {output}")
    if state_path.exists() and not resume:
        raise FileExistsError(f"state exists; use --resume or a fresh directory: {state_path}")
    carbon = CarbonTrace.from_csv(
        resolve_path(config, config["carbon"]["trace"]),
        max_age_s=float(config["carbon"].get("max_age_s", 1800.0)),
    )
    profiles = {
        region["id"]: HardwareProfile.from_json(resolve_path(config, region["profile"]))
        for region in config["regions"]
    }
    state = StateDirectory(state_path)
    routing_raw["lease"] = config.get("lease", {})
    router = RouterPolicy(PolicySettings.from_dict(routing_raw), carbon, profiles, state)
    rows = load_trace(trace_path, float(runtime.get("arrival_scale", 1.0)), runtime.get("duration_limit_s"))
    needs_materialization = any(
        row.get("prompt") is None and row.get("prompt_token_ids") is None for row in rows
    )
    materializer = (
        PromptMaterializer(str(config["experiment"]["tokenizer"]))
        if needs_materialization else None
    )
    completed_ids: set[str] = set()
    prior_records: list[dict[str, Any]] = []
    if resume and output.exists():
        prior_records = [json.loads(line) for line in output.read_text(encoding="utf-8").splitlines() if line.strip()]
        completed_ids = {record["request_id"] for record in prior_records}
        for record in sorted(prior_records, key=lambda item: item["completion"]["completed_wall_time_ns"]):
            if record["completion"].get("success"):
                state.update(
                    RequestSpec.from_dict(record),
                    record["decision"]["selected_region"],
                    record["completion"]["completed_wall_time_ns"] / 1e9,
                    float(record["decision"]["lease_ttl_s"]),
                    record["completion"].get("cached_prompt_tokens_observed"),
                    record.get("cache_salt"),
                    persist=False,
                )
    carbon_config = config.get("carbon", {})
    carbon_clock_mode = str(carbon_config.get("clock_mode", "trace_relative"))
    carbon_start_raw = carbon_config.get("trace_start_timestamp")
    if carbon_clock_mode == "trace_relative" and carbon_start_raw is None:
        raise ValueError("carbon.trace_start_timestamp is required for trace_relative clock mode")
    if isinstance(carbon_start_raw, (int, float)):
        carbon_start_s = float(carbon_start_raw)
    elif carbon_start_raw is not None:
        carbon_start_s = datetime.fromisoformat(str(carbon_start_raw).replace("Z", "+00:00")).timestamp()
    else:
        carbon_start_s = 0.0
    output.parent.mkdir(parents=True, exist_ok=True)
    clients = {
        region["id"]: RegionClient(region, float(runtime.get("request_timeout_s", 900.0)))
        for region in config["regions"]
    }
    output_handle = output.open("a", encoding="utf-8")
    events = {str(row["request_id"]): asyncio.Event() for row in rows}
    completion_perf: dict[str, int] = {}
    for request_id in completed_ids:
        if request_id in events:
            events[request_id].set()
            completion_perf[request_id] = time.perf_counter_ns()
    write_lock = asyncio.Lock()
    global_limit = asyncio.Semaphore(int(runtime.get("max_in_flight", 256)))
    start_perf_ns = time.perf_counter_ns()
    remaining_arrivals = [float(row["arrival_ms"]) for row in rows if str(row["request_id"]) not in completed_ids]
    arrival_origin_ms = min(remaining_arrivals) if completed_ids and remaining_arrivals else 0.0

    async def issue(raw: dict[str, Any]) -> None:
        request = RequestSpec.from_dict(raw)
        if request.request_id in completed_ids:
            return
        if request.parent_request_id and request.parent_request_id in events:
            await events[request.parent_request_id].wait()
        trace_target = start_perf_ns + int((request.arrival_ms - arrival_origin_ms) * 1e6)
        dependency_target = completion_perf.get(request.parent_request_id or "", start_perf_ns) + int(request.tool_delay_ms * 1e6)
        delay_s = (max(trace_target, dependency_target) - time.perf_counter_ns()) / 1e9
        if delay_s > 0:
            await asyncio.sleep(delay_s)
        async with global_limit:
            now_s = time.time()
            carbon_time_s = (
                request.carbon_timestamp_s
                if request.carbon_timestamp_s is not None
                else (now_s if carbon_clock_mode == "wall" else carbon_start_s + request.arrival_ms / 1000.0)
            )
            health = await asyncio.gather(*[client.healthy() for client in clients.values()])
            snapshots = {
                region_id: client.snapshot(is_healthy)
                for (region_id, client), is_healthy in zip(clients.items(), health)
            }
            decision = router.decide(request, snapshots, now_s, carbon_time_s)
            client = clients[decision.selected_region]
            if request.prompt is not None:
                prompt = request.prompt
            elif raw.get("prompt_token_ids") is not None:
                prompt = [int(token) for token in raw["prompt_token_ids"]]
            else:
                assert materializer is not None
                prompt = materializer.tokens(raw)
            cache_salt = state.salt_for_dispatch(request.session_id, decision.selected_region, now_s)
            result = await client.complete(request, prompt, cache_salt=cache_salt)
            lease_enforced = await client.set_cache_lease(request.session_id, decision.lease_ttl_s)
            selected = next(candidate for candidate in decision.candidates if candidate.region_id == decision.selected_region)
            request_runtime_s = max(0.0, (result.completed_wall_time_ns - result.dispatch_wall_time_ns) / 1e9)
            historical = carbon.at(decision.selected_region, carbon_time_s + request_runtime_s)
            settled_profile_carbon_g = (
                carbon_grams(selected.energy_j, historical.historical_lbs_per_mwh)
                if historical.historical_lbs_per_mwh is not None else None
            )
            if result.success:
                state.update(
                    request, decision.selected_region, result.completed_wall_time_ns / 1e9,
                    decision.lease_ttl_s, result.cached_prompt_tokens_observed, cache_salt,
                )
            record = {
                **asdict(request),
                "config_fingerprint": config_fingerprint(config),
                "decision": decision.to_dict(),
                "completion": asdict(result),
                "lease_enforced": lease_enforced,
                "cache_namespace_enforced": True,
                "cache_salt": cache_salt,
                "forecast_profile_carbon_g": selected.forecast_carbon_g,
                "settled_profile_carbon_g": settled_profile_carbon_g,
                "historical_lbs_per_mwh": historical.historical_lbs_per_mwh,
                "historical_source_timestamp_s": historical.source_timestamp_s,
                "routing_carbon_timestamp_s": carbon_time_s,
                "ttft_violation": result.ttft_ms is None or result.ttft_ms > request.ttft_slo_ms,
                "tpot_violation": (
                    result.output_tokens > 1
                    and (result.tpot_ms is None or result.tpot_ms > request.tpot_slo_ms)
                ),
            }
            async with write_lock:
                output_handle.write(json.dumps(record, ensure_ascii=False) + "\n")
                output_handle.flush()
        completion_perf[request.request_id] = time.perf_counter_ns()
        events[request.request_id].set()

    async def guarded_issue(raw: dict[str, Any]) -> None:
        request_id = str(raw["request_id"])
        try:
            await issue(raw)
        finally:
            completion_perf.setdefault(request_id, time.perf_counter_ns())
            events[request_id].set()

    try:
        await asyncio.gather(*(guarded_issue(row) for row in rows))
    finally:
        state.persist()
        output_handle.close()
        await asyncio.gather(*(client.close() for client in clients.values()))
