from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import yaml


def load_config(path: str | Path) -> dict[str, Any]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError("configuration root must be a mapping")
    config["_config_path"] = str(config_path)
    config["_root"] = str(config_path.parent.parent)
    validate_config(config)
    return config


def resolve_path(config: dict[str, Any], value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else Path(config["_root"]) / path


def validate_config(config: dict[str, Any]) -> None:
    regions = config.get("regions", [])
    if len(regions) != 2:
        raise ValueError("the main experiment requires exactly two physical regions")
    ids = [str(region.get("id", "")) for region in regions]
    if len(set(ids)) != 2 or any(not item for item in ids):
        raise ValueError("region ids must be non-empty and unique")
    models = {str(region.get("model")) for region in regions}
    if len(models) != 1:
        raise ValueError("both regions must declare the same model")
    for region in regions:
        if int(region.get("gpu_count", 1)) != 1:
            raise ValueError("main experiment region gpu_count must be exactly 1")
        if int(region.get("tensor_parallel_size", 1)) != 1:
            raise ValueError("main experiment tensor_parallel_size must be exactly 1")
        if not all(region.get(key) for key in ("api_base", "control_base", "profile", "site_manifest")):
            raise ValueError(
                f"region {region.get('id')} needs api_base, control_base, profile, and site_manifest"
            )
    policy = config.get("routing", {}).get("policy", "carbon_affinity")
    allowed = {
        "carbon_affinity", "cleanest_now", "sticky", "pressure_only",
        "cedar_like", "oracle_historical", "round_robin",
    }
    if policy not in allowed:
        raise ValueError(f"unknown routing policy: {policy}")


def config_fingerprint(config: dict[str, Any]) -> str:
    public = {key: value for key, value in config.items() if not key.startswith("_")}
    payload = json.dumps(public, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()
