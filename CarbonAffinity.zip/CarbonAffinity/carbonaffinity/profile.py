from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from .models import RequestSpec, RegionSnapshot


@dataclass(frozen=True)
class ServiceEstimate:
    energy_j: float
    ttft_ms: float
    tpot_ms: float


@dataclass(frozen=True)
class HardwareProfile:
    region_id: str
    accelerator: str
    model: str
    base_request_j: float
    cold_prefill_j_per_token: float
    cached_prefill_j_per_token: float
    decode_j_per_token: float
    base_ttft_ms: float
    cold_prefill_ms_per_token: float
    cached_prefill_ms_per_token: float
    base_tpot_ms: float
    queue_ttft_ms_per_request: float
    uncertainty_margin: float = 1.0
    max_prompt_tokens: int = 32768
    max_output_tokens: int = 2048
    max_concurrency: int = 32

    @classmethod
    def from_json(cls, path: str | Path) -> "HardwareProfile":
        with Path(path).open("r", encoding="utf-8") as handle:
            return cls(**json.load(handle))

    def estimate(self, request: RequestSpec, cached_tokens: int, snapshot: RegionSnapshot) -> ServiceEstimate:
        cached = max(0, min(cached_tokens, request.prompt_tokens))
        cold = request.prompt_tokens - cached
        energy = (
            self.base_request_j
            + cold * self.cold_prefill_j_per_token
            + cached * self.cached_prefill_j_per_token
            + request.max_output_tokens * self.decode_j_per_token
        ) * self.uncertainty_margin
        ttft = (
            self.base_ttft_ms
            + cold * self.cold_prefill_ms_per_token
            + cached * self.cached_prefill_ms_per_token
            + (snapshot.active_requests + snapshot.queue_depth) * self.queue_ttft_ms_per_request
            + snapshot.rtt_ms
        ) * self.uncertainty_margin
        return ServiceEstimate(energy_j=max(0.0, energy), ttft_ms=max(0.0, ttft), tpot_ms=self.base_tpot_ms)

    def in_domain(self, request: RequestSpec, snapshot: RegionSnapshot) -> bool:
        return (
            request.prompt_tokens <= self.max_prompt_tokens
            and request.max_output_tokens <= self.max_output_tokens
            and snapshot.active_requests + snapshot.queue_depth + 1 <= self.max_concurrency
        )
