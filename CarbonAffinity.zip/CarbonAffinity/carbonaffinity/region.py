from __future__ import annotations

import asyncio
import json
import time
from typing import Any

import httpx

from .models import CompletionResult, RegionSnapshot, RequestSpec


def _cached_tokens(usage: dict[str, Any] | None) -> int | None:
    if not usage:
        return None
    details = usage.get("prompt_tokens_details") or usage.get("prompt_token_details") or {}
    for key in ("cached_tokens", "cached_prompt_tokens", "num_cached_tokens"):
        if details.get(key) is not None:
            return int(details[key])
        if usage.get(key) is not None:
            return int(usage[key])
    return None


class RegionClient:
    def __init__(self, config: dict[str, Any], timeout_s: float = 900.0):
        self.region_id = str(config["id"])
        self.api_base = str(config["api_base"]).rstrip("/")
        self.model = str(config["model"])
        self.api_key = str(config.get("api_key", "EMPTY"))
        self.capacity = int(config.get("admission_concurrency", 16))
        self.rtt_ms = float(config.get("rtt_ms", 0.0))
        self.cache_control_url = config.get("cache_control_url")
        self._active = 0
        self._waiting = 0
        self._counter_lock = asyncio.Lock()
        self._semaphore = asyncio.Semaphore(self.capacity)
        self._health_value = True
        self._health_checked_perf_s = 0.0
        self._health_cache_s = float(config.get("health_cache_s", 1.0))
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(timeout_s),
            headers={"Authorization": f"Bearer {self.api_key}"},
            limits=httpx.Limits(max_connections=max(32, self.capacity * 4), max_keepalive_connections=max(16, self.capacity * 2)),
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def healthy(self) -> bool:
        now = time.perf_counter()
        if now - self._health_checked_perf_s < self._health_cache_s:
            return self._health_value
        try:
            response = await self._client.get(f"{self.api_base.removesuffix('/v1')}/health")
            if response.status_code == 404:
                response = await self._client.get(f"{self.api_base}/models")
            self._health_value = response.status_code < 500
        except httpx.HTTPError:
            self._health_value = False
        self._health_checked_perf_s = now
        return self._health_value

    async def models(self) -> list[str]:
        response = await self._client.get(f"{self.api_base}/models")
        response.raise_for_status()
        payload = response.json()
        return [str(item.get("id")) for item in payload.get("data", []) if item.get("id")]

    async def reset_prefix_cache(self) -> bool:
        root = self.api_base.removesuffix("/v1")
        response = await self._client.post(root + "/reset_prefix_cache")
        response.raise_for_status()
        try:
            payload = response.json()
            if isinstance(payload, bool):
                return payload
            if isinstance(payload, dict):
                return bool(payload.get("success", payload.get("reset", True)))
        except ValueError:
            pass
        return True

    def snapshot(self, healthy: bool = True) -> RegionSnapshot:
        return RegionSnapshot(
            region_id=self.region_id,
            active_requests=self._active,
            queue_depth=self._waiting,
            healthy=healthy,
            rtt_ms=self.rtt_ms,
            capacity=self.capacity,
        )

    async def complete(
        self, request: RequestSpec, prompt: str | list[int], cache_salt: str | None = None
    ) -> CompletionResult:
        async with self._counter_lock:
            self._waiting += 1
        await self._semaphore.acquire()
        async with self._counter_lock:
            self._waiting -= 1
            self._active += 1
        try:
            return await self._complete_inner(request, prompt, cache_salt)
        finally:
            async with self._counter_lock:
                self._active -= 1
            self._semaphore.release()

    async def _complete_inner(
        self, request: RequestSpec, prompt: str | list[int], cache_salt: str | None
    ) -> CompletionResult:
        dispatch_perf_ns = time.perf_counter_ns()
        dispatch_wall_ns = time.time_ns()
        first_perf_ns: int | None = None
        previous_perf_ns: int | None = None
        gaps_ms: list[float] = []
        completion_tokens = 0
        prompt_tokens_reported: int | None = None
        cached: int | None = None
        status: int | None = None
        error: str | None = None
        payload = {
            "model": self.model,
            "prompt": prompt,
            "max_tokens": request.max_output_tokens,
            "temperature": 0.0,
            "ignore_eos": True,
            "stream": True,
            "stream_options": {"include_usage": True},
        }
        if cache_salt is not None:
            payload["cache_salt"] = cache_salt
        try:
            async with self._client.stream("POST", f"{self.api_base}/completions", json=payload) as response:
                status = response.status_code
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    data = line[5:].strip()
                    if data == "[DONE]":
                        break
                    message = json.loads(data)
                    usage = message.get("usage")
                    if usage:
                        completion_tokens = int(usage.get("completion_tokens", completion_tokens))
                        prompt_tokens_reported = usage.get("prompt_tokens", prompt_tokens_reported)
                        cached = _cached_tokens(usage) if _cached_tokens(usage) is not None else cached
                    choices = message.get("choices") or []
                    if choices and choices[0].get("text"):
                        now = time.perf_counter_ns()
                        if first_perf_ns is None:
                            first_perf_ns = now
                        if previous_perf_ns is not None:
                            gaps_ms.append((now - previous_perf_ns) / 1e6)
                        previous_perf_ns = now
                        if not usage:
                            completion_tokens += 1
        except Exception as exc:  # recorded verbatim for artifact auditing
            error = f"{type(exc).__name__}: {exc}"
        completed_perf_ns = time.perf_counter_ns()
        completed_wall_ns = dispatch_wall_ns + completed_perf_ns - dispatch_perf_ns
        return CompletionResult(
            request_id=request.request_id,
            region_id=self.region_id,
            success=error is None and first_perf_ns is not None,
            status_code=status,
            dispatch_wall_time_ns=dispatch_wall_ns,
            first_token_wall_time_ns=(None if first_perf_ns is None else dispatch_wall_ns + first_perf_ns - dispatch_perf_ns),
            completed_wall_time_ns=completed_wall_ns,
            ttft_ms=(None if first_perf_ns is None else (first_perf_ns - dispatch_perf_ns) / 1e6),
            tpot_ms=(sum(gaps_ms) / len(gaps_ms) if gaps_ms else None),
            output_tokens=completion_tokens,
            prompt_tokens_reported=(int(prompt_tokens_reported) if prompt_tokens_reported is not None else None),
            cached_prompt_tokens_observed=cached,
            error=error,
        )

    async def set_cache_lease(self, session_id: str, ttl_s: float) -> bool | None:
        """Return None when no eviction sidecar exists; never pretend TTL was enforced."""
        if not self.cache_control_url:
            return None
        try:
            response = await self._client.post(
                str(self.cache_control_url).rstrip("/") + "/lease",
                json={"session_id": session_id, "ttl_s": ttl_s},
            )
            response.raise_for_status()
            return True
        except httpx.HTTPError:
            return False

    async def supports_cache_salt(self) -> bool:
        payload = {
            "model": self.model,
            "prompt": "CarbonAffinity cache-salt preflight.",
            "max_tokens": 1,
            "temperature": 0.0,
            "cache_salt": "0" * 64,
        }
        try:
            response = await self._client.post(f"{self.api_base}/completions", json=payload)
            return response.status_code == 200
        except httpx.HTTPError:
            return False
