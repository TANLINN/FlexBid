# FlexBid-LLM paper artifact (8×A100)

这是论文实验的独立、可恢复版本。它不是早期单卡 smoke test 的包装：正式结果来自
8×A100 上的真实 vLLM replay；大于 8 卡的结果仅作为 bootstrap scale-out projection，
在输出文件中会明确标记，绝不写成硬件实测。

## 实验边界

- 两个模型：Qwen2.5-7B（8 个单卡 replica）和 Qwen2.5-32B（2 个 TP=4 replica）。
- 四个公开负载族：BurstGPT、Azure conversation/code、Qwen Bailian，另加一个
  Agentic/TraceLab 格式负载。所有 trace 按连续时间切分，禁止随机行切分。
- 控制变量：chunked-prefill token budget `K`、gateway admission concurrency `C`、
  所有参与 GPU 的硬件 power cap `Pcap`。
- 对照：no-DR、静态保守、power-cap-only、PALS-style reactive、workload-only、
  FlexBid/no-CP、row-CP、episode/grouped-block-CP、clairvoyant-workload surrogate benchmark。
- 功率边界：`Σ GPU NVML + available CPU package/DRAM RAPL`。主板、网卡、磁盘、
  风扇、PSU 损耗和制冷不在实测边界内。PUE 与碳强度结果是单列的 operational
  projection，不是 IPMI/BMC 整机实测，也不含 embodied carbon。

## A100 节点硬门槛

不要在 preflight 失败时继续：必须恰好看到 8 张 A100 80GB、无别人的 CUDA
进程、NVML 功率可读、对当前功率上限的无变化写回成功、磁盘至少 200 GiB，且
当前 vLLM 能导入自定义 V1 scheduler。老驱动（例如之前 V100 节点的 470.82）
通常不能承载当前 vLLM/CUDA；这不是代码可绕过的权限问题。

## 上传后的唯一操作

```bash
cd /root/workspace/paper_artifact
python3 -m venv .venv --system-site-packages
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -r requirements.txt
python -m pip install -e . --no-deps
vllm --version
```

将原始 trace 放到下列位置（或修改 `configs/a100_8gpu.yaml`）：

可以先运行 `python scripts/fetch_public_traces.py` 从各项目的官方 release 获取；
下载来源与许可入口记录在 `DATA_SOURCES.md`。

```text
data/raw/BurstGPT_without_fails_1.csv
data/raw/AzureLLMInferenceTrace_conv_1week.csv
data/raw/AzureLLMInferenceTrace_code_1week.csv
data/raw/qwen_traceB_blksz_16.jsonl
data/raw/tracelab_export.jsonl
```

若服务器不能访问 GitHub，请先在本地准备上述五个文件并上传；否则启动脚本会自动从
官方 release 下载、校验并适配。然后只需：

```bash
bash scripts/launch.sh
bash scripts/monitor.sh
```

SSH 断开不影响运行。失败后不要删除目录，直接：

```bash
nohup python -u scripts/run_all.py --config configs/a100_8gpu.yaml \
  --from-phase profile >> results/paper_artifact_a100/logs/launcher.log 2>&1 &
```

`profile` 和 `closed-loop` 会跳过所有已通过 `CELL_COMPLETE.json` 校验的单元。
任何异常路径都会尝试恢复租用开始时的每卡功率上限。

每个实验单元开始前会通过仅绑定 localhost 的 vLLM development endpoint 清空
prefix cache；单元内部的 session prefix reuse 仍被保留。这样不同动作/重复之间不会
因跨单元残留 KV cache 产生顺序偏差。服务启动后还会先 warm up 再清 cache。

## 防止测试集泄漏

顺序固定为：preflight → trace preparation → 60 秒 SLO-safe load pilot → train/calibration profiling → surrogate
fit → `ALGORITHM_FREEZE.json` → offline test → real closed-loop test → audit。Freeze
记录配置、算法源码、脚本和模型哈希；closed-loop 在哈希改变时拒绝打开 test split。

## 最终输出

- `closed_loop_summary.csv`：逐模型、逐 episode、逐方法的真实实测结果。
- `paper_method_summary.csv`：bid、实际削减、delivery failure、TTFT/TPOT、能耗与碳。
- `conformal_test_audit.csv`：测试集 power coverage 与区间保守度。
- `scale_projection.csv`：以真实 8 卡节点为锚点的 1–64 GPU 投影，证据类型有显式标签。
- `FINAL_AUDIT.json`：零请求错误、功率恢复、输出完备性总闸门。

只有 `FINAL_AUDIT.json` 中 `passed=true` 时，campaign 才能视为完成。论文中仍需报告
GPU 型号、驱动、CUDA、vLLM commit/version、拓扑、模型、原始 trace checksum、随机
种子和测量边界；这些信息由 preflight、manifest 与 freeze 文件保留。

不同生产 trace 原本对应不同规模的集群，不能把原始 QPS 直接压到一台 8 卡机器。
`pilot` 会从配置中的保守起点开始做 trace dilation，并在每个模型/来源上倍增 dilation，
直到默认策略满足 TTFT/TPOT；最终因子写入 `load_scales.json`，在冻结前固定。它只看
train split，既避免测试泄漏，也防止长 campaign 跑到一半才发现负载完全过载。

## 预计时长

真实时长取决于原始 trace 的 episode 数和请求负载。默认闭环测试为每个 source 3 个
5 分钟 episode × 9 方法 × 2 模型，单闭环部分约 22.5 小时，加上 profiling、模型
启动和下载通常需 1–3 天。它是正式实验量，不是几分钟的 smoke test；所有阶段均可恢复。
