#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from flexbid.config import canonical_hash, load_config


CUDA_MIN_DRIVER = {
    (11, 8): 520.61,
    (12, 0): 525.60,
    (12, 1): 525.60,
    (12, 2): 525.60,
    (12, 3): 545.23,
    (12, 4): 550.54,
    (12, 5): 555.42,
    (12, 6): 560.28,
    (12, 8): 570.26,
    (13, 0): 580.65,
}


def command(args: list[str]) -> dict:
    executable = shutil.which(args[0])
    if executable is None:
        return {"command": args, "ok": False, "error": "not found"}
    result = subprocess.run(args, text=True, capture_output=True, check=False)
    return {
        "command": args, "ok": result.returncode == 0,
        "return_code": result.returncode,
        "stdout": result.stdout.strip(), "stderr": result.stderr.strip(),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    config = load_config(args.config)
    hardware = config["hardware"]
    fields = (
        "index,name,uuid,driver_version,memory.total,power.draw,power.limit,"
        "power.default_limit,power.min_limit,power.max_limit,mig.mode.current,"
        "persistence_mode,temperature.gpu,utilization.gpu"
    )
    gpu = command(["nvidia-smi", f"--query-gpu={fields}", "--format=csv,noheader,nounits"])
    devices = []
    if gpu["ok"]:
        keys = fields.split(",")
        devices = [dict(zip(keys, [item.strip() for item in line.split(",")]))
                   for line in gpu["stdout"].splitlines() if line.strip()]
    expected_count = int(hardware["expected_gpu_count"])
    model_pattern = re.compile(hardware["expected_gpu_name_regex"], re.IGNORECASE)
    checks = {
        "gpu_count": len(devices) == expected_count,
        "gpu_model": bool(devices) and all(model_pattern.search(device["name"]) for device in devices),
        "gpu_idle": bool(devices) and all(float(device["utilization.gpu"]) == 0 for device in devices),
        "power_readable": bool(devices) and all(device["power.draw"].lower() != "n/a" for device in devices),
        "power_ranges": bool(devices) and all(device["power.min_limit"].lower() != "n/a" for device in devices),
        "python_310_plus": sys.version_info >= (3, 10),
        "vllm_installed": shutil.which("vllm") is not None,
    }
    torch_info = {"available": False}
    try:
        import torch

        torch_info = {
            "available": True, "version": torch.__version__,
            "cuda_runtime": torch.version.cuda,
            "cuda_available": torch.cuda.is_available(),
            "device_count": torch.cuda.device_count(),
        }
        checks["torch_cuda_count"] = torch.cuda.device_count() == expected_count
        if torch.version.cuda and devices:
            major, minor = map(int, torch.version.cuda.split(".")[:2])
            required = CUDA_MIN_DRIVER.get((major, minor))
            driver = float(".".join(devices[0]["driver_version"].split(".")[:2]))
            checks["driver_runtime_compatible"] = required is None or driver >= required
            torch_info["minimum_driver_hint"] = required
    except Exception as exc:
        torch_info["error"] = f"{type(exc).__name__}: {exc}"
        checks["torch_cuda_count"] = False
    disk = shutil.disk_usage(args.output.parent if args.output.parent.exists() else Path.cwd())
    checks["disk_free_200gb"] = disk.free >= 200 * 2**30
    processes = command([
        "nvidia-smi", "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
        "--format=csv,noheader,nounits",
    ])
    checks["no_foreign_compute_processes"] = processes["ok"] and not processes["stdout"].strip()
    try:
        from flexbid.runtime_scheduler import FlexBidScheduler  # noqa: F401
        checks["custom_scheduler_import"] = True
    except Exception as exc:
        checks["custom_scheduler_import"] = False
        torch_info["custom_scheduler_error"] = f"{type(exc).__name__}: {exc}"
    power_write = {"ok": False}
    try:
        import pynvml

        pynvml.nvmlInit()
        verified = []
        for index in range(pynvml.nvmlDeviceGetCount()):
            handle = pynvml.nvmlDeviceGetHandleByIndex(index)
            original = pynvml.nvmlDeviceGetEnforcedPowerLimit(handle)
            pynvml.nvmlDeviceSetPowerManagementLimit(handle, original)
            verified.append(pynvml.nvmlDeviceGetEnforcedPowerLimit(handle) == original)
        pynvml.nvmlShutdown()
        power_write = {"ok": all(verified), "tested_devices": len(verified),
                       "operation": "write current limit back unchanged"}
    except Exception as exc:
        power_write = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    checks["power_cap_write"] = power_write["ok"]
    report = {
        "schema_version": 1,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "config": str(args.config.resolve()),
        "config_hash": canonical_hash(config),
        "host": {"platform": platform.platform(), "python": sys.version},
        "gpu_query": gpu, "devices": devices,
        "topology": command(["nvidia-smi", "topo", "-m"]),
        "nvlink": command(["nvidia-smi", "nvlink", "-s"]),
        "compute_processes": processes,
        "torch": torch_info,
        "power_cap_write_test": power_write,
        "vllm_version": command(["vllm", "--version"]),
        "disk_free_gib": disk.free / 2**30,
        "checks": checks,
        "passed": all(checks.values()),
        "environment": {key: bool(os.environ.get(key)) for key in ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN")},
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({"passed": report["passed"], "checks": checks}, indent=2))
    if not report["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
